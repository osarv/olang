; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/list:listState.9783095779ea18337775adeb6569839d" = type { { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, i64, i64, i64 }
%"compiler/diag:Item" = type { i1, { i64, ptr }, i64, i64, i64, i64, { i64, ptr } }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/diag:context" = type { { i64, [3 x i64] }, { i64, ptr } }
%"compiler/diag:note" = type { i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/diag:record" = type { { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i32, i64, i1 }
define dso_local i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i1, ptr %t17, i64 %t14
  %t19 = load i1, ptr %t18, !tbaa !31
  store i1 %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i1, ptr %t60, i64 %t57
  %t62 = load i1, ptr %t61, !tbaa !31
  store i1 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i1, ptr %l1, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cBool_3e_2egrow_3cBool_3e(ptr %v0, ptr %t18, i1 %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i1, ptr %l1, !tbaa !21
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i1, ptr %t34, i64 %t29
  store i1 %t30, ptr %t35, !tbaa !31
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i64, ptr %t17, i64 %t14
  %t19 = load i64, ptr %t18, !tbaa !34
  store i64 %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i64, ptr %t60, i64 %t57
  %t62 = load i64, ptr %t61, !tbaa !34
  store i64 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eCl_He62a1125a32dfc5a59291318c690abf4(ptr %v0, ptr %a0)
  ret void
}

define dso_local i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l22 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l13
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l12
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  br label %bb7
bb3:
  %t13 = load i32, ptr %l13, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_67bd7411a85bddd6_397ca10f5085a562)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb7:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i64, ptr %t35, i64 %t32
  %t37 = load i64, ptr %t36, !tbaa !34
  %t43 = icmp eq i64 %t37, %a1
  br i1 %t43, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb8
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t50, %t51
  store i64 %t54, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb1
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l10 = alloca { i64, ptr }
  %rv = alloca { i32, i64 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2edropLast_3cI64_3e(ptr %v0, ptr %t15)
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t17, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l10, !tbaa !27
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t21, i32 0, i32 5
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i64, ptr %t27, i64 %t24
  %t29 = load i64, ptr %t28, !tbaa !34
  %t31 = insertvalue { i32, i64 } zeroinitializer, i64 %t29, 1
  store { i32, i64 } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca i64
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t14
  store i64 %t15, ptr %t20, !tbaa !34
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l17
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l17, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l4, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l24, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  store i64 %t50, ptr %l27, !tbaa !24
  %t52 = load i64, ptr %l27, !tbaa !24
  %t53 = load i64, ptr %l27, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t58 = load i64, ptr %l2, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t57
  store i64 %t58, ptr %t63, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2ePush_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:Item" %a1) #0 {
entry:
  %l1 = alloca %"compiler/diag:Item"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/diag:Item" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/diag:Item", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aItem_3e_2egrow_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %v1, ptr %t18, %"compiler/diag:Item" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/diag:Item", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/diag:Item", ptr %t34, i64 %t29
  store %"compiler/diag:Item" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ePush_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:Said" %a1) #0 {
entry:
  %l1 = alloca %"compiler/diag:Said"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/diag:Said" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/diag:Said", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aSaid_3e_2egrow_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %v1, ptr %t18, %"compiler/diag:Said" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/diag:Said", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/diag:Said", ptr %t34, i64 %t29
  store %"compiler/diag:Said" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/diag:context" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca %"compiler/diag:context"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr %"compiler/diag:context", ptr %t17, i64 %t14
  %t19 = load %"compiler/diag:context", ptr %t18
  store %"compiler/diag:context" %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/diag:context", ptr %t60, i64 %t57
  %t62 = load %"compiler/diag:context", ptr %t61
  store %"compiler/diag:context" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diag:context", ptr %rv
  ret %"compiler/diag:context" %rr
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eLen_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i32, %"compiler/diag:context" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2ePop_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l10 = alloca { i64, ptr }
  %rv = alloca { i32, %"compiler/diag:context" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t14 = insertvalue { i32, %"compiler/diag:context" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/diag:context" } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2edropLast_3cI64_3e(ptr %v0, ptr %t15)
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t17, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l10, !tbaa !27
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t21, i32 0, i32 5
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr %"compiler/diag:context", ptr %t27, i64 %t24
  %t29 = load %"compiler/diag:context", ptr %t28
  %t31 = insertvalue { i32, %"compiler/diag:context" } zeroinitializer, %"compiler/diag:context" %t29, 1
  store { i32, %"compiler/diag:context" } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/diag:context" }, ptr %rv
  ret { i32, %"compiler/diag:context" } %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2ePush_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:context" %a1) #0 {
entry:
  %l1 = alloca %"compiler/diag:context"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/diag:context" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/diag:context", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3acontext_3e_2_H09014fe2f5a328755d1b786d930a509d(ptr %v0, ptr %v1, ptr %t18, %"compiler/diag:context" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/diag:context", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/diag:context", ptr %t34, i64 %t29
  store %"compiler/diag:context" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/diag:note" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca %"compiler/diag:note"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr %"compiler/diag:note", ptr %t17, i64 %t14
  %t19 = load %"compiler/diag:note", ptr %t18
  store %"compiler/diag:note" %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/diag:note", ptr %t60, i64 %t57
  %t62 = load %"compiler/diag:note", ptr %t61
  store %"compiler/diag:note" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diag:note", ptr %rv
  ret %"compiler/diag:note" %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eClear_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eCl_He62a1125a32dfc5a59291318c690abf4(ptr %v0, ptr %a0)
  ret void
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eLen_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2ePush_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:note" %a1) #0 {
entry:
  %l1 = alloca %"compiler/diag:note"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/diag:note" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/diag:note", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3anote_3e_2egrow_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v1, ptr %t18, %"compiler/diag:note" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/diag:note", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/diag:note", ptr %t34, i64 %t29
  store %"compiler/diag:note" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eRunFrom_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 1
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l17, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t34, i32 0, i32 5
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4276aa0d6ff50940_61ad4d4404298084)
  unreachable
bb11:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_4276aa0d6ff50940_61ad4d4404298084)
  unreachable
bb13:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = getelementptr %"compiler/diag:note", ptr %t52, i64 %t53
  %t56 = sub i64 %t54, %t53
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_4276aa0d6ff50940_61ad4d4404298084)
  unreachable
bb15:
  %t61 = load ptr, ptr %l2, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t66)
  store i64 %t68, ptr %l30
  br label %bb16
bb16:
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t70 = load i64, ptr %l30, !tbaa !24
  %t72 = sub i64 %t70, %t69
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l26, !tbaa !29
  %t77 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3anote_3e_2erunIn_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %t74, i64 %t72, i64 %t73)
  store { i64, ptr } %t77, ptr %l34
  br label %bb17
bb17:
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t78, 1
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eSetAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/diag:note" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/diag:note"
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l17 = alloca i64
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l27 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/diag:note" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load %"compiler/diag:note", ptr %l2
  %t18 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr %"compiler/diag:note", ptr %t19, i64 %t14
  store %"compiler/diag:note" %t15, ptr %t20
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l17
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l17, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l4, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l24, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  store i64 %t50, ptr %l27, !tbaa !24
  %t52 = load i64, ptr %l27, !tbaa !24
  %t53 = load i64, ptr %l27, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t58 = load %"compiler/diag:note", ptr %l2
  %t61 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr %"compiler/diag:note", ptr %t62, i64 %t57
  store %"compiler/diag:note" %t58, ptr %t63
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eTruncate_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l19 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l36 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sle i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eCl_He62a1125a32dfc5a59291318c690abf4(ptr %v0, ptr %t19)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %ret
bb7:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t27 = add i64 %t23, %t24
  store i64 %t27, ptr %l3, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t29)
  store i64 %t31, ptr %l19
  br label %bb8
bb8:
  %t32 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t33 = load i64, ptr %l19, !tbaa !24
  %t35 = sub i64 %t33, %t32
  store i64 %t35, ptr %l4, !tbaa !24
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = add i64 %t38, 1
  %t43 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 2
  store i64 %t40, ptr %t43, !tbaa !24
  %t44 = load ptr, ptr %l2, !tbaa !29
  store ptr %t44, ptr %l25, !tbaa !29
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t45, i64 %t46)
  store { i64, ptr } %t49, ptr %l28
  br label %bb9
bb9:
  %t50 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t51 = load ptr, ptr %l25, !tbaa !29
  %t52 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t51, i32 0, i32 4
  store { i64, ptr } %t50, ptr %t52, !tbaa !27
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t54, i32 0, i32 4
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t62 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t53, i32 0, i32 6
  store i64 %t59, ptr %t62, !tbaa !24
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t64 = load i64, ptr %l3, !tbaa !24
  %t65 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t66 = load i64, ptr %l4, !tbaa !24
  store i64 %t66, ptr %l36, !tbaa !24
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = load i64, ptr %l36, !tbaa !24
  %t70 = shl i64 %t65, %t69
  %t73 = sub i64 %t64, %t70
  %t75 = add i64 %t73, 1
  %t78 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t63, i32 0, i32 5
  store i64 %t75, ptr %t78, !tbaa !24
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load i64, ptr %l1, !tbaa !24
  %t83 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 7
  store i64 %t80, ptr %t83, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/diag:record" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %rv = alloca %"compiler/diag:record"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr %"compiler/diag:record", ptr %t17, i64 %t14
  %t19 = load %"compiler/diag:record", ptr %t18
  store %"compiler/diag:record" %t19, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t25 = add i64 %t21, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t27)
  store i64 %t29, ptr %l16
  br label %bb4
bb4:
  %t30 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t33 = sub i64 %t31, %t30
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l21, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = shl i64 %t49, %t53
  %t57 = sub i64 %t48, %t54
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/diag:record", ptr %t60, i64 %t57
  %t62 = load %"compiler/diag:record", ptr %t61
  store %"compiler/diag:record" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diag:record", ptr %rv
  ret %"compiler/diag:record" %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eClear_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %a0) #0 {
entry:
  tail call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eCl_He62a1125a32dfc5a59291318c690abf4(ptr %v0, ptr %a0)
  ret void
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2ePush_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:record" %a1) #0 {
entry:
  %l1 = alloca %"compiler/diag:record"
  %l2 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l20 = alloca ptr
  store %"compiler/diag:record" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 5
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t10, i32 0, i32 6
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp eq i64 %t9, %t13
  br i1 %t16, label %bb1, label %bb2
bb1:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load %"compiler/diag:record", ptr %l1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3arecord_3e_2e_H172244b976f4addfba88daa841d19719(ptr %v0, ptr %v1, ptr %t18, %"compiler/diag:record" %t19)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 4
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load %"compiler/diag:record", ptr %l1
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/diag:record", ptr %t34, i64 %t29
  store %"compiler/diag:record" %t30, ptr %t35
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t37, i32 0, i32 5
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = add i64 %t39, 1
  %t43 = load ptr, ptr %l17, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t43, i32 0, i32 5
  store i64 %t41, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t46, i32 0, i32 7
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t52, i32 0, i32 7
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eRunFrom_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 1
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l17, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t34, i32 0, i32 5
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5079283e2d8c0a18_20afd8541d03fe8c)
  unreachable
bb11:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_5079283e2d8c0a18_20afd8541d03fe8c)
  unreachable
bb13:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = getelementptr %"compiler/diag:record", ptr %t52, i64 %t53
  %t56 = sub i64 %t54, %t53
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_5079283e2d8c0a18_20afd8541d03fe8c)
  unreachable
bb15:
  %t61 = load ptr, ptr %l2, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t66)
  store i64 %t68, ptr %l30
  br label %bb16
bb16:
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t70 = load i64, ptr %l30, !tbaa !24
  %t72 = sub i64 %t70, %t69
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l26, !tbaa !29
  %t77 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3arecord_3e_2e_H5c7a1efa90166c7eb19ac0411c8ca654(ptr %v0, ptr %t74, i64 %t72, i64 %t73)
  store { i64, ptr } %t77, ptr %l34
  br label %bb17
bb17:
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t78, 1
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

@std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eTrunc_Hfb0c5ceb44a5ca5b5beffc6b7a3329ef = dso_local alias void (ptr, ptr, i64), ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eTruncate_3ccompiler_2fdiag_3anote_3e
define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cBool_3e_2echunk_3cBool_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cBool_3e_2egrow_3cBool_3e(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca i64
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i1
  %l104 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l111 = alloca ptr
  %s9 = alloca %olang.scope
  %t51 = alloca i64
  %t101 = alloca i64
  %t134 = alloca i64
  %t247 = alloca i64
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb37
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load i1, ptr %l1, !tbaa !21
  store i1 %t34, ptr %l24, !tbaa !21
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb8, label %bb9
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t48)
  %t50 = load i1, ptr %l24, !tbaa !21
  store i64 0, ptr %t51
  br label %fill.52
fill.52:
  %t55 = load i64, ptr %t51
  %t56 = icmp slt i64 %t55, %t47
  br i1 %t56, label %fillb.53, label %filld.54
fillb.53:
  %t57 = getelementptr i1, ptr %t49, i64 %t55
  store i1 %t50, ptr %t57
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %t51
  br label %fill.52
filld.54:
  %t59 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t49, 1
  %t62 = load ptr, ptr %l22, !tbaa !29
  %t63 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t62, i32 0, i32 1
  store { i64, ptr } %t60, ptr %t63, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t71 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t64, i32 0, i32 4
  store { i64, ptr } %t68, ptr %t71, !tbaa !27
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t72, i32 0, i32 3
  store i64 1, ptr %t74, !tbaa !24
  br label %bb36
bb7:
  call void @__olang_check_failed(ptr @olang_loc_4d334469e801b5bb_528e26417185845f)
  unreachable
bb8:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l35, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l37, !tbaa !27
  %t80 = icmp sge i64 4, 0
  br i1 %t80, label %bb10, label %bb11
bb9:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t82, i32 0, i32 3
  %t85 = load i64, ptr %t84, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t94 = icmp eq i64 %t85, %t91
  br i1 %t94, label %bb14, label %bb15
bb10:
  %t96 = icmp sle i64 4, 576460752303423487
  br i1 %t96, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4fe1a86f19e49226_efb78e903136768a)
  unreachable
bb12:
  %t98 = mul i64 4, 16
  %t99 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t98)
  %t100 = load { i64, ptr }, ptr %l37, !tbaa !27
  store i64 0, ptr %t101
  br label %fill.102
fill.102:
  %t105 = load i64, ptr %t101
  %t106 = icmp slt i64 %t105, 4
  br i1 %t106, label %fillb.103, label %filld.104
fillb.103:
  %t107 = getelementptr { i64, ptr }, ptr %t99, i64 %t105
  store { i64, ptr } %t100, ptr %t107
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %t101
  br label %fill.102
filld.104:
  %t109 = insertvalue { i64, ptr } undef, i64 4, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t99, 1
  %t112 = load ptr, ptr %l35, !tbaa !29
  %t113 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t112, i32 0, i32 0
  store { i64, ptr } %t110, ptr %t113, !tbaa !27
  br label %bb33
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4fe1a86f19e49226_efb78e903136768a)
  unreachable
bb14:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t114, i32 0, i32 3
  %t117 = load i64, ptr %t116, !tbaa !24
  %t119 = mul i64 %t117, 2
  store i64 %t119, ptr %l49, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t120, i32 0, i32 1
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l51, !tbaa !27
  %t124 = load i64, ptr %l49, !tbaa !24
  %t125 = icmp sge i64 %t124, 0
  br i1 %t125, label %bb16, label %bb17
bb15:
  br label %bb32
bb16:
  %t127 = load i64, ptr %l49, !tbaa !24
  %t128 = icmp sle i64 %t127, 576460752303423487
  br i1 %t128, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_fe2211e759cb4c45_752cc5452836f349)
  unreachable
bb18:
  %t130 = load i64, ptr %l49, !tbaa !24
  %t131 = mul i64 %t130, 16
  %t132 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t131)
  %t133 = load { i64, ptr }, ptr %l51, !tbaa !27
  store i64 0, ptr %t134
  br label %fill.135
fill.135:
  %t138 = load i64, ptr %t134
  %t139 = icmp slt i64 %t138, %t130
  br i1 %t139, label %fillb.136, label %filld.137
fillb.136:
  %t140 = getelementptr { i64, ptr }, ptr %t132, i64 %t138
  store { i64, ptr } %t133, ptr %t140
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %t134
  br label %fill.135
filld.137:
  %t142 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t132, 1
  store { i64, ptr } %t143, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t145, i32 0, i32 3
  %t148 = load i64, ptr %t147, !tbaa !24
  store i64 %t148, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t150 = load i64, ptr %l4, !tbaa !24
  %t151 = load i64, ptr %l3, !tbaa !24
  %t154 = icmp sgt i64 %t150, %t151
  br i1 %t154, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_fe2211e759cb4c45_752cc5452836f349)
  unreachable
bb20:
  %t156 = load i64, ptr %l5, !tbaa !24
  %t158 = icmp sgt i64 %t156, 0
  br i1 %t158, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb25
bb22:
  %t160 = load i64, ptr %l4, !tbaa !24
  %t161 = load i64, ptr %l3, !tbaa !24
  %t164 = sub i64 %t160, %t161
  %t165 = load i64, ptr %l5, !tbaa !24
  %t168 = add i64 %t164, %t165
  %t170 = sub i64 %t168, 1
  %t171 = load i64, ptr %l5, !tbaa !24
  %t174 = sdiv i64 %t170, %t171
  store i64 %t174, ptr %l63, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb24
bb24:
  %t176 = load i64, ptr %l63, !tbaa !24
  store i64 %t176, ptr %l60, !tbaa !24
  br label %bb25
bb25:
  %t177 = load i64, ptr %l60, !tbaa !24
  store i64 %t177, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s9
  %t178 = load i64, ptr %l7, !tbaa !24
  %t179 = load i64, ptr %l6, !tbaa !24
  %t182 = icmp slt i64 %t178, %t179
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t186 = load i64, ptr %l3, !tbaa !24
  %t187 = load i64, ptr %l7, !tbaa !24
  %t188 = load i64, ptr %l5, !tbaa !24
  %t191 = mul i64 %t187, %t188
  %t194 = add i64 %t186, %t191
  store i64 %t194, ptr %l8, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t196, ptr %l81, !tbaa !27
  %t197 = load i64, ptr %l8, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t198, i32 0, i32 0
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l84, !tbaa !27
  %t202 = load i64, ptr %l8, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %t205, i64 %t202
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !37
  %t210 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr { i64, ptr }, ptr %t211, i64 %t197
  store { i64, ptr } %t207, ptr %t212, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb30
bb30:
  %t213 = load i64, ptr %l7, !tbaa !24
  %t215 = add i64 %t213, 1
  store i64 %t215, ptr %l7, !tbaa !24
  br label %bb26
bb31:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t221 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t217, i32 0, i32 0
  store { i64, ptr } %t218, ptr %t221, !tbaa !27
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t222, i32 0, i32 0
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  store { i64, ptr } %t225, ptr %l92, !tbaa !27
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t226, i32 0, i32 3
  %t229 = load i64, ptr %t228, !tbaa !24
  store i64 %t229, ptr %l94, !tbaa !24
  %t230 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t231, i32 0, i32 3
  %t234 = load i64, ptr %t233, !tbaa !24
  store i64 %t234, ptr %l97, !tbaa !24
  %t236 = load i64, ptr %l97, !tbaa !24
  %t237 = load i64, ptr %l97, !tbaa !24
  %t238 = shl i64 %t230, %t237
  store i64 %t238, ptr %l98, !tbaa !24
  %t239 = load i1, ptr %l1, !tbaa !21
  store i1 %t239, ptr %l99, !tbaa !21
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = icmp sge i64 %t240, 0
  br i1 %t241, label %bb34, label %bb35
bb34:
  %t243 = load i64, ptr %l98, !tbaa !24
  %t244 = mul i64 %t243, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t244)
  %t246 = load i1, ptr %l99, !tbaa !21
  store i64 0, ptr %t247
  br label %fill.248
fill.248:
  %t251 = load i64, ptr %t247
  %t252 = icmp slt i64 %t251, %t243
  br i1 %t252, label %fillb.249, label %filld.250
fillb.249:
  %t253 = getelementptr i1, ptr %t245, i64 %t251
  store i1 %t246, ptr %t253
  %t254 = add i64 %t251, 1
  store i64 %t254, ptr %t247
  br label %fill.248
filld.250:
  %t255 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t245, 1
  %t258 = load i64, ptr %l94, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %t260, i64 %t258
  store { i64, ptr } %t256, ptr %t261, !tbaa !37
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t263, i32 0, i32 0
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  store { i64, ptr } %t266, ptr %l104, !tbaa !27
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t267, i32 0, i32 3
  %t270 = load i64, ptr %t269, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %t273, i64 %t270
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !37
  %t278 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t262, i32 0, i32 4
  store { i64, ptr } %t275, ptr %t278, !tbaa !27
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l108, !tbaa !29
  %t280 = load ptr, ptr %l108, !tbaa !29
  %t281 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t280, i32 0, i32 3
  %t282 = load i64, ptr %t281, !tbaa !24
  %t284 = add i64 %t282, 1
  %t286 = load ptr, ptr %l108, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  store i64 %t284, ptr %t287, !tbaa !24
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_8b6b1bdbb1597ad8_6e13662896aee6fc)
  unreachable
bb36:
  br label %bb37
bb37:
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l111, !tbaa !29
  %t289 = load ptr, ptr %l111, !tbaa !29
  %t290 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t289, i32 0, i32 2
  %t291 = load i64, ptr %t290, !tbaa !24
  %t293 = add i64 %t291, 1
  %t295 = load ptr, ptr %l111, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  store i64 %t293, ptr %t296, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t297, i32 0, i32 5
  store i64 0, ptr %t299, !tbaa !24
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 4
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t300, i32 0, i32 6
  store i64 %t306, ptr %t309, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2edropLast_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp eq i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t9, i32 0, i32 2
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = sub i64 %t11, 1
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  store i64 %t13, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l7, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t19, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = sub i64 %t22, 1
  %t27 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t18, i64 %t24)
  store { i64, ptr } %t27, ptr %l12
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t28 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t29 = load ptr, ptr %l7, !tbaa !29
  %t30 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t29, i32 0, i32 4
  store { i64, ptr } %t28, ptr %t30, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t32, i32 0, i32 4
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t31, i32 0, i32 6
  store i64 %t37, ptr %t40, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t42, i32 0, i32 6
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t41, i32 0, i32 5
  store i64 %t45, ptr %t48, !tbaa !24
  br label %bb4
bb4:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l20, !tbaa !29
  %t50 = load ptr, ptr %l20, !tbaa !29
  %t51 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t50, i32 0, i32 5
  %t52 = load i64, ptr %t51, !tbaa !24
  %t54 = sub i64 %t52, 1
  %t56 = load ptr, ptr %l20, !tbaa !29
  %t57 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t56, i32 0, i32 5
  store i64 %t54, ptr %t57, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l23, !tbaa !29
  %t59 = load ptr, ptr %l23, !tbaa !29
  %t60 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t59, i32 0, i32 7
  %t61 = load i64, ptr %t60, !tbaa !24
  %t63 = sub i64 %t61, 1
  %t65 = load ptr, ptr %l23, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 7
  store i64 %t63, ptr %t66, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aItem_3e_2echunk_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aItem_3e_2egrow_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:Item" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/diag:Item"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/diag:Item"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/diag:Item"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/diag:Item" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/diag:Item", ptr %l1
  store %"compiler/diag:Item" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 128102389400760775
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_c825086be23f399d_4f9a04d0dc8995d1)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 72
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/diag:Item", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/diag:Item", ptr %t52, i64 %t58
  store %"compiler/diag:Item" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c825086be23f399d_4f9a04d0dc8995d1)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8b5965bdfdd8e6f0_92795128512067c4)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_8b5965bdfdd8e6f0_92795128512067c4)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_b7c998588f92f993_3a96d949c06544a7)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b7c998588f92f993_3a96d949c06544a7)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/diag:Item", ptr %l1
  store %"compiler/diag:Item" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 128102389400760775
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_313798fac044245e_494ea0b5c4e628b2)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 72
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/diag:Item", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/diag:Item", ptr %t251, i64 %t257
  store %"compiler/diag:Item" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_313798fac044245e_494ea0b5c4e628b2)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aSaid_3e_2echunk_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aSaid_3e_2egrow_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:Said" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/diag:Said"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/diag:Said"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/diag:Said"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/diag:Said" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/diag:Said", ptr %l1
  store %"compiler/diag:Said" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 192153584101141162
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_26b0dd57c84bdd1_9bb6b561f398bf95)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 48
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/diag:Said", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/diag:Said", ptr %t52, i64 %t58
  store %"compiler/diag:Said" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_26b0dd57c84bdd1_9bb6b561f398bf95)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_454a5a2cf11b8fc4_8feb825bcdacb3a8)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_454a5a2cf11b8fc4_8feb825bcdacb3a8)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_ed67e24e60606ca7_7a07a22fbfdf710b)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ed67e24e60606ca7_7a07a22fbfdf710b)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/diag:Said", ptr %l1
  store %"compiler/diag:Said" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 192153584101141162
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_fc1fa9ba64e150b2_6234d56134b2d676)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 48
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/diag:Said", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/diag:Said", ptr %t251, i64 %t257
  store %"compiler/diag:Said" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_fc1fa9ba64e150b2_6234d56134b2d676)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3acontext_3e_2_H09014fe2f5a328755d1b786d930a509d(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:context" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/diag:context"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/diag:context"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/diag:context"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/diag:context" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/diag:context", ptr %l1
  store %"compiler/diag:context" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 192153584101141162
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_11ef750acf242625_17cbbe56136a7549)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 48
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/diag:context", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/diag:context", ptr %t52, i64 %t58
  store %"compiler/diag:context" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_11ef750acf242625_17cbbe56136a7549)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_fd690b86fe282bb8_10b25f3981e268fc)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fd690b86fe282bb8_10b25f3981e268fc)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_dab00dff291fcd9b_f52d1f525cb9065f)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_dab00dff291fcd9b_f52d1f525cb9065f)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/diag:context", ptr %l1
  store %"compiler/diag:context" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 192153584101141162
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_8e80142f12a10406_925687a11c69f88a)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 48
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/diag:context", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/diag:context", ptr %t251, i64 %t257
  store %"compiler/diag:context" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_8e80142f12a10406_925687a11c69f88a)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3acontext_3e_2_H537afcb7fb34649bea1649309d9acc6a(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

@std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3acontext_3e_2_Hb2d2d7b66c2b581b9231174a62b52e08 = dso_local alias void (ptr, ptr), ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cI64_3e_2edropLast_3cI64_3e
define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3anote_3e_2echunk_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3anote_3e_2egrow_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:note" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/diag:note"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/diag:note"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/diag:note"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/diag:note" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/diag:note", ptr %l1
  store %"compiler/diag:note" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 164703072086692425
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_27857e08243125f7_f51b68382dadfe8b)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 56
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/diag:note", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/diag:note", ptr %t52, i64 %t58
  store %"compiler/diag:note" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_27857e08243125f7_f51b68382dadfe8b)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_479fd5b990642e42_dd489b69a28163f6)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_479fd5b990642e42_dd489b69a28163f6)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_9f87ecf65d9dc361_16ca7b6a61674d15)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9f87ecf65d9dc361_16ca7b6a61674d15)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/diag:note", ptr %l1
  store %"compiler/diag:note" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 164703072086692425
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_ba26f8d95088b54_aff48643b7b4128)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 56
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/diag:note", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/diag:note", ptr %t251, i64 %t257
  store %"compiler/diag:note" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_ba26f8d95088b54_aff48643b7b4128)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3anote_3e_2erunIn_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t2, i32 0, i32 2
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = sub i64 %t5, 1
  %t10 = icmp eq i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t12, i64 %t13)
  store { i64, ptr } %t16, ptr %l10
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t23 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = shl i64 %t23, %t27
  %t31 = sub i64 %t22, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb4, label %bb5
bb4:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_579ac17f97fbdc0e_f38472f074dc1752)
  unreachable
bb6:
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_579ac17f97fbdc0e_f38472f074dc1752)
  unreachable
bb8:
  %t49 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l18, !tbaa !24
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = getelementptr %"compiler/diag:note", ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_579ac17f97fbdc0e_f38472f074dc1752)
  unreachable
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t58, i64 %t59)
  store { i64, ptr } %t62, ptr %l28
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l29, !tbaa !27
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  store i64 %t70, ptr %l34, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  %t73 = load i64, ptr %l34, !tbaa !24
  %t74 = shl i64 %t69, %t73
  %t77 = sub i64 %t68, %t74
  store i64 %t77, ptr %l36, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l39
  br label %bb12
bb12:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 0
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l43, !tbaa !24
  %t89 = load i64, ptr %l36, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load i64, ptr %l36, !tbaa !24
  %t93 = load i64, ptr %l42, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e30b01b101f6280b_74200f6bb26f874f)
  unreachable
bb15:
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = load i64, ptr %l43, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e30b01b101f6280b_74200f6bb26f874f)
  unreachable
bb17:
  %t100 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l36, !tbaa !24
  %t103 = load i64, ptr %l42, !tbaa !24
  %t104 = getelementptr %"compiler/diag:note", ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e30b01b101f6280b_74200f6bb26f874f)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3arecord_3e_2e_H172244b976f4addfba88daa841d19719(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:record" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/diag:record"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/diag:record"
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca %"compiler/diag:record"
  %l106 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l113 = alloca ptr
  %s9 = alloca %olang.scope
  %t54 = alloca i64
  %t104 = alloca i64
  %t137 = alloca i64
  %t253 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/diag:record" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t14, i64 %t18)
  store { i64, ptr } %t21, ptr %l18
  br label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  %t29 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t30, i32 0, i32 4
  store { i64, ptr } %t29, ptr %t31, !tbaa !27
  br label %bb41
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  %t34 = load %"compiler/diag:record", ptr %l1
  store %"compiler/diag:record" %t34, ptr %l24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb6:
  %t47 = load i64, ptr %l23, !tbaa !24
  %t48 = icmp sle i64 %t47, 104811045873349725
  br i1 %t48, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1b3bad14a137350a_15de62cc2adde936)
  unreachable
bb8:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = mul i64 %t50, 88
  %t52 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t51)
  %t53 = load %"compiler/diag:record", ptr %l24
  store i64 0, ptr %t54
  br label %fill.55
fill.55:
  %t58 = load i64, ptr %t54
  %t59 = icmp slt i64 %t58, %t50
  br i1 %t59, label %fillb.56, label %filld.57
fillb.56:
  %t60 = getelementptr %"compiler/diag:record", ptr %t52, i64 %t58
  store %"compiler/diag:record" %t53, ptr %t60
  %t61 = add i64 %t58, 1
  store i64 %t61, ptr %t54
  br label %fill.55
filld.57:
  %t62 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t52, 1
  %t65 = load ptr, ptr %l22, !tbaa !29
  %t66 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t65, i32 0, i32 1
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t74 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t67, i32 0, i32 4
  store { i64, ptr } %t71, ptr %t74, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t75, i32 0, i32 3
  store i64 1, ptr %t77, !tbaa !24
  br label %bb40
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1b3bad14a137350a_15de62cc2adde936)
  unreachable
bb10:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = icmp sge i64 4, 0
  br i1 %t83, label %bb12, label %bb13
bb11:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t89, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp eq i64 %t88, %t94
  br i1 %t97, label %bb16, label %bb17
bb12:
  %t99 = icmp sle i64 4, 576460752303423487
  br i1 %t99, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7e1244c5e18642df_d9394ba5955009cb)
  unreachable
bb14:
  %t101 = mul i64 4, 16
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store i64 0, ptr %t104
  br label %fill.105
fill.105:
  %t108 = load i64, ptr %t104
  %t109 = icmp slt i64 %t108, 4
  br i1 %t109, label %fillb.106, label %filld.107
fillb.106:
  %t110 = getelementptr { i64, ptr }, ptr %t102, i64 %t108
  store { i64, ptr } %t103, ptr %t110
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %t104
  br label %fill.105
filld.107:
  %t112 = insertvalue { i64, ptr } undef, i64 4, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t102, 1
  %t115 = load ptr, ptr %l36, !tbaa !29
  %t116 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t115, i32 0, i32 0
  store { i64, ptr } %t113, ptr %t116, !tbaa !27
  br label %bb35
bb15:
  call void @__olang_check_failed(ptr @olang_loc_7e1244c5e18642df_d9394ba5955009cb)
  unreachable
bb16:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 3
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = mul i64 %t120, 2
  store i64 %t122, ptr %l50, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l52, !tbaa !27
  %t127 = load i64, ptr %l50, !tbaa !24
  %t128 = icmp sge i64 %t127, 0
  br i1 %t128, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t130 = load i64, ptr %l50, !tbaa !24
  %t131 = icmp sle i64 %t130, 576460752303423487
  br i1 %t131, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_999784ad06afa57c_75fdf29414147e68)
  unreachable
bb20:
  %t133 = load i64, ptr %l50, !tbaa !24
  %t134 = mul i64 %t133, 16
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = load { i64, ptr }, ptr %l52, !tbaa !27
  store i64 0, ptr %t137
  br label %fill.138
fill.138:
  %t141 = load i64, ptr %t137
  %t142 = icmp slt i64 %t141, %t133
  br i1 %t142, label %fillb.139, label %filld.140
fillb.139:
  %t143 = getelementptr { i64, ptr }, ptr %t135, i64 %t141
  store { i64, ptr } %t136, ptr %t143
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %t137
  br label %fill.138
filld.140:
  %t145 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t135, 1
  store { i64, ptr } %t146, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l4, !tbaa !24
  %t154 = load i64, ptr %l3, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_999784ad06afa57c_75fdf29414147e68)
  unreachable
bb22:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb27
bb24:
  %t163 = load i64, ptr %l4, !tbaa !24
  %t164 = load i64, ptr %l3, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l5, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l5, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l64, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb26
bb26:
  %t179 = load i64, ptr %l64, !tbaa !24
  store i64 %t179, ptr %l61, !tbaa !24
  br label %bb27
bb27:
  %t180 = load i64, ptr %l61, !tbaa !24
  store i64 %t180, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s9
  %t181 = load i64, ptr %l7, !tbaa !24
  %t182 = load i64, ptr %l6, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t189 = load i64, ptr %l3, !tbaa !24
  %t190 = load i64, ptr %l7, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  store i64 %t197, ptr %l8, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t199, ptr %l82, !tbaa !27
  %t200 = load i64, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t201, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l85, !tbaa !27
  %t205 = load i64, ptr %l8, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %t208, i64 %t205
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !37
  %t213 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t200
  store { i64, ptr } %t210, ptr %t215, !tbaa !37
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb32:
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l7, !tbaa !24
  br label %bb28
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t220, i32 0, i32 0
  store { i64, ptr } %t221, ptr %t224, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t225, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l93, !tbaa !27
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t229, i32 0, i32 3
  %t232 = load i64, ptr %t231, !tbaa !24
  store i64 %t232, ptr %l95, !tbaa !24
  %t233 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l98, !tbaa !24
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = load i64, ptr %l98, !tbaa !24
  %t241 = shl i64 %t233, %t240
  store i64 %t241, ptr %l99, !tbaa !24
  %t242 = load %"compiler/diag:record", ptr %l1
  store %"compiler/diag:record" %t242, ptr %l100
  %t243 = load i64, ptr %l99, !tbaa !24
  %t244 = icmp sge i64 %t243, 0
  br i1 %t244, label %bb36, label %bb37
bb36:
  %t246 = load i64, ptr %l99, !tbaa !24
  %t247 = icmp sle i64 %t246, 104811045873349725
  br i1 %t247, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_a0b0e3c99837b1c9_d89b02a654bf2e55)
  unreachable
bb38:
  %t249 = load i64, ptr %l99, !tbaa !24
  %t250 = mul i64 %t249, 88
  %t251 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t250)
  %t252 = load %"compiler/diag:record", ptr %l100
  store i64 0, ptr %t253
  br label %fill.254
fill.254:
  %t257 = load i64, ptr %t253
  %t258 = icmp slt i64 %t257, %t249
  br i1 %t258, label %fillb.255, label %filld.256
fillb.255:
  %t259 = getelementptr %"compiler/diag:record", ptr %t251, i64 %t257
  store %"compiler/diag:record" %t252, ptr %t259
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %t253
  br label %fill.254
filld.256:
  %t261 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t251, 1
  %t264 = load i64, ptr %l95, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t264
  store { i64, ptr } %t262, ptr %t267, !tbaa !37
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l106, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t273, i32 0, i32 3
  %t276 = load i64, ptr %t275, !tbaa !24
  %t278 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %t279, i64 %t276
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !37
  %t284 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t268, i32 0, i32 4
  store { i64, ptr } %t281, ptr %t284, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l110, !tbaa !29
  %t286 = load ptr, ptr %l110, !tbaa !29
  %t287 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t286, i32 0, i32 3
  %t288 = load i64, ptr %t287, !tbaa !24
  %t290 = add i64 %t288, 1
  %t292 = load ptr, ptr %l110, !tbaa !29
  %t293 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t292, i32 0, i32 3
  store i64 %t290, ptr %t293, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_a0b0e3c99837b1c9_d89b02a654bf2e55)
  unreachable
bb40:
  br label %bb41
bb41:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l113, !tbaa !29
  %t295 = load ptr, ptr %l113, !tbaa !29
  %t296 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t295, i32 0, i32 2
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = add i64 %t297, 1
  %t301 = load ptr, ptr %l113, !tbaa !29
  %t302 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t301, i32 0, i32 2
  store i64 %t299, ptr %t302, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t303, i32 0, i32 5
  store i64 0, ptr %t305, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t307, i32 0, i32 4
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t315 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t306, i32 0, i32 6
  store i64 %t312, ptr %t315, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3arecord_3e_2e_H5c7a1efa90166c7eb19ac0411c8ca654(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t2, i32 0, i32 2
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = sub i64 %t5, 1
  %t10 = icmp eq i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t12, i64 %t13)
  store { i64, ptr } %t16, ptr %l10
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t23 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = shl i64 %t23, %t27
  %t31 = sub i64 %t22, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb4, label %bb5
bb4:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3b15a85c7b2e94f4_25b0f2d66071e068)
  unreachable
bb6:
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3b15a85c7b2e94f4_25b0f2d66071e068)
  unreachable
bb8:
  %t49 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l18, !tbaa !24
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = getelementptr %"compiler/diag:record", ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_3b15a85c7b2e94f4_25b0f2d66071e068)
  unreachable
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t58, i64 %t59)
  store { i64, ptr } %t62, ptr %l28
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l29, !tbaa !27
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  store i64 %t70, ptr %l34, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  %t73 = load i64, ptr %l34, !tbaa !24
  %t74 = shl i64 %t69, %t73
  %t77 = sub i64 %t68, %t74
  store i64 %t77, ptr %l36, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l39
  br label %bb12
bb12:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 0
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l43, !tbaa !24
  %t89 = load i64, ptr %l36, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load i64, ptr %l36, !tbaa !24
  %t93 = load i64, ptr %l42, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_e9d163bbb40732e1_d05f2d0aec414c45)
  unreachable
bb15:
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = load i64, ptr %l43, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e9d163bbb40732e1_d05f2d0aec414c45)
  unreachable
bb17:
  %t100 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l36, !tbaa !24
  %t103 = load i64, ptr %l42, !tbaa !24
  %t104 = getelementptr %"compiler/diag:record", ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e9d163bbb40732e1_d05f2d0aec414c45)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3arecord_3e_2e_Hc8eaf7b915c8e02d33e2dda610abe743(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %r = tail call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
  ret { i64, ptr } %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2ector(ptr %v0) #0 {
entry:
  %l1 = alloca %"std/prelude/list:listState.9783095779ea18337775adeb6569839d"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aItem_3e_2ector(ptr %v0)
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %l1
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 88, i64 8)
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t2, ptr %t3
  %t6 = insertvalue %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t3, 0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0) #0 {
entry:
  %l1 = alloca %"std/prelude/list:listState.9783095779ea18337775adeb6569839d"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0)
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %l1
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 88, i64 8)
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t2, ptr %t3
  %t6 = insertvalue %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t3, 0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2ector = dso_local alias %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" (ptr), ptr @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ector
define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0) #0 {
entry:
  %l1 = alloca %"std/prelude/list:listState.9783095779ea18337775adeb6569839d"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0)
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %l1
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 88, i64 8)
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t2, ptr %t3
  %t6 = insertvalue %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t3, 0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cBool_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aItem_3e_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %rv = alloca %"std/prelude/list:listState.9783095779ea18337775adeb6569839d"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = icmp sle i64 0, 576460752303423487
  br i1 %t3, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_57707f9461e221c1_89e939dc8f7e8415)
  unreachable
bb3:
  %t5 = mul i64 0, 16
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  %t10 = icmp sge i64 0, 0
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_57707f9461e221c1_89e939dc8f7e8415)
  unreachable
bb5:
  %t12 = icmp sle i64 0, 128102389400760775
  br i1 %t12, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_c17ed9ce039863b4_7e1e06d669927828)
  unreachable
bb7:
  %t14 = mul i64 0, 72
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 0, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c17ed9ce039863b4_7e1e06d669927828)
  unreachable
bb9:
  %t21 = icmp sle i64 0, 128102389400760775
  br i1 %t21, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_38585a76313dc557_683a26aa5bc5358b)
  unreachable
bb11:
  %t23 = mul i64 0, 72
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 0, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" undef, { i64, ptr } %t28, 0
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t29, { i64, ptr } %t30, 1
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t31, i64 %t32, 2
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t33, i64 %t34, 3
  %t37 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t35, { i64, ptr } %t26, 4
  %t39 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t37, i64 0, 5
  %t41 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t39, i64 0, 6
  %t43 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t41, i64 0, 7
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t43, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_38585a76313dc557_683a26aa5bc5358b)
  unreachable
ret:
  %rr = load %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %rv
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %rr
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %rv = alloca %"std/prelude/list:listState.9783095779ea18337775adeb6569839d"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = icmp sle i64 0, 576460752303423487
  br i1 %t3, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_148762ed49397fcf_32955e31d7c39c33)
  unreachable
bb3:
  %t5 = mul i64 0, 16
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  %t10 = icmp sge i64 0, 0
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_148762ed49397fcf_32955e31d7c39c33)
  unreachable
bb5:
  %t12 = icmp sle i64 0, 192153584101141162
  br i1 %t12, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6a8d6de301dfa87a_d17d7811ef8546fe)
  unreachable
bb7:
  %t14 = mul i64 0, 48
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 0, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_6a8d6de301dfa87a_d17d7811ef8546fe)
  unreachable
bb9:
  %t21 = icmp sle i64 0, 192153584101141162
  br i1 %t21, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_259d5ba26124f7f9_780d00d9d3492c3d)
  unreachable
bb11:
  %t23 = mul i64 0, 48
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 0, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" undef, { i64, ptr } %t28, 0
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t29, { i64, ptr } %t30, 1
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t31, i64 %t32, 2
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t33, i64 %t34, 3
  %t37 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t35, { i64, ptr } %t26, 4
  %t39 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t37, i64 0, 5
  %t41 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t39, i64 0, 6
  %t43 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t41, i64 0, 7
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t43, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_259d5ba26124f7f9_780d00d9d3492c3d)
  unreachable
ret:
  %rr = load %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %rv
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %rr
}

@std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3acontext_3e_2ector = dso_local alias %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" (ptr), ptr @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3aSaid_3e_2ector
define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3anote_3e_2ector(ptr %v0) #0 {
entry:
  %r = tail call %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %r
}

define dso_local %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %rv = alloca %"std/prelude/list:listState.9783095779ea18337775adeb6569839d"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = icmp sle i64 0, 576460752303423487
  br i1 %t3, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_628b180b10d9712f_d7c4665ccaff9d93)
  unreachable
bb3:
  %t5 = mul i64 0, 16
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  %t10 = icmp sge i64 0, 0
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_628b180b10d9712f_d7c4665ccaff9d93)
  unreachable
bb5:
  %t12 = icmp sle i64 0, 104811045873349725
  br i1 %t12, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_4721b5baeef3595a_513266fefbb0c85e)
  unreachable
bb7:
  %t14 = mul i64 0, 88
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 0, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t19 = icmp sge i64 0, 0
  br i1 %t19, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4721b5baeef3595a_513266fefbb0c85e)
  unreachable
bb9:
  %t21 = icmp sle i64 0, 104811045873349725
  br i1 %t21, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_594d296c47175ed9_e81fd6701dabdd9d)
  unreachable
bb11:
  %t23 = mul i64 0, 88
  %t24 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 0, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" undef, { i64, ptr } %t28, 0
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t29, { i64, ptr } %t30, 1
  %t32 = load i64, ptr %l2, !tbaa !24
  %t33 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t31, i64 %t32, 2
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t33, i64 %t34, 3
  %t37 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t35, { i64, ptr } %t26, 4
  %t39 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t37, i64 0, 5
  %t41 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t39, i64 0, 6
  %t43 = insertvalue %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t41, i64 0, 7
  store %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %t43, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_594d296c47175ed9_e81fd6701dabdd9d)
  unreachable
ret:
  %rr = load %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %rv
  ret %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" %rr
}

declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2estd_2fprelude_2flist_2efirstChunk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2flist_2ehighBit(i64 %a0)
@G_2estd_2fprelude_2flist_2efirstChunkLog = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eCl_He62a1125a32dfc5a59291318c690abf4(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_67bd7411a85bddd6_397ca10f5085a562 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
@olang_loc_4276aa0d6ff50940_61ad4d4404298084 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5079283e2d8c0a18_20afd8541d03fe8c = external constant [0 x i8]
@olang_loc_4d334469e801b5bb_528e26417185845f = external constant [0 x i8]
@olang_loc_4fe1a86f19e49226_efb78e903136768a = external constant [0 x i8]
@olang_loc_fe2211e759cb4c45_752cc5452836f349 = external constant [0 x i8]
@olang_loc_8b6b1bdbb1597ad8_6e13662896aee6fc = external constant [0 x i8]
@olang_loc_c825086be23f399d_4f9a04d0dc8995d1 = external constant [0 x i8]
@olang_loc_8b5965bdfdd8e6f0_92795128512067c4 = external constant [0 x i8]
@olang_loc_b7c998588f92f993_3a96d949c06544a7 = external constant [0 x i8]
@olang_loc_313798fac044245e_494ea0b5c4e628b2 = external constant [0 x i8]
@olang_loc_26b0dd57c84bdd1_9bb6b561f398bf95 = external constant [0 x i8]
@olang_loc_454a5a2cf11b8fc4_8feb825bcdacb3a8 = external constant [0 x i8]
@olang_loc_ed67e24e60606ca7_7a07a22fbfdf710b = external constant [0 x i8]
@olang_loc_fc1fa9ba64e150b2_6234d56134b2d676 = external constant [0 x i8]
@olang_loc_11ef750acf242625_17cbbe56136a7549 = external constant [0 x i8]
@olang_loc_fd690b86fe282bb8_10b25f3981e268fc = external constant [0 x i8]
@olang_loc_dab00dff291fcd9b_f52d1f525cb9065f = external constant [0 x i8]
@olang_loc_8e80142f12a10406_925687a11c69f88a = external constant [0 x i8]
@olang_loc_27857e08243125f7_f51b68382dadfe8b = external constant [0 x i8]
@olang_loc_479fd5b990642e42_dd489b69a28163f6 = external constant [0 x i8]
@olang_loc_9f87ecf65d9dc361_16ca7b6a61674d15 = external constant [0 x i8]
@olang_loc_ba26f8d95088b54_aff48643b7b4128 = external constant [0 x i8]
@olang_loc_579ac17f97fbdc0e_f38472f074dc1752 = external constant [0 x i8]
@olang_loc_e30b01b101f6280b_74200f6bb26f874f = external constant [0 x i8]
@olang_loc_1b3bad14a137350a_15de62cc2adde936 = external constant [0 x i8]
@olang_loc_7e1244c5e18642df_d9394ba5955009cb = external constant [0 x i8]
@olang_loc_999784ad06afa57c_75fdf29414147e68 = external constant [0 x i8]
@olang_loc_a0b0e3c99837b1c9_d89b02a654bf2e55 = external constant [0 x i8]
@olang_loc_3b15a85c7b2e94f4_25b0f2d66071e068 = external constant [0 x i8]
@olang_loc_e9d163bbb40732e1_d05f2d0aec414c45 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0)
@olang_loc_57707f9461e221c1_89e939dc8f7e8415 = external constant [0 x i8]
@olang_loc_c17ed9ce039863b4_7e1e06d669927828 = external constant [0 x i8]
@olang_loc_38585a76313dc557_683a26aa5bc5358b = external constant [0 x i8]
@olang_loc_148762ed49397fcf_32955e31d7c39c33 = external constant [0 x i8]
@olang_loc_6a8d6de301dfa87a_d17d7811ef8546fe = external constant [0 x i8]
@olang_loc_259d5ba26124f7f9_780d00d9d3492c3d = external constant [0 x i8]
declare %"std/prelude/list:listState.9783095779ea18337775adeb6569839d" @std_2fprelude_2flist_3alistState_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
@olang_loc_628b180b10d9712f_d7c4665ccaff9d93 = external constant [0 x i8]
@olang_loc_4721b5baeef3595a_513266fefbb0c85e = external constant [0 x i8]
@olang_loc_594d296c47175ed9_e81fd6701dabdd9d = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
