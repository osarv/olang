; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:holdWalk" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:LastUses" = type { i64, { i64, ptr }, { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i32, i1, i1 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:DerivedArg" = type { i64, i64, { i64, [2 x i64] } }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:SiteInfo" = type { i32, %"compiler/source:Span" }
%"compiler/typed:Landings" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/typed:landLoop" = type { i32, i64, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:wordReader" = type { { i64, ptr }, { ptr, ptr }, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Nodes" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Versions" = type { ptr, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/typed:ViewWalk" = type { ptr, ptr, i64, { ptr, ptr }, { ptr, ptr } }
%"compiler/typed:dropWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:leaveWalk" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:landState" = type { { i64, ptr }, i1 }
@G_2ecompiler_2ftyped_2eElsewhere = constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftyped_2eHanded = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftyped_2eMutGlobalsFact = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\13\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2eMutGlobalsFact.k1 }>, align 8
@G_2ecompiler_2ftyped_2eMutGlobalsFact.k1 = internal global <{ [19 x i8] }> <{ [19 x i8] c"\44\39\68\20\6D\75\74\61\62\6C\65\20\67\6C\6F\62\61\6C\73" }>, align 8
@G_2ecompiler_2ftyped_2eViewBits = constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftyped_2eViewOther = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
@G_2ecompiler_2ftyped_2emathArity = constant <{ [248 x i8] }> <{ [248 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ftyped_2emathNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k1, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k2, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k3, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k4, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k5, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k6, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k8, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k9, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k11, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k12, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k13, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k14, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k15, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k16, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k17, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k18, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k19, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k20, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k21, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k22, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k23, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k24, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k25, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k26, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k27, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k28, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k29, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k30, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k31 }>, align 64
@G_2ecompiler_2ftyped_2emathNames.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\73\71\72\74" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k2 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\6D\61" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k3 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\6C\6F\6F\72" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\65\69\6C" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k5 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\74\72\75\6E\63" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k6 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\72\6F\75\6E\64" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k7 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\72\6F\75\6E\64\65\76\65\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\66\61\62\73" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k9 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6F\70\79\73\69\67\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k10 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\62\72\74" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\65\78\70" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k12 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\78\70\32" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k13 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\65\78\70\6D\31" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k14 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6C\6F\67" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k15 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6C\6F\67\32" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k16 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\31\30" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k17 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\31\70" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k18 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\70\6F\77" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k19 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\73\69\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k20 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\63\6F\73" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k21 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\74\61\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k22 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\73\69\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k23 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\63\6F\73" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k24 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\74\61\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k25 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\61\74\61\6E\32" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k26 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\73\69\6E\68" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k27 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\6F\73\68" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k28 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\61\6E\68" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k29 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\65\72\66" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k30 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\72\66\63" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k31 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\68\79\70\6F\74" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k1, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k2, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k3, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k4, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k5, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k6, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k7, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k8, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k9, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k10, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k11, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k12, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k13, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k14, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k15, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k16, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k17, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k18, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k19, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k20, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k21, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k22, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k23, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k24, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k25, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k26, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k27, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k28, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k29, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k30, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k31, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k32, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k33, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k34, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k35, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k36, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k37, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k38, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k39, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k40, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k41, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k42, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k43, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k44, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k45, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k46, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k47, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k48, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k49, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k50, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k51, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k52, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k53, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k54, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k55, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k56, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k57, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k58, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k59, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k60, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k61, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k62, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k63, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k64, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k65, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k66, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k67, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k68, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k69, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k70, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k71, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k72, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k73, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k74, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k75, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k76, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k77, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k78, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k79, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k80, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k81, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k82, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k83, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k84, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k85, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k86, [8 x i8] c"\0C\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k87, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k88, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k89, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k90, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k91, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k92, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k93, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k94, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2enoCallbackNames.k95 }>, align 64
@G_2ecompiler_2ftyped_2enoCallbackNames.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\72\65\61\64" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k2 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\77\72\69\74\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k3 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\70\72\65\61\64" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k4 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\70\77\72\69\74\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k5 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\72\65\61\64\76" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k6 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\77\72\69\74\65\76" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k7 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6F\70\65\6E" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k8 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6F\70\65\6E\61\74" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k9 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\63\72\65\61\74" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k10 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\63\6C\6F\73\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k11 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\73\65\65\6B" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k12 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\73\79\6E\63" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k13 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\66\64\61\74\61\73\79\6E\63" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k14 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\66\74\72\75\6E\63\61\74\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k15 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\73\74\61\74" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k16 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\73\74\61\74" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k17 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\73\74\61\74" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k18 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\66\73\74\61\74\61\74" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k19 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\61\63\63\65\73\73" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k20 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\75\6E\6C\69\6E\6B" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k21 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\72\65\6E\61\6D\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k22 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6D\6B\64\69\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k23 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\72\6D\64\69\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k24 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\6F\70\65\6E\64\69\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k25 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\72\65\61\64\64\69\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k26 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6C\6F\73\65\64\69\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k27 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\67\65\74\63\77\64" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k28 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\63\68\64\69\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k29 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\64\75\70" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k30 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\64\75\70\32" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k31 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\70\69\70\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k32 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\70\6F\6C\6C" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k33 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\69\73\61\74\74\79" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k34 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\6F\70\65\6E" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k35 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\66\63\6C\6F\73\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k36 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\72\65\61\64" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k37 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\66\77\72\69\74\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k38 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\66\66\6C\75\73\68" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k39 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\70\75\74\73" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k40 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\67\65\74\73" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k41 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\70\75\74\73" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k42 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\70\75\74\63\68\61\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k43 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\67\65\74\63\68\61\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k44 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\70\72\69\6E\74\66" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k45 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\66\70\72\69\6E\74\66" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k46 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\73\6E\70\72\69\6E\74\66" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k47 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\70\72\69\6E\74\66" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k48 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\70\65\72\72\6F\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k49 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\6C\65\6E" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k50 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\74\72\6E\6C\65\6E" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k51 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\63\6D\70" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k52 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\74\72\6E\63\6D\70" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k53 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\63\70\79" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k54 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\74\72\6E\63\70\79" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k55 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\63\61\74" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k56 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\74\72\6E\63\61\74" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k57 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\63\68\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k58 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\74\72\72\63\68\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k59 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\73\74\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k60 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\64\75\70" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k61 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\74\72\6E\64\75\70" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k62 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\74\6F\6C" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k63 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\74\72\74\6F\6C\6C" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k64 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\73\74\72\74\6F\75\6C" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k65 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\73\74\72\74\6F\75\6C\6C" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k66 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\74\6F\64" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k67 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\74\6F\66" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k68 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\73\74\72\65\72\72\6F\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k69 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6D\65\6D\63\70\79" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k70 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\6D\65\6D\6D\6F\76\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k71 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6D\65\6D\73\65\74" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k72 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6D\65\6D\63\6D\70" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k73 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6D\65\6D\63\68\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k74 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6D\61\6C\6C\6F\63" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k75 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\63\61\6C\6C\6F\63" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k76 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\72\65\61\6C\6C\6F\63" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k77 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\66\72\65\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k78 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\61\6C\69\67\6E\65\64\5F\61\6C\6C\6F\63" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k79 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\70\6F\73\69\78\5F\6D\65\6D\61\6C\69\67\6E" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k80 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6D\6D\61\70" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k81 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6D\75\6E\6D\61\70" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k82 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\6D\70\72\6F\74\65\63\74" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k83 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\6D\61\64\76\69\73\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k84 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\69\6D\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k85 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\63\6C\6F\63\6B\5F\67\65\74\74\69\6D\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k86 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\63\6C\6F\63\6B\5F\67\65\74\72\65\73" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k87 = internal constant <{ [12 x i8] }> <{ [12 x i8] c"\67\65\74\74\69\6D\65\6F\66\64\61\79" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k88 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\6E\61\6E\6F\73\6C\65\65\70" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k89 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\75\73\6C\65\65\70" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k90 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\73\6C\65\65\70" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k91 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\6C\6F\63\61\6C\74\69\6D\65\5F\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k92 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\67\6D\74\69\6D\65\5F\72" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k93 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\6D\6B\74\69\6D\65" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k94 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\74\69\6D\65\67\6D" }>, align 8
@G_2ecompiler_2ftyped_2enoCallbackNames.k95 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\73\74\72\66\74\69\6D\65" }>, align 8
define dso_local i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l85 = alloca { i64, ptr }
  %l92 = alloca i1
  %l97 = alloca i1
  %l105 = alloca i1
  %l114 = alloca i1
  %l115 = alloca ptr
  %l123 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l138 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l155 = alloca i1
  %l165 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i1
  %l175 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i1
  %l185 = alloca i1
  %l186 = alloca ptr
  %l187 = alloca i1
  %l195 = alloca i1
  %l196 = alloca i1
  %l200 = alloca i1
  %l202 = alloca { i64, ptr }
  %l205 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t7 = load ptr, ptr %l25, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l25, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 7
  store i1 %t13, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l26, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb20
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t16 = load ptr, ptr %l29, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l29, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 5
  store i1 %t22, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l30, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t25 = load ptr, ptr %l33, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l33, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 8
  store i1 %t31, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l34, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb20
bb15:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t34 = load ptr, ptr %l37, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb16, label %bb17
bb16:
  %t37 = load ptr, ptr %l37, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 16
  store i1 %t40, ptr %l38, !tbaa !21
  br label %bb17
bb17:
  %t41 = load i1, ptr %l38, !tbaa !21
  br i1 %t41, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t44 = load ptr, ptr %l42, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb22, label %bb23
bb22:
  %t47 = load ptr, ptr %l42, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 6
  store i1 %t50, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t51 = load i1, ptr %l43, !tbaa !21
  br i1 %t51, label %bb24, label %bb25
bb24:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l2, !tbaa !23
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l50
  br label %bb27
bb27:
  %t63 = load i1, ptr %l50, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
bb28:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t65 = load ptr, ptr %l51, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb29, label %bb30
bb29:
  %t68 = load ptr, ptr %l51, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 11
  store i1 %t71, ptr %l52, !tbaa !21
  br label %bb30
bb30:
  %t72 = load i1, ptr %l52, !tbaa !21
  br i1 %t72, label %bb31, label %bb32
bb31:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Cond", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t79, ptr %t83)
  store i1 %t86, ptr %l60
  br label %bb34
bb34:
  %t87 = load i1, ptr %l60, !tbaa !21
  br i1 %t87, label %bb35, label %bb36
bb35:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Cond", ptr %t89, i32 0, i32 2
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t96 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t88, ptr %t92)
  store i1 %t96, ptr %l66
  br label %bb37
bb36:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb38
bb37:
  %t97 = load i1, ptr %l66, !tbaa !21
  store i1 %t97, ptr %l61, !tbaa !21
  br label %bb38
bb38:
  %t98 = load i1, ptr %l61, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
bb39:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t100 = load ptr, ptr %l67, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb40, label %bb41
bb40:
  %t103 = load ptr, ptr %l67, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 18}
  %t106 = icmp eq i64 %t104, 13
  store i1 %t106, ptr %l68, !tbaa !21
  br label %bb41
bb41:
  %t107 = load i1, ptr %l68, !tbaa !21
  br i1 %t107, label %bb42, label %bb43
bb42:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l4, !tbaa !29
  br label %bb44
bb43:
  br label %bb74
bb44:
  %t114 = load ptr, ptr %l4, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Match", ptr %t114, i32 0, i32 3
  %t117 = load i1, ptr %t116, !tbaa !21
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb45, label %bb46
bb45:
  store i1 false, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Match", ptr %t122, i32 0, i32 1
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  store i64 %t129, ptr %l7, !tbaa !24
  br label %bb48
bb48:
  %t131 = load i64, ptr %l6, !tbaa !24
  %t132 = load i64, ptr %l7, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb49, label %bb50
bb49:
  br label %bb60
bb50:
  br label %bb51
bb51:
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t139, ptr %l85, !tbaa !27
  %t140 = load i64, ptr %l6, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr ptr, ptr %t143, i64 %t140
  %t145 = load ptr, ptr %t144, !tbaa !39
  store ptr %t145, ptr %l8, !tbaa !29
  %t147 = load ptr, ptr %l8, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Arm", ptr %t147, i32 0, i32 4
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb52, label %bb53
bb52:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l8, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Arm", ptr %t157, i32 0, i32 4
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t164 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t156, ptr %t160)
  store i1 %t164, ptr %l97
  br label %bb54
bb53:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb55
bb54:
  %t165 = load i1, ptr %l97, !tbaa !21
  %t166 = xor i1 %t165, true
  store i1 %t166, ptr %l92, !tbaa !21
  br label %bb55
bb55:
  %t168 = load i1, ptr %l92, !tbaa !21
  br i1 %t168, label %bb56, label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t170 = load i64, ptr %l6, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l6, !tbaa !24
  br label %bb48
bb60:
  %t174 = load ptr, ptr %l4, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Match", ptr %t174, i32 0, i32 2
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = icmp eq ptr %t177, null
  br i1 %t179, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb66
bb62:
  %t181 = load ptr, ptr %l4, !tbaa !29
  %t183 = getelementptr %"compiler/typed:Match", ptr %t181, i32 0, i32 2
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t186 = icmp eq ptr %t184, null
  br i1 %t186, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_9640b30413567955_c65a1e6fb20cf981)
  unreachable
bb64:
  br label %bb65
bb65:
  %t188 = load ptr, ptr %l4, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Match", ptr %t188, i32 0, i32 2
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t194 = getelementptr %"compiler/typed:Arm", ptr %t191, i32 0, i32 4
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = icmp eq ptr %t195, null
  store i1 %t197, ptr %l105, !tbaa !21
  br label %bb66
bb66:
  %t199 = load i1, ptr %l105, !tbaa !21
  br i1 %t199, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb73
bb68:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l115, !tbaa !29
  %t201 = load ptr, ptr %l4, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Match", ptr %t201, i32 0, i32 2
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = icmp eq ptr %t204, null
  br i1 %t206, label %bb69, label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_9640b30413567955_c65a1e6fb20cf981)
  unreachable
bb70:
  br label %bb71
bb71:
  %t208 = load ptr, ptr %l4, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Match", ptr %t208, i32 0, i32 2
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t214 = getelementptr %"compiler/typed:Arm", ptr %t211, i32 0, i32 4
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t216 = load ptr, ptr %l115, !tbaa !29
  %t218 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t216, ptr %t215)
  store i1 %t218, ptr %l123
  br label %bb72
bb72:
  %t219 = load i1, ptr %l123, !tbaa !21
  store i1 %t219, ptr %l114, !tbaa !21
  br label %bb73
bb73:
  %t220 = load i1, ptr %l114, !tbaa !21
  store i1 %t220, ptr %rv
  br label %ret
bb74:
  %t221 = load ptr, ptr %l1, !tbaa !29
  store ptr %t221, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t222 = load ptr, ptr %l124, !tbaa !29
  %t223 = icmp ne ptr %t222, null
  br i1 %t223, label %bb75, label %bb76
bb75:
  %t225 = load ptr, ptr %l124, !tbaa !29
  %t226 = load i64, ptr %t225, !range !{i64 0, i64 18}
  %t228 = icmp eq i64 %t226, 14
  store i1 %t228, ptr %l125, !tbaa !21
  br label %bb76
bb76:
  %t229 = load i1, ptr %l125, !tbaa !21
  br i1 %t229, label %bb77, label %bb78
bb77:
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr { i64, [5 x i64] }, ptr %t230, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t232, i32 0, i32 2
  %t234 = load ptr, ptr %t233
  store ptr %t234, ptr %l9, !tbaa !29
  br label %bb79
bb78:
  br label %bb97
bb79:
  %t236 = load ptr, ptr %l9, !tbaa !29
  %t238 = getelementptr %"compiler/typed:Try", ptr %t236, i32 0, i32 1
  %t239 = load { i64, ptr }, ptr %t238, !tbaa !27
  store { i64, ptr } %t239, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t241 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  store i64 %t243, ptr %l12, !tbaa !24
  br label %bb80
bb80:
  %t245 = load i64, ptr %l11, !tbaa !24
  %t246 = load i64, ptr %l12, !tbaa !24
  %t249 = icmp slt i64 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb81, label %bb82
bb81:
  br label %bb95
bb82:
  br label %bb83
bb83:
  %t253 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t253, ptr %l138, !tbaa !27
  %t254 = load i64, ptr %l11, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr ptr, ptr %t257, i64 %t254
  %t259 = load ptr, ptr %t258, !tbaa !39
  %t263 = getelementptr %"compiler/typed:Clause", ptr %t259, i32 0, i32 4
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  store { i64, ptr } %t264, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t266, 0
  store i64 %t268, ptr %l16, !tbaa !24
  br label %bb84
bb84:
  %t270 = load i64, ptr %l15, !tbaa !24
  %t271 = load i64, ptr %l16, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb85, label %bb86
bb85:
  br label %bb93
bb86:
  br label %bb87
bb87:
  %t278 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t278, ptr %l149, !tbaa !27
  %t279 = load i64, ptr %l15, !tbaa !24
  %t281 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr ptr, ptr %t282, i64 %t279
  %t284 = load ptr, ptr %t283, !tbaa !39
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t291 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t286, ptr %t284)
  store i1 %t291, ptr %l155
  br label %bb88
bb88:
  %t292 = load i1, ptr %l155, !tbaa !21
  %t293 = xor i1 %t292, true
  br i1 %t293, label %bb89, label %bb90
bb89:
  store i1 false, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t296 = load i64, ptr %l15, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l15, !tbaa !24
  br label %bb84
bb93:
  br label %bb94
bb94:
  %t300 = load i64, ptr %l11, !tbaa !24
  %t302 = add i64 %t300, 1
  store i64 %t302, ptr %l11, !tbaa !24
  br label %bb80
bb95:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load ptr, ptr %l9, !tbaa !29
  %t307 = getelementptr %"compiler/typed:Try", ptr %t305, i32 0, i32 0
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t311 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t304, ptr %t308)
  store i1 %t311, ptr %l165
  br label %bb96
bb96:
  %t312 = load i1, ptr %l165, !tbaa !21
  store i1 %t312, ptr %rv
  br label %ret
bb97:
  %t313 = load ptr, ptr %l1, !tbaa !29
  store ptr %t313, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t314 = load ptr, ptr %l166, !tbaa !29
  %t315 = icmp ne ptr %t314, null
  br i1 %t315, label %bb98, label %bb99
bb98:
  %t317 = load ptr, ptr %l166, !tbaa !29
  %t318 = load i64, ptr %t317, !range !{i64 0, i64 18}
  %t320 = icmp eq i64 %t318, 12
  store i1 %t320, ptr %l167, !tbaa !21
  br label %bb99
bb99:
  %t321 = load i1, ptr %l167, !tbaa !21
  br i1 %t321, label %bb100, label %bb101
bb100:
  %t322 = load ptr, ptr %l1, !tbaa !29
  %t324 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 1
  %t325 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t324, i32 0, i32 2
  %t326 = load ptr, ptr %t325
  store ptr %t326, ptr %l18, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load ptr, ptr %l18, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Seq", ptr %t329, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !29
  %t335 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t328, ptr %t332)
  store i1 %t335, ptr %l175
  br label %bb103
bb103:
  %t336 = load i1, ptr %l175, !tbaa !21
  store i1 %t336, ptr %rv
  br label %ret
bb104:
  %t337 = load ptr, ptr %l1, !tbaa !29
  store ptr %t337, ptr %l176, !tbaa !29
  store i1 false, ptr %l177, !tbaa !21
  %t338 = load ptr, ptr %l176, !tbaa !29
  %t339 = icmp ne ptr %t338, null
  br i1 %t339, label %bb105, label %bb106
bb105:
  %t341 = load ptr, ptr %l176, !tbaa !29
  %t342 = load i64, ptr %t341, !range !{i64 0, i64 18}
  %t344 = icmp eq i64 %t342, 17
  store i1 %t344, ptr %l177, !tbaa !21
  br label %bb106
bb106:
  %t345 = load i1, ptr %l177, !tbaa !21
  br i1 %t345, label %bb107, label %bb108
bb107:
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t348 = getelementptr { i64, [5 x i64] }, ptr %t346, i32 0, i32 1
  %t349 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t348, i32 0, i32 2
  %t350 = load ptr, ptr %t349
  store ptr %t350, ptr %l19, !tbaa !29
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l19, !tbaa !29
  %t357 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t352, ptr %t353)
  store i1 %t357, ptr %l185
  br label %bb110
bb110:
  %t358 = load i1, ptr %l185, !tbaa !21
  store i1 %t358, ptr %rv
  br label %ret
bb111:
  %t359 = load ptr, ptr %l1, !tbaa !29
  store ptr %t359, ptr %l186, !tbaa !29
  store i1 false, ptr %l187, !tbaa !21
  %t360 = load ptr, ptr %l186, !tbaa !29
  %t361 = icmp ne ptr %t360, null
  br i1 %t361, label %bb112, label %bb113
bb112:
  %t363 = load ptr, ptr %l186, !tbaa !29
  %t364 = load i64, ptr %t363, !range !{i64 0, i64 18}
  %t366 = icmp eq i64 %t364, 9
  store i1 %t366, ptr %l187, !tbaa !21
  br label %bb113
bb113:
  %t367 = load i1, ptr %l187, !tbaa !21
  br i1 %t367, label %bb114, label %bb115
bb114:
  %t368 = load ptr, ptr %l1, !tbaa !29
  %t370 = getelementptr { i64, [5 x i64] }, ptr %t368, i32 0, i32 1
  %t371 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t370, i32 0, i32 2
  %t372 = load i32, ptr %t371, !range !{i32 0, i32 52}
  store i32 %t372, ptr %l20
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t376 = getelementptr { i64, [5 x i64] }, ptr %t374, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t376, i32 0, i32 4
  %t378 = load { i64, ptr }, ptr %t377
  store { i64, ptr } %t378, ptr %l21, !tbaa !27
  br label %bb116
bb115:
  br label %bb125
bb116:
  %t380 = load i32, ptr %l20, !range !{i32 0, i32 52}
  %t382 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t380)
  store i1 %t382, ptr %l195
  br label %bb117
bb117:
  %t383 = load i1, ptr %l195, !tbaa !21
  br i1 %t383, label %bb118, label %bb119
bb118:
  %t384 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t384, 0
  %t388 = icmp sgt i64 %t386, 0
  store i1 %t388, ptr %l196, !tbaa !21
  br label %bb120
bb119:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb120
bb120:
  %t390 = load i1, ptr %l196, !tbaa !21
  br i1 %t390, label %bb121, label %bb122
bb121:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t392, ptr %l202, !tbaa !27
  %t393 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !27
  %t395 = getelementptr ptr, ptr %t394, i64 0
  %t396 = load ptr, ptr %t395, !tbaa !39
  %t400 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t391, ptr %t396)
  store i1 %t400, ptr %l205
  br label %bb123
bb122:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb124
bb123:
  %t401 = load i1, ptr %l205, !tbaa !21
  store i1 %t401, ptr %l200, !tbaa !21
  br label %bb124
bb124:
  %t402 = load i1, ptr %l200, !tbaa !21
  store i1 %t402, ptr %rv
  br label %ret
bb125:
  br i1 true, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  store i1 false, ptr %rv
  br label %ret
bb129:
  call void @__olang_check_failed(ptr @olang_loc_c8cee6ec101913bd_743c2b1d0ab2dad9)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2eCalledBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l12, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { i32 }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t36 = load i32, ptr %l3, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_831440fdfc819328_dabfa81c01cf773c)
  unreachable
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 -1, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_7bdf3cb2fb8351f9_389183759a182ed)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2ftyped_2eCopiedOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l4 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2ftyped_2ecopied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
  store ptr %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ftyped_2eDropHolding_2eJudged(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l4 = alloca %"compiler/typed:DropHolding"
  %t3 = alloca %"compiler/typed:DropHolding", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ftyped_2eDropHolding_2eholding(ptr %t3, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 true)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t3, i64 224, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l4, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2eDropHolding_2eholding(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/typed:holdWalk"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"compiler/typed:DropHolding"
  %l38 = alloca %"compiler/typed:DropHolding"
  %l39 = alloca ptr
  %l48 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca %"compiler/typed:DropHolding"
  %l68 = alloca %"compiler/typed:holdWalk"
  %l70 = alloca i64
  %l72 = alloca i64
  %l77 = alloca i64
  %l83 = alloca i64
  %l85 = alloca i64
  %l90 = alloca i32
  %l97 = alloca i64
  %l101 = alloca i64
  %l104 = alloca i64
  %l122 = alloca ptr
  %l123 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l139 = alloca i64
  %l143 = alloca i64
  %l146 = alloca i64
  %l164 = alloca ptr
  %l167 = alloca i64
  %l168 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l170 = alloca { i64, ptr }
  %l171 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l172 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l174 = alloca i64
  %l178 = alloca i64
  %l181 = alloca i64
  %l202 = alloca i1
  %l205 = alloca i32
  %l208 = alloca i32
  %l210 = alloca i1
  %l211 = alloca ptr
  %l214 = alloca i64
  %l215 = alloca i1
  %l216 = alloca ptr
  %l219 = alloca i64
  %l226 = alloca %"compiler/typed:DropHolding"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %t1 = alloca %"compiler/typed:DropHolding", align 8
  %t71 = alloca %"compiler/typed:holdWalk", align 8
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2ftyped_3aDropHolding_2ector(ptr %t1, ptr %v2)
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %t1, i64 224, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 224, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l34, i64 224, i1 false)
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 11
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t11, i64 224, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l38, i64 224, i1 false)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l39, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 11
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_1d48dcdc24016ab9_795d1a331a4bc775)
  unreachable
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 11
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load ptr, ptr %lp3
  %t25 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v1, ptr %v1, ptr %v2, ptr %t25, ptr %t23, ptr %t24)
  br label %bb8
bb8:
  %t28 = load i1, ptr %l2, !tbaa !21
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %lp3
  %t33 = getelementptr %"compiler/typed:DropHolding", ptr %t32, i32 0, i32 1
  %t35 = call i1 @compiler_2ftyped_2esharedBlock(ptr %v2, ptr %t33)
  store i1 %t35, ptr %l50
  br label %bb11
bb10:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb12
bb11:
  %t36 = load i1, ptr %l50, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l48, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l48, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %lp3
  %t41 = getelementptr %"compiler/typed:DropHolding", ptr %t40, i32 0, i32 0
  store ptr %t41, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb15
bb14:
  br label %bb25
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t43 = load i64, ptr %l5, !tbaa !24
  store i64 %t43, ptr %l53, !tbaa !24
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t44)
  store i64 %t46, ptr %l55
  br label %bb16
bb16:
  %t47 = load i64, ptr %l53, !tbaa !24
  %t48 = load i64, ptr %l55, !tbaa !24
  %t49 = icmp slt i64 %t47, %t48
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb18:
  br label %bb19
bb19:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t53, i64 %t54)
  store i64 %t57, ptr %l60
  br label %bb20
bb20:
  %t58 = load i64, ptr %l60, !tbaa !24
  store i64 %t58, ptr %l6, !tbaa !24
  %t59 = load ptr, ptr %lp3
  %t60 = getelementptr %"compiler/typed:DropHolding", ptr %t59, i32 0, i32 2
  store ptr %t60, ptr %l61, !tbaa !29
  %t61 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %l62
  br label %bb21
bb21:
  %t62 = load ptr, ptr %l61, !tbaa !29
  %t63 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v2, ptr %s4, ptr %t62, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l5, !tbaa !24
  br label %bb15
bb24:
  %t68 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t68, i64 224, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l65, i64 224, i1 false)
  br label %ret
bb25:
  %t70 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_3aholdWalk_2ector(ptr %t71, ptr %v0, ptr %v1, ptr %s0, ptr %a0, ptr %t70)
  call void @llvm.memmove.p0.p0.i64(ptr %l68, ptr %t71, i64 472, i1 false)
  br label %bb26
bb26:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l68, i64 472, i1 false)
  %t74 = load ptr, ptr %lp3
  %t75 = getelementptr %"compiler/typed:DropHolding", ptr %t74, i32 0, i32 0
  store ptr %t75, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb27:
  %t77 = load i64, ptr %l9, !tbaa !24
  store i64 %t77, ptr %l70, !tbaa !24
  %t78 = load ptr, ptr %l8, !tbaa !29
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t78)
  store i64 %t80, ptr %l72
  br label %bb28
bb28:
  %t81 = load i64, ptr %l70, !tbaa !24
  %t82 = load i64, ptr %l72, !tbaa !24
  %t83 = icmp slt i64 %t81, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb29, label %bb30
bb29:
  br label %bb35
bb30:
  br label %bb31
bb31:
  %t87 = load ptr, ptr %l8, !tbaa !29
  %t88 = load i64, ptr %l9, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l77
  br label %bb32
bb32:
  %t92 = load i64, ptr %l77, !tbaa !24
  %t93 = getelementptr %"compiler/typed:holdWalk", ptr %l7, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t93, i64 %t92)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l9, !tbaa !24
  br label %bb27
bb35:
  %t101 = load ptr, ptr %lp3
  %t102 = getelementptr %"compiler/typed:DropHolding", ptr %t101, i32 0, i32 1
  store ptr %t102, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb36
bb36:
  %t104 = load i64, ptr %l12, !tbaa !24
  store i64 %t104, ptr %l83, !tbaa !24
  %t105 = load ptr, ptr %l11, !tbaa !29
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v2, ptr %t105)
  store i64 %t107, ptr %l85
  br label %bb37
bb37:
  %t108 = load i64, ptr %l83, !tbaa !24
  %t109 = load i64, ptr %l85, !tbaa !24
  %t110 = icmp slt i64 %t108, %t109
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb38, label %bb39
bb38:
  br label %bb44
bb39:
  br label %bb40
bb40:
  %t114 = load ptr, ptr %l11, !tbaa !29
  %t115 = load i64, ptr %l12, !tbaa !24
  %t118 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v2, ptr %t114, i64 %t115)
  store i32 %t118, ptr %l90
  br label %bb41
bb41:
  %t119 = load i32, ptr %l90, !tbaa !23
  %t120 = getelementptr %"compiler/typed:holdWalk", ptr %l7, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %s0, ptr %t120, i32 %t119)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t124 = load i64, ptr %l12, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l12, !tbaa !24
  br label %bb36
bb44:
  store i64 0, ptr %l14, !tbaa !24
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Body", ptr %t128, i32 0, i32 7
  %t132 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t130)
  store i64 %t132, ptr %l97
  br label %bb45
bb45:
  %t133 = load i64, ptr %l97, !tbaa !24
  store i64 %t133, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t135 = load i64, ptr %l14, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb46, label %bb47
bb46:
  %t140 = load i64, ptr %l16, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb51
bb48:
  %t144 = load i64, ptr %l15, !tbaa !24
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l16, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l16, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l104, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb50
bb50:
  %t160 = load i64, ptr %l104, !tbaa !24
  store i64 %t160, ptr %l101, !tbaa !24
  br label %bb51
bb51:
  %t161 = load i64, ptr %l101, !tbaa !24
  store i64 %t161, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t162 = load i64, ptr %l18, !tbaa !24
  %t163 = load i64, ptr %l17, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s13)
  br label %bb59
bb54:
  br label %bb55
bb55:
  %t170 = load i64, ptr %l14, !tbaa !24
  %t171 = load i64, ptr %l18, !tbaa !24
  %t172 = load i64, ptr %l16, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l19, !tbaa !24
  %t180 = getelementptr %"compiler/typed:holdWalk", ptr %l7, i32 0, i32 2
  store ptr %t180, ptr %l122, !tbaa !29
  %t181 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s13, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t181, ptr %l123
  br label %bb56
bb56:
  %t182 = load ptr, ptr %l122, !tbaa !29
  %t183 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l123
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %s0, ptr %s13, ptr %t182, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t183)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s13)
  br label %bb58
bb58:
  %t184 = load i64, ptr %l18, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l18, !tbaa !24
  br label %bb52
bb59:
  br label %bb60
bb60:
  %t188 = getelementptr %"compiler/typed:holdWalk", ptr %l7, i32 0, i32 3
  store i1 false, ptr %t188, !tbaa !21
  %t189 = getelementptr %"compiler/typed:holdWalk", ptr %l7, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %t189)
  br label %bb61
bb61:
  %t191 = getelementptr %"compiler/typed:holdWalk", ptr %l7, i32 0, i32 14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H76000d29bd4678bab17d21d786d60caf(ptr %s0, ptr %t191)
  br label %bb62
bb62:
  %t193 = getelementptr %"compiler/typed:holdWalk", ptr %l7, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %s0, ptr %t193)
  br label %bb63
bb63:
  %t195 = getelementptr %"compiler/typed:holdWalk", ptr %l7, i32 0, i32 16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eClear_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t195)
  br label %bb64
bb64:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Body", ptr %t197, i32 0, i32 11
  %t200 = load ptr, ptr %t199, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %s0, ptr %v1, ptr %v0, ptr %v1, ptr %l7, ptr %t200)
  br label %bb65
bb65:
  %t203 = getelementptr %"compiler/typed:holdWalk", ptr %l7, i32 0, i32 3
  %t204 = load i1, ptr %t203, !tbaa !21
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb66, label %bb67
bb66:
  br label %bb70
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb60
bb70:
  %t208 = load i1, ptr %l2, !tbaa !21
  br i1 %t208, label %bb71, label %bb72
bb71:
  %t210 = load ptr, ptr %lp3
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefusals(ptr %s0, ptr %v2, ptr %v1, ptr %v0, ptr %l7, ptr %t210)
  br label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb74
bb74:
  store i64 0, ptr %l20, !tbaa !24
  %t213 = load ptr, ptr %lp3
  %t214 = getelementptr %"compiler/typed:DropHolding", ptr %t213, i32 0, i32 0
  %t216 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t214)
  store i64 %t216, ptr %l139
  br label %bb75
bb75:
  %t217 = load i64, ptr %l139, !tbaa !24
  store i64 %t217, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t218 = load i64, ptr %l21, !tbaa !24
  %t219 = load i64, ptr %l20, !tbaa !24
  %t222 = icmp sgt i64 %t218, %t219
  br i1 %t222, label %bb76, label %bb77
bb76:
  %t224 = load i64, ptr %l22, !tbaa !24
  %t226 = icmp sgt i64 %t224, 0
  br i1 %t226, label %bb78, label %bb79
bb77:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb81
bb78:
  %t228 = load i64, ptr %l21, !tbaa !24
  %t229 = load i64, ptr %l20, !tbaa !24
  %t232 = sub i64 %t228, %t229
  %t233 = load i64, ptr %l22, !tbaa !24
  %t236 = add i64 %t232, %t233
  %t238 = sub i64 %t236, 1
  %t239 = load i64, ptr %l22, !tbaa !24
  %t242 = sdiv i64 %t238, %t239
  store i64 %t242, ptr %l146, !tbaa !24
  br label %bb80
bb79:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb80
bb80:
  %t244 = load i64, ptr %l146, !tbaa !24
  store i64 %t244, ptr %l143, !tbaa !24
  br label %bb81
bb81:
  %t245 = load i64, ptr %l143, !tbaa !24
  store i64 %t245, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb82
bb82:
  store %olang.scope zeroinitializer, ptr %s19
  %t246 = load i64, ptr %l24, !tbaa !24
  %t247 = load i64, ptr %l23, !tbaa !24
  %t250 = icmp slt i64 %t246, %t247
  %t252 = xor i1 %t250, true
  br i1 %t252, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s19)
  br label %bb121
bb84:
  br label %bb85
bb85:
  %t254 = load i64, ptr %l20, !tbaa !24
  %t255 = load i64, ptr %l24, !tbaa !24
  %t256 = load i64, ptr %l22, !tbaa !24
  %t259 = mul i64 %t255, %t256
  %t262 = add i64 %t254, %t259
  store i64 %t262, ptr %l25, !tbaa !24
  store ptr %l7, ptr %l164, !tbaa !29
  %t264 = load ptr, ptr %lp3
  %t265 = getelementptr %"compiler/typed:DropHolding", ptr %t264, i32 0, i32 0
  %t266 = load i64, ptr %l25, !tbaa !24
  %t269 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t265, i64 %t266)
  store i64 %t269, ptr %l167
  br label %bb86
bb86:
  %t270 = load i64, ptr %l167, !tbaa !24
  %t271 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %s19, i64 %t270)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t271, ptr %l168
  br label %bb87
bb87:
  %t272 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l168
  %t273 = call ptr @__olang_scope_alloc_a(ptr %s19, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t272, ptr %t273
  %t275 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s19, ptr %s19, ptr %t273)
  store { i64, ptr } %t275, ptr %l170
  br label %bb88
bb88:
  %t276 = load ptr, ptr %l164, !tbaa !29
  %t277 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t278 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclosure(ptr %s0, ptr %s19, ptr %s19, ptr %t276, { i64, ptr } %t277)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %l171
  br label %bb89
bb89:
  %t279 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l171
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t279, ptr %l26
  %t280 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s19, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t280, ptr %l172
  br label %bb90
bb90:
  %t281 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l172
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t281, ptr %l27
  store i64 0, ptr %l28, !tbaa !24
  %t282 = load ptr, ptr %lp3
  %t283 = getelementptr %"compiler/typed:DropHolding", ptr %t282, i32 0, i32 0
  %t285 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t283)
  store i64 %t285, ptr %l174
  br label %bb91
bb91:
  %t286 = load i64, ptr %l174, !tbaa !24
  store i64 %t286, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t287 = load i64, ptr %l29, !tbaa !24
  %t288 = load i64, ptr %l28, !tbaa !24
  %t291 = icmp sgt i64 %t287, %t288
  br i1 %t291, label %bb92, label %bb93
bb92:
  %t293 = load i64, ptr %l30, !tbaa !24
  %t295 = icmp sgt i64 %t293, 0
  br i1 %t295, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l178, !tbaa !24
  br label %bb97
bb94:
  %t297 = load i64, ptr %l29, !tbaa !24
  %t298 = load i64, ptr %l28, !tbaa !24
  %t301 = sub i64 %t297, %t298
  %t302 = load i64, ptr %l30, !tbaa !24
  %t305 = add i64 %t301, %t302
  %t307 = sub i64 %t305, 1
  %t308 = load i64, ptr %l30, !tbaa !24
  %t311 = sdiv i64 %t307, %t308
  store i64 %t311, ptr %l181, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l181, !tbaa !24
  br label %bb96
bb96:
  %t313 = load i64, ptr %l181, !tbaa !24
  store i64 %t313, ptr %l178, !tbaa !24
  br label %bb97
bb97:
  %t314 = load i64, ptr %l178, !tbaa !24
  store i64 %t314, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb98
bb98:
  %t315 = load i64, ptr %l32, !tbaa !24
  %t316 = load i64, ptr %l31, !tbaa !24
  %t319 = icmp slt i64 %t315, %t316
  %t321 = xor i1 %t319, true
  br i1 %t321, label %bb99, label %bb100
bb99:
  br label %bb118
bb100:
  br label %bb101
bb101:
  %t323 = load i64, ptr %l28, !tbaa !24
  %t324 = load i64, ptr %l32, !tbaa !24
  %t325 = load i64, ptr %l30, !tbaa !24
  %t328 = mul i64 %t324, %t325
  %t331 = add i64 %t323, %t328
  store i64 %t331, ptr %l33, !tbaa !24
  %t333 = load i64, ptr %l33, !tbaa !24
  %t334 = load i64, ptr %l25, !tbaa !24
  %t337 = icmp ne i64 %t333, %t334
  br i1 %t337, label %bb102, label %bb103
bb102:
  %t339 = load ptr, ptr %lp3
  %t340 = getelementptr %"compiler/typed:DropHolding", ptr %t339, i32 0, i32 1
  %t341 = load i64, ptr %l33, !tbaa !24
  %t344 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v2, ptr %t340, i64 %t341)
  store i32 %t344, ptr %l205
  br label %bb104
bb103:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb106
bb104:
  %t345 = load ptr, ptr %lp3
  %t346 = getelementptr %"compiler/typed:DropHolding", ptr %t345, i32 0, i32 1
  %t347 = load i64, ptr %l25, !tbaa !24
  %t350 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v2, ptr %t346, i64 %t347)
  store i32 %t350, ptr %l208
  br label %bb105
bb105:
  %t351 = load i32, ptr %l205, !tbaa !23
  %t352 = load i32, ptr %l208, !tbaa !23
  %t353 = icmp eq i32 %t351, %t352
  store i1 %t353, ptr %l202, !tbaa !21
  br label %bb106
bb106:
  %t355 = load i1, ptr %l202, !tbaa !21
  br i1 %t355, label %bb107, label %bb108
bb107:
  store ptr %l26, ptr %l211, !tbaa !29
  %t356 = load ptr, ptr %lp3
  %t357 = getelementptr %"compiler/typed:DropHolding", ptr %t356, i32 0, i32 0
  %t358 = load i64, ptr %l33, !tbaa !24
  %t361 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t357, i64 %t358)
  store i64 %t361, ptr %l214
  br label %bb109
bb108:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb111
bb109:
  %t362 = load ptr, ptr %l211, !tbaa !29
  %t363 = load i64, ptr %l214, !tbaa !24
  %t364 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s19, ptr %t362, i64 %t363)
  store i1 %t364, ptr %l215
  br label %bb110
bb110:
  %t365 = load i1, ptr %l215, !tbaa !21
  store i1 %t365, ptr %l210, !tbaa !21
  br label %bb111
bb111:
  %t366 = load i1, ptr %l210, !tbaa !21
  br i1 %t366, label %bb112, label %bb113
bb112:
  store ptr %l27, ptr %l216, !tbaa !29
  %t367 = load ptr, ptr %lp3
  %t368 = getelementptr %"compiler/typed:DropHolding", ptr %t367, i32 0, i32 0
  %t369 = load i64, ptr %l33, !tbaa !24
  %t372 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t368, i64 %t369)
  store i64 %t372, ptr %l219
  br label %bb114
bb113:
  br label %bb116
bb114:
  %t373 = load ptr, ptr %l216, !tbaa !29
  %t374 = load i64, ptr %l219, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s19, ptr %t373, i64 %t374)
  br label %bb115
bb115:
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t375 = load i64, ptr %l32, !tbaa !24
  %t377 = add i64 %t375, 1
  store i64 %t377, ptr %l32, !tbaa !24
  br label %bb98
bb118:
  %t379 = load ptr, ptr %lp3
  %t380 = getelementptr %"compiler/typed:DropHolding", ptr %t379, i32 0, i32 2
  %t381 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v2, ptr %s19, ptr %t380, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t381)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s19)
  br label %bb120
bb120:
  %t384 = load i64, ptr %l24, !tbaa !24
  %t386 = add i64 %t384, 1
  store i64 %t386, ptr %l24, !tbaa !24
  br label %bb82
bb121:
  %t388 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l226, ptr %t388, i64 224, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l226, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2ftyped_2eLastCopies(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"compiler/typed:LastUses"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca i1
  %l21 = alloca i64
  %l22 = alloca %"compiler/typed:LastUses"
  %l23 = alloca ptr
  %l31 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l63 = alloca i1
  %l64 = alloca { i64, ptr }
  %l66 = alloca i64
  %l69 = alloca i64
  %l71 = alloca i1
  %l73 = alloca i1
  %l74 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca i1
  %l80 = alloca ptr
  %l83 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %t23 = alloca %"compiler/typed:LastUses", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Body", ptr %t3, i32 0, i32 11
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 14
  %t13 = load i1, ptr %t12, !tbaa !21
  store i1 %t13, ptr %l15, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l15, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 7
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l21
  br label %bb8
bb8:
  %t24 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2ftyped_3aLastUses_2ector(ptr %t23, ptr %s0, i64 %t24)
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t23, i64 264, i1 false)
  br label %bb9
bb9:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l22, i64 264, i1 false)
  store ptr %l3, ptr %l23, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 11
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_160fc62cca54a9e9_1017e7cee7f3c75d)
  unreachable
bb11:
  br label %bb12
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 11
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %s0, ptr %v0, ptr %t37, ptr %t35)
  br label %bb13
bb13:
  store i64 0, ptr %l4, !tbaa !24
  %t39 = getelementptr %"compiler/typed:LastUses", ptr %l3, i32 0, i32 6
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t39)
  store i64 %t41, ptr %l31
  br label %bb14
bb14:
  %t42 = load i64, ptr %l31, !tbaa !24
  store i64 %t42, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp sgt i64 %t43, %t44
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb20
bb17:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l38, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb19
bb19:
  %t69 = load i64, ptr %l38, !tbaa !24
  store i64 %t69, ptr %l35, !tbaa !24
  br label %bb20
bb20:
  %t70 = load i64, ptr %l35, !tbaa !24
  store i64 %t70, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb22, label %bb23
bb22:
  br label %bb45
bb23:
  br label %bb24
bb24:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l9, !tbaa !24
  %t89 = getelementptr %"compiler/typed:LastUses", ptr %l3, i32 0, i32 7
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t89, i64 %t90)
  store i64 %t93, ptr %l58
  br label %bb25
bb25:
  %t94 = load i64, ptr %l58, !tbaa !24
  store i64 %t94, ptr %l10, !tbaa !24
  %t95 = getelementptr %"compiler/typed:LastUses", ptr %l3, i32 0, i32 8
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t95, i64 %t96)
  store i64 %t99, ptr %l61
  br label %bb26
bb26:
  %t100 = load i64, ptr %l61, !tbaa !24
  %t101 = icmp sge i64 %t100, 0
  br i1 %t101, label %bb27, label %bb28
bb27:
  %t103 = getelementptr %"compiler/typed:LastUses", ptr %l3, i32 0, i32 1
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l64, !tbaa !27
  %t105 = load i64, ptr %l10, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i64, ptr %t108, i64 %t105
  %t110 = load i64, ptr %t109, !tbaa !34
  store i64 %t110, ptr %l66, !tbaa !24
  %t111 = getelementptr %"compiler/typed:LastUses", ptr %l3, i32 0, i32 8
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t111, i64 %t112)
  store i64 %t115, ptr %l69
  br label %bb29
bb28:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb30
bb29:
  %t116 = load i64, ptr %l66, !tbaa !24
  %t117 = load i64, ptr %l69, !tbaa !24
  %t118 = icmp eq i64 %t116, %t117
  store i1 %t118, ptr %l63, !tbaa !21
  br label %bb30
bb30:
  %t120 = load i1, ptr %l63, !tbaa !21
  br i1 %t120, label %bb31, label %bb32
bb31:
  br i1 %a1, label %bb33, label %bb34
bb32:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb38
bb33:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb37
bb34:
  %t123 = getelementptr %"compiler/typed:LastUses", ptr %l3, i32 0, i32 10
  store ptr %t123, ptr %l74, !tbaa !29
  %t124 = getelementptr %"compiler/typed:LastUses", ptr %l3, i32 0, i32 6
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t124, i64 %t125)
  store i64 %t128, ptr %l77
  br label %bb35
bb35:
  %t129 = load ptr, ptr %l74, !tbaa !29
  %t130 = load i64, ptr %l77, !tbaa !24
  %t131 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %t129, i64 %t130)
  store i1 %t131, ptr %l78
  br label %bb36
bb36:
  %t132 = load i1, ptr %l78, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l73, !tbaa !21
  br label %bb37
bb37:
  %t135 = load i1, ptr %l73, !tbaa !21
  store i1 %t135, ptr %l71, !tbaa !21
  br label %bb38
bb38:
  %t136 = load i1, ptr %l71, !tbaa !21
  br i1 %t136, label %bb39, label %bb40
bb39:
  store ptr %l2, ptr %l80, !tbaa !29
  %t137 = getelementptr %"compiler/typed:LastUses", ptr %l3, i32 0, i32 6
  %t138 = load i64, ptr %l9, !tbaa !24
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t137, i64 %t138)
  store i64 %t141, ptr %l83
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t143 = load ptr, ptr %l80, !tbaa !29
  %t144 = load i64, ptr %l83, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v1, ptr %t143, i64 %t144, i64 %t142)
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t146 = load i64, ptr %l8, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l8, !tbaa !24
  br label %bb21
bb45:
  %t150 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t150, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/typed:Local"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l17 = alloca %"compiler/typed:LocalUses"
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca %"compiler/typed:Local"
  %l72 = alloca ptr
  %l75 = alloca i64
  %l81 = alloca i32
  %l85 = alloca i1
  %l86 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i1
  %l97 = alloca ptr
  %l106 = alloca i64
  %l108 = alloca i64
  %l113 = alloca i32
  %l120 = alloca %"compiler/typed:LocalUses"
  %t3 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_3aLocalUses_2ector(ptr %t3, ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t3, i64 1320, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 1320, i64 8)
  store ptr %t6, ptr %lp2
  %t7 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %l17, i64 1320, i1 false)
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t10)
  store i64 %t12, ptr %l20
  br label %bb2
bb2:
  %t13 = load i64, ptr %l20, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb5:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l27, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l27, !tbaa !24
  store i64 %t40, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l24, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load ptr, ptr %lp2
  %t61 = getelementptr %"compiler/typed:LocalUses", ptr %t60, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t61, i1 false)
  br label %bb13
bb13:
  %t63 = load ptr, ptr %lp2
  %t64 = getelementptr %"compiler/typed:LocalUses", ptr %t63, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t64, i1 false)
  br label %bb14
bb14:
  %t66 = load ptr, ptr %lp2
  %t67 = getelementptr %"compiler/typed:LocalUses", ptr %t66, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t67, i1 false)
  br label %bb15
bb15:
  %t69 = load ptr, ptr %lp2
  %t70 = getelementptr %"compiler/typed:LocalUses", ptr %t69, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t70, i1 false)
  br label %bb16
bb16:
  %t72 = load ptr, ptr %lp2
  %t73 = getelementptr %"compiler/typed:LocalUses", ptr %t72, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t73, i1 false)
  br label %bb17
bb17:
  %t75 = load ptr, ptr %lp2
  %t76 = getelementptr %"compiler/typed:LocalUses", ptr %t75, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t76, i1 false)
  br label %bb18
bb18:
  %t78 = load ptr, ptr %lp2
  %t79 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t79, i1 false)
  br label %bb19
bb19:
  %t81 = load ptr, ptr %lp2
  %t82 = getelementptr %"compiler/typed:LocalUses", ptr %t81, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t82, i64 -1)
  br label %bb20
bb20:
  %t84 = load ptr, ptr %lp2
  %t85 = getelementptr %"compiler/typed:LocalUses", ptr %t84, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePus_H0c70e9e86794aea54789ff5f3987086b(ptr %v2, ptr %v2, ptr %t85, ptr null)
  br label %bb21
bb21:
  %t87 = load ptr, ptr %lp2
  %t88 = getelementptr %"compiler/typed:LocalUses", ptr %t87, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t88, i1 false)
  br label %bb22
bb22:
  %t90 = load ptr, ptr %lp2
  %t91 = getelementptr %"compiler/typed:LocalUses", ptr %t90, i32 0, i32 29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t91, i1 false)
  br label %bb23
bb23:
  %t93 = load ptr, ptr %lp2
  %t94 = getelementptr %"compiler/typed:LocalUses", ptr %t93, i32 0, i32 30
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t94, i1 false)
  br label %bb24
bb24:
  %t96 = load ptr, ptr %lp2
  %t97 = getelementptr %"compiler/typed:LocalUses", ptr %t96, i32 0, i32 31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t97, i1 false)
  br label %bb25
bb25:
  %t99 = load ptr, ptr %lp2
  %t100 = getelementptr %"compiler/typed:LocalUses", ptr %t99, i32 0, i32 32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t100, i1 false)
  br label %bb26
bb26:
  %t102 = load ptr, ptr %lp2
  %t103 = getelementptr %"compiler/typed:LocalUses", ptr %t102, i32 0, i32 33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v2, ptr %t103, i1 false)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l7, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l7, !tbaa !24
  br label %bb9
bb29:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Body", ptr %t109, i32 0, i32 7
  store ptr %t111, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  %t113 = load i64, ptr %l10, !tbaa !24
  store i64 %t113, ptr %l64, !tbaa !24
  %t114 = load ptr, ptr %l9, !tbaa !29
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t114)
  store i64 %t116, ptr %l66
  br label %bb31
bb31:
  %t117 = load i64, ptr %l64, !tbaa !24
  %t118 = load i64, ptr %l66, !tbaa !24
  %t119 = icmp slt i64 %t117, %t118
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb32, label %bb33
bb32:
  br label %bb41
bb33:
  br label %bb34
bb34:
  %t123 = load ptr, ptr %l9, !tbaa !29
  %t124 = load i64, ptr %l10, !tbaa !24
  %t127 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t123, i64 %t124)
  store %"compiler/typed:Local" %t127, ptr %l71
  br label %bb35
bb35:
  %t128 = load %"compiler/typed:Local", ptr %l71
  store %"compiler/typed:Local" %t128, ptr %l11
  %t129 = load ptr, ptr %lp2
  %t130 = getelementptr %"compiler/typed:LocalUses", ptr %t129, i32 0, i32 44
  store ptr %t130, ptr %l72, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 4
  %t132 = load i32, ptr %t131, !range !{i32 0, i32 7}
  %t134 = trunc i64 0 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb36, label %bb37
bb36:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb38
bb37:
  store i64 9223372036854775807, ptr %l75, !tbaa !24
  br label %bb38
bb38:
  %t137 = load ptr, ptr %l72, !tbaa !29
  %t138 = load i64, ptr %l75, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t137, i64 %t138)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l10, !tbaa !24
  br label %bb30
bb41:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Body", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %t146, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t143, i32 %t147)
  store i32 %t150, ptr %l81
  br label %bb42
bb42:
  %t151 = load i32, ptr %l81, !range !{i32 0, i32 33}
  %t153 = trunc i64 21 to i32
  %t154 = icmp eq i32 %t151, %t153
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb47
bb44:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l86, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Body", ptr %t160, i32 0, i32 2
  %t163 = load i32, ptr %t162, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t159, i32 %t163)
  store i32 %t166, ptr %l90
  br label %bb45
bb45:
  %t167 = load ptr, ptr %l86, !tbaa !29
  %t168 = load i32, ptr %l90, !tbaa !23
  %t169 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t167, i32 %t168)
  store i1 %t169, ptr %l91
  br label %bb46
bb46:
  %t170 = load i1, ptr %l91, !tbaa !21
  %t171 = xor i1 %t170, true
  store i1 %t171, ptr %l85, !tbaa !21
  br label %bb47
bb47:
  %t173 = load i1, ptr %l85, !tbaa !21
  %t174 = load ptr, ptr %lp2
  %t175 = getelementptr %"compiler/typed:LocalUses", ptr %t174, i32 0, i32 50
  store i1 %t173, ptr %t175, !tbaa !21
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Body", ptr %t176, i32 0, i32 11
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = icmp eq ptr %t179, null
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb48, label %bb49
bb48:
  %t185 = load ptr, ptr %lp2
  store ptr %t185, ptr %l97, !tbaa !29
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Body", ptr %t186, i32 0, i32 11
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = icmp eq ptr %t189, null
  br i1 %t191, label %bb50, label %bb51
bb49:
  br label %bb54
bb50:
  call void @__olang_check_failed(ptr @olang_loc_5a8d28bd3acbc65d_f5c7f83d77176e09)
  unreachable
bb51:
  br label %bb52
bb52:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Body", ptr %t193, i32 0, i32 11
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = load ptr, ptr %l97, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v2, ptr %v1, ptr %v1, ptr %v0, ptr %t198, ptr %t196)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Body", ptr %t200, i32 0, i32 10
  store ptr %t202, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb55
bb55:
  %t204 = load i64, ptr %l13, !tbaa !24
  store i64 %t204, ptr %l106, !tbaa !24
  %t205 = load ptr, ptr %l12, !tbaa !29
  %t207 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t205)
  store i64 %t207, ptr %l108
  br label %bb56
bb56:
  %t208 = load i64, ptr %l106, !tbaa !24
  %t209 = load i64, ptr %l108, !tbaa !24
  %t210 = icmp slt i64 %t208, %t209
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb57, label %bb58
bb57:
  br label %bb63
bb58:
  br label %bb59
bb59:
  %t214 = load ptr, ptr %l12, !tbaa !29
  %t215 = load i64, ptr %l13, !tbaa !24
  %t218 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t214, i64 %t215)
  store i32 %t218, ptr %l113
  br label %bb60
bb60:
  %t219 = load i32, ptr %l113, !tbaa !23
  %t220 = load ptr, ptr %lp2
  %t221 = getelementptr %"compiler/typed:LocalUses", ptr %t220, i32 0, i32 8
  %t224 = sext i32 %t219 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v2, ptr %t221, i64 %t224, i1 true)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t227 = load i64, ptr %l13, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l13, !tbaa !24
  br label %bb55
bb63:
  %t231 = load ptr, ptr %lp2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecloseAliases(ptr %v2, ptr %v0, ptr %t231)
  br label %bb64
bb64:
  %t233 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l120, ptr %t233, i64 1320, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l120, i64 1320, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2eMovedArg(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 2
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Seq", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  store i1 %t28, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Seq", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_c21a1343bdb3d01_d6f77a8ccb597545)
  unreachable
bb13:
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Seq", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l2, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t45 = load ptr, ptr %l27, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l27, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 2
  store i1 %t51, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l3
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l4, !tbaa !23
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t73, i32 0, i32 3
  %t75 = load i32, ptr %t74
  store i32 %t75, ptr %l6, !tbaa !23
  store ptr %t69, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb21
bb19:
  %t81 = load ptr, ptr %l40, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 8}
  %t84 = icmp eq i64 %t82, 0
  store i1 %t84, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t85 = load i1, ptr %l41, !tbaa !21
  store i1 %t85, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t86 = load i1, ptr %l31, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb22:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t88 = load ptr, ptr %l44, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l44, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 18}
  %t94 = icmp eq i64 %t92, 17
  store i1 %t94, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t95 = load i1, ptr %l45, !tbaa !21
  br i1 %t95, label %bb25, label %bb26
bb25:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t98, i32 0, i32 2
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l7, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t102 = load ptr, ptr %l7, !tbaa !29
  %t104 = call i1 @compiler_2ftyped_2eMovedArg(ptr %v0, ptr %t102)
  store i1 %t104, ptr %l51
  br label %bb28
bb28:
  %t105 = load i1, ptr %l51, !tbaa !21
  store i1 %t105, ptr %rv
  br label %ret
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i1 false, ptr %rv
  br label %ret
bb33:
  call void @__olang_check_failed(ptr @olang_loc_4964fda744059959_ea5b63edb7fb932d)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ePlan_2eNew(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/typed:Plan"
  %t16 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Body", ptr %t6, i32 0, i32 7
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l6
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 6
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l9
  br label %bb3
bb3:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2ftyped_3aPlan_2ector(ptr %t16, ptr %v1, i64 %t17, i64 %t18, i64 %t19)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t16, i64 584, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l10, i64 584, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftyped_2ePlan_2ereadHead(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l37 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l45 = alloca i64
  %l49 = alloca %"compiler/typed:Plan"
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i1
  %l58 = alloca i1
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i1
  %l67 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i1
  %l78 = alloca { i64, ptr }
  %l80 = alloca i32
  %l83 = alloca { i64, ptr }
  %l85 = alloca i32
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l93 = alloca i64
  %l97 = alloca { i64, ptr }
  %l99 = alloca i32
  %l102 = alloca { i64, ptr }
  %l104 = alloca i32
  %l107 = alloca { i64, ptr }
  %l109 = alloca i32
  %l112 = alloca { i64, ptr }
  %l114 = alloca i32
  %l117 = alloca { i64, ptr }
  %l118 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l120 = alloca i64
  %l122 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i32
  %l133 = alloca i64
  %l134 = alloca { i64, ptr }
  %l135 = alloca i64
  %l136 = alloca i64
  %l140 = alloca { i64, ptr }
  %l141 = alloca i64
  %l142 = alloca i32
  %l143 = alloca i64
  %l144 = alloca i32
  %l148 = alloca i1
  %l154 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l155 = alloca { i64, ptr }
  %l157 = alloca i64
  %l160 = alloca i64
  %l161 = alloca i64
  %l166 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l177 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca { i64, [2 x i64] }
  %l182 = alloca { i64, [2 x i64] }
  %l183 = alloca i32
  %l187 = alloca ptr
  %l190 = alloca i32
  %l192 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l197 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l199 = alloca i64
  %l201 = alloca i64
  %l206 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l209 = alloca ptr
  %l211 = alloca i64
  %l214 = alloca ptr
  %l215 = alloca i64
  %l217 = alloca { i64, ptr }
  %l218 = alloca i64
  %l219 = alloca i32
  %l220 = alloca i64
  %l221 = alloca i32
  %l223 = alloca ptr
  %l224 = alloca i64
  %l226 = alloca { i64, ptr }
  %l227 = alloca i64
  %l228 = alloca i32
  %l229 = alloca i64
  %l230 = alloca i32
  %l235 = alloca { i64, ptr }
  %l236 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l238 = alloca i64
  %l240 = alloca i64
  %l245 = alloca { i64, ptr }
  %l246 = alloca i64
  %l248 = alloca i64
  %l249 = alloca i32
  %l251 = alloca i64
  %l252 = alloca { i64, ptr }
  %l253 = alloca i64
  %l254 = alloca i64
  %l258 = alloca { i64, ptr }
  %l259 = alloca i64
  %l260 = alloca i32
  %l261 = alloca i64
  %l262 = alloca i32
  %l264 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l265 = alloca { i64, ptr }
  %l267 = alloca i64
  %l270 = alloca i64
  %l271 = alloca i64
  %l276 = alloca { i64, ptr }
  %l283 = alloca { i64, ptr }
  %l287 = alloca i1
  %l289 = alloca { i64, ptr }
  %l290 = alloca ptr
  %l292 = alloca i64
  %l295 = alloca i64
  %l297 = alloca { i64, ptr }
  %l298 = alloca i64
  %l299 = alloca i32
  %l300 = alloca i64
  %l301 = alloca i32
  %l303 = alloca i64
  %l305 = alloca { i64, ptr }
  %l306 = alloca i64
  %l307 = alloca i32
  %l308 = alloca i64
  %l309 = alloca i32
  %l311 = alloca ptr
  %l312 = alloca i64
  %l313 = alloca i64
  %l314 = alloca { i64, [2 x i64] }
  %l315 = alloca { i64, ptr }
  %l317 = alloca { i64, ptr }
  %l318 = alloca i64
  %l320 = alloca { i64, ptr }
  %l323 = alloca i64
  %l326 = alloca i64
  %l327 = alloca i64
  %l332 = alloca { i64, [2 x i64] }
  %l333 = alloca i32
  %l335 = alloca %"compiler/typed:DerivedArg"
  %l345 = alloca %"compiler/typed:Plan"
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca i32
  %t30 = alloca %"compiler/typed:Plan", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %a1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l34
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t5 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v1, ptr %s0, { i64, ptr } %t4)
  store ptr %t5, ptr %l35
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l35, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t7)
  store i64 %t9, ptr %l37
  br label %bb3
bb3:
  %t10 = load i64, ptr %l37, !tbaa !24
  %t11 = icmp ne i64 %t10, 7
  br i1 %t11, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t14, i64 0)
  store { i64, ptr } %t16, ptr %l41
  br label %bb7
bb7:
  %t17 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t18 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store { i64, ptr } %t18, ptr %l42
  br label %bb8
bb8:
  %t19 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t20 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0, ptr %s0, { i64, ptr } %t19)
  store ptr %t20, ptr %l43
  br label %bb9
bb9:
  %t21 = load ptr, ptr %l43, !tbaa !29
  store ptr %t21, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t22)
  store i64 %t24, ptr %l45
  br label %bb10
bb10:
  %t25 = load i64, ptr %l45, !tbaa !24
  %t26 = icmp ne i64 %t25, 3
  br i1 %t26, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  call void @compiler_2ftyped_2ePlan_2eNew(ptr %t30, ptr %v0, ptr %v2, ptr %a0)
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t30, i64 584, i1 false)
  br label %bb14
bb14:
  %t32 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 584, i64 8)
  store ptr %t32, ptr %lp4
  %t33 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %l49, i64 584, i1 false)
  %t34 = load ptr, ptr %lp4
  %t35 = getelementptr %"compiler/typed:Plan", ptr %t34, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t40 = call i64 @__olang_fmt_i64(ptr null, i64 %t38)
  %t41 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t40)
  %t42 = call i64 @__olang_fmt_i64(ptr %t41, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l53, !tbaa !27
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t52, i64 0)
  store { i64, ptr } %t54, ptr %l55
  br label %bb15
bb15:
  %t55 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t55, { i64, ptr } %t56)
  store i1 %t57, ptr %l56
  br label %bb16
bb16:
  %t58 = load i1, ptr %l56, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb21
bb18:
  %t61 = load ptr, ptr %lp4
  %t62 = getelementptr %"compiler/typed:Plan", ptr %t61, i32 0, i32 1
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t67 = call i64 @__olang_fmt_i64(ptr null, i64 %t65)
  %t68 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t67)
  %t69 = call i64 @__olang_fmt_i64(ptr %t68, i64 %t65)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t68, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l62, !tbaa !27
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t79, i64 1)
  store { i64, ptr } %t81, ptr %l64
  br label %bb19
bb19:
  %t82 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t82, { i64, ptr } %t83)
  store i1 %t84, ptr %l65
  br label %bb20
bb20:
  %t85 = load i1, ptr %l65, !tbaa !21
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %l58, !tbaa !21
  br label %bb21
bb21:
  %t88 = load i1, ptr %l58, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb26
bb23:
  %t89 = load ptr, ptr %lp4
  %t90 = getelementptr %"compiler/typed:Plan", ptr %t89, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t95 = call i64 @__olang_fmt_i64(ptr null, i64 %t93)
  %t96 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t95)
  %t97 = call i64 @__olang_fmt_i64(ptr %t96, i64 %t93)
  %t98 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l71, !tbaa !27
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t107, i64 2)
  store { i64, ptr } %t109, ptr %l73
  br label %bb24
bb24:
  %t110 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t112 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t110, { i64, ptr } %t111)
  store i1 %t112, ptr %l74
  br label %bb25
bb25:
  %t113 = load i1, ptr %l74, !tbaa !21
  %t114 = xor i1 %t113, true
  store i1 %t114, ptr %l67, !tbaa !21
  br label %bb26
bb26:
  %t116 = load i1, ptr %l67, !tbaa !21
  br i1 %t116, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t120 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t118, i64 1)
  store { i64, ptr } %t120, ptr %l78
  br label %bb30
bb30:
  %t121 = load ptr, ptr %lp4
  %t122 = getelementptr %"compiler/typed:Plan", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t126 = call i32 @compiler_2ftyped_2ereadScopes(ptr %s0, ptr %v2, { i64, ptr } %t124, { i64, ptr } %t123)
  store i32 %t126, ptr %l80
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb32, label %ok.128, !prof !99
ok.128:
  br label %bb31
bb31:
  br label %bb33
bb32:
  %t129 = load i32, ptr %l80, !tbaa !23
  %t130 = lshr i32 %t129, 16
  %t131 = and i32 %t129, 65535
  %t132 = icmp eq i32 %t130, 1
  %t133 = select i1 %t132, i32 1, i32 0
  %t134 = icmp eq i32 %t129, 0
  %t135 = shl i32 %t133, 16
  %t136 = or i32 %t135, %t131
  %t137 = select i1 %t134, i32 0, i32 %t136
  call void @__olang_scope_close(ptr %s0)
  store i32 %t137, ptr %rv
  br label %ret
bb33:
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t141 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t139, i64 2)
  store { i64, ptr } %t141, ptr %l83
  br label %bb34
bb34:
  %t142 = load ptr, ptr %lp4
  %t143 = getelementptr %"compiler/typed:Plan", ptr %t142, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t147 = call i32 @compiler_2ftyped_2ereadScopes(ptr %s0, ptr %v2, { i64, ptr } %t145, { i64, ptr } %t144)
  store i32 %t147, ptr %l85
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb36, label %ok.149, !prof !99
ok.149:
  br label %bb35
bb35:
  br label %bb37
bb36:
  %t150 = load i32, ptr %l85, !tbaa !23
  %t151 = lshr i32 %t150, 16
  %t152 = and i32 %t150, 65535
  %t153 = icmp eq i32 %t151, 1
  %t154 = select i1 %t153, i32 1, i32 0
  %t155 = icmp eq i32 %t150, 0
  %t156 = shl i32 %t154, 16
  %t157 = or i32 %t156, %t152
  %t158 = select i1 %t155, i32 0, i32 %t157
  call void @__olang_scope_close(ptr %s0)
  store i32 %t158, ptr %rv
  br label %ret
bb37:
  %t160 = load ptr, ptr %l2, !tbaa !29
  %t162 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t160, i64 3)
  store { i64, ptr } %t162, ptr %l88
  br label %bb38
bb38:
  %t163 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t164 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s0, { i64, ptr } %t163)
  store { i64, ptr } %t164, ptr %l89
  br label %bb39
bb39:
  %t165 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t166 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t165, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store { i64, ptr } %t166, ptr %l90
  br label %bb40
bb40:
  %t167 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t168 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0, ptr %s0, { i64, ptr } %t167)
  store ptr %t168, ptr %l91
  br label %bb41
bb41:
  %t169 = load ptr, ptr %l91, !tbaa !29
  store ptr %t169, ptr %l5, !tbaa !29
  %t170 = load ptr, ptr %l5, !tbaa !29
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t170)
  store i64 %t172, ptr %l93
  br label %bb42
bb42:
  %t173 = load i64, ptr %l93, !tbaa !24
  %t174 = icmp ne i64 %t173, 4
  br i1 %t174, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t177 = load ptr, ptr %l5, !tbaa !29
  %t179 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t177, i64 0)
  store { i64, ptr } %t179, ptr %l97
  br label %bb46
bb46:
  %t180 = load ptr, ptr %lp4
  %t181 = getelementptr %"compiler/typed:Plan", ptr %t180, i32 0, i32 2
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t185 = call i32 @compiler_2ftyped_2ereadBits(ptr %s0, ptr %v2, { i64, ptr } %t183, { i64, ptr } %t182)
  store i32 %t185, ptr %l99
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb48, label %ok.187, !prof !99
ok.187:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t188 = load i32, ptr %l99, !tbaa !23
  %t189 = lshr i32 %t188, 16
  %t190 = and i32 %t188, 65535
  %t191 = icmp eq i32 %t189, 1
  %t192 = select i1 %t191, i32 1, i32 0
  %t193 = icmp eq i32 %t188, 0
  %t194 = shl i32 %t192, 16
  %t195 = or i32 %t194, %t190
  %t196 = select i1 %t193, i32 0, i32 %t195
  call void @__olang_scope_close(ptr %s0)
  store i32 %t196, ptr %rv
  br label %ret
bb49:
  %t198 = load ptr, ptr %l5, !tbaa !29
  %t200 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t198, i64 1)
  store { i64, ptr } %t200, ptr %l102
  br label %bb50
bb50:
  %t201 = load ptr, ptr %lp4
  %t202 = getelementptr %"compiler/typed:Plan", ptr %t201, i32 0, i32 3
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t206 = call i32 @compiler_2ftyped_2ereadBits(ptr %s0, ptr %v2, { i64, ptr } %t204, { i64, ptr } %t203)
  store i32 %t206, ptr %l104
  %t207 = icmp ne i32 %t206, 0
  br i1 %t207, label %bb52, label %ok.208, !prof !99
ok.208:
  br label %bb51
bb51:
  br label %bb53
bb52:
  %t209 = load i32, ptr %l104, !tbaa !23
  %t210 = lshr i32 %t209, 16
  %t211 = and i32 %t209, 65535
  %t212 = icmp eq i32 %t210, 1
  %t213 = select i1 %t212, i32 1, i32 0
  %t214 = icmp eq i32 %t209, 0
  %t215 = shl i32 %t213, 16
  %t216 = or i32 %t215, %t211
  %t217 = select i1 %t214, i32 0, i32 %t216
  call void @__olang_scope_close(ptr %s0)
  store i32 %t217, ptr %rv
  br label %ret
bb53:
  %t219 = load ptr, ptr %l5, !tbaa !29
  %t221 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t219, i64 2)
  store { i64, ptr } %t221, ptr %l107
  br label %bb54
bb54:
  %t222 = load ptr, ptr %lp4
  %t223 = getelementptr %"compiler/typed:Plan", ptr %t222, i32 0, i32 5
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t227 = call i32 @compiler_2ftyped_2ereadBits(ptr %s0, ptr %v2, { i64, ptr } %t225, { i64, ptr } %t224)
  store i32 %t227, ptr %l109
  %t228 = icmp ne i32 %t227, 0
  br i1 %t228, label %bb56, label %ok.229, !prof !99
ok.229:
  br label %bb55
bb55:
  br label %bb57
bb56:
  %t230 = load i32, ptr %l109, !tbaa !23
  %t231 = lshr i32 %t230, 16
  %t232 = and i32 %t230, 65535
  %t233 = icmp eq i32 %t231, 1
  %t234 = select i1 %t233, i32 1, i32 0
  %t235 = icmp eq i32 %t230, 0
  %t236 = shl i32 %t234, 16
  %t237 = or i32 %t236, %t232
  %t238 = select i1 %t235, i32 0, i32 %t237
  call void @__olang_scope_close(ptr %s0)
  store i32 %t238, ptr %rv
  br label %ret
bb57:
  %t240 = load ptr, ptr %l5, !tbaa !29
  %t242 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t240, i64 3)
  store { i64, ptr } %t242, ptr %l112
  br label %bb58
bb58:
  %t243 = load ptr, ptr %lp4
  %t244 = getelementptr %"compiler/typed:Plan", ptr %t243, i32 0, i32 4
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  %t246 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t248 = call i32 @compiler_2ftyped_2ereadBits(ptr %s0, ptr %v2, { i64, ptr } %t246, { i64, ptr } %t245)
  store i32 %t248, ptr %l114
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb60, label %ok.250, !prof !99
ok.250:
  br label %bb59
bb59:
  br label %bb61
bb60:
  %t251 = load i32, ptr %l114, !tbaa !23
  %t252 = lshr i32 %t251, 16
  %t253 = and i32 %t251, 65535
  %t254 = icmp eq i32 %t252, 1
  %t255 = select i1 %t254, i32 1, i32 0
  %t256 = icmp eq i32 %t251, 0
  %t257 = shl i32 %t255, 16
  %t258 = or i32 %t257, %t253
  %t259 = select i1 %t256, i32 0, i32 %t258
  call void @__olang_scope_close(ptr %s0)
  store i32 %t259, ptr %rv
  br label %ret
bb61:
  store %olang.scope zeroinitializer, ptr %s8
  %t261 = load ptr, ptr %l2, !tbaa !29
  %t263 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t261, i64 4)
  store { i64, ptr } %t263, ptr %l117
  br label %bb62
bb62:
  %t264 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t265 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ewordsOf(ptr %s0, ptr %s8, { i64, ptr } %t264)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %l118
  br label %bb63
bb63:
  %t266 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l118
  %t267 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %t267
  store ptr %t267, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s9
  %t269 = load i64, ptr %l7, !tbaa !24
  store i64 %t269, ptr %l120, !tbaa !24
  %t270 = load ptr, ptr %l6, !tbaa !29
  %t272 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s8, ptr %t270)
  store i64 %t272, ptr %l122
  br label %bb65
bb65:
  %t273 = load i64, ptr %l120, !tbaa !24
  %t274 = load i64, ptr %l122, !tbaa !24
  %t275 = icmp slt i64 %t273, %t274
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s9)
  br label %bb117
bb67:
  br label %bb68
bb68:
  %t279 = load ptr, ptr %l6, !tbaa !29
  %t280 = load i64, ptr %l7, !tbaa !24
  %t283 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s8, ptr %s8, ptr %t279, i64 %t280)
  store { i64, ptr } %t283, ptr %l127
  br label %bb69
bb69:
  %t284 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t284, ptr %l8, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t287 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s8, ptr %s9, { i64, ptr } %t285, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) })
  %t288 = extractvalue { i32, i64 } %t287, 1
  %t289 = extractvalue { i32, i64 } %t287, 0
  store i32 %t289, ptr %l131
  %t290 = icmp ne i32 %t289, 0
  br i1 %t290, label %bb71, label %ok.291, !prof !99
ok.291:
  store i64 %t288, ptr %l130
  br label %bb70
bb70:
  %t292 = load i64, ptr %l130, !tbaa !24
  store i64 %t292, ptr %l128, !tbaa !24
  br label %bb73
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb73:
  %t294 = load i64, ptr %l128, !tbaa !24
  store i64 %t294, ptr %l9, !tbaa !24
  %t295 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t295, ptr %l134, !tbaa !27
  %t296 = load i64, ptr %l9, !tbaa !24
  store i64 %t296, ptr %l135, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 0
  store i64 %t298, ptr %l136, !tbaa !24
  %t299 = icmp sge i64 0, 0
  br i1 %t299, label %bb74, label %bb75
bb74:
  %t301 = load i64, ptr %l135, !tbaa !24
  %t302 = icmp sle i64 0, %t301
  br i1 %t302, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_513fe42ccd619edb_f9eefb0210e3c837)
  unreachable
bb76:
  %t304 = load i64, ptr %l135, !tbaa !24
  %t305 = load i64, ptr %l136, !tbaa !24
  %t306 = icmp sle i64 %t304, %t305
  br i1 %t306, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_513fe42ccd619edb_f9eefb0210e3c837)
  unreachable
bb78:
  %t308 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = load i64, ptr %l135, !tbaa !24
  %t311 = getelementptr i8, ptr %t309, i64 0
  %t312 = sub i64 %t310, 0
  %t313 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t311, 1
  store { i64, ptr } %t314, ptr %l140, !tbaa !27
  %t315 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s9, i64 10)
  %t316 = extractvalue { i32, i64 } %t315, 1
  %t317 = extractvalue { i32, i64 } %t315, 0
  store i32 %t317, ptr %l142
  %t318 = icmp ne i32 %t317, 0
  br i1 %t318, label %bb81, label %ok.319, !prof !99
ok.319:
  store i64 %t316, ptr %l141
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_513fe42ccd619edb_f9eefb0210e3c837)
  unreachable
bb80:
  %t320 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t321 = load i64, ptr %l141, !tbaa !24
  %t322 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s8, { i64, ptr } %t320, i64 %t321)
  %t323 = extractvalue { i32, i64 } %t322, 1
  %t324 = extractvalue { i32, i64 } %t322, 0
  store i32 %t324, ptr %l144
  %t325 = icmp ne i32 %t324, 0
  br i1 %t325, label %bb84, label %ok.326, !prof !99
ok.326:
  store i64 %t323, ptr %l143
  br label %bb83
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb83:
  %t328 = load i64, ptr %l143, !tbaa !24
  store i64 %t328, ptr %l133, !tbaa !24
  br label %bb85
bb84:
  br label %bb82
bb85:
  %t329 = load i64, ptr %l133, !tbaa !24
  store i64 %t329, ptr %l10, !tbaa !24
  %t330 = load i64, ptr %l10, !tbaa !24
  %t332 = icmp slt i64 %t330, 0
  br i1 %t332, label %bb86, label %bb87
bb86:
  store i1 true, ptr %l148, !tbaa !21
  br label %bb88
bb87:
  %t334 = load i64, ptr %l10, !tbaa !24
  %t335 = load ptr, ptr %lp4
  %t336 = getelementptr %"compiler/typed:Plan", ptr %t335, i32 0, i32 0
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t342 = icmp sge i64 %t334, %t339
  store i1 %t342, ptr %l148, !tbaa !21
  br label %bb88
bb88:
  %t344 = load i1, ptr %l148, !tbaa !21
  br i1 %t344, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  %t346 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %s9, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t346, ptr %l154
  br label %bb92
bb92:
  %t347 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l154
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t347, ptr %l11
  store %olang.scope zeroinitializer, ptr %s13
  %t348 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t348, ptr %l155, !tbaa !27
  %t349 = load i64, ptr %l9, !tbaa !24
  %t351 = add i64 %t349, 1
  store i64 %t351, ptr %l157, !tbaa !24
  %t352 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t352, 0
  store i64 %t355, ptr %l160, !tbaa !24
  %t356 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t356, 0
  store i64 %t357, ptr %l161, !tbaa !24
  %t358 = load i64, ptr %l157, !tbaa !24
  %t359 = icmp sge i64 %t358, 0
  br i1 %t359, label %bb93, label %bb94
bb93:
  %t361 = load i64, ptr %l157, !tbaa !24
  %t362 = load i64, ptr %l160, !tbaa !24
  %t363 = icmp sle i64 %t361, %t362
  br i1 %t363, label %bb95, label %bb96
bb94:
  call void @__olang_check_failed(ptr @olang_loc_f54e407a1957a5de_bac5f2aedbd3a6da)
  unreachable
bb95:
  %t365 = load i64, ptr %l160, !tbaa !24
  %t366 = load i64, ptr %l161, !tbaa !24
  %t367 = icmp sle i64 %t365, %t366
  br i1 %t367, label %bb97, label %bb98
bb96:
  call void @__olang_check_failed(ptr @olang_loc_f54e407a1957a5de_bac5f2aedbd3a6da)
  unreachable
bb97:
  %t369 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = load i64, ptr %l157, !tbaa !24
  %t372 = load i64, ptr %l160, !tbaa !24
  %t373 = getelementptr i8, ptr %t370, i64 %t371
  %t374 = sub i64 %t372, %t371
  %t375 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t373, 1
  %t378 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s8, ptr %s13, ptr %s13, { i64, ptr } %t376, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t378, ptr %l166
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_f54e407a1957a5de_bac5f2aedbd3a6da)
  unreachable
bb99:
  %t379 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t379, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t380 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t380, 0
  store i64 %t382, ptr %l14, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s14
  %t384 = load i64, ptr %l13, !tbaa !24
  %t385 = load i64, ptr %l14, !tbaa !24
  %t388 = icmp slt i64 %t384, %t385
  %t390 = xor i1 %t388, true
  br i1 %t390, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s14)
  br label %bb113
bb102:
  br label %bb103
bb103:
  %t392 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t392, ptr %l173, !tbaa !27
  %t393 = load i64, ptr %l13, !tbaa !24
  %t395 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !27
  %t397 = getelementptr { i64, ptr }, ptr %t396, i64 %t393
  %t398 = load { i64, ptr }, ptr %t397, !tbaa !37
  store { i64, ptr } %t398, ptr %l15, !tbaa !27
  %t400 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t402 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s13, ptr %s14, { i64, ptr } %t400, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t402, ptr %l177
  br label %bb104
bb104:
  %t403 = load i1, ptr %l177, !tbaa !21
  %t404 = xor i1 %t403, true
  br i1 %t404, label %bb105, label %bb106
bb105:
  store ptr %l11, ptr %l179, !tbaa !29
  %t406 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t408 = call { i32, { i64, [2 x i64] } } @compiler_2ftyped_2eScope_2eOfText(ptr %s13, { i64, ptr } %t406)
  %t409 = extractvalue { i32, { i64, [2 x i64] } } %t408, 1
  %t410 = extractvalue { i32, { i64, [2 x i64] } } %t408, 0
  store i32 %t410, ptr %l183
  %t411 = icmp ne i32 %t410, 0
  br i1 %t411, label %bb108, label %ok.412, !prof !99
ok.412:
  store { i64, [2 x i64] } %t409, ptr %l182
  br label %bb107
bb106:
  br label %bb111
bb107:
  %t413 = load { i64, [2 x i64] }, ptr %l182
  store { i64, [2 x i64] } %t413, ptr %l180
  br label %bb109
bb108:
  %t414 = load i32, ptr %l183, !tbaa !23
  %t415 = lshr i32 %t414, 16
  %t416 = and i32 %t414, 65535
  %t417 = icmp eq i32 %t415, 1
  %t418 = select i1 %t417, i32 1, i32 0
  %t419 = icmp eq i32 %t414, 0
  %t420 = shl i32 %t418, 16
  %t421 = or i32 %t420, %t416
  %t422 = select i1 %t419, i32 0, i32 %t421
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t422, ptr %rv
  br label %ret
bb109:
  %t424 = load ptr, ptr %l179, !tbaa !29
  %t425 = load { i64, [2 x i64] }, ptr %l180
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %s9, ptr %t424, { i64, [2 x i64] } %t425)
  br label %bb110
bb110:
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s14)
  br label %bb112
bb112:
  %t426 = load i64, ptr %l13, !tbaa !24
  %t428 = add i64 %t426, 1
  store i64 %t428, ptr %l13, !tbaa !24
  br label %bb100
bb113:
  call void @__olang_scope_close(ptr %s13)
  %t430 = load ptr, ptr %lp4
  store ptr %t430, ptr %l187, !tbaa !29
  %t431 = load i64, ptr %l10, !tbaa !24
  %t433 = trunc i64 %t431 to i32
  store i32 %t433, ptr %l190, !tbaa !23
  %t436 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eToArray_3ccompiler_2ftyped_3aScope_3e(ptr %s9, ptr %s9, ptr %l11)
  store { i64, ptr } %t436, ptr %l192
  br label %bb114
bb114:
  %t437 = load ptr, ptr %l187, !tbaa !29
  %t438 = load i32, ptr %l190, !tbaa !23
  %t439 = load { i64, ptr }, ptr %l192, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v2, ptr %s9, ptr %t437, i32 %t438, { i64, ptr } %t439)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s9)
  br label %bb116
bb116:
  %t440 = load i64, ptr %l7, !tbaa !24
  %t442 = add i64 %t440, 1
  store i64 %t442, ptr %l7, !tbaa !24
  br label %bb64
bb117:
  call void @__olang_scope_close(ptr %s8)
  store %olang.scope zeroinitializer, ptr %s18
  %t444 = load ptr, ptr %l2, !tbaa !29
  %t446 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t444, i64 5)
  store { i64, ptr } %t446, ptr %l196
  br label %bb118
bb118:
  %t447 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t448 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ewordsOf(ptr %s0, ptr %s18, { i64, ptr } %t447)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t448, ptr %l197
  br label %bb119
bb119:
  %t449 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l197
  %t450 = call ptr @__olang_scope_alloc_a(ptr %s18, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t449, ptr %t450
  store ptr %t450, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s19
  %t452 = load i64, ptr %l17, !tbaa !24
  store i64 %t452, ptr %l199, !tbaa !24
  %t453 = load ptr, ptr %l16, !tbaa !29
  %t455 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s18, ptr %t453)
  store i64 %t455, ptr %l201
  br label %bb121
bb121:
  %t456 = load i64, ptr %l199, !tbaa !24
  %t457 = load i64, ptr %l201, !tbaa !24
  %t458 = icmp slt i64 %t456, %t457
  %t460 = xor i1 %t458, true
  br i1 %t460, label %bb122, label %bb123
bb122:
  call void @__olang_scope_close(ptr %s19)
  br label %bb149
bb123:
  br label %bb124
bb124:
  %t462 = load ptr, ptr %l16, !tbaa !29
  %t463 = load i64, ptr %l17, !tbaa !24
  %t466 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s18, ptr %s18, ptr %t462, i64 %t463)
  store { i64, ptr } %t466, ptr %l206
  br label %bb125
bb125:
  %t467 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t470 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s18, ptr %s19, ptr %s18, { i64, ptr } %t467, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store { i64, ptr } %t470, ptr %l208
  br label %bb126
bb126:
  %t471 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t472 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s18, ptr %s19, { i64, ptr } %t471)
  store ptr %t472, ptr %l209
  br label %bb127
bb127:
  %t473 = load ptr, ptr %l209, !tbaa !29
  store ptr %t473, ptr %l19, !tbaa !29
  %t474 = load ptr, ptr %l19, !tbaa !29
  %t476 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s19, ptr %t474)
  store i64 %t476, ptr %l211
  br label %bb128
bb128:
  %t477 = load i64, ptr %l211, !tbaa !24
  %t478 = icmp ne i64 %t477, 2
  br i1 %t478, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb130:
  br label %bb131
bb131:
  %t481 = load ptr, ptr %lp4
  %t482 = getelementptr %"compiler/typed:Plan", ptr %t481, i32 0, i32 17
  store ptr %t482, ptr %l214, !tbaa !29
  %t483 = load ptr, ptr %l19, !tbaa !29
  %t485 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s19, ptr %s19, ptr %t483, i64 0)
  store { i64, ptr } %t485, ptr %l217
  br label %bb132
bb132:
  %t486 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s19, i64 10)
  %t487 = extractvalue { i32, i64 } %t486, 1
  %t488 = extractvalue { i32, i64 } %t486, 0
  store i32 %t488, ptr %l219
  %t489 = icmp ne i32 %t488, 0
  br i1 %t489, label %bb134, label %ok.490, !prof !99
ok.490:
  store i64 %t487, ptr %l218
  br label %bb133
bb133:
  %t491 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t492 = load i64, ptr %l218, !tbaa !24
  %t493 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s19, { i64, ptr } %t491, i64 %t492)
  %t494 = extractvalue { i32, i64 } %t493, 1
  %t495 = extractvalue { i32, i64 } %t493, 0
  store i32 %t495, ptr %l221
  %t496 = icmp ne i32 %t495, 0
  br i1 %t496, label %bb137, label %ok.497, !prof !99
ok.497:
  store i64 %t494, ptr %l220
  br label %bb136
bb134:
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb136:
  %t499 = load i64, ptr %l220, !tbaa !24
  store i64 %t499, ptr %l215, !tbaa !24
  br label %bb138
bb137:
  br label %bb135
bb138:
  %t500 = load ptr, ptr %l214, !tbaa !29
  %t501 = load i64, ptr %l215, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t500, i64 %t501)
  br label %bb139
bb139:
  %t502 = load ptr, ptr %lp4
  %t503 = getelementptr %"compiler/typed:Plan", ptr %t502, i32 0, i32 18
  store ptr %t503, ptr %l223, !tbaa !29
  %t504 = load ptr, ptr %l19, !tbaa !29
  %t506 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s19, ptr %s19, ptr %t504, i64 1)
  store { i64, ptr } %t506, ptr %l226
  br label %bb140
bb140:
  %t507 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s19, i64 10)
  %t508 = extractvalue { i32, i64 } %t507, 1
  %t509 = extractvalue { i32, i64 } %t507, 0
  store i32 %t509, ptr %l228
  %t510 = icmp ne i32 %t509, 0
  br i1 %t510, label %bb142, label %ok.511, !prof !99
ok.511:
  store i64 %t508, ptr %l227
  br label %bb141
bb141:
  %t512 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t513 = load i64, ptr %l227, !tbaa !24
  %t514 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s19, { i64, ptr } %t512, i64 %t513)
  %t515 = extractvalue { i32, i64 } %t514, 1
  %t516 = extractvalue { i32, i64 } %t514, 0
  store i32 %t516, ptr %l230
  %t517 = icmp ne i32 %t516, 0
  br i1 %t517, label %bb145, label %ok.518, !prof !99
ok.518:
  store i64 %t515, ptr %l229
  br label %bb144
bb142:
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb144:
  %t520 = load i64, ptr %l229, !tbaa !24
  store i64 %t520, ptr %l224, !tbaa !24
  br label %bb146
bb145:
  br label %bb143
bb146:
  %t521 = load ptr, ptr %l223, !tbaa !29
  %t522 = load i64, ptr %l224, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t521, i64 %t522)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s19)
  br label %bb148
bb148:
  %t523 = load i64, ptr %l17, !tbaa !24
  %t525 = add i64 %t523, 1
  store i64 %t525, ptr %l17, !tbaa !24
  br label %bb120
bb149:
  call void @__olang_scope_close(ptr %s18)
  store %olang.scope zeroinitializer, ptr %s24
  %t527 = load ptr, ptr %l2, !tbaa !29
  %t529 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t527, i64 6)
  store { i64, ptr } %t529, ptr %l235
  br label %bb150
bb150:
  %t530 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t531 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ewordsOf(ptr %s0, ptr %s24, { i64, ptr } %t530)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t531, ptr %l236
  br label %bb151
bb151:
  %t532 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l236
  %t533 = call ptr @__olang_scope_alloc_a(ptr %s24, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t532, ptr %t533
  store ptr %t533, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb152
bb152:
  store %olang.scope zeroinitializer, ptr %s25
  %t535 = load i64, ptr %l21, !tbaa !24
  store i64 %t535, ptr %l238, !tbaa !24
  %t536 = load ptr, ptr %l20, !tbaa !29
  %t538 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s24, ptr %t536)
  store i64 %t538, ptr %l240
  br label %bb153
bb153:
  %t539 = load i64, ptr %l238, !tbaa !24
  %t540 = load i64, ptr %l240, !tbaa !24
  %t541 = icmp slt i64 %t539, %t540
  %t543 = xor i1 %t541, true
  br i1 %t543, label %bb154, label %bb155
bb154:
  call void @__olang_scope_close(ptr %s25)
  br label %bb227
bb155:
  br label %bb156
bb156:
  %t545 = load ptr, ptr %l20, !tbaa !29
  %t546 = load i64, ptr %l21, !tbaa !24
  %t549 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s24, ptr %s24, ptr %t545, i64 %t546)
  store { i64, ptr } %t549, ptr %l245
  br label %bb157
bb157:
  %t550 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t550, ptr %l22, !tbaa !27
  %t551 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t553 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s24, ptr %s25, { i64, ptr } %t551, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) })
  %t554 = extractvalue { i32, i64 } %t553, 1
  %t555 = extractvalue { i32, i64 } %t553, 0
  store i32 %t555, ptr %l249
  %t556 = icmp ne i32 %t555, 0
  br i1 %t556, label %bb159, label %ok.557, !prof !99
ok.557:
  store i64 %t554, ptr %l248
  br label %bb158
bb158:
  %t558 = load i64, ptr %l248, !tbaa !24
  store i64 %t558, ptr %l246, !tbaa !24
  br label %bb161
bb159:
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb161:
  %t560 = load i64, ptr %l246, !tbaa !24
  store i64 %t560, ptr %l23, !tbaa !24
  %t561 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t561, ptr %l252, !tbaa !27
  %t562 = load i64, ptr %l23, !tbaa !24
  store i64 %t562, ptr %l253, !tbaa !24
  %t563 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t564 = extractvalue { i64, ptr } %t563, 0
  store i64 %t564, ptr %l254, !tbaa !24
  %t565 = icmp sge i64 0, 0
  br i1 %t565, label %bb162, label %bb163
bb162:
  %t567 = load i64, ptr %l253, !tbaa !24
  %t568 = icmp sle i64 0, %t567
  br i1 %t568, label %bb164, label %bb165
bb163:
  call void @__olang_check_failed(ptr @olang_loc_a2b2db9c76964d3d_44f19efa61cd8f79)
  unreachable
bb164:
  %t570 = load i64, ptr %l253, !tbaa !24
  %t571 = load i64, ptr %l254, !tbaa !24
  %t572 = icmp sle i64 %t570, %t571
  br i1 %t572, label %bb166, label %bb167
bb165:
  call void @__olang_check_failed(ptr @olang_loc_a2b2db9c76964d3d_44f19efa61cd8f79)
  unreachable
bb166:
  %t574 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = load i64, ptr %l253, !tbaa !24
  %t577 = getelementptr i8, ptr %t575, i64 0
  %t578 = sub i64 %t576, 0
  %t579 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t577, 1
  store { i64, ptr } %t580, ptr %l258, !tbaa !27
  %t581 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s25, i64 10)
  %t582 = extractvalue { i32, i64 } %t581, 1
  %t583 = extractvalue { i32, i64 } %t581, 0
  store i32 %t583, ptr %l260
  %t584 = icmp ne i32 %t583, 0
  br i1 %t584, label %bb169, label %ok.585, !prof !99
ok.585:
  store i64 %t582, ptr %l259
  br label %bb168
bb167:
  call void @__olang_check_failed(ptr @olang_loc_a2b2db9c76964d3d_44f19efa61cd8f79)
  unreachable
bb168:
  %t586 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t587 = load i64, ptr %l259, !tbaa !24
  %t588 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s24, { i64, ptr } %t586, i64 %t587)
  %t589 = extractvalue { i32, i64 } %t588, 1
  %t590 = extractvalue { i32, i64 } %t588, 0
  store i32 %t590, ptr %l262
  %t591 = icmp ne i32 %t590, 0
  br i1 %t591, label %bb172, label %ok.592, !prof !99
ok.592:
  store i64 %t589, ptr %l261
  br label %bb171
bb169:
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb171:
  %t594 = load i64, ptr %l261, !tbaa !24
  store i64 %t594, ptr %l251, !tbaa !24
  br label %bb173
bb172:
  br label %bb170
bb173:
  %t595 = load i64, ptr %l251, !tbaa !24
  store i64 %t595, ptr %l24, !tbaa !24
  %t596 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2ector(ptr %s25, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t596, ptr %l264
  br label %bb174
bb174:
  %t597 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l264
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t597, ptr %l25
  store %olang.scope zeroinitializer, ptr %s28
  %t598 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t598, ptr %l265, !tbaa !27
  %t599 = load i64, ptr %l23, !tbaa !24
  %t601 = add i64 %t599, 1
  store i64 %t601, ptr %l267, !tbaa !24
  %t602 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t605 = extractvalue { i64, ptr } %t602, 0
  store i64 %t605, ptr %l270, !tbaa !24
  %t606 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t607 = extractvalue { i64, ptr } %t606, 0
  store i64 %t607, ptr %l271, !tbaa !24
  %t608 = load i64, ptr %l267, !tbaa !24
  %t609 = icmp sge i64 %t608, 0
  br i1 %t609, label %bb175, label %bb176
bb175:
  %t611 = load i64, ptr %l267, !tbaa !24
  %t612 = load i64, ptr %l270, !tbaa !24
  %t613 = icmp sle i64 %t611, %t612
  br i1 %t613, label %bb177, label %bb178
bb176:
  call void @__olang_check_failed(ptr @olang_loc_db138e9723fb9fe0_9822d1289854fb4c)
  unreachable
bb177:
  %t615 = load i64, ptr %l270, !tbaa !24
  %t616 = load i64, ptr %l271, !tbaa !24
  %t617 = icmp sle i64 %t615, %t616
  br i1 %t617, label %bb179, label %bb180
bb178:
  call void @__olang_check_failed(ptr @olang_loc_db138e9723fb9fe0_9822d1289854fb4c)
  unreachable
bb179:
  %t619 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t620 = load ptr, ptr %t619, !tbaa !27
  %t621 = load i64, ptr %l267, !tbaa !24
  %t622 = load i64, ptr %l270, !tbaa !24
  %t623 = getelementptr i8, ptr %t620, i64 %t621
  %t624 = sub i64 %t622, %t621
  %t625 = insertvalue { i64, ptr } undef, i64 %t624, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t623, 1
  %t628 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s24, ptr %s28, ptr %s28, { i64, ptr } %t626, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store { i64, ptr } %t628, ptr %l276
  br label %bb181
bb180:
  call void @__olang_check_failed(ptr @olang_loc_db138e9723fb9fe0_9822d1289854fb4c)
  unreachable
bb181:
  %t629 = load { i64, ptr }, ptr %l276, !tbaa !27
  store { i64, ptr } %t629, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t630 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t632 = extractvalue { i64, ptr } %t630, 0
  store i64 %t632, ptr %l28, !tbaa !24
  br label %bb182
bb182:
  store %olang.scope zeroinitializer, ptr %s29
  %t634 = load i64, ptr %l27, !tbaa !24
  %t635 = load i64, ptr %l28, !tbaa !24
  %t638 = icmp slt i64 %t634, %t635
  %t640 = xor i1 %t638, true
  br i1 %t640, label %bb183, label %bb184
bb183:
  call void @__olang_scope_close(ptr %s29)
  br label %bb224
bb184:
  br label %bb185
bb185:
  %t642 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t642, ptr %l283, !tbaa !27
  %t643 = load i64, ptr %l27, !tbaa !24
  %t645 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t646 = load ptr, ptr %t645, !tbaa !27
  %t647 = getelementptr { i64, ptr }, ptr %t646, i64 %t643
  %t648 = load { i64, ptr }, ptr %t647, !tbaa !37
  store { i64, ptr } %t648, ptr %l29, !tbaa !27
  %t650 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t652 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s28, ptr %s29, { i64, ptr } %t650, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t652, ptr %l287
  br label %bb186
bb186:
  %t653 = load i1, ptr %l287, !tbaa !21
  br i1 %t653, label %bb187, label %bb188
bb187:
  call void @__olang_scope_close(ptr %s29)
  br label %bb223
bb188:
  br label %bb189
bb189:
  %t654 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t656 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s28, ptr %s29, ptr %s28, { i64, ptr } %t654, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store { i64, ptr } %t656, ptr %l289
  br label %bb190
bb190:
  %t657 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t658 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s28, ptr %s29, { i64, ptr } %t657)
  store ptr %t658, ptr %l290
  br label %bb191
bb191:
  %t659 = load ptr, ptr %l290, !tbaa !29
  store ptr %t659, ptr %l30, !tbaa !29
  %t660 = load ptr, ptr %l30, !tbaa !29
  %t662 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s29, ptr %t660)
  store i64 %t662, ptr %l292
  br label %bb192
bb192:
  %t663 = load i64, ptr %l292, !tbaa !24
  %t664 = icmp slt i64 %t663, 3
  br i1 %t664, label %bb193, label %bb194
bb193:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb194:
  br label %bb195
bb195:
  %t667 = load ptr, ptr %l30, !tbaa !29
  %t669 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s29, ptr %s29, ptr %t667, i64 0)
  store { i64, ptr } %t669, ptr %l297
  br label %bb196
bb196:
  %t670 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s29, i64 10)
  %t671 = extractvalue { i32, i64 } %t670, 1
  %t672 = extractvalue { i32, i64 } %t670, 0
  store i32 %t672, ptr %l299
  %t673 = icmp ne i32 %t672, 0
  br i1 %t673, label %bb198, label %ok.674, !prof !99
ok.674:
  store i64 %t671, ptr %l298
  br label %bb197
bb197:
  %t675 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t676 = load i64, ptr %l298, !tbaa !24
  %t677 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s29, { i64, ptr } %t675, i64 %t676)
  %t678 = extractvalue { i32, i64 } %t677, 1
  %t679 = extractvalue { i32, i64 } %t677, 0
  store i32 %t679, ptr %l301
  %t680 = icmp ne i32 %t679, 0
  br i1 %t680, label %bb201, label %ok.681, !prof !99
ok.681:
  store i64 %t678, ptr %l300
  br label %bb200
bb198:
  br label %bb199
bb199:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb200:
  %t683 = load i64, ptr %l300, !tbaa !24
  store i64 %t683, ptr %l295, !tbaa !24
  br label %bb202
bb201:
  br label %bb199
bb202:
  %t684 = load i64, ptr %l295, !tbaa !24
  store i64 %t684, ptr %l31, !tbaa !24
  %t685 = load ptr, ptr %l30, !tbaa !29
  %t687 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s29, ptr %s29, ptr %t685, i64 1)
  store { i64, ptr } %t687, ptr %l305
  br label %bb203
bb203:
  %t688 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s29, i64 10)
  %t689 = extractvalue { i32, i64 } %t688, 1
  %t690 = extractvalue { i32, i64 } %t688, 0
  store i32 %t690, ptr %l307
  %t691 = icmp ne i32 %t690, 0
  br i1 %t691, label %bb205, label %ok.692, !prof !99
ok.692:
  store i64 %t689, ptr %l306
  br label %bb204
bb204:
  %t693 = load { i64, ptr }, ptr %l305, !tbaa !27
  %t694 = load i64, ptr %l306, !tbaa !24
  %t695 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s29, { i64, ptr } %t693, i64 %t694)
  %t696 = extractvalue { i32, i64 } %t695, 1
  %t697 = extractvalue { i32, i64 } %t695, 0
  store i32 %t697, ptr %l309
  %t698 = icmp ne i32 %t697, 0
  br i1 %t698, label %bb208, label %ok.699, !prof !99
ok.699:
  store i64 %t696, ptr %l308
  br label %bb207
bb205:
  br label %bb206
bb206:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb207:
  %t701 = load i64, ptr %l308, !tbaa !24
  store i64 %t701, ptr %l303, !tbaa !24
  br label %bb209
bb208:
  br label %bb206
bb209:
  %t702 = load i64, ptr %l303, !tbaa !24
  store ptr %l25, ptr %l311, !tbaa !29
  %t703 = load i64, ptr %l31, !tbaa !24
  store i64 %t703, ptr %l312, !tbaa !24
  store i64 %t702, ptr %l313, !tbaa !24
  %t705 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t705, ptr %l315, !tbaa !27
  %t706 = load ptr, ptr %l30, !tbaa !29
  %t708 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s29, ptr %s29, ptr %t706, i64 0)
  store { i64, ptr } %t708, ptr %l317
  br label %bb210
bb210:
  %t709 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t710 = extractvalue { i64, ptr } %t709, 0
  store i64 %t710, ptr %l318, !tbaa !24
  %t711 = load ptr, ptr %l30, !tbaa !29
  %t713 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s29, ptr %s29, ptr %t711, i64 1)
  store { i64, ptr } %t713, ptr %l320
  br label %bb211
bb211:
  %t714 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t715 = extractvalue { i64, ptr } %t714, 0
  %t716 = load i64, ptr %l318, !tbaa !24
  %t718 = add i64 %t716, %t715
  %t720 = add i64 %t718, 2
  store i64 %t720, ptr %l323, !tbaa !24
  %t721 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t724 = extractvalue { i64, ptr } %t721, 0
  store i64 %t724, ptr %l326, !tbaa !24
  %t725 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t726 = extractvalue { i64, ptr } %t725, 0
  store i64 %t726, ptr %l327, !tbaa !24
  %t727 = load i64, ptr %l323, !tbaa !24
  %t728 = icmp sge i64 %t727, 0
  br i1 %t728, label %bb212, label %bb213
bb212:
  %t730 = load i64, ptr %l323, !tbaa !24
  %t731 = load i64, ptr %l326, !tbaa !24
  %t732 = icmp sle i64 %t730, %t731
  br i1 %t732, label %bb214, label %bb215
bb213:
  call void @__olang_check_failed(ptr @olang_loc_850ab3b4cafc30bf_b865ab70d4df5d13)
  unreachable
bb214:
  %t734 = load i64, ptr %l326, !tbaa !24
  %t735 = load i64, ptr %l327, !tbaa !24
  %t736 = icmp sle i64 %t734, %t735
  br i1 %t736, label %bb216, label %bb217
bb215:
  call void @__olang_check_failed(ptr @olang_loc_850ab3b4cafc30bf_b865ab70d4df5d13)
  unreachable
bb216:
  %t738 = getelementptr { i64, ptr }, ptr %l315, i32 0, i32 1
  %t739 = load ptr, ptr %t738, !tbaa !27
  %t740 = load i64, ptr %l323, !tbaa !24
  %t741 = load i64, ptr %l326, !tbaa !24
  %t742 = getelementptr i8, ptr %t739, i64 %t740
  %t743 = sub i64 %t741, %t740
  %t744 = insertvalue { i64, ptr } undef, i64 %t743, 0
  %t745 = insertvalue { i64, ptr } %t744, ptr %t742, 1
  %t747 = call { i32, { i64, [2 x i64] } } @compiler_2ftyped_2eScope_2eOfText(ptr %s28, { i64, ptr } %t745)
  %t748 = extractvalue { i32, { i64, [2 x i64] } } %t747, 1
  %t749 = extractvalue { i32, { i64, [2 x i64] } } %t747, 0
  store i32 %t749, ptr %l333
  %t750 = icmp ne i32 %t749, 0
  br i1 %t750, label %bb219, label %ok.751, !prof !99
ok.751:
  store { i64, [2 x i64] } %t748, ptr %l332
  br label %bb218
bb217:
  call void @__olang_check_failed(ptr @olang_loc_850ab3b4cafc30bf_b865ab70d4df5d13)
  unreachable
bb218:
  %t752 = load { i64, [2 x i64] }, ptr %l332
  store { i64, [2 x i64] } %t752, ptr %l314
  br label %bb220
bb219:
  %t753 = load i32, ptr %l333, !tbaa !23
  %t754 = lshr i32 %t753, 16
  %t755 = and i32 %t753, 65535
  %t756 = icmp eq i32 %t754, 1
  %t757 = select i1 %t756, i32 1, i32 0
  %t758 = icmp eq i32 %t753, 0
  %t759 = shl i32 %t757, 16
  %t760 = or i32 %t759, %t755
  %t761 = select i1 %t758, i32 0, i32 %t760
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t761, ptr %rv
  br label %ret
bb220:
  %t763 = load i64, ptr %l312, !tbaa !24
  %t764 = load i64, ptr %l313, !tbaa !24
  %t765 = load { i64, [2 x i64] }, ptr %l314
  %t766 = call %"compiler/typed:DerivedArg" @compiler_2ftyped_3aDerivedArg_2ector(ptr %s29, i64 %t763, i64 %t764, { i64, [2 x i64] } %t765)
  store %"compiler/typed:DerivedArg" %t766, ptr %l335
  br label %bb221
bb221:
  %t767 = load ptr, ptr %l311, !tbaa !29
  %t768 = load %"compiler/typed:DerivedArg", ptr %l335
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2ePus_Hd9c60b9bc3eb0bc15b58bce924fabf2c(ptr %s25, ptr %t767, %"compiler/typed:DerivedArg" %t768)
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s29)
  br label %bb223
bb223:
  %t769 = load i64, ptr %l27, !tbaa !24
  %t771 = add i64 %t769, 1
  store i64 %t771, ptr %l27, !tbaa !24
  br label %bb182
bb224:
  call void @__olang_scope_close(ptr %s28)
  %t773 = load ptr, ptr %lp4
  %t774 = load i64, ptr %l24, !tbaa !24
  %t776 = trunc i64 %t774 to i32
  %t778 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassDerived(ptr %v2, ptr %s25, ptr %t773, i32 %t776, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t778)
  br label %bb225
bb225:
  call void @__olang_scope_close(ptr %s25)
  br label %bb226
bb226:
  %t782 = load i64, ptr %l21, !tbaa !24
  %t784 = add i64 %t782, 1
  store i64 %t784, ptr %l21, !tbaa !24
  br label %bb152
bb227:
  call void @__olang_scope_close(ptr %s24)
  %t786 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l345, ptr %t786, i64 584, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l345, i64 584, i1 false)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2ftyped_2eScopeText(ptr %v0, { i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l9, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  br label %bb37
bb4:
  %t8 = load { i64, [2 x i64] }, ptr %l0
  %t10 = extractvalue { i64, [2 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t14 = getelementptr { i32 }, ptr %t13, i32 0, i32 0
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l1, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t17 = load i32, ptr %l1, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t23 = call i64 @__olang_fmt_i64(ptr null, i64 %t19)
  %t24 = add i64 %t21, %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  call void @olang_textcopy(ptr %t25, ptr %t20, i64 %t21)
  %t26 = getelementptr i8, ptr %t25, i64 %t21
  %t27 = call i64 @__olang_fmt_i64(ptr %t26, i64 %t19)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t25, 1
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  br label %bb37
bb8:
  %t31 = load { i64, [2 x i64] }, ptr %l0
  %t33 = extractvalue { i64, [2 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 2
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t37 = getelementptr { i64 }, ptr %t36, i32 0, i32 0
  %t38 = load i64, ptr %t37
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t44 = call i64 @__olang_fmt_i64(ptr null, i64 %t40)
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = getelementptr i8, ptr %t46, i64 %t42
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t40)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  br label %bb37
bb12:
  %t52 = load { i64, [2 x i64] }, ptr %l0
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 3
  br i1 %t55, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t57, ptr %l6, !tbaa !27
  br label %bb37
bb16:
  %t59 = load { i64, [2 x i64] }, ptr %l0
  %t61 = extractvalue { i64, [2 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 5
  br i1 %t62, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t64, ptr %l6, !tbaa !27
  br label %bb37
bb20:
  %t66 = load { i64, [2 x i64] }, ptr %l0
  %t68 = extractvalue { i64, [2 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 6
  br i1 %t69, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t71, ptr %l6, !tbaa !27
  br label %bb37
bb24:
  %t73 = load { i64, [2 x i64] }, ptr %l0
  %t75 = extractvalue { i64, [2 x i64] } %t73, 0
  %t76 = icmp eq i64 %t75, 7
  br i1 %t76, label %bb25, label %bb26
bb25:
  %t78 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t79 = getelementptr { i64 }, ptr %t78, i32 0, i32 0
  %t80 = load i64, ptr %t79
  store i64 %t80, ptr %l3, !tbaa !24
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t86 = call i64 @__olang_fmt_i64(ptr null, i64 %t82)
  %t87 = add i64 %t84, %t86
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t83, i64 %t84)
  %t89 = getelementptr i8, ptr %t88, i64 %t84
  %t90 = call i64 @__olang_fmt_i64(ptr %t89, i64 %t82)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t88, 1
  store { i64, ptr } %t92, ptr %l6, !tbaa !27
  br label %bb37
bb28:
  %t94 = load { i64, [2 x i64] }, ptr %l0
  %t96 = extractvalue { i64, [2 x i64] } %t94, 0
  %t97 = icmp eq i64 %t96, 8
  br i1 %t97, label %bb29, label %bb30
bb29:
  %t99 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t100 = getelementptr { i64, i64 }, ptr %t99, i32 0, i32 0
  %t101 = load i64, ptr %t100
  store i64 %t101, ptr %l4, !tbaa !24
  %t103 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t104 = getelementptr { i64, i64 }, ptr %t103, i32 0, i32 1
  %t105 = load i64, ptr %t104
  store i64 %t105, ptr %l5, !tbaa !24
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t107 = load i64, ptr %l4, !tbaa !24
  %t108 = load i64, ptr %l5, !tbaa !24
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t112 = call i64 @__olang_fmt_i64(ptr null, i64 %t107)
  %t113 = add i64 %t110, %t112
  %t114 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t116 = add i64 %t113, %t115
  %t118 = call i64 @__olang_fmt_i64(ptr null, i64 %t108)
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t109, i64 %t110)
  %t121 = getelementptr i8, ptr %t120, i64 %t110
  %t122 = call i64 @__olang_fmt_i64(ptr %t121, i64 %t107)
  %t123 = getelementptr i8, ptr %t121, i64 %t112
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = getelementptr i8, ptr %t123, i64 %t115
  %t125 = call i64 @__olang_fmt_i64(ptr %t124, i64 %t108)
  %t126 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t120, 1
  store { i64, ptr } %t127, ptr %l6, !tbaa !27
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t130 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t130, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @olang_loc_4b5d458aacbb0718_a8ad2bd2a7dc13cc)
  unreachable
bb37:
  %t131 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l47, !tbaa !24
  %t133 = load i64, ptr %l47, !tbaa !24
  %t134 = mul i64 %t133, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t134)
  %t136 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l48, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l47, !tbaa !24
  %t143 = mul i64 %t142, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %t141, i64 %t143, i1 false)
  %t144 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t144, ptr %l6, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t146 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t145, 1
  store { i32, { i64, ptr } } %t146, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2ftyped_2eScope_2eresult(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l43 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t75 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i64, ptr %t55, i64 %t52
  %t57 = load i64, ptr %t56, !tbaa !34
  %t58 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t61 = icmp eq i64 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t69 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %t65)
  store { i64, [2 x i64] } %t69, ptr %l43
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t70 = load { i64, [2 x i64] }, ptr %l43
  store { i64, [2 x i64] } %t70, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb7
bb16:
  store { i64, [2 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [2 x i64] }, ptr %t75, i32 0, i32 0
  store i64 0, ptr %t76
  %t77 = load { i64, [2 x i64] }, ptr %t75
  store { i64, [2 x i64] } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2ftyped_2eViewsMoved(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l46 = alloca i64
  %l50 = alloca i1
  %l52 = alloca { i64, ptr }
  %l55 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t9 = and i64 %t5, %t6
  %t11 = icmp ne i64 %t9, 0
  store i1 %t11, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  store i64 0, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Call", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t24 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t20, i64 %t21)
  store i64 %t24, ptr %l20
  br label %bb7
bb7:
  %t25 = load i64, ptr %l20, !tbaa !24
  store i64 %t25, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb13
bb10:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l2, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l27, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i64, ptr %l27, !tbaa !24
  store i64 %t52, ptr %l24, !tbaa !24
  br label %bb13
bb13:
  %t53 = load i64, ptr %l24, !tbaa !24
  store i64 %t53, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb15, label %bb16
bb15:
  br label %bb26
bb16:
  br label %bb17
bb17:
  %t62 = load i64, ptr %l2, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l7, !tbaa !24
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  store i64 %t73, ptr %l46, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = load i64, ptr %l46, !tbaa !24
  %t76 = shl i64 1, %t75
  %t79 = and i64 %t72, %t76
  %t81 = icmp ne i64 %t79, 0
  br i1 %t81, label %bb18, label %bb19
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Call", ptr %t83, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l52, !tbaa !27
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr ptr, ptr %t90, i64 %t87
  %t92 = load ptr, ptr %t91, !tbaa !39
  %t94 = call i1 @compiler_2ftyped_2eMovedArg(ptr %v0, ptr %t92)
  store i1 %t94, ptr %l55
  br label %bb20
bb19:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb21
bb20:
  %t95 = load i1, ptr %l55, !tbaa !21
  %t96 = xor i1 %t95, true
  store i1 %t96, ptr %l50, !tbaa !21
  br label %bb21
bb21:
  %t98 = load i1, ptr %l50, !tbaa !21
  br i1 %t98, label %bb22, label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l6, !tbaa !24
  br label %bb14
bb26:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eallInert(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t25 = call i1 @compiler_2ftyped_2einert(ptr %v0, ptr %t21)
  store i1 %t25, ptr %l16
  br label %bb5
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eclausesBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t30, i32 0, i32 3
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb12
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Clause", ptr %t39, i32 0, i32 4
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i1 @compiler_2ftyped_2eexprsBreak(ptr %v0, { i64, ptr } %t42, i32 %t43)
  store i1 %t46, ptr %l28
  br label %bb11
bb11:
  %t47 = load i1, ptr %l28, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca %"compiler/typed:BlockInfo"
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l5, !tbaa !29
  %t10 = call %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %s0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
  store %"compiler/typed:BlockInfo" %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load %"compiler/typed:BlockInfo", ptr %l9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ePush_H85e1838377aa8e6b322d82e3edbac596(ptr %v0, ptr %t11, %"compiler/typed:BlockInfo" %t12)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 8
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = sub i64 %t18, 1
  %t21 = trunc i64 %t19 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca %"compiler/typed:SiteInfo"
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l4, !tbaa !29
  %t8 = call %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %s0, i32 %a1, %"compiler/source:Span" %a2)
  store %"compiler/typed:SiteInfo" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"compiler/typed:SiteInfo", ptr %l7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ePush_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %t9, %"compiler/typed:SiteInfo" %t10)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 9
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = sub i64 %t16, 1
  %t19 = trunc i64 %t17 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eInst(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l5 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 1
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l1
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i64, ptr %l2, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3a838910fbaaf0b4_28daeb84482f7128)
  unreachable
bb9:
  %t17 = load i64, ptr %l5, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, [1 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [1 x i64] }
  %t23 = alloca { i64, [1 x i64] }, align 8
  %t54 = alloca { i64, [1 x i64] }, align 8
  %t58 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %t4, !tbaa !23
  %t6 = load i64, ptr %l2, !tbaa !24
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v1, ptr %t1, i32 %t5, i64 %t6)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 5
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t18, i64 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [1 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [1 x i64] }, ptr %t23, i32 0, i32 0
  store i64 2, ptr %t24
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = insertvalue { i32 } undef, i32 %t25, 0
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t23, i32 0, i32 1
  store { i32 } %t26, ptr %t27
  %t28 = load { i64, [1 x i64] }, ptr %t23
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t28, ptr %rv
  br label %ret
bb5:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %t35, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t32, i32 %t36)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %s0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i32, ptr %t47, i64 %t44
  %t49 = load i32, ptr %t48, !tbaa !33
  %t50 = load ptr, ptr %l16, !tbaa !29
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v1, ptr %t50, i32 %t49)
  store i1 %t52, ptr %l26
  br label %bb8
bb8:
  %t53 = load i1, ptr %l26, !tbaa !21
  br i1 %t53, label %bb9, label %bb10
bb9:
  store { i64, [1 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [1 x i64] }, ptr %t54, i32 0, i32 0
  store i64 1, ptr %t55
  %t56 = load { i64, [1 x i64] }, ptr %t54
  store { i64, [1 x i64] } %t56, ptr %l27
  br label %bb11
bb10:
  store { i64, [1 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [1 x i64] }, ptr %t58, i32 0, i32 0
  store i64 0, ptr %t59
  %t60 = load { i64, [1 x i64] }, ptr %t58
  store { i64, [1 x i64] } %t60, ptr %l27
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, [1 x i64] }, ptr %l27
  store { i64, [1 x i64] } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eResultMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i32
  %rv = alloca { i64, [1 x i64] }
  %t18 = alloca { i64, [1 x i64] }, align 8
  %t33 = alloca { i64, [1 x i64] }, align 8
  %t40 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %t4, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v1, ptr %a1, i32 %t5, i64 %a2)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t16 = icmp eq i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store { i64, [1 x i64] } zeroinitializer, ptr %t18
  %t19 = getelementptr { i64, [1 x i64] }, ptr %t18, i32 0, i32 0
  store i64 5, ptr %t19
  %t20 = load { i64, [1 x i64] }, ptr %t18
  store { i64, [1 x i64] } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l18
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [1 x i64] }, ptr %t33, i32 0, i32 0
  store i64 2, ptr %t34
  %t35 = load i32, ptr %l18, !tbaa !23
  %t36 = insertvalue { i32 } undef, i32 %t35, 0
  %t37 = getelementptr { i64, [1 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [1 x i64] }, ptr %t33
  store { i64, [1 x i64] } %t38, ptr %rv
  br label %ret
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [1 x i64] }, ptr %t40, i32 0, i32 0
  store i64 1, ptr %t41
  %t42 = load { i64, [1 x i64] }, ptr %t40
  store { i64, [1 x i64] } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l61 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  br label %bb1
bb1:
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Landings", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l20, !tbaa !24
  store i64 %t39, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l17, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Landings", ptr %t59, i32 0, i32 11
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Landings", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l41, !tbaa !27
  %t66 = load i64, ptr %l7, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i64, ptr %t69, i64 %t66
  %t71 = load i64, ptr %t70, !tbaa !34
  %t74 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t61, i64 %t71)
  store i1 %t74, ptr %l44
  br label %bb12
bb12:
  %t75 = load i1, ptr %l44, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb13, label %bb14
bb13:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2elastAfter(ptr %v0, ptr %t78, i64 %t79)
  store i1 %t82, ptr %l49
  br label %bb15
bb14:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb16
bb15:
  %t83 = load i1, ptr %l49, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t86 = load i1, ptr %l46, !tbaa !21
  br i1 %t86, label %bb17, label %bb18
bb17:
  br label %bb24
bb18:
  br label %bb19
bb19:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Landings", ptr %t87, i32 0, i32 3
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  store { i64, ptr } %t90, ptr %l52, !tbaa !27
  %t91 = load i64, ptr %l7, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i1, ptr %t94, i64 %t91
  store i1 true, ptr %t95, !tbaa !31
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Landings", ptr %t96, i32 0, i32 4
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l55, !tbaa !27
  %t100 = load i64, ptr %l7, !tbaa !24
  store i64 %t100, ptr %l56, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Landings", ptr %t101, i32 0, i32 12
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Landings", ptr %t104, i32 0, i32 0
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %l61, !tbaa !27
  %t108 = load i64, ptr %l7, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i64, ptr %t111, i64 %t108
  %t113 = load i64, ptr %t112, !tbaa !34
  %t116 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t103, i64 %t113)
  %t117 = extractvalue { i32, i64 } %t116, 1
  %t118 = extractvalue { i32, i64 } %t116, 0
  store i32 %t118, ptr %l65
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb21, label %ok.120, !prof !99
ok.120:
  store i64 %t117, ptr %l64
  br label %bb20
bb20:
  %t121 = load i64, ptr %l64, !tbaa !24
  store i64 %t121, ptr %l57, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l57, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l57, !tbaa !24
  %t123 = load i64, ptr %l56, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i64, ptr %t125, i64 %t123
  store i64 %t122, ptr %t126, !tbaa !34
  br label %bb24
bb24:
  %t127 = load i64, ptr %l6, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l6, !tbaa !24
  br label %bb8
bb25:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/typed:landLoop"
  %l9 = alloca i64
  %l17 = alloca %"compiler/typed:landLoop"
  %l24 = alloca %"compiler/typed:landLoop"
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Landings", ptr %t6, i32 0, i32 8
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eLen_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l9
  br label %bb4
bb4:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = sub i64 %t11, 1
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Landings", ptr %t20, i32 0, i32 8
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call %"compiler/typed:landLoop" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eAt_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %s3, ptr %t22, i64 %t23)
  store %"compiler/typed:landLoop" %t26, ptr %l17
  br label %bb9
bb9:
  %t27 = getelementptr %"compiler/typed:landLoop", ptr %l17, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t32 = icmp ne i32 %t28, %a2
  br i1 %t32, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Landings", ptr %t34, i32 0, i32 8
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = call %"compiler/typed:landLoop" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eAt_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  store %"compiler/typed:landLoop" %t40, ptr %l24
  br label %bb13
bb13:
  %t41 = load %"compiler/typed:landLoop", ptr %l24
  store %"compiler/typed:landLoop" %t41, ptr %l4
  %t44 = trunc i64 0 to i32
  %t45 = icmp eq i32 %a1, %t44
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t47 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 2
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Landings", ptr %t49, i32 0, i32 6
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  call void @compiler_2ftyped_2eorInto(ptr %v0, ptr %v0, { i64, ptr } %t48, { i64, ptr } %t52)
  br label %bb16
bb15:
  %t55 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 3
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Landings", ptr %t57, i32 0, i32 6
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  call void @compiler_2ftyped_2eorInto(ptr %v0, ptr %v0, { i64, ptr } %t56, { i64, ptr } %t60)
  br label %bb17
bb16:
  %t63 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 4
  store i1 true, ptr %t63, !tbaa !21
  br label %bb18
bb17:
  %t64 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 5
  store i1 true, ptr %t64, !tbaa !21
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Landings", ptr %t65, i32 0, i32 8
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load %"compiler/typed:landLoop", ptr %l4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eSetAt_H5ab2aabe0ae7951e8bb06fbe4ca7219a(ptr %v0, ptr %v0, ptr %t67, i64 %t68, %"compiler/typed:landLoop" %t69)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb20:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = sub i64 %t73, 1
  store i64 %t75, ptr %l3, !tbaa !24
  br label %bb5
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Landings", ptr %t77, i32 0, i32 7
  store i1 true, ptr %t79, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erenewed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Landings", ptr %t6, i32 0, i32 9
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  store i1 %t11, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  store i64 0, ptr %l2, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Landings", ptr %t14, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb12
bb9:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l23, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb11
bb11:
  %t47 = load i64, ptr %l23, !tbaa !24
  store i64 %t47, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l20, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l7, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Landings", ptr %t67, i32 0, i32 0
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i64, ptr %t74, i64 %t71
  %t76 = load i64, ptr %t75, !tbaa !34
  %t80 = icmp eq i64 %t76, %a1
  br i1 %t80, label %bb17, label %bb18
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Landings", ptr %t82, i32 0, i32 6
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  store { i64, ptr } %t85, ptr %l48, !tbaa !27
  %t86 = load i64, ptr %l7, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i1, ptr %t89, i64 %t86
  store i1 false, ptr %t90, !tbaa !31
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb13
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2ecopyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i1
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l49 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l56 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Make", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !range !{i32 0, i32 5}
  %t6 = trunc i64 4 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Make", ptr %t11, i32 0, i32 2
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp ne i64 %t16, 1
  store i1 %t18, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Make", ptr %t21, i32 0, i32 4
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = icmp slt i32 %t24, 0
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Make", ptr %t29, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l18, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 0
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = call i64 @compiler_2ftyped_2ewholeLocal(ptr %v1, ptr %t36)
  store i64 %t38, ptr %l20
  br label %bb10
bb10:
  %t39 = load i64, ptr %l20, !tbaa !24
  store i64 %t39, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/typed:LastUses", ptr %t45, i32 0, i32 0
  %t48 = load i64, ptr %t47, !tbaa !24
  %t51 = icmp sge i64 %t44, %t48
  store i1 %t51, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l23, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %ret
bb15:
  br label %bb16
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:LastUses", ptr %t54, i32 0, i32 6
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Make", ptr %t57, i32 0, i32 4
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = sext i32 %t60 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t56, i64 %t62)
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:LastUses", ptr %t65, i32 0, i32 7
  %t68 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t67, i64 %t68)
  br label %bb18
bb18:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/typed:LastUses", ptr %t71, i32 0, i32 5
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = icmp sgt i64 %t74, 0
  br i1 %t76, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb24
bb20:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LastUses", ptr %t78, i32 0, i32 2
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = load i64, ptr %l2, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 %t82
  %t87 = load i64, ptr %t86, !tbaa !34
  %t89 = icmp sge i64 %t87, 0
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/typed:LastUses", ptr %t91, i32 0, i32 4
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:LastUses", ptr %t95, i32 0, i32 2
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l49, !tbaa !27
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i64, ptr %t102, i64 %t99
  %t104 = load i64, ptr %t103, !tbaa !34
  %t107 = icmp sgt i64 %t94, %t104
  store i1 %t107, ptr %l45, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t109 = load i1, ptr %l45, !tbaa !21
  store i1 %t109, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t110 = load i1, ptr %l39, !tbaa !21
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/typed:LastUses", ptr %t111, i32 0, i32 8
  store ptr %t113, ptr %l54, !tbaa !29
  br i1 %t110, label %bb25, label %bb26
bb25:
  store i64 -1, ptr %l56, !tbaa !24
  br label %bb27
bb26:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/typed:LastUses", ptr %t116, i32 0, i32 3
  %t119 = load i64, ptr %t118, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l56, !tbaa !24
  br label %bb27
bb27:
  %t123 = load ptr, ptr %l54, !tbaa !29
  %t124 = load i64, ptr %l56, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t123, i64 %t124)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l36 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  store i64 %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t16 = load ptr, ptr %l15, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l15, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 8}
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l16, !tbaa !21
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l4
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l5, !tbaa !23
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l6, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:LocalUses", ptr %t43, i32 0, i32 4
  %t46 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t45, i64 %t46, i1 true)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %ret
bb11:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = icmp sge i64 %t49, 0
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb14:
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 8}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l32, !tbaa !21
  %t62 = xor i1 %t61, true
  store i1 %t62, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l30, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:LocalUses", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l38, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t69)
  store i32 %t71, ptr %l40
  br label %bb19
bb18:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb21
bb19:
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = call ptr @__olang_scope_or(ptr %v3, ptr %t72)
  %t74 = ptrtoint ptr %t73 to i64
  %t76 = inttoptr i64 %t74 to ptr
  %t77 = load ptr, ptr %l38, !tbaa !29
  %t78 = load i32, ptr %l40, !tbaa !23
  %t79 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t76, ptr %t77, i32 %t78)
  store i1 %t79, ptr %l42
  br label %bb20
bb20:
  %t80 = load i1, ptr %l42, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t83 = load i1, ptr %l36, !tbaa !21
  br i1 %t83, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t88 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %v3, ptr %t84, ptr %t85)
  store i1 %t88, ptr %l47
  br label %bb24
bb23:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb25
bb24:
  %t89 = load i1, ptr %l47, !tbaa !21
  %t90 = xor i1 %t89, true
  store i1 %t90, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t92 = load i1, ptr %l44, !tbaa !21
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:LocalUses", ptr %t93, i32 0, i32 11
  %t96 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t95, i64 %t96)
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/typed:LocalUses", ptr %t99, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t101, ptr %a2)
  br label %bb29
bb29:
  br label %ret
bb30:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t105, ptr %t106, i1 false)
  br label %bb31
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eborrow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, { i64, [1 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, [1 x i64] }
  %l5 = alloca ptr
  %l8 = alloca i64
  %l22 = alloca i1
  %t34 = alloca { i64, [1 x i64] }, align 8
  %t51 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [1 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = call ptr @__olang_scope_or(ptr %v2, ptr %t6)
  %t8 = ptrtoint ptr %t7 to i64
  %t10 = inttoptr i64 %t8 to ptr
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t13 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t10, ptr %t11, i32 %a2)
  store i64 %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t15 = load i64, ptr %l8, !tbaa !24
  %t17 = and i64 %t15, %t14
  %t19 = icmp ne i64 %t17, 0
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t21, ptr %t22, i1 true)
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t25 = load { i64, [1 x i64] }, ptr %l3
  %t27 = extractvalue { i64, [1 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 1
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 0
  store i64 5, ptr %t35
  %t36 = load { i64, [1 x i64] }, ptr %t34
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2euse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t32, ptr %t33, { i64, [1 x i64] } %t36, i1 true)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %ret
bb9:
  %t40 = load { i64, [1 x i64] }, ptr %l3
  %t42 = extractvalue { i64, [1 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 3
  br i1 %t43, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb12
bb11:
  %t45 = load { i64, [1 x i64] }, ptr %l3
  %t47 = extractvalue { i64, [1 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 2
  store i1 %t48, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l22, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  store { i64, [1 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [1 x i64] }, ptr %t51, i32 0, i32 0
  store i64 5, ptr %t52
  %t53 = load { i64, [1 x i64] }, ptr %t51
  store { i64, [1 x i64] } %t53, ptr %l3
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t57 = load { i64, [1 x i64] }, ptr %l3
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2euse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t55, ptr %t56, { i64, [1 x i64] } %t57, i1 true)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2efnVal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l21 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %t44 = alloca { i64, [1 x i64] }, align 8
  %t72 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t30, ptr %l21, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Capture", ptr %t36, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [1 x i64] }, ptr %t44, i32 0, i32 0
  store i64 5, ptr %t45
  %t46 = load { i64, [1 x i64] }, ptr %t44
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t38, ptr %t42, { i64, [1 x i64] } %t46)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  br label %bb27
bb13:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 3}
  %t61 = icmp eq i64 %t59, 2
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { i32, ptr, i32 }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [1 x i64] }, ptr %t72, i32 0, i32 0
  store i64 5, ptr %t73
  %t74 = load { i64, [1 x i64] }, ptr %t72
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t69, ptr %t70, { i64, [1 x i64] } %t74)
  br label %bb19
bb19:
  br label %bb27
bb20:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load ptr, ptr %l41, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 3}
  %t85 = icmp eq i64 %t83, 0
  store i1 %t85, ptr %l42, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l42, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_c889b00966965144_dcfe1455a200f620)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2egive(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t3, i64 %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:LocalUses", ptr %t7, i32 0, i32 35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t9, i64 %a2)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:LocalUses", ptr %t13, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t15, i64 %a3)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:LocalUses", ptr %t19, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t21, i1 %a4)
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2emade(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, [1 x i64] } %a3, i64 %a4, i64 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l22 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca i32
  %l34 = alloca i1
  %l44 = alloca i64
  %l50 = alloca ptr
  %l53 = alloca i1
  %l75 = alloca ptr
  %l78 = alloca i64
  %l82 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ftyped_2econverted(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l16, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t5 = load ptr, ptr %l7, !tbaa !29
  store ptr %t5, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t6 = load ptr, ptr %l17, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l17, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 6
  store i1 %t12, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l18, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l8
  %t22 = load ptr, ptr %l7, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l9, !tbaa !23
  %t28 = load ptr, ptr %l7, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l10, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/typed:LocalUses", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l30, !tbaa !29
  %t38 = load ptr, ptr %l7, !tbaa !29
  %t40 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t38)
  store i32 %t40, ptr %l32
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l30, !tbaa !29
  %t42 = call ptr @__olang_scope_or(ptr %v2, ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  %t45 = inttoptr i64 %t43 to ptr
  %t46 = load ptr, ptr %l30, !tbaa !29
  %t47 = load i32, ptr %l32, !tbaa !23
  %t48 = call i1 @compiler_2ftyped_2emayHold(ptr %t45, ptr %t46, i32 %t47, i64 0)
  store i1 %t48, ptr %l34
  br label %bb7
bb7:
  %t49 = load i1, ptr %l34, !tbaa !21
  %t50 = xor i1 %t49, true
  store i1 %t50, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t52 = load i1, ptr %l22, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t53 = load ptr, ptr %l7, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l11
  %t59 = load ptr, ptr %l7, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l12, !tbaa !23
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l13, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/typed:LocalUses", ptr %t71, i32 0, i32 28
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t73)
  store i64 %t75, ptr %l44
  br label %bb12
bb12:
  %t76 = load i64, ptr %l44, !tbaa !24
  store i64 %t76, ptr %l14, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:LocalUses", ptr %t77, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t79, i1 false)
  br label %bb13
bb13:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:LocalUses", ptr %t81, i32 0, i32 29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t83, i1 false)
  br label %bb14
bb14:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:LocalUses", ptr %t85, i32 0, i32 30
  store ptr %t87, ptr %l50, !tbaa !29
  %t88 = load i64, ptr %l4, !tbaa !24
  %t90 = icmp slt i64 %t88, 0
  br i1 %t90, label %bb15, label %bb16
bb15:
  %t94 = xor i1 %a6, true
  store i1 %t94, ptr %l53, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb17
bb17:
  %t96 = load ptr, ptr %l50, !tbaa !29
  %t97 = load i1, ptr %l53, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t96, i1 %t97)
  br label %bb18
bb18:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/typed:LocalUses", ptr %t98, i32 0, i32 31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t100, i1 false)
  br label %bb19
bb19:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/typed:LocalUses", ptr %t102, i32 0, i32 32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t104, i1 false)
  br label %bb20
bb20:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/typed:LocalUses", ptr %t106, i32 0, i32 33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t108, i1 false)
  br label %bb21
bb21:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/typed:LocalUses", ptr %t110, i32 0, i32 44
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/typed:LocalUses", ptr %t113, i32 0, i32 43
  %t116 = load i64, ptr %t115, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t112, i64 %t116)
  br label %bb22
bb22:
  %t119 = load i64, ptr %l4, !tbaa !24
  %t121 = icmp sge i64 %t119, 0
  br i1 %t121, label %bb23, label %bb24
bb23:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i64, ptr %l14, !tbaa !24
  %t125 = load i64, ptr %l4, !tbaa !24
  %t126 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2egive(ptr %v0, ptr %t123, i64 %t124, i64 %t125, i64 %t126, i1 true)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t131 = load { i64, [1 x i64] }, ptr %l3
  %t133 = extractvalue { i64, [1 x i64] } %t131, 0
  %t134 = icmp eq i64 %t133, 0
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb27, label %bb28
bb27:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l75, !tbaa !29
  %t139 = load i64, ptr %l2, !tbaa !24
  %t141 = icmp sge i64 %t139, 0
  br i1 %t141, label %bb29, label %bb30
bb28:
  br label %bb36
bb29:
  %t143 = load i64, ptr %l2, !tbaa !24
  store i64 %t143, ptr %l78, !tbaa !24
  br label %bb34
bb30:
  %t145 = load { i64, [1 x i64] }, ptr %l3
  %t147 = extractvalue { i64, [1 x i64] } %t145, 0
  %t148 = icmp eq i64 %t147, 3
  br i1 %t148, label %bb31, label %bb32
bb31:
  %t150 = load i64, ptr @G_2ecompiler_2ftyped_2eHanded, !tbaa !24
  store i64 %t150, ptr %l82, !tbaa !24
  br label %bb33
bb32:
  %t152 = load i64, ptr @G_2ecompiler_2ftyped_2eElsewhere, !tbaa !24
  store i64 %t152, ptr %l82, !tbaa !24
  br label %bb33
bb33:
  %t154 = load i64, ptr %l82, !tbaa !24
  store i64 %t154, ptr %l78, !tbaa !24
  br label %bb34
bb34:
  %t155 = load i64, ptr %l14, !tbaa !24
  %t156 = load i64, ptr %l4, !tbaa !24
  %t157 = load i64, ptr %l5, !tbaa !24
  %t158 = load ptr, ptr %l75, !tbaa !29
  %t159 = load i64, ptr %l78, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elink(ptr %v0, ptr %t158, i64 %t159, i64 %t155, i1 false, i64 %t156, i64 %t157)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i64, ptr %l14, !tbaa !24
  %t167 = getelementptr %"compiler/typed:LocalUses", ptr %t163, i32 0, i32 46
  store i64 %t164, ptr %t167, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eoutlasts(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:LocalUses", ptr %t5, i32 0, i32 44
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t7, i64 %t8)
  store i64 %t11, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:LocalUses", ptr %t12, i32 0, i32 45
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = load i64, ptr %l8, !tbaa !24
  %t18 = icmp sle i64 %t16, %t15
  store i1 %t18, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l4, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca i1
  %t48 = alloca { i64, [1 x i64] }, align 8
  %t102 = alloca { i64, [1 x i64] }, align 8
  %t126 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb45
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 4
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Elem", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t35, ptr %t39)
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Elem", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [1 x i64] }, ptr %t48, i32 0, i32 0
  store i64 0, ptr %t49
  %t50 = load { i64, [1 x i64] }, ptr %t48
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t42, ptr %t46, { i64, [1 x i64] } %t50)
  br label %bb14
bb14:
  br label %bb45
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 8}
  %t61 = icmp eq i64 %t59, 5
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t62 = load i1, ptr %l30, !tbaa !21
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Payload", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t69, ptr %t73)
  br label %bb21
bb21:
  br label %bb45
bb22:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t77 = load ptr, ptr %l38, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb23, label %bb24
bb23:
  %t80 = load ptr, ptr %l38, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 2
  store i1 %t83, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t84 = load i1, ptr %l39, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l5, !tbaa !29
  %t95 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store i64 %t95, ptr %l46
  br label %bb28
bb28:
  %t96 = load i64, ptr %l46, !tbaa !24
  %t97 = icmp slt i64 %t96, 0
  br i1 %t97, label %bb29, label %bb30
bb29:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l5, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [1 x i64] }, ptr %t102, i32 0, i32 0
  store i64 0, ptr %t103
  %t104 = load { i64, [1 x i64] }, ptr %t102
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t99, ptr %t100, { i64, [1 x i64] } %t104)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb45
bb33:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t109 = load ptr, ptr %l52, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 8}
  %t115 = icmp eq i64 %t113, 6
  store i1 %t115, ptr %l53, !tbaa !21
  br label %bb35
bb35:
  %t116 = load i1, ptr %l53, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [1 x i64] }, ptr %t126, i32 0, i32 0
  store i64 0, ptr %t127
  %t128 = load { i64, [1 x i64] }, ptr %t126
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t123, ptr %t124, { i64, [1 x i64] } %t128)
  br label %bb39
bb39:
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_572ff0c594eb7d28_3eb561bfca5d9eb4)
  unreachable
bb45:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i1
  %l53 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb39
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t39 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store i64 %t39, ptr %l24
  br label %bb12
bb12:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  br label %bb39
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l25, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 8}
  %t48 = icmp eq i64 %t46, 4
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l26, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Elem", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  store i64 %t63, ptr %l34
  br label %bb19
bb19:
  %t64 = load i64, ptr %l34, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  br label %bb39
bb20:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l36, !tbaa !21
  br label %bb22
bb22:
  %t73 = load i1, ptr %l36, !tbaa !21
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Payload", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  store i64 %t87, ptr %l44
  br label %bb26
bb26:
  %t88 = load i64, ptr %l44, !tbaa !24
  store i64 %t88, ptr %l7, !tbaa !24
  br label %bb39
bb27:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t90 = load ptr, ptr %l45, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t93 = load ptr, ptr %l45, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 2
  store i1 %t96, ptr %l46, !tbaa !21
  br label %bb29
bb29:
  %t97 = load i1, ptr %l46, !tbaa !21
  br i1 %t97, label %bb30, label %bb31
bb30:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t108 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  store i64 %t108, ptr %l53
  br label %bb33
bb33:
  %t109 = load i64, ptr %l53, !tbaa !24
  store i64 %t109, ptr %l7, !tbaa !24
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_6333e3fa20d2f5d8_bcafed7a04540454)
  unreachable
bb39:
  %t110 = load i64, ptr %l7, !tbaa !24
  store i64 %t110, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2euse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i32
  %l14 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l29 = alloca i1
  %l31 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i1
  %l62 = alloca i1
  %l74 = alloca i1
  %l111 = alloca i64
  %l113 = alloca i1
  %l118 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [1 x i64] } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  store i64 %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load i64, ptr %l14, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t16 = load ptr, ptr %l17, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb4:
  br label %bb17
bb5:
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 8}
  %t22 = icmp eq i64 %t20, 6
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l18, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l5, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t30, ptr %t31, { i64, [1 x i64] } %t33)
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4f6de7c744c3571c_6f8dca6bf99a5cd8)
  unreachable
bb16:
  br label %ret
bb17:
  %t37 = load i1, ptr %l3, !tbaa !21
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/typed:LocalUses", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l31, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/typed:LocalUses", ptr %t45, i32 0, i32 48
  %t48 = load i32, ptr %t47, !tbaa !23
  %t49 = load ptr, ptr %l31, !tbaa !29
  %t50 = call ptr @__olang_scope_or(ptr %v2, ptr %t49)
  %t51 = ptrtoint ptr %t50 to i64
  %t53 = inttoptr i64 %t51 to ptr
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t56 = call i1 @compiler_2ftyped_2emayHold(ptr %t53, ptr %t54, i32 %t48, i64 0)
  store i1 %t56, ptr %l35
  br label %bb20
bb19:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb21
bb20:
  %t57 = load i1, ptr %l35, !tbaa !21
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t58 = load i1, ptr %l29, !tbaa !21
  store i1 %t58, ptr %l6, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:LocalUses", ptr %t59, i32 0, i32 25
  %t62 = load i64, ptr %t61, !tbaa !24
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb22, label %bb23
bb22:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/typed:LocalUses", ptr %t66, i32 0, i32 28
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t68, i64 %t69)
  store i1 %t72, ptr %l42
  br label %bb24
bb23:
  br label %bb42
bb24:
  %t73 = load i1, ptr %l42, !tbaa !21
  store i1 %t73, ptr %l7, !tbaa !21
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:LocalUses", ptr %t74, i32 0, i32 29
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t76, i64 %t77)
  store i1 %t80, ptr %l46
  br label %bb25
bb25:
  %t81 = load i1, ptr %l46, !tbaa !21
  store i1 %t81, ptr %l8, !tbaa !21
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eescape(ptr %v0, ptr %t82, i64 %t83)
  br label %bb26
bb26:
  %t86 = load i1, ptr %l3, !tbaa !21
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb27, label %bb28
bb27:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/typed:LocalUses", ptr %t90, i32 0, i32 28
  %t93 = load i64, ptr %l4, !tbaa !24
  %t94 = load i1, ptr %l7, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t92, i64 %t93, i1 %t94)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t98 = load i1, ptr %l3, !tbaa !21
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/typed:LocalUses", ptr %t102, i32 0, i32 29
  %t105 = load i64, ptr %l4, !tbaa !24
  %t106 = load i1, ptr %l8, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t104, i64 %t105, i1 %t106)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t110 = load i1, ptr %l6, !tbaa !21
  br i1 %t110, label %bb35, label %bb36
bb35:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/typed:LocalUses", ptr %t112, i32 0, i32 49
  %t115 = load i1, ptr %t114, !tbaa !21
  %t117 = xor i1 %t115, true
  store i1 %t117, ptr %l62, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb37
bb37:
  %t119 = load i1, ptr %l62, !tbaa !21
  br i1 %t119, label %bb38, label %bb39
bb38:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/typed:LocalUses", ptr %t120, i32 0, i32 30
  %t123 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t122, i64 %t123, i1 true)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %ret
bb42:
  %t126 = load { i64, [1 x i64] }, ptr %l2
  %t128 = extractvalue { i64, [1 x i64] } %t126, 0
  %t129 = icmp eq i64 %t128, 0
  br i1 %t129, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb102
bb46:
  %t131 = load { i64, [1 x i64] }, ptr %l2
  %t133 = extractvalue { i64, [1 x i64] } %t131, 0
  %t134 = icmp eq i64 %t133, 1
  br i1 %t134, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb57
bb49:
  %t136 = load i1, ptr %l6, !tbaa !21
  br i1 %t136, label %bb50, label %bb51
bb50:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/typed:LocalUses", ptr %t138, i32 0, i32 49
  %t141 = load i1, ptr %t140, !tbaa !21
  %t143 = xor i1 %t141, true
  store i1 %t143, ptr %l74, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb52
bb52:
  %t145 = load i1, ptr %l74, !tbaa !21
  br i1 %t145, label %bb53, label %bb54
bb53:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/typed:LocalUses", ptr %t146, i32 0, i32 30
  %t149 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t148, i64 %t149, i1 true)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  br label %bb102
bb57:
  %t152 = load { i64, [1 x i64] }, ptr %l2
  %t154 = extractvalue { i64, [1 x i64] } %t152, 0
  %t155 = icmp eq i64 %t154, 2
  br i1 %t155, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb69
bb60:
  %t157 = load i1, ptr %l3, !tbaa !21
  br i1 %t157, label %bb61, label %bb62
bb61:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eescape(ptr %v0, ptr %t159, i64 %t160)
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  %t163 = load i1, ptr %l6, !tbaa !21
  br i1 %t163, label %bb65, label %bb66
bb65:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecopied(ptr %v0, ptr %t165, i64 %t166)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  br label %bb102
bb69:
  %t169 = load { i64, [1 x i64] }, ptr %l2
  %t171 = extractvalue { i64, [1 x i64] } %t169, 0
  %t172 = icmp eq i64 %t171, 3
  br i1 %t172, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb82
bb72:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/typed:LocalUses", ptr %t174, i32 0, i32 8
  %t177 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t176, i64 %t177, i1 true)
  br label %bb73
bb73:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/typed:LocalUses", ptr %t180, i32 0, i32 27
  %t183 = load i1, ptr %t182, !tbaa !21
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb74, label %bb75
bb74:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/typed:LocalUses", ptr %t187, i32 0, i32 33
  %t190 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t189, i64 %t190, i1 true)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  %t193 = load i1, ptr %l6, !tbaa !21
  br i1 %t193, label %bb78, label %bb79
bb78:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/typed:LocalUses", ptr %t195, i32 0, i32 32
  %t198 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t197, i64 %t198, i1 true)
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb81
bb81:
  br label %bb102
bb82:
  %t201 = load { i64, [1 x i64] }, ptr %l2
  %t203 = extractvalue { i64, [1 x i64] } %t201, 0
  %t204 = icmp eq i64 %t203, 4
  br i1 %t204, label %bb83, label %bb84
bb83:
  %t206 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t207 = getelementptr { i32 }, ptr %t206, i32 0, i32 0
  %t208 = load i32, ptr %t207
  store i32 %t208, ptr %l9, !tbaa !23
  br label %bb85
bb84:
  br label %bb96
bb85:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/typed:LocalUses", ptr %t210, i32 0, i32 9
  %t213 = load i32, ptr %l9, !tbaa !23
  %t215 = sext i32 %t213 to i64
  %t218 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t212, i64 %t215)
  store i64 %t218, ptr %l111
  br label %bb86
bb86:
  %t219 = load i64, ptr %l111, !tbaa !24
  %t220 = icmp sge i64 %t219, 0
  br i1 %t220, label %bb87, label %bb88
bb87:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/typed:LocalUses", ptr %t222, i32 0, i32 9
  %t225 = load i32, ptr %l9, !tbaa !23
  %t227 = sext i32 %t225 to i64
  %t230 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t224, i64 %t227)
  store i64 %t230, ptr %l118
  br label %bb89
bb88:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb90
bb89:
  %t231 = load i64, ptr %l4, !tbaa !24
  %t232 = load i64, ptr %l118, !tbaa !24
  %t234 = icmp ne i64 %t232, %t231
  store i1 %t234, ptr %l113, !tbaa !21
  br label %bb90
bb90:
  %t236 = load i1, ptr %l113, !tbaa !21
  br i1 %t236, label %bb91, label %bb92
bb91:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eescape(ptr %v0, ptr %t237, i64 %t238)
  br label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb94
bb94:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/typed:LocalUses", ptr %t241, i32 0, i32 9
  %t244 = load i32, ptr %l9, !tbaa !23
  %t246 = sext i32 %t244 to i64
  %t247 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t243, i64 %t246, i64 %t247)
  br label %bb95
bb95:
  br label %bb102
bb96:
  %t251 = load { i64, [1 x i64] }, ptr %l2
  %t253 = extractvalue { i64, [1 x i64] } %t251, 0
  %t254 = icmp eq i64 %t253, 5
  br i1 %t254, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eescape(ptr %v0, ptr %t256, i64 %t257)
  br label %bb100
bb100:
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_2bdab9da3f4d_ded05e4518f32fa9)
  unreachable
bb102:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l15 = alloca i1
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l8, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t15, ptr %t16)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %ret
bb6:
  %t21 = xor i1 %a2, true
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %v2, ptr %t23, ptr %t24)
  store i1 %t27, ptr %l18
  br label %bb9
bb8:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb10
bb9:
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:LocalUses", ptr %t30, i32 0, i32 3
  %t33 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t32, i64 %t33, i1 true)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %ret
bb14:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/typed:LocalUses", ptr %t36, i32 0, i32 2
  %t39 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t38, i64 %t39, i1 true)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eExprWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2c, ptr %a2e) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { ptr, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca i1
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  %pf2 = insertvalue { ptr, ptr } undef, ptr %a2c, 0
  %pg2 = insertvalue { ptr, ptr } %pf2, ptr %a2e, 1
  store { ptr, ptr } %pg2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eExprAt(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t11)
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = getelementptr i8, ptr %t17, i64 %t13
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t11)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t21, 1
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t25 = load ptr, ptr %l16, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 2
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l17, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t35, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l4
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l5, !tbaa !23
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l6, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t53, i32 0, i32 3
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l7, !tbaa !23
  br label %bb9
bb8:
  br label %bb16
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  store i32 %t58, ptr %l28, !tbaa !23
  %t59 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t60 = load i32, ptr %t59, !tbaa !23
  store i32 %t60, ptr %l29, !tbaa !23
  %t61 = load i32, ptr %l5, !tbaa !23
  %t62 = load { ptr, ptr }, ptr %l2
  %t65 = extractvalue { ptr, ptr } %t62, 0
  %t66 = extractvalue { ptr, ptr } %t62, 1
  %t67 = call { i32, { i64, ptr } } @compiler_2ftyped_2etypeWord(ptr %v2, ptr %s3, i32 %t61, ptr %t65, ptr %t66)
  %t68 = extractvalue { i32, { i64, ptr } } %t67, 1
  %t69 = extractvalue { i32, { i64, ptr } } %t67, 0
  store i32 %t69, ptr %l34
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb11, label %ok.71, !prof !99
ok.71:
  store { i64, ptr } %t68, ptr %l33
  br label %bb10
bb10:
  %t72 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t72, ptr %l30, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i32, ptr %l34, !tbaa !23
  %t74 = lshr i32 %t73, 16
  %t75 = and i32 %t73, 65535
  %t76 = icmp eq i32 %t74, 1
  %t77 = select i1 %t76, i32 1, i32 0
  %t78 = icmp eq i32 %t73, 0
  %t79 = shl i32 %t77, 16
  %t80 = or i32 %t79, %t75
  %t81 = select i1 %t78, i32 0, i32 %t80
  call void @__olang_scope_close(ptr %s3)
  %t83 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t81, 0
  store { i32, { i64, ptr } } %t83, ptr %rv
  br label %ret
bb12:
  %t84 = load i32, ptr %l7, !tbaa !23
  %t86 = sext i32 %t84 to i64
  store i64 %t86, ptr %l37, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t89 = load { ptr, ptr }, ptr %l2
  %t93 = extractvalue { ptr, ptr } %t89, 0
  %t94 = extractvalue { ptr, ptr } %t89, 1
  %t95 = call { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplaceWord(ptr %v0, ptr %v1, ptr %v2, ptr %s3, ptr %t87, ptr %t88, ptr %t93, ptr %t94)
  %t96 = extractvalue { i32, { i64, ptr } } %t95, 1
  %t97 = extractvalue { i32, { i64, ptr } } %t95, 0
  store i32 %t97, ptr %l43
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb14, label %ok.99, !prof !99
ok.99:
  store { i64, ptr } %t96, ptr %l42
  br label %bb13
bb13:
  %t100 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t100, ptr %l38, !tbaa !27
  br label %bb15
bb14:
  %t101 = load i32, ptr %l43, !tbaa !23
  %t102 = lshr i32 %t101, 16
  %t103 = and i32 %t101, 65535
  %t104 = icmp eq i32 %t102, 1
  %t105 = select i1 %t104, i32 1, i32 0
  %t106 = icmp eq i32 %t101, 0
  %t107 = shl i32 %t105, 16
  %t108 = or i32 %t107, %t103
  %t109 = select i1 %t106, i32 0, i32 %t108
  call void @__olang_scope_close(ptr %s3)
  %t111 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t109, 0
  store { i32, { i64, ptr } } %t111, ptr %rv
  br label %ret
bb15:
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t114 = load i32, ptr %l28, !tbaa !23
  %t115 = sext i32 %t114 to i64
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t115)
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load i32, ptr %l29, !tbaa !23
  %t122 = sext i32 %t121 to i64
  %t123 = call i64 @__olang_fmt_i64(ptr null, i64 %t122)
  %t124 = add i64 %t120, %t123
  %t125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t127 = add i64 %t124, %t126
  %t128 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = add i64 %t127, %t130
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t135 = load i64, ptr %l37, !tbaa !24
  %t136 = call i64 @__olang_fmt_i64(ptr null, i64 %t135)
  %t137 = add i64 %t134, %t136
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = add i64 %t140, %t143
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t112, i64 %t113)
  %t149 = getelementptr i8, ptr %t148, i64 %t113
  %t150 = call i64 @__olang_fmt_i64(ptr %t149, i64 %t115)
  %t151 = getelementptr i8, ptr %t149, i64 %t116
  call void @olang_textcopy(ptr %t151, ptr %t118, i64 %t119)
  %t152 = getelementptr i8, ptr %t151, i64 %t119
  %t153 = call i64 @__olang_fmt_i64(ptr %t152, i64 %t122)
  %t154 = getelementptr i8, ptr %t152, i64 %t123
  call void @olang_textcopy(ptr %t154, ptr %t125, i64 %t126)
  %t155 = getelementptr i8, ptr %t154, i64 %t126
  call void @olang_textcopy(ptr %t155, ptr %t129, i64 %t130)
  %t156 = getelementptr i8, ptr %t155, i64 %t130
  call void @olang_textcopy(ptr %t156, ptr %t132, i64 %t133)
  %t157 = getelementptr i8, ptr %t156, i64 %t133
  %t158 = call i64 @__olang_fmt_i64(ptr %t157, i64 %t135)
  %t159 = getelementptr i8, ptr %t157, i64 %t136
  call void @olang_textcopy(ptr %t159, ptr %t138, i64 %t139)
  %t160 = getelementptr i8, ptr %t159, i64 %t139
  call void @olang_textcopy(ptr %t160, ptr %t142, i64 %t143)
  %t161 = getelementptr i8, ptr %t160, i64 %t143
  call void @olang_textcopy(ptr %t161, ptr %t145, i64 %t146)
  %t162 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t148, 1
  store { i64, ptr } %t163, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t166 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t166, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_afe89d4716bb52e8_bab84d91c7a69354)
  unreachable
bb21:
  %t167 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t168 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t167, 1
  store { i32, { i64, ptr } } %t168, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eReadExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2c, ptr %a2e) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"compiler/typed:wordReader"
  %l4 = alloca ptr
  %l7 = alloca %"compiler/typed:wordReader"
  %l8 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store { i64, ptr } %a1, ptr %l1
  %pf2 = insertvalue { ptr, ptr } undef, ptr %a2c, 0
  %pg2 = insertvalue { ptr, ptr } %pf2, ptr %a2e, 1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { ptr, ptr } %pg2, 0
  %t6 = extractvalue { ptr, ptr } %pg2, 1
  %t7 = call %"compiler/typed:wordReader" @compiler_2ftyped_3awordReader_2ector(ptr %v1, ptr %v2, ptr %s0, { i64, ptr } %t1, ptr %t5, ptr %t6)
  store %"compiler/typed:wordReader" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/typed:wordReader", ptr %l7
  store %"compiler/typed:wordReader" %t8, ptr %l3
  %t12 = call { i32, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ereadExpr(ptr %v0, ptr %s0, ptr %v3, ptr %a0, ptr %l3)
  %t13 = extractvalue { i32, ptr } %t12, 1
  %t14 = extractvalue { i32, ptr } %t12, 0
  store i32 %t14, ptr %l12
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16, !prof !99
ok.16:
  store ptr %t13, ptr %l11
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l11, !tbaa !29
  store ptr %t17, ptr %l8, !tbaa !29
  br label %bb4
bb3:
  %t18 = load i32, ptr %l12, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  call void @__olang_scope_close(ptr %s0)
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb4:
  %t29 = load ptr, ptr %l8, !tbaa !29
  store ptr %t29, ptr %l4, !tbaa !29
  %t30 = getelementptr %"compiler/typed:wordReader", ptr %l3, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t37 = icmp ne i64 %t31, %t34
  br i1 %t37, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  %t43 = insertvalue { i32, ptr } zeroinitializer, ptr %t41, 1
  store { i32, ptr } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l83 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l119 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i1
  %l188 = alloca ptr
  %l189 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca i1
  %l210 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l214 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Nodes", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t3, ptr %t4)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t8 = load ptr, ptr %l32, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l32, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 18}
  %t14 = icmp eq i64 %t12, 2
  store i1 %t14, ptr %l33, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l33, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb14
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t23 = load ptr, ptr %l38, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l38, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l39, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l39, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l2, !tbaa !29
  br label %bb14
bb9:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t38 = load ptr, ptr %l44, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l44, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 4
  store i1 %t44, ptr %l45, !tbaa !21
  br label %bb11
bb11:
  %t45 = load i1, ptr %l45, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l2, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb15
bb15:
  br label %bb143
bb16:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t57 = load ptr, ptr %l52, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = load ptr, ptr %l52, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 18}
  %t63 = icmp eq i64 %t61, 5
  store i1 %t63, ptr %l53, !tbaa !21
  br label %bb18
bb18:
  %t64 = load i1, ptr %l53, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Promote", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t71, ptr %t75)
  br label %bb22
bb22:
  br label %bb143
bb23:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t79 = load ptr, ptr %l61, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb24, label %bb25
bb24:
  %t82 = load ptr, ptr %l61, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 6
  store i1 %t85, ptr %l62, !tbaa !21
  br label %bb25
bb25:
  %t86 = load i1, ptr %l62, !tbaa !21
  br i1 %t86, label %bb26, label %bb27
bb26:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ecall(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  br label %bb29
bb29:
  br label %bb143
bb30:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t98 = load ptr, ptr %l69, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb31, label %bb32
bb31:
  %t101 = load ptr, ptr %l69, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 18}
  %t104 = icmp eq i64 %t102, 7
  store i1 %t104, ptr %l70, !tbaa !21
  br label %bb32
bb32:
  %t105 = load i1, ptr %l70, !tbaa !21
  br i1 %t105, label %bb33, label %bb34
bb33:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 2
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l5, !tbaa !29
  br label %bb35
bb34:
  br label %bb44
bb35:
  %t112 = load ptr, ptr %l5, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Make", ptr %t112, i32 0, i32 2
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  store i64 %t119, ptr %l8, !tbaa !24
  br label %bb36
bb36:
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load i64, ptr %l8, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb37, label %bb38
bb37:
  br label %bb42
bb38:
  br label %bb39
bb39:
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t129, ptr %l83, !tbaa !27
  %t130 = load i64, ptr %l7, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 %t130
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t137 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t137, ptr %t135)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t141 = load i64, ptr %l7, !tbaa !24
  %t143 = add i64 %t141, 1
  store i64 %t143, ptr %l7, !tbaa !24
  br label %bb36
bb42:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l5, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Make", ptr %t146, i32 0, i32 3
  %t149 = load ptr, ptr %t148, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t145, ptr %t149)
  br label %bb43
bb43:
  br label %bb143
bb44:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t153 = load ptr, ptr %l93, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb45, label %bb46
bb45:
  %t156 = load ptr, ptr %l93, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 18}
  %t159 = icmp eq i64 %t157, 8
  store i1 %t159, ptr %l94, !tbaa !21
  br label %bb46
bb46:
  %t160 = load i1, ptr %l94, !tbaa !21
  br i1 %t160, label %bb47, label %bb48
bb47:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t163, i32 0, i32 2
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l10, !tbaa !29
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l10, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Collect", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t167, ptr %t171)
  br label %bb50
bb50:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l10, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Collect", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t174, ptr %t178)
  br label %bb51
bb51:
  br label %bb143
bb52:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t183 = load ptr, ptr %l106, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb53, label %bb54
bb53:
  %t186 = load ptr, ptr %l106, !tbaa !29
  %t187 = load i64, ptr %t186, !range !{i64 0, i64 18}
  %t189 = icmp eq i64 %t187, 9
  store i1 %t189, ptr %l107, !tbaa !21
  br label %bb54
bb54:
  %t190 = load i1, ptr %l107, !tbaa !21
  br i1 %t190, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t193, i32 0, i32 4
  %t195 = load { i64, ptr }, ptr %t194
  store { i64, ptr } %t195, ptr %l11, !tbaa !27
  br label %bb57
bb56:
  br label %bb65
bb57:
  %t197 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t197, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t199, 0
  store i64 %t201, ptr %l14, !tbaa !24
  br label %bb58
bb58:
  %t203 = load i64, ptr %l13, !tbaa !24
  %t204 = load i64, ptr %l14, !tbaa !24
  %t207 = icmp slt i64 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb59, label %bb60
bb59:
  br label %bb64
bb60:
  br label %bb61
bb61:
  %t211 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t211, ptr %l119, !tbaa !27
  %t212 = load i64, ptr %l13, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr ptr, ptr %t215, i64 %t212
  %t217 = load ptr, ptr %t216, !tbaa !39
  %t219 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t219, ptr %t217)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t223 = load i64, ptr %l13, !tbaa !24
  %t225 = add i64 %t223, 1
  store i64 %t225, ptr %l13, !tbaa !24
  br label %bb58
bb64:
  br label %bb143
bb65:
  %t227 = load ptr, ptr %l1, !tbaa !29
  store ptr %t227, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t228 = load ptr, ptr %l126, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb66, label %bb67
bb66:
  %t231 = load ptr, ptr %l126, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 18}
  %t234 = icmp eq i64 %t232, 10
  store i1 %t234, ptr %l127, !tbaa !21
  br label %bb67
bb67:
  %t235 = load i1, ptr %l127, !tbaa !21
  br i1 %t235, label %bb68, label %bb69
bb68:
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t238, i32 0, i32 2
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l16, !tbaa !29
  br label %bb70
bb69:
  br label %bb74
bb70:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l16, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Slice", ptr %t243, i32 0, i32 0
  %t246 = load ptr, ptr %t245, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %t242, ptr %t246)
  br label %bb71
bb71:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load ptr, ptr %l16, !tbaa !29
  %t252 = getelementptr %"compiler/typed:Slice", ptr %t250, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t249, ptr %t253)
  br label %bb72
bb72:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load ptr, ptr %l16, !tbaa !29
  %t259 = getelementptr %"compiler/typed:Slice", ptr %t257, i32 0, i32 2
  %t260 = load ptr, ptr %t259, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t256, ptr %t260)
  br label %bb73
bb73:
  br label %bb143
bb74:
  %t263 = load ptr, ptr %l1, !tbaa !29
  store ptr %t263, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t264 = load ptr, ptr %l141, !tbaa !29
  %t265 = icmp ne ptr %t264, null
  br i1 %t265, label %bb75, label %bb76
bb75:
  %t267 = load ptr, ptr %l141, !tbaa !29
  %t268 = load i64, ptr %t267, !range !{i64 0, i64 18}
  %t270 = icmp eq i64 %t268, 11
  store i1 %t270, ptr %l142, !tbaa !21
  br label %bb76
bb76:
  %t271 = load i1, ptr %l142, !tbaa !21
  br i1 %t271, label %bb77, label %bb78
bb77:
  %t272 = load ptr, ptr %l1, !tbaa !29
  %t274 = getelementptr { i64, [5 x i64] }, ptr %t272, i32 0, i32 1
  %t275 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t274, i32 0, i32 2
  %t276 = load ptr, ptr %t275
  store ptr %t276, ptr %l17, !tbaa !29
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l17, !tbaa !29
  %t281 = getelementptr %"compiler/typed:Cond", ptr %t279, i32 0, i32 0
  %t282 = load ptr, ptr %t281, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t278, ptr %t282)
  br label %bb80
bb80:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load ptr, ptr %l17, !tbaa !29
  %t288 = getelementptr %"compiler/typed:Cond", ptr %t286, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t285, ptr %t289)
  br label %bb81
bb81:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l17, !tbaa !29
  %t295 = getelementptr %"compiler/typed:Cond", ptr %t293, i32 0, i32 2
  %t296 = load ptr, ptr %t295, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t292, ptr %t296)
  br label %bb82
bb82:
  br label %bb143
bb83:
  %t299 = load ptr, ptr %l1, !tbaa !29
  store ptr %t299, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t300 = load ptr, ptr %l156, !tbaa !29
  %t301 = icmp ne ptr %t300, null
  br i1 %t301, label %bb84, label %bb85
bb84:
  %t303 = load ptr, ptr %l156, !tbaa !29
  %t304 = load i64, ptr %t303, !range !{i64 0, i64 18}
  %t306 = icmp eq i64 %t304, 12
  store i1 %t306, ptr %l157, !tbaa !21
  br label %bb85
bb85:
  %t307 = load i1, ptr %l157, !tbaa !21
  br i1 %t307, label %bb86, label %bb87
bb86:
  %t308 = load ptr, ptr %l1, !tbaa !29
  %t310 = getelementptr { i64, [5 x i64] }, ptr %t308, i32 0, i32 1
  %t311 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t310, i32 0, i32 2
  %t312 = load ptr, ptr %t311
  store ptr %t312, ptr %l18, !tbaa !29
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l18, !tbaa !29
  %t317 = getelementptr %"compiler/typed:Seq", ptr %t315, i32 0, i32 0
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2estmts(ptr %v0, ptr %v1, ptr %t314, { i64, ptr } %t318)
  br label %bb89
bb89:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l18, !tbaa !29
  %t324 = getelementptr %"compiler/typed:Seq", ptr %t322, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t321, ptr %t325)
  br label %bb90
bb90:
  br label %bb143
bb91:
  %t328 = load ptr, ptr %l1, !tbaa !29
  store ptr %t328, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t329 = load ptr, ptr %l168, !tbaa !29
  %t330 = icmp ne ptr %t329, null
  br i1 %t330, label %bb92, label %bb93
bb92:
  %t332 = load ptr, ptr %l168, !tbaa !29
  %t333 = load i64, ptr %t332, !range !{i64 0, i64 18}
  %t335 = icmp eq i64 %t333, 13
  store i1 %t335, ptr %l169, !tbaa !21
  br label %bb93
bb93:
  %t336 = load i1, ptr %l169, !tbaa !21
  br i1 %t336, label %bb94, label %bb95
bb94:
  %t337 = load ptr, ptr %l1, !tbaa !29
  %t339 = getelementptr { i64, [5 x i64] }, ptr %t337, i32 0, i32 1
  %t340 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t339, i32 0, i32 2
  %t341 = load ptr, ptr %t340
  store ptr %t341, ptr %l19, !tbaa !29
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ematch(ptr %v0, ptr %v1, ptr %t343, ptr %t344)
  br label %bb97
bb97:
  br label %bb143
bb98:
  %t347 = load ptr, ptr %l1, !tbaa !29
  store ptr %t347, ptr %l176, !tbaa !29
  store i1 false, ptr %l177, !tbaa !21
  %t348 = load ptr, ptr %l176, !tbaa !29
  %t349 = icmp ne ptr %t348, null
  br i1 %t349, label %bb99, label %bb100
bb99:
  %t351 = load ptr, ptr %l176, !tbaa !29
  %t352 = load i64, ptr %t351, !range !{i64 0, i64 18}
  %t354 = icmp eq i64 %t352, 14
  store i1 %t354, ptr %l177, !tbaa !21
  br label %bb100
bb100:
  %t355 = load i1, ptr %l177, !tbaa !21
  br i1 %t355, label %bb101, label %bb102
bb101:
  %t356 = load ptr, ptr %l1, !tbaa !29
  %t358 = getelementptr { i64, [5 x i64] }, ptr %t356, i32 0, i32 1
  %t359 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t358, i32 0, i32 2
  %t360 = load ptr, ptr %t359
  store ptr %t360, ptr %l20, !tbaa !29
  br label %bb103
bb102:
  br label %bb106
bb103:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load ptr, ptr %l20, !tbaa !29
  %t365 = getelementptr %"compiler/typed:Try", ptr %t363, i32 0, i32 0
  %t366 = load ptr, ptr %t365, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t362, ptr %t366)
  br label %bb104
bb104:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load ptr, ptr %l20, !tbaa !29
  %t372 = getelementptr %"compiler/typed:Try", ptr %t370, i32 0, i32 1
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eclauses(ptr %v0, ptr %v1, ptr %t369, { i64, ptr } %t373)
  br label %bb105
bb105:
  br label %bb143
bb106:
  %t376 = load ptr, ptr %l1, !tbaa !29
  store ptr %t376, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t377 = load ptr, ptr %l188, !tbaa !29
  %t378 = icmp ne ptr %t377, null
  br i1 %t378, label %bb107, label %bb108
bb107:
  %t380 = load ptr, ptr %l188, !tbaa !29
  %t381 = load i64, ptr %t380, !range !{i64 0, i64 18}
  %t383 = icmp eq i64 %t381, 15
  store i1 %t383, ptr %l189, !tbaa !21
  br label %bb108
bb108:
  %t384 = load i1, ptr %l189, !tbaa !21
  br i1 %t384, label %bb109, label %bb110
bb109:
  %t385 = load ptr, ptr %l1, !tbaa !29
  %t387 = getelementptr { i64, [5 x i64] }, ptr %t385, i32 0, i32 1
  %t388 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t387, i32 0, i32 2
  %t389 = load ptr, ptr %t388
  store ptr %t389, ptr %l21, !tbaa !29
  br label %bb111
bb110:
  br label %bb113
bb111:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2efnVal(ptr %v0, ptr %v1, ptr %t391, ptr %t392)
  br label %bb112
bb112:
  br label %bb143
bb113:
  %t395 = load ptr, ptr %l1, !tbaa !29
  store ptr %t395, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t396 = load ptr, ptr %l196, !tbaa !29
  %t397 = icmp ne ptr %t396, null
  br i1 %t397, label %bb114, label %bb115
bb114:
  %t399 = load ptr, ptr %l196, !tbaa !29
  %t400 = load i64, ptr %t399, !range !{i64 0, i64 18}
  %t402 = icmp eq i64 %t400, 16
  store i1 %t402, ptr %l197, !tbaa !21
  br label %bb115
bb115:
  %t403 = load i1, ptr %l197, !tbaa !21
  br i1 %t403, label %bb116, label %bb117
bb116:
  %t404 = load ptr, ptr %l1, !tbaa !29
  %t406 = getelementptr { i64, [5 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t406, i32 0, i32 2
  %t408 = load ptr, ptr %t407
  store ptr %t408, ptr %l22, !tbaa !29
  br label %bb118
bb117:
  br label %bb131
bb118:
  %t410 = load ptr, ptr %l22, !tbaa !29
  %t412 = getelementptr %"compiler/typed:Text", ptr %t410, i32 0, i32 0
  %t413 = load { i64, ptr }, ptr %t412, !tbaa !27
  store { i64, ptr } %t413, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t415 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t415, 0
  store i64 %t417, ptr %l25, !tbaa !24
  br label %bb119
bb119:
  %t419 = load i64, ptr %l24, !tbaa !24
  %t420 = load i64, ptr %l25, !tbaa !24
  %t423 = icmp slt i64 %t419, %t420
  %t425 = xor i1 %t423, true
  br i1 %t425, label %bb120, label %bb121
bb120:
  br label %bb130
bb121:
  br label %bb122
bb122:
  %t427 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t427, ptr %l210, !tbaa !27
  %t428 = load i64, ptr %l24, !tbaa !24
  %t430 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = getelementptr ptr, ptr %t431, i64 %t428
  %t433 = load ptr, ptr %t432, !tbaa !39
  store ptr %t433, ptr %l26, !tbaa !29
  %t435 = load ptr, ptr %l26, !tbaa !29
  store ptr %t435, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t436 = load ptr, ptr %l213, !tbaa !29
  %t437 = icmp ne ptr %t436, null
  br i1 %t437, label %bb123, label %bb124
bb123:
  %t439 = load ptr, ptr %l213, !tbaa !29
  %t440 = load i64, ptr %t439, !range !{i64 0, i64 2}
  %t442 = icmp eq i64 %t440, 1
  store i1 %t442, ptr %l214, !tbaa !21
  br label %bb124
bb124:
  %t443 = load i1, ptr %l214, !tbaa !21
  br i1 %t443, label %bb125, label %bb126
bb125:
  %t444 = load ptr, ptr %l26, !tbaa !29
  %t446 = getelementptr { i64, [2 x i64] }, ptr %t444, i32 0, i32 1
  %t447 = getelementptr { ptr }, ptr %t446, i32 0, i32 0
  %t448 = load ptr, ptr %t447
  %t450 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t450, ptr %t448)
  br label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb128
bb128:
  br label %bb129
bb129:
  %t454 = load i64, ptr %l24, !tbaa !24
  %t456 = add i64 %t454, 1
  store i64 %t456, ptr %l24, !tbaa !24
  br label %bb119
bb130:
  br label %bb143
bb131:
  %t458 = load ptr, ptr %l1, !tbaa !29
  store ptr %t458, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t459 = load ptr, ptr %l223, !tbaa !29
  %t460 = icmp ne ptr %t459, null
  br i1 %t460, label %bb132, label %bb133
bb132:
  %t462 = load ptr, ptr %l223, !tbaa !29
  %t463 = load i64, ptr %t462, !range !{i64 0, i64 18}
  %t465 = icmp eq i64 %t463, 17
  store i1 %t465, ptr %l224, !tbaa !21
  br label %bb133
bb133:
  %t466 = load i1, ptr %l224, !tbaa !21
  br i1 %t466, label %bb134, label %bb135
bb134:
  %t467 = load ptr, ptr %l1, !tbaa !29
  %t469 = getelementptr { i64, [5 x i64] }, ptr %t467, i32 0, i32 1
  %t470 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t469, i32 0, i32 2
  %t471 = load ptr, ptr %t470
  store ptr %t471, ptr %l28, !tbaa !29
  br label %bb136
bb135:
  br label %bb138
bb136:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t473, ptr %t474)
  br label %bb137
bb137:
  br label %bb143
bb138:
  br i1 true, label %bb139, label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb143
bb142:
  call void @__olang_check_failed(ptr @olang_loc_fc4a9e97a0375850_6fc32d1d5d28aa84)
  unreachable
bb143:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Match", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2estmts(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Match", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2earm(ptr %v0, ptr %v1, ptr %t33, ptr %t31)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Match", ptr %t42, i32 0, i32 2
  %t45 = load ptr, ptr %t44, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eoptArm(ptr %v0, ptr %v1, ptr %t41, ptr %t45)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  %t5 = xor i1 %t3, true
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t8)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ereadExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i8
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l32 = alloca i1
  %l33 = alloca i64
  %l36 = alloca i64
  %l42 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l51 = alloca i32
  %l53 = alloca i32
  %l54 = alloca i32
  %l56 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i32
  %l62 = alloca i32
  %l64 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i32
  %l71 = alloca i32
  %rv = alloca { i32, ptr }
  %t217 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:wordReader", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:wordReader", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp sge i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t16 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t16, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/typed:wordReader", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:wordReader", ptr %t21, i32 0, i32 2
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  store i8 %t29, ptr %l2, !tbaa !22
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = getelementptr %"compiler/typed:wordReader", ptr %t32, i32 0, i32 2
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = add i64 %t34, 1
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = getelementptr %"compiler/typed:wordReader", ptr %t38, i32 0, i32 2
  store i64 %t36, ptr %t39, !tbaa !24
  %t40 = load i8, ptr %l2, !tbaa !22
  %t42 = icmp eq i8 %t40, 78
  br i1 %t42, label %bb4, label %bb5
bb4:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = call { i32, i64 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2eint(ptr %v1, ptr %t44)
  %t47 = extractvalue { i32, i64 } %t46, 1
  %t48 = extractvalue { i32, i64 } %t46, 0
  store i32 %t48, ptr %l28
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb7, label %ok.50, !prof !99
ok.50:
  store i64 %t47, ptr %l27
  br label %bb6
bb5:
  br label %bb17
bb6:
  %t51 = load i64, ptr %l27, !tbaa !24
  store i64 %t51, ptr %l25, !tbaa !24
  br label %bb8
bb7:
  %t52 = load i32, ptr %l28, !tbaa !23
  %t53 = lshr i32 %t52, 16
  %t54 = and i32 %t52, 65535
  %t55 = icmp eq i32 %t53, 1
  %t56 = select i1 %t55, i32 1, i32 0
  %t57 = icmp eq i32 %t52, 0
  %t58 = shl i32 %t56, 16
  %t59 = or i32 %t58, %t54
  %t60 = select i1 %t57, i32 0, i32 %t59
  %t62 = insertvalue { i32, ptr } zeroinitializer, i32 %t60, 0
  store { i32, ptr } %t62, ptr %rv
  br label %ret
bb8:
  %t63 = load i64, ptr %l25, !tbaa !24
  store i64 %t63, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l3, !tbaa !24
  %t66 = icmp slt i64 %t64, 0
  br i1 %t66, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb12
bb10:
  %t68 = load i64, ptr %l3, !tbaa !24
  store i64 %t68, ptr %l33, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Nodes", ptr %t69, i32 0, i32 0
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l36
  br label %bb11
bb11:
  %t74 = load i64, ptr %l33, !tbaa !24
  %t75 = load i64, ptr %l36, !tbaa !24
  %t76 = icmp sge i64 %t74, %t75
  store i1 %t76, ptr %l32, !tbaa !21
  br label %bb12
bb12:
  %t78 = load i1, ptr %l32, !tbaa !21
  br i1 %t78, label %bb13, label %bb14
bb13:
  %t80 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t80, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Nodes", ptr %t81, i32 0, i32 0
  %t84 = load i64, ptr %l3, !tbaa !24
  %t87 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t83, i64 %t84)
  store ptr %t87, ptr %l42
  br label %bb16
bb16:
  %t88 = load ptr, ptr %l42, !tbaa !29
  %t89 = insertvalue { i32, ptr } zeroinitializer, ptr %t88, 1
  store { i32, ptr } %t89, ptr %rv
  br label %ret
bb17:
  %t90 = load i8, ptr %l2, !tbaa !22
  %t92 = icmp ne i8 %t90, 82
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t95 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t95, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = call { i32, %"compiler/source:Span" } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2espan(ptr %v1, ptr %t96)
  %t99 = extractvalue { i32, %"compiler/source:Span" } %t98, 1
  %t100 = extractvalue { i32, %"compiler/source:Span" } %t98, 0
  store i32 %t100, ptr %l49
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb22, label %ok.102, !prof !99
ok.102:
  store %"compiler/source:Span" %t99, ptr %l48
  br label %bb21
bb21:
  %t103 = load %"compiler/source:Span", ptr %l48
  store %"compiler/source:Span" %t103, ptr %l46
  br label %bb23
bb22:
  %t104 = load i32, ptr %l49, !tbaa !23
  %t105 = lshr i32 %t104, 16
  %t106 = and i32 %t104, 65535
  %t107 = icmp eq i32 %t105, 1
  %t108 = select i1 %t107, i32 1, i32 0
  %t109 = icmp eq i32 %t104, 0
  %t110 = shl i32 %t108, 16
  %t111 = or i32 %t110, %t106
  %t112 = select i1 %t109, i32 0, i32 %t111
  %t114 = insertvalue { i32, ptr } zeroinitializer, i32 %t112, 0
  store { i32, ptr } %t114, ptr %rv
  br label %ret
bb23:
  %t115 = load %"compiler/source:Span", ptr %l46
  store %"compiler/source:Span" %t115, ptr %l4
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = call { i32, i32 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2ety(ptr %v1, ptr %t116)
  %t119 = extractvalue { i32, i32 } %t118, 1
  %t120 = extractvalue { i32, i32 } %t118, 0
  store i32 %t120, ptr %l54
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb25, label %ok.122, !prof !99
ok.122:
  store i32 %t119, ptr %l53
  br label %bb24
bb24:
  %t123 = load i32, ptr %l53, !tbaa !23
  store i32 %t123, ptr %l51, !tbaa !23
  br label %bb26
bb25:
  %t124 = load i32, ptr %l54, !tbaa !23
  %t125 = lshr i32 %t124, 16
  %t126 = and i32 %t124, 65535
  %t127 = icmp eq i32 %t125, 1
  %t128 = select i1 %t127, i32 1, i32 0
  %t129 = icmp eq i32 %t124, 0
  %t130 = shl i32 %t128, 16
  %t131 = or i32 %t130, %t126
  %t132 = select i1 %t129, i32 0, i32 %t131
  %t134 = insertvalue { i32, ptr } zeroinitializer, i32 %t132, 0
  store { i32, ptr } %t134, ptr %rv
  br label %ret
bb26:
  %t135 = load i32, ptr %l51, !tbaa !23
  store i32 %t135, ptr %l5, !tbaa !23
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = call { i32, i64 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2eint(ptr %v1, ptr %t136)
  %t139 = extractvalue { i32, i64 } %t138, 1
  %t140 = extractvalue { i32, i64 } %t138, 0
  store i32 %t140, ptr %l59
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb28, label %ok.142, !prof !99
ok.142:
  store i64 %t139, ptr %l58
  br label %bb27
bb27:
  %t143 = load i64, ptr %l58, !tbaa !24
  store i64 %t143, ptr %l56, !tbaa !24
  br label %bb29
bb28:
  %t144 = load i32, ptr %l59, !tbaa !23
  %t145 = lshr i32 %t144, 16
  %t146 = and i32 %t144, 65535
  %t147 = icmp eq i32 %t145, 1
  %t148 = select i1 %t147, i32 1, i32 0
  %t149 = icmp eq i32 %t144, 0
  %t150 = shl i32 %t148, 16
  %t151 = or i32 %t150, %t146
  %t152 = select i1 %t149, i32 0, i32 %t151
  %t154 = insertvalue { i32, ptr } zeroinitializer, i32 %t152, 0
  store { i32, ptr } %t154, ptr %rv
  br label %ret
bb29:
  %t155 = load i64, ptr %l56, !tbaa !24
  store i64 %t155, ptr %l6, !tbaa !24
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2echar(ptr %v1, ptr %t156, i8 40)
  store i32 %t158, ptr %l62
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb31, label %ok.160, !prof !99
ok.160:
  br label %bb30
bb30:
  br label %bb32
bb31:
  %t161 = load i32, ptr %l62, !tbaa !23
  %t162 = lshr i32 %t161, 16
  %t163 = and i32 %t161, 65535
  %t164 = icmp eq i32 %t162, 1
  %t165 = select i1 %t164, i32 1, i32 0
  %t166 = icmp eq i32 %t161, 0
  %t167 = shl i32 %t165, 16
  %t168 = or i32 %t167, %t163
  %t169 = select i1 %t166, i32 0, i32 %t168
  %t171 = insertvalue { i32, ptr } zeroinitializer, i32 %t169, 0
  store { i32, ptr } %t171, ptr %rv
  br label %ret
bb32:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t176 = call { i32, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t172, ptr %t173)
  %t177 = extractvalue { i32, ptr } %t176, 1
  %t178 = extractvalue { i32, ptr } %t176, 0
  store i32 %t178, ptr %l68
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb34, label %ok.180, !prof !99
ok.180:
  store ptr %t177, ptr %l67
  br label %bb33
bb33:
  %t181 = load ptr, ptr %l67, !tbaa !29
  store ptr %t181, ptr %l64, !tbaa !29
  br label %bb35
bb34:
  %t182 = load i32, ptr %l68, !tbaa !23
  %t183 = lshr i32 %t182, 16
  %t184 = and i32 %t182, 65535
  %t185 = icmp eq i32 %t183, 1
  %t186 = select i1 %t185, i32 1, i32 0
  %t187 = icmp eq i32 %t182, 0
  %t188 = shl i32 %t186, 16
  %t189 = or i32 %t188, %t184
  %t190 = select i1 %t187, i32 0, i32 %t189
  %t192 = insertvalue { i32, ptr } zeroinitializer, i32 %t190, 0
  store { i32, ptr } %t192, ptr %rv
  br label %ret
bb35:
  %t193 = load ptr, ptr %l64, !tbaa !29
  store ptr %t193, ptr %l7, !tbaa !29
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2echar(ptr %v1, ptr %t194, i8 41)
  store i32 %t196, ptr %l71
  %t197 = icmp ne i32 %t196, 0
  br i1 %t197, label %bb37, label %ok.198, !prof !99
ok.198:
  br label %bb36
bb36:
  br label %bb38
bb37:
  %t199 = load i32, ptr %l71, !tbaa !23
  %t200 = lshr i32 %t199, 16
  %t201 = and i32 %t199, 65535
  %t202 = icmp eq i32 %t200, 1
  %t203 = select i1 %t202, i32 1, i32 0
  %t204 = icmp eq i32 %t199, 0
  %t205 = shl i32 %t203, 16
  %t206 = or i32 %t205, %t201
  %t207 = select i1 %t204, i32 0, i32 %t206
  %t209 = insertvalue { i32, ptr } zeroinitializer, i32 %t207, 0
  store { i32, ptr } %t209, ptr %rv
  br label %ret
bb38:
  %t210 = load %"compiler/source:Span", ptr %l4
  %t211 = load i32, ptr %l5, !tbaa !23
  %t212 = load ptr, ptr %l7, !tbaa !29
  %t213 = load i64, ptr %l6, !tbaa !24
  %t215 = trunc i64 %t213 to i32
  store { i64, [5 x i64] } zeroinitializer, ptr %t217
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t217, i32 0, i32 0
  store i64 2, ptr %t218
  %t220 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t210, 0
  %t222 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t220, i32 %t211, 1
  %t224 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t222, ptr %t212, 2
  %t226 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t224, i32 %t215, 3
  %t227 = getelementptr { i64, [5 x i64] }, ptr %t217, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t226, ptr %t227
  %t228 = load { i64, [5 x i64] }, ptr %t217
  %t230 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t228, ptr %t230
  %t232 = insertvalue { i32, ptr } zeroinitializer, ptr %t230, 1
  store { i32, ptr } %t232, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eDropDerivedOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca ptr
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 20
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Plan", ptr %t53, i32 0, i32 20
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s2, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l38
  br label %bb12
bb12:
  %t61 = load ptr, ptr %l38, !tbaa !29
  %t63 = icmp eq ptr %t61, %a1
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Plan", ptr %t65, i32 0, i32 21
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hb773ac01a07f3f9e7f749c328573d0ee(ptr %v0, ptr %v2, ptr %t67, i64 %t68)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %l44
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v2, ptr %l44)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l46
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %rv
  br label %ret
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb8
bb19:
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l49
  br label %bb20
bb20:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca i64
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 14
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Plan", ptr %t8, i32 0, i32 16
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l13
  br label %bb1
bb1:
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = add i64 %t13, 1
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i64, ptr %t18, i64 %t16
  store i64 %t14, ptr %t19, !tbaa !34
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Plan", ptr %t20, i32 0, i32 15
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i64, ptr %t33, i64 %t26
  store i64 %t29, ptr %t34, !tbaa !34
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t49, ptr %l28, !tbaa !27
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, [2 x i64] }, ptr %t53, i64 %t50
  %t55 = load { i64, [2 x i64] }, ptr %t54
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Plan", ptr %t57, i32 0, i32 16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t59, { i64, [2 x i64] } %t55)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l11, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v2, ptr %t6)
  store i64 %t8, ptr %l13
  br label %bb3
bb3:
  %t9 = load i64, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = icmp sge i64 %t9, %t10
  store i1 %t11, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sge i64 %t14, 64
  store i1 %t16, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = mul i64 %t20, 64
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  store i64 %t26, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:RefsKept", ptr %t28, i32 0, i32 0
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t30, i64 %t31)
  %t35 = extractvalue { i32, i1 } %t34, 1
  %t36 = extractvalue { i32, i1 } %t34, 0
  store i32 %t36, ptr %l28
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb12, label %ok.38, !prof !99
ok.38:
  store i1 %t35, ptr %l27
  br label %bb11
bb11:
  %t39 = load i1, ptr %l27, !tbaa !21
  store i1 %t39, ptr %l23, !tbaa !21
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:RefsKept", ptr %t40, i32 0, i32 0
  %t43 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t42, i64 %t43, i1 false)
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  store ptr %a1, ptr %l33, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  store ptr %t48, ptr %l34, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v2, ptr %v2, ptr %t49, i64 %t50)
  store ptr %t53, ptr %l37
  br label %bb15
bb15:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load ptr, ptr %l37, !tbaa !29
  %t60 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2enoneIn(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t55, ptr %t56, ptr %t57, ptr %t58, i64 %t54)
  store i1 %t60, ptr %l39
  br label %bb16
bb16:
  %t61 = load i1, ptr %l39, !tbaa !21
  store i1 %t61, ptr %l6, !tbaa !21
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/typed:RefsKept", ptr %t62, i32 0, i32 0
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i1, ptr %l6, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t64, i64 %t65, i1 %t66)
  br label %bb17
bb17:
  %t70 = load i1, ptr %l6, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
bb18:
  %t72 = load i1, ptr %l23, !tbaa !21
  store i1 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i32
  %l35 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i32
  %l52 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l65 = alloca ptr
  %l67 = alloca i1
  %l71 = alloca i1
  %l74 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l13, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v2, ptr %t6)
  store i64 %t8, ptr %l15
  br label %bb3
bb3:
  %t9 = load i64, ptr %l13, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp sge i64 %t9, %t10
  store i1 %t11, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l12, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb7
bb6:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sge i64 %t14, 64
  store i1 %t16, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t18 = load i1, ptr %l17, !tbaa !21
  br i1 %t18, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = mul i64 %t20, 64
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  store i64 %t26, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:RefsKept", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t30, i64 %t31)
  store i1 %t34, ptr %l28
  br label %bb11
bb11:
  %t35 = load i1, ptr %l28, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/typed:RefsKept", ptr %t36, i32 0, i32 1
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t38, i64 %t39)
  %t43 = extractvalue { i32, i1 } %t42, 1
  %t44 = extractvalue { i32, i1 } %t42, 0
  store i32 %t44, ptr %l34
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb15, label %ok.46, !prof !99
ok.46:
  store i1 %t43, ptr %l33
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t47 = load i1, ptr %l33, !tbaa !21
  store i1 %t47, ptr %l29, !tbaa !21
  br label %bb17
bb15:
  br label %bb16
bb16:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb17
bb17:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
bb18:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:RefsKept", ptr %t49, i32 0, i32 2
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t51, i64 %t52)
  %t56 = extractvalue { i32, i64 } %t55, 1
  %t57 = extractvalue { i32, i64 } %t55, 0
  store i32 %t57, ptr %l40
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb20, label %ok.59, !prof !99
ok.59:
  store i64 %t56, ptr %l39
  br label %bb19
bb19:
  %t60 = load i64, ptr %l39, !tbaa !24
  store i64 %t60, ptr %l35, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb22
bb22:
  %t61 = load i64, ptr %l35, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = icmp sge i64 %t62, 0
  br i1 %t64, label %bb23, label %bb24
bb23:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/typed:RefsKept", ptr %t67, i32 0, i32 3
  %t70 = load i64, ptr %t69, !tbaa !24
  %t73 = icmp slt i64 %t66, %t70
  br i1 %t73, label %bb25, label %bb26
bb24:
  br label %bb28
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = getelementptr %"compiler/typed:RefsKept", ptr %t75, i32 0, i32 3
  store i64 %t76, ptr %t79, !tbaa !24
  br label %bb27
bb26:
  br label %bb27
bb27:
  store i1 true, ptr %rv
  br label %ret
bb28:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:RefsKept", ptr %t81, i32 0, i32 2
  %t85 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t83)
  store i64 %t85, ptr %l52
  br label %bb29
bb29:
  %t86 = load i64, ptr %l52, !tbaa !24
  store i64 %t86, ptr %l7, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:RefsKept", ptr %t87, i32 0, i32 2
  %t90 = load i64, ptr %l5, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t89, i64 %t90, i64 %t91)
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:RefsKept", ptr %t95, i32 0, i32 3
  %t98 = load i64, ptr %t97, !tbaa !24
  store i64 %t98, ptr %l8, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/typed:RefsKept", ptr %t100, i32 0, i32 3
  store i64 9223372036854775807, ptr %t102, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l60, !tbaa !29
  store ptr %a1, ptr %l61, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  store ptr %t105, ptr %l62, !tbaa !29
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t107 = load i64, ptr %l3, !tbaa !24
  %t110 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v2, ptr %v2, ptr %t106, i64 %t107)
  store ptr %t110, ptr %l65
  br label %bb31
bb31:
  %t111 = load i64, ptr %l4, !tbaa !24
  %t112 = load ptr, ptr %l60, !tbaa !29
  %t113 = load ptr, ptr %l61, !tbaa !29
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load ptr, ptr %l65, !tbaa !29
  %t117 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2enoneKeptIn(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t112, ptr %t113, ptr %t114, ptr %t115, i64 %t111)
  store i1 %t117, ptr %l67
  br label %bb32
bb32:
  %t118 = load i1, ptr %l67, !tbaa !21
  store i1 %t118, ptr %l9, !tbaa !21
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/typed:RefsKept", ptr %t119, i32 0, i32 2
  %t122 = load i64, ptr %l5, !tbaa !24
  %t125 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eRemove_3cI64_2c_20I64_3e(ptr %v0, ptr %t121, i64 %t122)
  store i1 %t125, ptr %l71
  br label %bb33
bb33:
  %t126 = load i1, ptr %l9, !tbaa !21
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb36
bb35:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/typed:RefsKept", ptr %t130, i32 0, i32 3
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = load i64, ptr %l7, !tbaa !24
  %t137 = icmp sge i64 %t133, %t134
  store i1 %t137, ptr %l74, !tbaa !21
  br label %bb36
bb36:
  %t139 = load i1, ptr %l74, !tbaa !21
  br i1 %t139, label %bb37, label %bb38
bb37:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/typed:RefsKept", ptr %t140, i32 0, i32 1
  %t143 = load i64, ptr %l5, !tbaa !24
  %t144 = load i1, ptr %l9, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t142, i64 %t143, i1 %t144)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/typed:RefsKept", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load i64, ptr %l7, !tbaa !24
  %t155 = icmp sge i64 %t151, %t152
  br i1 %t155, label %bb41, label %bb42
bb41:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:RefsKept", ptr %t157, i32 0, i32 3
  store i64 9223372036854775807, ptr %t159, !tbaa !24
  br label %bb43
bb42:
  br label %bb43
bb43:
  %t160 = load i64, ptr %l8, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/typed:RefsKept", ptr %t161, i32 0, i32 3
  %t164 = load i64, ptr %t163, !tbaa !24
  %t167 = icmp slt i64 %t160, %t164
  br i1 %t167, label %bb44, label %bb45
bb44:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load i64, ptr %l8, !tbaa !24
  %t173 = getelementptr %"compiler/typed:RefsKept", ptr %t169, i32 0, i32 3
  store i64 %t170, ptr %t173, !tbaa !24
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t174 = load i1, ptr %l9, !tbaa !21
  store i1 %t174, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2elinkLevel(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i64
  %rv = alloca i64
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 40
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v3, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load i1, ptr %l10, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i64 1, ptr %l11, !tbaa !24
  br label %bb4
bb3:
  store i64 2, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l11, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/typed:LocalUses", ptr %t10, i32 0, i32 41
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t12, i64 %t13)
  store i64 %t16, ptr %l15
  br label %bb5
bb5:
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = icmp slt i64 %t17, 0
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store ptr %a0, ptr %l18, !tbaa !29
  store ptr %a1, ptr %l19, !tbaa !29
  store ptr %a2, ptr %l20, !tbaa !29
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"compiler/typed:LocalUses", ptr %t25, i32 0, i32 41
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l24
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = getelementptr %"compiler/typed:LocalUses", ptr %t32, i32 0, i32 42
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v3, ptr %t34, i64 %t35)
  store i64 %t38, ptr %l28
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = load i64, ptr %l24, !tbaa !24
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2ecarries(ptr %v0, ptr %v1, ptr %v2, ptr %t39, ptr %t40, ptr %t41, i64 %t42, i64 %t43)
  store i64 %t44, ptr %l29
  br label %bb11
bb11:
  %t45 = load i64, ptr %l29, !tbaa !24
  store i64 %t45, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i64, ptr %l6, !tbaa !24
  store i64 %t52, ptr %l33, !tbaa !24
  br label %bb14
bb13:
  %t54 = load i64, ptr %l5, !tbaa !24
  store i64 %t54, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t56 = load i64, ptr %l33, !tbaa !24
  store i64 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eNamed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Versions", ptr %a0, i32 0, i32 10
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eReachInto(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eRowOf(ptr %v0, ptr %t2, i64 %a1)
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eReachRow(ptr %v0, ptr %v1, ptr %t9, i64 %t10, i64 %a2, ptr %a3)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eRowOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Versions", ptr %a0, i32 0, i32 10
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l20 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Versions", ptr %t5, i32 0, i32 16
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Block", ptr %t8, i32 0, i32 0
  %t11 = load i32, ptr %t10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t7, i32 %t11)
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Block", ptr %t14, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l20, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr ptr, ptr %t35, i64 %t32
  %t37 = load ptr, ptr %t36, !tbaa !39
  %t39 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %t39, ptr %t37)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb5
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Versions", ptr %t47, i32 0, i32 16
  %t51 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t49)
  %t52 = extractvalue { i32, i32 } %t51, 1
  %t53 = extractvalue { i32, i32 } %t51, 0
  store i32 %t53, ptr %l31
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb13, label %ok.55, !prof !99
ok.55:
  store i32 %t52, ptr %l30
  br label %bb12
bb12:
  %t56 = load i32, ptr %l30, !tbaa !23
  store i32 %t56, ptr %l27, !tbaa !23
  br label %bb20
bb13:
  %t57 = load i32, ptr %l31, !tbaa !23
  %t58 = icmp eq i32 %t57, 65536
  br i1 %t58, label %bb14, label %bb15
bb14:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1728180708920569_396f77e53f37dbed)
  unreachable
bb15:
  %t60 = load i32, ptr %l31, !tbaa !23
  %t61 = icmp eq i32 %t60, 65537
  br i1 %t61, label %bb16, label %bb17
bb16:
  call void @__olang_bang_failed_plain(ptr @olang_loc_64712ec69db6f686_5286ea6d6f8bc3a)
  unreachable
bb17:
  %t63 = load i32, ptr %l31, !tbaa !23
  %t64 = icmp eq i32 %t63, 65538
  br i1 %t64, label %bb18, label %bb19
bb18:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3937948e4172da86_b4226ee484a284a)
  unreachable
bb19:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e2e1378986f13fd0_6a804f95244a4cf4)
  unreachable
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edefine(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i32
  %l44 = alloca i64
  %l47 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l80 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Versions", ptr %t6, i32 0, i32 2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp sge i64 %t5, %t11
  store i1 %t14, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l14, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Versions", ptr %t17, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l22, !tbaa !27
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i1, ptr %t24, i64 %t21
  %t26 = load i1, ptr %t25, !tbaa !31
  %t28 = xor i1 %t26, true
  store i1 %t28, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Versions", ptr %t31, i32 0, i32 20
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t37, ptr %l29
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %l30, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Versions", ptr %t39, i32 0, i32 16
  store ptr %t41, ptr %l32, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Versions", ptr %t42, i32 0, i32 16
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l35
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t47 = load i64, ptr %l35, !tbaa !24
  %t48 = sub i64 %t47, 1
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t51 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t49, i64 %t48)
  store i32 %t51, ptr %l37
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l29
  %t56 = load i64, ptr %l30, !tbaa !24
  %t57 = load i32, ptr %l37, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eaddDef(ptr %v0, ptr %v1, ptr %t54, %"compiler/source:Span" %t55, i64 %t56, i32 %t57, ptr %a3, i1 %a4)
  br label %bb14
bb14:
  br label %ret
bb15:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t64 = sext i32 %t62 to i64
  %t65 = load i64, ptr %l2, !tbaa !24
  %t69 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eDefOf(ptr %v0, ptr %t60, i64 %t64, i64 %t65)
  store i64 %t69, ptr %l44
  br label %bb16
bb16:
  %t70 = load i64, ptr %l44, !tbaa !24
  store i64 %t70, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp slt i64 %t71, 0
  br i1 %t73, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb20
bb18:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %t75)
  store i1 %t77, ptr %l49
  br label %bb19
bb19:
  %t78 = load i1, ptr %l49, !tbaa !21
  store i1 %t78, ptr %l47, !tbaa !21
  br label %bb20
bb20:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb21, label %bb22
bb21:
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l6, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Versions", ptr %t80, i32 0, i32 3
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t82)
  store i64 %t84, ptr %l52
  br label %bb24
bb24:
  %t85 = load i64, ptr %l52, !tbaa !24
  store i64 %t85, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb30
bb27:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l59, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb29
bb29:
  %t112 = load i64, ptr %l59, !tbaa !24
  store i64 %t112, ptr %l56, !tbaa !24
  br label %bb30
bb30:
  %t113 = load i64, ptr %l56, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb31
bb31:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb32, label %bb33
bb32:
  br label %bb41
bb33:
  br label %bb34
bb34:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/typed:Versions", ptr %t132, i32 0, i32 3
  %t135 = load i64, ptr %l11, !tbaa !24
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t134, i64 %t135)
  store i64 %t138, ptr %l80
  br label %bb35
bb35:
  %t139 = load i64, ptr %l2, !tbaa !24
  %t140 = load i64, ptr %l80, !tbaa !24
  %t142 = icmp eq i64 %t140, %t139
  br i1 %t142, label %bb36, label %bb37
bb36:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Versions", ptr %t144, i32 0, i32 14
  %t147 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t146, i64 %t147, i64 -2)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t150 = load i64, ptr %l10, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l10, !tbaa !24
  br label %bb31
bb41:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/typed:Versions", ptr %t154, i32 0, i32 14
  %t157 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t156, i64 %t157, i64 -1)
  br label %bb42
bb42:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Versions", ptr %t160, i32 0, i32 15
  %t163 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t162, i64 %t163)
  br label %bb43
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Versions", ptr %t8, i32 0, i32 14
  store ptr %t10, ptr %l5, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Versions", ptr %t11, i32 0, i32 14
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l8
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t16 = load i64, ptr %l8, !tbaa !24
  %t17 = sub i64 %t16, 1
  %t18 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t17, i64 1)
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca i32
  %l47 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca ptr
  %l54 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l139 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l180 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l185 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l194 = alloca ptr
  %l195 = alloca i1
  %l208 = alloca { i64, ptr }
  %l218 = alloca ptr
  %l219 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i1
  %l233 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l236 = alloca i64
  %l241 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l246 = alloca i64
  %l251 = alloca i64
  %l254 = alloca i64
  %l272 = alloca ptr
  %l273 = alloca i64
  %l274 = alloca ptr
  %l277 = alloca i64
  %l280 = alloca i64
  %l281 = alloca i64
  %l284 = alloca ptr
  %l286 = alloca i64
  %l287 = alloca i64
  %l288 = alloca ptr
  %l290 = alloca i64
  %l292 = alloca i64
  %l296 = alloca i64
  %l300 = alloca i64
  %l303 = alloca i64
  %l321 = alloca ptr
  %l325 = alloca i64
  %l326 = alloca ptr
  %l327 = alloca ptr
  %l331 = alloca i64
  %l332 = alloca i64
  %l333 = alloca i64
  %l340 = alloca ptr
  %l341 = alloca i1
  %l346 = alloca ptr
  %l347 = alloca i1
  %l363 = alloca { i64, ptr }
  %l372 = alloca ptr
  %l373 = alloca i1
  %l385 = alloca ptr
  %l386 = alloca i1
  %l399 = alloca { i64, ptr }
  %l402 = alloca ptr
  %l403 = alloca i1
  %l413 = alloca ptr
  %l414 = alloca i1
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t6 = load ptr, ptr %l57, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l57, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l58, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l58, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t15 = load ptr, ptr %l61, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l61, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l62, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l62, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb222
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t24 = load ptr, ptr %l65, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l65, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l66, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l66, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb26
bb17:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t39 = load ptr, ptr %l71, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l71, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l72, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l72, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb26
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t54 = load ptr, ptr %l77, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l77, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l78, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l78, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb27
bb27:
  br label %bb222
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t73 = load ptr, ptr %l85, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb29, label %bb30
bb29:
  %t76 = load ptr, ptr %l85, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 5
  store i1 %t79, ptr %l86, !tbaa !21
  br label %bb30
bb30:
  %t80 = load i1, ptr %l86, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  br label %bb34
bb34:
  br label %bb222
bb35:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t96 = load ptr, ptr %l95, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l95, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 18}
  %t102 = icmp eq i64 %t100, 6
  store i1 %t102, ptr %l96, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l96, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb48
bb40:
  %t110 = load ptr, ptr %l4, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Call", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l5, !tbaa !29
  %t115 = load ptr, ptr %l5, !tbaa !29
  store ptr %t115, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t116 = load ptr, ptr %l103, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb41, label %bb42
bb41:
  %t119 = load ptr, ptr %l103, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 5}
  %t122 = icmp eq i64 %t120, 2
  store i1 %t122, ptr %l104, !tbaa !21
  br label %bb42
bb42:
  %t123 = load i1, ptr %l104, !tbaa !21
  br i1 %t123, label %bb43, label %bb44
bb43:
  %t124 = load ptr, ptr %l5, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { ptr }, ptr %t126, i32 0, i32 0
  %t128 = load ptr, ptr %t127
  %t130 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t130, ptr %t128)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Call", ptr %t136, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %t135, { i64, ptr } %t139)
  br label %bb47
bb47:
  br label %bb222
bb48:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t143 = load ptr, ptr %l115, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb49, label %bb50
bb49:
  %t146 = load ptr, ptr %l115, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 18}
  %t149 = icmp eq i64 %t147, 7
  store i1 %t149, ptr %l116, !tbaa !21
  br label %bb50
bb50:
  %t150 = load i1, ptr %l116, !tbaa !21
  br i1 %t150, label %bb51, label %bb52
bb51:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l7, !tbaa !29
  br label %bb53
bb52:
  br label %bb56
bb53:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l7, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Make", ptr %t158, i32 0, i32 2
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %t157, { i64, ptr } %t161)
  br label %bb54
bb54:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l7, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Make", ptr %t165, i32 0, i32 3
  %t168 = load ptr, ptr %t167, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t164, ptr %t168)
  br label %bb55
bb55:
  br label %bb222
bb56:
  %t171 = load ptr, ptr %l1, !tbaa !29
  store ptr %t171, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t172 = load ptr, ptr %l127, !tbaa !29
  %t173 = icmp ne ptr %t172, null
  br i1 %t173, label %bb57, label %bb58
bb57:
  %t175 = load ptr, ptr %l127, !tbaa !29
  %t176 = load i64, ptr %t175, !range !{i64 0, i64 18}
  %t178 = icmp eq i64 %t176, 8
  store i1 %t178, ptr %l128, !tbaa !21
  br label %bb58
bb58:
  %t179 = load i1, ptr %l128, !tbaa !21
  br i1 %t179, label %bb59, label %bb60
bb59:
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t182, i32 0, i32 2
  %t184 = load ptr, ptr %t183
  store ptr %t184, ptr %l8, !tbaa !29
  br label %bb61
bb60:
  br label %bb69
bb61:
  store %olang.scope zeroinitializer, ptr %s8
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Collect", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t186, ptr %t190)
  br label %bb62
bb62:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Collect", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t200 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eloop(ptr %v0, ptr %v1, ptr %v0, ptr %s8, ptr %t193, ptr %t197, ptr null)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t200, ptr %l139
  br label %bb63
bb63:
  %t201 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l139
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t201, ptr %l9
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %t202)
  store i1 %t204, ptr %l141
  br label %bb64
bb64:
  %t205 = load i1, ptr %l141, !tbaa !21
  br i1 %t205, label %bb65, label %bb66
bb65:
  %t206 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s8, ptr %t206, ptr %l9)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s8)
  br label %bb222
bb69:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t210 = load ptr, ptr %l144, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb70, label %bb71
bb70:
  %t213 = load ptr, ptr %l144, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 18}
  %t216 = icmp eq i64 %t214, 9
  store i1 %t216, ptr %l145, !tbaa !21
  br label %bb71
bb71:
  %t217 = load i1, ptr %l145, !tbaa !21
  br i1 %t217, label %bb72, label %bb73
bb72:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t220, i32 0, i32 4
  %t222 = load { i64, ptr }, ptr %t221
  store { i64, ptr } %t222, ptr %l10, !tbaa !27
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %t224, { i64, ptr } %t225)
  br label %bb75
bb75:
  br label %bb222
bb76:
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t229 = load ptr, ptr %l152, !tbaa !29
  %t230 = icmp ne ptr %t229, null
  br i1 %t230, label %bb77, label %bb78
bb77:
  %t232 = load ptr, ptr %l152, !tbaa !29
  %t233 = load i64, ptr %t232, !range !{i64 0, i64 18}
  %t235 = icmp eq i64 %t233, 10
  store i1 %t235, ptr %l153, !tbaa !21
  br label %bb78
bb78:
  %t236 = load i1, ptr %l153, !tbaa !21
  br i1 %t236, label %bb79, label %bb80
bb79:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t239, i32 0, i32 2
  %t241 = load ptr, ptr %t240
  store ptr %t241, ptr %l11, !tbaa !29
  br label %bb81
bb80:
  br label %bb85
bb81:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l11, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Slice", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %t243, ptr %t247)
  br label %bb82
bb82:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l11, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Slice", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t250, ptr %t254)
  br label %bb83
bb83:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %l11, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Slice", ptr %t259, i32 0, i32 2
  %t262 = load ptr, ptr %t261, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t258, ptr %t262)
  br label %bb84
bb84:
  br label %bb222
bb85:
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t267 = load ptr, ptr %l169, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %bb86, label %bb87
bb86:
  %t270 = load ptr, ptr %l169, !tbaa !29
  %t271 = load i64, ptr %t270, !range !{i64 0, i64 18}
  %t273 = icmp eq i64 %t271, 11
  store i1 %t273, ptr %l170, !tbaa !21
  br label %bb87
bb87:
  %t274 = load i1, ptr %l170, !tbaa !21
  br i1 %t274, label %bb88, label %bb89
bb88:
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr { i64, [5 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t277, i32 0, i32 2
  %t279 = load ptr, ptr %t278
  store ptr %t279, ptr %l12, !tbaa !29
  br label %bb90
bb89:
  br label %bb98
bb90:
  store %olang.scope zeroinitializer, ptr %s12
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l12, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Cond", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t281, ptr %t285)
  br label %bb91
bb91:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s12, ptr %t289)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t291, ptr %l180
  br label %bb92
bb92:
  %t292 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l180
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t292, ptr %l13
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l12, !tbaa !29
  %t296 = getelementptr %"compiler/typed:Cond", ptr %t294, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t293, ptr %t297)
  br label %bb93
bb93:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s12, ptr %t300)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t302, ptr %l185
  br label %bb94
bb94:
  %t303 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l185
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t303, ptr %l14
  %t304 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s12, ptr %t304, ptr %l13)
  br label %bb95
bb95:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load ptr, ptr %l12, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Cond", ptr %t308, i32 0, i32 2
  %t311 = load ptr, ptr %t310, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t307, ptr %t311)
  br label %bb96
bb96:
  %t315 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s12, ptr %t315, ptr %l14)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s12)
  br label %bb222
bb98:
  %t318 = load ptr, ptr %l1, !tbaa !29
  store ptr %t318, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t319 = load ptr, ptr %l194, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb99, label %bb100
bb99:
  %t322 = load ptr, ptr %l194, !tbaa !29
  %t323 = load i64, ptr %t322, !range !{i64 0, i64 18}
  %t325 = icmp eq i64 %t323, 12
  store i1 %t325, ptr %l195, !tbaa !21
  br label %bb100
bb100:
  %t326 = load i1, ptr %l195, !tbaa !21
  br i1 %t326, label %bb101, label %bb102
bb101:
  %t327 = load ptr, ptr %l1, !tbaa !29
  %t329 = getelementptr { i64, [5 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t329, i32 0, i32 2
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l15, !tbaa !29
  br label %bb103
bb102:
  br label %bb112
bb103:
  %t333 = load ptr, ptr %l15, !tbaa !29
  %t335 = getelementptr %"compiler/typed:Seq", ptr %t333, i32 0, i32 0
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  store { i64, ptr } %t336, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t338 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t338, 0
  store i64 %t340, ptr %l18, !tbaa !24
  br label %bb104
bb104:
  %t342 = load i64, ptr %l17, !tbaa !24
  %t343 = load i64, ptr %l18, !tbaa !24
  %t346 = icmp slt i64 %t342, %t343
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb105, label %bb106
bb105:
  br label %bb110
bb106:
  br label %bb107
bb107:
  %t350 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t350, ptr %l208, !tbaa !27
  %t351 = load i64, ptr %l17, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 %t351
  %t356 = load ptr, ptr %t355, !tbaa !39
  %t358 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %t358, ptr %t356)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t362 = load i64, ptr %l17, !tbaa !24
  %t364 = add i64 %t362, 1
  store i64 %t364, ptr %l17, !tbaa !24
  br label %bb104
bb110:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load ptr, ptr %l15, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Seq", ptr %t367, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t366, ptr %t370)
  br label %bb111
bb111:
  br label %bb222
bb112:
  %t373 = load ptr, ptr %l1, !tbaa !29
  store ptr %t373, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t374 = load ptr, ptr %l218, !tbaa !29
  %t375 = icmp ne ptr %t374, null
  br i1 %t375, label %bb113, label %bb114
bb113:
  %t377 = load ptr, ptr %l218, !tbaa !29
  %t378 = load i64, ptr %t377, !range !{i64 0, i64 18}
  %t380 = icmp eq i64 %t378, 13
  store i1 %t380, ptr %l219, !tbaa !21
  br label %bb114
bb114:
  %t381 = load i1, ptr %l219, !tbaa !21
  br i1 %t381, label %bb115, label %bb116
bb115:
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t384 = getelementptr { i64, [5 x i64] }, ptr %t382, i32 0, i32 1
  %t385 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t384, i32 0, i32 2
  %t386 = load ptr, ptr %t385
  store ptr %t386, ptr %l20, !tbaa !29
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ematch(ptr %v0, ptr %v1, ptr %t388, ptr %t389)
  br label %bb118
bb118:
  br label %bb222
bb119:
  %t392 = load ptr, ptr %l1, !tbaa !29
  store ptr %t392, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t393 = load ptr, ptr %l226, !tbaa !29
  %t394 = icmp ne ptr %t393, null
  br i1 %t394, label %bb120, label %bb121
bb120:
  %t396 = load ptr, ptr %l226, !tbaa !29
  %t397 = load i64, ptr %t396, !range !{i64 0, i64 18}
  %t399 = icmp eq i64 %t397, 14
  store i1 %t399, ptr %l227, !tbaa !21
  br label %bb121
bb121:
  %t400 = load i1, ptr %l227, !tbaa !21
  br i1 %t400, label %bb122, label %bb123
bb122:
  %t401 = load ptr, ptr %l1, !tbaa !29
  %t403 = getelementptr { i64, [5 x i64] }, ptr %t401, i32 0, i32 1
  %t404 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t403, i32 0, i32 2
  %t405 = load ptr, ptr %t404
  store ptr %t405, ptr %l21, !tbaa !29
  br label %bb124
bb123:
  br label %bb172
bb124:
  store %olang.scope zeroinitializer, ptr %s18
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s18, ptr %t407)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t409, ptr %l233
  br label %bb125
bb125:
  %t410 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l233
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t410, ptr %l22
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/typed:Versions", ptr %t411, i32 0, i32 15
  %t415 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t413)
  store i64 %t415, ptr %l236
  br label %bb126
bb126:
  %t416 = load i64, ptr %l236, !tbaa !24
  store i64 %t416, ptr %l23, !tbaa !24
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load ptr, ptr %l21, !tbaa !29
  %t420 = getelementptr %"compiler/typed:Try", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t417, ptr %t421)
  br label %bb127
bb127:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s18, ptr %t424)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t426, ptr %l241
  br label %bb128
bb128:
  %t427 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l241
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t427, ptr %l24
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/typed:Versions", ptr %t428, i32 0, i32 20
  %t431 = load i1, ptr %t430, !tbaa !21
  %t433 = xor i1 %t431, true
  br i1 %t433, label %bb129, label %bb130
bb129:
  store i64 0, ptr %l25, !tbaa !24
  %t436 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %l22)
  store i64 %t436, ptr %l246
  br label %bb131
bb130:
  br label %bb170
bb131:
  %t437 = load i64, ptr %l246, !tbaa !24
  %t438 = sub i64 %t437, 1
  store i64 %t438, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t440 = load i64, ptr %l26, !tbaa !24
  %t441 = load i64, ptr %l25, !tbaa !24
  %t444 = icmp sgt i64 %t440, %t441
  br i1 %t444, label %bb132, label %bb133
bb132:
  %t446 = load i64, ptr %l27, !tbaa !24
  %t448 = icmp sgt i64 %t446, 0
  br i1 %t448, label %bb134, label %bb135
bb133:
  store i64 0, ptr %l251, !tbaa !24
  br label %bb137
bb134:
  %t450 = load i64, ptr %l26, !tbaa !24
  %t451 = load i64, ptr %l25, !tbaa !24
  %t454 = sub i64 %t450, %t451
  %t455 = load i64, ptr %l27, !tbaa !24
  %t458 = add i64 %t454, %t455
  %t460 = sub i64 %t458, 1
  %t461 = load i64, ptr %l27, !tbaa !24
  %t464 = sdiv i64 %t460, %t461
  store i64 %t464, ptr %l254, !tbaa !24
  br label %bb136
bb135:
  store i64 0, ptr %l254, !tbaa !24
  br label %bb136
bb136:
  %t466 = load i64, ptr %l254, !tbaa !24
  store i64 %t466, ptr %l251, !tbaa !24
  br label %bb137
bb137:
  %t467 = load i64, ptr %l251, !tbaa !24
  store i64 %t467, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb138
bb138:
  %t468 = load i64, ptr %l29, !tbaa !24
  %t469 = load i64, ptr %l28, !tbaa !24
  %t472 = icmp slt i64 %t468, %t469
  %t474 = xor i1 %t472, true
  br i1 %t474, label %bb139, label %bb140
bb139:
  br label %bb147
bb140:
  br label %bb141
bb141:
  %t476 = load i64, ptr %l25, !tbaa !24
  %t477 = load i64, ptr %l29, !tbaa !24
  %t478 = load i64, ptr %l27, !tbaa !24
  %t481 = mul i64 %t477, %t478
  %t484 = add i64 %t476, %t481
  store i64 %t484, ptr %l30, !tbaa !24
  store ptr %l24, ptr %l272, !tbaa !29
  %t486 = load i64, ptr %l30, !tbaa !24
  store i64 %t486, ptr %l273, !tbaa !24
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l274, !tbaa !29
  %t488 = load i64, ptr %l30, !tbaa !24
  %t491 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l24, i64 %t488)
  store i64 %t491, ptr %l277
  br label %bb142
bb142:
  %t492 = load i64, ptr %l30, !tbaa !24
  %t495 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l22, i64 %t492)
  store i64 %t495, ptr %l280
  br label %bb143
bb143:
  %t496 = load ptr, ptr %l274, !tbaa !29
  %t497 = load i64, ptr %l277, !tbaa !24
  %t498 = load i64, ptr %l280, !tbaa !24
  %t499 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t496, i64 %t497, i64 %t498)
  store i64 %t499, ptr %l281
  br label %bb144
bb144:
  %t500 = load ptr, ptr %l272, !tbaa !29
  %t501 = load i64, ptr %l273, !tbaa !24
  %t502 = load i64, ptr %l281, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s18, ptr %t500, i64 %t501, i64 %t502)
  br label %bb145
bb145:
  br label %bb146
bb146:
  %t503 = load i64, ptr %l29, !tbaa !24
  %t505 = add i64 %t503, 1
  store i64 %t505, ptr %l29, !tbaa !24
  br label %bb138
bb147:
  store ptr %l24, ptr %l284, !tbaa !29
  %t508 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %l22)
  store i64 %t508, ptr %l286
  br label %bb148
bb148:
  %t509 = load i64, ptr %l286, !tbaa !24
  %t510 = sub i64 %t509, 1
  store i64 %t510, ptr %l287, !tbaa !24
  store ptr %l22, ptr %l288, !tbaa !29
  %t512 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %l22)
  store i64 %t512, ptr %l290
  br label %bb149
bb149:
  %t513 = load i64, ptr %l290, !tbaa !24
  %t514 = sub i64 %t513, 1
  %t515 = load ptr, ptr %l288, !tbaa !29
  %t517 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %t515, i64 %t514)
  store i64 %t517, ptr %l292
  br label %bb150
bb150:
  %t518 = load ptr, ptr %l284, !tbaa !29
  %t519 = load i64, ptr %l287, !tbaa !24
  %t520 = load i64, ptr %l292, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s18, ptr %t518, i64 %t519, i64 %t520)
  br label %bb151
bb151:
  %t521 = load i64, ptr %l23, !tbaa !24
  store i64 %t521, ptr %l31, !tbaa !24
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t525 = getelementptr %"compiler/typed:Versions", ptr %t523, i32 0, i32 15
  %t527 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t525)
  store i64 %t527, ptr %l296
  br label %bb152
bb152:
  %t528 = load i64, ptr %l296, !tbaa !24
  store i64 %t528, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t529 = load i64, ptr %l32, !tbaa !24
  %t530 = load i64, ptr %l31, !tbaa !24
  %t533 = icmp sgt i64 %t529, %t530
  br i1 %t533, label %bb153, label %bb154
bb153:
  %t535 = load i64, ptr %l33, !tbaa !24
  %t537 = icmp sgt i64 %t535, 0
  br i1 %t537, label %bb155, label %bb156
bb154:
  store i64 0, ptr %l300, !tbaa !24
  br label %bb158
bb155:
  %t539 = load i64, ptr %l32, !tbaa !24
  %t540 = load i64, ptr %l31, !tbaa !24
  %t543 = sub i64 %t539, %t540
  %t544 = load i64, ptr %l33, !tbaa !24
  %t547 = add i64 %t543, %t544
  %t549 = sub i64 %t547, 1
  %t550 = load i64, ptr %l33, !tbaa !24
  %t553 = sdiv i64 %t549, %t550
  store i64 %t553, ptr %l303, !tbaa !24
  br label %bb157
bb156:
  store i64 0, ptr %l303, !tbaa !24
  br label %bb157
bb157:
  %t555 = load i64, ptr %l303, !tbaa !24
  store i64 %t555, ptr %l300, !tbaa !24
  br label %bb158
bb158:
  %t556 = load i64, ptr %l300, !tbaa !24
  store i64 %t556, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb159
bb159:
  %t557 = load i64, ptr %l35, !tbaa !24
  %t558 = load i64, ptr %l34, !tbaa !24
  %t561 = icmp slt i64 %t557, %t558
  %t563 = xor i1 %t561, true
  br i1 %t563, label %bb160, label %bb161
bb160:
  br label %bb169
bb161:
  br label %bb162
bb162:
  %t565 = load i64, ptr %l31, !tbaa !24
  %t566 = load i64, ptr %l35, !tbaa !24
  %t567 = load i64, ptr %l33, !tbaa !24
  %t570 = mul i64 %t566, %t567
  %t573 = add i64 %t565, %t570
  store i64 %t573, ptr %l36, !tbaa !24
  store ptr %l24, ptr %l321, !tbaa !29
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t577 = getelementptr %"compiler/typed:Versions", ptr %t575, i32 0, i32 15
  %t578 = load i64, ptr %l36, !tbaa !24
  %t581 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t577, i64 %t578)
  store i64 %t581, ptr %l325
  br label %bb163
bb163:
  %t582 = load ptr, ptr %l0, !tbaa !29
  store ptr %t582, ptr %l326, !tbaa !29
  store ptr %l24, ptr %l327, !tbaa !29
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t585 = getelementptr %"compiler/typed:Versions", ptr %t583, i32 0, i32 15
  %t586 = load i64, ptr %l36, !tbaa !24
  %t589 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t585, i64 %t586)
  store i64 %t589, ptr %l331
  br label %bb164
bb164:
  %t590 = load ptr, ptr %l327, !tbaa !29
  %t591 = load i64, ptr %l331, !tbaa !24
  %t592 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %t590, i64 %t591)
  store i64 %t592, ptr %l332
  br label %bb165
bb165:
  %t593 = load ptr, ptr %l326, !tbaa !29
  %t594 = load i64, ptr %l332, !tbaa !24
  %t595 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t593, i64 %t594, i64 -1)
  store i64 %t595, ptr %l333
  br label %bb166
bb166:
  %t596 = load ptr, ptr %l321, !tbaa !29
  %t597 = load i64, ptr %l325, !tbaa !24
  %t598 = load i64, ptr %l333, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s18, ptr %t596, i64 %t597, i64 %t598)
  br label %bb167
bb167:
  br label %bb168
bb168:
  %t599 = load i64, ptr %l35, !tbaa !24
  %t601 = add i64 %t599, 1
  store i64 %t601, ptr %l35, !tbaa !24
  br label %bb159
bb169:
  br label %bb170
bb170:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load ptr, ptr %l21, !tbaa !29
  %t606 = getelementptr %"compiler/typed:Try", ptr %t604, i32 0, i32 1
  %t607 = load { i64, ptr }, ptr %t606, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclauses(ptr %v0, ptr %v1, ptr %s18, ptr %t603, { i64, ptr } %t607, ptr %l24, i1 false)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s18)
  br label %bb222
bb172:
  %t611 = load ptr, ptr %l1, !tbaa !29
  store ptr %t611, ptr %l340, !tbaa !29
  store i1 false, ptr %l341, !tbaa !21
  %t612 = load ptr, ptr %l340, !tbaa !29
  %t613 = icmp ne ptr %t612, null
  br i1 %t613, label %bb173, label %bb174
bb173:
  %t615 = load ptr, ptr %l340, !tbaa !29
  %t616 = load i64, ptr %t615, !range !{i64 0, i64 18}
  %t618 = icmp eq i64 %t616, 15
  store i1 %t618, ptr %l341, !tbaa !21
  br label %bb174
bb174:
  %t619 = load i1, ptr %l341, !tbaa !21
  br i1 %t619, label %bb175, label %bb176
bb175:
  %t620 = load ptr, ptr %l1, !tbaa !29
  %t622 = getelementptr { i64, [5 x i64] }, ptr %t620, i32 0, i32 1
  %t623 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t622, i32 0, i32 2
  %t624 = load ptr, ptr %t623
  store ptr %t624, ptr %l37, !tbaa !29
  br label %bb177
bb176:
  br label %bb196
bb177:
  %t626 = load ptr, ptr %l37, !tbaa !29
  store ptr %t626, ptr %l346, !tbaa !29
  store i1 false, ptr %l347, !tbaa !21
  %t627 = load ptr, ptr %l346, !tbaa !29
  %t628 = icmp ne ptr %t627, null
  br i1 %t628, label %bb178, label %bb179
bb178:
  %t630 = load ptr, ptr %l346, !tbaa !29
  %t631 = load i64, ptr %t630, !range !{i64 0, i64 3}
  %t633 = icmp eq i64 %t631, 1
  store i1 %t633, ptr %l347, !tbaa !21
  br label %bb179
bb179:
  %t634 = load i1, ptr %l347, !tbaa !21
  br i1 %t634, label %bb180, label %bb181
bb180:
  %t635 = load ptr, ptr %l37, !tbaa !29
  %t637 = getelementptr { i64, [4 x i64] }, ptr %t635, i32 0, i32 1
  %t638 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t637, i32 0, i32 0
  %t639 = load i32, ptr %t638
  store i32 %t639, ptr %l38, !tbaa !23
  %t641 = load ptr, ptr %l37, !tbaa !29
  %t643 = getelementptr { i64, [4 x i64] }, ptr %t641, i32 0, i32 1
  %t644 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t643, i32 0, i32 1
  %t645 = load { i64, ptr }, ptr %t644
  %t647 = load ptr, ptr %l37, !tbaa !29
  %t649 = getelementptr { i64, [4 x i64] }, ptr %t647, i32 0, i32 1
  %t650 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t649, i32 0, i32 2
  %t651 = load i32, ptr %t650
  store i32 %t651, ptr %l40, !tbaa !23
  store { i64, ptr } %t645, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t655 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t657 = extractvalue { i64, ptr } %t655, 0
  store i64 %t657, ptr %l43, !tbaa !24
  br label %bb182
bb181:
  br label %bb189
bb182:
  %t659 = load i64, ptr %l42, !tbaa !24
  %t660 = load i64, ptr %l43, !tbaa !24
  %t663 = icmp slt i64 %t659, %t660
  %t665 = xor i1 %t663, true
  br i1 %t665, label %bb183, label %bb184
bb183:
  br label %bb188
bb184:
  br label %bb185
bb185:
  %t667 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t667, ptr %l363, !tbaa !27
  %t668 = load i64, ptr %l42, !tbaa !24
  %t670 = getelementptr { i64, ptr }, ptr %l363, i32 0, i32 1
  %t671 = load ptr, ptr %t670, !tbaa !27
  %t672 = getelementptr ptr, ptr %t671, i64 %t668
  %t673 = load ptr, ptr %t672, !tbaa !39
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t678 = getelementptr %"compiler/typed:Capture", ptr %t673, i32 0, i32 1
  %t679 = load ptr, ptr %t678, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t675, ptr %t679)
  br label %bb186
bb186:
  br label %bb187
bb187:
  %t683 = load i64, ptr %l42, !tbaa !24
  %t685 = add i64 %t683, 1
  store i64 %t685, ptr %l42, !tbaa !24
  br label %bb182
bb188:
  br label %bb189
bb189:
  %t687 = load ptr, ptr %l37, !tbaa !29
  store ptr %t687, ptr %l372, !tbaa !29
  store i1 false, ptr %l373, !tbaa !21
  %t688 = load ptr, ptr %l372, !tbaa !29
  %t689 = icmp ne ptr %t688, null
  br i1 %t689, label %bb190, label %bb191
bb190:
  %t691 = load ptr, ptr %l372, !tbaa !29
  %t692 = load i64, ptr %t691, !range !{i64 0, i64 3}
  %t694 = icmp eq i64 %t692, 2
  store i1 %t694, ptr %l373, !tbaa !21
  br label %bb191
bb191:
  %t695 = load i1, ptr %l373, !tbaa !21
  br i1 %t695, label %bb192, label %bb193
bb192:
  %t696 = load ptr, ptr %l37, !tbaa !29
  %t698 = getelementptr { i64, [4 x i64] }, ptr %t696, i32 0, i32 1
  %t699 = getelementptr { i32, ptr, i32 }, ptr %t698, i32 0, i32 0
  %t700 = load i32, ptr %t699
  store i32 %t700, ptr %l45, !tbaa !23
  %t702 = load ptr, ptr %l37, !tbaa !29
  %t704 = getelementptr { i64, [4 x i64] }, ptr %t702, i32 0, i32 1
  %t705 = getelementptr { i32, ptr, i32 }, ptr %t704, i32 0, i32 1
  %t706 = load ptr, ptr %t705
  %t708 = load ptr, ptr %l37, !tbaa !29
  %t710 = getelementptr { i64, [4 x i64] }, ptr %t708, i32 0, i32 1
  %t711 = getelementptr { i32, ptr, i32 }, ptr %t710, i32 0, i32 2
  %t712 = load i32, ptr %t711
  store i32 %t712, ptr %l47, !tbaa !23
  %t714 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t714, ptr %t706)
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb195
bb195:
  br label %bb222
bb196:
  %t719 = load ptr, ptr %l1, !tbaa !29
  store ptr %t719, ptr %l385, !tbaa !29
  store i1 false, ptr %l386, !tbaa !21
  %t720 = load ptr, ptr %l385, !tbaa !29
  %t721 = icmp ne ptr %t720, null
  br i1 %t721, label %bb197, label %bb198
bb197:
  %t723 = load ptr, ptr %l385, !tbaa !29
  %t724 = load i64, ptr %t723, !range !{i64 0, i64 18}
  %t726 = icmp eq i64 %t724, 16
  store i1 %t726, ptr %l386, !tbaa !21
  br label %bb198
bb198:
  %t727 = load i1, ptr %l386, !tbaa !21
  br i1 %t727, label %bb199, label %bb200
bb199:
  %t728 = load ptr, ptr %l1, !tbaa !29
  %t730 = getelementptr { i64, [5 x i64] }, ptr %t728, i32 0, i32 1
  %t731 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t730, i32 0, i32 2
  %t732 = load ptr, ptr %t731
  store ptr %t732, ptr %l48, !tbaa !29
  br label %bb201
bb200:
  br label %bb214
bb201:
  %t734 = load ptr, ptr %l48, !tbaa !29
  %t736 = getelementptr %"compiler/typed:Text", ptr %t734, i32 0, i32 0
  %t737 = load { i64, ptr }, ptr %t736, !tbaa !27
  store { i64, ptr } %t737, ptr %l49, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  %t739 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t741 = extractvalue { i64, ptr } %t739, 0
  store i64 %t741, ptr %l51, !tbaa !24
  br label %bb202
bb202:
  %t743 = load i64, ptr %l50, !tbaa !24
  %t744 = load i64, ptr %l51, !tbaa !24
  %t747 = icmp slt i64 %t743, %t744
  %t749 = xor i1 %t747, true
  br i1 %t749, label %bb203, label %bb204
bb203:
  br label %bb213
bb204:
  br label %bb205
bb205:
  %t751 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t751, ptr %l399, !tbaa !27
  %t752 = load i64, ptr %l50, !tbaa !24
  %t754 = getelementptr { i64, ptr }, ptr %l399, i32 0, i32 1
  %t755 = load ptr, ptr %t754, !tbaa !27
  %t756 = getelementptr ptr, ptr %t755, i64 %t752
  %t757 = load ptr, ptr %t756, !tbaa !39
  store ptr %t757, ptr %l52, !tbaa !29
  %t759 = load ptr, ptr %l52, !tbaa !29
  store ptr %t759, ptr %l402, !tbaa !29
  store i1 false, ptr %l403, !tbaa !21
  %t760 = load ptr, ptr %l402, !tbaa !29
  %t761 = icmp ne ptr %t760, null
  br i1 %t761, label %bb206, label %bb207
bb206:
  %t763 = load ptr, ptr %l402, !tbaa !29
  %t764 = load i64, ptr %t763, !range !{i64 0, i64 2}
  %t766 = icmp eq i64 %t764, 1
  store i1 %t766, ptr %l403, !tbaa !21
  br label %bb207
bb207:
  %t767 = load i1, ptr %l403, !tbaa !21
  br i1 %t767, label %bb208, label %bb209
bb208:
  %t768 = load ptr, ptr %l52, !tbaa !29
  %t770 = getelementptr { i64, [2 x i64] }, ptr %t768, i32 0, i32 1
  %t771 = getelementptr { ptr }, ptr %t770, i32 0, i32 0
  %t772 = load ptr, ptr %t771
  %t774 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t774, ptr %t772)
  br label %bb210
bb209:
  br label %bb211
bb210:
  br label %bb211
bb211:
  br label %bb212
bb212:
  %t779 = load i64, ptr %l50, !tbaa !24
  %t781 = add i64 %t779, 1
  store i64 %t781, ptr %l50, !tbaa !24
  br label %bb202
bb213:
  br label %bb222
bb214:
  %t783 = load ptr, ptr %l1, !tbaa !29
  store ptr %t783, ptr %l413, !tbaa !29
  store i1 false, ptr %l414, !tbaa !21
  %t784 = load ptr, ptr %l413, !tbaa !29
  %t785 = icmp ne ptr %t784, null
  br i1 %t785, label %bb215, label %bb216
bb215:
  %t787 = load ptr, ptr %l413, !tbaa !29
  %t788 = load i64, ptr %t787, !range !{i64 0, i64 18}
  %t790 = icmp eq i64 %t788, 17
  store i1 %t790, ptr %l414, !tbaa !21
  br label %bb216
bb216:
  %t791 = load i1, ptr %l414, !tbaa !21
  br i1 %t791, label %bb217, label %bb218
bb217:
  %t792 = load ptr, ptr %l1, !tbaa !29
  %t794 = getelementptr { i64, [5 x i64] }, ptr %t792, i32 0, i32 1
  %t795 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t794, i32 0, i32 2
  %t796 = load ptr, ptr %t795
  store ptr %t796, ptr %l54, !tbaa !29
  br label %bb219
bb218:
  br label %bb221
bb219:
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t799 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t798, ptr %t799)
  br label %bb220
bb220:
  br label %bb222
bb221:
  call void @__olang_check_failed(ptr @olang_loc_77315c1e1ec03e98_be22ee0dd90c53a4)
  unreachable
bb222:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca ptr
  %l39 = alloca i64
  %l49 = alloca { i64, ptr }
  %l58 = alloca i64
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca ptr
  %l81 = alloca i64
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l20, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %t26, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s0, ptr %t34)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l28
  br label %bb8
bb8:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l6
  %t38 = ptrtoint ptr %s0 to i64
  store i64 %t38, ptr %l29, !tbaa !24
  %t39 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = call ptr @__olang_region_make(ptr %s0)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l29, !tbaa !24
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l29
  %t45 = inttoptr i64 %t44 to ptr
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %t45, ptr %t43)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l32
  br label %bb11
bb11:
  %t48 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t50 = load i64, ptr %l29
  %t51 = inttoptr i64 %t50 to ptr
  %t52 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32, i32 0, i32 0
  %t53 = load { i64, ptr }, ptr %t52
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = call ptr @__olang_region_or(ptr %t54, ptr null)
  %t56 = call ptr @__olang_region_home(ptr %t55)
  %t57 = icmp ne ptr %t56, null
  %t58 = select i1 %t57, ptr %t56, ptr null
  %t59 = icmp eq ptr %t58, %t51
  call void @__olang_region_settle(ptr %t51, i1 %t59)
  br label %bb13
bb13:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l7
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Versions", ptr %t61, i32 0, i32 20
  %t64 = load i1, ptr %t63, !tbaa !21
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb14, label %bb15
bb14:
  store ptr %l7, ptr %l37, !tbaa !29
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t69, ptr %l39
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t70 = load i64, ptr %l39, !tbaa !24
  %t71 = sub i64 %t70, 1
  %t72 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s0, ptr %t72, i64 %t71, i64 1)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Match", ptr %t74, i32 0, i32 1
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  store i64 %t81, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t83 = load i64, ptr %l9, !tbaa !24
  %t84 = load i64, ptr %l10, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb20, label %bb21
bb20:
  br label %bb34
bb21:
  br label %bb22
bb22:
  %t91 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t91, ptr %l49, !tbaa !27
  %t92 = load i64, ptr %l9, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 %t92
  %t97 = load ptr, ptr %t96, !tbaa !39
  store ptr %t97, ptr %l11, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t99, ptr %l6)
  br label %bb23
bb23:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2earm(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  br label %bb24
bb24:
  %t106 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s0, ptr %t106, ptr %l7)
  br label %bb25
bb25:
  %t109 = ptrtoint ptr %s0 to i64
  store i64 %t109, ptr %l58, !tbaa !24
  %t110 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t112 = call ptr @__olang_region_make(ptr %s0)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l58, !tbaa !24
  br label %bb27
bb27:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i64, ptr %l58
  %t116 = inttoptr i64 %t115 to ptr
  %t118 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %t116, ptr %t114)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l61
  br label %bb28
bb28:
  %t119 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t119, label %bb29, label %bb30
bb29:
  %t121 = load i64, ptr %l58
  %t122 = inttoptr i64 %t121 to ptr
  %t123 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123
  %t125 = extractvalue { i64, ptr } %t124, 1
  %t126 = call ptr @__olang_region_or(ptr %t125, ptr null)
  %t127 = call ptr @__olang_region_home(ptr %t126)
  %t128 = icmp ne ptr %t127, null
  %t129 = select i1 %t128, ptr %t127, ptr null
  %t130 = icmp eq ptr %t129, %t122
  call void @__olang_region_settle(ptr %t122, i1 %t130)
  br label %bb30
bb30:
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l63
  %t132 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %l7
  %t133 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t133, label %bb31, label %bb32
bb31:
  %t135 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = call ptr @__olang_region_or(ptr %t137, ptr null)
  %t139 = call ptr @__olang_region_home(ptr %t138)
  %t140 = icmp ne ptr %t139, null
  %t141 = select i1 %t140, ptr %t139, ptr null
  call void @__olang_region_drop(ptr %t141)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l63
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t142 = load i64, ptr %l9, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l9, !tbaa !24
  br label %bb19
bb34:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Match", ptr %t146, i32 0, i32 2
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb35, label %bb36
bb35:
  %t155 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t155, ptr %l6)
  br label %bb37
bb36:
  br label %bb50
bb37:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l73, !tbaa !29
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Match", ptr %t159, i32 0, i32 2
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_456f0c0b74db68d5_29242d1724c8a7c1)
  unreachable
bb39:
  br label %bb40
bb40:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Match", ptr %t166, i32 0, i32 2
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t170 = load ptr, ptr %l73, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2earm(ptr %v0, ptr %v1, ptr %t170, ptr %t169)
  br label %bb41
bb41:
  %t172 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s0, ptr %t172, ptr %l7)
  br label %bb42
bb42:
  %t175 = ptrtoint ptr %s0 to i64
  store i64 %t175, ptr %l81, !tbaa !24
  %t176 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t176, label %bb43, label %bb44
bb43:
  %t178 = call ptr @__olang_region_make(ptr %s0)
  %t179 = ptrtoint ptr %t178 to i64
  store i64 %t179, ptr %l81, !tbaa !24
  br label %bb44
bb44:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l81
  %t182 = inttoptr i64 %t181 to ptr
  %t184 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %t182, ptr %t180)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %l84
  br label %bb45
bb45:
  %t185 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t185, label %bb46, label %bb47
bb46:
  %t187 = load i64, ptr %l81
  %t188 = inttoptr i64 %t187 to ptr
  %t189 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84, i32 0, i32 0
  %t190 = load { i64, ptr }, ptr %t189
  %t191 = extractvalue { i64, ptr } %t190, 1
  %t192 = call ptr @__olang_region_or(ptr %t191, ptr null)
  %t193 = call ptr @__olang_region_home(ptr %t192)
  %t194 = icmp ne ptr %t193, null
  %t195 = select i1 %t194, ptr %t193, ptr null
  %t196 = icmp eq ptr %t195, %t188
  call void @__olang_region_settle(ptr %t188, i1 %t196)
  br label %bb47
bb47:
  %t197 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t197, ptr %l86
  %t198 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t198, ptr %l7
  %t199 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7
  br i1 %t199, label %bb48, label %bb49
bb48:
  %t201 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86, i32 0, i32 0
  %t202 = load { i64, ptr }, ptr %t201
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = call ptr @__olang_region_or(ptr %t203, ptr null)
  %t205 = call ptr @__olang_region_home(ptr %t204)
  %t206 = icmp ne ptr %t205, null
  %t207 = select i1 %t206, ptr %t205, ptr null
  call void @__olang_region_drop(ptr %t207)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l86
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t208 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t208, ptr %l7)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca ptr
  %l58 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Versions", ptr %t6, i32 0, i32 14
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l13
  br label %bb4
bb4:
  %t11 = load i64, ptr %l13, !tbaa !24
  %t12 = sub i64 %t11, 1
  store i64 %t12, ptr %l2, !tbaa !24
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t14, i64 %t15)
  store i64 %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = icmp ne i64 %t19, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Versions", ptr %t22, i32 0, i32 14
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t28, ptr %l22
  br label %bb9
bb9:
  %t29 = load i64, ptr %l22, !tbaa !24
  %t30 = icmp ne i64 %t29, 0
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %ret
bb13:
  store i64 0, ptr %l3, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  store i64 %t36, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb14, label %bb15
bb14:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb19
bb16:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l33, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb18
bb18:
  %t64 = load i64, ptr %l33, !tbaa !24
  store i64 %t64, ptr %l30, !tbaa !24
  br label %bb19
bb19:
  %t65 = load i64, ptr %l30, !tbaa !24
  store i64 %t65, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb20
bb20:
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb21, label %bb22
bb21:
  br label %bb29
bb22:
  br label %bb23
bb23:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l5, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store i64 %t82, ptr %l8, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Versions", ptr %t84, i32 0, i32 14
  store ptr %t86, ptr %l52, !tbaa !29
  %t87 = load i64, ptr %l8, !tbaa !24
  store i64 %t87, ptr %l53, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l54, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Versions", ptr %t89, i32 0, i32 14
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l58
  br label %bb24
bb24:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t97 = load i64, ptr %l8, !tbaa !24
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t96, i64 %t97)
  store i64 %t100, ptr %l61
  br label %bb25
bb25:
  %t101 = load ptr, ptr %l54, !tbaa !29
  %t102 = load i64, ptr %l58, !tbaa !24
  %t103 = load i64, ptr %l61, !tbaa !24
  %t104 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t101, i64 %t102, i64 %t103)
  store i64 %t104, ptr %l62
  br label %bb26
bb26:
  %t105 = load ptr, ptr %l52, !tbaa !29
  %t106 = load i64, ptr %l53, !tbaa !24
  %t107 = load i64, ptr %l62, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t105, i64 %t106, i64 %t107)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t108 = load i64, ptr %l7, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb20
bb29:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esettle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l78 = alloca { i64, ptr }
  %l81 = alloca i64
  %l83 = alloca ptr
  %l86 = alloca %"compiler/source:Span"
  %l89 = alloca i64
  %l92 = alloca i32
  %l95 = alloca ptr
  %l98 = alloca i1
  %l103 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i64
  %l131 = alloca i64
  %l135 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i64
  %l140 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca i32
  %l153 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 3
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l20
  %t6 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l20)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l22
  br label %bb1
bb1:
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Versions", ptr %t8, i32 0, i32 4
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l24
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l24)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l26
  br label %bb2
bb2:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l2
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Versions", ptr %t15, i32 0, i32 5
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l28
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e(ptr %s0, ptr %l28)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l30
  br label %bb3
bb3:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l3
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Versions", ptr %t22, i32 0, i32 6
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l32
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %l32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l34
  br label %bb4
bb4:
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store ptr %t28, ptr %lp4
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  %t30 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %t30
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Versions", ptr %t31, i32 0, i32 7
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l36
  %t36 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %s0, ptr %l36)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l38
  br label %bb5
bb5:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l5
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Versions", ptr %t38, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t40)
  br label %bb6
bb6:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Versions", ptr %t42, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t44)
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Versions", ptr %t46, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t48)
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Versions", ptr %t50, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eCle_H9e31dbf06df58c38226424712d120dfe(ptr %v0, ptr %t52)
  br label %bb9
bb9:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Versions", ptr %t54, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t56)
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Versions", ptr %t58, i32 0, i32 8
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t60)
  br label %bb11
bb11:
  store i64 0, ptr %l6, !tbaa !24
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l1)
  store i64 %t63, ptr %l52
  br label %bb12
bb12:
  %t64 = load i64, ptr %l52, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb18
bb15:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l8, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l59, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb17
bb17:
  %t91 = load i64, ptr %l59, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  br label %bb18
bb18:
  %t92 = load i64, ptr %l56, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb34
bb21:
  br label %bb22
bb22:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l11, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Versions", ptr %t111, i32 0, i32 2
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l78, !tbaa !27
  %t115 = load i64, ptr %l11, !tbaa !24
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l1, i64 %t115)
  store i64 %t118, ptr %l81
  br label %bb23
bb23:
  %t119 = load i64, ptr %l81, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i1, ptr %t121, i64 %t119
  %t123 = load i1, ptr %t122, !tbaa !31
  br i1 %t123, label %bb24, label %bb25
bb24:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l83, !tbaa !29
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l2, i64 %t126)
  store %"compiler/source:Span" %t129, ptr %l86
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l1, i64 %t130)
  store i64 %t133, ptr %l89
  br label %bb27
bb27:
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %s0, ptr %l3, i64 %t134)
  store i32 %t137, ptr %l92
  br label %bb28
bb28:
  %t138 = load ptr, ptr %lp4
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v0, ptr %t138, i64 %t139)
  store ptr %t142, ptr %l95
  br label %bb29
bb29:
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %l5, i64 %t143)
  store i1 %t146, ptr %l98
  br label %bb30
bb30:
  %t147 = load ptr, ptr %l83, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l86
  %t149 = load i64, ptr %l89, !tbaa !24
  %t150 = load i32, ptr %l92, !tbaa !23
  %t151 = load ptr, ptr %l95, !tbaa !29
  %t152 = load i1, ptr %l98, !tbaa !21
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eaddDef(ptr %v0, ptr %v0, ptr %t147, %"compiler/source:Span" %t148, i64 %t149, i32 %t150, ptr %t151, i1 %t152)
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l10, !tbaa !24
  br label %bb19
bb34:
  store i64 0, ptr %l12, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Versions", ptr %t157, i32 0, i32 3
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t159)
  store i64 %t161, ptr %l103
  br label %bb35
bb35:
  %t162 = load i64, ptr %l103, !tbaa !24
  store i64 %t162, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t163 = load i64, ptr %l13, !tbaa !24
  %t164 = load i64, ptr %l12, !tbaa !24
  %t167 = icmp sgt i64 %t163, %t164
  br i1 %t167, label %bb36, label %bb37
bb36:
  %t169 = load i64, ptr %l14, !tbaa !24
  %t171 = icmp sgt i64 %t169, 0
  br i1 %t171, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb41
bb38:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l12, !tbaa !24
  %t177 = sub i64 %t173, %t174
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = add i64 %t177, %t178
  %t183 = sub i64 %t181, 1
  %t184 = load i64, ptr %l14, !tbaa !24
  %t187 = sdiv i64 %t183, %t184
  store i64 %t187, ptr %l110, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb40
bb40:
  %t189 = load i64, ptr %l110, !tbaa !24
  store i64 %t189, ptr %l107, !tbaa !24
  br label %bb41
bb41:
  %t190 = load i64, ptr %l107, !tbaa !24
  store i64 %t190, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb42
bb42:
  %t191 = load i64, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l15, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb43, label %bb44
bb43:
  br label %bb60
bb44:
  br label %bb45
bb45:
  %t199 = load i64, ptr %l12, !tbaa !24
  %t200 = load i64, ptr %l16, !tbaa !24
  %t201 = load i64, ptr %l14, !tbaa !24
  %t204 = mul i64 %t200, %t201
  %t207 = add i64 %t199, %t204
  store i64 %t207, ptr %l17, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Versions", ptr %t209, i32 0, i32 3
  %t212 = load i64, ptr %l17, !tbaa !24
  %t215 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t211, i64 %t212)
  store i64 %t215, ptr %l131
  br label %bb46
bb46:
  %t216 = load i64, ptr %l131, !tbaa !24
  store i64 %t216, ptr %l18, !tbaa !24
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/typed:Versions", ptr %t217, i32 0, i32 9
  %t220 = load i64, ptr %l18, !tbaa !24
  %t223 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t219, i64 %t220)
  store i1 %t223, ptr %l135
  br label %bb47
bb47:
  %t224 = load i1, ptr %l135, !tbaa !21
  %t225 = xor i1 %t224, true
  br i1 %t225, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/typed:Versions", ptr %t227, i32 0, i32 9
  store ptr %t229, ptr %l138, !tbaa !29
  %t230 = load i64, ptr %l18, !tbaa !24
  store i64 %t230, ptr %l139, !tbaa !24
  %t231 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, ptr %l140
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t232 = load ptr, ptr %l138, !tbaa !29
  %t233 = load i64, ptr %l139, !tbaa !24
  %t234 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l140
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %s7, ptr %t232, i64 %t233, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb52:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/typed:Versions", ptr %t235, i32 0, i32 9
  %t238 = load i64, ptr %l18, !tbaa !24
  %t241 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hdc84c10e1af960a666eeb267120f3ec3(ptr %v0, ptr %v0, ptr %t237, i64 %t238)
  %t242 = extractvalue { i32, ptr } %t241, 1
  %t243 = extractvalue { i32, ptr } %t241, 0
  store i32 %t243, ptr %l146
  %t244 = icmp ne i32 %t243, 0
  br i1 %t244, label %bb54, label %ok.245, !prof !99
ok.245:
  store ptr %t242, ptr %l145
  br label %bb53
bb53:
  %t246 = load ptr, ptr %l145, !tbaa !29
  store ptr %t246, ptr %l141, !tbaa !29
  br label %bb57
bb54:
  %t247 = load i32, ptr %l146, !tbaa !23
  %t248 = icmp eq i32 %t247, 65536
  br i1 %t248, label %bb55, label %bb56
bb55:
  call void @__olang_bang_failed_plain(ptr @olang_loc_59830ee0ec754a32_f5aff824d93b155e)
  unreachable
bb56:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b8ff85e818b1a126_11cf17c421c4721a)
  unreachable
bb57:
  %t250 = load i64, ptr %l17, !tbaa !24
  %t251 = load ptr, ptr %l141, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t251, i64 %t250)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t253 = load i64, ptr %l16, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l16, !tbaa !24
  br label %bb42
bb60:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/typed:Versions", ptr %t257, i32 0, i32 3
  %t261 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t259)
  store i64 %t261, ptr %l153
  br label %bb61
bb61:
  %t262 = load i64, ptr %l153, !tbaa !24
  %t263 = icmp sgt i64 %t262, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t263, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eElidedCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2elocalRoots(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:Local"
  %l7 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca %"compiler/typed:Local"
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca i1
  %l27 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 4
  %t4 = load { ptr, ptr }, ptr %t3
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = extractvalue { ptr, ptr } %t4, 0
  %t8 = extractvalue { ptr, ptr } %t4, 1
  %t10 = call i64 %t7(ptr %t8, i32 %t5)
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i64, ptr %l7, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:ViewWalk", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = call ptr @__olang_scope_or(ptr %v1, ptr %t23)
  %t25 = ptrtoint ptr %t24 to i64
  %t27 = inttoptr i64 %t25 to ptr
  %t28 = load ptr, ptr %l12, !tbaa !29
  %t30 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %t27, ptr %t28, i32 %t22)
  store %"compiler/typed:Local" %t30, ptr %l15
  br label %bb5
bb5:
  %t31 = load %"compiler/typed:Local", ptr %l15
  store %"compiler/typed:Local" %t31, ptr %l3
  %t32 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t33 = load i32, ptr %t32, !range !{i32 0, i32 7}
  %t35 = trunc i64 0 to i32
  %t36 = icmp eq i32 %t33, %t35
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:ViewWalk", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l21, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = call ptr @__olang_scope_or(ptr %v2, ptr %t46)
  %t48 = ptrtoint ptr %t47 to i64
  %t50 = inttoptr i64 %t48 to ptr
  %t51 = load ptr, ptr %l21, !tbaa !29
  %t53 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t50, ptr %t51, i32 %t45)
  store i1 %t53, ptr %l24
  br label %bb8
bb8:
  %t54 = load i1, ptr %l24, !tbaa !21
  store i1 %t54, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t55 = load i1, ptr %l19, !tbaa !21
  br i1 %t55, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/typed:ViewWalk", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l27, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  %t62 = load ptr, ptr %l27, !tbaa !29
  %t63 = call ptr @__olang_scope_or(ptr %v2, ptr %t62)
  %t64 = ptrtoint ptr %t63 to i64
  %t66 = inttoptr i64 %t64 to ptr
  %t67 = load ptr, ptr %l27, !tbaa !29
  %t69 = call i1 @compiler_2ftyped_2eHoldsOwned(ptr %t66, ptr %t67, i32 %t61)
  store i1 %t69, ptr %l30
  br label %bb12
bb12:
  %t70 = load i1, ptr %l30, !tbaa !21
  %t71 = xor i1 %t70, true
  store i1 %t71, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t73 = load i1, ptr %l25, !tbaa !21
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eparamBit(ptr %v0, ptr %v1, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l35
  br label %bb17
bb17:
  %t80 = load i64, ptr %l35, !tbaa !24
  store i64 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eparamBit(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca i32
  %l49 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 5
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = call ptr @__olang_scope_or(ptr %v1, ptr %t7)
  %t9 = ptrtoint ptr %t8 to i64
  %t11 = inttoptr i64 %t9 to ptr
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %t11, ptr %t12)
  store i64 %t13, ptr %l12
  br label %bb1
bb1:
  %t14 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t15 = load i64, ptr %l12, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t15, i64 %t14)
  store i64 %t17, ptr %l14
  br label %bb2
bb2:
  %t18 = load i64, ptr %l14, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l21, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l21, !tbaa !24
  store i64 %t45, ptr %l18, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l18, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l7, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:ViewWalk", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Body", ptr %t68, i32 0, i32 5
  store ptr %t70, ptr %l41, !tbaa !29
  %t71 = load i64, ptr %l7, !tbaa !24
  %t72 = load ptr, ptr %l41, !tbaa !29
  %t73 = call ptr @__olang_scope_or(ptr %v1, ptr %t72)
  %t74 = ptrtoint ptr %t73 to i64
  %t76 = inttoptr i64 %t74 to ptr
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t79 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %t76, ptr %t77, i64 %t71)
  store i32 %t79, ptr %l44
  br label %bb13
bb13:
  %t81 = load i32, ptr %l44, !tbaa !23
  %t83 = icmp eq i32 %t81, %a1
  br i1 %t83, label %bb14, label %bb15
bb14:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:ViewWalk", ptr %t85, i32 0, i32 2
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  store i64 %t89, ptr %l49, !tbaa !24
  %t90 = load i64, ptr %l49, !tbaa !24
  %t91 = load i64, ptr %l49, !tbaa !24
  %t92 = shl i64 1, %t91
  %t95 = and i64 %t88, %t92
  %t97 = icmp ne i64 %t95, 0
  br i1 %t97, label %bb16, label %bb17
bb15:
  br label %bb19
bb16:
  %t99 = load i64, ptr %l7, !tbaa !24
  store i64 %t99, ptr %l54, !tbaa !24
  %t100 = load i64, ptr %l54, !tbaa !24
  %t101 = load i64, ptr %l54, !tbaa !24
  %t102 = shl i64 1, %t101
  store i64 %t102, ptr %l53, !tbaa !24
  br label %bb18
bb17:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb18
bb18:
  %t104 = load i64, ptr %l53, !tbaa !24
  store i64 %t104, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l6, !tbaa !24
  br label %bb9
bb21:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i1
  %l54 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2elocalRoots(ptr %v0, ptr %v2, ptr %v3, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb40
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l25
  br label %bb13
bb13:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  br label %bb40
bb14:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 3
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t62 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t58, ptr %t59)
  store i64 %t62, ptr %l34
  br label %bb20
bb20:
  %t63 = load i64, ptr %l34, !tbaa !24
  store i64 %t63, ptr %l7, !tbaa !24
  br label %bb40
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t65 = load ptr, ptr %l35, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 8}
  %t71 = icmp eq i64 %t69, 4
  store i1 %t71, ptr %l36, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l36, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Elem", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t79, ptr %t83)
  store i64 %t86, ptr %l44
  br label %bb27
bb27:
  %t87 = load i64, ptr %l44, !tbaa !24
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb40
bb28:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t89 = load ptr, ptr %l45, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb29, label %bb30
bb29:
  %t92 = load ptr, ptr %l45, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 8}
  %t95 = icmp eq i64 %t93, 5
  store i1 %t95, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t96 = load i1, ptr %l46, !tbaa !21
  br i1 %t96, label %bb31, label %bb32
bb31:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Payload", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t110 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t103, ptr %t107)
  store i64 %t110, ptr %l54
  br label %bb34
bb34:
  %t111 = load i64, ptr %l54, !tbaa !24
  store i64 %t111, ptr %l7, !tbaa !24
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_38f82f633fcbfe78_2a415e18f8868a4c)
  unreachable
bb40:
  %t112 = load i64, ptr %l7, !tbaa !24
  store i64 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eresultLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca %"compiler/typed:Local"
  %l25 = alloca i1
  %l29 = alloca i1
  %l35 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i64
  %l92 = alloca i64
  %l101 = alloca i1
  %l109 = alloca i64
  %l110 = alloca ptr
  %l112 = alloca i64
  %l115 = alloca ptr
  %l118 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  store ptr %t6, ptr %l17, !tbaa !29
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr %l17, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v2, ptr %t8)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t15 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t12, ptr %t13, i64 %t7)
  store %"compiler/typed:Local" %t15, ptr %l20
  br label %bb1
bb1:
  %t16 = load %"compiler/typed:Local", ptr %l20
  store %"compiler/typed:Local" %t16, ptr %l4
  %t17 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 7}
  store i32 %t18, ptr %l5
  %t20 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t22 = trunc i64 1 to i32
  %t23 = icmp eq i32 %t20, %t22
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb2, label %bb3
bb2:
  %t27 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t29 = trunc i64 3 to i32
  %t30 = icmp eq i32 %t27, %t29
  %t32 = xor i1 %t30, true
  store i1 %t32, ptr %l25, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb4
bb4:
  %t34 = load i1, ptr %l25, !tbaa !21
  br i1 %t34, label %bb5, label %bb6
bb5:
  %t35 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t37 = trunc i64 6 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  store i1 %t40, ptr %l29, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t42 = load i1, ptr %l29, !tbaa !21
  br i1 %t42, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/typed:ViewWalk", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l35, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t49 = load i32, ptr %t48, !tbaa !23
  %t50 = load ptr, ptr %l35, !tbaa !29
  %t51 = call ptr @__olang_scope_or(ptr %v3, ptr %t50)
  %t52 = ptrtoint ptr %t51 to i64
  %t54 = inttoptr i64 %t52 to ptr
  %t55 = load ptr, ptr %l35, !tbaa !29
  %t57 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t54, ptr %t55, i32 %t49)
  store i1 %t57, ptr %l38
  br label %bb11
bb11:
  %t58 = load i1, ptr %l38, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb15
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:ViewWalk", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l41, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t64 = load i32, ptr %t63, !tbaa !23
  %t65 = load ptr, ptr %l41, !tbaa !29
  %t66 = call ptr @__olang_scope_or(ptr %v3, ptr %t65)
  %t67 = ptrtoint ptr %t66 to i64
  %t69 = inttoptr i64 %t67 to ptr
  %t70 = load ptr, ptr %l41, !tbaa !29
  %t72 = call i1 @compiler_2ftyped_2eHoldsOwned(ptr %t69, ptr %t70, i32 %t64)
  store i1 %t72, ptr %l44
  br label %bb14
bb14:
  %t73 = load i1, ptr %l44, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l39, !tbaa !21
  br label %bb15
bb15:
  %t76 = load i1, ptr %l39, !tbaa !21
  br i1 %t76, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 5
  %t81 = load i64, ptr %l2, !tbaa !24
  %t84 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t80, i64 %t81)
  store i1 %t84, ptr %l50
  br label %bb19
bb19:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb21:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/typed:LocalUses", ptr %t86, i32 0, i32 2
  %t89 = load i64, ptr %l2, !tbaa !24
  %t92 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t88, i64 %t89)
  store i1 %t92, ptr %l55
  br label %bb22
bb22:
  %t93 = load i1, ptr %l55, !tbaa !21
  store i1 %t93, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb27
bb25:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:LocalUses", ptr %t95, i32 0, i32 4
  %t98 = load i64, ptr %l2, !tbaa !24
  %t101 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t97, i64 %t98)
  store i1 %t101, ptr %l60
  br label %bb26
bb26:
  %t102 = load i1, ptr %l60, !tbaa !21
  store i1 %t102, ptr %l56, !tbaa !21
  br label %bb27
bb27:
  %t103 = load i1, ptr %l56, !tbaa !21
  br i1 %t103, label %bb28, label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  store i64 0, ptr %l6, !tbaa !24
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/typed:LocalUses", ptr %t105, i32 0, i32 13
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t107)
  store i64 %t109, ptr %l64
  br label %bb31
bb31:
  %t110 = load i64, ptr %l64, !tbaa !24
  store i64 %t110, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t112 = load i64, ptr %l6, !tbaa !24
  %t115 = icmp sgt i64 %t111, %t112
  br i1 %t115, label %bb32, label %bb33
bb32:
  %t117 = load i64, ptr %l8, !tbaa !24
  %t119 = icmp sgt i64 %t117, 0
  br i1 %t119, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb37
bb34:
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load i64, ptr %l6, !tbaa !24
  %t125 = sub i64 %t121, %t122
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = add i64 %t125, %t126
  %t131 = sub i64 %t129, 1
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = sdiv i64 %t131, %t132
  store i64 %t135, ptr %l71, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb36
bb36:
  %t137 = load i64, ptr %l71, !tbaa !24
  store i64 %t137, ptr %l68, !tbaa !24
  br label %bb37
bb37:
  %t138 = load i64, ptr %l68, !tbaa !24
  store i64 %t138, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb38
bb38:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t140 = load i64, ptr %l9, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb39, label %bb40
bb39:
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t147 = load i64, ptr %l6, !tbaa !24
  %t148 = load i64, ptr %l10, !tbaa !24
  %t149 = load i64, ptr %l8, !tbaa !24
  %t152 = mul i64 %t148, %t149
  %t155 = add i64 %t147, %t152
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/typed:LocalUses", ptr %t157, i32 0, i32 13
  %t163 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t159, i64 %t155)
  store i64 %t163, ptr %l92
  br label %bb42
bb42:
  %t164 = load i64, ptr %l2, !tbaa !24
  %t165 = load i64, ptr %l92, !tbaa !24
  %t167 = icmp eq i64 %t165, %t164
  br i1 %t167, label %bb43, label %bb44
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t170 = load i64, ptr %l10, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l10, !tbaa !24
  br label %bb38
bb47:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr %"compiler/typed:LocalUses", ptr %t174, i32 0, i32 8
  %t177 = load i64, ptr %l2, !tbaa !24
  %t180 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t176, i64 %t177)
  store i1 %t180, ptr %l101
  br label %bb48
bb48:
  %t181 = load i1, ptr %l101, !tbaa !21
  br i1 %t181, label %bb49, label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t185 = xor i1 %a3, true
  br i1 %t185, label %bb52, label %bb53
bb52:
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/typed:ViewWalk", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Body", ptr %t191, i32 0, i32 10
  store ptr %t193, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb55
bb55:
  %t195 = load i64, ptr %l13, !tbaa !24
  store i64 %t195, ptr %l109, !tbaa !24
  %t196 = load ptr, ptr %l12, !tbaa !29
  store ptr %t196, ptr %l110, !tbaa !29
  %t197 = load ptr, ptr %l110, !tbaa !29
  %t198 = call ptr @__olang_scope_or(ptr %v2, ptr %t197)
  %t199 = ptrtoint ptr %t198 to i64
  %t201 = inttoptr i64 %t199 to ptr
  %t202 = load ptr, ptr %l110, !tbaa !29
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %t201, ptr %t202)
  store i64 %t203, ptr %l112
  br label %bb56
bb56:
  %t204 = load i64, ptr %l109, !tbaa !24
  %t205 = load i64, ptr %l112, !tbaa !24
  %t206 = icmp slt i64 %t204, %t205
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb57, label %bb58
bb57:
  br label %bb65
bb58:
  br label %bb59
bb59:
  %t210 = load ptr, ptr %l12, !tbaa !29
  store ptr %t210, ptr %l115, !tbaa !29
  %t211 = load i64, ptr %l13, !tbaa !24
  %t212 = load ptr, ptr %l115, !tbaa !29
  %t213 = call ptr @__olang_scope_or(ptr %v2, ptr %t212)
  %t214 = ptrtoint ptr %t213 to i64
  %t216 = inttoptr i64 %t214 to ptr
  %t217 = load ptr, ptr %l115, !tbaa !29
  %t219 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %t216, ptr %t217, i64 %t211)
  store i32 %t219, ptr %l118
  br label %bb60
bb60:
  %t220 = load i32, ptr %l118, !tbaa !23
  %t223 = sext i32 %t220 to i64
  %t224 = load i64, ptr %l2, !tbaa !24
  %t227 = icmp eq i64 %t223, %t224
  br i1 %t227, label %bb61, label %bb62
bb61:
  store i1 true, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t230 = load i64, ptr %l13, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l13, !tbaa !24
  br label %bb55
bb65:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca i1
  %l52 = alloca i1
  %l62 = alloca i1
  %l89 = alloca { i64, ptr }
  %l106 = alloca i64
  %l108 = alloca i64
  %l113 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t7 = load ptr, ptr %l27, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l27, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l28, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l28, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  br label %bb6
bb6:
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_5f0c96ba8f37c420_5ca612e1d5c707f4)
  unreachable
bb12:
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l36
  br label %bb13
bb13:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l4
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Call", ptr %t28, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb15, label %bb16
bb15:
  br label %bb39
bb16:
  br label %bb17
bb17:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t45, ptr %l45, !tbaa !27
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  store ptr %t51, ptr %l8, !tbaa !29
  %t53 = load ptr, ptr %l8, !tbaa !29
  store ptr %t53, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t54 = load ptr, ptr %l48, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l48, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 12
  store i1 %t60, ptr %l49, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l49, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l8, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  store %"compiler/source:Span" %t66, ptr %l9
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l10, !tbaa !23
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  %t83 = getelementptr %"compiler/typed:Seq", ptr %t78, i32 0, i32 2
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l52, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l52, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t87 = load ptr, ptr %l8, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l12
  %t93 = load ptr, ptr %l8, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 1
  %t97 = load i32, ptr %t96
  store i32 %t97, ptr %l13, !tbaa !23
  %t99 = load ptr, ptr %l8, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  %t108 = getelementptr %"compiler/typed:Seq", ptr %t103, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = icmp eq ptr %t109, null
  %t113 = xor i1 %t111, true
  store i1 %t113, ptr %l62, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb25
bb25:
  %t115 = load i1, ptr %l62, !tbaa !21
  br i1 %t115, label %bb26, label %bb27
bb26:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = getelementptr { i64, [5 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t118, i32 0, i32 0
  %t120 = load %"compiler/source:Span", ptr %t119
  store %"compiler/source:Span" %t120, ptr %l15
  %t122 = load ptr, ptr %l8, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 1
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l16, !tbaa !23
  %t128 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t130, i32 0, i32 2
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l17, !tbaa !29
  %t134 = load ptr, ptr %l17, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Seq", ptr %t134, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l20, !tbaa !24
  br label %bb28
bb27:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t144, ptr %t145)
  br label %bb36
bb28:
  %t149 = load i64, ptr %l19, !tbaa !24
  %t150 = load i64, ptr %l20, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb29, label %bb30
bb29:
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t157 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t157, ptr %l89, !tbaa !27
  %t158 = load i64, ptr %l19, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr ptr, ptr %t161, i64 %t158
  %t163 = load ptr, ptr %t162, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %s0, ptr %v1, ptr %l4, ptr %t163)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t168 = load i64, ptr %l19, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l19, !tbaa !24
  br label %bb28
bb34:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l17, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Seq", ptr %t173, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t172, ptr %t177)
  br label %bb35
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t180 = load i64, ptr %l6, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l6, !tbaa !24
  br label %bb14
bb39:
  store ptr %l4, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb40
bb40:
  %t185 = load i64, ptr %l23, !tbaa !24
  store i64 %t185, ptr %l106, !tbaa !24
  %t186 = load ptr, ptr %l22, !tbaa !29
  %t188 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %s0, ptr %t186)
  store i64 %t188, ptr %l108
  br label %bb41
bb41:
  %t189 = load i64, ptr %l106, !tbaa !24
  %t190 = load i64, ptr %l108, !tbaa !24
  %t191 = icmp slt i64 %t189, %t190
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb42, label %bb43
bb42:
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t195 = load ptr, ptr %l22, !tbaa !29
  %t196 = load i64, ptr %l23, !tbaa !24
  %t199 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %s0, ptr %s0, ptr %t195, i64 %t196)
  store ptr %t199, ptr %l113
  br label %bb45
bb45:
  %t200 = load ptr, ptr %l113, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %s0, ptr %t201, ptr %t200)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t205 = load i64, ptr %l23, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l23, !tbaa !24
  br label %bb40
bb48:
  %t209 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t209, i1 false)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l8, !tbaa !27
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:dropWalk", ptr %t2, i32 0, i32 2
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l11
  br label %bb1
bb1:
  %t7 = load i64, ptr %l11, !tbaa !24
  %t8 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i1, ptr %t9, i64 %t7
  %t11 = load i1, ptr %t10, !tbaa !31
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 3
  %t16 = load i1, ptr %t15, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %v1, ptr %t18, { i64, ptr } %t19)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %ret
bb8:
  store i64 0, ptr %l2, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:dropWalk", ptr %t22, i32 0, i32 2
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l19
  br label %bb9
bb9:
  %t27 = load i64, ptr %l19, !tbaa !24
  store i64 %t27, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb15
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l2, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l26, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb14
bb14:
  %t54 = load i64, ptr %l26, !tbaa !24
  store i64 %t54, ptr %l23, !tbaa !24
  br label %bb15
bb15:
  %t55 = load i64, ptr %l23, !tbaa !24
  store i64 %t55, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb17, label %bb18
bb17:
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l4, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l7, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:dropWalk", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l45, !tbaa !29
  %t77 = load i64, ptr %l7, !tbaa !24
  store i64 %t77, ptr %l46, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:dropWalk", ptr %t78, i32 0, i32 2
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t80, i64 %t81)
  store i1 %t84, ptr %l50
  br label %bb20
bb20:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb22:
  %t86 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t86, ptr %l52, !tbaa !27
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i1, ptr %t90, i64 %t87
  %t92 = load i1, ptr %t91, !tbaa !31
  store i1 %t92, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = load i64, ptr %l46, !tbaa !24
  %t96 = load i1, ptr %l51, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t94, i64 %t95, i1 %t96)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l6, !tbaa !24
  br label %bb16
bb26:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l14 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 7
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:dropWalk", ptr %t15, i32 0, i32 7
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l14
  br label %bb6
bb6:
  %t23 = load i32, ptr %l14, !tbaa !23
  %t25 = icmp ne i32 %t23, %a2
  br i1 %t25, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l17, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:dropWalk", ptr %t28, i32 0, i32 8
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t31)
  store i64 %t34, ptr %l21
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t35, i64 %t36)
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t40 = trunc i64 0 to i32
  %t41 = icmp eq i32 %a1, %t40
  %t42 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ekeepFor(ptr %v0, ptr %t37, i1 %t41, i64 %t42)
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = sub i64 %t46, 1
  store i64 %t48, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/typed:dropWalk", ptr %t50, i32 0, i32 3
  store i1 true, ptr %t52, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ekeepFor(ptr %v0, ptr %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca i1
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = add i64 %t8, 1
  %t13 = mul i64 %a2, %t10
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l25, !tbaa !24
  store i64 %t43, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l22, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:dropWalk", ptr %t63, i32 0, i32 2
  %t66 = load i64, ptr %l10, !tbaa !24
  %t69 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t65, i64 %t66)
  store i1 %t69, ptr %l46
  br label %bb12
bb12:
  %t70 = load i1, ptr %l46, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t73 = load i1, ptr %l1, !tbaa !21
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/typed:dropWalk", ptr %t75, i32 0, i32 9
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = add i64 %t78, %t79
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t77, i64 %t82, i1 true)
  br label %bb18
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:dropWalk", ptr %t85, i32 0, i32 10
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = add i64 %t88, %t89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t87, i64 %t92, i1 true)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t95 = load i64, ptr %l9, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l9, !tbaa !24
  br label %bb8
bb22:
  %t99 = load i1, ptr %l1, !tbaa !21
  br i1 %t99, label %bb23, label %bb24
bb23:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/typed:dropWalk", ptr %t101, i32 0, i32 9
  %t104 = load i64, ptr %l4, !tbaa !24
  %t105 = load i64, ptr %l3, !tbaa !24
  %t108 = add i64 %t104, %t105
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t103, i64 %t108, i1 false)
  br label %bb25
bb24:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/typed:dropWalk", ptr %t111, i32 0, i32 10
  %t114 = load i64, ptr %l4, !tbaa !24
  %t115 = load i64, ptr %l3, !tbaa !24
  %t118 = add i64 %t114, %t115
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t113, i64 %t118, i1 false)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca ptr
  %l24 = alloca i1
  %l39 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i64
  %l92 = alloca ptr
  %l95 = alloca ptr
  %l97 = alloca i1
  %l98 = alloca i1
  %l100 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i32
  %l106 = alloca i1
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l20
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Call", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l4, !tbaa !29
  store ptr %t10, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t11 = load ptr, ptr %l23, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l23, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 5}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l24, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l24, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { ptr }, ptr %t21, i32 0, i32 0
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l5, !tbaa !29
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t25 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %v1, ptr %l3, ptr %t25)
  br label %bb8
bb8:
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_2676a1f2cfb255f8_2530c83c98e00394)
  unreachable
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Call", ptr %t28, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t45, ptr %l39, !tbaa !27
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %v1, ptr %l3, ptr %t51)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l7, !tbaa !24
  br label %bb15
bb21:
  store ptr %l3, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t61 = load i64, ptr %l11, !tbaa !24
  store i64 %t61, ptr %l47, !tbaa !24
  %t62 = load ptr, ptr %l10, !tbaa !29
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %t62)
  store i64 %t64, ptr %l49
  br label %bb23
bb23:
  %t65 = load i64, ptr %l47, !tbaa !24
  %t66 = load i64, ptr %l49, !tbaa !24
  %t67 = icmp slt i64 %t65, %t66
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t71 = load ptr, ptr %l10, !tbaa !29
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l54
  br label %bb27
bb27:
  %t76 = load ptr, ptr %l54, !tbaa !29
  store ptr %l2, ptr %l55, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t82 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %s0, ptr %v0, ptr %v3, ptr %v4, ptr %t77, ptr %t76)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l59
  br label %bb28
bb28:
  %t83 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  %t84 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t83, ptr %t84
  %t85 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t85, ptr %t84)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l11, !tbaa !24
  br label %bb22
bb31:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l63, !tbaa !29
  %t93 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t93, ptr %l65
  br label %bb32
bb32:
  %t94 = load ptr, ptr %l63, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l65, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2emix(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t94, { i64, ptr } %t95)
  br label %bb33
bb33:
  store i64 0, ptr %l13, !tbaa !24
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %l3)
  store i64 %t97, ptr %l67
  br label %bb34
bb34:
  %t98 = load i64, ptr %l67, !tbaa !24
  store i64 %t98, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t99 = load i64, ptr %l14, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t103 = icmp sgt i64 %t99, %t100
  br i1 %t103, label %bb35, label %bb36
bb35:
  %t105 = load i64, ptr %l15, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb40
bb37:
  %t109 = load i64, ptr %l14, !tbaa !24
  %t110 = load i64, ptr %l13, !tbaa !24
  %t113 = sub i64 %t109, %t110
  %t114 = load i64, ptr %l15, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = sub i64 %t117, 1
  %t120 = load i64, ptr %l15, !tbaa !24
  %t123 = sdiv i64 %t119, %t120
  store i64 %t123, ptr %l74, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb39
bb39:
  %t125 = load i64, ptr %l74, !tbaa !24
  store i64 %t125, ptr %l71, !tbaa !24
  br label %bb40
bb40:
  %t126 = load i64, ptr %l71, !tbaa !24
  store i64 %t126, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s10
  %t127 = load i64, ptr %l17, !tbaa !24
  %t128 = load i64, ptr %l16, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb43:
  br label %bb44
bb44:
  %t135 = load i64, ptr %l13, !tbaa !24
  %t136 = load i64, ptr %l17, !tbaa !24
  %t137 = load i64, ptr %l15, !tbaa !24
  %t140 = mul i64 %t136, %t137
  %t143 = add i64 %t135, %t140
  store i64 %t143, ptr %l18, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l92, !tbaa !29
  %t146 = load i64, ptr %l18, !tbaa !24
  %t149 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s10, ptr %l3, i64 %t146)
  store ptr %t149, ptr %l95
  br label %bb45
bb45:
  %t150 = load ptr, ptr %l95, !tbaa !29
  %t151 = load ptr, ptr %l92, !tbaa !29
  %t153 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %s10, ptr %v3, ptr %t151, ptr %t150)
  store i1 %t153, ptr %l97
  br label %bb46
bb46:
  %t154 = load i1, ptr %l97, !tbaa !21
  br i1 %t154, label %bb47, label %bb48
bb47:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/typed:holdWalk", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  store ptr %t158, ptr %l100, !tbaa !29
  %t159 = load i64, ptr %l18, !tbaa !24
  %t162 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t159)
  store ptr %t162, ptr %l103
  br label %bb49
bb48:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb52
bb49:
  %t163 = load ptr, ptr %l103, !tbaa !29
  %t164 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %s0, ptr %t163)
  store i32 %t164, ptr %l104
  br label %bb50
bb50:
  %t165 = load ptr, ptr %l100, !tbaa !29
  %t166 = call ptr @__olang_scope_or(ptr %v3, ptr %t165)
  %t167 = ptrtoint ptr %t166 to i64
  %t169 = inttoptr i64 %t167 to ptr
  %t170 = load ptr, ptr %l100, !tbaa !29
  %t171 = load i32, ptr %l104, !tbaa !23
  %t172 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %t169, ptr %t170, i32 %t171, i1 false)
  store i1 %t172, ptr %l106
  br label %bb51
bb51:
  %t173 = load i1, ptr %l106, !tbaa !21
  store i1 %t173, ptr %l98, !tbaa !21
  br label %bb52
bb52:
  %t174 = load i1, ptr %l98, !tbaa !21
  br i1 %t174, label %bb53, label %bb54
bb53:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempGiven(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t175, i64 %t176, ptr %l3)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  %t180 = load i64, ptr %l17, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l17, !tbaa !24
  br label %bb41
bb58:
  %t184 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eelemStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Elem", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s0, ptr %v3, ptr %v4, ptr %t1, ptr %t5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Elem", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t10, ptr %t14)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l10
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheldBefore(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l26 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %s1, i64 %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t8 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s1, ptr %s1, ptr %t6)
  store { i64, ptr } %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclosure(ptr %v0, ptr %s1, ptr %s1, ptr %t9, { i64, ptr } %t10)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l10
  br label %bb3
bb3:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t13 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %t13
  store ptr %t13, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l12, !tbaa !24
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t16)
  store i64 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb26
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l19
  br label %bb9
bb9:
  %t30 = load i64, ptr %l19, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp eq i64 %t31, %t32
  br i1 %t35, label %bb10, label %bb11
bb10:
  br label %bb25
bb11:
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:holdWalk", ptr %t37, i32 0, i32 6
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t39, i64 %t40)
  store i1 %t43, ptr %l26
  br label %bb13
bb13:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t45, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/typed:holdWalk", ptr %t47, i32 0, i32 9
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t49, i64 %t50)
  store i1 %t53, ptr %l31
  br label %bb17
bb17:
  %t54 = load i1, ptr %l31, !tbaa !21
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l1, !tbaa !24
  %t61 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregisteredBefore(ptr %v0, ptr %v1, ptr %t55, i64 %t56, i64 %t57)
  store i1 %t61, ptr %l36
  br label %bb20
bb19:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb21
bb20:
  %t62 = load i1, ptr %l36, !tbaa !21
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t65 = load i1, ptr %l32, !tbaa !21
  br i1 %t65, label %bb22, label %bb23
bb22:
  %t66 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t66, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l3, !tbaa !24
  br label %bb4
bb26:
  call void @__olang_scope_close(ptr %s1)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2einBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:holdWalk", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:holdWalk", ptr %t9, i32 0, i32 8
  store ptr %t11, ptr %l7, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:holdWalk", ptr %t12, i32 0, i32 8
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l10
  br label %bb4
bb3:
  store i32 -1, ptr %l5, !tbaa !23
  br label %bb6
bb4:
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = sub i64 %t17, 1
  %t19 = load ptr, ptr %l7, !tbaa !29
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t19, i64 %t18)
  store i32 %t21, ptr %l12
  br label %bb5
bb5:
  %t22 = load i32, ptr %l12, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  br label %bb6
bb6:
  %t23 = load i32, ptr %l5, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 5
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/typed:holdWalk", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Promote", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t28)
  store i32 %t30, ptr %l19
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = call ptr @__olang_scope_or(ptr %v2, ptr %t31)
  %t33 = ptrtoint ptr %t32 to i64
  %t35 = inttoptr i64 %t33 to ptr
  %t36 = load ptr, ptr %l16, !tbaa !29
  %t37 = load i32, ptr %l19, !tbaa !23
  %t38 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %t35, ptr %t36, i32 %t37)
  store i1 %t38, ptr %l21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l21, !tbaa !21
  store i1 %t39, ptr %l8, !tbaa !21
  br label %bb30
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 14
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Try", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t62 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %v2, ptr %t55, ptr %t59)
  store i1 %t62, ptr %l31
  br label %bb17
bb17:
  %t63 = load i1, ptr %l31, !tbaa !21
  store i1 %t63, ptr %l8, !tbaa !21
  br label %bb30
bb18:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t65 = load ptr, ptr %l32, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load ptr, ptr %l32, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 12
  store i1 %t71, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t72 = load i1, ptr %l33, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Seq", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %v2, ptr %t79, ptr %t83)
  store i1 %t86, ptr %l41
  br label %bb24
bb24:
  %t87 = load i1, ptr %l41, !tbaa !21
  store i1 %t87, ptr %l8, !tbaa !21
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_77c9af98e9dace58_20acd54f7de13794)
  unreachable
bb30:
  %t88 = load i1, ptr %l8, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca %"compiler/typed:Local"
  %l13 = alloca i1
  %l15 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:holdWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v1, ptr %t8)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t12, ptr %t13, i64 %t7)
  store %"compiler/typed:Local" %t15, ptr %l8
  br label %bb1
bb1:
  %t16 = getelementptr %"compiler/typed:Local", ptr %l8, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  store i32 %t17, ptr %l2, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:holdWalk", ptr %t19, i32 0, i32 9
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t21, i64 %t22)
  store i1 %t25, ptr %l13
  br label %bb2
bb2:
  %t26 = load i1, ptr %l13, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/typed:holdWalk", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  store ptr %t32, ptr %l17, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = call ptr @__olang_scope_or(ptr %v2, ptr %t34)
  %t36 = ptrtoint ptr %t35 to i64
  %t38 = inttoptr i64 %t36 to ptr
  %t39 = load ptr, ptr %l17, !tbaa !29
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t38, ptr %t39, i32 %t33)
  store i32 %t41, ptr %l20
  br label %bb5
bb5:
  %t42 = load i32, ptr %l20, !range !{i32 0, i32 33}
  %t44 = trunc i64 20 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t49 = load i1, ptr %l15, !tbaa !21
  br i1 %t49, label %bb7, label %bb8
bb7:
  %t50 = load i32, ptr %l2, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/typed:holdWalk", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l26, !tbaa !29
  %t56 = load i32, ptr %l2, !tbaa !23
  %t57 = load ptr, ptr %l26, !tbaa !29
  %t58 = call ptr @__olang_scope_or(ptr %v2, ptr %t57)
  %t59 = ptrtoint ptr %t58 to i64
  %t61 = inttoptr i64 %t59 to ptr
  %t62 = load ptr, ptr %l26, !tbaa !29
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t61, ptr %t62, i32 %t56)
  store i32 %t64, ptr %l29
  br label %bb10
bb10:
  %t65 = load i32, ptr %l29, !tbaa !23
  store i32 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempHolds(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i1
  %l63 = alloca i32
  %l67 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:holdWalk", ptr %t1, i32 0, i32 14
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %s1, ptr %t3, i64 %t4)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l14
  br label %bb1
bb1:
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s1, ptr %l14)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  %t11 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  store ptr %t11, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l18, !tbaa !24
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s1, ptr %t14)
  store i64 %t16, ptr %l20
  br label %bb4
bb4:
  %t17 = load i64, ptr %l18, !tbaa !24
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb32
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s1, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l25
  br label %bb8
bb8:
  %t28 = load i64, ptr %l25, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/typed:holdWalk", ptr %t29, i32 0, i32 6
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l28
  br label %bb9
bb9:
  %t34 = load i64, ptr %l28, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp sgt i64 %t35, %t36
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb15
bb12:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = sub i64 %t45, %t46
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = add i64 %t49, %t50
  %t55 = sub i64 %t53, 1
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = sdiv i64 %t55, %t56
  store i64 %t59, ptr %l35, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb14
bb14:
  %t61 = load i64, ptr %l35, !tbaa !24
  store i64 %t61, ptr %l32, !tbaa !24
  br label %bb15
bb15:
  %t62 = load i64, ptr %l32, !tbaa !24
  store i64 %t62, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb17, label %bb18
bb17:
  br label %bb30
bb18:
  br label %bb19
bb19:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = mul i64 %t72, %t73
  %t79 = add i64 %t71, %t76
  store i64 %t79, ptr %l10, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:holdWalk", ptr %t81, i32 0, i32 6
  %t84 = load i64, ptr %l10, !tbaa !24
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l56
  br label %bb20
bb20:
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l56, !tbaa !24
  %t91 = icmp eq i64 %t89, %t88
  br i1 %t91, label %bb21, label %bb22
bb21:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:holdWalk", ptr %t93, i32 0, i32 7
  %t96 = load i64, ptr %l10, !tbaa !24
  %t99 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t95, i64 %t96)
  store i32 %t99, ptr %l63
  br label %bb23
bb22:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb25
bb23:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/typed:holdWalk", ptr %t100, i32 0, i32 15
  %t103 = load i64, ptr %l1, !tbaa !24
  %t106 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t102, i64 %t103)
  store i32 %t106, ptr %l67
  br label %bb24
bb24:
  %t107 = load i32, ptr %l63, !tbaa !23
  %t108 = load i32, ptr %l67, !tbaa !23
  %t109 = icmp eq i32 %t107, %t108
  store i1 %t109, ptr %l59, !tbaa !21
  br label %bb25
bb25:
  %t111 = load i1, ptr %l59, !tbaa !21
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t112 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  store i64 %t112, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t114 = load i64, ptr %l9, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l9, !tbaa !24
  br label %bb16
bb30:
  br label %bb31
bb31:
  %t118 = load i64, ptr %l3, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l3, !tbaa !24
  br label %bb3
bb32:
  call void @__olang_scope_close(ptr %s1)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i32
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = icmp eq ptr %t3, null
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t9)
  store i32 %t11, ptr %l12
  br label %bb5
bb5:
  %t12 = load i32, ptr %l12, !tbaa !23
  store i32 %t12, ptr %l3, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s2, ptr %v3, ptr %v4, ptr %t13, ptr %t14)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l16
  br label %bb6
bb6:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  %t20 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t20
  store ptr %t20, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t22 = load i64, ptr %l5, !tbaa !24
  store i64 %t22, ptr %l18, !tbaa !24
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t23)
  store i64 %t25, ptr %l20
  br label %bb8
bb8:
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = load i64, ptr %l20, !tbaa !24
  %t28 = icmp slt i64 %t26, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb9, label %bb10
bb9:
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t32, i64 %t33)
  store i64 %t36, ptr %l25
  br label %bb12
bb12:
  %t37 = load i64, ptr %l25, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:holdWalk", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l27, !tbaa !29
  %t42 = load i32, ptr %l3, !tbaa !23
  store i32 %t42, ptr %l28, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %v4, ptr %v3, ptr %t43, i64 %t44)
  store i32 %t47, ptr %l31
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l27, !tbaa !29
  %t49 = call ptr @__olang_scope_or(ptr %v3, ptr %t48)
  %t50 = ptrtoint ptr %t49 to i64
  %t52 = inttoptr i64 %t50 to ptr
  %t53 = load ptr, ptr %l27, !tbaa !29
  %t54 = load i32, ptr %l28, !tbaa !23
  %t55 = load i32, ptr %l31, !tbaa !23
  %t56 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefInto(ptr %t52, ptr %t53, i32 %t54, i32 %t55)
  store i1 %t56, ptr %l33
  br label %bb14
bb14:
  %t57 = load i1, ptr %l33, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %l2, i64 %t58)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l5, !tbaa !24
  br label %bb7
bb20:
  call void @__olang_scope_close(ptr %s2)
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %l33 = alloca { i64, ptr }
  %l40 = alloca i1
  %l50 = alloca { i64, ptr }
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Arm", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i1 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Arm", ptr %t11, i32 0, i32 3
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t10, ptr %t14)
  store i1 %t17, ptr %l18
  br label %bb4
bb4:
  %t18 = load i1, ptr %l18, !tbaa !21
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Arm", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t27 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t20, ptr %t24)
  store i1 %t27, ptr %l23
  br label %bb8
bb8:
  %t28 = load i1, ptr %l23, !tbaa !21
  store i1 %t28, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Arm", ptr %t31, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  br label %bb32
bb15:
  br label %bb16
bb16:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l33, !tbaa !27
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr ptr, ptr %t52, i64 %t49
  %t54 = load ptr, ptr %t53, !tbaa !39
  store ptr %t54, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Alt", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t64 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  store i1 %t64, ptr %l40
  br label %bb17
bb17:
  %t65 = load i1, ptr %l40, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Alt", ptr %t67, i32 0, i32 1
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  store i64 %t74, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  br label %bb24
bb24:
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr ptr, ptr %t88, i64 %t85
  %t90 = load ptr, ptr %t89, !tbaa !39
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Bind", ptr %t90, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t100 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t92, ptr %t96)
  store i1 %t100, ptr %l57
  br label %bb25
bb25:
  %t101 = load i1, ptr %l57, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l7, !tbaa !24
  br label %bb21
bb30:
  br label %bb31
bb31:
  %t107 = load i64, ptr %l3, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l3, !tbaa !24
  br label %bb13
bb32:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t34 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2ecalleeLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t17)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l3, !tbaa !21
  br label %bb26
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 5}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  br label %bb24
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 5}
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 5}
  %t48 = icmp eq i64 %t46, 3
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 5}
  %t57 = icmp eq i64 %t55, 4
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb21
bb21:
  %t58 = load i1, ptr %l27, !tbaa !21
  br i1 %t58, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_10efe43793a641ac_2dabf1c43cd6a168)
  unreachable
bb26:
  %t59 = load i1, ptr %l3, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eopenLeaves(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eopenLeaves(ptr %v0, ptr %v2, ptr %t8, ptr %a2)
  store i1 %t12, ptr %l10
  br label %bb4
bb4:
  %t13 = load i1, ptr %l10, !tbaa !21
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2epiecesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb26
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 2}
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { ptr }, ptr %t41, i32 0, i32 0
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l6, !tbaa !29
  %t50 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t46)
  store i1 %t50, ptr %l30
  br label %bb13
bb13:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb24
bb17:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 2}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l33, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4c49c2cc391943fc_885b7fff3b4a3180)
  unreachable
bb24:
  br label %bb25
bb25:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l3, !tbaa !24
  br label %bb4
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l104 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %l116 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l131 = alloca i1
  %l133 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l144 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i1
  %l154 = alloca i1
  %l155 = alloca ptr
  %l156 = alloca i1
  %l163 = alloca i1
  %l167 = alloca i1
  %l170 = alloca i1
  %l172 = alloca i1
  %l177 = alloca i1
  %l178 = alloca i1
  %l182 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca i1
  %l193 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t11 = load ptr, ptr %l19, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l19, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 17}
  %t17 = icmp eq i64 %t15, 16
  store i1 %t17, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l20, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb134
bb10:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t20 = load ptr, ptr %l23, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l23, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 17}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l24, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t29 = load ptr, ptr %l27, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l27, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 17}
  %t35 = icmp eq i64 %t33, 8
  store i1 %t35, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l28, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:leaveWalk", ptr %t37, i32 0, i32 1
  %t40 = load i1, ptr %t39, !tbaa !21
  %t42 = xor i1 %t40, true
  store i1 %t42, ptr %l14, !tbaa !21
  br label %bb134
bb20:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t45 = load ptr, ptr %l34, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb21, label %bb22
bb21:
  %t48 = load ptr, ptr %l34, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 17}
  %t51 = icmp eq i64 %t49, 5
  store i1 %t51, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t52 = load i1, ptr %l35, !tbaa !21
  br i1 %t52, label %bb23, label %bb24
bb23:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [3 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t55, i32 0, i32 2
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l2, !tbaa !23
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:leaveWalk", ptr %t59, i32 0, i32 0
  %t62 = load i32, ptr %l2, !tbaa !23
  %t65 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eHas_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t61, i32 %t62)
  store i1 %t65, ptr %l43
  br label %bb26
bb26:
  %t66 = load i1, ptr %l43, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l14, !tbaa !21
  br label %bb134
bb27:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t70 = load ptr, ptr %l45, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb28, label %bb29
bb28:
  %t73 = load ptr, ptr %l45, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 17}
  %t76 = icmp eq i64 %t74, 0
  store i1 %t76, ptr %l46, !tbaa !21
  br label %bb29
bb29:
  %t77 = load i1, ptr %l46, !tbaa !21
  br i1 %t77, label %bb30, label %bb31
bb30:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  store ptr %t82, ptr %l3, !tbaa !29
  br label %bb40
bb31:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t85 = load ptr, ptr %l51, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb32, label %bb33
bb32:
  %t88 = load ptr, ptr %l51, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 17}
  %t91 = icmp eq i64 %t89, 2
  store i1 %t91, ptr %l52, !tbaa !21
  br label %bb33
bb33:
  %t92 = load i1, ptr %l52, !tbaa !21
  br i1 %t92, label %bb34, label %bb35
bb34:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [3 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", ptr }, ptr %t95, i32 0, i32 1
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l3, !tbaa !29
  br label %bb40
bb35:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t100 = load ptr, ptr %l57, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb36, label %bb37
bb36:
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 17}
  %t106 = icmp eq i64 %t104, 15
  store i1 %t106, ptr %l58, !tbaa !21
  br label %bb37
bb37:
  %t107 = load i1, ptr %l58, !tbaa !21
  br i1 %t107, label %bb38, label %bb39
bb38:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [3 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", ptr }, ptr %t110, i32 0, i32 1
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l3, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t119 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t114, ptr %t115)
  store i1 %t119, ptr %l66
  br label %bb41
bb41:
  %t120 = load i1, ptr %l66, !tbaa !21
  store i1 %t120, ptr %l14, !tbaa !21
  br label %bb134
bb42:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t122 = load ptr, ptr %l67, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb43, label %bb44
bb43:
  %t125 = load ptr, ptr %l67, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 17}
  %t128 = icmp eq i64 %t126, 1
  store i1 %t128, ptr %l68, !tbaa !21
  br label %bb44
bb44:
  %t129 = load i1, ptr %l68, !tbaa !21
  br i1 %t129, label %bb45, label %bb46
bb45:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [3 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l4, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [3 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t138, i32 0, i32 2
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l5, !tbaa !29
  br label %bb47
bb46:
  br label %bb53
bb47:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l4, !tbaa !29
  %t146 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t142, ptr %t143)
  store i1 %t146, ptr %l77
  br label %bb48
bb48:
  %t147 = load i1, ptr %l77, !tbaa !21
  br i1 %t147, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb52
bb50:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l5, !tbaa !29
  %t153 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t148, ptr %t149)
  store i1 %t153, ptr %l82
  br label %bb51
bb51:
  %t154 = load i1, ptr %l82, !tbaa !21
  store i1 %t154, ptr %l78, !tbaa !21
  br label %bb52
bb52:
  %t155 = load i1, ptr %l78, !tbaa !21
  store i1 %t155, ptr %l14, !tbaa !21
  br label %bb134
bb53:
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t157 = load ptr, ptr %l83, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb54, label %bb55
bb54:
  %t160 = load ptr, ptr %l83, !tbaa !29
  %t161 = load i64, ptr %t160, !range !{i64 0, i64 17}
  %t163 = icmp eq i64 %t161, 3
  store i1 %t163, ptr %l84, !tbaa !21
  br label %bb55
bb55:
  %t164 = load i1, ptr %l84, !tbaa !21
  br i1 %t164, label %bb56, label %bb57
bb56:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr { i64, [3 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", ptr }, ptr %t167, i32 0, i32 1
  %t169 = load ptr, ptr %t168
  store ptr %t169, ptr %l6, !tbaa !29
  br label %bb58
bb57:
  br label %bb68
bb58:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l6, !tbaa !29
  %t174 = getelementptr %"compiler/typed:If", ptr %t172, i32 0, i32 0
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t179 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t171, ptr %t175)
  store i1 %t179, ptr %l93
  br label %bb59
bb59:
  %t180 = load i1, ptr %l93, !tbaa !21
  br i1 %t180, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb63
bb61:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load ptr, ptr %l6, !tbaa !29
  %t184 = getelementptr %"compiler/typed:If", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t189 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t181, ptr %t185)
  store i1 %t189, ptr %l99
  br label %bb62
bb62:
  %t190 = load i1, ptr %l99, !tbaa !21
  store i1 %t190, ptr %l94, !tbaa !21
  br label %bb63
bb63:
  %t191 = load i1, ptr %l94, !tbaa !21
  br i1 %t191, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb67
bb65:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load ptr, ptr %l6, !tbaa !29
  %t195 = getelementptr %"compiler/typed:If", ptr %t193, i32 0, i32 2
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t199 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t192, ptr %t196)
  store i1 %t199, ptr %l104
  br label %bb66
bb66:
  %t200 = load i1, ptr %l104, !tbaa !21
  store i1 %t200, ptr %l100, !tbaa !21
  br label %bb67
bb67:
  %t201 = load i1, ptr %l100, !tbaa !21
  store i1 %t201, ptr %l14, !tbaa !21
  br label %bb134
bb68:
  %t202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t202, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t203 = load ptr, ptr %l105, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb69, label %bb70
bb69:
  %t206 = load ptr, ptr %l105, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 4
  store i1 %t209, ptr %l106, !tbaa !21
  br label %bb70
bb70:
  %t210 = load i1, ptr %l106, !tbaa !21
  br i1 %t210, label %bb71, label %bb72
bb71:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l7, !tbaa !29
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr { i64, [3 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t219, i32 0, i32 2
  %t221 = load ptr, ptr %t220
  store ptr %t221, ptr %l8, !tbaa !29
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l7, !tbaa !29
  %t225 = load ptr, ptr %l8, !tbaa !29
  %t229 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %v1, ptr %t223, ptr %t224, ptr %t225)
  store i1 %t229, ptr %l116
  br label %bb74
bb74:
  %t230 = load i1, ptr %l116, !tbaa !21
  store i1 %t230, ptr %l14, !tbaa !21
  br label %bb134
bb75:
  %t231 = load ptr, ptr %l1, !tbaa !29
  store ptr %t231, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t232 = load ptr, ptr %l117, !tbaa !29
  %t233 = icmp ne ptr %t232, null
  br i1 %t233, label %bb76, label %bb77
bb76:
  %t235 = load ptr, ptr %l117, !tbaa !29
  %t236 = load i64, ptr %t235, !range !{i64 0, i64 17}
  %t238 = icmp eq i64 %t236, 9
  store i1 %t238, ptr %l118, !tbaa !21
  br label %bb77
bb77:
  %t239 = load i1, ptr %l118, !tbaa !21
  br i1 %t239, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/typed:leaveWalk", ptr %t240, i32 0, i32 2
  %t243 = load i1, ptr %t242, !tbaa !21
  store i1 %t243, ptr %l14, !tbaa !21
  br label %bb134
bb81:
  %t245 = load ptr, ptr %l1, !tbaa !29
  store ptr %t245, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t246 = load ptr, ptr %l123, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb82, label %bb83
bb82:
  %t249 = load ptr, ptr %l123, !tbaa !29
  %t250 = load i64, ptr %t249, !range !{i64 0, i64 17}
  %t252 = icmp eq i64 %t250, 10
  store i1 %t252, ptr %l124, !tbaa !21
  br label %bb83
bb83:
  %t253 = load i1, ptr %l124, !tbaa !21
  br i1 %t253, label %bb84, label %bb85
bb84:
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [3 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t256, i32 0, i32 1
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l9, !tbaa !29
  br label %bb86
bb85:
  br label %bb91
bb86:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/typed:leaveWalk", ptr %t260, i32 0, i32 2
  %t263 = load i1, ptr %t262, !tbaa !21
  br i1 %t263, label %bb87, label %bb88
bb87:
  %t265 = load ptr, ptr %l9, !tbaa !29
  %t267 = call i1 @compiler_2ftyped_2eassertTrue(ptr %v1, ptr %t265)
  store i1 %t267, ptr %l133
  br label %bb89
bb88:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb90
bb89:
  %t268 = load i1, ptr %l133, !tbaa !21
  %t269 = xor i1 %t268, true
  store i1 %t269, ptr %l131, !tbaa !21
  br label %bb90
bb90:
  %t271 = load i1, ptr %l131, !tbaa !21
  store i1 %t271, ptr %l14, !tbaa !21
  br label %bb134
bb91:
  %t272 = load ptr, ptr %l1, !tbaa !29
  store ptr %t272, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t273 = load ptr, ptr %l135, !tbaa !29
  %t274 = icmp ne ptr %t273, null
  br i1 %t274, label %bb92, label %bb93
bb92:
  %t276 = load ptr, ptr %l135, !tbaa !29
  %t277 = load i64, ptr %t276, !range !{i64 0, i64 17}
  %t279 = icmp eq i64 %t277, 11
  store i1 %t279, ptr %l136, !tbaa !21
  br label %bb93
bb93:
  %t280 = load i1, ptr %l136, !tbaa !21
  br i1 %t280, label %bb94, label %bb95
bb94:
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr { i64, [3 x i64] }, ptr %t281, i32 0, i32 1
  %t284 = getelementptr { %"compiler/source:Span", ptr }, ptr %t283, i32 0, i32 1
  %t285 = load ptr, ptr %t284
  store ptr %t285, ptr %l10, !tbaa !29
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load ptr, ptr %l10, !tbaa !29
  %t292 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eopenLeaves(ptr %v0, ptr %v1, ptr %t287, ptr %t288)
  store i1 %t292, ptr %l144
  br label %bb97
bb97:
  %t293 = load i1, ptr %l144, !tbaa !21
  store i1 %t293, ptr %l14, !tbaa !21
  br label %bb134
bb98:
  %t294 = load ptr, ptr %l1, !tbaa !29
  store ptr %t294, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t295 = load ptr, ptr %l145, !tbaa !29
  %t296 = icmp ne ptr %t295, null
  br i1 %t296, label %bb99, label %bb100
bb99:
  %t298 = load ptr, ptr %l145, !tbaa !29
  %t299 = load i64, ptr %t298, !range !{i64 0, i64 17}
  %t301 = icmp eq i64 %t299, 12
  store i1 %t301, ptr %l146, !tbaa !21
  br label %bb100
bb100:
  %t302 = load i1, ptr %l146, !tbaa !21
  br i1 %t302, label %bb101, label %bb102
bb101:
  %t303 = load ptr, ptr %l1, !tbaa !29
  %t305 = getelementptr { i64, [3 x i64] }, ptr %t303, i32 0, i32 1
  %t306 = getelementptr { %"compiler/source:Span", ptr }, ptr %t305, i32 0, i32 1
  %t307 = load ptr, ptr %t306
  store ptr %t307, ptr %l11, !tbaa !29
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l11, !tbaa !29
  %t314 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t309, ptr %t310)
  store i1 %t314, ptr %l154
  br label %bb104
bb104:
  %t315 = load i1, ptr %l154, !tbaa !21
  store i1 %t315, ptr %l14, !tbaa !21
  br label %bb134
bb105:
  %t316 = load ptr, ptr %l1, !tbaa !29
  store ptr %t316, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t317 = load ptr, ptr %l155, !tbaa !29
  %t318 = icmp ne ptr %t317, null
  br i1 %t318, label %bb106, label %bb107
bb106:
  %t320 = load ptr, ptr %l155, !tbaa !29
  %t321 = load i64, ptr %t320, !range !{i64 0, i64 17}
  %t323 = icmp eq i64 %t321, 13
  store i1 %t323, ptr %l156, !tbaa !21
  br label %bb107
bb107:
  %t324 = load i1, ptr %l156, !tbaa !21
  br i1 %t324, label %bb108, label %bb109
bb108:
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr { i64, [3 x i64] }, ptr %t325, i32 0, i32 1
  %t328 = getelementptr { %"compiler/source:Span", ptr }, ptr %t327, i32 0, i32 1
  %t329 = load ptr, ptr %t328
  store ptr %t329, ptr %l12, !tbaa !29
  br label %bb110
bb109:
  br label %bb126
bb110:
  %t331 = load ptr, ptr %l12, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Join", ptr %t331, i32 0, i32 1
  %t334 = load i1, ptr %t333, !tbaa !21
  br i1 %t334, label %bb111, label %bb112
bb111:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/typed:leaveWalk", ptr %t336, i32 0, i32 1
  %t339 = load i1, ptr %t338, !tbaa !21
  %t341 = xor i1 %t339, true
  store i1 %t341, ptr %l163, !tbaa !21
  br label %bb113
bb112:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb113
bb113:
  %t343 = load i1, ptr %l163, !tbaa !21
  br i1 %t343, label %bb114, label %bb115
bb114:
  %t344 = load ptr, ptr %l12, !tbaa !29
  %t346 = getelementptr %"compiler/typed:Join", ptr %t344, i32 0, i32 2
  %t347 = load { i64, ptr }, ptr %t346, !tbaa !27
  %t349 = call i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v1, { i64, ptr } %t347)
  store i1 %t349, ptr %l170
  br label %bb116
bb115:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb117
bb116:
  %t350 = load i1, ptr %l170, !tbaa !21
  %t351 = xor i1 %t350, true
  store i1 %t351, ptr %l167, !tbaa !21
  br label %bb117
bb117:
  %t353 = load i1, ptr %l167, !tbaa !21
  br i1 %t353, label %bb118, label %bb119
bb118:
  store i1 true, ptr %l172, !tbaa !21
  br label %bb121
bb119:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load ptr, ptr %l12, !tbaa !29
  %t357 = getelementptr %"compiler/typed:Join", ptr %t355, i32 0, i32 0
  %t358 = load ptr, ptr %t357, !tbaa !29
  %t362 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t354, ptr %t358)
  store i1 %t362, ptr %l177
  br label %bb120
bb120:
  %t363 = load i1, ptr %l177, !tbaa !21
  store i1 %t363, ptr %l172, !tbaa !21
  br label %bb121
bb121:
  %t364 = load i1, ptr %l172, !tbaa !21
  br i1 %t364, label %bb122, label %bb123
bb122:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb125
bb123:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load ptr, ptr %l12, !tbaa !29
  %t368 = getelementptr %"compiler/typed:Join", ptr %t366, i32 0, i32 2
  %t369 = load { i64, ptr }, ptr %t368, !tbaa !27
  %t372 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %t365, { i64, ptr } %t369)
  store i1 %t372, ptr %l182
  br label %bb124
bb124:
  %t373 = load i1, ptr %l182, !tbaa !21
  store i1 %t373, ptr %l178, !tbaa !21
  br label %bb125
bb125:
  %t374 = load i1, ptr %l178, !tbaa !21
  store i1 %t374, ptr %l14, !tbaa !21
  br label %bb134
bb126:
  %t375 = load ptr, ptr %l1, !tbaa !29
  store ptr %t375, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t376 = load ptr, ptr %l183, !tbaa !29
  %t377 = icmp ne ptr %t376, null
  br i1 %t377, label %bb127, label %bb128
bb127:
  %t379 = load ptr, ptr %l183, !tbaa !29
  %t380 = load i64, ptr %t379, !range !{i64 0, i64 17}
  %t382 = icmp eq i64 %t380, 14
  store i1 %t382, ptr %l184, !tbaa !21
  br label %bb128
bb128:
  %t383 = load i1, ptr %l184, !tbaa !21
  br i1 %t383, label %bb129, label %bb130
bb129:
  %t384 = load ptr, ptr %l1, !tbaa !29
  %t386 = getelementptr { i64, [3 x i64] }, ptr %t384, i32 0, i32 1
  %t387 = getelementptr { %"compiler/source:Span", ptr }, ptr %t386, i32 0, i32 1
  %t388 = load ptr, ptr %t387
  store ptr %t388, ptr %l13, !tbaa !29
  br label %bb131
bb130:
  br label %bb133
bb131:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load ptr, ptr %l13, !tbaa !29
  %t393 = getelementptr %"compiler/typed:Spawn", ptr %t391, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !29
  %t398 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t390, ptr %t394)
  store i1 %t398, ptr %l193
  br label %bb132
bb132:
  %t399 = load i1, ptr %l193, !tbaa !21
  store i1 %t399, ptr %l14, !tbaa !21
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_d15cb06393d6b10c_f6dc2a2381fafcf0)
  unreachable
bb134:
  %t400 = load i1, ptr %l14, !tbaa !21
  store i1 %t400, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t34 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 32)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  store ptr %l2, ptr %l39, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t59, ptr %l41, !tbaa !27
  %t60 = load i64, ptr %l8, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t69 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %v3, ptr %a0, ptr %t65)
  store { i64, ptr } %t69, ptr %l45
  br label %bb16
bb16:
  %t70 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t77 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t77, { i64, ptr } %t76)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l7, !tbaa !24
  br label %bb8
bb19:
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t84, ptr %l50
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t85 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2econstItems(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 91)
  br label %bb2
bb2:
  store i64 0, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb5:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l18, !tbaa !24
  store i64 %t34, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l15, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb13, label %bb14
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store ptr %l1, ptr %l39, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t59, ptr %l40, !tbaa !27
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t67 = call { i64, ptr } @compiler_2ftyped_2econstText(ptr %v0, ptr %s2, ptr %t65)
  store { i64, ptr } %t67, ptr %l43
  br label %bb17
bb17:
  %t68 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t75, { i64, ptr } %t74)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb9
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 93)
  br label %bb21
bb21:
  %t83 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t83, ptr %l49
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftyped_2efreshText(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 16
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Text", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = sext i32 %t24 to i64
  store i64 %t26, ptr %l8, !tbaa !24
  br label %bb28
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 5
  store i1 %t35, ptr %l19, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l19, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Promote", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i64, ptr %l1, !tbaa !24
  %t49 = add i64 %t47, 1
  %t52 = call i64 @compiler_2ftyped_2efreshText(ptr %v0, ptr %t46, i64 %t49)
  store i64 %t52, ptr %l28
  br label %bb15
bb15:
  %t53 = load i64, ptr %l28, !tbaa !24
  store i64 %t53, ptr %l8, !tbaa !24
  br label %bb28
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 17
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l30, !tbaa !21
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l4, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t70 = load i64, ptr %l1, !tbaa !24
  %t72 = add i64 %t70, 1
  %t75 = call i64 @compiler_2ftyped_2efreshText(ptr %v0, ptr %t69, i64 %t72)
  store i64 %t75, ptr %l38
  br label %bb22
bb22:
  %t76 = load i64, ptr %l38, !tbaa !24
  store i64 %t76, ptr %l8, !tbaa !24
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_48b93bf05ad91c8c_dfcbf93f670f6050)
  unreachable
bb28:
  %t77 = load i64, ptr %l8, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb24
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Make", ptr %t25, i32 0, i32 0
  %t28 = load i32, ptr %t27, !range !{i32 0, i32 5}
  %t30 = trunc i64 4 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l3, !tbaa !21
  br label %bb24
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb13, label %bb14
bb13:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 17
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l19, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l25
  br label %bb18
bb18:
  %t53 = load i1, ptr %l25, !tbaa !21
  store i1 %t53, ptr %l3, !tbaa !21
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_bea5bf6ffc689610_b71acf810bfa0324)
  unreachable
bb24:
  %t54 = load i1, ptr %l3, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2enamedHoldsWritable(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load i32, ptr %l7, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !range !{i32 0, i32 6}
  store i32 %t10, ptr %l3
  %t11 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t13 = trunc i64 2 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t18 = trunc i64 5 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t25 = trunc i64 3 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb12
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l20
  br label %bb11
bb11:
  %t33 = load i1, ptr %l20, !tbaa !21
  %t34 = xor i1 %t33, true
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t38 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t40 = trunc i64 4 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l28
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = add i64 %t49, 1
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load i32, ptr %l28, !tbaa !23
  %t55 = call i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %t52, i32 %t53, i64 %t51)
  store i1 %t55, ptr %l31
  br label %bb19
bb19:
  %t56 = load i1, ptr %l31, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
bb20:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l1, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l36
  br label %bb21
bb21:
  %t64 = load ptr, ptr %l33, !tbaa !29
  %t65 = load i32, ptr %l36, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t64, i32 %t65)
  store { i64, ptr } %t66, ptr %l37
  br label %bb22
bb22:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load ptr, ptr %l32, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t71 = call i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v0, ptr %t68, { i64, ptr } %t69, i64 %t67)
  store i1 %t71, ptr %l39
  br label %bb23
bb23:
  %t72 = load i1, ptr %l39, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb29
bb25:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l42, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l45
  br label %bb26
bb26:
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = load i32, ptr %l45, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t80, i32 %t81)
  store { i64, ptr } %t82, ptr %l46
  br label %bb27
bb27:
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load ptr, ptr %l41, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t87 = call i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v0, ptr %t84, { i64, ptr } %t85, i64 %t83)
  store i1 %t87, ptr %l48
  br label %bb28
bb28:
  %t88 = load i1, ptr %l48, !tbaa !21
  store i1 %t88, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t89 = load i1, ptr %l40, !tbaa !21
  br i1 %t89, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb35
bb31:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l50, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l51, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l1, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l54
  br label %bb32
bb32:
  %t97 = load ptr, ptr %l51, !tbaa !29
  %t98 = load i32, ptr %l54, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t97, i32 %t98)
  store { i64, ptr } %t99, ptr %l55
  br label %bb33
bb33:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load ptr, ptr %l50, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t104 = call i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v0, ptr %t101, { i64, ptr } %t102, i64 %t100)
  store i1 %t104, ptr %l57
  br label %bb34
bb34:
  %t105 = load i1, ptr %l57, !tbaa !21
  store i1 %t105, ptr %l49, !tbaa !21
  br label %bb35
bb35:
  %t106 = load i1, ptr %l49, !tbaa !21
  store i1 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb54
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t43, i32 %t45)
  store i1 %t48, ptr %l29
  br label %bb20
bb20:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l7, !tbaa !21
  br label %bb54
bb21:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb22, label %bb23
bb22:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l38
  br label %bb27
bb27:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l7, !tbaa !21
  br label %bb54
bb28:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb29, label %bb30
bb29:
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 8}
  %t78 = icmp eq i64 %t76, 4
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb30
bb30:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb31, label %bb32
bb31:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Elem", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  %t93 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t89, i32 %t90)
  store i1 %t93, ptr %l48
  br label %bb34
bb34:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb38
bb36:
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Elem", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = load i32, ptr %l1, !tbaa !23
  %t103 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t98, i32 %t100)
  store i1 %t103, ptr %l54
  br label %bb37
bb37:
  %t104 = load i1, ptr %l54, !tbaa !21
  store i1 %t104, ptr %l49, !tbaa !21
  br label %bb38
bb38:
  %t105 = load i1, ptr %l49, !tbaa !21
  store i1 %t105, ptr %l7, !tbaa !21
  br label %bb54
bb39:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t107 = load ptr, ptr %l55, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb40, label %bb41
bb40:
  %t110 = load ptr, ptr %l55, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 8}
  %t113 = icmp eq i64 %t111, 5
  store i1 %t113, ptr %l56, !tbaa !21
  br label %bb41
bb41:
  %t114 = load i1, ptr %l56, !tbaa !21
  br i1 %t114, label %bb42, label %bb43
bb42:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Payload", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = load i32, ptr %l1, !tbaa !23
  %t128 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t124, i32 %t125)
  store i1 %t128, ptr %l64
  br label %bb45
bb45:
  %t129 = load i1, ptr %l64, !tbaa !21
  store i1 %t129, ptr %l7, !tbaa !21
  br label %bb54
bb46:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb47, label %bb48
bb47:
  %t134 = load ptr, ptr %l65, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 6
  store i1 %t137, ptr %l66, !tbaa !21
  br label %bb48
bb48:
  %t138 = load i1, ptr %l66, !tbaa !21
  br i1 %t138, label %bb49, label %bb50
bb49:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l6, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t145 = load ptr, ptr %l6, !tbaa !29
  %t147 = load i32, ptr %l1, !tbaa !23
  %t150 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t145, i32 %t147)
  store i1 %t150, ptr %l74
  br label %bb52
bb52:
  %t151 = load i1, ptr %l74, !tbaa !21
  store i1 %t151, ptr %l7, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_f3346b4d6d82824c_aeee08707a274ea0)
  unreachable
bb54:
  %t152 = load i1, ptr %l7, !tbaa !21
  store i1 %t152, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftyped_2ereadScopes(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, [2 x i64] }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, [2 x i64] }
  %l50 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ewordsOf(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l2)
  store i64 %t6, ptr %l12
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = load i64, ptr %l12, !tbaa !24
  %t12 = icmp ne i64 %t10, %t9
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %l3, !tbaa !24
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l2)
  store i64 %t16, ptr %l18
  br label %bb6
bb6:
  %t17 = load i64, ptr %l18, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb12
bb9:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l25, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %l22, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l22, !tbaa !24
  store i64 %t45, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb22
bb15:
  br label %bb16
bb16:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l8, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t64, ptr %l43, !tbaa !27
  %t65 = load i64, ptr %l8, !tbaa !24
  store i64 %t65, ptr %l44, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l2, i64 %t66)
  store { i64, ptr } %t69, ptr %l48
  br label %bb17
bb17:
  %t70 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t71 = call { i32, { i64, [2 x i64] } } @compiler_2ftyped_2eScope_2eOfText(ptr %s0, { i64, ptr } %t70)
  %t72 = extractvalue { i32, { i64, [2 x i64] } } %t71, 1
  %t73 = extractvalue { i32, { i64, [2 x i64] } } %t71, 0
  store i32 %t73, ptr %l50
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb19, label %ok.75, !prof !99
ok.75:
  store { i64, [2 x i64] } %t72, ptr %l49
  br label %bb18
bb18:
  %t76 = load { i64, [2 x i64] }, ptr %l49
  store { i64, [2 x i64] } %t76, ptr %l45
  br label %bb20
bb19:
  %t77 = load i32, ptr %l50, !tbaa !23
  %t78 = lshr i32 %t77, 16
  %t79 = and i32 %t77, 65535
  %t80 = icmp eq i32 %t78, 1
  %t81 = select i1 %t80, i32 1, i32 0
  %t82 = icmp eq i32 %t77, 0
  %t83 = shl i32 %t81, 16
  %t84 = or i32 %t83, %t79
  %t85 = select i1 %t82, i32 0, i32 %t84
  call void @__olang_scope_close(ptr %s0)
  store i32 %t85, ptr %rv
  br label %ret
bb20:
  %t87 = load { i64, [2 x i64] }, ptr %l45
  %t88 = load i64, ptr %l44, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, [2 x i64] }, ptr %t90, i64 %t88
  store { i64, [2 x i64] } %t87, ptr %t91
  br label %bb21
bb21:
  %t92 = load i64, ptr %l7, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l7, !tbaa !24
  br label %bb13
bb22:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftyped_2estmtFails(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l21 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i1
  %l55 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 17}
  %t17 = icmp eq i64 %t15, 8
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 17}
  %t26 = icmp eq i64 %t24, 9
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb48
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t29 = load ptr, ptr %l17, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 17}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l18, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l18, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr }, ptr %t39, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t42 = load ptr, ptr %l23, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb21
bb19:
  %t45 = load ptr, ptr %l23, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 18}
  %t48 = icmp eq i64 %t46, 6
  store i1 %t48, ptr %l24, !tbaa !21
  br label %bb20
bb20:
  %t49 = load i1, ptr %l24, !tbaa !21
  store i1 %t49, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t50 = load i1, ptr %l21, !tbaa !21
  br i1 %t50, label %bb22, label %bb23
bb22:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr { i64, [3 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", ptr }, ptr %t53, i32 0, i32 1
  %t55 = load ptr, ptr %t54
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l1, !tbaa !23
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t61 = load i32, ptr %l1, !tbaa !23
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t65 = icmp eq i32 %t61, %t62
  store i1 %t65, ptr %l4, !tbaa !21
  br label %bb48
bb25:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t68 = load ptr, ptr %l33, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb26, label %bb27
bb26:
  %t71 = load ptr, ptr %l33, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 17}
  %t74 = icmp eq i64 %t72, 11
  store i1 %t74, ptr %l34, !tbaa !21
  br label %bb27
bb27:
  %t75 = load i1, ptr %l34, !tbaa !21
  br i1 %t75, label %bb28, label %bb29
bb28:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr { i64, [3 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", ptr }, ptr %t78, i32 0, i32 1
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l2, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t85 = call i1 @compiler_2ftyped_2eFails(ptr %v0, ptr %t82)
  store i1 %t85, ptr %l41
  br label %bb31
bb31:
  %t86 = load i1, ptr %l41, !tbaa !21
  store i1 %t86, ptr %l4, !tbaa !21
  br label %bb48
bb32:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t88 = load ptr, ptr %l42, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb33, label %bb34
bb33:
  %t91 = load ptr, ptr %l42, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 17}
  %t94 = icmp eq i64 %t92, 3
  store i1 %t94, ptr %l43, !tbaa !21
  br label %bb34
bb34:
  %t95 = load i1, ptr %l43, !tbaa !21
  br i1 %t95, label %bb35, label %bb36
bb35:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr { i64, [3 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l3, !tbaa !29
  br label %bb37
bb36:
  br label %bb43
bb37:
  %t102 = load ptr, ptr %l3, !tbaa !29
  %t104 = getelementptr %"compiler/typed:If", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t108 = call i1 @compiler_2ftyped_2eFails(ptr %v0, ptr %t105)
  store i1 %t108, ptr %l51
  br label %bb38
bb38:
  %t109 = load i1, ptr %l51, !tbaa !21
  br i1 %t109, label %bb39, label %bb40
bb39:
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t112 = getelementptr %"compiler/typed:If", ptr %t110, i32 0, i32 2
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = call i1 @compiler_2ftyped_2eFails(ptr %v0, ptr %t113)
  store i1 %t115, ptr %l55
  br label %bb41
bb40:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb42
bb41:
  %t116 = load i1, ptr %l55, !tbaa !21
  store i1 %t116, ptr %l52, !tbaa !21
  br label %bb42
bb42:
  %t117 = load i1, ptr %l52, !tbaa !21
  store i1 %t117, ptr %l4, !tbaa !21
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_a2953a30b2f8c4d8_7c37346654e0475c)
  unreachable
bb48:
  %t118 = load i1, ptr %l4, !tbaa !21
  store i1 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2estoresNothing(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 52}
  %t3 = trunc i64 25 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb13
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 52}
  %t8 = trunc i64 26 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 52}
  %t13 = trunc i64 27 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 52}
  %t18 = trunc i64 28 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 52}
  %t23 = trunc i64 30 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  %t26 = load i32, ptr %l0, !range !{i32 0, i32 52}
  %t28 = trunc i64 29 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_27c76e49adb539dc_ebba4be7d4da8e48)
  unreachable
bb19:
  %t31 = load i1, ptr %l1, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2etargetsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb16
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t40 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t36, i32 %a1)
  store i1 %t40, ptr %l26
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb11
bb10:
  %t41 = load i1, ptr %l26, !tbaa !21
  store i1 %t41, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l3, !tbaa !24
  br label %bb4
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eturnStmt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 17}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  %t36 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t31, %"compiler/source:Span" %t33)
  store i1 %t36, ptr %l22
  br label %bb10
bb10:
  %t37 = load i1, ptr %l22, !tbaa !21
  store i1 %t37, ptr %l6, !tbaa !21
  br label %bb34
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load ptr, ptr %l23, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 17}
  %t45 = icmp eq i64 %t43, 1
  store i1 %t45, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t46 = load i1, ptr %l24, !tbaa !21
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l3, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr { i64, [3 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  %t63 = call i1 @compiler_2ftyped_2eturnPlace(ptr %v0, ptr %t59, %"compiler/source:Span" %t60)
  store i1 %t63, ptr %l33
  br label %bb17
bb17:
  %t64 = load i1, ptr %l33, !tbaa !21
  br i1 %t64, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb21
bb19:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  %t70 = call i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %t65, %"compiler/source:Span" %t67)
  store i1 %t70, ptr %l38
  br label %bb20
bb20:
  %t71 = load i1, ptr %l38, !tbaa !21
  store i1 %t71, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t72 = load i1, ptr %l34, !tbaa !21
  store i1 %t72, ptr %l6, !tbaa !21
  br label %bb34
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t74 = load ptr, ptr %l39, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb23, label %bb24
bb23:
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 17}
  %t80 = icmp eq i64 %t78, 11
  store i1 %t80, ptr %l40, !tbaa !21
  br label %bb24
bb24:
  %t81 = load i1, ptr %l40, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr { i64, [3 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", ptr }, ptr %t84, i32 0, i32 1
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l1
  %t92 = call i1 @compiler_2ftyped_2eEveryTurn(ptr %v0, ptr %t88, %"compiler/source:Span" %t89)
  store i1 %t92, ptr %l47
  br label %bb28
bb28:
  %t93 = load i1, ptr %l47, !tbaa !21
  store i1 %t93, ptr %l6, !tbaa !21
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_b972818c6780b098_95e0408c3aef143c)
  unreachable
bb34:
  %t94 = load i1, ptr %l6, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2eunion(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t19, i64 %t20)
  store i1 %t23, ptr %l16
  br label %bb7
bb7:
  %t24 = load i1, ptr %l16, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t27, i64 %t28)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Arm"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Arm" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/typed:Arm" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Arm" %t14, ptr %a2, 2
  %t18 = insertvalue %"compiler/typed:Arm" %t16, ptr %a3, 3
  %t20 = insertvalue %"compiler/typed:Arm" %t18, ptr %a4, 4
  store %"compiler/typed:Arm" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Arm", ptr %rv
  ret %"compiler/typed:Arm" %rr
}

define dso_local %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Capture"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Capture" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Capture" %t6, ptr %a1, 1
  store %"compiler/typed:Capture" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Capture", ptr %rv
  ret %"compiler/typed:Capture" %rr
}

define dso_local %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i32 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Collect"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Collect" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/typed:Collect" %t12, ptr %a1, 1
  %t16 = insertvalue %"compiler/typed:Collect" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/typed:Collect" %t16, i32 %a3, 3
  %t20 = insertvalue %"compiler/typed:Collect" %t18, i1 %a4, 4
  store %"compiler/typed:Collect" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Collect", ptr %rv
  ret %"compiler/typed:Collect" %rr
}

define dso_local void @compiler_2ftyped_3aContractInfo_2ector(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"compiler/typed:ContractInfo"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 %a1, ptr %l3, !tbaa !24
  %t5 = ptrtoint ptr %v1 to i64
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e2
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call ptr @__olang_region_make(ptr %v1)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l10, !tbaa !24
  br label %bb2
bb2:
  %t10 = load i64, ptr %l10
  %t11 = inttoptr i64 %t10 to ptr
  %t12 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t11, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l12
  br label %bb3
bb3:
  %t13 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e2
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load i64, ptr %l10
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12, i32 0, i32 0
  %t18 = load { i64, ptr }, ptr %t17
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = call ptr @__olang_region_or(ptr %t19, ptr null)
  %t21 = call ptr @__olang_region_home(ptr %t20)
  %t22 = icmp ne ptr %t21, null
  %t23 = select i1 %t22, ptr %t21, ptr null
  %t24 = icmp eq ptr %t23, %t16
  call void @__olang_region_settle(ptr %t16, i1 %t24)
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l4
  %t26 = ptrtoint ptr %v1 to i64
  store i64 %t26, ptr %l14, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e3
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = call ptr @__olang_region_make(ptr %v1)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l14
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t32, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l16
  br label %bb8
bb8:
  %t34 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e3
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l14
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = call ptr @__olang_region_or(ptr %t40, ptr null)
  %t42 = call ptr @__olang_region_home(ptr %t41)
  %t43 = icmp ne ptr %t42, null
  %t44 = select i1 %t43, ptr %t42, ptr null
  %t45 = icmp eq ptr %t44, %t37
  call void @__olang_region_settle(ptr %t37, i1 %t45)
  br label %bb10
bb10:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l5
  %t47 = ptrtoint ptr %v1 to i64
  store i64 %t47, ptr %l18, !tbaa !24
  %t48 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e4
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = call ptr @__olang_region_make(ptr %v1)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l18, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i64, ptr %l18
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t53, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l20
  br label %bb13
bb13:
  %t55 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e4
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load i64, ptr %l18
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = call ptr @__olang_region_or(ptr %t61, ptr null)
  %t63 = call ptr @__olang_region_home(ptr %t62)
  %t64 = icmp ne ptr %t63, null
  %t65 = select i1 %t64, ptr %t63, ptr null
  %t66 = icmp eq ptr %t65, %t58
  call void @__olang_region_settle(ptr %t58, i1 %t66)
  br label %bb15
bb15:
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l6
  %t68 = ptrtoint ptr %v1 to i64
  store i64 %t68, ptr %l22, !tbaa !24
  %t69 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e5
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t71 = call ptr @__olang_region_make(ptr %v1)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l22, !tbaa !24
  br label %bb17
bb17:
  %t73 = load i64, ptr %l22
  %t74 = inttoptr i64 %t73 to ptr
  %t75 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t74, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l24
  br label %bb18
bb18:
  %t76 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e5
  br i1 %t76, label %bb19, label %bb20
bb19:
  %t78 = load i64, ptr %l22
  %t79 = inttoptr i64 %t78 to ptr
  %t80 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = call ptr @__olang_region_or(ptr %t82, ptr null)
  %t84 = call ptr @__olang_region_home(ptr %t83)
  %t85 = icmp ne ptr %t84, null
  %t86 = select i1 %t85, ptr %t84, ptr null
  %t87 = icmp eq ptr %t86, %t79
  call void @__olang_region_settle(ptr %t79, i1 %t87)
  br label %bb20
bb20:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  %t89 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 0
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t90, ptr %t89, !tbaa !27
  %t91 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 1
  %t92 = load i64, ptr %l3, !tbaa !24
  store i64 %t92, ptr %t91, !tbaa !24
  %t93 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 2
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %t93
  %t95 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 3
  %t96 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %t95
  %t97 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 4
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %t97
  %t99 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %t99
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l26, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6) #0 {
entry:
  %rv = alloca %"compiler/typed:Make"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/typed:Make" undef, i32 %a0, 0
  %t18 = insertvalue %"compiler/typed:Make" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/typed:Make" %t18, { i64, ptr } %a2, 2
  %t22 = insertvalue %"compiler/typed:Make" %t20, ptr %a3, 3
  %t24 = insertvalue %"compiler/typed:Make" %t22, i32 %a4, 4
  %t26 = insertvalue %"compiler/typed:Make" %t24, i32 %a5, 5
  %t28 = insertvalue %"compiler/typed:Make" %t26, i1 %a6, 6
  store %"compiler/typed:Make" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Make", ptr %rv
  ret %"compiler/typed:Make" %rr
}

define dso_local %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Payload"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Payload" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Payload" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/typed:Payload" %t10, i32 %a2, 2
  store %"compiler/typed:Payload" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Payload", ptr %rv
  ret %"compiler/typed:Payload" %rr
}

define dso_local void @compiler_2ftyped_3aRefsKept_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca i64
  %l5 = alloca i64
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca %"compiler/typed:RefsKept"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = ptrtoint ptr %v0 to i64
  store i64 %t1, ptr %l5, !tbaa !24
  %t2 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = call ptr @__olang_region_make(ptr %v0)
  %t5 = ptrtoint ptr %t4 to i64
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t6 = load i64, ptr %l5
  %t7 = inttoptr i64 %t6 to ptr
  %t8 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t7)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e0
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l5
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7, i32 0, i32 2
  %t14 = load { i64, ptr }, ptr %t13
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = call ptr @__olang_region_or(ptr %t15, ptr null)
  %t17 = call ptr @__olang_region_home(ptr %t16)
  %t18 = icmp ne ptr %t17, null
  %t19 = select i1 %t18, ptr %t17, ptr null
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = call ptr @__olang_region_or(ptr %t22, ptr null)
  %t24 = call ptr @__olang_region_home(ptr %t23)
  %t25 = icmp ne ptr %t24, null
  %t26 = select i1 %t25, ptr %t24, ptr %t19
  %t27 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27
  %t29 = extractvalue { i64, ptr } %t28, 1
  %t30 = call ptr @__olang_region_or(ptr %t29, ptr null)
  %t31 = call ptr @__olang_region_home(ptr %t30)
  %t32 = icmp ne ptr %t31, null
  %t33 = select i1 %t32, ptr %t31, ptr %t26
  %t34 = icmp eq ptr %t33, %t12
  call void @__olang_region_settle(ptr %t12, i1 %t34)
  br label %bb5
bb5:
  %t35 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %l0
  %t36 = ptrtoint ptr %v0 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e1
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = call ptr @__olang_region_make(ptr %v0)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l9
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t42)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %l11
  br label %bb8
bb8:
  %t44 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e1
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load i64, ptr %l9
  %t47 = inttoptr i64 %t46 to ptr
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11, i32 0, i32 2
  %t49 = load { i64, ptr }, ptr %t48
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = call ptr @__olang_region_or(ptr %t50, ptr null)
  %t52 = call ptr @__olang_region_home(ptr %t51)
  %t53 = icmp ne ptr %t52, null
  %t54 = select i1 %t53, ptr %t52, ptr null
  %t55 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = call ptr @__olang_region_or(ptr %t57, ptr null)
  %t59 = call ptr @__olang_region_home(ptr %t58)
  %t60 = icmp ne ptr %t59, null
  %t61 = select i1 %t60, ptr %t59, ptr %t54
  %t62 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = call ptr @__olang_region_or(ptr %t64, ptr null)
  %t66 = call ptr @__olang_region_home(ptr %t65)
  %t67 = icmp ne ptr %t66, null
  %t68 = select i1 %t67, ptr %t66, ptr %t61
  %t69 = icmp eq ptr %t68, %t47
  call void @__olang_region_settle(ptr %t47, i1 %t69)
  br label %bb10
bb10:
  %t70 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t70, ptr %l1
  %t71 = ptrtoint ptr %v0 to i64
  store i64 %t71, ptr %l13, !tbaa !24
  %t72 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e2
  br i1 %t72, label %bb11, label %bb12
bb11:
  %t74 = call ptr @__olang_region_make(ptr %v0)
  %t75 = ptrtoint ptr %t74 to i64
  store i64 %t75, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  %t76 = load i64, ptr %l13
  %t77 = inttoptr i64 %t76 to ptr
  %t78 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t77)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t78, ptr %l15
  br label %bb13
bb13:
  %t79 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e2
  br i1 %t79, label %bb14, label %bb15
bb14:
  %t81 = load i64, ptr %l13
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15, i32 0, i32 2
  %t84 = load { i64, ptr }, ptr %t83
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = call ptr @__olang_region_or(ptr %t85, ptr null)
  %t87 = call ptr @__olang_region_home(ptr %t86)
  %t88 = icmp ne ptr %t87, null
  %t89 = select i1 %t88, ptr %t87, ptr null
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %t90
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = call ptr @__olang_region_or(ptr %t92, ptr null)
  %t94 = call ptr @__olang_region_home(ptr %t93)
  %t95 = icmp ne ptr %t94, null
  %t96 = select i1 %t95, ptr %t94, ptr %t89
  %t97 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15, i32 0, i32 0
  %t98 = load { i64, ptr }, ptr %t97
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = call ptr @__olang_region_home(ptr %t100)
  %t102 = icmp ne ptr %t101, null
  %t103 = select i1 %t102, ptr %t101, ptr %t96
  %t104 = icmp eq ptr %t103, %t82
  call void @__olang_region_settle(ptr %t82, i1 %t104)
  br label %bb15
bb15:
  %t105 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t105, ptr %l2
  store i64 9223372036854775807, ptr %l3, !tbaa !24
  %t106 = ptrtoint ptr %v0 to i64
  store i64 %t106, ptr %l17, !tbaa !24
  %t107 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e4
  br i1 %t107, label %bb16, label %bb17
bb16:
  %t109 = call ptr @__olang_region_make(ptr %v0)
  %t110 = ptrtoint ptr %t109 to i64
  store i64 %t110, ptr %l17, !tbaa !24
  br label %bb17
bb17:
  %t111 = load i64, ptr %l17
  %t112 = inttoptr i64 %t111 to ptr
  %t113 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t112)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t113, ptr %l19
  br label %bb18
bb18:
  %t114 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e4
  br i1 %t114, label %bb19, label %bb20
bb19:
  %t116 = load i64, ptr %l17
  %t117 = inttoptr i64 %t116 to ptr
  %t118 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19, i32 0, i32 2
  %t119 = load { i64, ptr }, ptr %t118
  %t120 = extractvalue { i64, ptr } %t119, 1
  %t121 = call ptr @__olang_region_or(ptr %t120, ptr null)
  %t122 = call ptr @__olang_region_home(ptr %t121)
  %t123 = icmp ne ptr %t122, null
  %t124 = select i1 %t123, ptr %t122, ptr null
  %t125 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = call ptr @__olang_region_or(ptr %t127, ptr null)
  %t129 = call ptr @__olang_region_home(ptr %t128)
  %t130 = icmp ne ptr %t129, null
  %t131 = select i1 %t130, ptr %t129, ptr %t124
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = call ptr @__olang_region_or(ptr %t134, ptr null)
  %t136 = call ptr @__olang_region_home(ptr %t135)
  %t137 = icmp ne ptr %t136, null
  %t138 = select i1 %t137, ptr %t136, ptr %t131
  %t139 = icmp eq ptr %t138, %t117
  call void @__olang_region_settle(ptr %t117, i1 %t139)
  br label %bb20
bb20:
  %t140 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  %t141 = getelementptr %"compiler/typed:RefsKept", ptr %l21, i32 0, i32 0
  %t142 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t142, ptr %t141
  %t143 = getelementptr %"compiler/typed:RefsKept", ptr %l21, i32 0, i32 1
  %t144 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t144, ptr %t143
  %t145 = getelementptr %"compiler/typed:RefsKept", ptr %l21, i32 0, i32 2
  %t146 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t146, ptr %t145
  %t147 = getelementptr %"compiler/typed:RefsKept", ptr %l21, i32 0, i32 3
  %t148 = load i64, ptr %l3, !tbaa !24
  store i64 %t148, ptr %t147, !tbaa !24
  %t149 = getelementptr %"compiler/typed:RefsKept", ptr %l21, i32 0, i32 4
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t140, ptr %t149
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l21, i64 296, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Slice"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Slice" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/typed:Slice" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/typed:Slice" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/typed:Slice" %t14, i32 %a3, 3
  store %"compiler/typed:Slice" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Slice", ptr %rv
  ret %"compiler/typed:Slice" %rr
}

define dso_local %"compiler/typed:landState" @compiler_2ftyped_3alandState_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:landState"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:landState" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:landState" %t6, i1 %a1, 1
  store %"compiler/typed:landState" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:landState", ptr %rv
  ret %"compiler/typed:landState" %rr
}

define dso_local %"compiler/typed:leaveWalk" @compiler_2ftyped_3aleaveWalk_2ector(ptr %v0) #0 {
entry:
  %l3 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/typed:leaveWalk"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = ptrtoint ptr %v0 to i64
  store i64 %t1, ptr %l3, !tbaa !24
  %t2 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aleaveWalk_2e0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = call ptr @__olang_region_make(ptr %v0)
  %t5 = ptrtoint ptr %t4 to i64
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t6 = load i64, ptr %l3
  %t7 = inttoptr i64 %t6 to ptr
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  br label %bb3
bb3:
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aleaveWalk_2e0
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l3
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = call ptr @__olang_region_or(ptr %t15, ptr null)
  %t17 = call ptr @__olang_region_home(ptr %t16)
  %t18 = icmp ne ptr %t17, null
  %t19 = select i1 %t18, ptr %t17, ptr null
  %t20 = icmp eq ptr %t19, %t12
  call void @__olang_region_settle(ptr %t12, i1 %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t23 = insertvalue %"compiler/typed:leaveWalk" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, 0
  %t25 = insertvalue %"compiler/typed:leaveWalk" %t23, i1 false, 1
  %t27 = insertvalue %"compiler/typed:leaveWalk" %t25, i1 false, 2
  store %"compiler/typed:leaveWalk" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:leaveWalk", ptr %rv
  ret %"compiler/typed:leaveWalk" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" |" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"U" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"B" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"V" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"P" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"F" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"I" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"O" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"D" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
declare ptr @__olang_scope_or(ptr, ptr)
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"N" }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"R" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @__olang_bang_failed_plain(ptr) cold noreturn
@olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2ematch_2elocal_2e7 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle(ptr, i1)
declare void @__olang_region_drop(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e0 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aRefsKept_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aleaveWalk_2e0 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9640b30413567955_c65a1e6fb20cf981 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_c8cee6ec101913bd_743c2b1d0ab2dad9 = external constant [0 x i8]
@olang_loc_831440fdfc819328_dabfa81c01cf773c = external constant [0 x i8]
@olang_loc_7bdf3cb2fb8351f9_389183759a182ed = external constant [0 x i8]
declare ptr @compiler_2ftyped_2ecopied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_3aDropHolding_2ector(ptr %out, ptr %v0)
@olang_loc_1d48dcdc24016ab9_795d1a331a4bc775 = external constant [0 x i8]
declare void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2ftyped_2esharedBlock(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare void @compiler_2ftyped_3aholdWalk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H76000d29bd4678bab17d21d786d60caf(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eClear_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefusals(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclosure(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_3aLastUses_2ector(ptr %out, ptr %v0, i64 %a0)
@olang_loc_160fc62cca54a9e9_1017e7cee7f3c75d = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_3aLocalUses_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ePus_H0c70e9e86794aea54789ff5f3987086b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5a8d28bd3acbc65d_f5c7f83d77176e09 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecloseAliases(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_c21a1343bdb3d01_d6f77a8ccb597545 = external constant [0 x i8]
@olang_loc_4964fda744059959_ea5b63edb7fb932d = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_3aPlan_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftyped_2ereadBits(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ewordsOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_513fe42ccd619edb_f9eefb0210e3c837 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_f54e407a1957a5de_bac5f2aedbd3a6da = external constant [0 x i8]
declare { i32, { i64, [2 x i64] } } @compiler_2ftyped_2eScope_2eOfText(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eToArray_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_a2b2db9c76964d3d_44f19efa61cd8f79 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_db138e9723fb9fe0_9822d1289854fb4c = external constant [0 x i8]
@olang_loc_850ab3b4cafc30bf_b865ab70d4df5d13 = external constant [0 x i8]
declare %"compiler/typed:DerivedArg" @compiler_2ftyped_3aDerivedArg_2ector(ptr %v0, i64 %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2ePus_Hd9c60b9bc3eb0bc15b58bce924fabf2c(ptr %v0, ptr %a0, %"compiler/typed:DerivedArg" %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassDerived(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
@olang_loc_4b5d458aacbb0718_a8ad2bd2a7dc13cc = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i1 @compiler_2ftyped_2einert(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eexprsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %v0, i32 %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ePush_H85e1838377aa8e6b322d82e3edbac596(ptr %v0, ptr %a0, %"compiler/typed:BlockInfo" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
declare %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ePush_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %a0, %"compiler/typed:SiteInfo" %a1)
@olang_loc_3a838910fbaaf0b4_28daeb84482f7128 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2elastAfter(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eLen_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:landLoop" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eAt_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2eorInto(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eSetAt_H5ab2aabe0ae7951e8bb06fbe4ca7219a(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/typed:landLoop" %a2)
declare i64 @compiler_2ftyped_2ewholeLocal(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2)
@olang_loc_c889b00966965144_dcfe1455a200f620 = external constant [0 x i8]
declare ptr @compiler_2ftyped_2econverted(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2emayHold(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elink(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3, i64 %a4, i64 %a5)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_572ff0c594eb7d28_3eb561bfca5d9eb4 = external constant [0 x i8]
@olang_loc_6333e3fa20d2f5d8_bcafed7a04540454 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_4f6de7c744c3571c_6f8dca6bf99a5cd8 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eescape(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecopied(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_2bdab9da3f4d_ded05e4518f32fa9 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eExprAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @compiler_2ftyped_2etypeWord(ptr %v0, ptr %v1, i32 %a0, ptr %a1c, ptr %a1e)
declare { i32, { i64, ptr } } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplaceWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2c, ptr %a2e)
@olang_loc_afe89d4716bb52e8_bab84d91c7a69354 = external constant [0 x i8]
declare %"compiler/typed:wordReader" @compiler_2ftyped_3awordReader_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_fc4a9e97a0375850_6fc32d1d5d28aa84 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eoptArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2eint(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, %"compiler/source:Span" } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2espan(ptr %v0, ptr %a0)
declare { i32, i32 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2ety(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2echar(ptr %v0, ptr %a0, i8 %a1)
declare { i32, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_Hb773ac01a07f3f9e7f749c328573d0ee(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2enoneIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2enoneKeptIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eRemove_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2ecarries(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eReachRow(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_1728180708920569_396f77e53f37dbed = external constant [0 x i8]
@olang_loc_64712ec69db6f686_5286ea6d6f8bc3a = external constant [0 x i8]
@olang_loc_3937948e4172da86_b4226ee484a284a = external constant [0 x i8]
@olang_loc_e2e1378986f13fd0_6a804f95244a4cf4 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eaddDef(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3, ptr %a4, i1 %a5)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eDefOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3)
@olang_loc_77315c1e1ec03e98_be22ee0dd90c53a4 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_456f0c0b74db68d5_29242d1724c8a7c1 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eCle_H9e31dbf06df58c38226424712d120dfe(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hdc84c10e1af960a666eeb267120f3ec3(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_59830ee0ec754a32_f5aff824d93b155e = external constant [0 x i8]
@olang_loc_b8ff85e818b1a126_11cf17c421c4721a = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_38f82f633fcbfe78_2a415e18f8868a4c = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5f0c96ba8f37c420_5ca612e1d5c707f4 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %a0, i1 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_2676a1f2cfb255f8_2530c83c98e00394 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2emix(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempGiven(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregisteredBefore(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_77c9af98e9dace58_20acd54f7de13794 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_10efe43793a641ac_2dabf1c43cd6a168 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eopenLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4c49c2cc391943fc_885b7fff3b4a3180 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eHas_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2eassertTrue(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_d15cb06393d6b10c_f6dc2a2381fafcf0 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2ftyped_2econstText(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_48b93bf05ad91c8c_dfcbf93f670f6050 = external constant [0 x i8]
@olang_loc_bea5bf6ffc689610_b71acf810bfa0324 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f3346b4d6d82824c_aeee08707a274ea0 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2ftyped_2eFails(ptr %v0, ptr %a0)
@olang_loc_a2953a30b2f8c4d8_7c37346654e0475c = external constant [0 x i8]
@olang_loc_27c76e49adb539dc_ebba4be7d4da8e48 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eturnExpr(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2ftyped_2eturnPlace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2ftyped_2eEveryTurn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_b972818c6780b098_95e0408c3aef143c = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
