; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:dropWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:LastUses" = type { i64, { i64, ptr }, { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:SiteInfo" = type { i32, %"compiler/source:Span" }
%"compiler/typed:Landings" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:landLoop" = type { i32, i64, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/typed:landState" = type { { i64, ptr }, i1 }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:ViewWalk" = type { ptr, ptr, i64, { ptr, ptr }, { ptr, ptr } }
%"compiler/typed:leaveWalk" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:printer" = type { ptr, %"std/prelude/text:StringBuilder" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
@G_2ecompiler_2ftyped_2eViewBits = constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftyped_2eViewOther = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
@G_2ecompiler_2ftyped_2emathArity = constant <{ [248 x i8] }> <{ [248 x i8] c"\01\00\00\00\00\00\00\00\03\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2ftyped_2emathNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k1, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k2, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k3, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k4, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k5, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k6, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k8, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k9, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k10, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k11, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k12, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k13, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k14, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k15, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k16, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k17, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k18, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k19, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k20, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k21, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k22, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k23, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k24, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k25, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k26, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k27, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k28, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k29, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k30, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ftyped_2emathNames.k31 }>, align 64
@G_2ecompiler_2ftyped_2emathNames.k1 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\73\71\72\74" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k2 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\6D\61" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k3 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\6C\6F\6F\72" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\65\69\6C" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k5 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\74\72\75\6E\63" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k6 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\72\6F\75\6E\64" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k7 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\72\6F\75\6E\64\65\76\65\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\66\61\62\73" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k9 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6F\70\79\73\69\67\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k10 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\62\72\74" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k11 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\65\78\70" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k12 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\78\70\32" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k13 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\65\78\70\6D\31" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k14 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6C\6F\67" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k15 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6C\6F\67\32" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k16 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\31\30" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k17 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6C\6F\67\31\70" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k18 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\70\6F\77" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k19 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\73\69\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k20 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\63\6F\73" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k21 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\74\61\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k22 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\73\69\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k23 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\63\6F\73" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k24 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\61\74\61\6E" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k25 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\61\74\61\6E\32" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k26 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\73\69\6E\68" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k27 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\6F\73\68" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k28 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\61\6E\68" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k29 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\65\72\66" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k30 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\72\66\63" }>, align 8
@G_2ecompiler_2ftyped_2emathNames.k31 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\68\79\70\6F\74" }>, align 8
define dso_local i1 @compiler_2ftyped_2eAlwaysReached(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftyped_2ereached(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp eq i64 %t6, 1
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l85 = alloca { i64, ptr }
  %l92 = alloca i1
  %l96 = alloca i1
  %l104 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l122 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l137 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l154 = alloca i1
  %l164 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l174 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l184 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i1
  %l194 = alloca i1
  %l195 = alloca i1
  %l199 = alloca i1
  %l201 = alloca { i64, ptr }
  %l204 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t7 = load ptr, ptr %l25, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l25, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 7
  store i1 %t13, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l26, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb20
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t16 = load ptr, ptr %l29, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l29, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 5
  store i1 %t22, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l30, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t25 = load ptr, ptr %l33, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l33, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 8
  store i1 %t31, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l34, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb20
bb15:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t34 = load ptr, ptr %l37, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb16, label %bb17
bb16:
  %t37 = load ptr, ptr %l37, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 18}
  %t40 = icmp eq i64 %t38, 16
  store i1 %t40, ptr %l38, !tbaa !21
  br label %bb17
bb17:
  %t41 = load i1, ptr %l38, !tbaa !21
  br i1 %t41, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t44 = load ptr, ptr %l42, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb22, label %bb23
bb22:
  %t47 = load ptr, ptr %l42, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 6
  store i1 %t50, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t51 = load i1, ptr %l43, !tbaa !21
  br i1 %t51, label %bb24, label %bb25
bb24:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l2, !tbaa !23
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l50
  br label %bb27
bb27:
  %t63 = load i1, ptr %l50, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
bb28:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t65 = load ptr, ptr %l51, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb29, label %bb30
bb29:
  %t68 = load ptr, ptr %l51, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 11
  store i1 %t71, ptr %l52, !tbaa !21
  br label %bb30
bb30:
  %t72 = load i1, ptr %l52, !tbaa !21
  br i1 %t72, label %bb31, label %bb32
bb31:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Cond", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t79, ptr %t83)
  store i1 %t86, ptr %l60
  br label %bb34
bb34:
  %t87 = load i1, ptr %l60, !tbaa !21
  br i1 %t87, label %bb35, label %bb36
bb35:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Cond", ptr %t89, i32 0, i32 2
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t96 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t88, ptr %t92)
  store i1 %t96, ptr %l66
  br label %bb37
bb36:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb38
bb37:
  %t97 = load i1, ptr %l66, !tbaa !21
  store i1 %t97, ptr %l61, !tbaa !21
  br label %bb38
bb38:
  %t98 = load i1, ptr %l61, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
bb39:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t100 = load ptr, ptr %l67, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb40, label %bb41
bb40:
  %t103 = load ptr, ptr %l67, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 18}
  %t106 = icmp eq i64 %t104, 13
  store i1 %t106, ptr %l68, !tbaa !21
  br label %bb41
bb41:
  %t107 = load i1, ptr %l68, !tbaa !21
  br i1 %t107, label %bb42, label %bb43
bb42:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l4, !tbaa !29
  br label %bb44
bb43:
  br label %bb74
bb44:
  %t114 = load ptr, ptr %l4, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Match", ptr %t114, i32 0, i32 3
  %t117 = load i1, ptr %t116, !tbaa !21
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb45, label %bb46
bb45:
  store i1 false, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Match", ptr %t122, i32 0, i32 1
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  store i64 %t129, ptr %l7, !tbaa !24
  br label %bb48
bb48:
  %t131 = load i64, ptr %l6, !tbaa !24
  %t132 = load i64, ptr %l7, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb49, label %bb50
bb49:
  br label %bb60
bb50:
  br label %bb51
bb51:
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t139, ptr %l85, !tbaa !27
  %t140 = load i64, ptr %l6, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr ptr, ptr %t143, i64 %t140
  %t145 = load ptr, ptr %t144, !tbaa !39
  store ptr %t145, ptr %l8, !tbaa !29
  %t147 = load ptr, ptr %l8, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Arm", ptr %t147, i32 0, i32 4
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb52, label %bb53
bb52:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l8, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Arm", ptr %t157, i32 0, i32 4
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t163 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t156, ptr %t160)
  store i1 %t163, ptr %l96
  br label %bb54
bb53:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb55
bb54:
  %t164 = load i1, ptr %l96, !tbaa !21
  %t165 = xor i1 %t164, true
  store i1 %t165, ptr %l92, !tbaa !21
  br label %bb55
bb55:
  %t167 = load i1, ptr %l92, !tbaa !21
  br i1 %t167, label %bb56, label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t169 = load i64, ptr %l6, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l6, !tbaa !24
  br label %bb48
bb60:
  %t173 = load ptr, ptr %l4, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Match", ptr %t173, i32 0, i32 2
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t178 = icmp eq ptr %t176, null
  br i1 %t178, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb66
bb62:
  %t180 = load ptr, ptr %l4, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Match", ptr %t180, i32 0, i32 2
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_9640b30413567955_c65a1e6fb20cf981)
  unreachable
bb64:
  br label %bb65
bb65:
  %t187 = load ptr, ptr %l4, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Match", ptr %t187, i32 0, i32 2
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Arm", ptr %t190, i32 0, i32 4
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = icmp eq ptr %t194, null
  store i1 %t196, ptr %l104, !tbaa !21
  br label %bb66
bb66:
  %t198 = load i1, ptr %l104, !tbaa !21
  br i1 %t198, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb73
bb68:
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l114, !tbaa !29
  %t200 = load ptr, ptr %l4, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Match", ptr %t200, i32 0, i32 2
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = icmp eq ptr %t203, null
  br i1 %t205, label %bb69, label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_9640b30413567955_c65a1e6fb20cf981)
  unreachable
bb70:
  br label %bb71
bb71:
  %t207 = load ptr, ptr %l4, !tbaa !29
  %t209 = getelementptr %"compiler/typed:Match", ptr %t207, i32 0, i32 2
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Arm", ptr %t210, i32 0, i32 4
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = load ptr, ptr %l114, !tbaa !29
  %t217 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t215, ptr %t214)
  store i1 %t217, ptr %l122
  br label %bb72
bb72:
  %t218 = load i1, ptr %l122, !tbaa !21
  store i1 %t218, ptr %l113, !tbaa !21
  br label %bb73
bb73:
  %t219 = load i1, ptr %l113, !tbaa !21
  store i1 %t219, ptr %rv
  br label %ret
bb74:
  %t220 = load ptr, ptr %l1, !tbaa !29
  store ptr %t220, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t221 = load ptr, ptr %l123, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb75, label %bb76
bb75:
  %t224 = load ptr, ptr %l123, !tbaa !29
  %t225 = load i64, ptr %t224, !range !{i64 0, i64 18}
  %t227 = icmp eq i64 %t225, 14
  store i1 %t227, ptr %l124, !tbaa !21
  br label %bb76
bb76:
  %t228 = load i1, ptr %l124, !tbaa !21
  br i1 %t228, label %bb77, label %bb78
bb77:
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t231, i32 0, i32 2
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l9, !tbaa !29
  br label %bb79
bb78:
  br label %bb97
bb79:
  %t235 = load ptr, ptr %l9, !tbaa !29
  %t237 = getelementptr %"compiler/typed:Try", ptr %t235, i32 0, i32 1
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  store { i64, ptr } %t238, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t240 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t240, 0
  store i64 %t242, ptr %l12, !tbaa !24
  br label %bb80
bb80:
  %t244 = load i64, ptr %l11, !tbaa !24
  %t245 = load i64, ptr %l12, !tbaa !24
  %t248 = icmp slt i64 %t244, %t245
  %t250 = xor i1 %t248, true
  br i1 %t250, label %bb81, label %bb82
bb81:
  br label %bb95
bb82:
  br label %bb83
bb83:
  %t252 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t252, ptr %l137, !tbaa !27
  %t253 = load i64, ptr %l11, !tbaa !24
  %t255 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr ptr, ptr %t256, i64 %t253
  %t258 = load ptr, ptr %t257, !tbaa !39
  %t262 = getelementptr %"compiler/typed:Clause", ptr %t258, i32 0, i32 4
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t265 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  store i64 %t267, ptr %l16, !tbaa !24
  br label %bb84
bb84:
  %t269 = load i64, ptr %l15, !tbaa !24
  %t270 = load i64, ptr %l16, !tbaa !24
  %t273 = icmp slt i64 %t269, %t270
  %t275 = xor i1 %t273, true
  br i1 %t275, label %bb85, label %bb86
bb85:
  br label %bb93
bb86:
  br label %bb87
bb87:
  %t277 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t277, ptr %l148, !tbaa !27
  %t278 = load i64, ptr %l15, !tbaa !24
  %t280 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr ptr, ptr %t281, i64 %t278
  %t283 = load ptr, ptr %t282, !tbaa !39
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t290 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t285, ptr %t283)
  store i1 %t290, ptr %l154
  br label %bb88
bb88:
  %t291 = load i1, ptr %l154, !tbaa !21
  %t292 = xor i1 %t291, true
  br i1 %t292, label %bb89, label %bb90
bb89:
  store i1 false, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t295 = load i64, ptr %l15, !tbaa !24
  %t297 = add i64 %t295, 1
  store i64 %t297, ptr %l15, !tbaa !24
  br label %bb84
bb93:
  br label %bb94
bb94:
  %t299 = load i64, ptr %l11, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l11, !tbaa !24
  br label %bb80
bb95:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load ptr, ptr %l9, !tbaa !29
  %t306 = getelementptr %"compiler/typed:Try", ptr %t304, i32 0, i32 0
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t310 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t303, ptr %t307)
  store i1 %t310, ptr %l164
  br label %bb96
bb96:
  %t311 = load i1, ptr %l164, !tbaa !21
  store i1 %t311, ptr %rv
  br label %ret
bb97:
  %t312 = load ptr, ptr %l1, !tbaa !29
  store ptr %t312, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t313 = load ptr, ptr %l165, !tbaa !29
  %t314 = icmp ne ptr %t313, null
  br i1 %t314, label %bb98, label %bb99
bb98:
  %t316 = load ptr, ptr %l165, !tbaa !29
  %t317 = load i64, ptr %t316, !range !{i64 0, i64 18}
  %t319 = icmp eq i64 %t317, 12
  store i1 %t319, ptr %l166, !tbaa !21
  br label %bb99
bb99:
  %t320 = load i1, ptr %l166, !tbaa !21
  br i1 %t320, label %bb100, label %bb101
bb100:
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr { i64, [5 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t323, i32 0, i32 2
  %t325 = load ptr, ptr %t324
  store ptr %t325, ptr %l18, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l18, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Seq", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t334 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t327, ptr %t331)
  store i1 %t334, ptr %l174
  br label %bb103
bb103:
  %t335 = load i1, ptr %l174, !tbaa !21
  store i1 %t335, ptr %rv
  br label %ret
bb104:
  %t336 = load ptr, ptr %l1, !tbaa !29
  store ptr %t336, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t337 = load ptr, ptr %l175, !tbaa !29
  %t338 = icmp ne ptr %t337, null
  br i1 %t338, label %bb105, label %bb106
bb105:
  %t340 = load ptr, ptr %l175, !tbaa !29
  %t341 = load i64, ptr %t340, !range !{i64 0, i64 18}
  %t343 = icmp eq i64 %t341, 17
  store i1 %t343, ptr %l176, !tbaa !21
  br label %bb106
bb106:
  %t344 = load i1, ptr %l176, !tbaa !21
  br i1 %t344, label %bb107, label %bb108
bb107:
  %t345 = load ptr, ptr %l1, !tbaa !29
  %t347 = getelementptr { i64, [5 x i64] }, ptr %t345, i32 0, i32 1
  %t348 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t347, i32 0, i32 2
  %t349 = load ptr, ptr %t348
  store ptr %t349, ptr %l19, !tbaa !29
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load ptr, ptr %l19, !tbaa !29
  %t356 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t351, ptr %t352)
  store i1 %t356, ptr %l184
  br label %bb110
bb110:
  %t357 = load i1, ptr %l184, !tbaa !21
  store i1 %t357, ptr %rv
  br label %ret
bb111:
  %t358 = load ptr, ptr %l1, !tbaa !29
  store ptr %t358, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t359 = load ptr, ptr %l185, !tbaa !29
  %t360 = icmp ne ptr %t359, null
  br i1 %t360, label %bb112, label %bb113
bb112:
  %t362 = load ptr, ptr %l185, !tbaa !29
  %t363 = load i64, ptr %t362, !range !{i64 0, i64 18}
  %t365 = icmp eq i64 %t363, 9
  store i1 %t365, ptr %l186, !tbaa !21
  br label %bb113
bb113:
  %t366 = load i1, ptr %l186, !tbaa !21
  br i1 %t366, label %bb114, label %bb115
bb114:
  %t367 = load ptr, ptr %l1, !tbaa !29
  %t369 = getelementptr { i64, [5 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t369, i32 0, i32 2
  %t371 = load i32, ptr %t370, !range !{i32 0, i32 44}
  store i32 %t371, ptr %l20
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [5 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t375, i32 0, i32 4
  %t377 = load { i64, ptr }, ptr %t376
  store { i64, ptr } %t377, ptr %l21, !tbaa !27
  br label %bb116
bb115:
  br label %bb125
bb116:
  %t379 = load i32, ptr %l20, !range !{i32 0, i32 44}
  %t381 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t379)
  store i1 %t381, ptr %l194
  br label %bb117
bb117:
  %t382 = load i1, ptr %l194, !tbaa !21
  br i1 %t382, label %bb118, label %bb119
bb118:
  %t383 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t387 = icmp sgt i64 %t385, 0
  store i1 %t387, ptr %l195, !tbaa !21
  br label %bb120
bb119:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb120
bb120:
  %t389 = load i1, ptr %l195, !tbaa !21
  br i1 %t389, label %bb121, label %bb122
bb121:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t391, ptr %l201, !tbaa !27
  %t392 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr ptr, ptr %t393, i64 0
  %t395 = load ptr, ptr %t394, !tbaa !39
  %t399 = call i1 @compiler_2ftyped_2eAnyItemNew(ptr %v0, ptr %v1, ptr %t390, ptr %t395)
  store i1 %t399, ptr %l204
  br label %bb123
bb122:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb124
bb123:
  %t400 = load i1, ptr %l204, !tbaa !21
  store i1 %t400, ptr %l199, !tbaa !21
  br label %bb124
bb124:
  %t401 = load i1, ptr %l199, !tbaa !21
  store i1 %t401, ptr %rv
  br label %ret
bb125:
  br i1 true, label %bb126, label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  store i1 false, ptr %rv
  br label %ret
bb129:
  call void @__olang_check_failed(ptr @olang_loc_c8cee6ec101913bd_743c2b1d0ab2dad9)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ftyped_2eCallOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 6
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l1, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l7, !tbaa !29
  br label %bb28
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t25 = load ptr, ptr %l16, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 14
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l17, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l2, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Try", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = call ptr @compiler_2ftyped_2eCallOf(ptr %v0, ptr %v1, ptr %t42)
  store ptr %t44, ptr %l24
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l24, !tbaa !29
  store ptr %t45, ptr %l7, !tbaa !29
  br label %bb28
bb16:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 17
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb18
bb18:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb19, label %bb20
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t64 = call ptr @compiler_2ftyped_2eCallOf(ptr %v0, ptr %v1, ptr %t61)
  store ptr %t64, ptr %l33
  br label %bb22
bb22:
  %t65 = load ptr, ptr %l33, !tbaa !29
  store ptr %t65, ptr %l7, !tbaa !29
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store ptr null, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_d77318aa483254f8_85fb99de392fdbc)
  unreachable
bb28:
  %t66 = load ptr, ptr %l7, !tbaa !29
  store ptr %t66, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ftyped_2eCalledBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l12, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { i32 }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t36 = load i32, ptr %l3, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_831440fdfc819328_dabfa81c01cf773c)
  unreachable
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 -1, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_7bdf3cb2fb8351f9_389183759a182ed)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2ftyped_2eCopiedOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l4 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call ptr @compiler_2ftyped_2ecopied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
  store ptr %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ftyped_2eDropFlag(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i1
  %l32 = alloca %"compiler/typed:BlockInfo"
  %l43 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Block", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t8 = icmp slt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb2:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Block", ptr %t10, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l21, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 8
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l24
  br label %bb3
bb3:
  %t21 = load i64, ptr %l21, !tbaa !24
  %t22 = load i64, ptr %l24, !tbaa !24
  %t23 = icmp sge i64 %t21, %t22
  store i1 %t23, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t25 = load i1, ptr %l18, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb8
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t26, i32 0, i32 8
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Block", ptr %t29, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = sext i32 %t32 to i64
  %t37 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t28, i64 %t34)
  store %"compiler/typed:BlockInfo" %t37, ptr %l32
  br label %bb7
bb7:
  %t38 = getelementptr %"compiler/typed:BlockInfo", ptr %l32, i32 0, i32 1
  %t39 = load i32, ptr %t38, !range !{i32 0, i32 10}
  %t41 = trunc i64 8 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  store i1 %t44, ptr %l26, !tbaa !21
  br label %bb8
bb8:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Block", ptr %t48, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t55 = icmp ne i64 %t53, 1
  br i1 %t55, label %bb12, label %bb13
bb12:
  store i64 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Block", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l43, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 0
  %t65 = load ptr, ptr %t64, !tbaa !39
  store ptr %t65, ptr %l2, !tbaa !29
  %t67 = load ptr, ptr %l2, !tbaa !29
  store ptr %t67, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t68 = load ptr, ptr %l45, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load ptr, ptr %l45, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 17}
  %t74 = icmp eq i64 %t72, 3
  store i1 %t74, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t75 = load i1, ptr %l46, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb17, label %bb18
bb17:
  store i64 -1, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr }, ptr %t81, i32 0, i32 0
  %t83 = load %"compiler/source:Span", ptr %t82
  store %"compiler/source:Span" %t83, ptr %l3
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", ptr }, ptr %t87, i32 0, i32 1
  %t89 = load ptr, ptr %t88
  %t94 = getelementptr %"compiler/typed:If", ptr %t89, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l5, !tbaa !29
  %t97 = load ptr, ptr %l5, !tbaa !29
  store ptr %t97, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t98 = load ptr, ptr %l58, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb20, label %bb21
bb20:
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 18}
  %t104 = icmp eq i64 %t102, 2
  store i1 %t104, ptr %l59, !tbaa !21
  br label %bb21
bb21:
  %t105 = load i1, ptr %l59, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb22, label %bb23
bb22:
  store i64 -1, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t109 = load ptr, ptr %l5, !tbaa !29
  %t111 = getelementptr { i64, [5 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t111, i32 0, i32 0
  %t113 = load %"compiler/source:Span", ptr %t112
  store %"compiler/source:Span" %t113, ptr %l6
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t117, i32 0, i32 1
  %t119 = load i32, ptr %t118
  store i32 %t119, ptr %l7, !tbaa !23
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t123, i32 0, i32 2
  %t125 = load ptr, ptr %t124
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t129, i32 0, i32 3
  %t131 = load i32, ptr %t130
  store i32 %t131, ptr %l9, !tbaa !23
  store ptr %t125, ptr %l10, !tbaa !29
  %t135 = load ptr, ptr %l10, !tbaa !29
  store ptr %t135, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t136 = load ptr, ptr %l73, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb25, label %bb26
bb25:
  %t139 = load ptr, ptr %l73, !tbaa !29
  %t140 = load i64, ptr %t139, !range !{i64 0, i64 8}
  %t142 = icmp eq i64 %t140, 0
  store i1 %t142, ptr %l74, !tbaa !21
  br label %bb26
bb26:
  %t143 = load i1, ptr %l74, !tbaa !21
  %t144 = xor i1 %t143, true
  br i1 %t144, label %bb27, label %bb28
bb27:
  store i64 -1, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t147 = load ptr, ptr %l10, !tbaa !29
  %t149 = getelementptr { i64, [4 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  store %"compiler/source:Span" %t151, ptr %l11
  %t153 = load ptr, ptr %l10, !tbaa !29
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t155, i32 0, i32 1
  %t157 = load i32, ptr %t156
  store i32 %t157, ptr %l12, !tbaa !23
  %t159 = load ptr, ptr %l10, !tbaa !29
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t161, i32 0, i32 2
  %t163 = load i32, ptr %t162
  %t167 = sext i32 %t163 to i64
  store i64 %t167, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2ftyped_2eDropsRun(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l3 = alloca %"compiler/typed:dropWalk"
  %l8 = alloca i64
  %l10 = alloca i1
  %l15 = alloca ptr
  %l22 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l24 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %t2 = alloca %"compiler/typed:dropWalk", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_3adropWalk_2ector(ptr %t2, ptr %v0, ptr %v1, ptr %t1)
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %t2, i64 488, i1 false)
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 488, i64 8)
  store ptr %t4, ptr %lp1
  %t5 = load ptr, ptr %lp1
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l3, i64 488, i1 false)
  %t6 = load ptr, ptr %lp1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Body", ptr %t7, i32 0, i32 11
  %t10 = load ptr, ptr %t9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v1, ptr %v0, ptr %t6, ptr %t10)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %lp1
  %t14 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 1
  %t16 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v1, ptr %t14)
  store i64 %t16, ptr %l8
  br label %bb3
bb3:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = icmp sgt i64 %t17, 0
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 11
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l10, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %lp1
  store ptr %t30, ptr %l15, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Body", ptr %t31, i32 0, i32 11
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  call void @__olang_check_failed(ptr @olang_loc_bcb9fe3b91f750d3_ca64047ead3323e7)
  unreachable
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 11
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v1, ptr %v0, ptr %t43, ptr %t41)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t45 = load ptr, ptr %lp1
  %t46 = getelementptr %"compiler/typed:dropWalk", ptr %t45, i32 0, i32 14
  %t47 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t46
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t47, ptr %l22
  %t49 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1, ptr %l22)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t49, ptr %l24
  br label %bb14
bb14:
  %t50 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t50, ptr %l22
  %t51 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l22
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t51, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2ftyped_2eholdsOwned(ptr %v0, ptr %a0, i32 %a1, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2ftyped_2eLastCopies(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca %"compiler/typed:LastUses"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca i1
  %l20 = alloca i64
  %l21 = alloca %"compiler/typed:LastUses"
  %l22 = alloca ptr
  %l30 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %l68 = alloca i64
  %l70 = alloca ptr
  %l73 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %t26 = alloca %"compiler/typed:LastUses", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Body", ptr %t5, i32 0, i32 11
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 14
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %lp1
  %t19 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t18
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t19, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 7
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l20
  br label %bb8
bb8:
  %t27 = load i64, ptr %l20, !tbaa !24
  call void @compiler_2ftyped_3aLastUses_2ector(ptr %t26, ptr %s0, i64 %t27)
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %t26, i64 192, i1 false)
  br label %bb9
bb9:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l21, i64 192, i1 false)
  store ptr %l2, ptr %l22, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 11
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_160fc62cca54a9e9_1017e7cee7f3c75d)
  unreachable
bb11:
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 11
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %s0, ptr %v0, ptr %t40, ptr %t38)
  br label %bb13
bb13:
  store i64 0, ptr %l3, !tbaa !24
  %t42 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 6
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t42)
  store i64 %t44, ptr %l30
  br label %bb14
bb14:
  %t45 = load i64, ptr %l30, !tbaa !24
  store i64 %t45, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb20
bb17:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l3, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l37, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb19
bb19:
  %t72 = load i64, ptr %l37, !tbaa !24
  store i64 %t72, ptr %l34, !tbaa !24
  br label %bb20
bb20:
  %t73 = load i64, ptr %l34, !tbaa !24
  store i64 %t73, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb21
bb21:
  %t74 = load i64, ptr %l7, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb22, label %bb23
bb22:
  br label %bb37
bb23:
  br label %bb24
bb24:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  store i64 %t90, ptr %l8, !tbaa !24
  %t92 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 7
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t92, i64 %t93)
  store i64 %t96, ptr %l57
  br label %bb25
bb25:
  %t97 = load i64, ptr %l57, !tbaa !24
  store i64 %t97, ptr %l9, !tbaa !24
  %t98 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 8
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t98, i64 %t99)
  store i64 %t102, ptr %l60
  br label %bb26
bb26:
  %t103 = load i64, ptr %l60, !tbaa !24
  %t104 = icmp sge i64 %t103, 0
  br i1 %t104, label %bb27, label %bb28
bb27:
  %t106 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 1
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %l63, !tbaa !27
  %t108 = load i64, ptr %l9, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i64, ptr %t111, i64 %t108
  %t113 = load i64, ptr %t112, !tbaa !34
  store i64 %t113, ptr %l65, !tbaa !24
  %t114 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 8
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t114, i64 %t115)
  store i64 %t118, ptr %l68
  br label %bb29
bb28:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb30
bb29:
  %t119 = load i64, ptr %l65, !tbaa !24
  %t120 = load i64, ptr %l68, !tbaa !24
  %t121 = icmp eq i64 %t119, %t120
  store i1 %t121, ptr %l62, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l62, !tbaa !21
  br i1 %t123, label %bb31, label %bb32
bb31:
  %t124 = load ptr, ptr %lp1
  store ptr %t124, ptr %l70, !tbaa !29
  %t125 = getelementptr %"compiler/typed:LastUses", ptr %l2, i32 0, i32 6
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t125, i64 %t126)
  store i64 %t129, ptr %l73
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t130 = load i64, ptr %l9, !tbaa !24
  %t131 = load ptr, ptr %l70, !tbaa !29
  %t132 = load i64, ptr %l73, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v1, ptr %t131, i64 %t132, i64 %t130)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t134 = load i64, ptr %l7, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l7, !tbaa !24
  br label %bb21
bb37:
  %t138 = load ptr, ptr %lp1
  %t139 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t138
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t139, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define dso_local void @compiler_2ftyped_2eNewPlan(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/typed:Plan"
  %t16 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Body", ptr %t6, i32 0, i32 7
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l6
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 6
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l9
  br label %bb3
bb3:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2ftyped_3aPlan_2ector(ptr %t16, ptr %v1, i64 %t17, i64 %t18, i64 %t19)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t16, i64 176, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l10, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ePassesRefs(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 44}
  %t3 = trunc i64 20 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 44}
  %t8 = trunc i64 41 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 44}
  %t14 = trunc i64 42 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eclausesBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t30, i32 0, i32 3
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb12
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Clause", ptr %t39, i32 0, i32 4
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i1 @compiler_2ftyped_2eexprsBreak(ptr %v0, { i64, ptr } %t42, i32 %t43)
  store i1 %t46, ptr %l28
  br label %bb11
bb11:
  %t47 = load i1, ptr %l28, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca %"compiler/typed:BlockInfo"
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l5, !tbaa !29
  %t10 = call %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %s0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
  store %"compiler/typed:BlockInfo" %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load %"compiler/typed:BlockInfo", ptr %l9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ePush_H85e1838377aa8e6b322d82e3edbac596(ptr %v0, ptr %t11, %"compiler/typed:BlockInfo" %t12)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 8
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = sub i64 %t18, 1
  %t21 = trunc i64 %t19 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2ePush_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t3, %"compiler/typed:Local" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Body", ptr %t7, i32 0, i32 7
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca %"compiler/typed:SiteInfo"
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l4, !tbaa !29
  %t8 = call %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %s0, i32 %a1, %"compiler/source:Span" %a2)
  store %"compiler/typed:SiteInfo" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"compiler/typed:SiteInfo", ptr %l7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ePush_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %t9, %"compiler/typed:SiteInfo" %t10)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 9
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = sub i64 %t16, 1
  %t19 = trunc i64 %t17 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca i32
  %l16 = alloca %"compiler/typed:BlockInfo"
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a2, ptr %l3, !tbaa !23
  br label %bb1
bb1:
  %t3 = load i32, ptr %l3, !tbaa !23
  %t5 = icmp sge i32 %t3, 0
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t13 = icmp eq i32 %t9, %a1
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 8
  %t19 = load i32, ptr %l3, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t18, i64 %t21)
  store %"compiler/typed:BlockInfo" %t24, ptr %l16
  br label %bb8
bb8:
  %t25 = getelementptr %"compiler/typed:BlockInfo", ptr %l16, i32 0, i32 0
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb9
bb9:
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eInst(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l5 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 1
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l1
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i64, ptr %l2, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3a838910fbaaf0b4_28daeb84482f7128)
  unreachable
bb9:
  %t17 = load i64, ptr %l5, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, [1 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [1 x i64] }
  %t23 = alloca { i64, [1 x i64] }, align 8
  %t54 = alloca { i64, [1 x i64] }, align 8
  %t58 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %t4, !tbaa !23
  %t6 = load i64, ptr %l2, !tbaa !24
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v1, ptr %t1, i32 %t5, i64 %t6)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 5
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t18, i64 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [1 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [1 x i64] }, ptr %t23, i32 0, i32 0
  store i64 2, ptr %t24
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = insertvalue { i32 } undef, i32 %t25, 0
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t23, i32 0, i32 1
  store { i32 } %t26, ptr %t27
  %t28 = load { i64, [1 x i64] }, ptr %t23
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t28, ptr %rv
  br label %ret
bb5:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %t35, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t32, i32 %t36)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %s0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i32, ptr %t47, i64 %t44
  %t49 = load i32, ptr %t48, !tbaa !33
  %t50 = load ptr, ptr %l16, !tbaa !29
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v1, ptr %t50, i32 %t49)
  store i1 %t52, ptr %l26
  br label %bb8
bb8:
  %t53 = load i1, ptr %l26, !tbaa !21
  br i1 %t53, label %bb9, label %bb10
bb9:
  store { i64, [1 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [1 x i64] }, ptr %t54, i32 0, i32 0
  store i64 1, ptr %t55
  %t56 = load { i64, [1 x i64] }, ptr %t54
  store { i64, [1 x i64] } %t56, ptr %l27
  br label %bb11
bb10:
  store { i64, [1 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [1 x i64] }, ptr %t58, i32 0, i32 0
  store i64 0, ptr %t59
  %t60 = load { i64, [1 x i64] }, ptr %t58
  store { i64, [1 x i64] } %t60, ptr %l27
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, [1 x i64] }, ptr %l27
  store { i64, [1 x i64] } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eResultMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i32
  %rv = alloca { i64, [1 x i64] }
  %t18 = alloca { i64, [1 x i64] }, align 8
  %t33 = alloca { i64, [1 x i64] }, align 8
  %t40 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %t4, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v1, ptr %a1, i32 %t5, i64 %a2)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t16 = icmp eq i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store { i64, [1 x i64] } zeroinitializer, ptr %t18
  %t19 = getelementptr { i64, [1 x i64] }, ptr %t18, i32 0, i32 0
  store i64 5, ptr %t19
  %t20 = load { i64, [1 x i64] }, ptr %t18
  store { i64, [1 x i64] } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l18
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [1 x i64] }, ptr %t33, i32 0, i32 0
  store i64 2, ptr %t34
  %t35 = load i32, ptr %l18, !tbaa !23
  %t36 = insertvalue { i32 } undef, i32 %t35, 0
  %t37 = getelementptr { i64, [1 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [1 x i64] }, ptr %t33
  store { i64, [1 x i64] } %t38, ptr %rv
  br label %ret
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [1 x i64] }, ptr %t40, i32 0, i32 0
  store i64 1, ptr %t41
  %t42 = load { i64, [1 x i64] }, ptr %t40
  store { i64, [1 x i64] } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l15 = alloca { i64, ptr }
  %l29 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca { i64, [1 x i64] }
  %l41 = alloca ptr
  %l45 = alloca i32
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t74 = alloca { i64, [1 x i64] }, align 8
  %t78 = alloca { i64, [1 x i64] }, align 8
  %t84 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb30
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  %t27 = icmp eq i64 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 6
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 3, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t31, { i64, [1 x i64] } %t34)
  br label %bb7
bb6:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t38 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t41 = icmp eq i64 %t37, %t38
  br i1 %t41, label %bb8, label %bb9
bb7:
  br label %bb28
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 1
  %t46 = load { i64, [2 x i64] }, ptr %t45
  store { i64, [2 x i64] } %t46, ptr %l6
  %t48 = load { i64, [2 x i64] }, ptr %l6
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb10, label %bb11
bb9:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t53, i32 0, i32 6
  store ptr %t55, ptr %l41, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 5
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t58, i64 %t59)
  store i32 %t62, ptr %l45
  br label %bb25
bb10:
  br label %bb14
bb11:
  %t63 = load { i64, [2 x i64] }, ptr %l6
  %t65 = extractvalue { i64, [2 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 2
  br i1 %t66, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_49a7b0a2550beed6_c54fa6caa81e807a)
  unreachable
bb20:
  %t68 = load i1, ptr %l29, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 6
  store ptr %t71, ptr %l35, !tbaa !29
  br i1 %t68, label %bb21, label %bb22
bb21:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 2, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  store { i64, [1 x i64] } %t76, ptr %l37
  br label %bb23
bb22:
  store { i64, [1 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [1 x i64] }, ptr %t78, i32 0, i32 0
  store i64 1, ptr %t79
  %t80 = load { i64, [1 x i64] }, ptr %t78
  store { i64, [1 x i64] } %t80, ptr %l37
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load { i64, [1 x i64] }, ptr %l37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t82, { i64, [1 x i64] } %t83)
  br label %bb24
bb24:
  br label %bb27
bb25:
  store { i64, [1 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [1 x i64] }, ptr %t84, i32 0, i32 0
  store i64 0, ptr %t85
  %t86 = load i32, ptr %l45, !tbaa !23
  %t87 = insertvalue { i32 } undef, i32 %t86, 0
  %t88 = getelementptr { i64, [1 x i64] }, ptr %t84, i32 0, i32 1
  store { i32 } %t87, ptr %t88
  %t89 = load { i64, [1 x i64] }, ptr %t84
  %t90 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t90, { i64, [1 x i64] } %t89)
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l3, !tbaa !24
  br label %bb1
bb30:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l56 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  br label %bb1
bb1:
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Landings", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l20, !tbaa !24
  store i64 %t39, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l17, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb9, label %bb10
bb9:
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Landings", ptr %t59, i32 0, i32 11
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Landings", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l41, !tbaa !27
  %t66 = load i64, ptr %l7, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i64, ptr %t69, i64 %t66
  %t71 = load i64, ptr %t70, !tbaa !34
  %t74 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t61, i64 %t71)
  store i1 %t74, ptr %l44
  br label %bb12
bb12:
  %t75 = load i1, ptr %l44, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb13, label %bb14
bb13:
  br label %bb20
bb14:
  br label %bb15
bb15:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Landings", ptr %t78, i32 0, i32 4
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l47, !tbaa !27
  %t82 = load i64, ptr %l7, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i1, ptr %t85, i64 %t82
  store i1 true, ptr %t86, !tbaa !31
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Landings", ptr %t87, i32 0, i32 5
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  store { i64, ptr } %t90, ptr %l50, !tbaa !27
  %t91 = load i64, ptr %l7, !tbaa !24
  store i64 %t91, ptr %l51, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Landings", ptr %t92, i32 0, i32 12
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Landings", ptr %t95, i32 0, i32 0
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l56, !tbaa !27
  %t99 = load i64, ptr %l7, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i64, ptr %t102, i64 %t99
  %t104 = load i64, ptr %t103, !tbaa !34
  %t107 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t94, i64 %t104)
  %t108 = extractvalue { i32, i64 } %t107, 1
  %t109 = extractvalue { i32, i64 } %t107, 0
  store i32 %t109, ptr %l60
  %t110 = icmp ne i32 %t109, 0
  br i1 %t110, label %bb17, label %ok.111, !prof !99
ok.111:
  store i64 %t108, ptr %l59
  br label %bb16
bb16:
  %t112 = load i64, ptr %l59, !tbaa !24
  store i64 %t112, ptr %l52, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l52, !tbaa !24
  br label %bb19
bb19:
  %t113 = load i64, ptr %l52, !tbaa !24
  %t114 = load i64, ptr %l51, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i64, ptr %t116, i64 %t114
  store i64 %t113, ptr %t117, !tbaa !34
  br label %bb20
bb20:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l6, !tbaa !24
  br label %bb8
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eapart(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l48 = alloca i1
  %l53 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l81 = alloca i64
  %l83 = alloca { i64, ptr }
  %l87 = alloca i1
  %l91 = alloca i1
  %l93 = alloca i1
  %l97 = alloca i1
  %l98 = alloca i1
  %l102 = alloca i64
  %l104 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l23, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb48
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Landings", ptr %t54, i32 0, i32 4
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l42, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i1, ptr %t61, i64 %t58
  %t63 = load i1, ptr %t62, !tbaa !31
  br i1 %t63, label %bb11, label %bb12
bb11:
  br label %bb47
bb12:
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l1, !tbaa !24
  %t71 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ereadIn(ptr %v0, ptr %t65, i64 %t66, i64 %t67)
  store i1 %t71, ptr %l48
  br label %bb14
bb14:
  %t72 = load i1, ptr %l48, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb15, label %bb16
bb15:
  br label %bb47
bb16:
  br label %bb17
bb17:
  %t75 = load i64, ptr %l1, !tbaa !24
  store i64 %t75, ptr %l8, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Landings", ptr %t77, i32 0, i32 13
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t79)
  store i64 %t81, ptr %l53
  br label %bb18
bb18:
  %t82 = load i64, ptr %l53, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb24
bb21:
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = sub i64 %t93, %t94
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t103 = sub i64 %t101, 1
  %t104 = load i64, ptr %l10, !tbaa !24
  %t107 = sdiv i64 %t103, %t104
  store i64 %t107, ptr %l60, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb23
bb23:
  %t109 = load i64, ptr %l60, !tbaa !24
  store i64 %t109, ptr %l57, !tbaa !24
  br label %bb24
bb24:
  %t110 = load i64, ptr %l57, !tbaa !24
  store i64 %t110, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb25
bb25:
  %t111 = load i64, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb26, label %bb27
bb26:
  br label %bb46
bb27:
  br label %bb28
bb28:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l12, !tbaa !24
  %t121 = load i64, ptr %l10, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  store i64 %t127, ptr %l13, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Landings", ptr %t129, i32 0, i32 13
  %t132 = load i64, ptr %l13, !tbaa !24
  %t135 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t135, ptr %l81
  br label %bb29
bb29:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Landings", ptr %t136, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l83, !tbaa !27
  %t140 = load i64, ptr %l7, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i64, ptr %t143, i64 %t140
  %t145 = load i64, ptr %t144, !tbaa !34
  %t146 = load i64, ptr %l81, !tbaa !24
  %t148 = icmp ne i64 %t146, %t145
  br i1 %t148, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb33
bb31:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Landings", ptr %t150, i32 0, i32 16
  %t153 = load i64, ptr %l13, !tbaa !24
  %t156 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t152, i64 %t153)
  store i1 %t156, ptr %l91
  br label %bb32
bb32:
  %t157 = load i1, ptr %l91, !tbaa !21
  %t158 = xor i1 %t157, true
  store i1 %t158, ptr %l87, !tbaa !21
  br label %bb33
bb33:
  %t160 = load i1, ptr %l87, !tbaa !21
  br i1 %t160, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb41
bb35:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Landings", ptr %t161, i32 0, i32 15
  %t164 = load i64, ptr %l13, !tbaa !24
  %t167 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t163, i64 %t164)
  store i1 %t167, ptr %l97
  br label %bb36
bb36:
  %t168 = load i1, ptr %l97, !tbaa !21
  br i1 %t168, label %bb37, label %bb38
bb37:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Landings", ptr %t169, i32 0, i32 14
  %t172 = load i64, ptr %l13, !tbaa !24
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172)
  store i64 %t175, ptr %l102
  br label %bb39
bb38:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb40
bb39:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Landings", ptr %t176, i32 0, i32 1
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  store { i64, ptr } %t179, ptr %l104, !tbaa !27
  %t180 = load i64, ptr %l7, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i64, ptr %t183, i64 %t180
  %t185 = load i64, ptr %t184, !tbaa !34
  %t186 = load i64, ptr %l102, !tbaa !24
  %t188 = icmp eq i64 %t186, %t185
  store i1 %t188, ptr %l98, !tbaa !21
  br label %bb40
bb40:
  %t190 = load i1, ptr %l98, !tbaa !21
  store i1 %t190, ptr %l93, !tbaa !21
  br label %bb41
bb41:
  %t191 = load i1, ptr %l93, !tbaa !21
  br i1 %t191, label %bb42, label %bb43
bb42:
  br label %bb45
bb43:
  br label %bb44
bb44:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/typed:Landings", ptr %t192, i32 0, i32 4
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l109, !tbaa !27
  %t196 = load i64, ptr %l7, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr i1, ptr %t199, i64 %t196
  store i1 true, ptr %t200, !tbaa !31
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Landings", ptr %t201, i32 0, i32 6
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l112, !tbaa !27
  %t205 = load i64, ptr %l7, !tbaa !24
  %t207 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr i1, ptr %t208, i64 %t205
  store i1 true, ptr %t209, !tbaa !31
  br label %bb45
bb45:
  %t210 = load i64, ptr %l12, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l12, !tbaa !24
  br label %bb25
bb46:
  br label %bb47
bb47:
  %t214 = load i64, ptr %l6, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l6, !tbaa !24
  br label %bb7
bb48:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l19 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l39 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Alt", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb7, label %bb8
bb7:
  br label %bb14
bb8:
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t51, ptr %l34, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  store ptr %t57, ptr %l9, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Landings", ptr %t59, i32 0, i32 13
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l39
  br label %bb10
bb10:
  %t64 = load i64, ptr %l39, !tbaa !24
  store i64 %t64, ptr %l10, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l9, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Bind", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t65, ptr %t69)
  br label %bb11
bb11:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l9, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Bind", ptr %t74, i32 0, i32 0
  %t77 = load i32, ptr %t76, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t80 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eholds(ptr %v0, ptr %t73, i64 %t79, i64 %t80)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t84 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l7, !tbaa !24
  br label %bb6
bb14:
  br label %bb15
bb15:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Arm", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %t95, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t92, ptr %t96)
  br label %bb17
bb17:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Arm", ptr %t100, i32 0, i32 3
  %t103 = load ptr, ptr %t102, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  br label %bb18
bb18:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Arm", ptr %t107, i32 0, i32 4
  %t110 = load ptr, ptr %t109, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t106, ptr %t110)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb8
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Clause", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Clause", ptr %t31, i32 0, i32 4
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %t30, { i64, ptr } %t34)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb1
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eholds(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l55 = alloca i64
  %l59 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l68 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Landings", ptr %t6, i32 0, i32 2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp sge i64 %t5, %t11
  store i1 %t14, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l12, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Landings", ptr %t17, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l20, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i1, ptr %t24, i64 %t21
  %t26 = load i1, ptr %t25, !tbaa !31
  %t28 = xor i1 %t26, true
  store i1 %t28, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  store i64 %a2, ptr %l3, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Landings", ptr %t33, i32 0, i32 13
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l27
  br label %bb10
bb10:
  %t38 = load i64, ptr %l27, !tbaa !24
  store i64 %t38, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb16
bb13:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l34, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb15
bb15:
  %t65 = load i64, ptr %l34, !tbaa !24
  store i64 %t65, ptr %l31, !tbaa !24
  br label %bb16
bb16:
  %t66 = load i64, ptr %l31, !tbaa !24
  store i64 %t66, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb18, label %bb19
bb18:
  br label %bb36
bb19:
  br label %bb20
bb20:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l5, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l8, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Landings", ptr %t85, i32 0, i32 13
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l55
  br label %bb21
bb21:
  %t92 = load i64, ptr %l55, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l1, !tbaa !24
  %t97 = icmp eq i64 %t93, %t94
  br i1 %t97, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb25
bb23:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Landings", ptr %t99, i32 0, i32 17
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t101, i64 %t102)
  store i1 %t105, ptr %l63
  br label %bb24
bb24:
  %t106 = load i1, ptr %l63, !tbaa !21
  %t107 = xor i1 %t106, true
  store i1 %t107, ptr %l59, !tbaa !21
  br label %bb25
bb25:
  %t109 = load i1, ptr %l59, !tbaa !21
  br i1 %t109, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb29
bb27:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ewatched(ptr %v0, ptr %t110, i64 %t111)
  store i1 %t114, ptr %l68
  br label %bb28
bb28:
  %t115 = load i1, ptr %l68, !tbaa !21
  %t116 = xor i1 %t115, true
  store i1 %t116, ptr %l65, !tbaa !21
  br label %bb29
bb29:
  %t118 = load i1, ptr %l65, !tbaa !21
  br i1 %t118, label %bb30, label %bb31
bb30:
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Landings", ptr %t119, i32 0, i32 19
  %t122 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  br label %bb33
bb33:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Landings", ptr %t125, i32 0, i32 20
  %t128 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t127, i64 %t128)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l7, !tbaa !24
  br label %bb17
bb36:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/typed:landLoop"
  %l9 = alloca i64
  %l17 = alloca %"compiler/typed:landLoop"
  %l24 = alloca %"compiler/typed:landLoop"
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Landings", ptr %t6, i32 0, i32 9
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eLen_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l9
  br label %bb4
bb4:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = sub i64 %t11, 1
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Landings", ptr %t20, i32 0, i32 9
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call %"compiler/typed:landLoop" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eAt_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %s3, ptr %t22, i64 %t23)
  store %"compiler/typed:landLoop" %t26, ptr %l17
  br label %bb9
bb9:
  %t27 = getelementptr %"compiler/typed:landLoop", ptr %l17, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t32 = icmp ne i32 %t28, %a2
  br i1 %t32, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Landings", ptr %t34, i32 0, i32 9
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = call %"compiler/typed:landLoop" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eAt_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  store %"compiler/typed:landLoop" %t40, ptr %l24
  br label %bb13
bb13:
  %t41 = load %"compiler/typed:landLoop", ptr %l24
  store %"compiler/typed:landLoop" %t41, ptr %l4
  %t44 = trunc i64 0 to i32
  %t45 = icmp eq i32 %a1, %t44
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t47 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 2
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Landings", ptr %t49, i32 0, i32 7
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  call void @compiler_2ftyped_2eorInto(ptr %v0, ptr %v0, { i64, ptr } %t48, { i64, ptr } %t52)
  br label %bb16
bb15:
  %t55 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 3
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Landings", ptr %t57, i32 0, i32 7
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  call void @compiler_2ftyped_2eorInto(ptr %v0, ptr %v0, { i64, ptr } %t56, { i64, ptr } %t60)
  br label %bb17
bb16:
  %t63 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 4
  store i1 true, ptr %t63, !tbaa !21
  br label %bb18
bb17:
  %t64 = getelementptr %"compiler/typed:landLoop", ptr %l4, i32 0, i32 5
  store i1 true, ptr %t64, !tbaa !21
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Landings", ptr %t65, i32 0, i32 9
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load %"compiler/typed:landLoop", ptr %l4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eSetAt_H5ab2aabe0ae7951e8bb06fbe4ca7219a(ptr %v0, ptr %v0, ptr %t67, i64 %t68, %"compiler/typed:landLoop" %t69)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb20:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = sub i64 %t73, 1
  store i64 %t75, ptr %l3, !tbaa !24
  br label %bb5
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Landings", ptr %t77, i32 0, i32 8
  store i1 true, ptr %t79, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/typed:landLoop"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/typed:landLoop"
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l30 = alloca %"compiler/typed:landLoop"
  %l34 = alloca i64
  %l37 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca i64
  %l64 = alloca %"compiler/typed:landLoop"
  %l74 = alloca i64
  %l77 = alloca i64
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l113 = alloca %"compiler/typed:landLoop"
  %l116 = alloca %"compiler/typed:landLoop"
  %l117 = alloca i32
  %l127 = alloca i64
  %l130 = alloca i64
  %l149 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l25, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Landings", ptr %t5, i32 0, i32 7
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = call %"compiler/typed:landLoop" @compiler_2ftyped_3alandLoop_2ector(ptr %v0, i32 %a1, i64 %t10)
  store %"compiler/typed:landLoop" %t13, ptr %l30
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l25, !tbaa !29
  %t15 = load %"compiler/typed:landLoop", ptr %l30
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2ePush_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %v0, ptr %t14, %"compiler/typed:landLoop" %t15)
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  store i64 2, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l37, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l37, !tbaa !24
  store i64 %t42, ptr %l34, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l34, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb40
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t62, ptr %a2)
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Landings", ptr %t67, i32 0, i32 9
  store ptr %t69, ptr %l59, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Landings", ptr %t70, i32 0, i32 9
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eLen_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %t72)
  store i64 %t74, ptr %l62
  br label %bb14
bb14:
  %t75 = load i64, ptr %l62, !tbaa !24
  %t76 = sub i64 %t75, 1
  %t77 = load ptr, ptr %l59, !tbaa !29
  %t79 = call %"compiler/typed:landLoop" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eAt_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %v0, ptr %t77, i64 %t76)
  store %"compiler/typed:landLoop" %t79, ptr %l64
  br label %bb15
bb15:
  %t80 = load %"compiler/typed:landLoop", ptr %l64
  store %"compiler/typed:landLoop" %t80, ptr %l10
  %t81 = getelementptr %"compiler/typed:landLoop", ptr %l10, i32 0, i32 5
  %t82 = load i1, ptr %t81, !tbaa !21
  br i1 %t82, label %bb16, label %bb17
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Landings", ptr %t84, i32 0, i32 8
  %t87 = load i1, ptr %t86, !tbaa !21
  br i1 %t87, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  store i64 0, ptr %l11, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Landings", ptr %t89, i32 0, i32 7
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t96 = load i64, ptr %l12, !tbaa !24
  %t97 = load i64, ptr %l11, !tbaa !24
  %t100 = icmp sgt i64 %t96, %t97
  br i1 %t100, label %bb20, label %bb21
bb19:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Landings", ptr %t102, i32 0, i32 7
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/typed:landLoop", ptr %l10, i32 0, i32 3
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  call void @compiler_2ftyped_2eorInto(ptr %v0, ptr %v0, { i64, ptr } %t105, { i64, ptr } %t107)
  br label %bb32
bb20:
  %t110 = load i64, ptr %l13, !tbaa !24
  %t112 = icmp sgt i64 %t110, 0
  br i1 %t112, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb25
bb22:
  %t114 = load i64, ptr %l12, !tbaa !24
  %t115 = load i64, ptr %l11, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t124 = sub i64 %t122, 1
  %t125 = load i64, ptr %l13, !tbaa !24
  %t128 = sdiv i64 %t124, %t125
  store i64 %t128, ptr %l77, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb24
bb24:
  %t130 = load i64, ptr %l77, !tbaa !24
  store i64 %t130, ptr %l74, !tbaa !24
  br label %bb25
bb25:
  %t131 = load i64, ptr %l74, !tbaa !24
  store i64 %t131, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb26
bb26:
  %t132 = load i64, ptr %l15, !tbaa !24
  %t133 = load i64, ptr %l14, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb27, label %bb28
bb27:
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t140 = load i64, ptr %l11, !tbaa !24
  %t141 = load i64, ptr %l15, !tbaa !24
  %t142 = load i64, ptr %l13, !tbaa !24
  %t145 = mul i64 %t141, %t142
  %t148 = add i64 %t140, %t145
  store i64 %t148, ptr %l16, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Landings", ptr %t150, i32 0, i32 7
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l96, !tbaa !27
  %t154 = load i64, ptr %l16, !tbaa !24
  %t155 = getelementptr %"compiler/typed:landLoop", ptr %l10, i32 0, i32 3
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l98, !tbaa !27
  %t157 = load i64, ptr %l16, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i1, ptr %t160, i64 %t157
  %t162 = load i1, ptr %t161, !tbaa !31
  %t165 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i1, ptr %t166, i64 %t154
  store i1 %t162, ptr %t167, !tbaa !31
  br label %bb30
bb30:
  %t168 = load i64, ptr %l15, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l15, !tbaa !24
  br label %bb26
bb31:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Landings", ptr %t172, i32 0, i32 8
  store i1 false, ptr %t174, !tbaa !21
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t175 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v2, ptr %t175, ptr %a3)
  br label %bb35
bb35:
  %t179 = load i64, ptr %l9, !tbaa !24
  %t181 = icmp eq i64 %t179, 1
  br i1 %t181, label %bb36, label %bb37
bb36:
  br label %bb40
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t183 = load i64, ptr %l8, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l8, !tbaa !24
  br label %bb9
bb40:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Landings", ptr %t187, i32 0, i32 9
  %t191 = call { i32, %"compiler/typed:landLoop" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2ePop_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %v0, ptr %t189)
  %t192 = extractvalue { i32, %"compiler/typed:landLoop" } %t191, 1
  %t193 = extractvalue { i32, %"compiler/typed:landLoop" } %t191, 0
  store i32 %t193, ptr %l117
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb42, label %ok.195, !prof !99
ok.195:
  store %"compiler/typed:landLoop" %t192, ptr %l116
  br label %bb41
bb41:
  %t196 = load %"compiler/typed:landLoop", ptr %l116
  store %"compiler/typed:landLoop" %t196, ptr %l113
  br label %bb44
bb42:
  br label %bb43
bb43:
  call void @__olang_ert_req_clear()
  br label %ret
bb44:
  %t197 = load %"compiler/typed:landLoop", ptr %l113
  store %"compiler/typed:landLoop" %t197, ptr %l17
  %t198 = getelementptr %"compiler/typed:landLoop", ptr %l17, i32 0, i32 4
  %t199 = load i1, ptr %t198, !tbaa !21
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb45, label %bb46
bb45:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/typed:Landings", ptr %t203, i32 0, i32 8
  store i1 true, ptr %t205, !tbaa !21
  br label %ret
bb46:
  br label %bb47
bb47:
  store i64 0, ptr %l18, !tbaa !24
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Landings", ptr %t206, i32 0, i32 7
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  store i64 %t211, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t213 = load i64, ptr %l19, !tbaa !24
  %t214 = load i64, ptr %l18, !tbaa !24
  %t217 = icmp sgt i64 %t213, %t214
  br i1 %t217, label %bb48, label %bb49
bb48:
  %t219 = load i64, ptr %l20, !tbaa !24
  %t221 = icmp sgt i64 %t219, 0
  br i1 %t221, label %bb50, label %bb51
bb49:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb53
bb50:
  %t223 = load i64, ptr %l19, !tbaa !24
  %t224 = load i64, ptr %l18, !tbaa !24
  %t227 = sub i64 %t223, %t224
  %t228 = load i64, ptr %l20, !tbaa !24
  %t231 = add i64 %t227, %t228
  %t233 = sub i64 %t231, 1
  %t234 = load i64, ptr %l20, !tbaa !24
  %t237 = sdiv i64 %t233, %t234
  store i64 %t237, ptr %l130, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb52
bb52:
  %t239 = load i64, ptr %l130, !tbaa !24
  store i64 %t239, ptr %l127, !tbaa !24
  br label %bb53
bb53:
  %t240 = load i64, ptr %l127, !tbaa !24
  store i64 %t240, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb54
bb54:
  %t241 = load i64, ptr %l22, !tbaa !24
  %t242 = load i64, ptr %l21, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  br label %bb57
bb57:
  %t249 = load i64, ptr %l18, !tbaa !24
  %t250 = load i64, ptr %l22, !tbaa !24
  %t251 = load i64, ptr %l20, !tbaa !24
  %t254 = mul i64 %t250, %t251
  %t257 = add i64 %t249, %t254
  store i64 %t257, ptr %l23, !tbaa !24
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Landings", ptr %t259, i32 0, i32 7
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  store { i64, ptr } %t262, ptr %l149, !tbaa !27
  %t263 = load i64, ptr %l23, !tbaa !24
  %t264 = getelementptr %"compiler/typed:landLoop", ptr %l17, i32 0, i32 2
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  store { i64, ptr } %t265, ptr %l151, !tbaa !27
  %t266 = load i64, ptr %l23, !tbaa !24
  %t268 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr i1, ptr %t269, i64 %t266
  %t271 = load i1, ptr %t270, !tbaa !31
  %t274 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr i1, ptr %t275, i64 %t263
  store i1 %t271, ptr %t276, !tbaa !31
  br label %bb58
bb58:
  %t277 = load i64, ptr %l22, !tbaa !24
  %t279 = add i64 %t277, 1
  store i64 %t279, ptr %l22, !tbaa !24
  br label %bb54
bb59:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/typed:Landings", ptr %t281, i32 0, i32 8
  store i1 false, ptr %t283, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ematchExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca %"compiler/typed:landState"
  %l7 = alloca %"compiler/typed:landState"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l28 = alloca %"compiler/typed:landState"
  %l31 = alloca i64
  %l34 = alloca %"compiler/typed:landState"
  %l43 = alloca { i64, ptr }
  %l53 = alloca %"compiler/typed:landState"
  %l62 = alloca ptr
  %l71 = alloca %"compiler/typed:landState"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l20, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %t26, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s0, ptr %t34)
  store %"compiler/typed:landState" %t36, ptr %l28
  br label %bb8
bb8:
  %t37 = load %"compiler/typed:landState", ptr %l28
  store %"compiler/typed:landState" %t37, ptr %l6
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Landings", ptr %t38, i32 0, i32 7
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l31, !tbaa !24
  %t44 = load i64, ptr %l31, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i64, ptr %l31, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = call %"compiler/typed:landState" @compiler_2ftyped_3alandState_2ector(ptr %s0, ptr %s0, { i64, ptr } %t51, i1 true)
  store %"compiler/typed:landState" %t53, ptr %l34
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_17d1ac1d0088a46d_f6898a8fba654071)
  unreachable
bb11:
  %t54 = load %"compiler/typed:landState", ptr %l34
  store %"compiler/typed:landState" %t54, ptr %l7
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Match", ptr %t55, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t72 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t72, ptr %l43, !tbaa !27
  %t73 = load i64, ptr %l9, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 %t73
  %t78 = load ptr, ptr %t77, !tbaa !39
  store ptr %t78, ptr %l11, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s0, ptr %t80, ptr %l6)
  br label %bb16
bb16:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2earm(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  br label %bb17
bb17:
  %t87 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s0, ptr %t87, ptr %l7)
  br label %bb18
bb18:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s0, ptr %t90)
  store %"compiler/typed:landState" %t92, ptr %l53
  br label %bb19
bb19:
  %t93 = load %"compiler/typed:landState", ptr %l53
  store %"compiler/typed:landState" %t93, ptr %l7
  br label %bb20
bb20:
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l9, !tbaa !24
  br label %bb12
bb21:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Match", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb22, label %bb23
bb22:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s0, ptr %t107, ptr %l6)
  br label %bb24
bb23:
  br label %bb31
bb24:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l62, !tbaa !29
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Match", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb25, label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_53c662fb23aaf808_98195192fab83824)
  unreachable
bb26:
  br label %bb27
bb27:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Match", ptr %t118, i32 0, i32 2
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load ptr, ptr %l62, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2earm(ptr %v0, ptr %v1, ptr %t122, ptr %t121)
  br label %bb28
bb28:
  %t124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s0, ptr %t124, ptr %l7)
  br label %bb29
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s0, ptr %t127)
  store %"compiler/typed:landState" %t129, ptr %l71
  br label %bb30
bb30:
  %t130 = load %"compiler/typed:landState", ptr %l71
  store %"compiler/typed:landState" %t130, ptr %l7
  br label %bb31
bb31:
  %t131 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s0, ptr %t131, ptr %l7)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emention(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l36 = alloca ptr
  %l38 = alloca i1
  %l42 = alloca i1
  %l47 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca i64
  %l90 = alloca ptr
  %l93 = alloca i64
  %l96 = alloca ptr
  %l100 = alloca i64
  %l112 = alloca i1
  %l116 = alloca i1
  %l136 = alloca i64
  %l139 = alloca i64
  %l158 = alloca { i64, ptr }
  %l163 = alloca i1
  %l165 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l187 = alloca i64
  %l190 = alloca i64
  %l209 = alloca { i64, ptr }
  %l214 = alloca i1
  %l216 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l4, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Landings", ptr %t5, i32 0, i32 13
  %t8 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Landings", ptr %t11, i32 0, i32 14
  %t14 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Landings", ptr %t17, i32 0, i32 15
  %t20 = load i1, ptr %l3, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t19, i1 %t20)
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Landings", ptr %t23, i32 0, i32 16
  store ptr %t25, ptr %l36, !tbaa !29
  %t26 = load i1, ptr %l3, !tbaa !21
  br i1 %t26, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb6
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Landings", ptr %t28, i32 0, i32 18
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  store i1 %t33, ptr %l38, !tbaa !21
  br label %bb6
bb6:
  %t35 = load i1, ptr %l38, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb9
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Landings", ptr %t36, i32 0, i32 21
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  store i1 %t41, ptr %l42, !tbaa !21
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l36, !tbaa !29
  %t44 = load i1, ptr %l42, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t43, i1 %t44)
  br label %bb10
bb10:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/typed:Landings", ptr %t45, i32 0, i32 17
  store ptr %t47, ptr %l47, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Landings", ptr %t48, i32 0, i32 18
  %t51 = load i64, ptr %t50, !tbaa !24
  %t53 = icmp sgt i64 %t51, 0
  br i1 %t53, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb13
bb12:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Landings", ptr %t55, i32 0, i32 21
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = icmp sge i64 %t58, 0
  store i1 %t60, ptr %l51, !tbaa !21
  br label %bb13
bb13:
  %t62 = load ptr, ptr %l47, !tbaa !29
  %t63 = load i1, ptr %l51, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t62, i1 %t63)
  br label %bb14
bb14:
  store i64 0, ptr %l5, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Landings", ptr %t64, i32 0, i32 19
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l57
  br label %bb15
bb15:
  %t69 = load i64, ptr %l57, !tbaa !24
  store i64 %t69, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb16, label %bb17
bb16:
  %t76 = load i64, ptr %l7, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb21
bb18:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t81 = load i64, ptr %l5, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l64, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb20
bb20:
  %t96 = load i64, ptr %l64, !tbaa !24
  store i64 %t96, ptr %l61, !tbaa !24
  br label %bb21
bb21:
  %t97 = load i64, ptr %l61, !tbaa !24
  store i64 %t97, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb22
bb22:
  %t98 = load i64, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb23, label %bb24
bb23:
  br label %bb36
bb24:
  br label %bb25
bb25:
  %t106 = load i64, ptr %l5, !tbaa !24
  %t107 = load i64, ptr %l9, !tbaa !24
  %t108 = load i64, ptr %l7, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l10, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Landings", ptr %t116, i32 0, i32 19
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t118, i64 %t119)
  store i64 %t122, ptr %l85
  br label %bb26
bb26:
  %t123 = load i64, ptr %l4, !tbaa !24
  %t124 = load i64, ptr %l85, !tbaa !24
  %t126 = icmp ne i64 %t124, %t123
  br i1 %t126, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Landings", ptr %t128, i32 0, i32 21
  %t131 = load i64, ptr %t130, !tbaa !24
  store i64 %t131, ptr %l11, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l90, !tbaa !29
  %t134 = load i64, ptr %l11, !tbaa !24
  %t136 = icmp slt i64 %t134, 0
  br i1 %t136, label %bb30, label %bb31
bb30:
  %t138 = load i64, ptr %l4, !tbaa !24
  store i64 %t138, ptr %l93, !tbaa !24
  br label %bb32
bb31:
  %t140 = load i64, ptr %l11, !tbaa !24
  store i64 %t140, ptr %l93, !tbaa !24
  br label %bb32
bb32:
  %t142 = load i64, ptr %l93, !tbaa !24
  %t143 = load ptr, ptr %l90, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Landings", ptr %t143, i32 0, i32 21
  store i64 %t142, ptr %t144, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l96, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Landings", ptr %t146, i32 0, i32 20
  %t149 = load i64, ptr %l10, !tbaa !24
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t148, i64 %t149)
  store i64 %t152, ptr %l100
  br label %bb33
bb33:
  %t153 = load i64, ptr %l100, !tbaa !24
  %t154 = trunc i64 %t153 to i32
  %t156 = load i64, ptr %l2, !tbaa !24
  %t157 = load ptr, ptr %l96, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emention(ptr %v0, ptr %t157, i32 %t154, i64 %t156, i1 false)
  br label %bb34
bb34:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i64, ptr %l11, !tbaa !24
  %t164 = getelementptr %"compiler/typed:Landings", ptr %t160, i32 0, i32 21
  store i64 %t161, ptr %t164, !tbaa !24
  br label %bb35
bb35:
  %t165 = load i64, ptr %l9, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l9, !tbaa !24
  br label %bb22
bb36:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Landings", ptr %t169, i32 0, i32 10
  %t172 = load i64, ptr %t171, !tbaa !24
  %t174 = icmp sgt i64 %t172, 0
  br i1 %t174, label %bb37, label %bb38
bb37:
  %t176 = load i1, ptr %l3, !tbaa !21
  br i1 %t176, label %bb39, label %bb40
bb38:
  br label %bb51
bb39:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i64, ptr %l4, !tbaa !24
  %t180 = load i64, ptr %l2, !tbaa !24
  %t184 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eguardedAt(ptr %v0, ptr %t178, i64 %t179, i64 %t180)
  store i1 %t184, ptr %l116
  br label %bb41
bb40:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb42
bb41:
  %t185 = load i1, ptr %l116, !tbaa !21
  store i1 %t185, ptr %l112, !tbaa !21
  br label %bb42
bb42:
  %t186 = load i1, ptr %l112, !tbaa !21
  br i1 %t186, label %bb43, label %bb44
bb43:
  br label %ret
bb44:
  br label %bb45
bb45:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Landings", ptr %t187, i32 0, i32 11
  %t190 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t189, i64 %t190, i1 true)
  br label %bb46
bb46:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Landings", ptr %t193, i32 0, i32 21
  %t196 = load i64, ptr %t195, !tbaa !24
  %t198 = icmp sge i64 %t196, 0
  br i1 %t198, label %bb47, label %bb48
bb47:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Landings", ptr %t200, i32 0, i32 12
  %t203 = load i64, ptr %l4, !tbaa !24
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/typed:Landings", ptr %t204, i32 0, i32 21
  %t207 = load i64, ptr %t206, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t202, i64 %t203, i64 %t207)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %ret
bb51:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Landings", ptr %t211, i32 0, i32 8
  %t214 = load i1, ptr %t213, !tbaa !21
  br i1 %t214, label %bb52, label %bb53
bb52:
  br label %ret
bb53:
  br label %bb54
bb54:
  store i64 0, ptr %l12, !tbaa !24
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Landings", ptr %t216, i32 0, i32 0
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t219, 0
  store i64 %t221, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t223 = load i64, ptr %l13, !tbaa !24
  %t224 = load i64, ptr %l12, !tbaa !24
  %t227 = icmp sgt i64 %t223, %t224
  br i1 %t227, label %bb55, label %bb56
bb55:
  %t229 = load i64, ptr %l14, !tbaa !24
  %t231 = icmp sgt i64 %t229, 0
  br i1 %t231, label %bb57, label %bb58
bb56:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb60
bb57:
  %t233 = load i64, ptr %l13, !tbaa !24
  %t234 = load i64, ptr %l12, !tbaa !24
  %t237 = sub i64 %t233, %t234
  %t238 = load i64, ptr %l14, !tbaa !24
  %t241 = add i64 %t237, %t238
  %t243 = sub i64 %t241, 1
  %t244 = load i64, ptr %l14, !tbaa !24
  %t247 = sdiv i64 %t243, %t244
  store i64 %t247, ptr %l139, !tbaa !24
  br label %bb59
bb58:
  store i64 0, ptr %l139, !tbaa !24
  br label %bb59
bb59:
  %t249 = load i64, ptr %l139, !tbaa !24
  store i64 %t249, ptr %l136, !tbaa !24
  br label %bb60
bb60:
  %t250 = load i64, ptr %l136, !tbaa !24
  store i64 %t250, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb61
bb61:
  %t251 = load i64, ptr %l16, !tbaa !24
  %t252 = load i64, ptr %l15, !tbaa !24
  %t255 = icmp slt i64 %t251, %t252
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb62, label %bb63
bb62:
  br label %bb72
bb63:
  br label %bb64
bb64:
  %t259 = load i64, ptr %l12, !tbaa !24
  %t260 = load i64, ptr %l16, !tbaa !24
  %t261 = load i64, ptr %l14, !tbaa !24
  %t264 = mul i64 %t260, %t261
  %t267 = add i64 %t259, %t264
  store i64 %t267, ptr %l17, !tbaa !24
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Landings", ptr %t269, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l158, !tbaa !27
  %t273 = load i64, ptr %l17, !tbaa !24
  %t275 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr i64, ptr %t276, i64 %t273
  %t278 = load i64, ptr %t277, !tbaa !34
  %t279 = load i64, ptr %l4, !tbaa !24
  %t282 = icmp ne i64 %t278, %t279
  br i1 %t282, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l163, !tbaa !21
  br label %bb67
bb66:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/typed:Landings", ptr %t284, i32 0, i32 7
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  store { i64, ptr } %t287, ptr %l165, !tbaa !27
  %t288 = load i64, ptr %l17, !tbaa !24
  %t290 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr i1, ptr %t291, i64 %t288
  %t293 = load i1, ptr %t292, !tbaa !31
  %t295 = xor i1 %t293, true
  store i1 %t295, ptr %l163, !tbaa !21
  br label %bb67
bb67:
  %t297 = load i1, ptr %l163, !tbaa !21
  br i1 %t297, label %bb68, label %bb69
bb68:
  br label %bb71
bb69:
  br label %bb70
bb70:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Landings", ptr %t298, i32 0, i32 4
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !27
  store { i64, ptr } %t301, ptr %l170, !tbaa !27
  %t302 = load i64, ptr %l17, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i1, ptr %t305, i64 %t302
  store i1 true, ptr %t306, !tbaa !31
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Landings", ptr %t307, i32 0, i32 5
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  store { i64, ptr } %t310, ptr %l173, !tbaa !27
  %t311 = load i64, ptr %l17, !tbaa !24
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/typed:Landings", ptr %t312, i32 0, i32 21
  %t315 = load i64, ptr %t314, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr i64, ptr %t319, i64 %t311
  store i64 %t315, ptr %t320, !tbaa !34
  br label %bb71
bb71:
  %t321 = load i64, ptr %l16, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l16, !tbaa !24
  br label %bb61
bb72:
  %t325 = load i1, ptr %l3, !tbaa !21
  %t327 = xor i1 %t325, true
  br i1 %t327, label %bb73, label %bb74
bb73:
  br label %ret
bb74:
  br label %bb75
bb75:
  store i64 0, ptr %l18, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Landings", ptr %t329, i32 0, i32 0
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t332, 0
  store i64 %t334, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t336 = load i64, ptr %l19, !tbaa !24
  %t337 = load i64, ptr %l18, !tbaa !24
  %t340 = icmp sgt i64 %t336, %t337
  br i1 %t340, label %bb76, label %bb77
bb76:
  %t342 = load i64, ptr %l20, !tbaa !24
  %t344 = icmp sgt i64 %t342, 0
  br i1 %t344, label %bb78, label %bb79
bb77:
  store i64 0, ptr %l187, !tbaa !24
  br label %bb81
bb78:
  %t346 = load i64, ptr %l19, !tbaa !24
  %t347 = load i64, ptr %l18, !tbaa !24
  %t350 = sub i64 %t346, %t347
  %t351 = load i64, ptr %l20, !tbaa !24
  %t354 = add i64 %t350, %t351
  %t356 = sub i64 %t354, 1
  %t357 = load i64, ptr %l20, !tbaa !24
  %t360 = sdiv i64 %t356, %t357
  store i64 %t360, ptr %l190, !tbaa !24
  br label %bb80
bb79:
  store i64 0, ptr %l190, !tbaa !24
  br label %bb80
bb80:
  %t362 = load i64, ptr %l190, !tbaa !24
  store i64 %t362, ptr %l187, !tbaa !24
  br label %bb81
bb81:
  %t363 = load i64, ptr %l187, !tbaa !24
  store i64 %t363, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb82
bb82:
  %t364 = load i64, ptr %l22, !tbaa !24
  %t365 = load i64, ptr %l21, !tbaa !24
  %t368 = icmp slt i64 %t364, %t365
  %t370 = xor i1 %t368, true
  br i1 %t370, label %bb83, label %bb84
bb83:
  br label %bb93
bb84:
  br label %bb85
bb85:
  %t372 = load i64, ptr %l18, !tbaa !24
  %t373 = load i64, ptr %l22, !tbaa !24
  %t374 = load i64, ptr %l20, !tbaa !24
  %t377 = mul i64 %t373, %t374
  %t380 = add i64 %t372, %t377
  store i64 %t380, ptr %l23, !tbaa !24
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/typed:Landings", ptr %t382, i32 0, i32 0
  %t385 = load { i64, ptr }, ptr %t384, !tbaa !27
  store { i64, ptr } %t385, ptr %l209, !tbaa !27
  %t386 = load i64, ptr %l23, !tbaa !24
  %t388 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !27
  %t390 = getelementptr i64, ptr %t389, i64 %t386
  %t391 = load i64, ptr %t390, !tbaa !34
  %t392 = load i64, ptr %l4, !tbaa !24
  %t395 = icmp eq i64 %t391, %t392
  br i1 %t395, label %bb86, label %bb87
bb86:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Landings", ptr %t397, i32 0, i32 1
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  store { i64, ptr } %t400, ptr %l216, !tbaa !27
  %t401 = load i64, ptr %l23, !tbaa !24
  %t403 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr i64, ptr %t404, i64 %t401
  %t406 = load i64, ptr %t405, !tbaa !34
  %t407 = load i64, ptr %l2, !tbaa !24
  %t410 = icmp eq i64 %t406, %t407
  store i1 %t410, ptr %l214, !tbaa !21
  br label %bb88
bb87:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb88
bb88:
  %t412 = load i1, ptr %l214, !tbaa !21
  br i1 %t412, label %bb89, label %bb90
bb89:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = getelementptr %"compiler/typed:Landings", ptr %t413, i32 0, i32 7
  %t416 = load { i64, ptr }, ptr %t415, !tbaa !27
  store { i64, ptr } %t416, ptr %l222, !tbaa !27
  %t417 = load i64, ptr %l23, !tbaa !24
  %t419 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !27
  %t421 = getelementptr i1, ptr %t420, i64 %t417
  store i1 true, ptr %t421, !tbaa !31
  br label %bb91
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t422 = load i64, ptr %l22, !tbaa !24
  %t424 = add i64 %t422, 1
  store i64 %t424, ptr %l22, !tbaa !24
  br label %bb82
bb93:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erenewed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Landings", ptr %t6, i32 0, i32 10
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  store i1 %t11, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  store i64 0, ptr %l2, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Landings", ptr %t14, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb12
bb9:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l23, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb11
bb11:
  %t47 = load i64, ptr %l23, !tbaa !24
  store i64 %t47, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l20, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb14, label %bb15
bb14:
  br label %bb21
bb15:
  br label %bb16
bb16:
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l7, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Landings", ptr %t67, i32 0, i32 0
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i64, ptr %t74, i64 %t71
  %t76 = load i64, ptr %t75, !tbaa !34
  %t80 = icmp eq i64 %t76, %a1
  br i1 %t80, label %bb17, label %bb18
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Landings", ptr %t82, i32 0, i32 7
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  store { i64, ptr } %t85, ptr %l48, !tbaa !27
  %t86 = load i64, ptr %l7, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i1, ptr %t89, i64 %t86
  store i1 false, ptr %t90, !tbaa !31
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb13
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 7
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l17, !tbaa !24
  store i64 %t34, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l14, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Landings", ptr %t54, i32 0, i32 7
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l36, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/typed:landState", ptr %t59, i32 0, i32 0
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l39, !tbaa !27
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i1, ptr %t66, i64 %t63
  %t68 = load i1, ptr %t67, !tbaa !31
  %t71 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i1, ptr %t72, i64 %t58
  store i1 %t68, ptr %t73, !tbaa !31
  br label %bb11
bb11:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb7
bb12:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:landState", ptr %t79, i32 0, i32 1
  %t82 = load i1, ptr %t81, !tbaa !21
  %t85 = getelementptr %"compiler/typed:Landings", ptr %t78, i32 0, i32 8
  store i1 %t82, ptr %t85, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/typed:landState"
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l45 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l94 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i1
  %l190 = alloca %"compiler/typed:landState"
  %l195 = alloca ptr
  %l196 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca i1
  %l213 = alloca ptr
  %l214 = alloca i1
  %l223 = alloca ptr
  %l229 = alloca ptr
  %l232 = alloca ptr
  %l233 = alloca i1
  %l238 = alloca ptr
  %l249 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l279 = alloca ptr
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t2 = load ptr, ptr %l35, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l35, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l36, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l36, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Landings", ptr %t22, i32 0, i32 13
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l45
  br label %bb6
bb6:
  %t27 = load i64, ptr %l45, !tbaa !24
  store i64 %t27, ptr %l4, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t36 = sext i32 %t34 to i64
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erenewed(ptr %v0, ptr %t33, i64 %t36)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t43 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eholds(ptr %v0, ptr %t39, i64 %t42, i64 %t43)
  br label %bb9
bb9:
  br label %bb151
bb10:
  %t47 = load ptr, ptr %l1, !tbaa !29
  store ptr %t47, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t48 = load ptr, ptr %l56, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l56, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 17}
  %t54 = icmp eq i64 %t52, 2
  store i1 %t54, ptr %l57, !tbaa !21
  br label %bb12
bb12:
  %t55 = load i1, ptr %l57, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [3 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l5, !tbaa !29
  br label %bb23
bb14:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t63 = load ptr, ptr %l62, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t66 = load ptr, ptr %l62, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 17}
  %t69 = icmp eq i64 %t67, 15
  store i1 %t69, ptr %l63, !tbaa !21
  br label %bb16
bb16:
  %t70 = load i1, ptr %l63, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", ptr }, ptr %t73, i32 0, i32 1
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l5, !tbaa !29
  br label %bb23
bb18:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t78 = load ptr, ptr %l68, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t81 = load ptr, ptr %l68, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 17}
  %t84 = icmp eq i64 %t82, 8
  store i1 %t84, ptr %l69, !tbaa !21
  br label %bb20
bb20:
  %t85 = load i1, ptr %l69, !tbaa !21
  br i1 %t85, label %bb21, label %bb22
bb21:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t88, i32 0, i32 1
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  br label %bb24
bb24:
  br label %bb151
bb25:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t98 = load ptr, ptr %l77, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb26, label %bb27
bb26:
  %t101 = load ptr, ptr %l77, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 17}
  %t104 = icmp eq i64 %t102, 1
  store i1 %t104, ptr %l78, !tbaa !21
  br label %bb27
bb27:
  %t105 = load i1, ptr %l78, !tbaa !21
  br i1 %t105, label %bb28, label %bb29
bb28:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [3 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t108, i32 0, i32 1
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l6, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr { i64, [3 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t114, i32 0, i32 2
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l7, !tbaa !29
  br label %bb30
bb29:
  br label %bb46
bb30:
  %t118 = load ptr, ptr %l6, !tbaa !29
  store ptr %t118, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t119 = load ptr, ptr %l85, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb31, label %bb32
bb31:
  %t122 = load ptr, ptr %l85, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 8}
  %t125 = icmp eq i64 %t123, 0
  store i1 %t125, ptr %l86, !tbaa !21
  br label %bb32
bb32:
  %t126 = load i1, ptr %l86, !tbaa !21
  %t127 = xor i1 %t126, true
  br i1 %t127, label %bb33, label %bb34
bb33:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t129, ptr %t130)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/typed:Landings", ptr %t133, i32 0, i32 13
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t135)
  store i64 %t137, ptr %l94
  br label %bb37
bb37:
  %t138 = load i64, ptr %l94, !tbaa !24
  store i64 %t138, ptr %l8, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t139, ptr %t140)
  br label %bb38
bb38:
  %t144 = load ptr, ptr %l6, !tbaa !29
  store ptr %t144, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t145 = load ptr, ptr %l98, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb39, label %bb40
bb39:
  %t148 = load ptr, ptr %l98, !tbaa !29
  %t149 = load i64, ptr %t148, !range !{i64 0, i64 8}
  %t151 = icmp eq i64 %t149, 0
  store i1 %t151, ptr %l99, !tbaa !21
  br label %bb40
bb40:
  %t152 = load i1, ptr %l99, !tbaa !21
  br i1 %t152, label %bb41, label %bb42
bb41:
  %t153 = load ptr, ptr %l6, !tbaa !29
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t155, i32 0, i32 0
  %t157 = load %"compiler/source:Span", ptr %t156
  store %"compiler/source:Span" %t157, ptr %l9
  %t159 = load ptr, ptr %l6, !tbaa !29
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t161, i32 0, i32 1
  %t163 = load i32, ptr %t162
  store i32 %t163, ptr %l10, !tbaa !23
  %t165 = load ptr, ptr %l6, !tbaa !29
  %t167 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t167, i32 0, i32 2
  %t169 = load i32, ptr %t168
  store i32 %t169, ptr %l11, !tbaa !23
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l11, !tbaa !23
  %t174 = sext i32 %t172 to i64
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erenewed(ptr %v0, ptr %t171, i64 %t174)
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l11, !tbaa !23
  %t180 = sext i32 %t178 to i64
  %t181 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eholds(ptr %v0, ptr %t177, i64 %t180, i64 %t181)
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb151
bb46:
  %t185 = load ptr, ptr %l1, !tbaa !29
  store ptr %t185, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t186 = load ptr, ptr %l115, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb47, label %bb48
bb47:
  %t189 = load ptr, ptr %l115, !tbaa !29
  %t190 = load i64, ptr %t189, !range !{i64 0, i64 17}
  %t192 = icmp eq i64 %t190, 16
  store i1 %t192, ptr %l116, !tbaa !21
  br label %bb48
bb48:
  %t193 = load i1, ptr %l116, !tbaa !21
  br i1 %t193, label %bb49, label %bb50
bb49:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr }, ptr %t196, i32 0, i32 1
  %t198 = load ptr, ptr %t197
  store ptr %t198, ptr %l12, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t200, ptr %t201)
  br label %bb52
bb52:
  br label %bb151
bb53:
  %t204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t204, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t205 = load ptr, ptr %l123, !tbaa !29
  %t206 = icmp ne ptr %t205, null
  br i1 %t206, label %bb54, label %bb55
bb54:
  %t208 = load ptr, ptr %l123, !tbaa !29
  %t209 = load i64, ptr %t208, !range !{i64 0, i64 17}
  %t211 = icmp eq i64 %t209, 6
  store i1 %t211, ptr %l124, !tbaa !21
  br label %bb55
bb55:
  %t212 = load i1, ptr %l124, !tbaa !21
  br i1 %t212, label %bb56, label %bb57
bb56:
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 1
  %t216 = getelementptr { %"compiler/source:Span", ptr }, ptr %t215, i32 0, i32 1
  %t217 = load ptr, ptr %t216
  store ptr %t217, ptr %l13, !tbaa !29
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t219, ptr %t220)
  br label %bb59
bb59:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Landings", ptr %t223, i32 0, i32 8
  store i1 true, ptr %t225, !tbaa !21
  br label %bb151
bb60:
  %t226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t226, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t227 = load ptr, ptr %l132, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb61, label %bb62
bb61:
  %t230 = load ptr, ptr %l132, !tbaa !29
  %t231 = load i64, ptr %t230, !range !{i64 0, i64 17}
  %t233 = icmp eq i64 %t231, 7
  store i1 %t233, ptr %l133, !tbaa !21
  br label %bb62
bb62:
  %t234 = load i1, ptr %l133, !tbaa !21
  br i1 %t234, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/typed:Landings", ptr %t235, i32 0, i32 8
  store i1 true, ptr %t237, !tbaa !21
  br label %bb151
bb66:
  %t238 = load ptr, ptr %l1, !tbaa !29
  store ptr %t238, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t239 = load ptr, ptr %l137, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb67, label %bb68
bb67:
  %t242 = load ptr, ptr %l137, !tbaa !29
  %t243 = load i64, ptr %t242, !range !{i64 0, i64 17}
  %t245 = icmp eq i64 %t243, 9
  store i1 %t245, ptr %l138, !tbaa !21
  br label %bb68
bb68:
  %t246 = load i1, ptr %l138, !tbaa !21
  br i1 %t246, label %bb69, label %bb70
bb69:
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t249 = getelementptr { i64, [3 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t249, i32 0, i32 2
  %t251 = load ptr, ptr %t250
  store ptr %t251, ptr %l14, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t253, ptr %t254)
  br label %bb72
bb72:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/typed:Landings", ptr %t257, i32 0, i32 8
  store i1 true, ptr %t259, !tbaa !21
  br label %bb151
bb73:
  %t260 = load ptr, ptr %l1, !tbaa !29
  store ptr %t260, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t261 = load ptr, ptr %l146, !tbaa !29
  %t262 = icmp ne ptr %t261, null
  br i1 %t262, label %bb74, label %bb75
bb74:
  %t264 = load ptr, ptr %l146, !tbaa !29
  %t265 = load i64, ptr %t264, !range !{i64 0, i64 17}
  %t267 = icmp eq i64 %t265, 3
  store i1 %t267, ptr %l147, !tbaa !21
  br label %bb75
bb75:
  %t268 = load i1, ptr %l147, !tbaa !21
  br i1 %t268, label %bb76, label %bb77
bb76:
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr { i64, [3 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { %"compiler/source:Span", ptr }, ptr %t271, i32 0, i32 1
  %t273 = load ptr, ptr %t272
  store ptr %t273, ptr %l15, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eifStmt(ptr %v0, ptr %v1, ptr %t275, ptr %t276)
  br label %bb79
bb79:
  br label %bb151
bb80:
  %t279 = load ptr, ptr %l1, !tbaa !29
  store ptr %t279, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t280 = load ptr, ptr %l154, !tbaa !29
  %t281 = icmp ne ptr %t280, null
  br i1 %t281, label %bb81, label %bb82
bb81:
  %t283 = load ptr, ptr %l154, !tbaa !29
  %t284 = load i64, ptr %t283, !range !{i64 0, i64 17}
  %t286 = icmp eq i64 %t284, 4
  store i1 %t286, ptr %l155, !tbaa !21
  br label %bb82
bb82:
  %t287 = load i1, ptr %l155, !tbaa !21
  br i1 %t287, label %bb83, label %bb84
bb83:
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr { i64, [3 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t290, i32 0, i32 1
  %t292 = load ptr, ptr %t291
  store ptr %t292, ptr %l16, !tbaa !29
  %t294 = load ptr, ptr %l1, !tbaa !29
  %t296 = getelementptr { i64, [3 x i64] }, ptr %t294, i32 0, i32 1
  %t297 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t296, i32 0, i32 2
  %t298 = load ptr, ptr %t297
  store ptr %t298, ptr %l17, !tbaa !29
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load ptr, ptr %l16, !tbaa !29
  %t303 = getelementptr %"compiler/typed:Block", ptr %t301, i32 0, i32 0
  %t304 = load i32, ptr %t303, !tbaa !23
  %t305 = load ptr, ptr %l16, !tbaa !29
  %t306 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %t300, i32 %t304, ptr %t305, ptr %t306)
  br label %bb86
bb86:
  br label %bb151
bb87:
  %t311 = load ptr, ptr %l1, !tbaa !29
  store ptr %t311, ptr %l167, !tbaa !29
  store i1 false, ptr %l168, !tbaa !21
  %t312 = load ptr, ptr %l167, !tbaa !29
  %t313 = icmp ne ptr %t312, null
  br i1 %t313, label %bb88, label %bb89
bb88:
  %t315 = load ptr, ptr %l167, !tbaa !29
  %t316 = load i64, ptr %t315, !range !{i64 0, i64 17}
  %t318 = icmp eq i64 %t316, 5
  store i1 %t318, ptr %l168, !tbaa !21
  br label %bb89
bb89:
  %t319 = load i1, ptr %l168, !tbaa !21
  br i1 %t319, label %bb90, label %bb91
bb90:
  %t320 = load ptr, ptr %l1, !tbaa !29
  %t322 = getelementptr { i64, [3 x i64] }, ptr %t320, i32 0, i32 1
  %t323 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t322, i32 0, i32 1
  %t324 = load i32, ptr %t323, !range !{i32 0, i32 2}
  store i32 %t324, ptr %l18
  %t326 = load ptr, ptr %l1, !tbaa !29
  %t328 = getelementptr { i64, [3 x i64] }, ptr %t326, i32 0, i32 1
  %t329 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t328, i32 0, i32 2
  %t330 = load i32, ptr %t329
  store i32 %t330, ptr %l19, !tbaa !23
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i32, ptr %l18, !range !{i32 0, i32 2}
  %t334 = load i32, ptr %l19, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ejump(ptr %v0, ptr %t332, i32 %t333, i32 %t334)
  br label %bb93
bb93:
  br label %bb151
bb94:
  %t338 = load ptr, ptr %l1, !tbaa !29
  store ptr %t338, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t339 = load ptr, ptr %l178, !tbaa !29
  %t340 = icmp ne ptr %t339, null
  br i1 %t340, label %bb95, label %bb96
bb95:
  %t342 = load ptr, ptr %l178, !tbaa !29
  %t343 = load i64, ptr %t342, !range !{i64 0, i64 17}
  %t345 = icmp eq i64 %t343, 10
  store i1 %t345, ptr %l179, !tbaa !21
  br label %bb96
bb96:
  %t346 = load i1, ptr %l179, !tbaa !21
  br i1 %t346, label %bb97, label %bb98
bb97:
  %t347 = load ptr, ptr %l1, !tbaa !29
  %t349 = getelementptr { i64, [3 x i64] }, ptr %t347, i32 0, i32 1
  %t350 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t349, i32 0, i32 1
  %t351 = load ptr, ptr %t350
  store ptr %t351, ptr %l20, !tbaa !29
  %t353 = load ptr, ptr %l1, !tbaa !29
  %t355 = getelementptr { i64, [3 x i64] }, ptr %t353, i32 0, i32 1
  %t356 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t355, i32 0, i32 2
  %t357 = load ptr, ptr %t356
  store ptr %t357, ptr %l21, !tbaa !29
  br label %bb99
bb98:
  br label %bb104
bb99:
  store %olang.scope zeroinitializer, ptr %s13
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t359, ptr %t360)
  br label %bb100
bb100:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s13, ptr %t364)
  store %"compiler/typed:landState" %t366, ptr %l190
  br label %bb101
bb101:
  %t367 = load %"compiler/typed:landState", ptr %l190
  store %"compiler/typed:landState" %t367, ptr %l22
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t368, ptr %t369)
  br label %bb102
bb102:
  %t372 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s13, ptr %t372, ptr %l22)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s13)
  br label %bb151
bb104:
  %t375 = load ptr, ptr %l1, !tbaa !29
  store ptr %t375, ptr %l195, !tbaa !29
  store i1 false, ptr %l196, !tbaa !21
  %t376 = load ptr, ptr %l195, !tbaa !29
  %t377 = icmp ne ptr %t376, null
  br i1 %t377, label %bb105, label %bb106
bb105:
  %t379 = load ptr, ptr %l195, !tbaa !29
  %t380 = load i64, ptr %t379, !range !{i64 0, i64 17}
  %t382 = icmp eq i64 %t380, 11
  store i1 %t382, ptr %l196, !tbaa !21
  br label %bb106
bb106:
  %t383 = load i1, ptr %l196, !tbaa !21
  br i1 %t383, label %bb107, label %bb108
bb107:
  %t384 = load ptr, ptr %l1, !tbaa !29
  %t386 = getelementptr { i64, [3 x i64] }, ptr %t384, i32 0, i32 1
  %t387 = getelementptr { %"compiler/source:Span", ptr }, ptr %t386, i32 0, i32 1
  %t388 = load ptr, ptr %t387
  store ptr %t388, ptr %l23, !tbaa !29
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t390, ptr %t391)
  br label %bb110
bb110:
  br label %bb151
bb111:
  %t395 = load ptr, ptr %l1, !tbaa !29
  store ptr %t395, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t396 = load ptr, ptr %l204, !tbaa !29
  %t397 = icmp ne ptr %t396, null
  br i1 %t397, label %bb112, label %bb113
bb112:
  %t399 = load ptr, ptr %l204, !tbaa !29
  %t400 = load i64, ptr %t399, !range !{i64 0, i64 17}
  %t402 = icmp eq i64 %t400, 12
  store i1 %t402, ptr %l205, !tbaa !21
  br label %bb113
bb113:
  %t403 = load i1, ptr %l205, !tbaa !21
  br i1 %t403, label %bb114, label %bb115
bb114:
  %t404 = load ptr, ptr %l1, !tbaa !29
  %t406 = getelementptr { i64, [3 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", ptr }, ptr %t406, i32 0, i32 1
  %t408 = load ptr, ptr %t407
  store ptr %t408, ptr %l24, !tbaa !29
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2elaterBlock(ptr %v0, ptr %v1, ptr %t410, ptr %t411)
  br label %bb117
bb117:
  br label %bb151
bb118:
  %t415 = load ptr, ptr %l1, !tbaa !29
  store ptr %t415, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t416 = load ptr, ptr %l213, !tbaa !29
  %t417 = icmp ne ptr %t416, null
  br i1 %t417, label %bb119, label %bb120
bb119:
  %t419 = load ptr, ptr %l213, !tbaa !29
  %t420 = load i64, ptr %t419, !range !{i64 0, i64 17}
  %t422 = icmp eq i64 %t420, 13
  store i1 %t422, ptr %l214, !tbaa !21
  br label %bb120
bb120:
  %t423 = load i1, ptr %l214, !tbaa !21
  br i1 %t423, label %bb121, label %bb122
bb121:
  %t424 = load ptr, ptr %l1, !tbaa !29
  %t426 = getelementptr { i64, [3 x i64] }, ptr %t424, i32 0, i32 1
  %t427 = getelementptr { %"compiler/source:Span", ptr }, ptr %t426, i32 0, i32 1
  %t428 = load ptr, ptr %t427
  store ptr %t428, ptr %l25, !tbaa !29
  br label %bb123
bb122:
  br label %bb126
bb123:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load ptr, ptr %l25, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Join", ptr %t431, i32 0, i32 0
  %t434 = load ptr, ptr %t433, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t430, ptr %t434)
  br label %bb124
bb124:
  %t438 = load ptr, ptr %l0, !tbaa !29
  store ptr %t438, ptr %l223, !tbaa !29
  %t439 = load ptr, ptr %l223, !tbaa !29
  %t440 = getelementptr %"compiler/typed:Landings", ptr %t439, i32 0, i32 10
  %t441 = load i64, ptr %t440, !tbaa !24
  %t443 = add i64 %t441, 1
  %t445 = load ptr, ptr %l223, !tbaa !29
  %t446 = getelementptr %"compiler/typed:Landings", ptr %t445, i32 0, i32 10
  store i64 %t443, ptr %t446, !tbaa !24
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load ptr, ptr %l25, !tbaa !29
  %t450 = getelementptr %"compiler/typed:Join", ptr %t448, i32 0, i32 2
  %t451 = load { i64, ptr }, ptr %t450, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eclauses(ptr %v0, ptr %v1, ptr %t447, { i64, ptr } %t451)
  br label %bb125
bb125:
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l229, !tbaa !29
  %t455 = load ptr, ptr %l229, !tbaa !29
  %t456 = getelementptr %"compiler/typed:Landings", ptr %t455, i32 0, i32 10
  %t457 = load i64, ptr %t456, !tbaa !24
  %t459 = sub i64 %t457, 1
  %t461 = load ptr, ptr %l229, !tbaa !29
  %t462 = getelementptr %"compiler/typed:Landings", ptr %t461, i32 0, i32 10
  store i64 %t459, ptr %t462, !tbaa !24
  br label %bb151
bb126:
  %t463 = load ptr, ptr %l1, !tbaa !29
  store ptr %t463, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t464 = load ptr, ptr %l232, !tbaa !29
  %t465 = icmp ne ptr %t464, null
  br i1 %t465, label %bb127, label %bb128
bb127:
  %t467 = load ptr, ptr %l232, !tbaa !29
  %t468 = load i64, ptr %t467, !range !{i64 0, i64 17}
  %t470 = icmp eq i64 %t468, 14
  store i1 %t470, ptr %l233, !tbaa !21
  br label %bb128
bb128:
  %t471 = load i1, ptr %l233, !tbaa !21
  br i1 %t471, label %bb129, label %bb130
bb129:
  %t472 = load ptr, ptr %l1, !tbaa !29
  %t474 = getelementptr { i64, [3 x i64] }, ptr %t472, i32 0, i32 1
  %t475 = getelementptr { %"compiler/source:Span", ptr }, ptr %t474, i32 0, i32 1
  %t476 = load ptr, ptr %t475
  store ptr %t476, ptr %l26, !tbaa !29
  br label %bb131
bb130:
  br label %bb150
bb131:
  %t478 = load ptr, ptr %l0, !tbaa !29
  store ptr %t478, ptr %l238, !tbaa !29
  %t479 = load ptr, ptr %l238, !tbaa !29
  %t480 = getelementptr %"compiler/typed:Landings", ptr %t479, i32 0, i32 10
  %t481 = load i64, ptr %t480, !tbaa !24
  %t483 = add i64 %t481, 1
  %t485 = load ptr, ptr %l238, !tbaa !29
  %t486 = getelementptr %"compiler/typed:Landings", ptr %t485, i32 0, i32 10
  store i64 %t483, ptr %t486, !tbaa !24
  %t487 = load ptr, ptr %l26, !tbaa !29
  %t489 = getelementptr %"compiler/typed:Spawn", ptr %t487, i32 0, i32 0
  %t490 = load { i64, ptr }, ptr %t489, !tbaa !27
  store { i64, ptr } %t490, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t492 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t492, 0
  store i64 %t494, ptr %l29, !tbaa !24
  br label %bb132
bb132:
  %t496 = load i64, ptr %l28, !tbaa !24
  %t497 = load i64, ptr %l29, !tbaa !24
  %t500 = icmp slt i64 %t496, %t497
  %t502 = xor i1 %t500, true
  br i1 %t502, label %bb133, label %bb134
bb133:
  br label %bb141
bb134:
  br label %bb135
bb135:
  %t504 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t504, ptr %l249, !tbaa !27
  %t505 = load i64, ptr %l28, !tbaa !24
  %t507 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !27
  %t509 = getelementptr ptr, ptr %t508, i64 %t505
  %t510 = load ptr, ptr %t509, !tbaa !39
  store ptr %t510, ptr %l30, !tbaa !29
  %t512 = load ptr, ptr %l30, !tbaa !29
  %t514 = icmp eq ptr %t512, null
  %t516 = xor i1 %t514, true
  br i1 %t516, label %bb136, label %bb137
bb136:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t518, ptr %t519)
  br label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb139
bb139:
  br label %bb140
bb140:
  %t522 = load i64, ptr %l28, !tbaa !24
  %t524 = add i64 %t522, 1
  store i64 %t524, ptr %l28, !tbaa !24
  br label %bb132
bb141:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load ptr, ptr %l26, !tbaa !29
  %t529 = getelementptr %"compiler/typed:Spawn", ptr %t527, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t526, ptr %t530)
  br label %bb142
bb142:
  %t534 = load ptr, ptr %l26, !tbaa !29
  %t536 = getelementptr %"compiler/typed:Spawn", ptr %t534, i32 0, i32 2
  %t537 = load { i64, ptr }, ptr %t536, !tbaa !27
  store { i64, ptr } %t537, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t539 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t541 = extractvalue { i64, ptr } %t539, 0
  store i64 %t541, ptr %l33, !tbaa !24
  br label %bb143
bb143:
  %t543 = load i64, ptr %l32, !tbaa !24
  %t544 = load i64, ptr %l33, !tbaa !24
  %t547 = icmp slt i64 %t543, %t544
  %t549 = xor i1 %t547, true
  br i1 %t549, label %bb144, label %bb145
bb144:
  br label %bb149
bb145:
  br label %bb146
bb146:
  %t551 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t551, ptr %l271, !tbaa !27
  %t552 = load i64, ptr %l32, !tbaa !24
  %t554 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !27
  %t556 = getelementptr ptr, ptr %t555, i64 %t552
  %t557 = load ptr, ptr %t556, !tbaa !39
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t562 = getelementptr %"compiler/typed:TaskClause", ptr %t557, i32 0, i32 3
  %t563 = load ptr, ptr %t562, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t559, ptr %t563)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t566 = load i64, ptr %l32, !tbaa !24
  %t568 = add i64 %t566, 1
  store i64 %t568, ptr %l32, !tbaa !24
  br label %bb143
bb149:
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l279, !tbaa !29
  %t571 = load ptr, ptr %l279, !tbaa !29
  %t572 = getelementptr %"compiler/typed:Landings", ptr %t571, i32 0, i32 10
  %t573 = load i64, ptr %t572, !tbaa !24
  %t575 = sub i64 %t573, 1
  %t577 = load ptr, ptr %l279, !tbaa !29
  %t578 = getelementptr %"compiler/typed:Landings", ptr %t577, i32 0, i32 10
  store i64 %t575, ptr %t578, !tbaa !24
  br label %bb151
bb150:
  call void @__olang_check_failed(ptr @olang_loc_c0d697227f379d2a_2050d061979ad5e)
  unreachable
bb151:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ewatched(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Landings", ptr %a0, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i64, ptr %t22, i64 %t19
  %t24 = load i64, ptr %t23, !tbaa !34
  %t30 = icmp eq i64 %t24, %a1
  br i1 %t30, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb1
bb9:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l82 = alloca i1
  %l87 = alloca i64
  %l91 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:LastUses", ptr %t3, i32 0, i32 6
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = load i64, ptr %l19, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb38
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l8, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:LastUses", ptr %t55, i32 0, i32 8
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l47
  br label %bb12
bb12:
  %t62 = load i64, ptr %l47, !tbaa !24
  store i64 %t62, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  br label %bb37
bb14:
  br label %bb15
bb15:
  %t69 = add i64 %a1, 1
  store i64 %t69, ptr %l10, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/typed:LastUses", ptr %t71, i32 0, i32 3
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  br i1 %t82, label %bb16, label %bb17
bb16:
  %t84 = load i64, ptr %l12, !tbaa !24
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb21
bb18:
  %t88 = load i64, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = sub i64 %t88, %t89
  %t93 = load i64, ptr %l12, !tbaa !24
  %t96 = add i64 %t92, %t93
  %t98 = sub i64 %t96, 1
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = sdiv i64 %t98, %t99
  store i64 %t102, ptr %l61, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb20
bb20:
  %t104 = load i64, ptr %l61, !tbaa !24
  store i64 %t104, ptr %l58, !tbaa !24
  br label %bb21
bb21:
  %t105 = load i64, ptr %l58, !tbaa !24
  store i64 %t105, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  %t106 = load i64, ptr %l14, !tbaa !24
  %t107 = load i64, ptr %l13, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb23, label %bb24
bb23:
  br label %bb36
bb24:
  br label %bb25
bb25:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l14, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = mul i64 %t115, %t116
  %t122 = add i64 %t114, %t119
  store i64 %t122, ptr %l15, !tbaa !24
  %t124 = load i64, ptr %l15, !tbaa !24
  %t125 = load i64, ptr %l9, !tbaa !24
  %t128 = icmp ne i64 %t124, %t125
  br i1 %t128, label %bb26, label %bb27
bb26:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/typed:LastUses", ptr %t130, i32 0, i32 9
  %t133 = load i64, ptr %l15, !tbaa !24
  %t135 = sub i64 %t133, 1
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t132, i64 %t135)
  store i64 %t138, ptr %l87
  br label %bb28
bb27:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb30
bb28:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/typed:LastUses", ptr %t139, i32 0, i32 7
  %t142 = load i64, ptr %l8, !tbaa !24
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t141, i64 %t142)
  store i64 %t145, ptr %l91
  br label %bb29
bb29:
  %t146 = load i64, ptr %l87, !tbaa !24
  %t147 = load i64, ptr %l91, !tbaa !24
  %t148 = icmp eq i64 %t146, %t147
  store i1 %t148, ptr %l82, !tbaa !21
  br label %bb30
bb30:
  %t150 = load i1, ptr %l82, !tbaa !21
  br i1 %t150, label %bb31, label %bb32
bb31:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/typed:LastUses", ptr %t151, i32 0, i32 8
  %t154 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t153, i64 %t154, i64 -1)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t157 = load i64, ptr %l14, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l14, !tbaa !24
  br label %bb22
bb36:
  br label %bb37
bb37:
  %t161 = load i64, ptr %l7, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l7, !tbaa !24
  br label %bb8
bb38:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Alt", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb7, label %bb8
bb7:
  br label %bb14
bb8:
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  store ptr %t57, ptr %l9, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l9, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Bind", ptr %t60, i32 0, i32 0
  %t63 = load i32, ptr %t62, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2edeclare(ptr %v0, ptr %t59, i32 %t63)
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l9, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Bind", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t66, ptr %t70)
  br label %bb11
bb11:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l9, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Bind", ptr %t75, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %t74, i32 %t78)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l7, !tbaa !24
  br label %bb6
bb14:
  br label %bb15
bb15:
  %t85 = load i64, ptr %l3, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Arm", ptr %t90, i32 0, i32 2
  %t93 = load ptr, ptr %t92, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t89, ptr %t93)
  br label %bb17
bb17:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Arm", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t96, ptr %t100)
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Arm", ptr %t104, i32 0, i32 4
  %t107 = load ptr, ptr %t106, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t103, ptr %t107)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb8
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Clause", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Clause", ptr %t31, i32 0, i32 4
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t30, { i64, ptr } %t34)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb1
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2ecopyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca i1
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l45 = alloca i1
  %l49 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l56 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Make", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !range !{i32 0, i32 5}
  %t6 = trunc i64 4 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Make", ptr %t11, i32 0, i32 2
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp ne i64 %t16, 1
  store i1 %t18, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Make", ptr %t21, i32 0, i32 4
  %t24 = load i32, ptr %t23, !tbaa !23
  %t26 = icmp slt i32 %t24, 0
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Make", ptr %t29, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l18, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 0
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = call i64 @compiler_2ftyped_2ewholeLocal(ptr %v1, ptr %t36)
  store i64 %t38, ptr %l20
  br label %bb10
bb10:
  %t39 = load i64, ptr %l20, !tbaa !24
  store i64 %t39, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/typed:LastUses", ptr %t45, i32 0, i32 0
  %t48 = load i64, ptr %t47, !tbaa !24
  %t51 = icmp sge i64 %t44, %t48
  store i1 %t51, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t53 = load i1, ptr %l23, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %ret
bb15:
  br label %bb16
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:LastUses", ptr %t54, i32 0, i32 6
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Make", ptr %t57, i32 0, i32 4
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = sext i32 %t60 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t56, i64 %t62)
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:LastUses", ptr %t65, i32 0, i32 7
  %t68 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t67, i64 %t68)
  br label %bb18
bb18:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/typed:LastUses", ptr %t71, i32 0, i32 5
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = icmp sgt i64 %t74, 0
  br i1 %t76, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb24
bb20:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LastUses", ptr %t78, i32 0, i32 2
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = load i64, ptr %l2, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 %t82
  %t87 = load i64, ptr %t86, !tbaa !34
  %t89 = icmp sge i64 %t87, 0
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/typed:LastUses", ptr %t91, i32 0, i32 4
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:LastUses", ptr %t95, i32 0, i32 2
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l49, !tbaa !27
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i64, ptr %t102, i64 %t99
  %t104 = load i64, ptr %t103, !tbaa !34
  %t107 = icmp sgt i64 %t94, %t104
  store i1 %t107, ptr %l45, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t109 = load i1, ptr %l45, !tbaa !21
  store i1 %t109, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t110 = load i1, ptr %l39, !tbaa !21
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/typed:LastUses", ptr %t111, i32 0, i32 8
  store ptr %t113, ptr %l54, !tbaa !29
  br i1 %t110, label %bb25, label %bb26
bb25:
  store i64 -1, ptr %l56, !tbaa !24
  br label %bb27
bb26:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/typed:LastUses", ptr %t116, i32 0, i32 3
  %t119 = load i64, ptr %t118, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l56, !tbaa !24
  br label %bb27
bb27:
  %t123 = load ptr, ptr %l54, !tbaa !29
  %t124 = load i64, ptr %l56, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t123, i64 %t124)
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2edeclare(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  %t5 = icmp sge i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:LastUses", ptr %t10, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp slt i64 %t9, %t13
  store i1 %t16, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l5, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:LastUses", ptr %t19, i32 0, i32 2
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t27 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t32 = icmp slt i64 %t30, 0
  store i1 %t32, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l11, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/typed:LastUses", ptr %t35, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l19, !tbaa !27
  %t39 = load i32, ptr %l1, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/typed:LastUses", ptr %t42, i32 0, i32 4
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i64, ptr %t49, i64 %t41
  store i64 %t45, ptr %t50, !tbaa !34
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca i1
  %l12 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l31 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sext i32 %a1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:LastUses", ptr %t10, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t16 = icmp sge i64 %t9, %t13
  store i1 %t16, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = getelementptr %"compiler/typed:LastUses", ptr %t20, i32 0, i32 3
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = getelementptr %"compiler/typed:LastUses", ptr %t26, i32 0, i32 3
  store i64 %t24, ptr %t27, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:LastUses", ptr %t28, i32 0, i32 9
  %t31 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t30, i64 %t31)
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/typed:LastUses", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l19, !tbaa !27
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %l20, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/typed:LastUses", ptr %t39, i32 0, i32 5
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb8, label %bb9
bb8:
  store i64 9223372036854775807, ptr %l24, !tbaa !24
  br label %bb11
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:LastUses", ptr %t46, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l26, !tbaa !27
  %t50 = load i64, ptr %l2, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i64, ptr %t53, i64 %t50
  %t55 = load i64, ptr %t54, !tbaa !34
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/typed:LastUses", ptr %t56, i32 0, i32 3
  %t59 = load i64, ptr %t58, !tbaa !24
  %t62 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t55, i64 %t59)
  store i64 %t62, ptr %l31
  br label %bb10
bb10:
  %t63 = load i64, ptr %l31, !tbaa !24
  store i64 %t63, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t64 = load i64, ptr %l24, !tbaa !24
  %t65 = load i64, ptr %l20, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i64, ptr %t67, i64 %t65
  store i64 %t64, ptr %t68, !tbaa !34
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l119 = alloca ptr
  %l127 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  %l171 = alloca ptr
  %l177 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca i1
  %l186 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l227 = alloca ptr
  %l230 = alloca ptr
  %l231 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t2 = load ptr, ptr %l25, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l25, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l26, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l26, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2edeclare(ptr %v0, ptr %t22, i32 %t23)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %t31, i32 %t32)
  br label %bb8
bb8:
  br label %bb129
bb9:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t36 = load ptr, ptr %l40, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l40, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 17}
  %t42 = icmp eq i64 %t40, 1
  store i1 %t42, ptr %l41, !tbaa !21
  br label %bb11
bb11:
  %t43 = load i1, ptr %l41, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l5, !tbaa !29
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t56, ptr %t57)
  br label %bb15
bb15:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  br label %bb16
bb16:
  br label %bb129
bb17:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t66 = load ptr, ptr %l53, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l53, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 17}
  %t72 = icmp eq i64 %t70, 2
  store i1 %t72, ptr %l54, !tbaa !21
  br label %bb19
bb19:
  %t73 = load i1, ptr %l54, !tbaa !21
  br i1 %t73, label %bb20, label %bb21
bb20:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l6, !tbaa !29
  br label %bb30
bb21:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t81 = load ptr, ptr %l59, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l59, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 17}
  %t87 = icmp eq i64 %t85, 15
  store i1 %t87, ptr %l60, !tbaa !21
  br label %bb23
bb23:
  %t88 = load i1, ptr %l60, !tbaa !21
  br i1 %t88, label %bb24, label %bb25
bb24:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l6, !tbaa !29
  br label %bb30
bb25:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t96 = load ptr, ptr %l65, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb26, label %bb27
bb26:
  %t99 = load ptr, ptr %l65, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 17}
  %t102 = icmp eq i64 %t100, 8
  store i1 %t102, ptr %l66, !tbaa !21
  br label %bb27
bb27:
  %t103 = load i1, ptr %l66, !tbaa !21
  br i1 %t103, label %bb28, label %bb29
bb28:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [3 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t106, i32 0, i32 1
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  br label %bb31
bb31:
  br label %bb129
bb32:
  %t115 = load ptr, ptr %l1, !tbaa !29
  store ptr %t115, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t116 = load ptr, ptr %l74, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb33, label %bb34
bb33:
  %t119 = load ptr, ptr %l74, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 17}
  %t122 = icmp eq i64 %t120, 6
  store i1 %t122, ptr %l75, !tbaa !21
  br label %bb34
bb34:
  %t123 = load i1, ptr %l75, !tbaa !21
  br i1 %t123, label %bb35, label %bb36
bb35:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", ptr }, ptr %t126, i32 0, i32 1
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l7, !tbaa !29
  br label %bb45
bb36:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t131 = load ptr, ptr %l80, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb37, label %bb38
bb37:
  %t134 = load ptr, ptr %l80, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 17}
  %t137 = icmp eq i64 %t135, 16
  store i1 %t137, ptr %l81, !tbaa !21
  br label %bb38
bb38:
  %t138 = load i1, ptr %l81, !tbaa !21
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [3 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", ptr }, ptr %t141, i32 0, i32 1
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l7, !tbaa !29
  br label %bb45
bb40:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t146 = load ptr, ptr %l86, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb41, label %bb42
bb41:
  %t149 = load ptr, ptr %l86, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 17}
  %t152 = icmp eq i64 %t150, 9
  store i1 %t152, ptr %l87, !tbaa !21
  br label %bb42
bb42:
  %t153 = load i1, ptr %l87, !tbaa !21
  br i1 %t153, label %bb43, label %bb44
bb43:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [3 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l7, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t160, ptr %t161)
  br label %bb46
bb46:
  br label %bb129
bb47:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t165 = load ptr, ptr %l94, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb48, label %bb49
bb48:
  %t168 = load ptr, ptr %l94, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 17}
  %t171 = icmp eq i64 %t169, 3
  store i1 %t171, ptr %l95, !tbaa !21
  br label %bb49
bb49:
  %t172 = load i1, ptr %l95, !tbaa !21
  br i1 %t172, label %bb50, label %bb51
bb50:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l8, !tbaa !29
  br label %bb52
bb51:
  br label %bb56
bb52:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l8, !tbaa !29
  %t182 = getelementptr %"compiler/typed:If", ptr %t180, i32 0, i32 0
  %t183 = load ptr, ptr %t182, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t179, ptr %t183)
  br label %bb53
bb53:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l8, !tbaa !29
  %t190 = getelementptr %"compiler/typed:If", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t187, ptr %t191)
  br label %bb54
bb54:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l8, !tbaa !29
  %t198 = getelementptr %"compiler/typed:If", ptr %t196, i32 0, i32 2
  %t199 = load ptr, ptr %t198, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t195, ptr %t199)
  br label %bb55
bb55:
  br label %bb129
bb56:
  %t202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t202, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t203 = load ptr, ptr %l111, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb57, label %bb58
bb57:
  %t206 = load ptr, ptr %l111, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 4
  store i1 %t209, ptr %l112, !tbaa !21
  br label %bb58
bb58:
  %t210 = load i1, ptr %l112, !tbaa !21
  br i1 %t210, label %bb59, label %bb60
bb59:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l9, !tbaa !29
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr { i64, [3 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t219, i32 0, i32 2
  %t221 = load ptr, ptr %t220
  store ptr %t221, ptr %l10, !tbaa !29
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l119, !tbaa !29
  %t224 = load ptr, ptr %l119, !tbaa !29
  %t225 = getelementptr %"compiler/typed:LastUses", ptr %t224, i32 0, i32 4
  %t226 = load i64, ptr %t225, !tbaa !24
  %t228 = add i64 %t226, 1
  %t230 = load ptr, ptr %l119, !tbaa !29
  %t231 = getelementptr %"compiler/typed:LastUses", ptr %t230, i32 0, i32 4
  store i64 %t228, ptr %t231, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t232, ptr %t233)
  br label %bb62
bb62:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t237, ptr %t238)
  br label %bb63
bb63:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l127, !tbaa !29
  %t242 = load ptr, ptr %l127, !tbaa !29
  %t243 = getelementptr %"compiler/typed:LastUses", ptr %t242, i32 0, i32 4
  %t244 = load i64, ptr %t243, !tbaa !24
  %t246 = sub i64 %t244, 1
  %t248 = load ptr, ptr %l127, !tbaa !29
  %t249 = getelementptr %"compiler/typed:LastUses", ptr %t248, i32 0, i32 4
  store i64 %t246, ptr %t249, !tbaa !24
  br label %bb129
bb64:
  %t250 = load ptr, ptr %l1, !tbaa !29
  store ptr %t250, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t251 = load ptr, ptr %l130, !tbaa !29
  %t252 = icmp ne ptr %t251, null
  br i1 %t252, label %bb65, label %bb66
bb65:
  %t254 = load ptr, ptr %l130, !tbaa !29
  %t255 = load i64, ptr %t254, !range !{i64 0, i64 17}
  %t257 = icmp eq i64 %t255, 10
  store i1 %t257, ptr %l131, !tbaa !21
  br label %bb66
bb66:
  %t258 = load i1, ptr %l131, !tbaa !21
  br i1 %t258, label %bb67, label %bb68
bb67:
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr { i64, [3 x i64] }, ptr %t259, i32 0, i32 1
  %t262 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t261, i32 0, i32 1
  %t263 = load ptr, ptr %t262
  store ptr %t263, ptr %l11, !tbaa !29
  %t265 = load ptr, ptr %l1, !tbaa !29
  %t267 = getelementptr { i64, [3 x i64] }, ptr %t265, i32 0, i32 1
  %t268 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t267, i32 0, i32 2
  %t269 = load ptr, ptr %t268
  store ptr %t269, ptr %l12, !tbaa !29
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t271, ptr %t272)
  br label %bb70
bb70:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t276, ptr %t277)
  br label %bb71
bb71:
  br label %bb129
bb72:
  %t280 = load ptr, ptr %l1, !tbaa !29
  store ptr %t280, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t281 = load ptr, ptr %l143, !tbaa !29
  %t282 = icmp ne ptr %t281, null
  br i1 %t282, label %bb73, label %bb74
bb73:
  %t284 = load ptr, ptr %l143, !tbaa !29
  %t285 = load i64, ptr %t284, !range !{i64 0, i64 17}
  %t287 = icmp eq i64 %t285, 11
  store i1 %t287, ptr %l144, !tbaa !21
  br label %bb74
bb74:
  %t288 = load i1, ptr %l144, !tbaa !21
  br i1 %t288, label %bb75, label %bb76
bb75:
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr { i64, [3 x i64] }, ptr %t289, i32 0, i32 1
  %t292 = getelementptr { %"compiler/source:Span", ptr }, ptr %t291, i32 0, i32 1
  %t293 = load ptr, ptr %t292
  store ptr %t293, ptr %l13, !tbaa !29
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t295, ptr %t296)
  br label %bb78
bb78:
  br label %bb129
bb79:
  %t300 = load ptr, ptr %l1, !tbaa !29
  store ptr %t300, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t301 = load ptr, ptr %l152, !tbaa !29
  %t302 = icmp ne ptr %t301, null
  br i1 %t302, label %bb80, label %bb81
bb80:
  %t304 = load ptr, ptr %l152, !tbaa !29
  %t305 = load i64, ptr %t304, !range !{i64 0, i64 17}
  %t307 = icmp eq i64 %t305, 12
  store i1 %t307, ptr %l153, !tbaa !21
  br label %bb81
bb81:
  %t308 = load i1, ptr %l153, !tbaa !21
  br i1 %t308, label %bb82, label %bb83
bb82:
  %t309 = load ptr, ptr %l1, !tbaa !29
  %t311 = getelementptr { i64, [3 x i64] }, ptr %t309, i32 0, i32 1
  %t312 = getelementptr { %"compiler/source:Span", ptr }, ptr %t311, i32 0, i32 1
  %t313 = load ptr, ptr %t312
  store ptr %t313, ptr %l14, !tbaa !29
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2elaterBlock(ptr %v0, ptr %v1, ptr %t315, ptr %t316)
  br label %bb85
bb85:
  br label %bb129
bb86:
  %t320 = load ptr, ptr %l1, !tbaa !29
  store ptr %t320, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t321 = load ptr, ptr %l161, !tbaa !29
  %t322 = icmp ne ptr %t321, null
  br i1 %t322, label %bb87, label %bb88
bb87:
  %t324 = load ptr, ptr %l161, !tbaa !29
  %t325 = load i64, ptr %t324, !range !{i64 0, i64 17}
  %t327 = icmp eq i64 %t325, 13
  store i1 %t327, ptr %l162, !tbaa !21
  br label %bb88
bb88:
  %t328 = load i1, ptr %l162, !tbaa !21
  br i1 %t328, label %bb89, label %bb90
bb89:
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t331 = getelementptr { i64, [3 x i64] }, ptr %t329, i32 0, i32 1
  %t332 = getelementptr { %"compiler/source:Span", ptr }, ptr %t331, i32 0, i32 1
  %t333 = load ptr, ptr %t332
  store ptr %t333, ptr %l15, !tbaa !29
  br label %bb91
bb90:
  br label %bb94
bb91:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l15, !tbaa !29
  %t338 = getelementptr %"compiler/typed:Join", ptr %t336, i32 0, i32 0
  %t339 = load ptr, ptr %t338, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t335, ptr %t339)
  br label %bb92
bb92:
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l171, !tbaa !29
  %t344 = load ptr, ptr %l171, !tbaa !29
  %t345 = getelementptr %"compiler/typed:LastUses", ptr %t344, i32 0, i32 5
  %t346 = load i64, ptr %t345, !tbaa !24
  %t348 = add i64 %t346, 1
  %t350 = load ptr, ptr %l171, !tbaa !29
  %t351 = getelementptr %"compiler/typed:LastUses", ptr %t350, i32 0, i32 5
  store i64 %t348, ptr %t351, !tbaa !24
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l15, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Join", ptr %t353, i32 0, i32 2
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %t352, { i64, ptr } %t356)
  br label %bb93
bb93:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l177, !tbaa !29
  %t360 = load ptr, ptr %l177, !tbaa !29
  %t361 = getelementptr %"compiler/typed:LastUses", ptr %t360, i32 0, i32 5
  %t362 = load i64, ptr %t361, !tbaa !24
  %t364 = sub i64 %t362, 1
  %t366 = load ptr, ptr %l177, !tbaa !29
  %t367 = getelementptr %"compiler/typed:LastUses", ptr %t366, i32 0, i32 5
  store i64 %t364, ptr %t367, !tbaa !24
  br label %bb129
bb94:
  %t368 = load ptr, ptr %l1, !tbaa !29
  store ptr %t368, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t369 = load ptr, ptr %l180, !tbaa !29
  %t370 = icmp ne ptr %t369, null
  br i1 %t370, label %bb95, label %bb96
bb95:
  %t372 = load ptr, ptr %l180, !tbaa !29
  %t373 = load i64, ptr %t372, !range !{i64 0, i64 17}
  %t375 = icmp eq i64 %t373, 14
  store i1 %t375, ptr %l181, !tbaa !21
  br label %bb96
bb96:
  %t376 = load i1, ptr %l181, !tbaa !21
  br i1 %t376, label %bb97, label %bb98
bb97:
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr { i64, [3 x i64] }, ptr %t377, i32 0, i32 1
  %t380 = getelementptr { %"compiler/source:Span", ptr }, ptr %t379, i32 0, i32 1
  %t381 = load ptr, ptr %t380
  store ptr %t381, ptr %l16, !tbaa !29
  br label %bb99
bb98:
  br label %bb118
bb99:
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l186, !tbaa !29
  %t384 = load ptr, ptr %l186, !tbaa !29
  %t385 = getelementptr %"compiler/typed:LastUses", ptr %t384, i32 0, i32 5
  %t386 = load i64, ptr %t385, !tbaa !24
  %t388 = add i64 %t386, 1
  %t390 = load ptr, ptr %l186, !tbaa !29
  %t391 = getelementptr %"compiler/typed:LastUses", ptr %t390, i32 0, i32 5
  store i64 %t388, ptr %t391, !tbaa !24
  %t392 = load ptr, ptr %l16, !tbaa !29
  %t394 = getelementptr %"compiler/typed:Spawn", ptr %t392, i32 0, i32 0
  %t395 = load { i64, ptr }, ptr %t394, !tbaa !27
  store { i64, ptr } %t395, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t397 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t399 = extractvalue { i64, ptr } %t397, 0
  store i64 %t399, ptr %l19, !tbaa !24
  br label %bb100
bb100:
  %t401 = load i64, ptr %l18, !tbaa !24
  %t402 = load i64, ptr %l19, !tbaa !24
  %t405 = icmp slt i64 %t401, %t402
  %t407 = xor i1 %t405, true
  br i1 %t407, label %bb101, label %bb102
bb101:
  br label %bb109
bb102:
  br label %bb103
bb103:
  %t409 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t409, ptr %l197, !tbaa !27
  %t410 = load i64, ptr %l18, !tbaa !24
  %t412 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr ptr, ptr %t413, i64 %t410
  %t415 = load ptr, ptr %t414, !tbaa !39
  store ptr %t415, ptr %l20, !tbaa !29
  %t417 = load ptr, ptr %l20, !tbaa !29
  %t419 = icmp eq ptr %t417, null
  %t421 = xor i1 %t419, true
  br i1 %t421, label %bb104, label %bb105
bb104:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t423, ptr %t424)
  br label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t427 = load i64, ptr %l18, !tbaa !24
  %t429 = add i64 %t427, 1
  store i64 %t429, ptr %l18, !tbaa !24
  br label %bb100
bb109:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load ptr, ptr %l16, !tbaa !29
  %t434 = getelementptr %"compiler/typed:Spawn", ptr %t432, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t431, ptr %t435)
  br label %bb110
bb110:
  %t439 = load ptr, ptr %l16, !tbaa !29
  %t441 = getelementptr %"compiler/typed:Spawn", ptr %t439, i32 0, i32 2
  %t442 = load { i64, ptr }, ptr %t441, !tbaa !27
  store { i64, ptr } %t442, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t444 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t444, 0
  store i64 %t446, ptr %l23, !tbaa !24
  br label %bb111
bb111:
  %t448 = load i64, ptr %l22, !tbaa !24
  %t449 = load i64, ptr %l23, !tbaa !24
  %t452 = icmp slt i64 %t448, %t449
  %t454 = xor i1 %t452, true
  br i1 %t454, label %bb112, label %bb113
bb112:
  br label %bb117
bb113:
  br label %bb114
bb114:
  %t456 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t456, ptr %l219, !tbaa !27
  %t457 = load i64, ptr %l22, !tbaa !24
  %t459 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t460 = load ptr, ptr %t459, !tbaa !27
  %t461 = getelementptr ptr, ptr %t460, i64 %t457
  %t462 = load ptr, ptr %t461, !tbaa !39
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/typed:TaskClause", ptr %t462, i32 0, i32 3
  %t468 = load ptr, ptr %t467, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t464, ptr %t468)
  br label %bb115
bb115:
  br label %bb116
bb116:
  %t471 = load i64, ptr %l22, !tbaa !24
  %t473 = add i64 %t471, 1
  store i64 %t473, ptr %l22, !tbaa !24
  br label %bb111
bb117:
  %t475 = load ptr, ptr %l0, !tbaa !29
  store ptr %t475, ptr %l227, !tbaa !29
  %t476 = load ptr, ptr %l227, !tbaa !29
  %t477 = getelementptr %"compiler/typed:LastUses", ptr %t476, i32 0, i32 5
  %t478 = load i64, ptr %t477, !tbaa !24
  %t480 = sub i64 %t478, 1
  %t482 = load ptr, ptr %l227, !tbaa !29
  %t483 = getelementptr %"compiler/typed:LastUses", ptr %t482, i32 0, i32 5
  store i64 %t480, ptr %t483, !tbaa !24
  br label %bb129
bb118:
  %t484 = load ptr, ptr %l1, !tbaa !29
  store ptr %t484, ptr %l230, !tbaa !29
  store i1 false, ptr %l231, !tbaa !21
  %t485 = load ptr, ptr %l230, !tbaa !29
  %t486 = icmp ne ptr %t485, null
  br i1 %t486, label %bb119, label %bb120
bb119:
  %t488 = load ptr, ptr %l230, !tbaa !29
  %t489 = load i64, ptr %t488, !range !{i64 0, i64 17}
  %t491 = icmp eq i64 %t489, 5
  store i1 %t491, ptr %l231, !tbaa !21
  br label %bb120
bb120:
  %t492 = load i1, ptr %l231, !tbaa !21
  br i1 %t492, label %bb121, label %bb122
bb121:
  br label %bb127
bb122:
  %t493 = load ptr, ptr %l1, !tbaa !29
  store ptr %t493, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t494 = load ptr, ptr %l234, !tbaa !29
  %t495 = icmp ne ptr %t494, null
  br i1 %t495, label %bb123, label %bb124
bb123:
  %t497 = load ptr, ptr %l234, !tbaa !29
  %t498 = load i64, ptr %t497, !range !{i64 0, i64 17}
  %t500 = icmp eq i64 %t498, 7
  store i1 %t500, ptr %l235, !tbaa !21
  br label %bb124
bb124:
  %t501 = load i1, ptr %l235, !tbaa !21
  br i1 %t501, label %bb125, label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  call void @__olang_check_failed(ptr @olang_loc_b7d0c4ef23cb16fa_bb49bf88955879a6)
  unreachable
bb129:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l36 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  store i64 %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t16 = load ptr, ptr %l15, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l15, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 8}
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l16, !tbaa !21
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l4
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l5, !tbaa !23
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l6, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:LocalUses", ptr %t43, i32 0, i32 4
  %t46 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t45, i64 %t46, i1 true)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %ret
bb11:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = icmp sge i64 %t49, 0
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb14:
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 8}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l32, !tbaa !21
  %t62 = xor i1 %t61, true
  store i1 %t62, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l30, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:LocalUses", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l38, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t69)
  store i32 %t71, ptr %l40
  br label %bb19
bb18:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb21
bb19:
  %t72 = load ptr, ptr @__olang_prog_scope
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = load i32, ptr %l40, !tbaa !23
  %t75 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t72, ptr %t73, i32 %t74)
  store i1 %t75, ptr %l41
  br label %bb20
bb20:
  %t76 = load i1, ptr %l41, !tbaa !21
  %t77 = xor i1 %t76, true
  store i1 %t77, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t79 = load i1, ptr %l36, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t84 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  store i1 %t84, ptr %l46
  br label %bb24
bb23:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb25
bb24:
  %t85 = load i1, ptr %l46, !tbaa !21
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %l43, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l43, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/typed:LocalUses", ptr %t89, i32 0, i32 10
  %t92 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t91, i64 %t92)
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:LocalUses", ptr %t95, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t97, ptr %a2)
  br label %bb29
bb29:
  br label %ret
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %t101, ptr %t102, i1 false)
  br label %bb31
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l22 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:LocalUses", ptr %t5, i32 0, i32 24
  %t8 = load i32, ptr %t7, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Block", ptr %t11, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t17 = getelementptr %"compiler/typed:LocalUses", ptr %t10, i32 0, i32 24
  store i32 %t14, ptr %t17, !tbaa !23
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Block", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l22, !tbaa !27
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 %t36
  %t41 = load ptr, ptr %t40, !tbaa !39
  %t43 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %t43, ptr %t41)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = getelementptr %"compiler/typed:LocalUses", ptr %t51, i32 0, i32 24
  store i32 %t52, ptr %t55, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eborrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [1 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, [1 x i64] }
  %l7 = alloca i64
  %l21 = alloca i1
  %t30 = alloca { i64, [1 x i64] }, align 8
  %t47 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [1 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load ptr, ptr @__olang_prog_scope
  %t9 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t6, ptr %t4, i32 %a2)
  store i64 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t11 = load i64, ptr %l7, !tbaa !24
  %t13 = and i64 %t11, %t10
  %t15 = icmp ne i64 %t13, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %t17, ptr %t18, i1 true)
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t21 = load { i64, [1 x i64] }, ptr %l3
  %t23 = extractvalue { i64, [1 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 1
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [1 x i64] }, ptr %t30, i32 0, i32 0
  store i64 5, ptr %t31
  %t32 = load { i64, [1 x i64] }, ptr %t30
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2euse(ptr %v0, ptr %v1, ptr %t28, ptr %t29, { i64, [1 x i64] } %t32, i1 true)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %ret
bb9:
  %t36 = load { i64, [1 x i64] }, ptr %l3
  %t38 = extractvalue { i64, [1 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 3
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  %t41 = load { i64, [1 x i64] }, ptr %l3
  %t43 = extractvalue { i64, [1 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 2
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store { i64, [1 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [1 x i64] }, ptr %t47, i32 0, i32 0
  store i64 5, ptr %t48
  %t49 = load { i64, [1 x i64] }, ptr %t47
  store { i64, [1 x i64] } %t49, ptr %l3
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t53 = load { i64, [1 x i64] }, ptr %l3
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2euse(ptr %v0, ptr %v1, ptr %t51, ptr %t52, { i64, [1 x i64] } %t53, i1 true)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eescape(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4, i1 true)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:LocalUses", ptr %t7, i32 0, i32 6
  %t10 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t9, i64 %t10, i1 true)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [1 x i64] }
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l51 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca { i64, [1 x i64] }
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l113 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l118 = alloca ptr
  %l122 = alloca { i64, [1 x i64] }
  %l131 = alloca ptr
  %l132 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca i1
  %l227 = alloca { i64, ptr }
  %l239 = alloca ptr
  %l246 = alloca ptr
  %l247 = alloca i1
  %l260 = alloca ptr
  %l261 = alloca i1
  %l268 = alloca ptr
  %l269 = alloca i1
  %l277 = alloca ptr
  %l278 = alloca i1
  %t217 = alloca { i64, [1 x i64] }, align 8
  %t233 = alloca { i64, [1 x i64] }, align 8
  %t259 = alloca { i64, [1 x i64] }, align 8
  %t332 = alloca { i64, [1 x i64] }, align 8
  %t344 = alloca { i64, [1 x i64] }, align 8
  %t371 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [1 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t6 = load ptr, ptr %l32, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l32, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l33, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l33, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t15 = load ptr, ptr %l36, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l36, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l37, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l37, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb162
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t24 = load ptr, ptr %l40, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l40, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l41, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l41, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 1
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb25
bb18:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/typed:LocalUses", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i32, ptr %l3, !tbaa !23
  %t49 = load ptr, ptr @__olang_prog_scope
  %t52 = call i1 @compiler_2ftyped_2escalarType(ptr %t49, ptr %t47, i32 %t48)
  store i1 %t52, ptr %l51
  br label %bb19
bb19:
  %t53 = load i1, ptr %l51, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l53, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  store ptr %t57, ptr %l54, !tbaa !29
  %t58 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t58, ptr %l55
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:LocalUses", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i32, ptr %l3, !tbaa !23
  %t64 = load ptr, ptr @__olang_prog_scope
  %t67 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t64, ptr %t62, i32 %t63)
  store i1 %t67, ptr %l59
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t68 = load ptr, ptr %l53, !tbaa !29
  %t69 = load ptr, ptr %l54, !tbaa !29
  %t70 = load { i64, [1 x i64] }, ptr %l55
  %t71 = load i1, ptr %l59, !tbaa !21
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2euse(ptr %v0, ptr %v1, ptr %t68, ptr %t69, { i64, [1 x i64] } %t70, i1 %t71)
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %bb162
bb25:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t73 = load ptr, ptr %l60, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb26, label %bb27
bb26:
  %t76 = load ptr, ptr %l60, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 3
  store i1 %t79, ptr %l61, !tbaa !21
  br label %bb27
bb27:
  %t80 = load i1, ptr %l61, !tbaa !21
  br i1 %t80, label %bb28, label %bb29
bb28:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l5, !tbaa !23
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l6, !tbaa !29
  %t95 = load i32, ptr %l5, !tbaa !23
  %t96 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eborrow(ptr %v0, ptr %v1, ptr %t93, ptr %t94, i32 %t95, { i64, [1 x i64] } %t96)
  br label %bb31
bb31:
  br label %bb162
bb32:
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t102 = load ptr, ptr %l72, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb33, label %bb34
bb33:
  %t105 = load ptr, ptr %l72, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 18}
  %t108 = icmp eq i64 %t106, 4
  store i1 %t108, ptr %l73, !tbaa !21
  br label %bb34
bb34:
  %t109 = load i1, ptr %l73, !tbaa !21
  br i1 %t109, label %bb35, label %bb36
bb35:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t112, i32 0, i32 2
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %t116, ptr %t117, i1 false)
  br label %bb38
bb38:
  br label %bb162
bb39:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t121 = load ptr, ptr %l80, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb40, label %bb41
bb40:
  %t124 = load ptr, ptr %l80, !tbaa !29
  %t125 = load i64, ptr %t124, !range !{i64 0, i64 18}
  %t127 = icmp eq i64 %t125, 5
  store i1 %t127, ptr %l81, !tbaa !21
  br label %bb41
bb41:
  %t128 = load i1, ptr %l81, !tbaa !21
  br i1 %t128, label %bb42, label %bb43
bb42:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [5 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t131, i32 0, i32 2
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l8, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l8, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Promote", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t135, ptr %t139, { i64, [1 x i64] } %t141)
  br label %bb45
bb45:
  br label %bb162
bb46:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t146 = load ptr, ptr %l91, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb47, label %bb48
bb47:
  %t149 = load ptr, ptr %l91, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 18}
  %t152 = icmp eq i64 %t150, 6
  store i1 %t152, ptr %l92, !tbaa !21
  br label %bb48
bb48:
  %t153 = load i1, ptr %l92, !tbaa !21
  br i1 %t153, label %bb49, label %bb50
bb49:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l9, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecall(ptr %v0, ptr %v1, ptr %t160, ptr %t161)
  br label %bb52
bb52:
  br label %bb162
bb53:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t165 = load ptr, ptr %l99, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb54, label %bb55
bb54:
  %t168 = load ptr, ptr %l99, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 18}
  %t171 = icmp eq i64 %t169, 7
  store i1 %t171, ptr %l100, !tbaa !21
  br label %bb55
bb55:
  %t172 = load i1, ptr %l100, !tbaa !21
  br i1 %t172, label %bb56, label %bb57
bb56:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t175, i32 0, i32 2
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l10, !tbaa !29
  br label %bb58
bb57:
  br label %bb70
bb58:
  %t179 = load ptr, ptr %l10, !tbaa !29
  %t181 = getelementptr %"compiler/typed:Make", ptr %t179, i32 0, i32 2
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  store { i64, ptr } %t182, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 0
  store i64 %t186, ptr %l13, !tbaa !24
  br label %bb59
bb59:
  %t188 = load i64, ptr %l12, !tbaa !24
  %t189 = load i64, ptr %l13, !tbaa !24
  %t192 = icmp slt i64 %t188, %t189
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb60, label %bb61
bb60:
  br label %bb68
bb61:
  br label %bb62
bb62:
  %t196 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t196, ptr %l113, !tbaa !27
  %t197 = load i64, ptr %l12, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr ptr, ptr %t200, i64 %t197
  %t202 = load ptr, ptr %t201, !tbaa !39
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l116, !tbaa !29
  store ptr %t202, ptr %l118, !tbaa !29
  %t207 = load ptr, ptr %l10, !tbaa !29
  %t209 = getelementptr %"compiler/typed:Make", ptr %t207, i32 0, i32 0
  %t210 = load i32, ptr %t209, !range !{i32 0, i32 5}
  %t212 = trunc i64 0 to i32
  %t213 = icmp eq i32 %t210, %t212
  br i1 %t213, label %bb63, label %bb64
bb63:
  %t215 = load { i64, [1 x i64] }, ptr %l2
  store { i64, [1 x i64] } %t215, ptr %l122
  br label %bb65
bb64:
  store { i64, [1 x i64] } zeroinitializer, ptr %t217
  %t218 = getelementptr { i64, [1 x i64] }, ptr %t217, i32 0, i32 0
  store i64 2, ptr %t218
  %t219 = load { i64, [1 x i64] }, ptr %t217
  store { i64, [1 x i64] } %t219, ptr %l122
  br label %bb65
bb65:
  %t221 = load ptr, ptr %l116, !tbaa !29
  %t222 = load ptr, ptr %l118, !tbaa !29
  %t223 = load { i64, [1 x i64] }, ptr %l122
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t221, ptr %t222, { i64, [1 x i64] } %t223)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t224 = load i64, ptr %l12, !tbaa !24
  %t226 = add i64 %t224, 1
  store i64 %t226, ptr %l12, !tbaa !24
  br label %bb59
bb68:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l10, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Make", ptr %t229, i32 0, i32 3
  %t232 = load ptr, ptr %t231, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t233
  %t234 = getelementptr { i64, [1 x i64] }, ptr %t233, i32 0, i32 0
  store i64 0, ptr %t234
  %t235 = load { i64, [1 x i64] }, ptr %t233
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t228, ptr %t232, { i64, [1 x i64] } %t235)
  br label %bb69
bb69:
  br label %bb162
bb70:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t240 = load ptr, ptr %l131, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb71, label %bb72
bb71:
  %t243 = load ptr, ptr %l131, !tbaa !29
  %t244 = load i64, ptr %t243, !range !{i64 0, i64 18}
  %t246 = icmp eq i64 %t244, 8
  store i1 %t246, ptr %l132, !tbaa !21
  br label %bb72
bb72:
  %t247 = load i1, ptr %l132, !tbaa !21
  br i1 %t247, label %bb73, label %bb74
bb73:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l15, !tbaa !29
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l15, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Collect", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [1 x i64] }, ptr %t259, i32 0, i32 0
  store i64 0, ptr %t260
  %t261 = load { i64, [1 x i64] }, ptr %t259
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t254, ptr %t258, { i64, [1 x i64] } %t261)
  br label %bb76
bb76:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l15, !tbaa !29
  %t268 = getelementptr %"compiler/typed:Collect", ptr %t266, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t265, ptr %t269)
  br label %bb77
bb77:
  br label %bb162
bb78:
  %t273 = load ptr, ptr %l1, !tbaa !29
  store ptr %t273, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t274 = load ptr, ptr %l145, !tbaa !29
  %t275 = icmp ne ptr %t274, null
  br i1 %t275, label %bb79, label %bb80
bb79:
  %t277 = load ptr, ptr %l145, !tbaa !29
  %t278 = load i64, ptr %t277, !range !{i64 0, i64 18}
  %t280 = icmp eq i64 %t278, 9
  store i1 %t280, ptr %l146, !tbaa !21
  br label %bb80
bb80:
  %t281 = load i1, ptr %l146, !tbaa !21
  br i1 %t281, label %bb81, label %bb82
bb81:
  %t282 = load ptr, ptr %l1, !tbaa !29
  %t284 = getelementptr { i64, [5 x i64] }, ptr %t282, i32 0, i32 1
  %t285 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t284, i32 0, i32 2
  %t286 = load i32, ptr %t285, !range !{i32 0, i32 44}
  store i32 %t286, ptr %l16
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t290, i32 0, i32 4
  %t292 = load { i64, ptr }, ptr %t291
  store { i64, ptr } %t292, ptr %l17, !tbaa !27
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i32, ptr %l16, !range !{i32 0, i32 44}
  %t296 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t297 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eprim(ptr %v0, ptr %v1, ptr %t294, i32 %t295, { i64, ptr } %t296, { i64, [1 x i64] } %t297)
  br label %bb84
bb84:
  br label %bb162
bb85:
  %t302 = load ptr, ptr %l1, !tbaa !29
  store ptr %t302, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t303 = load ptr, ptr %l157, !tbaa !29
  %t304 = icmp ne ptr %t303, null
  br i1 %t304, label %bb86, label %bb87
bb86:
  %t306 = load ptr, ptr %l157, !tbaa !29
  %t307 = load i64, ptr %t306, !range !{i64 0, i64 18}
  %t309 = icmp eq i64 %t307, 10
  store i1 %t309, ptr %l158, !tbaa !21
  br label %bb87
bb87:
  %t310 = load i1, ptr %l158, !tbaa !21
  br i1 %t310, label %bb88, label %bb89
bb88:
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t313 = getelementptr { i64, [5 x i64] }, ptr %t311, i32 0, i32 1
  %t314 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t313, i32 0, i32 2
  %t315 = load ptr, ptr %t314
  store ptr %t315, ptr %l18, !tbaa !29
  br label %bb90
bb89:
  br label %bb94
bb90:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load ptr, ptr %l18, !tbaa !29
  %t320 = getelementptr %"compiler/typed:Slice", ptr %t318, i32 0, i32 0
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t322 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2euse(ptr %v0, ptr %v1, ptr %t317, ptr %t321, { i64, [1 x i64] } %t322, i1 false)
  br label %bb91
bb91:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load ptr, ptr %l18, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Slice", ptr %t327, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t332
  %t333 = getelementptr { i64, [1 x i64] }, ptr %t332, i32 0, i32 0
  store i64 0, ptr %t333
  %t334 = load { i64, [1 x i64] }, ptr %t332
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t326, ptr %t330, { i64, [1 x i64] } %t334)
  br label %bb92
bb92:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load ptr, ptr %l18, !tbaa !29
  %t341 = getelementptr %"compiler/typed:Slice", ptr %t339, i32 0, i32 2
  %t342 = load ptr, ptr %t341, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t344
  %t345 = getelementptr { i64, [1 x i64] }, ptr %t344, i32 0, i32 0
  store i64 0, ptr %t345
  %t346 = load { i64, [1 x i64] }, ptr %t344
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t338, ptr %t342, { i64, [1 x i64] } %t346)
  br label %bb93
bb93:
  br label %bb162
bb94:
  %t350 = load ptr, ptr %l1, !tbaa !29
  store ptr %t350, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t351 = load ptr, ptr %l177, !tbaa !29
  %t352 = icmp ne ptr %t351, null
  br i1 %t352, label %bb95, label %bb96
bb95:
  %t354 = load ptr, ptr %l177, !tbaa !29
  %t355 = load i64, ptr %t354, !range !{i64 0, i64 18}
  %t357 = icmp eq i64 %t355, 11
  store i1 %t357, ptr %l178, !tbaa !21
  br label %bb96
bb96:
  %t358 = load i1, ptr %l178, !tbaa !21
  br i1 %t358, label %bb97, label %bb98
bb97:
  %t359 = load ptr, ptr %l1, !tbaa !29
  %t361 = getelementptr { i64, [5 x i64] }, ptr %t359, i32 0, i32 1
  %t362 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t361, i32 0, i32 2
  %t363 = load ptr, ptr %t362
  store ptr %t363, ptr %l19, !tbaa !29
  br label %bb99
bb98:
  br label %bb103
bb99:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load ptr, ptr %l19, !tbaa !29
  %t368 = getelementptr %"compiler/typed:Cond", ptr %t366, i32 0, i32 0
  %t369 = load ptr, ptr %t368, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t371
  %t372 = getelementptr { i64, [1 x i64] }, ptr %t371, i32 0, i32 0
  store i64 0, ptr %t372
  %t373 = load { i64, [1 x i64] }, ptr %t371
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t365, ptr %t369, { i64, [1 x i64] } %t373)
  br label %bb100
bb100:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load ptr, ptr %l19, !tbaa !29
  %t380 = getelementptr %"compiler/typed:Cond", ptr %t378, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t382 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t377, ptr %t381, { i64, [1 x i64] } %t382)
  br label %bb101
bb101:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load ptr, ptr %l19, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Cond", ptr %t387, i32 0, i32 2
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t392 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t386, ptr %t390, { i64, [1 x i64] } %t392)
  br label %bb102
bb102:
  br label %bb162
bb103:
  %t396 = load ptr, ptr %l1, !tbaa !29
  store ptr %t396, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t397 = load ptr, ptr %l197, !tbaa !29
  %t398 = icmp ne ptr %t397, null
  br i1 %t398, label %bb104, label %bb105
bb104:
  %t400 = load ptr, ptr %l197, !tbaa !29
  %t401 = load i64, ptr %t400, !range !{i64 0, i64 18}
  %t403 = icmp eq i64 %t401, 12
  store i1 %t403, ptr %l198, !tbaa !21
  br label %bb105
bb105:
  %t404 = load i1, ptr %l198, !tbaa !21
  br i1 %t404, label %bb106, label %bb107
bb106:
  %t405 = load ptr, ptr %l1, !tbaa !29
  %t407 = getelementptr { i64, [5 x i64] }, ptr %t405, i32 0, i32 1
  %t408 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t407, i32 0, i32 2
  %t409 = load ptr, ptr %t408
  store ptr %t409, ptr %l20, !tbaa !29
  br label %bb108
bb107:
  br label %bb111
bb108:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load ptr, ptr %l20, !tbaa !29
  %t414 = getelementptr %"compiler/typed:Seq", ptr %t412, i32 0, i32 0
  %t415 = load { i64, ptr }, ptr %t414, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmts(ptr %v0, ptr %v1, ptr %t411, { i64, ptr } %t415)
  br label %bb109
bb109:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load ptr, ptr %l20, !tbaa !29
  %t421 = getelementptr %"compiler/typed:Seq", ptr %t419, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !29
  %t423 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t418, ptr %t422, { i64, [1 x i64] } %t423)
  br label %bb110
bb110:
  br label %bb162
bb111:
  %t427 = load ptr, ptr %l1, !tbaa !29
  store ptr %t427, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t428 = load ptr, ptr %l210, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb112, label %bb113
bb112:
  %t431 = load ptr, ptr %l210, !tbaa !29
  %t432 = load i64, ptr %t431, !range !{i64 0, i64 18}
  %t434 = icmp eq i64 %t432, 13
  store i1 %t434, ptr %l211, !tbaa !21
  br label %bb113
bb113:
  %t435 = load i1, ptr %l211, !tbaa !21
  br i1 %t435, label %bb114, label %bb115
bb114:
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr { i64, [5 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t438, i32 0, i32 2
  %t440 = load ptr, ptr %t439
  store ptr %t440, ptr %l21, !tbaa !29
  br label %bb116
bb115:
  br label %bb132
bb116:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load ptr, ptr %l21, !tbaa !29
  %t445 = getelementptr %"compiler/typed:Match", ptr %t443, i32 0, i32 0
  %t446 = load { i64, ptr }, ptr %t445, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmts(ptr %v0, ptr %v1, ptr %t442, { i64, ptr } %t446)
  br label %bb117
bb117:
  %t449 = load ptr, ptr %l21, !tbaa !29
  %t451 = getelementptr %"compiler/typed:Match", ptr %t449, i32 0, i32 1
  %t452 = load { i64, ptr }, ptr %t451, !tbaa !27
  store { i64, ptr } %t452, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t454 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t456 = extractvalue { i64, ptr } %t454, 0
  store i64 %t456, ptr %l24, !tbaa !24
  br label %bb118
bb118:
  %t458 = load i64, ptr %l23, !tbaa !24
  %t459 = load i64, ptr %l24, !tbaa !24
  %t462 = icmp slt i64 %t458, %t459
  %t464 = xor i1 %t462, true
  br i1 %t464, label %bb119, label %bb120
bb119:
  br label %bb124
bb120:
  br label %bb121
bb121:
  %t466 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t466, ptr %l227, !tbaa !27
  %t467 = load i64, ptr %l23, !tbaa !24
  %t469 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !27
  %t471 = getelementptr ptr, ptr %t470, i64 %t467
  %t472 = load ptr, ptr %t471, !tbaa !39
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t476 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2earm(ptr %v0, ptr %v1, ptr %t474, ptr %t472, { i64, [1 x i64] } %t476)
  br label %bb122
bb122:
  br label %bb123
bb123:
  %t480 = load i64, ptr %l23, !tbaa !24
  %t482 = add i64 %t480, 1
  store i64 %t482, ptr %l23, !tbaa !24
  br label %bb118
bb124:
  %t484 = load ptr, ptr %l21, !tbaa !29
  %t486 = getelementptr %"compiler/typed:Match", ptr %t484, i32 0, i32 2
  %t487 = load ptr, ptr %t486, !tbaa !29
  %t489 = icmp eq ptr %t487, null
  %t491 = xor i1 %t489, true
  br i1 %t491, label %bb125, label %bb126
bb125:
  %t493 = load ptr, ptr %l0, !tbaa !29
  store ptr %t493, ptr %l239, !tbaa !29
  %t494 = load ptr, ptr %l21, !tbaa !29
  %t496 = getelementptr %"compiler/typed:Match", ptr %t494, i32 0, i32 2
  %t497 = load ptr, ptr %t496, !tbaa !29
  %t499 = icmp eq ptr %t497, null
  br i1 %t499, label %bb127, label %bb128
bb126:
  br label %bb131
bb127:
  call void @__olang_check_failed(ptr @olang_loc_378ad1b24c170823_353e69e2764e6faf)
  unreachable
bb128:
  br label %bb129
bb129:
  %t501 = load ptr, ptr %l21, !tbaa !29
  %t503 = getelementptr %"compiler/typed:Match", ptr %t501, i32 0, i32 2
  %t504 = load ptr, ptr %t503, !tbaa !29
  %t505 = load { i64, [1 x i64] }, ptr %l2
  %t506 = load ptr, ptr %l239, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2earm(ptr %v0, ptr %v1, ptr %t506, ptr %t504, { i64, [1 x i64] } %t505)
  br label %bb130
bb130:
  br label %bb131
bb131:
  br label %bb162
bb132:
  %t509 = load ptr, ptr %l1, !tbaa !29
  store ptr %t509, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t510 = load ptr, ptr %l246, !tbaa !29
  %t511 = icmp ne ptr %t510, null
  br i1 %t511, label %bb133, label %bb134
bb133:
  %t513 = load ptr, ptr %l246, !tbaa !29
  %t514 = load i64, ptr %t513, !range !{i64 0, i64 18}
  %t516 = icmp eq i64 %t514, 14
  store i1 %t516, ptr %l247, !tbaa !21
  br label %bb134
bb134:
  %t517 = load i1, ptr %l247, !tbaa !21
  br i1 %t517, label %bb135, label %bb136
bb135:
  %t518 = load ptr, ptr %l1, !tbaa !29
  %t520 = getelementptr { i64, [5 x i64] }, ptr %t518, i32 0, i32 1
  %t521 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t520, i32 0, i32 2
  %t522 = load ptr, ptr %t521
  store ptr %t522, ptr %l26, !tbaa !29
  br label %bb137
bb136:
  br label %bb140
bb137:
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load ptr, ptr %l26, !tbaa !29
  %t527 = getelementptr %"compiler/typed:Try", ptr %t525, i32 0, i32 0
  %t528 = load ptr, ptr %t527, !tbaa !29
  %t529 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t524, ptr %t528, { i64, [1 x i64] } %t529)
  br label %bb138
bb138:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load ptr, ptr %l26, !tbaa !29
  %t536 = getelementptr %"compiler/typed:Try", ptr %t534, i32 0, i32 1
  %t537 = load { i64, ptr }, ptr %t536, !tbaa !27
  %t538 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eclauses(ptr %v0, ptr %v1, ptr %t533, { i64, ptr } %t537, { i64, [1 x i64] } %t538)
  br label %bb139
bb139:
  br label %bb162
bb140:
  %t542 = load ptr, ptr %l1, !tbaa !29
  store ptr %t542, ptr %l260, !tbaa !29
  store i1 false, ptr %l261, !tbaa !21
  %t543 = load ptr, ptr %l260, !tbaa !29
  %t544 = icmp ne ptr %t543, null
  br i1 %t544, label %bb141, label %bb142
bb141:
  %t546 = load ptr, ptr %l260, !tbaa !29
  %t547 = load i64, ptr %t546, !range !{i64 0, i64 18}
  %t549 = icmp eq i64 %t547, 15
  store i1 %t549, ptr %l261, !tbaa !21
  br label %bb142
bb142:
  %t550 = load i1, ptr %l261, !tbaa !21
  br i1 %t550, label %bb143, label %bb144
bb143:
  %t551 = load ptr, ptr %l1, !tbaa !29
  %t553 = getelementptr { i64, [5 x i64] }, ptr %t551, i32 0, i32 1
  %t554 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t553, i32 0, i32 2
  %t555 = load ptr, ptr %t554
  store ptr %t555, ptr %l27, !tbaa !29
  br label %bb145
bb144:
  br label %bb147
bb145:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2efnVal(ptr %v0, ptr %v1, ptr %t557, ptr %t558)
  br label %bb146
bb146:
  br label %bb162
bb147:
  %t561 = load ptr, ptr %l1, !tbaa !29
  store ptr %t561, ptr %l268, !tbaa !29
  store i1 false, ptr %l269, !tbaa !21
  %t562 = load ptr, ptr %l268, !tbaa !29
  %t563 = icmp ne ptr %t562, null
  br i1 %t563, label %bb148, label %bb149
bb148:
  %t565 = load ptr, ptr %l268, !tbaa !29
  %t566 = load i64, ptr %t565, !range !{i64 0, i64 18}
  %t568 = icmp eq i64 %t566, 16
  store i1 %t568, ptr %l269, !tbaa !21
  br label %bb149
bb149:
  %t569 = load i1, ptr %l269, !tbaa !21
  br i1 %t569, label %bb150, label %bb151
bb150:
  %t570 = load ptr, ptr %l1, !tbaa !29
  %t572 = getelementptr { i64, [5 x i64] }, ptr %t570, i32 0, i32 1
  %t573 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t572, i32 0, i32 2
  %t574 = load ptr, ptr %t573
  store ptr %t574, ptr %l28, !tbaa !29
  br label %bb152
bb151:
  br label %bb154
bb152:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load ptr, ptr %l28, !tbaa !29
  %t579 = getelementptr %"compiler/typed:Text", ptr %t577, i32 0, i32 0
  %t580 = load { i64, ptr }, ptr %t579, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2epieces(ptr %v0, ptr %v1, ptr %t576, { i64, ptr } %t580)
  br label %bb153
bb153:
  br label %bb162
bb154:
  %t583 = load ptr, ptr %l1, !tbaa !29
  store ptr %t583, ptr %l277, !tbaa !29
  store i1 false, ptr %l278, !tbaa !21
  %t584 = load ptr, ptr %l277, !tbaa !29
  %t585 = icmp ne ptr %t584, null
  br i1 %t585, label %bb155, label %bb156
bb155:
  %t587 = load ptr, ptr %l277, !tbaa !29
  %t588 = load i64, ptr %t587, !range !{i64 0, i64 18}
  %t590 = icmp eq i64 %t588, 17
  store i1 %t590, ptr %l278, !tbaa !21
  br label %bb156
bb156:
  %t591 = load i1, ptr %l278, !tbaa !21
  br i1 %t591, label %bb157, label %bb158
bb157:
  %t592 = load ptr, ptr %l1, !tbaa !29
  %t594 = getelementptr { i64, [5 x i64] }, ptr %t592, i32 0, i32 1
  %t595 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t594, i32 0, i32 2
  %t596 = load ptr, ptr %t595
  store ptr %t596, ptr %l29, !tbaa !29
  br label %bb159
bb158:
  br label %bb161
bb159:
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load ptr, ptr %l29, !tbaa !29
  %t601 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t598, ptr %t599, { i64, [1 x i64] } %t601)
  br label %bb160
bb160:
  br label %bb162
bb161:
  call void @__olang_check_failed(ptr @olang_loc_ff24328511a0943b_1b00d38544175a97)
  unreachable
bb162:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca i1
  %l67 = alloca i64
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i64 %t35, ptr %l23
  br label %bb10
bb10:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  br label %bb50
bb11:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t38 = load ptr, ptr %l24, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l24, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 18}
  %t44 = icmp eq i64 %t42, 10
  store i1 %t44, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l25, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Slice", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t59 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t52, ptr %t56)
  store i64 %t59, ptr %l33
  br label %bb17
bb17:
  %t60 = load i64, ptr %l33, !tbaa !24
  store i64 %t60, ptr %l8, !tbaa !24
  br label %bb50
bb18:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t62 = load ptr, ptr %l34, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 18}
  %t68 = icmp eq i64 %t66, 5
  store i1 %t68, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Promote", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t83 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %t76, ptr %t80)
  store i64 %t83, ptr %l43
  br label %bb24
bb24:
  %t84 = load i64, ptr %l43, !tbaa !24
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb50
bb25:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t86 = load ptr, ptr %l44, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l44, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 17
  store i1 %t92, ptr %l45, !tbaa !21
  br label %bb27
bb27:
  %t93 = load i1, ptr %l45, !tbaa !21
  br i1 %t93, label %bb28, label %bb29
bb28:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t104 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %t100, ptr %t101)
  store i64 %t104, ptr %l52
  br label %bb31
bb31:
  %t105 = load i64, ptr %l52, !tbaa !24
  store i64 %t105, ptr %l8, !tbaa !24
  br label %bb50
bb32:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t107 = load ptr, ptr %l53, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t110 = load ptr, ptr %l53, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 18}
  %t113 = icmp eq i64 %t111, 9
  store i1 %t113, ptr %l54, !tbaa !21
  br label %bb34
bb34:
  %t114 = load i1, ptr %l54, !tbaa !21
  br i1 %t114, label %bb35, label %bb36
bb35:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t117, i32 0, i32 2
  %t119 = load i32, ptr %t118, !range !{i32 0, i32 44}
  store i32 %t119, ptr %l6
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t123, i32 0, i32 4
  %t125 = load { i64, ptr }, ptr %t124
  store { i64, ptr } %t125, ptr %l7, !tbaa !27
  br label %bb37
bb36:
  br label %bb45
bb37:
  %t127 = load i32, ptr %l6, !range !{i32 0, i32 44}
  %t129 = trunc i64 20 to i32
  %t130 = icmp eq i32 %t127, %t129
  br i1 %t130, label %bb38, label %bb39
bb38:
  %t132 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t136 = icmp eq i64 %t134, 1
  store i1 %t136, ptr %l63, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb40
bb40:
  %t138 = load i1, ptr %l63, !tbaa !21
  br i1 %t138, label %bb41, label %bb42
bb41:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t140, ptr %l69, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr ptr, ptr %t142, i64 0
  %t144 = load ptr, ptr %t143, !tbaa !39
  %t147 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %t139, ptr %t144)
  store i64 %t147, ptr %l71
  br label %bb43
bb42:
  store i64 -1, ptr %l67, !tbaa !24
  br label %bb44
bb43:
  %t148 = load i64, ptr %l71, !tbaa !24
  store i64 %t148, ptr %l67, !tbaa !24
  br label %bb44
bb44:
  %t149 = load i64, ptr %l67, !tbaa !24
  store i64 %t149, ptr %l8, !tbaa !24
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_ea76fa4e8d5c92b6_ce360b1ee865cf5a)
  unreachable
bb50:
  %t150 = load i64, ptr %l8, !tbaa !24
  store i64 %t150, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2efieldsOnly(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca i1
  %l43 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb30
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l13, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t29 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2efieldsOnly(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i1 %t29, ptr %l21
  br label %bb12
bb12:
  %t30 = load i1, ptr %l21, !tbaa !21
  store i1 %t30, ptr %l8, !tbaa !21
  br label %bb30
bb13:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb14, label %bb15
bb14:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb16, label %bb17
bb16:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb25
bb18:
  %t46 = load ptr, ptr %l3, !tbaa !29
  store ptr %t46, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t47 = load ptr, ptr %l28, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb19, label %bb20
bb19:
  %t50 = load ptr, ptr %l28, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 2
  store i1 %t53, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t54 = load i1, ptr %l29, !tbaa !21
  br i1 %t54, label %bb21, label %bb22
bb21:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l4
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t63, i32 0, i32 1
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l6, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t75, i32 0, i32 3
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l7, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t83 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t79, ptr %t80)
  store i64 %t83, ptr %l43
  br label %bb23
bb22:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb24
bb23:
  %t84 = load i64, ptr %l43, !tbaa !24
  %t85 = icmp sge i64 %t84, 0
  store i1 %t85, ptr %l32, !tbaa !21
  br label %bb24
bb24:
  %t87 = load i1, ptr %l32, !tbaa !21
  store i1 %t87, ptr %l8, !tbaa !21
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_b3e084de49f7dfe2_9d51886cee01545e)
  unreachable
bb30:
  %t88 = load i1, ptr %l8, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l21 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %t44 = alloca { i64, [1 x i64] }, align 8
  %t72 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t30, ptr %l21, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Capture", ptr %t36, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [1 x i64] }, ptr %t44, i32 0, i32 0
  store i64 5, ptr %t45
  %t46 = load { i64, [1 x i64] }, ptr %t44
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t38, ptr %t42, { i64, [1 x i64] } %t46)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  br label %bb27
bb13:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 3}
  %t61 = icmp eq i64 %t59, 2
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { i32, ptr, i32 }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [1 x i64] }, ptr %t72, i32 0, i32 0
  store i64 5, ptr %t73
  %t74 = load { i64, [1 x i64] }, ptr %t72
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t69, ptr %t70, { i64, [1 x i64] } %t74)
  br label %bb19
bb19:
  br label %bb27
bb20:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load ptr, ptr %l41, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 3}
  %t85 = icmp eq i64 %t83, 0
  store i1 %t85, ptr %l42, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l42, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_c889b00966965144_dcfe1455a200f620)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elet(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l14 = alloca %"compiler/typed:Local"
  %l17 = alloca ptr
  %l21 = alloca %"compiler/typed:Local"
  %l23 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l34 = alloca { i64, [1 x i64] }
  %t62 = alloca { i64, [1 x i64] }, align 8
  %t69 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 9
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t7 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eSet_H54ebfdc15a9c097858a2e264494e7d5a(ptr %v0, ptr %v1, ptr %t3, i64 %t6, ptr %t7)
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:LocalUses", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t17 = load ptr, ptr @__olang_prog_scope
  %t20 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %t17, ptr %t15, i32 %t16)
  store %"compiler/typed:Local" %t20, ptr %l14
  br label %bb2
bb2:
  %t21 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 4
  %t22 = load i32, ptr %t21, !range !{i32 0, i32 7}
  store i32 %t22, ptr %l3
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/typed:LocalUses", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  store ptr %t27, ptr %l17, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:LocalUses", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t33 = load ptr, ptr @__olang_prog_scope
  %t36 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %t33, ptr %t31, i32 %t32)
  store %"compiler/typed:Local" %t36, ptr %l21
  br label %bb3
bb3:
  %t37 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 2
  %t38 = load i32, ptr %t37, !tbaa !23
  %t39 = load ptr, ptr @__olang_prog_scope
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t39, ptr %t40, i32 %t38)
  store i1 %t42, ptr %l23
  br label %bb4
bb4:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb7
bb6:
  %t44 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t46 = trunc i64 2 to i32
  %t47 = icmp eq i32 %t44, %t46
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb7
bb7:
  %t49 = load i1, ptr %l24, !tbaa !21
  br i1 %t49, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  %t50 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t52 = trunc i64 4 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l27, !tbaa !21
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l30, !tbaa !29
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t61 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [1 x i64] }, ptr %t62, i32 0, i32 0
  store i64 4, ptr %t63
  %t65 = insertvalue { i32 } undef, i32 %t61, 0
  %t66 = getelementptr { i64, [1 x i64] }, ptr %t62, i32 0, i32 1
  store { i32 } %t65, ptr %t66
  %t67 = load { i64, [1 x i64] }, ptr %t62
  store { i64, [1 x i64] } %t67, ptr %l34
  br label %bb13
bb12:
  store { i64, [1 x i64] } zeroinitializer, ptr %t69
  %t70 = getelementptr { i64, [1 x i64] }, ptr %t69, i32 0, i32 0
  store i64 2, ptr %t70
  %t71 = load { i64, [1 x i64] }, ptr %t69
  store { i64, [1 x i64] } %t71, ptr %l34
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l30, !tbaa !29
  %t74 = load ptr, ptr %l32, !tbaa !29
  %t75 = load { i64, [1 x i64] }, ptr %l34
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t73, ptr %t74, { i64, [1 x i64] } %t75)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2epieces(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca i1
  %t41 = alloca { i64, [1 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l17, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 2}
  %t30 = icmp eq i64 %t28, 1
  store i1 %t30, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { ptr }, ptr %t34, i32 0, i32 0
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t39 = load ptr, ptr %l6, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [1 x i64] }, ptr %t41, i32 0, i32 0
  store i64 0, ptr %t42
  %t43 = load { i64, [1 x i64] }, ptr %t41
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t39, { i64, [1 x i64] } %t43)
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f1d97b93b21930ce_df2dd3f10bda1132)
  unreachable
bb16:
  br label %bb17
bb17:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l3, !tbaa !24
  br label %bb1
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca i1
  %t48 = alloca { i64, [1 x i64] }, align 8
  %t102 = alloca { i64, [1 x i64] }, align 8
  %t126 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb45
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 4
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Elem", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t35, ptr %t39)
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Elem", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [1 x i64] }, ptr %t48, i32 0, i32 0
  store i64 0, ptr %t49
  %t50 = load { i64, [1 x i64] }, ptr %t48
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t42, ptr %t46, { i64, [1 x i64] } %t50)
  br label %bb14
bb14:
  br label %bb45
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 8}
  %t61 = icmp eq i64 %t59, 5
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t62 = load i1, ptr %l30, !tbaa !21
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Payload", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t69, ptr %t73)
  br label %bb21
bb21:
  br label %bb45
bb22:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t77 = load ptr, ptr %l38, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb23, label %bb24
bb23:
  %t80 = load ptr, ptr %l38, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 2
  store i1 %t83, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t84 = load i1, ptr %l39, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l5, !tbaa !29
  %t95 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store i64 %t95, ptr %l46
  br label %bb28
bb28:
  %t96 = load i64, ptr %l46, !tbaa !24
  %t97 = icmp slt i64 %t96, 0
  br i1 %t97, label %bb29, label %bb30
bb29:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l5, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [1 x i64] }, ptr %t102, i32 0, i32 0
  store i64 0, ptr %t103
  %t104 = load { i64, [1 x i64] }, ptr %t102
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t99, ptr %t100, { i64, [1 x i64] } %t104)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb45
bb33:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t109 = load ptr, ptr %l52, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 8}
  %t115 = icmp eq i64 %t113, 6
  store i1 %t115, ptr %l53, !tbaa !21
  br label %bb35
bb35:
  %t116 = load i1, ptr %l53, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [1 x i64] }, ptr %t126, i32 0, i32 0
  store i64 0, ptr %t127
  %t128 = load { i64, [1 x i64] }, ptr %t126
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t123, ptr %t124, { i64, [1 x i64] } %t128)
  br label %bb39
bb39:
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_572ff0c594eb7d28_3eb561bfca5d9eb4)
  unreachable
bb45:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l22 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i64
  %l50 = alloca ptr
  %l58 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l4, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l5, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:LocalUses", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t27 = load ptr, ptr @__olang_prog_scope
  %t30 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t27, ptr %t25, i32 %t26)
  store i64 %t30, ptr %l22
  br label %bb6
bb6:
  %t31 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t32 = load i64, ptr %l22, !tbaa !24
  %t34 = and i64 %t32, %t31
  %t36 = icmp eq i64 %t34, 0
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t38 = load ptr, ptr %l5, !tbaa !29
  store ptr %t38, ptr %l26, !tbaa !29
  br label %bb9
bb8:
  store ptr null, ptr %l26, !tbaa !29
  br label %bb9
bb9:
  %t41 = load ptr, ptr %l26, !tbaa !29
  store ptr %t41, ptr %l10, !tbaa !29
  br label %bb29
bb10:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t43 = load ptr, ptr %l29, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l29, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 18}
  %t49 = icmp eq i64 %t47, 2
  store i1 %t49, ptr %l30, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l30, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t53, i32 0, i32 1
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l6, !tbaa !23
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l7, !tbaa !29
  br label %bb15
bb14:
  br label %bb24
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:LocalUses", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t67 = load i32, ptr %l6, !tbaa !23
  %t68 = load ptr, ptr @__olang_prog_scope
  %t71 = call i1 @compiler_2ftyped_2escalarType(ptr %t68, ptr %t66, i32 %t67)
  store i1 %t71, ptr %l40
  br label %bb16
bb16:
  %t72 = load i1, ptr %l40, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/typed:LocalUses", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l6, !tbaa !23
  %t80 = load ptr, ptr @__olang_prog_scope
  %t83 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t80, ptr %t78, i32 %t79)
  store i64 %t83, ptr %l46
  br label %bb19
bb18:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb20
bb19:
  %t84 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t85 = load i64, ptr %l46, !tbaa !24
  %t87 = and i64 %t85, %t84
  %t89 = icmp eq i64 %t87, 0
  store i1 %t89, ptr %l42, !tbaa !21
  br label %bb20
bb20:
  %t91 = load i1, ptr %l42, !tbaa !21
  br i1 %t91, label %bb21, label %bb22
bb21:
  %t92 = load ptr, ptr %l7, !tbaa !29
  store ptr %t92, ptr %l50, !tbaa !29
  br label %bb23
bb22:
  store ptr null, ptr %l50, !tbaa !29
  br label %bb23
bb23:
  %t95 = load ptr, ptr %l50, !tbaa !29
  store ptr %t95, ptr %l10, !tbaa !29
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store ptr null, ptr %l10, !tbaa !29
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_93af16bb2b9103f6_23d1e52eae2906e2)
  unreachable
bb29:
  %t96 = load ptr, ptr %l10, !tbaa !29
  store ptr %t96, ptr %l8, !tbaa !29
  %t97 = load ptr, ptr %l8, !tbaa !29
  %t99 = icmp eq ptr %t97, null
  br i1 %t99, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t106 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i64 %t106, ptr %l58
  br label %bb33
bb33:
  %t107 = load i64, ptr %l58, !tbaa !24
  store i64 %t107, ptr %l9, !tbaa !24
  %t108 = load i64, ptr %l9, !tbaa !24
  %t110 = icmp slt i64 %t108, 0
  br i1 %t110, label %bb34, label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t113, ptr %t114)
  br label %bb37
bb37:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/typed:LocalUses", ptr %t117, i32 0, i32 5
  %t120 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t119, i64 %t120, i1 true)
  br label %bb38
bb38:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/typed:LocalUses", ptr %t123, i32 0, i32 15
  %t126 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t125, i64 %t126)
  br label %bb39
bb39:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/typed:LocalUses", ptr %t129, i32 0, i32 16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t131, i64 %a2)
  br label %bb40
bb40:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/typed:LocalUses", ptr %t135, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t137, i64 %a3)
  br label %bb41
bb41:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i1
  %l53 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb39
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t39 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store i64 %t39, ptr %l24
  br label %bb12
bb12:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  br label %bb39
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l25, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 8}
  %t48 = icmp eq i64 %t46, 4
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l26, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Elem", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  store i64 %t63, ptr %l34
  br label %bb19
bb19:
  %t64 = load i64, ptr %l34, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  br label %bb39
bb20:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l36, !tbaa !21
  br label %bb22
bb22:
  %t73 = load i1, ptr %l36, !tbaa !21
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Payload", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  store i64 %t87, ptr %l44
  br label %bb26
bb26:
  %t88 = load i64, ptr %l44, !tbaa !24
  store i64 %t88, ptr %l7, !tbaa !24
  br label %bb39
bb27:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t90 = load ptr, ptr %l45, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t93 = load ptr, ptr %l45, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 2
  store i1 %t96, ptr %l46, !tbaa !21
  br label %bb29
bb29:
  %t97 = load i1, ptr %l46, !tbaa !21
  br i1 %t97, label %bb30, label %bb31
bb30:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t108 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  store i64 %t108, ptr %l53
  br label %bb33
bb33:
  %t109 = load i64, ptr %l53, !tbaa !24
  store i64 %t109, ptr %l7, !tbaa !24
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_6333e3fa20d2f5d8_bcafed7a04540454)
  unreachable
bb39:
  %t110 = load i64, ptr %l7, !tbaa !24
  store i64 %t110, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempLent(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca i64
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l44 = alloca i64
  %l48 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 6
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:LocalUses", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load ptr, ptr @__olang_prog_scope
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t42, ptr %t40, i32 %t41)
  store i64 %t45, ptr %l26
  br label %bb11
bb11:
  %t46 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t47 = load i64, ptr %l26, !tbaa !24
  %t49 = and i64 %t47, %t46
  %t51 = icmp ne i64 %t49, 0
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %l4, !tbaa !29
  store ptr %t53, ptr %l30, !tbaa !29
  br label %bb14
bb13:
  store ptr null, ptr %l30, !tbaa !29
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l30, !tbaa !29
  store ptr %t56, ptr %l16, !tbaa !29
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store ptr null, ptr %l16, !tbaa !29
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_43639d7480e3f1b2_6970610da298d01e)
  unreachable
bb20:
  %t57 = load ptr, ptr %l16, !tbaa !29
  store ptr %t57, ptr %l7, !tbaa !29
  br label %bb36
bb21:
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t59 = load ptr, ptr %l33, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb22, label %bb23
bb22:
  %t62 = load ptr, ptr %l33, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 18}
  %t65 = icmp eq i64 %t63, 5
  store i1 %t65, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb24, label %bb25
bb24:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t69, i32 0, i32 1
  %t71 = load i32, ptr %t70
  store i32 %t71, ptr %l5, !tbaa !23
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l6, !tbaa !29
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:LocalUses", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i32, ptr %l5, !tbaa !23
  %t84 = load ptr, ptr @__olang_prog_scope
  %t87 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t84, ptr %t82, i32 %t83)
  store i64 %t87, ptr %l44
  br label %bb27
bb27:
  %t88 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t89 = load i64, ptr %l44, !tbaa !24
  %t91 = and i64 %t89, %t88
  %t93 = icmp ne i64 %t91, 0
  br i1 %t93, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Promote", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l48, !tbaa !29
  br label %bb30
bb29:
  store ptr null, ptr %l48, !tbaa !29
  br label %bb30
bb30:
  %t101 = load ptr, ptr %l48, !tbaa !29
  store ptr %t101, ptr %l7, !tbaa !29
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store ptr null, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_13022d0d55ff9b33_d1cf61a4f0453a9f)
  unreachable
bb36:
  %t102 = load ptr, ptr %l7, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2euse(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [1 x i64] }
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l11 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l54 = alloca i64
  %l56 = alloca i1
  %l61 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [1 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  store i64 %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t16 = load ptr, ptr %l14, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb4:
  br label %bb17
bb5:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 8}
  %t22 = icmp eq i64 %t20, 6
  store i1 %t22, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l5, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = load { i64, [1 x i64] }, ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t30, ptr %t31, { i64, [1 x i64] } %t33)
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4f6de7c744c3571c_6f8dca6bf99a5cd8)
  unreachable
bb16:
  br label %ret
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:LocalUses", ptr %t37, i32 0, i32 23
  %t40 = load i64, ptr %t39, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb18, label %bb19
bb18:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/typed:LocalUses", ptr %t44, i32 0, i32 5
  %t47 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t46, i64 %t47, i1 true)
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/typed:LocalUses", ptr %t50, i32 0, i32 6
  %t53 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t52, i64 %t53, i1 true)
  br label %bb21
bb21:
  br label %ret
bb22:
  %t56 = load { i64, [1 x i64] }, ptr %l2
  %t58 = extractvalue { i64, [1 x i64] } %t56, 0
  %t59 = icmp eq i64 %t58, 0
  br i1 %t59, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  %t61 = load { i64, [1 x i64] }, ptr %l2
  %t63 = extractvalue { i64, [1 x i64] } %t61, 0
  %t64 = icmp eq i64 %t63, 1
  br i1 %t64, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb61
bb28:
  %t66 = load { i64, [1 x i64] }, ptr %l2
  %t68 = extractvalue { i64, [1 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 2
  br i1 %t69, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb36
bb31:
  br i1 %a3, label %bb32, label %bb33
bb32:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eescape(ptr %v0, ptr %t73, i64 %t74)
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  br label %bb61
bb36:
  %t77 = load { i64, [1 x i64] }, ptr %l2
  %t79 = extractvalue { i64, [1 x i64] } %t77, 0
  %t80 = icmp eq i64 %t79, 3
  br i1 %t80, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/typed:LocalUses", ptr %t82, i32 0, i32 7
  %t85 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t84, i64 %t85, i1 true)
  br label %bb40
bb40:
  br label %bb61
bb41:
  %t88 = load { i64, [1 x i64] }, ptr %l2
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 4
  br i1 %t91, label %bb42, label %bb43
bb42:
  %t93 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l6, !tbaa !23
  br label %bb44
bb43:
  br label %bb55
bb44:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/typed:LocalUses", ptr %t97, i32 0, i32 8
  %t100 = load i32, ptr %l6, !tbaa !23
  %t102 = sext i32 %t100 to i64
  %t105 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t99, i64 %t102)
  store i64 %t105, ptr %l54
  br label %bb45
bb45:
  %t106 = load i64, ptr %l54, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  br i1 %t107, label %bb46, label %bb47
bb46:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/typed:LocalUses", ptr %t109, i32 0, i32 8
  %t112 = load i32, ptr %l6, !tbaa !23
  %t114 = sext i32 %t112 to i64
  %t117 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t111, i64 %t114)
  store i64 %t117, ptr %l61
  br label %bb48
bb47:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb49
bb48:
  %t118 = load i64, ptr %l4, !tbaa !24
  %t119 = load i64, ptr %l61, !tbaa !24
  %t121 = icmp ne i64 %t119, %t118
  store i1 %t121, ptr %l56, !tbaa !21
  br label %bb49
bb49:
  %t123 = load i1, ptr %l56, !tbaa !21
  br i1 %t123, label %bb50, label %bb51
bb50:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eescape(ptr %v0, ptr %t124, i64 %t125)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/typed:LocalUses", ptr %t128, i32 0, i32 8
  %t131 = load i32, ptr %l6, !tbaa !23
  %t133 = sext i32 %t131 to i64
  %t134 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t130, i64 %t133, i64 %t134)
  br label %bb54
bb54:
  br label %bb61
bb55:
  %t138 = load { i64, [1 x i64] }, ptr %l2
  %t140 = extractvalue { i64, [1 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 5
  br i1 %t141, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eescape(ptr %v0, ptr %t143, i64 %t144)
  br label %bb59
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_2bdab9da3f4d_ded05e4518f32fa9)
  unreachable
bb61:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l6, !tbaa !24
  br label %bb32
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t39 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store i64 %t39, ptr %l23
  br label %bb12
bb12:
  %t40 = load i64, ptr %l23, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  br label %bb32
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 8}
  %t48 = icmp eq i64 %t46, 4
  store i1 %t48, ptr %l25, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l25, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Elem", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  store i64 %t63, ptr %l33
  br label %bb19
bb19:
  %t64 = load i64, ptr %l33, !tbaa !24
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb32
bb20:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l34, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t73 = load i1, ptr %l35, !tbaa !21
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Payload", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  store i64 %t87, ptr %l43
  br label %bb26
bb26:
  %t88 = load i64, ptr %l43, !tbaa !24
  store i64 %t88, ptr %l6, !tbaa !24
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_4086334666941342_2cd2470309ce51f6)
  unreachable
bb32:
  %t89 = load i64, ptr %l6, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l15 = alloca i1
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l8, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t15, ptr %t16)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %ret
bb6:
  %t21 = xor i1 %a2, true
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i1 %t27, ptr %l18
  br label %bb9
bb8:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb10
bb9:
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:LocalUses", ptr %t30, i32 0, i32 3
  %t33 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t32, i64 %t33, i1 true)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %ret
bb14:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/typed:LocalUses", ptr %t36, i32 0, i32 2
  %t39 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t38, i64 %t39, i1 true)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca i64
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 7
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Plan", ptr %t8, i32 0, i32 9
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l13
  br label %bb1
bb1:
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = add i64 %t13, 1
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i64, ptr %t18, i64 %t16
  store i64 %t14, ptr %t19, !tbaa !34
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Plan", ptr %t20, i32 0, i32 8
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i64, ptr %t33, i64 %t26
  store i64 %t29, ptr %t34, !tbaa !34
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t49, ptr %l28, !tbaa !27
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, [1 x i64] }, ptr %t53, i64 %t50
  %t55 = load { i64, [1 x i64] }, ptr %t54
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Plan", ptr %t57, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t59, { i64, [1 x i64] } %t55)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb21
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 17}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb21
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 17}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb21
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 17}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb21
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l31, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 17}
  %t68 = icmp eq i64 %t66, 4
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb18
bb18:
  %t69 = load i1, ptr %l32, !tbaa !21
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l1
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t76 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t76, ptr %l6
  br label %bb79
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 17}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb43
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 17}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [3 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb43
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 17}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb43
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t124 = load ptr, ptr %l56, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l56, !tbaa !29
  %t128 = load i64, ptr %t127, !range !{i64 0, i64 17}
  %t130 = icmp eq i64 %t128, 9
  store i1 %t130, ptr %l57, !tbaa !21
  br label %bb36
bb36:
  %t131 = load i1, ptr %l57, !tbaa !21
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l2
  br label %bb43
bb38:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t139 = load ptr, ptr %l62, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb39, label %bb40
bb39:
  %t142 = load ptr, ptr %l62, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 17}
  %t145 = icmp eq i64 %t143, 10
  store i1 %t145, ptr %l63, !tbaa !21
  br label %bb40
bb40:
  %t146 = load i1, ptr %l63, !tbaa !21
  br i1 %t146, label %bb41, label %bb42
bb41:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  store %"compiler/source:Span" %t151, ptr %l2
  br label %bb43
bb42:
  br label %bb44
bb43:
  %t153 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t153, ptr %l6
  br label %bb79
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 17}
  %t162 = icmp eq i64 %t160, 8
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb49
bb48:
  br label %bb50
bb49:
  %t170 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t170, ptr %l6
  br label %bb79
bb50:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t173 = load ptr, ptr %l76, !tbaa !29
  %t174 = icmp ne ptr %t173, null
  br i1 %t174, label %bb51, label %bb52
bb51:
  %t176 = load ptr, ptr %l76, !tbaa !29
  %t177 = load i64, ptr %t176, !range !{i64 0, i64 17}
  %t179 = icmp eq i64 %t177, 11
  store i1 %t179, ptr %l77, !tbaa !21
  br label %bb52
bb52:
  %t180 = load i1, ptr %l77, !tbaa !21
  br i1 %t180, label %bb53, label %bb54
bb53:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr { i64, [3 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", ptr }, ptr %t183, i32 0, i32 0
  %t185 = load %"compiler/source:Span", ptr %t184
  store %"compiler/source:Span" %t185, ptr %l4
  br label %bb71
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 17}
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", ptr }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l4
  br label %bb71
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l4
  br label %bb71
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb71
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 17}
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t247 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t247, ptr %l6
  br label %bb79
bb72:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t250 = load ptr, ptr %l107, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb73, label %bb74
bb73:
  %t253 = load ptr, ptr %l107, !tbaa !29
  %t254 = load i64, ptr %t253, !range !{i64 0, i64 17}
  %t256 = icmp eq i64 %t254, 16
  store i1 %t256, ptr %l108, !tbaa !21
  br label %bb74
bb74:
  %t257 = load i1, ptr %l108, !tbaa !21
  br i1 %t257, label %bb75, label %bb76
bb75:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", ptr }, ptr %t260, i32 0, i32 0
  %t262 = load %"compiler/source:Span", ptr %t261
  store %"compiler/source:Span" %t262, ptr %l5
  br label %bb77
bb76:
  br label %bb78
bb77:
  %t264 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t264, ptr %l6
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_d42dce2e5a8639a6_22ec82fe09d5fbba)
  unreachable
bb79:
  %t266 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t266, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l16 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t23 = getelementptr %"compiler/typed:ViewWalk", ptr %a0, i32 0, i32 3
  %t24 = load { ptr, ptr }, ptr %t23
  %t25 = load i32, ptr %l3, !tbaa !23
  %t27 = extractvalue { ptr, ptr } %t24, 0
  %t28 = extractvalue { ptr, ptr } %t24, 1
  %t30 = call i64 %t27(ptr %t28, i32 %t25)
  store i64 %t30, ptr %l16
  br label %bb6
bb6:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_996d81e577c7faae_f3b4a025cf703a)
  unreachable
bb12:
  %t32 = load i64, ptr %l6, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eElidedCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2earrayValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l18 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t7 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %a1)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr @__olang_prog_scope
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i32, ptr %l6, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t8, ptr %t9, i32 %t10)
  store i32 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i32, ptr %l7, !tbaa !23
  store i32 %t12, ptr %l2, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:ViewWalk", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t18 = load ptr, ptr @__olang_prog_scope
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t18, ptr %t16, i32 %t17)
  store i32 %t21, ptr %l11
  br label %bb3
bb3:
  %t22 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t24 = trunc i64 19 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:ViewWalk", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load i32, ptr %l2, !tbaa !23
  %t32 = load ptr, ptr @__olang_prog_scope
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t32, ptr %t30, i32 %t31)
  store i32 %t35, ptr %l18
  br label %bb6
bb5:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t36 = load i32, ptr %l18, !tbaa !23
  %t37 = icmp eq i32 %t36, 0
  store i1 %t37, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t39 = load i1, ptr %l14, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2elocalRoots(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:Local"
  %l7 = alloca i64
  %l14 = alloca %"compiler/typed:Local"
  %l18 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l32 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 4
  %t4 = load { ptr, ptr }, ptr %t3
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = extractvalue { ptr, ptr } %t4, 0
  %t8 = extractvalue { ptr, ptr } %t4, 1
  %t10 = call i64 %t7(ptr %t8, i32 %t5)
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i64, ptr %l7, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:ViewWalk", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load ptr, ptr @__olang_prog_scope
  %t26 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %t23, ptr %t21, i32 %t22)
  store %"compiler/typed:Local" %t26, ptr %l14
  br label %bb5
bb5:
  %t27 = load %"compiler/typed:Local", ptr %l14
  store %"compiler/typed:Local" %t27, ptr %l3
  %t28 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t29 = load i32, ptr %t28, !range !{i32 0, i32 7}
  %t31 = trunc i64 0 to i32
  %t32 = icmp eq i32 %t29, %t31
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb9
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/typed:ViewWalk", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load ptr, ptr @__olang_prog_scope
  %t45 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t42, ptr %t39, i32 %t41)
  store i1 %t45, ptr %l22
  br label %bb8
bb8:
  %t46 = load i1, ptr %l22, !tbaa !21
  store i1 %t46, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t47 = load i1, ptr %l18, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/typed:ViewWalk", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = load ptr, ptr @__olang_prog_scope
  %t57 = call i1 @compiler_2ftyped_2eHoldsOwned(ptr %t54, ptr %t51, i32 %t53)
  store i1 %t57, ptr %l27
  br label %bb12
bb12:
  %t58 = load i1, ptr %l27, !tbaa !21
  %t59 = xor i1 %t58, true
  store i1 %t59, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t61 = load i1, ptr %l23, !tbaa !21
  br i1 %t61, label %bb14, label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t67 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eparamBit(ptr %v0, ptr %t63, i32 %t64)
  store i64 %t67, ptr %l32
  br label %bb17
bb17:
  %t68 = load i64, ptr %l32, !tbaa !24
  store i64 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ematchRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb8
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %l18, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Arm", ptr %t24, i32 0, i32 4
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t34 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t27, ptr %t31)
  store i64 %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load i64, ptr %l18, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = call i64 @compiler_2ftyped_2emeetRoots(i64 %t35, i64 %t36)
  store i64 %t37, ptr %l23
  br label %bb6
bb6:
  %t38 = load i64, ptr %l23, !tbaa !24
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb1
bb8:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Match", ptr %t43, i32 0, i32 2
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load i64, ptr %l2, !tbaa !24
  store i64 %t52, ptr %l30, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Match", ptr %t54, i32 0, i32 2
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb11, label %bb12
bb10:
  br label %bb16
bb11:
  call void @__olang_check_failed(ptr @olang_loc_dd6dc40ab752fedf_c333d42519625383)
  unreachable
bb12:
  br label %bb13
bb13:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Match", ptr %t61, i32 0, i32 2
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Arm", ptr %t64, i32 0, i32 4
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l31, !tbaa !29
  %t71 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t69, ptr %t68)
  store i64 %t71, ptr %l39
  br label %bb14
bb14:
  %t72 = load i64, ptr %l30, !tbaa !24
  %t73 = load i64, ptr %l39, !tbaa !24
  %t74 = call i64 @compiler_2ftyped_2emeetRoots(i64 %t72, i64 %t73)
  store i64 %t74, ptr %l40
  br label %bb15
bb15:
  %t75 = load i64, ptr %l40, !tbaa !24
  store i64 %t75, ptr %l2, !tbaa !24
  br label %bb16
bb16:
  %t76 = load i64, ptr %l2, !tbaa !24
  store i64 %t76, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eparamBit(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l42 = alloca i32
  %l47 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 5
  %t7 = load ptr, ptr @__olang_prog_scope
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %t7, ptr %t6)
  store i64 %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t11 = load i64, ptr %l11, !tbaa !24
  %t13 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t11, i64 %t10)
  store i64 %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load i64, ptr %l13, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb8
bb5:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l20, !tbaa !24
  store i64 %t41, ptr %l17, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l17, !tbaa !24
  store i64 %t42, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/typed:ViewWalk", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Body", ptr %t64, i32 0, i32 5
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load ptr, ptr @__olang_prog_scope
  %t71 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %t68, ptr %t66, i64 %t67)
  store i32 %t71, ptr %l42
  br label %bb13
bb13:
  %t73 = load i32, ptr %l42, !tbaa !23
  %t75 = icmp eq i32 %t73, %a1
  br i1 %t75, label %bb14, label %bb15
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:ViewWalk", ptr %t77, i32 0, i32 2
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  store i64 %t81, ptr %l47, !tbaa !24
  %t82 = load i64, ptr %l47, !tbaa !24
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = shl i64 1, %t83
  %t87 = and i64 %t80, %t84
  %t89 = icmp ne i64 %t87, 0
  br i1 %t89, label %bb16, label %bb17
bb15:
  br label %bb19
bb16:
  %t91 = load i64, ptr %l7, !tbaa !24
  store i64 %t91, ptr %l52, !tbaa !24
  %t92 = load i64, ptr %l52, !tbaa !24
  %t93 = load i64, ptr %l52, !tbaa !24
  %t94 = shl i64 1, %t93
  store i64 %t94, ptr %l51, !tbaa !24
  br label %bb18
bb17:
  store i64 -1, ptr %l51, !tbaa !24
  br label %bb18
bb18:
  %t96 = load i64, ptr %l51, !tbaa !24
  store i64 %t96, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l6, !tbaa !24
  br label %bb9
bb21:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i1
  %l54 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2elocalRoots(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb40
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l25
  br label %bb13
bb13:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  br label %bb40
bb14:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 3
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t62 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  store i64 %t62, ptr %l34
  br label %bb20
bb20:
  %t63 = load i64, ptr %l34, !tbaa !24
  store i64 %t63, ptr %l7, !tbaa !24
  br label %bb40
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t65 = load ptr, ptr %l35, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 8}
  %t71 = icmp eq i64 %t69, 4
  store i1 %t71, ptr %l36, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l36, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Elem", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t79, ptr %t83)
  store i64 %t86, ptr %l44
  br label %bb27
bb27:
  %t87 = load i64, ptr %l44, !tbaa !24
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb40
bb28:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t89 = load ptr, ptr %l45, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb29, label %bb30
bb29:
  %t92 = load ptr, ptr %l45, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 8}
  %t95 = icmp eq i64 %t93, 5
  store i1 %t95, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t96 = load i1, ptr %l46, !tbaa !21
  br i1 %t96, label %bb31, label %bb32
bb31:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Payload", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t110 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t103, ptr %t107)
  store i64 %t110, ptr %l54
  br label %bb34
bb34:
  %t111 = load i64, ptr %l54, !tbaa !24
  store i64 %t111, ptr %l7, !tbaa !24
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_38f82f633fcbfe78_2a415e18f8868a4c)
  unreachable
bb40:
  %t112 = load i64, ptr %l7, !tbaa !24
  store i64 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %l54 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l69 = alloca i64
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca i1
  %l84 = alloca i1
  %l89 = alloca i64
  %l90 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca i1
  %l105 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l19
  br label %bb6
bb6:
  %t21 = load i64, ptr %l19, !tbaa !24
  store i64 %t21, ptr %l10, !tbaa !24
  br label %bb74
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l20, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l28
  br label %bb13
bb13:
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l10, !tbaa !24
  br label %bb74
bb14:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t44 = load ptr, ptr %l29, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l29, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 10
  store i1 %t50, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Slice", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t58, ptr %t62)
  store i64 %t65, ptr %l38
  br label %bb20
bb20:
  %t66 = load i64, ptr %l38, !tbaa !24
  store i64 %t66, ptr %l10, !tbaa !24
  br label %bb74
bb21:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t68 = load ptr, ptr %l39, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 18}
  %t74 = icmp eq i64 %t72, 5
  store i1 %t74, ptr %l40, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l40, !tbaa !21
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Promote", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t89 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2earrayValue(ptr %v0, ptr %v1, ptr %t82, ptr %t86)
  store i1 %t89, ptr %l48
  br label %bb27
bb27:
  %t90 = load i1, ptr %l48, !tbaa !21
  br i1 %t90, label %bb28, label %bb29
bb28:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l5, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Promote", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t99 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  store i64 %t99, ptr %l54
  br label %bb30
bb29:
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb31
bb30:
  %t100 = load i64, ptr %l54, !tbaa !24
  store i64 %t100, ptr %l49, !tbaa !24
  br label %bb31
bb31:
  %t101 = load i64, ptr %l49, !tbaa !24
  store i64 %t101, ptr %l10, !tbaa !24
  br label %bb74
bb32:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t103 = load ptr, ptr %l55, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb33, label %bb34
bb33:
  %t106 = load ptr, ptr %l55, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 18}
  %t109 = icmp eq i64 %t107, 9
  store i1 %t109, ptr %l56, !tbaa !21
  br label %bb34
bb34:
  %t110 = load i1, ptr %l56, !tbaa !21
  br i1 %t110, label %bb35, label %bb36
bb35:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t113, i32 0, i32 2
  %t115 = load i32, ptr %t114, !range !{i32 0, i32 44}
  store i32 %t115, ptr %l6
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t119, i32 0, i32 4
  %t121 = load { i64, ptr }, ptr %t120
  store { i64, ptr } %t121, ptr %l7, !tbaa !27
  br label %bb37
bb36:
  br label %bb46
bb37:
  %t123 = load i32, ptr %l6, !range !{i32 0, i32 44}
  %t125 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t123)
  store i1 %t125, ptr %l64
  br label %bb38
bb38:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb39, label %bb40
bb39:
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = icmp sgt i64 %t129, 0
  store i1 %t131, ptr %l65, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb41
bb41:
  %t133 = load i1, ptr %l65, !tbaa !21
  br i1 %t133, label %bb42, label %bb43
bb42:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t135, ptr %l71, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr ptr, ptr %t137, i64 0
  %t139 = load ptr, ptr %t138, !tbaa !39
  %t142 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t134, ptr %t139)
  store i64 %t142, ptr %l73
  br label %bb44
bb43:
  store i64 -1, ptr %l69, !tbaa !24
  br label %bb45
bb44:
  %t143 = load i64, ptr %l73, !tbaa !24
  store i64 %t143, ptr %l69, !tbaa !24
  br label %bb45
bb45:
  %t144 = load i64, ptr %l69, !tbaa !24
  store i64 %t144, ptr %l10, !tbaa !24
  br label %bb74
bb46:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t146 = load ptr, ptr %l74, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb47, label %bb48
bb47:
  %t149 = load ptr, ptr %l74, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 18}
  %t152 = icmp eq i64 %t150, 12
  store i1 %t152, ptr %l75, !tbaa !21
  br label %bb48
bb48:
  %t153 = load i1, ptr %l75, !tbaa !21
  br i1 %t153, label %bb49, label %bb50
bb49:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l8, !tbaa !29
  br label %bb51
bb50:
  br label %bb62
bb51:
  %t160 = load ptr, ptr %l8, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Seq", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb52, label %bb53
bb52:
  %t169 = load ptr, ptr %l8, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Seq", ptr %t169, i32 0, i32 0
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t176 = icmp eq i64 %t174, 0
  store i1 %t176, ptr %l84, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb54
bb54:
  %t178 = load i1, ptr %l84, !tbaa !21
  br i1 %t178, label %bb55, label %bb56
bb55:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l90, !tbaa !29
  %t180 = load ptr, ptr %l8, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Seq", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb57, label %bb58
bb56:
  store i64 -1, ptr %l89, !tbaa !24
  br label %bb61
bb57:
  call void @__olang_check_failed(ptr @olang_loc_859ef9a416eafd63_e1a98b601ef27d27)
  unreachable
bb58:
  br label %bb59
bb59:
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Seq", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load ptr, ptr %l90, !tbaa !29
  %t193 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t191, ptr %t190)
  store i64 %t193, ptr %l96
  br label %bb60
bb60:
  %t194 = load i64, ptr %l96, !tbaa !24
  store i64 %t194, ptr %l89, !tbaa !24
  br label %bb61
bb61:
  %t195 = load i64, ptr %l89, !tbaa !24
  store i64 %t195, ptr %l10, !tbaa !24
  br label %bb74
bb62:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t197 = load ptr, ptr %l97, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb63, label %bb64
bb63:
  %t200 = load ptr, ptr %l97, !tbaa !29
  %t201 = load i64, ptr %t200, !range !{i64 0, i64 18}
  %t203 = icmp eq i64 %t201, 17
  store i1 %t203, ptr %l98, !tbaa !21
  br label %bb64
bb64:
  %t204 = load i1, ptr %l98, !tbaa !21
  br i1 %t204, label %bb65, label %bb66
bb65:
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t207 = getelementptr { i64, [5 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t207, i32 0, i32 2
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l9, !tbaa !29
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l9, !tbaa !29
  %t215 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t211, ptr %t212)
  store i64 %t215, ptr %l105
  br label %bb68
bb68:
  %t216 = load i64, ptr %l105, !tbaa !24
  store i64 %t216, ptr %l10, !tbaa !24
  br label %bb74
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_21fa85d53b5eac7b_5a0125da6c5c013f)
  unreachable
bb74:
  %t217 = load i64, ptr %l10, !tbaa !24
  store i64 %t217, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eresultLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l19 = alloca %"compiler/typed:Local"
  %l24 = alloca i1
  %l28 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l41 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l57 = alloca i1
  %l61 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i64
  %l89 = alloca i64
  %l98 = alloca i1
  %l106 = alloca i64
  %l108 = alloca i64
  %l113 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %t8, ptr %t6, i64 %t7)
  store %"compiler/typed:Local" %t11, ptr %l19
  br label %bb1
bb1:
  %t12 = load %"compiler/typed:Local", ptr %l19
  store %"compiler/typed:Local" %t12, ptr %l4
  %t13 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 7}
  store i32 %t14, ptr %l5
  %t16 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t18 = trunc i64 1 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t25 = trunc i64 3 to i32
  %t26 = icmp eq i32 %t23, %t25
  %t28 = xor i1 %t26, true
  store i1 %t28, ptr %l24, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb4
bb4:
  %t30 = load i1, ptr %l24, !tbaa !21
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t31 = load i32, ptr %l5, !range !{i32 0, i32 7}
  %t33 = trunc i64 6 to i32
  %t34 = icmp eq i32 %t31, %t33
  %t36 = xor i1 %t34, true
  store i1 %t36, ptr %l28, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i1, ptr %l28, !tbaa !21
  br i1 %t38, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:ViewWalk", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = load ptr, ptr @__olang_prog_scope
  %t49 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t46, ptr %t43, i32 %t45)
  store i1 %t49, ptr %l36
  br label %bb11
bb11:
  %t50 = load i1, ptr %l36, !tbaa !21
  br i1 %t50, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb15
bb13:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/typed:ViewWalk", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load ptr, ptr @__olang_prog_scope
  %t60 = call i1 @compiler_2ftyped_2eHoldsOwned(ptr %t57, ptr %t54, i32 %t56)
  store i1 %t60, ptr %l41
  br label %bb14
bb14:
  %t61 = load i1, ptr %l41, !tbaa !21
  %t62 = xor i1 %t61, true
  store i1 %t62, ptr %l37, !tbaa !21
  br label %bb15
bb15:
  %t64 = load i1, ptr %l37, !tbaa !21
  br i1 %t64, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/typed:LocalUses", ptr %t66, i32 0, i32 5
  %t69 = load i64, ptr %l2, !tbaa !24
  %t72 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t68, i64 %t69)
  store i1 %t72, ptr %l47
  br label %bb19
bb19:
  %t73 = load i1, ptr %l47, !tbaa !21
  br i1 %t73, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb23
bb21:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/typed:LocalUses", ptr %t74, i32 0, i32 2
  %t77 = load i64, ptr %l2, !tbaa !24
  %t80 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t76, i64 %t77)
  store i1 %t80, ptr %l52
  br label %bb22
bb22:
  %t81 = load i1, ptr %l52, !tbaa !21
  store i1 %t81, ptr %l48, !tbaa !21
  br label %bb23
bb23:
  %t82 = load i1, ptr %l48, !tbaa !21
  br i1 %t82, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb27
bb25:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/typed:LocalUses", ptr %t83, i32 0, i32 4
  %t86 = load i64, ptr %l2, !tbaa !24
  %t89 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t85, i64 %t86)
  store i1 %t89, ptr %l57
  br label %bb26
bb26:
  %t90 = load i1, ptr %l57, !tbaa !21
  store i1 %t90, ptr %l53, !tbaa !21
  br label %bb27
bb27:
  %t91 = load i1, ptr %l53, !tbaa !21
  br i1 %t91, label %bb28, label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  store i64 0, ptr %l6, !tbaa !24
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/typed:LocalUses", ptr %t93, i32 0, i32 12
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t95)
  store i64 %t97, ptr %l61
  br label %bb31
bb31:
  %t98 = load i64, ptr %l61, !tbaa !24
  store i64 %t98, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = icmp sgt i64 %t99, %t100
  br i1 %t103, label %bb32, label %bb33
bb32:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb37
bb34:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t110 = load i64, ptr %l6, !tbaa !24
  %t113 = sub i64 %t109, %t110
  %t114 = load i64, ptr %l8, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = sub i64 %t117, 1
  %t120 = load i64, ptr %l8, !tbaa !24
  %t123 = sdiv i64 %t119, %t120
  store i64 %t123, ptr %l68, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb36
bb36:
  %t125 = load i64, ptr %l68, !tbaa !24
  store i64 %t125, ptr %l65, !tbaa !24
  br label %bb37
bb37:
  %t126 = load i64, ptr %l65, !tbaa !24
  store i64 %t126, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb38
bb38:
  %t127 = load i64, ptr %l10, !tbaa !24
  %t128 = load i64, ptr %l9, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb39, label %bb40
bb39:
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t135 = load i64, ptr %l6, !tbaa !24
  %t136 = load i64, ptr %l10, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t140 = mul i64 %t136, %t137
  %t143 = add i64 %t135, %t140
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr %"compiler/typed:LocalUses", ptr %t145, i32 0, i32 12
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t147, i64 %t143)
  store i64 %t151, ptr %l89
  br label %bb42
bb42:
  %t152 = load i64, ptr %l2, !tbaa !24
  %t153 = load i64, ptr %l89, !tbaa !24
  %t155 = icmp eq i64 %t153, %t152
  br i1 %t155, label %bb43, label %bb44
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t158 = load i64, ptr %l10, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l10, !tbaa !24
  br label %bb38
bb47:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr %"compiler/typed:LocalUses", ptr %t162, i32 0, i32 7
  %t165 = load i64, ptr %l2, !tbaa !24
  %t168 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t164, i64 %t165)
  store i1 %t168, ptr %l98
  br label %bb48
bb48:
  %t169 = load i1, ptr %l98, !tbaa !21
  br i1 %t169, label %bb49, label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t173 = xor i1 %a3, true
  br i1 %t173, label %bb52, label %bb53
bb52:
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/typed:ViewWalk", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/typed:Body", ptr %t179, i32 0, i32 10
  store ptr %t181, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb55
bb55:
  %t183 = load i64, ptr %l13, !tbaa !24
  store i64 %t183, ptr %l106, !tbaa !24
  %t184 = load ptr, ptr %l12, !tbaa !29
  %t185 = load ptr, ptr @__olang_prog_scope
  %t187 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %t185, ptr %t184)
  store i64 %t187, ptr %l108
  br label %bb56
bb56:
  %t188 = load i64, ptr %l106, !tbaa !24
  %t189 = load i64, ptr %l108, !tbaa !24
  %t190 = icmp slt i64 %t188, %t189
  %t192 = xor i1 %t190, true
  br i1 %t192, label %bb57, label %bb58
bb57:
  br label %bb65
bb58:
  br label %bb59
bb59:
  %t194 = load ptr, ptr %l12, !tbaa !29
  %t195 = load i64, ptr %l13, !tbaa !24
  %t196 = load ptr, ptr @__olang_prog_scope
  %t199 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %t196, ptr %t194, i64 %t195)
  store i32 %t199, ptr %l113
  br label %bb60
bb60:
  %t200 = load i32, ptr %l113, !tbaa !23
  %t203 = sext i32 %t200 to i64
  %t204 = load i64, ptr %l2, !tbaa !24
  %t207 = icmp eq i64 %t203, %t204
  br i1 %t207, label %bb61, label %bb62
bb61:
  store i1 true, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t210 = load i64, ptr %l13, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l13, !tbaa !24
  br label %bb55
bb65:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2etryRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l23 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Try", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load i64, ptr %l14, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Try", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  %t37 = getelementptr %"compiler/typed:Clause", ptr %t33, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l9, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t52 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t52, ptr %l34, !tbaa !27
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr ptr, ptr %t56, i64 %t53
  %t58 = load ptr, ptr %t57, !tbaa !39
  %t60 = load i64, ptr %l2, !tbaa !24
  store i64 %t60, ptr %l37, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t61, ptr %t58)
  store i64 %t66, ptr %l41
  br label %bb10
bb10:
  %t67 = load i64, ptr %l37, !tbaa !24
  %t68 = load i64, ptr %l41, !tbaa !24
  %t69 = call i64 @compiler_2ftyped_2emeetRoots(i64 %t67, i64 %t68)
  store i64 %t69, ptr %l42
  br label %bb11
bb11:
  %t70 = load i64, ptr %l42, !tbaa !24
  store i64 %t70, ptr %l2, !tbaa !24
  br label %bb12
bb12:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l8, !tbaa !24
  br label %bb6
bb13:
  br label %bb14
bb14:
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l4, !tbaa !24
  br label %bb2
bb15:
  %t79 = load i64, ptr %l2, !tbaa !24
  store i64 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca i1
  %l52 = alloca i1
  %l62 = alloca i1
  %l89 = alloca { i64, ptr }
  %l106 = alloca i64
  %l108 = alloca i64
  %l113 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t7 = load ptr, ptr %l27, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l27, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l28, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l28, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  br label %bb6
bb6:
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_5f0c96ba8f37c420_5ca612e1d5c707f4)
  unreachable
bb12:
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l36
  br label %bb13
bb13:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l4
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Call", ptr %t28, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb15, label %bb16
bb15:
  br label %bb39
bb16:
  br label %bb17
bb17:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t45, ptr %l45, !tbaa !27
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  store ptr %t51, ptr %l8, !tbaa !29
  %t53 = load ptr, ptr %l8, !tbaa !29
  store ptr %t53, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t54 = load ptr, ptr %l48, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l48, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 12
  store i1 %t60, ptr %l49, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l49, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l8, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  store %"compiler/source:Span" %t66, ptr %l9
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l10, !tbaa !23
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  %t83 = getelementptr %"compiler/typed:Seq", ptr %t78, i32 0, i32 2
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l52, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l52, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t87 = load ptr, ptr %l8, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l12
  %t93 = load ptr, ptr %l8, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 1
  %t97 = load i32, ptr %t96
  store i32 %t97, ptr %l13, !tbaa !23
  %t99 = load ptr, ptr %l8, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  %t108 = getelementptr %"compiler/typed:Seq", ptr %t103, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = icmp eq ptr %t109, null
  %t113 = xor i1 %t111, true
  store i1 %t113, ptr %l62, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb25
bb25:
  %t115 = load i1, ptr %l62, !tbaa !21
  br i1 %t115, label %bb26, label %bb27
bb26:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = getelementptr { i64, [5 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t118, i32 0, i32 0
  %t120 = load %"compiler/source:Span", ptr %t119
  store %"compiler/source:Span" %t120, ptr %l15
  %t122 = load ptr, ptr %l8, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 1
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l16, !tbaa !23
  %t128 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t130, i32 0, i32 2
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l17, !tbaa !29
  %t134 = load ptr, ptr %l17, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Seq", ptr %t134, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l20, !tbaa !24
  br label %bb28
bb27:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t144, ptr %t145)
  br label %bb36
bb28:
  %t149 = load i64, ptr %l19, !tbaa !24
  %t150 = load i64, ptr %l20, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb29, label %bb30
bb29:
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t157 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t157, ptr %l89, !tbaa !27
  %t158 = load i64, ptr %l19, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr ptr, ptr %t161, i64 %t158
  %t163 = load ptr, ptr %t162, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %s0, ptr %v1, ptr %l4, ptr %t163)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t168 = load i64, ptr %l19, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l19, !tbaa !24
  br label %bb28
bb34:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l17, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Seq", ptr %t173, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t172, ptr %t177)
  br label %bb35
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t180 = load i64, ptr %l6, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l6, !tbaa !24
  br label %bb14
bb39:
  store ptr %l4, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb40
bb40:
  %t185 = load i64, ptr %l23, !tbaa !24
  store i64 %t185, ptr %l106, !tbaa !24
  %t186 = load ptr, ptr %l22, !tbaa !29
  %t188 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %s0, ptr %t186)
  store i64 %t188, ptr %l108
  br label %bb41
bb41:
  %t189 = load i64, ptr %l106, !tbaa !24
  %t190 = load i64, ptr %l108, !tbaa !24
  %t191 = icmp slt i64 %t189, %t190
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb42, label %bb43
bb42:
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t195 = load ptr, ptr %l22, !tbaa !29
  %t196 = load i64, ptr %l23, !tbaa !24
  %t199 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %s0, ptr %s0, ptr %t195, i64 %t196)
  store ptr %t199, ptr %l113
  br label %bb45
bb45:
  %t200 = load ptr, ptr %l113, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %s0, ptr %t201, ptr %t200)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t205 = load i64, ptr %l23, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l23, !tbaa !24
  br label %bb40
bb48:
  %t209 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t209, i1 false)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l70 = alloca i64
  %l73 = alloca i64
  %l92 = alloca ptr
  %l95 = alloca i64
  %l101 = alloca i1
  %l102 = alloca i1
  %l106 = alloca i1
  %l117 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:dropWalk", ptr %t6, i32 0, i32 2
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l21
  br label %bb4
bb4:
  %t11 = load i64, ptr %l21, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  store i1 %a1, ptr %l3, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 12
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l25
  br label %bb5
bb5:
  %t19 = load i64, ptr %l25, !tbaa !24
  %t20 = icmp sgt i64 %t19, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l27, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/typed:dropWalk", ptr %t23, i32 0, i32 12
  store ptr %t25, ptr %l29, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:dropWalk", ptr %t26, i32 0, i32 12
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l32
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t31 = load i64, ptr %l32, !tbaa !24
  %t32 = sub i64 %t31, 1
  %t33 = load ptr, ptr %l29, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t33, i64 %t32)
  store i64 %t35, ptr %l34
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l27, !tbaa !29
  %t37 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t36, i64 %t37)
  br label %bb10
bb10:
  br label %bb11
bb11:
  store i64 0, ptr %l4, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:dropWalk", ptr %t38, i32 0, i32 11
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t40)
  store i64 %t42, ptr %l37
  br label %bb12
bb12:
  %t43 = load i64, ptr %l37, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp sgt i64 %t44, %t45
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp sgt i64 %t50, 0
  br i1 %t52, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb18
bb15:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = sub i64 %t54, %t55
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = add i64 %t58, %t59
  %t64 = sub i64 %t62, 1
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = sdiv i64 %t64, %t65
  store i64 %t68, ptr %l44, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb17
bb17:
  %t70 = load i64, ptr %l44, !tbaa !24
  store i64 %t70, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t71 = load i64, ptr %l41, !tbaa !24
  store i64 %t71, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb19
bb19:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb20, label %bb21
bb20:
  br label %bb47
bb21:
  br label %bb22
bb22:
  %t80 = load i64, ptr %l4, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = mul i64 %t81, %t82
  %t88 = add i64 %t80, %t85
  store i64 %t88, ptr %l9, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l2, !tbaa !24
  %t93 = add i64 %t91, 1
  %t96 = mul i64 %t90, %t93
  store i64 %t96, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l2, !tbaa !24
  store i64 %t98, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load i64, ptr %l13, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb28
bb25:
  %t110 = load i64, ptr %l12, !tbaa !24
  %t111 = load i64, ptr %l11, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l73, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb27
bb27:
  %t126 = load i64, ptr %l73, !tbaa !24
  store i64 %t126, ptr %l70, !tbaa !24
  br label %bb28
bb28:
  %t127 = load i64, ptr %l70, !tbaa !24
  store i64 %t127, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb29
bb29:
  %t128 = load i64, ptr %l15, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb30, label %bb31
bb30:
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t136 = load i64, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l15, !tbaa !24
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = mul i64 %t137, %t138
  %t144 = add i64 %t136, %t141
  store i64 %t144, ptr %l16, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/typed:dropWalk", ptr %t146, i32 0, i32 13
  store ptr %t148, ptr %l92, !tbaa !29
  %t149 = load i64, ptr %l10, !tbaa !24
  %t150 = load i64, ptr %l16, !tbaa !24
  %t153 = add i64 %t149, %t150
  store i64 %t153, ptr %l95, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/typed:dropWalk", ptr %t154, i32 0, i32 13
  %t157 = load i64, ptr %l10, !tbaa !24
  %t158 = load i64, ptr %l16, !tbaa !24
  %t161 = add i64 %t157, %t158
  %t164 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t156, i64 %t161)
  store i1 %t164, ptr %l101
  br label %bb33
bb33:
  %t165 = load i1, ptr %l101, !tbaa !21
  br i1 %t165, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb37
bb35:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/typed:dropWalk", ptr %t166, i32 0, i32 2
  %t169 = load i64, ptr %l16, !tbaa !24
  %t172 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t168, i64 %t169)
  store i1 %t172, ptr %l106
  br label %bb36
bb36:
  %t173 = load i1, ptr %l106, !tbaa !21
  store i1 %t173, ptr %l102, !tbaa !21
  br label %bb37
bb37:
  %t174 = load ptr, ptr %l92, !tbaa !29
  %t175 = load i64, ptr %l95, !tbaa !24
  %t176 = load i1, ptr %l102, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t174, i64 %t175, i1 %t176)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t177 = load i64, ptr %l15, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l15, !tbaa !24
  br label %bb29
bb40:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/typed:dropWalk", ptr %t181, i32 0, i32 13
  %t184 = load i64, ptr %l10, !tbaa !24
  %t185 = load i64, ptr %l2, !tbaa !24
  %t188 = add i64 %t184, %t185
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t183, i64 %t188, i1 false)
  br label %bb41
bb41:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/typed:dropWalk", ptr %t191, i32 0, i32 11
  %t194 = load i64, ptr %l9, !tbaa !24
  %t197 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t193, i64 %t194)
  store i1 %t197, ptr %l117
  br label %bb42
bb42:
  %t198 = load i1, ptr %l117, !tbaa !21
  br i1 %t198, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t199 = load i64, ptr %l8, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l8, !tbaa !24
  br label %bb19
bb47:
  %t203 = load i1, ptr %l3, !tbaa !21
  br i1 %t203, label %bb48, label %bb49
bb48:
  %t205 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t205, i64 -1)
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l8, !tbaa !27
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:dropWalk", ptr %t2, i32 0, i32 2
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l11
  br label %bb1
bb1:
  %t7 = load i64, ptr %l11, !tbaa !24
  %t8 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i1, ptr %t9, i64 %t7
  %t11 = load i1, ptr %t10, !tbaa !31
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 3
  %t16 = load i1, ptr %t15, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %v1, ptr %t18, { i64, ptr } %t19)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %ret
bb8:
  store i64 0, ptr %l2, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:dropWalk", ptr %t22, i32 0, i32 2
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l19
  br label %bb9
bb9:
  %t27 = load i64, ptr %l19, !tbaa !24
  store i64 %t27, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb15
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l2, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l26, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb14
bb14:
  %t54 = load i64, ptr %l26, !tbaa !24
  store i64 %t54, ptr %l23, !tbaa !24
  br label %bb15
bb15:
  %t55 = load i64, ptr %l23, !tbaa !24
  store i64 %t55, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb17, label %bb18
bb17:
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l4, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l7, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:dropWalk", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l45, !tbaa !29
  %t77 = load i64, ptr %l7, !tbaa !24
  store i64 %t77, ptr %l46, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:dropWalk", ptr %t78, i32 0, i32 2
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t80, i64 %t81)
  store i1 %t84, ptr %l50
  br label %bb20
bb20:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb22:
  %t86 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t86, ptr %l52, !tbaa !27
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i1, ptr %t90, i64 %t87
  %t92 = load i1, ptr %t91, !tbaa !31
  store i1 %t92, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = load i64, ptr %l46, !tbaa !24
  %t96 = load i1, ptr %l51, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t94, i64 %t95, i1 %t96)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l6, !tbaa !24
  br label %bb16
bb26:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l14 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 7
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:dropWalk", ptr %t15, i32 0, i32 7
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l14
  br label %bb6
bb6:
  %t23 = load i32, ptr %l14, !tbaa !23
  %t25 = icmp ne i32 %t23, %a2
  br i1 %t25, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l17, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:dropWalk", ptr %t28, i32 0, i32 8
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t31)
  store i64 %t34, ptr %l21
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t35, i64 %t36)
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t40 = trunc i64 0 to i32
  %t41 = icmp eq i32 %a1, %t40
  %t42 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ekeepFor(ptr %v0, ptr %t37, i1 %t41, i64 %t42)
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = sub i64 %t46, 1
  store i64 %t48, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/typed:dropWalk", ptr %t50, i32 0, i32 3
  store i1 true, ptr %t52, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ekeepFor(ptr %v0, ptr %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca i1
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = add i64 %t8, 1
  %t13 = mul i64 %a2, %t10
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l25, !tbaa !24
  store i64 %t43, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l22, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:dropWalk", ptr %t63, i32 0, i32 2
  %t66 = load i64, ptr %l10, !tbaa !24
  %t69 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t65, i64 %t66)
  store i1 %t69, ptr %l46
  br label %bb12
bb12:
  %t70 = load i1, ptr %l46, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t73 = load i1, ptr %l1, !tbaa !21
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/typed:dropWalk", ptr %t75, i32 0, i32 9
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = add i64 %t78, %t79
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t77, i64 %t82, i1 true)
  br label %bb18
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:dropWalk", ptr %t85, i32 0, i32 10
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = add i64 %t88, %t89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t87, i64 %t92, i1 true)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t95 = load i64, ptr %l9, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l9, !tbaa !24
  br label %bb8
bb22:
  %t99 = load i1, ptr %l1, !tbaa !21
  br i1 %t99, label %bb23, label %bb24
bb23:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/typed:dropWalk", ptr %t101, i32 0, i32 9
  %t104 = load i64, ptr %l4, !tbaa !24
  %t105 = load i64, ptr %l3, !tbaa !24
  %t108 = add i64 %t104, %t105
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t103, i64 %t108, i1 false)
  br label %bb25
bb24:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/typed:dropWalk", ptr %t111, i32 0, i32 10
  %t114 = load i64, ptr %l4, !tbaa !24
  %t115 = load i64, ptr %l3, !tbaa !24
  %t118 = add i64 %t114, %t115
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t113, i64 %t118, i1 false)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l89 = alloca i64
  %l92 = alloca i64
  %l126 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l142 = alloca i32
  %l145 = alloca i32
  %l146 = alloca i32
  %l150 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i32
  %l163 = alloca i64
  %l166 = alloca i64
  %l184 = alloca i1
  %l187 = alloca i1
  %l188 = alloca i32
  %l192 = alloca i1
  %l195 = alloca i1
  %l196 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i64, ptr %l26, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:dropWalk", ptr %t7, i32 0, i32 7
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l29
  br label %bb2
bb2:
  %t12 = load i64, ptr %l29, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 7
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Block", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t15, i32 %t19)
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:dropWalk", ptr %t22, i32 0, i32 8
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/typed:dropWalk", ptr %t25, i32 0, i32 4
  %t28 = load i64, ptr %t27, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t24, i64 %t28)
  br label %bb4
bb4:
  store i64 0, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp sgt i64 %t35, %t36
  br i1 %t39, label %bb5, label %bb6
bb5:
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb10
bb7:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = sub i64 %t45, %t46
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = add i64 %t49, %t50
  %t55 = sub i64 %t53, 1
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = sdiv i64 %t55, %t56
  store i64 %t59, ptr %l46, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb9
bb9:
  %t61 = load i64, ptr %l46, !tbaa !24
  store i64 %t61, ptr %l43, !tbaa !24
  br label %bb10
bb10:
  %t62 = load i64, ptr %l43, !tbaa !24
  store i64 %t62, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = mul i64 %t72, %t73
  %t79 = add i64 %t71, %t76
  store i64 %t79, ptr %l10, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:dropWalk", ptr %t81, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t83, i1 false)
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:dropWalk", ptr %t85, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t87, i1 false)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l9, !tbaa !24
  br label %bb11
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:dropWalk", ptr %t93, i32 0, i32 9
  %t96 = load i64, ptr %l4, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  %t99 = add i64 %t97, 1
  %t102 = mul i64 %t96, %t99
  %t103 = load i64, ptr %l3, !tbaa !24
  %t106 = add i64 %t102, %t103
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t95, i64 %t106, i1 true)
  br label %bb19
bb19:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s0, ptr %t109)
  store { i64, ptr } %t111, ptr %l79
  br label %bb20
bb20:
  %t112 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  store i64 %t113, ptr %l80, !tbaa !24
  %t114 = load i64, ptr %l80, !tbaa !24
  %t115 = mul i64 %t114, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  %t117 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l81, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = load i64, ptr %l80, !tbaa !24
  %t124 = mul i64 %t123, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t120, ptr %t122, i64 %t124, i1 false)
  %t125 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t125, ptr %l11, !tbaa !27
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t126, { i64, ptr } %t127)
  br label %bb22
bb22:
  store i64 0, ptr %l12, !tbaa !24
  %t130 = load i64, ptr %l3, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb23, label %bb24
bb23:
  %t140 = load i64, ptr %l14, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb28
bb25:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l14, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l92, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb27
bb27:
  %t160 = load i64, ptr %l92, !tbaa !24
  store i64 %t160, ptr %l89, !tbaa !24
  br label %bb28
bb28:
  %t161 = load i64, ptr %l89, !tbaa !24
  store i64 %t161, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb29
bb29:
  %t162 = load i64, ptr %l16, !tbaa !24
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb30, label %bb31
bb30:
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l17, !tbaa !24
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/typed:dropWalk", ptr %t180, i32 0, i32 10
  %t183 = load i64, ptr %l4, !tbaa !24
  %t184 = load i64, ptr %l3, !tbaa !24
  %t186 = add i64 %t184, 1
  %t189 = mul i64 %t183, %t186
  %t190 = load i64, ptr %l17, !tbaa !24
  %t193 = add i64 %t189, %t190
  %t194 = load i64, ptr %l17, !tbaa !24
  %t195 = load i64, ptr %l3, !tbaa !24
  %t198 = icmp eq i64 %t194, %t195
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t182, i64 %t193, i1 %t198)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t202 = load i64, ptr %l16, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l16, !tbaa !24
  br label %bb29
bb35:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t206, ptr %t207)
  br label %bb36
bb36:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l126, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l4, !tbaa !24
  %t216 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloopState(ptr %v0, ptr %s4, ptr %t212, i1 false, i64 %t213)
  store { i64, ptr } %t216, ptr %l129
  br label %bb37
bb37:
  %t217 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 0
  %t219 = extractvalue { i64, ptr } %t217, 1
  %t220 = mul i64 %t218, 1
  %t221 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t220)
  call void @llvm.memcpy.p0.p0.i64(ptr %t221, ptr %t219, i64 %t220, i1 false)
  %t222 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  %t224 = load ptr, ptr %l126, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s4, ptr %t224, { i64, ptr } %t223)
  br label %bb38
bb38:
  %t226 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v2, ptr %t226, ptr %a2)
  br label %bb39
bb39:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t234 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ewiden(ptr %v0, ptr %s0, ptr %t230, { i64, ptr } %t231)
  store i64 %t234, ptr %l135
  br label %bb40
bb40:
  %t235 = load i64, ptr %l135, !tbaa !24
  %t236 = icmp eq i64 %t235, 0
  br i1 %t236, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb44:
  br label %bb21
bb45:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l137, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i64, ptr %l4, !tbaa !24
  %t243 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloopState(ptr %v0, ptr %s0, ptr %t239, i1 true, i64 %t240)
  store { i64, ptr } %t243, ptr %l140
  br label %bb46
bb46:
  %t244 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t251 = load ptr, ptr %l137, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s0, ptr %t251, { i64, ptr } %t250)
  br label %bb47
bb47:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/typed:dropWalk", ptr %t253, i32 0, i32 7
  %t257 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t255)
  %t258 = extractvalue { i32, i32 } %t257, 1
  %t259 = extractvalue { i32, i32 } %t257, 0
  store i32 %t259, ptr %l146
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb49, label %ok.261, !prof !99
ok.261:
  store i32 %t258, ptr %l145
  br label %bb48
bb48:
  %t262 = load i32, ptr %l145, !tbaa !23
  store i32 %t262, ptr %l142, !tbaa !23
  br label %bb56
bb49:
  %t263 = load i32, ptr %l146, !tbaa !23
  %t264 = icmp eq i32 %t263, 65536
  br i1 %t264, label %bb50, label %bb51
bb50:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1a9a85648681e97_fcf9d2fab7c32a6b)
  unreachable
bb51:
  %t266 = load i32, ptr %l146, !tbaa !23
  %t267 = icmp eq i32 %t266, 65537
  br i1 %t267, label %bb52, label %bb53
bb52:
  call void @__olang_bang_failed_plain(ptr @olang_loc_54fd08b205476dc4_657f8db756d05b08)
  unreachable
bb53:
  %t269 = load i32, ptr %l146, !tbaa !23
  %t270 = icmp eq i32 %t269, 65538
  br i1 %t270, label %bb54, label %bb55
bb54:
  call void @__olang_bang_failed_plain(ptr @olang_loc_923c0e7922172d2c_3d5b7ddd1cd85e60)
  unreachable
bb55:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3398753e62525e0a_a26aec7fb7dfed8e)
  unreachable
bb56:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/typed:dropWalk", ptr %t272, i32 0, i32 8
  %t276 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t274)
  %t277 = extractvalue { i32, i64 } %t276, 1
  %t278 = extractvalue { i32, i64 } %t276, 0
  store i32 %t278, ptr %l154
  %t279 = icmp ne i32 %t278, 0
  br i1 %t279, label %bb58, label %ok.280, !prof !99
ok.280:
  store i64 %t277, ptr %l153
  br label %bb57
bb57:
  %t281 = load i64, ptr %l153, !tbaa !24
  store i64 %t281, ptr %l150, !tbaa !24
  br label %bb65
bb58:
  %t282 = load i32, ptr %l154, !tbaa !23
  %t283 = icmp eq i32 %t282, 65536
  br i1 %t283, label %bb59, label %bb60
bb59:
  call void @__olang_bang_failed_plain(ptr @olang_loc_8b9fe86f9939495b_ac6312ba480f0d67)
  unreachable
bb60:
  %t285 = load i32, ptr %l154, !tbaa !23
  %t286 = icmp eq i32 %t285, 65537
  br i1 %t286, label %bb61, label %bb62
bb61:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3f464ddbb91b0a38_82918aeeacdcc614)
  unreachable
bb62:
  %t288 = load i32, ptr %l154, !tbaa !23
  %t289 = icmp eq i32 %t288, 65538
  br i1 %t289, label %bb63, label %bb64
bb63:
  call void @__olang_bang_failed_plain(ptr @olang_loc_29167372d5c184b0_5aaac5f2b3f16f1c)
  unreachable
bb64:
  call void @__olang_bang_failed_plain(ptr @olang_loc_18d2a0b724f39c7e_37ab118f04dce49a)
  unreachable
bb65:
  store i64 0, ptr %l18, !tbaa !24
  %t291 = load i64, ptr %l3, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t295 = load i64, ptr %l19, !tbaa !24
  %t296 = load i64, ptr %l18, !tbaa !24
  %t299 = icmp sgt i64 %t295, %t296
  br i1 %t299, label %bb66, label %bb67
bb66:
  %t301 = load i64, ptr %l20, !tbaa !24
  %t303 = icmp sgt i64 %t301, 0
  br i1 %t303, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb71
bb68:
  %t305 = load i64, ptr %l19, !tbaa !24
  %t306 = load i64, ptr %l18, !tbaa !24
  %t309 = sub i64 %t305, %t306
  %t310 = load i64, ptr %l20, !tbaa !24
  %t313 = add i64 %t309, %t310
  %t315 = sub i64 %t313, 1
  %t316 = load i64, ptr %l20, !tbaa !24
  %t319 = sdiv i64 %t315, %t316
  store i64 %t319, ptr %l166, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb70
bb70:
  %t321 = load i64, ptr %l166, !tbaa !24
  store i64 %t321, ptr %l163, !tbaa !24
  br label %bb71
bb71:
  %t322 = load i64, ptr %l163, !tbaa !24
  store i64 %t322, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb72
bb72:
  %t323 = load i64, ptr %l22, !tbaa !24
  %t324 = load i64, ptr %l21, !tbaa !24
  %t327 = icmp slt i64 %t323, %t324
  %t329 = xor i1 %t327, true
  br i1 %t329, label %bb73, label %bb74
bb73:
  br label %bb95
bb74:
  br label %bb75
bb75:
  %t331 = load i64, ptr %l18, !tbaa !24
  %t332 = load i64, ptr %l22, !tbaa !24
  %t333 = load i64, ptr %l20, !tbaa !24
  %t336 = mul i64 %t332, %t333
  %t339 = add i64 %t331, %t336
  store i64 %t339, ptr %l23, !tbaa !24
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/typed:dropWalk", ptr %t341, i32 0, i32 9
  %t345 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t343)
  %t346 = extractvalue { i32, i1 } %t345, 1
  %t347 = extractvalue { i32, i1 } %t345, 0
  store i32 %t347, ptr %l188
  %t348 = icmp ne i32 %t347, 0
  br i1 %t348, label %bb77, label %ok.349, !prof !99
ok.349:
  store i1 %t346, ptr %l187
  br label %bb76
bb76:
  %t350 = load i1, ptr %l187, !tbaa !21
  store i1 %t350, ptr %l184, !tbaa !21
  br label %bb84
bb77:
  %t351 = load i32, ptr %l188, !tbaa !23
  %t352 = icmp eq i32 %t351, 65536
  br i1 %t352, label %bb78, label %bb79
bb78:
  call void @__olang_bang_failed_plain(ptr @olang_loc_fb0720d2dfee7f_1f99818eb62f02f3)
  unreachable
bb79:
  %t354 = load i32, ptr %l188, !tbaa !23
  %t355 = icmp eq i32 %t354, 65537
  br i1 %t355, label %bb80, label %bb81
bb80:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3cd7aa482e25463c_a46dd5e6d10de4a0)
  unreachable
bb81:
  %t357 = load i32, ptr %l188, !tbaa !23
  %t358 = icmp eq i32 %t357, 65538
  br i1 %t358, label %bb82, label %bb83
bb82:
  call void @__olang_bang_failed_plain(ptr @olang_loc_65fecb72da6e9be9_e6833fce5f1f4ea5)
  unreachable
bb83:
  call void @__olang_bang_failed_plain(ptr @olang_loc_313fe9555679a06f_fa589a226c49c6eb)
  unreachable
bb84:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/typed:dropWalk", ptr %t360, i32 0, i32 10
  %t364 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t362)
  %t365 = extractvalue { i32, i1 } %t364, 1
  %t366 = extractvalue { i32, i1 } %t364, 0
  store i32 %t366, ptr %l196
  %t367 = icmp ne i32 %t366, 0
  br i1 %t367, label %bb86, label %ok.368, !prof !99
ok.368:
  store i1 %t365, ptr %l195
  br label %bb85
bb85:
  %t369 = load i1, ptr %l195, !tbaa !21
  store i1 %t369, ptr %l192, !tbaa !21
  br label %bb93
bb86:
  %t370 = load i32, ptr %l196, !tbaa !23
  %t371 = icmp eq i32 %t370, 65536
  br i1 %t371, label %bb87, label %bb88
bb87:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f3df993f4c7e1fd4_8419908bae6ac650)
  unreachable
bb88:
  %t373 = load i32, ptr %l196, !tbaa !23
  %t374 = icmp eq i32 %t373, 65537
  br i1 %t374, label %bb89, label %bb90
bb89:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e306d5ccad957c29_6b95b0de26f94a45)
  unreachable
bb90:
  %t376 = load i32, ptr %l196, !tbaa !23
  %t377 = icmp eq i32 %t376, 65538
  br i1 %t377, label %bb91, label %bb92
bb91:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d73b6870bbe51a4d_d845c63f23993221)
  unreachable
bb92:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2545ce011bc2e3f3_a4cac8bc0a2d8747)
  unreachable
bb93:
  br label %bb94
bb94:
  %t379 = load i64, ptr %l22, !tbaa !24
  %t381 = add i64 %t379, 1
  store i64 %t381, ptr %l22, !tbaa !24
  br label %bb72
bb95:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l47 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:dropWalk", ptr %t53, i32 0, i32 2
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t57, ptr %l38, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i1, ptr %t61, i64 %t58
  %t63 = load i1, ptr %t62, !tbaa !31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t55, i64 %t56, i1 %t63)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t67 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l43, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t72, ptr %l44, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/typed:dropWalk", ptr %t73, i32 0, i32 2
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t75)
  store i64 %t77, ptr %l47
  br label %bb15
bb15:
  %t78 = load i64, ptr %l47, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i1, ptr %t80, i64 %t78
  %t82 = load i1, ptr %t81, !tbaa !31
  %t84 = load ptr, ptr %l43, !tbaa !29
  %t85 = getelementptr %"compiler/typed:dropWalk", ptr %t84, i32 0, i32 3
  store i1 %t82, ptr %t85, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l168 = alloca { i64, ptr }
  %l169 = alloca i64
  %l170 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l177 = alloca i64
  %l178 = alloca { i64, ptr }
  %l186 = alloca ptr
  %l187 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i1
  %l208 = alloca ptr
  %l209 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca i1
  %l225 = alloca i64
  %l228 = alloca i1
  %l232 = alloca i1
  %l239 = alloca i1
  %l243 = alloca i1
  %l251 = alloca ptr
  %l252 = alloca i1
  %l265 = alloca { i64, ptr }
  %l266 = alloca i64
  %l267 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l281 = alloca i64
  %l282 = alloca { i64, ptr }
  %l292 = alloca ptr
  %l293 = alloca i1
  %l306 = alloca { i64, ptr }
  %s12 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t7 = load ptr, ptr %l40, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l40, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 17}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l41, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l41, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l2, !tbaa !23
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esetLocal(ptr %v0, ptr %v1, ptr %t32, i64 %t35, ptr %t36)
  br label %bb10
bb10:
  br label %bb176
bb11:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t42 = load ptr, ptr %l56, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load ptr, ptr %l56, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 17}
  %t48 = icmp eq i64 %t46, 1
  store i1 %t48, ptr %l57, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l57, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t52, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [3 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb25
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  br label %bb18
bb18:
  %t72 = load ptr, ptr %l4, !tbaa !29
  store ptr %t72, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t73 = load ptr, ptr %l70, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t76 = load ptr, ptr %l70, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 8}
  %t79 = icmp eq i64 %t77, 0
  store i1 %t79, ptr %l71, !tbaa !21
  br label %bb20
bb20:
  %t80 = load i1, ptr %l71, !tbaa !21
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t83, i32 0, i32 0
  %t85 = load %"compiler/source:Span", ptr %t84
  store %"compiler/source:Span" %t85, ptr %l6
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l7, !tbaa !23
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t95, i32 0, i32 2
  %t97 = load i32, ptr %t96
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t102 = sext i32 %t97 to i64
  %t103 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esetLocal(ptr %v0, ptr %v1, ptr %t99, i64 %t102, ptr %t103)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb176
bb25:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t109 = load ptr, ptr %l85, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t112 = load ptr, ptr %l85, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 17}
  %t115 = icmp eq i64 %t113, 2
  store i1 %t115, ptr %l86, !tbaa !21
  br label %bb27
bb27:
  %t116 = load i1, ptr %l86, !tbaa !21
  br i1 %t116, label %bb28, label %bb29
bb28:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l9, !tbaa !29
  br label %bb34
bb29:
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t124 = load ptr, ptr %l91, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t127 = load ptr, ptr %l91, !tbaa !29
  %t128 = load i64, ptr %t127, !range !{i64 0, i64 17}
  %t130 = icmp eq i64 %t128, 15
  store i1 %t130, ptr %l92, !tbaa !21
  br label %bb31
bb31:
  %t131 = load i1, ptr %l92, !tbaa !21
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", ptr }, ptr %t134, i32 0, i32 1
  %t136 = load ptr, ptr %t135
  store ptr %t136, ptr %l9, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t138, ptr %t139)
  br label %bb35
bb35:
  br label %bb176
bb36:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t144 = load ptr, ptr %l100, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb37, label %bb38
bb37:
  %t147 = load ptr, ptr %l100, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 17}
  %t150 = icmp eq i64 %t148, 16
  store i1 %t150, ptr %l101, !tbaa !21
  br label %bb38
bb38:
  %t151 = load i1, ptr %l101, !tbaa !21
  br i1 %t151, label %bb39, label %bb40
bb39:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", ptr }, ptr %t154, i32 0, i32 1
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l10, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  br label %bb42
bb42:
  br label %bb176
bb43:
  %t162 = load ptr, ptr %l1, !tbaa !29
  store ptr %t162, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t163 = load ptr, ptr %l108, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb44, label %bb45
bb44:
  %t166 = load ptr, ptr %l108, !tbaa !29
  %t167 = load i64, ptr %t166, !range !{i64 0, i64 17}
  %t169 = icmp eq i64 %t167, 6
  store i1 %t169, ptr %l109, !tbaa !21
  br label %bb45
bb45:
  %t170 = load i1, ptr %l109, !tbaa !21
  br i1 %t170, label %bb46, label %bb47
bb46:
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", ptr }, ptr %t173, i32 0, i32 1
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l11, !tbaa !29
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t177, ptr %t178)
  br label %bb49
bb49:
  %t181 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t181, i64 -1)
  br label %bb50
bb50:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/typed:dropWalk", ptr %t183, i32 0, i32 3
  store i1 true, ptr %t185, !tbaa !21
  br label %bb176
bb51:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t187 = load ptr, ptr %l118, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb52, label %bb53
bb52:
  %t190 = load ptr, ptr %l118, !tbaa !29
  %t191 = load i64, ptr %t190, !range !{i64 0, i64 17}
  %t193 = icmp eq i64 %t191, 8
  store i1 %t193, ptr %l119, !tbaa !21
  br label %bb53
bb53:
  %t194 = load i1, ptr %l119, !tbaa !21
  br i1 %t194, label %bb54, label %bb55
bb54:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [3 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t197, i32 0, i32 1
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l12, !tbaa !29
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t201, ptr %t202)
  br label %bb57
bb57:
  %t206 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t206, i1 true)
  br label %bb58
bb58:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/typed:dropWalk", ptr %t208, i32 0, i32 3
  store i1 true, ptr %t210, !tbaa !21
  br label %bb176
bb59:
  %t211 = load ptr, ptr %l1, !tbaa !29
  store ptr %t211, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t212 = load ptr, ptr %l129, !tbaa !29
  %t213 = icmp ne ptr %t212, null
  br i1 %t213, label %bb60, label %bb61
bb60:
  %t215 = load ptr, ptr %l129, !tbaa !29
  %t216 = load i64, ptr %t215, !range !{i64 0, i64 17}
  %t218 = icmp eq i64 %t216, 7
  store i1 %t218, ptr %l130, !tbaa !21
  br label %bb61
bb61:
  %t219 = load i1, ptr %l130, !tbaa !21
  br i1 %t219, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t220 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t220, i1 true)
  br label %bb65
bb65:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/typed:dropWalk", ptr %t222, i32 0, i32 3
  store i1 true, ptr %t224, !tbaa !21
  br label %bb176
bb66:
  %t225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t225, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t226 = load ptr, ptr %l135, !tbaa !29
  %t227 = icmp ne ptr %t226, null
  br i1 %t227, label %bb67, label %bb68
bb67:
  %t229 = load ptr, ptr %l135, !tbaa !29
  %t230 = load i64, ptr %t229, !range !{i64 0, i64 17}
  %t232 = icmp eq i64 %t230, 9
  store i1 %t232, ptr %l136, !tbaa !21
  br label %bb68
bb68:
  %t233 = load i1, ptr %l136, !tbaa !21
  br i1 %t233, label %bb69, label %bb70
bb69:
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t234, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t236, i32 0, i32 2
  %t238 = load ptr, ptr %t237
  store ptr %t238, ptr %l13, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t240, ptr %t241)
  br label %bb72
bb72:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/typed:dropWalk", ptr %t244, i32 0, i32 3
  store i1 true, ptr %t246, !tbaa !21
  br label %bb176
bb73:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t248 = load ptr, ptr %l144, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb74, label %bb75
bb74:
  %t251 = load ptr, ptr %l144, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 10
  store i1 %t254, ptr %l145, !tbaa !21
  br label %bb75
bb75:
  %t255 = load i1, ptr %l145, !tbaa !21
  br i1 %t255, label %bb76, label %bb77
bb76:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l14, !tbaa !29
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [3 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t264, i32 0, i32 2
  %t266 = load ptr, ptr %t265
  store ptr %t266, ptr %l15, !tbaa !29
  br label %bb78
bb77:
  br label %bb81
bb78:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t268, ptr %t269)
  br label %bb79
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t273, ptr %t274)
  br label %bb80
bb80:
  br label %bb176
bb81:
  %t277 = load ptr, ptr %l1, !tbaa !29
  store ptr %t277, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t278 = load ptr, ptr %l157, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb82, label %bb83
bb82:
  %t281 = load ptr, ptr %l157, !tbaa !29
  %t282 = load i64, ptr %t281, !range !{i64 0, i64 17}
  %t284 = icmp eq i64 %t282, 3
  store i1 %t284, ptr %l158, !tbaa !21
  br label %bb83
bb83:
  %t285 = load i1, ptr %l158, !tbaa !21
  br i1 %t285, label %bb84, label %bb85
bb84:
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr { i64, [3 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr }, ptr %t288, i32 0, i32 1
  %t290 = load ptr, ptr %t289
  store ptr %t290, ptr %l16, !tbaa !29
  br label %bb86
bb85:
  br label %bb94
bb86:
  store %olang.scope zeroinitializer, ptr %s12
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l16, !tbaa !29
  %t295 = getelementptr %"compiler/typed:If", ptr %t293, i32 0, i32 0
  %t296 = load ptr, ptr %t295, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t292, ptr %t296)
  br label %bb87
bb87:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s12, ptr %t300)
  store { i64, ptr } %t302, ptr %l168
  br label %bb88
bb88:
  %t303 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  store i64 %t304, ptr %l169, !tbaa !24
  %t305 = load i64, ptr %l169, !tbaa !24
  %t306 = mul i64 %t305, 1
  %t307 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t306)
  %t308 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  store { i64, ptr } %t309, ptr %l170, !tbaa !27
  %t310 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l169, !tbaa !24
  %t315 = mul i64 %t314, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t311, ptr %t313, i64 %t315, i1 false)
  %t316 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t316, ptr %l17, !tbaa !27
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load ptr, ptr %l16, !tbaa !29
  %t320 = getelementptr %"compiler/typed:If", ptr %t318, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t317, ptr %t321)
  br label %bb89
bb89:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s12, ptr %t325)
  store { i64, ptr } %t327, ptr %l176
  br label %bb90
bb90:
  %t328 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  store i64 %t329, ptr %l177, !tbaa !24
  %t330 = load i64, ptr %l177, !tbaa !24
  %t331 = mul i64 %t330, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t331)
  %t333 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  store { i64, ptr } %t334, ptr %l178, !tbaa !27
  %t335 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = load i64, ptr %l177, !tbaa !24
  %t340 = mul i64 %t339, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t336, ptr %t338, i64 %t340, i1 false)
  %t341 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t341, ptr %l18, !tbaa !27
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s12, ptr %t342, { i64, ptr } %t343)
  br label %bb91
bb91:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l16, !tbaa !29
  %t349 = getelementptr %"compiler/typed:If", ptr %t347, i32 0, i32 2
  %t350 = load ptr, ptr %t349, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t346, ptr %t350)
  br label %bb92
bb92:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s12, ptr %t353, { i64, ptr } %t354)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s12)
  br label %bb176
bb94:
  %t357 = load ptr, ptr %l1, !tbaa !29
  store ptr %t357, ptr %l186, !tbaa !29
  store i1 false, ptr %l187, !tbaa !21
  %t358 = load ptr, ptr %l186, !tbaa !29
  %t359 = icmp ne ptr %t358, null
  br i1 %t359, label %bb95, label %bb96
bb95:
  %t361 = load ptr, ptr %l186, !tbaa !29
  %t362 = load i64, ptr %t361, !range !{i64 0, i64 17}
  %t364 = icmp eq i64 %t362, 4
  store i1 %t364, ptr %l187, !tbaa !21
  br label %bb96
bb96:
  %t365 = load i1, ptr %l187, !tbaa !21
  br i1 %t365, label %bb97, label %bb98
bb97:
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t368 = getelementptr { i64, [3 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t368, i32 0, i32 1
  %t370 = load ptr, ptr %t369
  store ptr %t370, ptr %l19, !tbaa !29
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t374 = getelementptr { i64, [3 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t374, i32 0, i32 2
  %t376 = load ptr, ptr %t375
  store ptr %t376, ptr %l20, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load ptr, ptr %l19, !tbaa !29
  %t380 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %t378, ptr %t379, ptr %t380)
  br label %bb100
bb100:
  br label %bb176
bb101:
  %t384 = load ptr, ptr %l1, !tbaa !29
  store ptr %t384, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t385 = load ptr, ptr %l197, !tbaa !29
  %t386 = icmp ne ptr %t385, null
  br i1 %t386, label %bb102, label %bb103
bb102:
  %t388 = load ptr, ptr %l197, !tbaa !29
  %t389 = load i64, ptr %t388, !range !{i64 0, i64 17}
  %t391 = icmp eq i64 %t389, 5
  store i1 %t391, ptr %l198, !tbaa !21
  br label %bb103
bb103:
  %t392 = load i1, ptr %l198, !tbaa !21
  br i1 %t392, label %bb104, label %bb105
bb104:
  %t393 = load ptr, ptr %l1, !tbaa !29
  %t395 = getelementptr { i64, [3 x i64] }, ptr %t393, i32 0, i32 1
  %t396 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t395, i32 0, i32 1
  %t397 = load i32, ptr %t396, !range !{i32 0, i32 2}
  store i32 %t397, ptr %l21
  %t399 = load ptr, ptr %l1, !tbaa !29
  %t401 = getelementptr { i64, [3 x i64] }, ptr %t399, i32 0, i32 1
  %t402 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t401, i32 0, i32 2
  %t403 = load i32, ptr %t402
  store i32 %t403, ptr %l22, !tbaa !23
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i32, ptr %l21, !range !{i32 0, i32 2}
  %t407 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejump(ptr %v0, ptr %t405, i32 %t406, i32 %t407)
  br label %bb107
bb107:
  br label %bb176
bb108:
  %t411 = load ptr, ptr %l1, !tbaa !29
  store ptr %t411, ptr %l208, !tbaa !29
  store i1 false, ptr %l209, !tbaa !21
  %t412 = load ptr, ptr %l208, !tbaa !29
  %t413 = icmp ne ptr %t412, null
  br i1 %t413, label %bb109, label %bb110
bb109:
  %t415 = load ptr, ptr %l208, !tbaa !29
  %t416 = load i64, ptr %t415, !range !{i64 0, i64 17}
  %t418 = icmp eq i64 %t416, 11
  store i1 %t418, ptr %l209, !tbaa !21
  br label %bb110
bb110:
  %t419 = load i1, ptr %l209, !tbaa !21
  br i1 %t419, label %bb111, label %bb112
bb111:
  %t420 = load ptr, ptr %l1, !tbaa !29
  %t422 = getelementptr { i64, [3 x i64] }, ptr %t420, i32 0, i32 1
  %t423 = getelementptr { %"compiler/source:Span", ptr }, ptr %t422, i32 0, i32 1
  %t424 = load ptr, ptr %t423
  store ptr %t424, ptr %l23, !tbaa !29
  br label %bb113
bb112:
  br label %bb115
bb113:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t426, ptr %t427)
  br label %bb114
bb114:
  br label %bb176
bb115:
  %t431 = load ptr, ptr %l1, !tbaa !29
  store ptr %t431, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t432 = load ptr, ptr %l217, !tbaa !29
  %t433 = icmp ne ptr %t432, null
  br i1 %t433, label %bb116, label %bb117
bb116:
  %t435 = load ptr, ptr %l217, !tbaa !29
  %t436 = load i64, ptr %t435, !range !{i64 0, i64 17}
  %t438 = icmp eq i64 %t436, 12
  store i1 %t438, ptr %l218, !tbaa !21
  br label %bb117
bb117:
  %t439 = load i1, ptr %l218, !tbaa !21
  br i1 %t439, label %bb118, label %bb119
bb118:
  %t440 = load ptr, ptr %l1, !tbaa !29
  %t442 = getelementptr { i64, [3 x i64] }, ptr %t440, i32 0, i32 1
  %t443 = getelementptr { %"compiler/source:Span", ptr }, ptr %t442, i32 0, i32 1
  %t444 = load ptr, ptr %t443
  store ptr %t444, ptr %l24, !tbaa !29
  br label %bb120
bb119:
  br label %bb139
bb120:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load ptr, ptr %l24, !tbaa !29
  %t450 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %t446, ptr %t447)
  store i64 %t450, ptr %l225
  br label %bb121
bb121:
  %t451 = load i64, ptr %l225, !tbaa !24
  store i64 %t451, ptr %l25, !tbaa !24
  %t452 = load i64, ptr %l25, !tbaa !24
  %t454 = icmp sge i64 %t452, 0
  br i1 %t454, label %bb122, label %bb123
bb122:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/typed:dropWalk", ptr %t456, i32 0, i32 1
  %t459 = load i64, ptr %l25, !tbaa !24
  %t462 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t458, i64 %t459)
  store i1 %t462, ptr %l232
  br label %bb124
bb123:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb125
bb124:
  %t463 = load i1, ptr %l232, !tbaa !21
  %t464 = xor i1 %t463, true
  store i1 %t464, ptr %l228, !tbaa !21
  br label %bb125
bb125:
  %t466 = load i1, ptr %l228, !tbaa !21
  br i1 %t466, label %bb126, label %bb127
bb126:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t469 = getelementptr %"compiler/typed:dropWalk", ptr %t467, i32 0, i32 14
  %t470 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t469, i64 %t470, i1 true)
  br label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb129
bb129:
  %t473 = load i64, ptr %l25, !tbaa !24
  %t475 = icmp sge i64 %t473, 0
  br i1 %t475, label %bb130, label %bb131
bb130:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/typed:dropWalk", ptr %t477, i32 0, i32 1
  %t480 = load i64, ptr %l25, !tbaa !24
  %t483 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t479, i64 %t480)
  store i1 %t483, ptr %l243
  br label %bb132
bb131:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb133
bb132:
  %t484 = load i1, ptr %l243, !tbaa !21
  store i1 %t484, ptr %l239, !tbaa !21
  br label %bb133
bb133:
  %t485 = load i1, ptr %l239, !tbaa !21
  br i1 %t485, label %bb134, label %bb135
bb134:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/typed:dropWalk", ptr %t486, i32 0, i32 5
  %t489 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t488, i64 %t489)
  br label %bb136
bb135:
  br label %bb138
bb136:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = getelementptr %"compiler/typed:dropWalk", ptr %t492, i32 0, i32 6
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/typed:dropWalk", ptr %t495, i32 0, i32 4
  %t498 = load i64, ptr %t497, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t494, i64 %t498)
  br label %bb137
bb137:
  br label %bb138
bb138:
  br label %bb176
bb139:
  %t501 = load ptr, ptr %l1, !tbaa !29
  store ptr %t501, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t502 = load ptr, ptr %l251, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb140, label %bb141
bb140:
  %t505 = load ptr, ptr %l251, !tbaa !29
  %t506 = load i64, ptr %t505, !range !{i64 0, i64 17}
  %t508 = icmp eq i64 %t506, 13
  store i1 %t508, ptr %l252, !tbaa !21
  br label %bb141
bb141:
  %t509 = load i1, ptr %l252, !tbaa !21
  br i1 %t509, label %bb142, label %bb143
bb142:
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [3 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", ptr }, ptr %t512, i32 0, i32 1
  %t514 = load ptr, ptr %t513
  store ptr %t514, ptr %l26, !tbaa !29
  br label %bb144
bb143:
  br label %bb161
bb144:
  store %olang.scope zeroinitializer, ptr %s19
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load ptr, ptr %l26, !tbaa !29
  %t519 = getelementptr %"compiler/typed:Join", ptr %t517, i32 0, i32 0
  %t520 = load ptr, ptr %t519, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t516, ptr %t520)
  br label %bb145
bb145:
  %t524 = load ptr, ptr %l26, !tbaa !29
  %t526 = getelementptr %"compiler/typed:Join", ptr %t524, i32 0, i32 1
  %t527 = load i1, ptr %t526, !tbaa !21
  br i1 %t527, label %bb146, label %bb147
bb146:
  %t529 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t529, i1 true)
  br label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb149
bb149:
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t533 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s19, ptr %t531)
  store { i64, ptr } %t533, ptr %l265
  br label %bb150
bb150:
  %t534 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t535 = extractvalue { i64, ptr } %t534, 0
  store i64 %t535, ptr %l266, !tbaa !24
  %t536 = load i64, ptr %l266, !tbaa !24
  %t537 = mul i64 %t536, 1
  %t538 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t537)
  %t539 = insertvalue { i64, ptr } undef, i64 %t536, 0
  %t540 = insertvalue { i64, ptr } %t539, ptr %t538, 1
  store { i64, ptr } %t540, ptr %l267, !tbaa !27
  %t541 = getelementptr { i64, ptr }, ptr %l267, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = load i64, ptr %l266, !tbaa !24
  %t546 = mul i64 %t545, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t542, ptr %t544, i64 %t546, i1 false)
  %t547 = load { i64, ptr }, ptr %l267, !tbaa !27
  store { i64, ptr } %t547, ptr %l27, !tbaa !27
  %t548 = load ptr, ptr %l26, !tbaa !29
  %t550 = getelementptr %"compiler/typed:Join", ptr %t548, i32 0, i32 2
  %t551 = load { i64, ptr }, ptr %t550, !tbaa !27
  store { i64, ptr } %t551, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t553 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t553, 0
  store i64 %t555, ptr %l30, !tbaa !24
  br label %bb151
bb151:
  store %olang.scope zeroinitializer, ptr %s22
  %t557 = load i64, ptr %l29, !tbaa !24
  %t558 = load i64, ptr %l30, !tbaa !24
  %t561 = icmp slt i64 %t557, %t558
  %t563 = xor i1 %t561, true
  br i1 %t563, label %bb152, label %bb153
bb152:
  call void @__olang_scope_close(ptr %s22)
  br label %bb160
bb153:
  br label %bb154
bb154:
  %t565 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t565, ptr %l276, !tbaa !27
  %t566 = load i64, ptr %l29, !tbaa !24
  %t568 = getelementptr { i64, ptr }, ptr %l276, i32 0, i32 1
  %t569 = load ptr, ptr %t568, !tbaa !27
  %t570 = getelementptr ptr, ptr %t569, i64 %t566
  %t571 = load ptr, ptr %t570, !tbaa !39
  store ptr %t571, ptr %l31, !tbaa !29
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t575 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s22, ptr %t573)
  store { i64, ptr } %t575, ptr %l280
  br label %bb155
bb155:
  %t576 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t577 = extractvalue { i64, ptr } %t576, 0
  store i64 %t577, ptr %l281, !tbaa !24
  %t578 = load i64, ptr %l281, !tbaa !24
  %t579 = mul i64 %t578, 1
  %t580 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t579)
  %t581 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t582 = insertvalue { i64, ptr } %t581, ptr %t580, 1
  store { i64, ptr } %t582, ptr %l282, !tbaa !27
  %t583 = getelementptr { i64, ptr }, ptr %l282, i32 0, i32 1
  %t584 = load ptr, ptr %t583, !tbaa !27
  %t585 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t586 = load ptr, ptr %t585, !tbaa !27
  %t587 = load i64, ptr %l281, !tbaa !24
  %t588 = mul i64 %t587, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t584, ptr %t586, i64 %t588, i1 false)
  %t589 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t589, ptr %l32, !tbaa !27
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s19, ptr %t590, { i64, ptr } %t591)
  br label %bb156
bb156:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load ptr, ptr %l31, !tbaa !29
  %t597 = getelementptr %"compiler/typed:Clause", ptr %t595, i32 0, i32 3
  %t598 = load ptr, ptr %t597, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t594, ptr %t598)
  br label %bb157
bb157:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t602 = load { i64, ptr }, ptr %l32, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s22, ptr %t601, { i64, ptr } %t602)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s22)
  br label %bb159
bb159:
  %t605 = load i64, ptr %l29, !tbaa !24
  %t607 = add i64 %t605, 1
  store i64 %t607, ptr %l29, !tbaa !24
  br label %bb151
bb160:
  call void @__olang_scope_close(ptr %s19)
  br label %bb176
bb161:
  %t609 = load ptr, ptr %l1, !tbaa !29
  store ptr %t609, ptr %l292, !tbaa !29
  store i1 false, ptr %l293, !tbaa !21
  %t610 = load ptr, ptr %l292, !tbaa !29
  %t611 = icmp ne ptr %t610, null
  br i1 %t611, label %bb162, label %bb163
bb162:
  %t613 = load ptr, ptr %l292, !tbaa !29
  %t614 = load i64, ptr %t613, !range !{i64 0, i64 17}
  %t616 = icmp eq i64 %t614, 14
  store i1 %t616, ptr %l293, !tbaa !21
  br label %bb163
bb163:
  %t617 = load i1, ptr %l293, !tbaa !21
  br i1 %t617, label %bb164, label %bb165
bb164:
  %t618 = load ptr, ptr %l1, !tbaa !29
  %t620 = getelementptr { i64, [3 x i64] }, ptr %t618, i32 0, i32 1
  %t621 = getelementptr { %"compiler/source:Span", ptr }, ptr %t620, i32 0, i32 1
  %t622 = load ptr, ptr %t621
  store ptr %t622, ptr %l33, !tbaa !29
  br label %bb166
bb165:
  br label %bb175
bb166:
  %t624 = load ptr, ptr %l33, !tbaa !29
  %t626 = getelementptr %"compiler/typed:Spawn", ptr %t624, i32 0, i32 0
  %t627 = load { i64, ptr }, ptr %t626, !tbaa !27
  store { i64, ptr } %t627, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t629 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t631 = extractvalue { i64, ptr } %t629, 0
  store i64 %t631, ptr %l36, !tbaa !24
  br label %bb167
bb167:
  %t633 = load i64, ptr %l35, !tbaa !24
  %t634 = load i64, ptr %l36, !tbaa !24
  %t637 = icmp slt i64 %t633, %t634
  %t639 = xor i1 %t637, true
  br i1 %t639, label %bb168, label %bb169
bb168:
  br label %bb173
bb169:
  br label %bb170
bb170:
  %t641 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t641, ptr %l306, !tbaa !27
  %t642 = load i64, ptr %l35, !tbaa !24
  %t644 = getelementptr { i64, ptr }, ptr %l306, i32 0, i32 1
  %t645 = load ptr, ptr %t644, !tbaa !27
  %t646 = getelementptr ptr, ptr %t645, i64 %t642
  %t647 = load ptr, ptr %t646, !tbaa !39
  %t649 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t649, ptr %t647)
  br label %bb171
bb171:
  br label %bb172
bb172:
  %t653 = load i64, ptr %l35, !tbaa !24
  %t655 = add i64 %t653, 1
  store i64 %t655, ptr %l35, !tbaa !24
  br label %bb167
bb173:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load ptr, ptr %l33, !tbaa !29
  %t660 = getelementptr %"compiler/typed:Spawn", ptr %t658, i32 0, i32 1
  %t661 = load ptr, ptr %t660, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t657, ptr %t661)
  br label %bb174
bb174:
  br label %bb176
bb175:
  call void @__olang_check_failed(ptr @olang_loc_43e833e67406aee2_76f2107f4f2989fe)
  unreachable
bb176:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %l33 = alloca { i64, ptr }
  %l40 = alloca i1
  %l50 = alloca { i64, ptr }
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Arm", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i1 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Arm", ptr %t11, i32 0, i32 3
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t10, ptr %t14)
  store i1 %t17, ptr %l18
  br label %bb4
bb4:
  %t18 = load i1, ptr %l18, !tbaa !21
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Arm", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t27 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t20, ptr %t24)
  store i1 %t27, ptr %l23
  br label %bb8
bb8:
  %t28 = load i1, ptr %l23, !tbaa !21
  store i1 %t28, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Arm", ptr %t31, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb14, label %bb15
bb14:
  br label %bb32
bb15:
  br label %bb16
bb16:
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l33, !tbaa !27
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr ptr, ptr %t52, i64 %t49
  %t54 = load ptr, ptr %t53, !tbaa !39
  store ptr %t54, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Alt", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t64 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  store i1 %t64, ptr %l40
  br label %bb17
bb17:
  %t65 = load i1, ptr %l40, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Alt", ptr %t67, i32 0, i32 1
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t72, 0
  store i64 %t74, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = icmp slt i64 %t76, %t77
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  br label %bb24
bb24:
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr ptr, ptr %t88, i64 %t85
  %t90 = load ptr, ptr %t89, !tbaa !39
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Bind", ptr %t90, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t100 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t92, ptr %t96)
  store i1 %t100, ptr %l57
  br label %bb25
bb25:
  %t101 = load i1, ptr %l57, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  store i1 true, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l7, !tbaa !24
  br label %bb21
bb30:
  br label %bb31
bb31:
  %t107 = load i64, ptr %l3, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l3, !tbaa !24
  br label %bb13
bb32:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t34 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2earmLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2ecalleeLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t17)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l3, !tbaa !21
  br label %bb26
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 5}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  br label %bb24
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 5}
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 5}
  %t48 = icmp eq i64 %t46, 3
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 5}
  %t57 = icmp eq i64 %t55, 4
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb21
bb21:
  %t58 = load i1, ptr %l27, !tbaa !21
  br i1 %t58, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_10efe43793a641ac_2dabf1c43cd6a168)
  unreachable
bb26:
  %t59 = load i1, ptr %l3, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eopenLeaves(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eopenLeaves(ptr %v0, ptr %v2, ptr %t8, ptr %a2)
  store i1 %t12, ptr %l10
  br label %bb4
bb4:
  %t13 = load i1, ptr %l10, !tbaa !21
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eopenLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:leaveWalk", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Block", ptr %t9, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t8, i32 %t12)
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Block", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t22 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %t19)
  store i1 %t22, ptr %l13
  br label %bb5
bb5:
  %t23 = load i1, ptr %l13, !tbaa !21
  store i1 %t23, ptr %l2, !tbaa !21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/typed:leaveWalk", ptr %t24, i32 0, i32 0
  %t28 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t26)
  %t29 = extractvalue { i32, i32 } %t28, 1
  %t30 = extractvalue { i32, i32 } %t28, 0
  store i32 %t30, ptr %l18
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb7, label %ok.32, !prof !99
ok.32:
  store i32 %t29, ptr %l17
  br label %bb6
bb6:
  %t33 = load i32, ptr %l17, !tbaa !23
  store i32 %t33, ptr %l14, !tbaa !23
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  br label %bb9
bb9:
  %t34 = load i1, ptr %l2, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2epiecesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb26
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 2}
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { ptr }, ptr %t41, i32 0, i32 0
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l6, !tbaa !29
  %t50 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t46)
  store i1 %t50, ptr %l30
  br label %bb13
bb13:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb24
bb17:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 2}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l33, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4c49c2cc391943fc_885b7fff3b4a3180)
  unreachable
bb24:
  br label %bb25
bb25:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l3, !tbaa !24
  br label %bb4
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l89 = alloca i1
  %l90 = alloca i1
  %l95 = alloca i1
  %l96 = alloca i1
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l112 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l140 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l149 = alloca i1
  %l152 = alloca i1
  %l154 = alloca i1
  %l159 = alloca i1
  %l160 = alloca i1
  %l164 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l175 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t2 = load ptr, ptr %l14, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l14, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l15, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t11 = load ptr, ptr %l18, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l18, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 17}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l19, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t20 = load ptr, ptr %l22, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 17}
  %t26 = icmp eq i64 %t24, 8
  store i1 %t26, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l23, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t29 = load ptr, ptr %l26, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l26, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 17}
  %t35 = icmp eq i64 %t33, 16
  store i1 %t35, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l27, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb123
bb18:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t38 = load ptr, ptr %l30, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb19, label %bb20
bb19:
  %t41 = load ptr, ptr %l30, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 17}
  %t44 = icmp eq i64 %t42, 5
  store i1 %t44, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t45 = load i1, ptr %l31, !tbaa !21
  br i1 %t45, label %bb21, label %bb22
bb21:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t48, i32 0, i32 2
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l2, !tbaa !23
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/typed:leaveWalk", ptr %t52, i32 0, i32 0
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eHas_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t54, i32 %t55)
  store i1 %t58, ptr %l39
  br label %bb24
bb24:
  %t59 = load i1, ptr %l39, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l13, !tbaa !21
  br label %bb123
bb25:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t63 = load ptr, ptr %l41, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb26, label %bb27
bb26:
  %t66 = load ptr, ptr %l41, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 17}
  %t69 = icmp eq i64 %t67, 0
  store i1 %t69, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t70 = load i1, ptr %l42, !tbaa !21
  br i1 %t70, label %bb28, label %bb29
bb28:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l3, !tbaa !29
  br label %bb38
bb29:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t78 = load ptr, ptr %l47, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb30, label %bb31
bb30:
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 17}
  %t84 = icmp eq i64 %t82, 2
  store i1 %t84, ptr %l48, !tbaa !21
  br label %bb31
bb31:
  %t85 = load i1, ptr %l48, !tbaa !21
  br i1 %t85, label %bb32, label %bb33
bb32:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [3 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", ptr }, ptr %t88, i32 0, i32 1
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l3, !tbaa !29
  br label %bb38
bb33:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t93 = load ptr, ptr %l53, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb34, label %bb35
bb34:
  %t96 = load ptr, ptr %l53, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 17}
  %t99 = icmp eq i64 %t97, 15
  store i1 %t99, ptr %l54, !tbaa !21
  br label %bb35
bb35:
  %t100 = load i1, ptr %l54, !tbaa !21
  br i1 %t100, label %bb36, label %bb37
bb36:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", ptr }, ptr %t103, i32 0, i32 1
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l3, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l3, !tbaa !29
  %t112 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  store i1 %t112, ptr %l62
  br label %bb39
bb39:
  %t113 = load i1, ptr %l62, !tbaa !21
  store i1 %t113, ptr %l13, !tbaa !21
  br label %bb123
bb40:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t115 = load ptr, ptr %l63, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb41, label %bb42
bb41:
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 17}
  %t121 = icmp eq i64 %t119, 1
  store i1 %t121, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t122 = load i1, ptr %l64, !tbaa !21
  br i1 %t122, label %bb43, label %bb44
bb43:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [3 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t125, i32 0, i32 1
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l4, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t131, i32 0, i32 2
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l5, !tbaa !29
  br label %bb45
bb44:
  br label %bb51
bb45:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t139 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t135, ptr %t136)
  store i1 %t139, ptr %l73
  br label %bb46
bb46:
  %t140 = load i1, ptr %l73, !tbaa !21
  br i1 %t140, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb50
bb48:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t146 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t141, ptr %t142)
  store i1 %t146, ptr %l78
  br label %bb49
bb49:
  %t147 = load i1, ptr %l78, !tbaa !21
  store i1 %t147, ptr %l74, !tbaa !21
  br label %bb50
bb50:
  %t148 = load i1, ptr %l74, !tbaa !21
  store i1 %t148, ptr %l13, !tbaa !21
  br label %bb123
bb51:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t150 = load ptr, ptr %l79, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb52, label %bb53
bb52:
  %t153 = load ptr, ptr %l79, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 17}
  %t156 = icmp eq i64 %t154, 3
  store i1 %t156, ptr %l80, !tbaa !21
  br label %bb53
bb53:
  %t157 = load i1, ptr %l80, !tbaa !21
  br i1 %t157, label %bb54, label %bb55
bb54:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l6, !tbaa !29
  br label %bb56
bb55:
  br label %bb66
bb56:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l6, !tbaa !29
  %t167 = getelementptr %"compiler/typed:If", ptr %t165, i32 0, i32 0
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t172 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t164, ptr %t168)
  store i1 %t172, ptr %l89
  br label %bb57
bb57:
  %t173 = load i1, ptr %l89, !tbaa !21
  br i1 %t173, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb61
bb59:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l6, !tbaa !29
  %t177 = getelementptr %"compiler/typed:If", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t182 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t174, ptr %t178)
  store i1 %t182, ptr %l95
  br label %bb60
bb60:
  %t183 = load i1, ptr %l95, !tbaa !21
  store i1 %t183, ptr %l90, !tbaa !21
  br label %bb61
bb61:
  %t184 = load i1, ptr %l90, !tbaa !21
  br i1 %t184, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb65
bb63:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l6, !tbaa !29
  %t188 = getelementptr %"compiler/typed:If", ptr %t186, i32 0, i32 2
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t192 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t185, ptr %t189)
  store i1 %t192, ptr %l100
  br label %bb64
bb64:
  %t193 = load i1, ptr %l100, !tbaa !21
  store i1 %t193, ptr %l96, !tbaa !21
  br label %bb65
bb65:
  %t194 = load i1, ptr %l96, !tbaa !21
  store i1 %t194, ptr %l13, !tbaa !21
  br label %bb123
bb66:
  %t195 = load ptr, ptr %l1, !tbaa !29
  store ptr %t195, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t196 = load ptr, ptr %l101, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb67, label %bb68
bb67:
  %t199 = load ptr, ptr %l101, !tbaa !29
  %t200 = load i64, ptr %t199, !range !{i64 0, i64 17}
  %t202 = icmp eq i64 %t200, 4
  store i1 %t202, ptr %l102, !tbaa !21
  br label %bb68
bb68:
  %t203 = load i1, ptr %l102, !tbaa !21
  br i1 %t203, label %bb69, label %bb70
bb69:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t206, i32 0, i32 1
  %t208 = load ptr, ptr %t207
  store ptr %t208, ptr %l7, !tbaa !29
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [3 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t212, i32 0, i32 2
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l8, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l7, !tbaa !29
  %t218 = load ptr, ptr %l8, !tbaa !29
  %t222 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eloopLeaves(ptr %v0, ptr %v1, ptr %v1, ptr %t216, ptr %t217, ptr %t218)
  store i1 %t222, ptr %l112
  br label %bb72
bb72:
  %t223 = load i1, ptr %l112, !tbaa !21
  store i1 %t223, ptr %l13, !tbaa !21
  br label %bb123
bb73:
  %t224 = load ptr, ptr %l1, !tbaa !29
  store ptr %t224, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t225 = load ptr, ptr %l113, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb74, label %bb75
bb74:
  %t228 = load ptr, ptr %l113, !tbaa !29
  %t229 = load i64, ptr %t228, !range !{i64 0, i64 17}
  %t231 = icmp eq i64 %t229, 9
  store i1 %t231, ptr %l114, !tbaa !21
  br label %bb75
bb75:
  %t232 = load i1, ptr %l114, !tbaa !21
  br i1 %t232, label %bb76, label %bb77
bb76:
  br label %bb82
bb77:
  %t233 = load ptr, ptr %l1, !tbaa !29
  store ptr %t233, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t234 = load ptr, ptr %l117, !tbaa !29
  %t235 = icmp ne ptr %t234, null
  br i1 %t235, label %bb78, label %bb79
bb78:
  %t237 = load ptr, ptr %l117, !tbaa !29
  %t238 = load i64, ptr %t237, !range !{i64 0, i64 17}
  %t240 = icmp eq i64 %t238, 10
  store i1 %t240, ptr %l118, !tbaa !21
  br label %bb79
bb79:
  %t241 = load i1, ptr %l118, !tbaa !21
  br i1 %t241, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb123
bb83:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t243 = load ptr, ptr %l121, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb84, label %bb85
bb84:
  %t246 = load ptr, ptr %l121, !tbaa !29
  %t247 = load i64, ptr %t246, !range !{i64 0, i64 17}
  %t249 = icmp eq i64 %t247, 11
  store i1 %t249, ptr %l122, !tbaa !21
  br label %bb85
bb85:
  %t250 = load i1, ptr %l122, !tbaa !21
  br i1 %t250, label %bb86, label %bb87
bb86:
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [3 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l9, !tbaa !29
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l9, !tbaa !29
  %t262 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eopenLeaves(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  store i1 %t262, ptr %l130
  br label %bb89
bb89:
  %t263 = load i1, ptr %l130, !tbaa !21
  store i1 %t263, ptr %l13, !tbaa !21
  br label %bb123
bb90:
  %t264 = load ptr, ptr %l1, !tbaa !29
  store ptr %t264, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t265 = load ptr, ptr %l131, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb91, label %bb92
bb91:
  %t268 = load ptr, ptr %l131, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 17}
  %t271 = icmp eq i64 %t269, 12
  store i1 %t271, ptr %l132, !tbaa !21
  br label %bb92
bb92:
  %t272 = load i1, ptr %l132, !tbaa !21
  br i1 %t272, label %bb93, label %bb94
bb93:
  %t273 = load ptr, ptr %l1, !tbaa !29
  %t275 = getelementptr { i64, [3 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", ptr }, ptr %t275, i32 0, i32 1
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l10, !tbaa !29
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load ptr, ptr %l10, !tbaa !29
  %t284 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t279, ptr %t280)
  store i1 %t284, ptr %l140
  br label %bb96
bb96:
  %t285 = load i1, ptr %l140, !tbaa !21
  store i1 %t285, ptr %l13, !tbaa !21
  br label %bb123
bb97:
  %t286 = load ptr, ptr %l1, !tbaa !29
  store ptr %t286, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t287 = load ptr, ptr %l141, !tbaa !29
  %t288 = icmp ne ptr %t287, null
  br i1 %t288, label %bb98, label %bb99
bb98:
  %t290 = load ptr, ptr %l141, !tbaa !29
  %t291 = load i64, ptr %t290, !range !{i64 0, i64 17}
  %t293 = icmp eq i64 %t291, 13
  store i1 %t293, ptr %l142, !tbaa !21
  br label %bb99
bb99:
  %t294 = load i1, ptr %l142, !tbaa !21
  br i1 %t294, label %bb100, label %bb101
bb100:
  %t295 = load ptr, ptr %l1, !tbaa !29
  %t297 = getelementptr { i64, [3 x i64] }, ptr %t295, i32 0, i32 1
  %t298 = getelementptr { %"compiler/source:Span", ptr }, ptr %t297, i32 0, i32 1
  %t299 = load ptr, ptr %t298
  store ptr %t299, ptr %l11, !tbaa !29
  br label %bb102
bb101:
  br label %bb115
bb102:
  %t301 = load ptr, ptr %l11, !tbaa !29
  %t303 = getelementptr %"compiler/typed:Join", ptr %t301, i32 0, i32 1
  %t304 = load i1, ptr %t303, !tbaa !21
  br i1 %t304, label %bb103, label %bb104
bb103:
  %t306 = load ptr, ptr %l11, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Join", ptr %t306, i32 0, i32 2
  %t309 = load { i64, ptr }, ptr %t308, !tbaa !27
  %t311 = call i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v1, { i64, ptr } %t309)
  store i1 %t311, ptr %l152
  br label %bb105
bb104:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb106
bb105:
  %t312 = load i1, ptr %l152, !tbaa !21
  %t313 = xor i1 %t312, true
  store i1 %t313, ptr %l149, !tbaa !21
  br label %bb106
bb106:
  %t315 = load i1, ptr %l149, !tbaa !21
  br i1 %t315, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb110
bb108:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l11, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Join", ptr %t317, i32 0, i32 0
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t324 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t316, ptr %t320)
  store i1 %t324, ptr %l159
  br label %bb109
bb109:
  %t325 = load i1, ptr %l159, !tbaa !21
  store i1 %t325, ptr %l154, !tbaa !21
  br label %bb110
bb110:
  %t326 = load i1, ptr %l154, !tbaa !21
  br i1 %t326, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l160, !tbaa !21
  br label %bb114
bb112:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l11, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Join", ptr %t328, i32 0, i32 2
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  %t334 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %t327, { i64, ptr } %t331)
  store i1 %t334, ptr %l164
  br label %bb113
bb113:
  %t335 = load i1, ptr %l164, !tbaa !21
  store i1 %t335, ptr %l160, !tbaa !21
  br label %bb114
bb114:
  %t336 = load i1, ptr %l160, !tbaa !21
  store i1 %t336, ptr %l13, !tbaa !21
  br label %bb123
bb115:
  %t337 = load ptr, ptr %l1, !tbaa !29
  store ptr %t337, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t338 = load ptr, ptr %l165, !tbaa !29
  %t339 = icmp ne ptr %t338, null
  br i1 %t339, label %bb116, label %bb117
bb116:
  %t341 = load ptr, ptr %l165, !tbaa !29
  %t342 = load i64, ptr %t341, !range !{i64 0, i64 17}
  %t344 = icmp eq i64 %t342, 14
  store i1 %t344, ptr %l166, !tbaa !21
  br label %bb117
bb117:
  %t345 = load i1, ptr %l166, !tbaa !21
  br i1 %t345, label %bb118, label %bb119
bb118:
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t348 = getelementptr { i64, [3 x i64] }, ptr %t346, i32 0, i32 1
  %t349 = getelementptr { %"compiler/source:Span", ptr }, ptr %t348, i32 0, i32 1
  %t350 = load ptr, ptr %t349
  store ptr %t350, ptr %l12, !tbaa !29
  br label %bb120
bb119:
  br label %bb122
bb120:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l12, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Spawn", ptr %t353, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !29
  %t360 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t352, ptr %t356)
  store i1 %t360, ptr %l175
  br label %bb121
bb121:
  %t361 = load i1, ptr %l175, !tbaa !21
  store i1 %t361, ptr %l13, !tbaa !21
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_d15cb06393d6b10c_f6dc2a2381fafcf0)
  unreachable
bb123:
  %t362 = load i1, ptr %l13, !tbaa !21
  store i1 %t362, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t34 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca i32
  %l47 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i1
  %l66 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t20 = sext i32 %t16 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l9, !tbaa !27
  br label %bb36
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 5}
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l19, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [3 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t48 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t45, i64 %t46)
  %t51 = getelementptr i8, ptr %t50, i64 %t46
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t44)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t50, 1
  store { i64, ptr } %t54, ptr %l9, !tbaa !27
  br label %bb36
bb12:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t57 = load ptr, ptr %l26, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = load ptr, ptr %l26, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 5}
  %t63 = icmp eq i64 %t61, 2
  store i1 %t63, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t64 = load i1, ptr %l27, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { ptr }, ptr %t67, i32 0, i32 0
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t76 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t71, ptr %t72)
  store { i64, ptr } %t76, ptr %l35
  br label %bb18
bb18:
  %t77 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t78, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb19:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t85 = load ptr, ptr %l37, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb20, label %bb21
bb20:
  %t88 = load ptr, ptr %l37, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 5}
  %t91 = icmp eq i64 %t89, 4
  store i1 %t91, ptr %l38, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l38, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [3 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { i32, i32 }, ptr %t95, i32 0, i32 0
  %t97 = load i32, ptr %t96, !range !{i32 0, i32 2}
  store i32 %t97, ptr %l5
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr { i64, [3 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { i32, i32 }, ptr %t101, i32 0, i32 1
  %t103 = load i32, ptr %t102
  store i32 %t103, ptr %l6, !tbaa !23
  br label %bb24
bb23:
  br label %bb28
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t105 = load i32, ptr %l5, !range !{i32 0, i32 2}
  store i32 %t105, ptr %l45
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aHelper(ptr %s8, ptr %l45, i64 0)
  br label %bb25
bb25:
  %t107 = load ptr, ptr %s8
  %t108 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t109 = load i64, ptr %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t107, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l47, !tbaa !27
  %t113 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t114 = load ptr, ptr %t113
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %sbgrew.116, label %sbdone.117
sbgrew.116:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.117
sbdone.117:
  %t118 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s7, ptr %s7, { i64, ptr } %t124)
  store { i64, ptr } %t126, ptr %l49
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/typed:printer", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load i32, ptr %l6, !tbaa !23
  %t132 = load ptr, ptr @__olang_prog_scope
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t132, ptr %s7, ptr %t130, i32 %t131)
  store { i64, ptr } %t135, ptr %l53
  br label %bb27
bb27:
  %t136 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t142 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = add i64 %t141, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t137, i64 %t138)
  %t147 = getelementptr i8, ptr %t146, i64 %t138
  call void @olang_textcopy(ptr %t147, ptr %t139, i64 %t140)
  %t148 = getelementptr i8, ptr %t147, i64 %t140
  call void @olang_textcopy(ptr %t148, ptr %t143, i64 %t144)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t146, 1
  store { i64, ptr } %t150, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb28:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t153 = load ptr, ptr %l55, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb29, label %bb30
bb29:
  %t156 = load ptr, ptr %l55, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 5}
  %t159 = icmp eq i64 %t157, 3
  store i1 %t159, ptr %l56, !tbaa !21
  br label %bb30
bb30:
  %t160 = load i1, ptr %l56, !tbaa !21
  br i1 %t160, label %bb31, label %bb32
bb31:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [3 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { i32, i64, i32 }, ptr %t163, i32 0, i32 0
  %t165 = load i32, ptr %t164
  store i32 %t165, ptr %l7, !tbaa !23
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [3 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { i32, i64, i32 }, ptr %t169, i32 0, i32 1
  %t171 = load i64, ptr %t170
  store i64 %t171, ptr %l8, !tbaa !24
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s10
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/typed:printer", ptr %t173, i32 0, i32 0
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t177 = load i32, ptr %l7, !tbaa !23
  %t178 = load ptr, ptr @__olang_prog_scope
  %t181 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t178, ptr %s10, ptr %t176, i32 %t177)
  store { i64, ptr } %t181, ptr %l66
  br label %bb34
bb34:
  %t182 = load i64, ptr %l8, !tbaa !24
  %t183 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t185 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = add i64 %t184, %t187
  %t189 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t191 = add i64 %t188, %t190
  %t193 = call i64 @__olang_fmt_i64(ptr null, i64 %t182)
  %t194 = add i64 %t191, %t193
  %t195 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t183, i64 %t184)
  %t196 = getelementptr i8, ptr %t195, i64 %t184
  call void @olang_textcopy(ptr %t196, ptr %t186, i64 %t187)
  %t197 = getelementptr i8, ptr %t196, i64 %t187
  call void @olang_textcopy(ptr %t197, ptr %t189, i64 %t190)
  %t198 = getelementptr i8, ptr %t197, i64 %t190
  %t199 = call i64 @__olang_fmt_i64(ptr %t198, i64 %t182)
  %t200 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t195, 1
  store { i64, ptr } %t201, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_c13c66c7f09ff87e_38ebe5e5af81f22)
  unreachable
bb36:
  %t203 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t203, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 32)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  store ptr %l2, ptr %l39, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t59, ptr %l41, !tbaa !27
  %t60 = load i64, ptr %l8, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t69 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %a0, ptr %t65)
  store { i64, ptr } %t69, ptr %l45
  br label %bb16
bb16:
  %t70 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t77 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t77, { i64, ptr } %t76)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l7, !tbaa !24
  br label %bb8
bb19:
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t84, ptr %l50
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t85 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:printer", ptr %t49, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t51, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb7
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:printer", ptr %t57, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t59, { i64, ptr } %a2)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:printer", ptr %t63, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t65, i8 10)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i32
  %l39 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i64
  %l87 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i64
  %l144 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i64
  %l159 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l168 = alloca ptr
  %l169 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i64
  %l181 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l186 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i64
  %l196 = alloca { i64, ptr }
  %l199 = alloca ptr
  %l200 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca i64
  %l207 = alloca i32
  %l209 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l215 = alloca i1
  %l220 = alloca ptr
  %l221 = alloca i64
  %l225 = alloca { i64, ptr }
  %l228 = alloca ptr
  %l229 = alloca i1
  %l238 = alloca ptr
  %l239 = alloca i1
  %l250 = alloca ptr
  %l251 = alloca i1
  %l256 = alloca ptr
  %l257 = alloca i64
  %l260 = alloca { i64, ptr }
  %l268 = alloca ptr
  %l269 = alloca i1
  %l274 = alloca ptr
  %l275 = alloca i64
  %l280 = alloca { i64, ptr }
  %l285 = alloca ptr
  %l286 = alloca i1
  %l291 = alloca ptr
  %l292 = alloca i64
  %l296 = alloca { i64, ptr }
  %l299 = alloca ptr
  %l300 = alloca i1
  %l305 = alloca ptr
  %l306 = alloca i64
  %l307 = alloca ptr
  %l312 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.builder
  %s22room = alloca [64 x i8], align 8
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t2 = load ptr, ptr %l25, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l25, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l26, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l26, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l33, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  store i64 %t23, ptr %l34, !tbaa !24
  %t24 = load i32, ptr %l3, !tbaa !23
  store i32 %t24, ptr %l35, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s1, ptr %t25, ptr %t26)
  store { i64, ptr } %t30, ptr %l39
  br label %bb6
bb6:
  %t31 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t33 = load i32, ptr %l35, !tbaa !23
  %t34 = sext i32 %t33 to i64
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = add i64 %t39, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t31, i64 %t32)
  %t45 = getelementptr i8, ptr %t44, i64 %t32
  %t46 = call i64 @__olang_fmt_i64(ptr %t45, i64 %t34)
  %t47 = getelementptr i8, ptr %t45, i64 %t35
  call void @olang_textcopy(ptr %t47, ptr %t37, i64 %t38)
  %t48 = getelementptr i8, ptr %t47, i64 %t38
  call void @olang_textcopy(ptr %t48, ptr %t41, i64 %t42)
  %t49 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t44, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t58 = load ptr, ptr %l33, !tbaa !29
  %t59 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s1, ptr %t58, i64 %t59, { i64, ptr } %t57)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb163
bb8:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t62 = load ptr, ptr %l42, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb9, label %bb10
bb9:
  %t65 = load ptr, ptr %l42, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 17}
  %t68 = icmp eq i64 %t66, 1
  store i1 %t68, ptr %l43, !tbaa !21
  br label %bb10
bb10:
  %t69 = load i1, ptr %l43, !tbaa !21
  br i1 %t69, label %bb11, label %bb12
bb11:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 1
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l5, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [3 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l50, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  store i64 %t83, ptr %l51, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t88 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s3, ptr %t84, ptr %t85)
  store { i64, ptr } %t88, ptr %l54
  br label %bb14
bb14:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t94 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s3, ptr %t89, ptr %t90)
  store { i64, ptr } %t94, ptr %l58
  br label %bb15
bb15:
  %t95 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t97 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = add i64 %t96, %t99
  %t101 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t103 = add i64 %t100, %t102
  %t104 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = add i64 %t103, %t106
  %t108 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t107)
  call void @olang_textcopy(ptr %t108, ptr %t95, i64 %t96)
  %t109 = getelementptr i8, ptr %t108, i64 %t96
  call void @olang_textcopy(ptr %t109, ptr %t98, i64 %t99)
  %t110 = getelementptr i8, ptr %t109, i64 %t99
  call void @olang_textcopy(ptr %t110, ptr %t101, i64 %t102)
  %t111 = getelementptr i8, ptr %t110, i64 %t102
  call void @olang_textcopy(ptr %t111, ptr %t105, i64 %t106)
  %t112 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t108, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = extractvalue { i64, ptr } %t113, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t121 = load ptr, ptr %l50, !tbaa !29
  %t122 = load i64, ptr %l51, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s3, ptr %t121, i64 %t122, { i64, ptr } %t120)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb163
bb17:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t125 = load ptr, ptr %l61, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb18, label %bb19
bb18:
  %t128 = load ptr, ptr %l61, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 17}
  %t131 = icmp eq i64 %t129, 2
  store i1 %t131, ptr %l62, !tbaa !21
  br label %bb19
bb19:
  %t132 = load i1, ptr %l62, !tbaa !21
  br i1 %t132, label %bb20, label %bb21
bb20:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", ptr }, ptr %t135, i32 0, i32 1
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l67, !tbaa !29
  %t140 = load i64, ptr %l2, !tbaa !24
  store i64 %t140, ptr %l68, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l7, !tbaa !29
  %t146 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t141, ptr %t142)
  store { i64, ptr } %t146, ptr %l72
  br label %bb23
bb23:
  %t147 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t149 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = add i64 %t148, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t147, i64 %t148)
  %t154 = getelementptr i8, ptr %t153, i64 %t148
  call void @olang_textcopy(ptr %t154, ptr %t150, i64 %t151)
  %t155 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = load ptr, ptr %l67, !tbaa !29
  %t165 = load i64, ptr %l68, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s5, ptr %t164, i64 %t165, { i64, ptr } %t163)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb163
bb25:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t168 = load ptr, ptr %l75, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb26, label %bb27
bb26:
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 17}
  %t174 = icmp eq i64 %t172, 3
  store i1 %t174, ptr %l76, !tbaa !21
  br label %bb27
bb27:
  %t175 = load i1, ptr %l76, !tbaa !21
  br i1 %t175, label %bb28, label %bb29
bb28:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l8, !tbaa !29
  br label %bb30
bb29:
  br label %bb42
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l81, !tbaa !29
  %t183 = load i64, ptr %l2, !tbaa !24
  store i64 %t183, ptr %l82, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load ptr, ptr %l8, !tbaa !29
  %t187 = getelementptr %"compiler/typed:If", ptr %t185, i32 0, i32 0
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t192 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %t184, ptr %t188)
  store { i64, ptr } %t192, ptr %l87
  br label %bb31
bb31:
  %t193 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t195 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = add i64 %t194, %t197
  %t199 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t198)
  call void @olang_textcopy(ptr %t199, ptr %t193, i64 %t194)
  %t200 = getelementptr i8, ptr %t199, i64 %t194
  call void @olang_textcopy(ptr %t200, ptr %t196, i64 %t197)
  %t201 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t199, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  %t210 = load ptr, ptr %l81, !tbaa !29
  %t211 = load i64, ptr %l82, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s7, ptr %t210, i64 %t211, { i64, ptr } %t209)
  br label %bb32
bb32:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l8, !tbaa !29
  %t216 = getelementptr %"compiler/typed:If", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t218 = load i64, ptr %l2, !tbaa !24
  %t220 = add i64 %t218, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t213, ptr %t217, i64 %t220)
  br label %bb33
bb33:
  %t224 = load ptr, ptr %l8, !tbaa !29
  %t226 = getelementptr %"compiler/typed:If", ptr %t224, i32 0, i32 2
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s9, ptr %t233, i64 %t234, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb36
bb35:
  br label %bb41
bb36:
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l101, !tbaa !29
  %t238 = load ptr, ptr %l8, !tbaa !29
  %t240 = getelementptr %"compiler/typed:If", ptr %t238, i32 0, i32 2
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = icmp eq ptr %t241, null
  br i1 %t243, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_7b432bbe8f05f1d7_7deffd42aa472253)
  unreachable
bb38:
  br label %bb39
bb39:
  %t245 = load ptr, ptr %l8, !tbaa !29
  %t247 = getelementptr %"compiler/typed:If", ptr %t245, i32 0, i32 2
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t249 = load i64, ptr %l2, !tbaa !24
  %t251 = add i64 %t249, 1
  %t252 = load ptr, ptr %l101, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t252, ptr %t248, i64 %t251)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb163
bb42:
  %t255 = load ptr, ptr %l1, !tbaa !29
  store ptr %t255, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t256 = load ptr, ptr %l109, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb43, label %bb44
bb43:
  %t259 = load ptr, ptr %l109, !tbaa !29
  %t260 = load i64, ptr %t259, !range !{i64 0, i64 17}
  %t262 = icmp eq i64 %t260, 4
  store i1 %t262, ptr %l110, !tbaa !21
  br label %bb44
bb44:
  %t263 = load i1, ptr %l110, !tbaa !21
  br i1 %t263, label %bb45, label %bb46
bb45:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [3 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t266, i32 0, i32 1
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l9, !tbaa !29
  %t270 = load ptr, ptr %l1, !tbaa !29
  %t272 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  %t273 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t272, i32 0, i32 2
  %t274 = load ptr, ptr %t273
  store ptr %t274, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb55
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s10, ptr %t276, i64 %t277, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  br label %bb48
bb48:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l9, !tbaa !29
  %t282 = load i64, ptr %l2, !tbaa !24
  %t284 = add i64 %t282, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t280, ptr %t281, i64 %t284)
  br label %bb49
bb49:
  %t288 = load ptr, ptr %l10, !tbaa !29
  %t290 = icmp eq ptr %t288, null
  %t292 = xor i1 %t290, true
  br i1 %t292, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s11, ptr %t294, i64 %t295, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l10, !tbaa !29
  %t300 = load i64, ptr %l2, !tbaa !24
  %t302 = add i64 %t300, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t298, ptr %t299, i64 %t302)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb163
bb55:
  %t306 = load ptr, ptr %l1, !tbaa !29
  store ptr %t306, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t307 = load ptr, ptr %l132, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb56, label %bb57
bb56:
  %t310 = load ptr, ptr %l132, !tbaa !29
  %t311 = load i64, ptr %t310, !range !{i64 0, i64 17}
  %t313 = icmp eq i64 %t311, 5
  store i1 %t313, ptr %l133, !tbaa !21
  br label %bb57
bb57:
  %t314 = load i1, ptr %l133, !tbaa !21
  br i1 %t314, label %bb58, label %bb59
bb58:
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t317 = getelementptr { i64, [3 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t317, i32 0, i32 1
  %t319 = load i32, ptr %t318, !range !{i32 0, i32 2}
  store i32 %t319, ptr %l11
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr { i64, [3 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t323, i32 0, i32 2
  %t325 = load i32, ptr %t324
  store i32 %t325, ptr %l12, !tbaa !23
  br label %bb60
bb59:
  br label %bb65
bb60:
  store %olang.scope zeroinitializer, ptr %s12
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l140, !tbaa !29
  %t328 = load i64, ptr %l2, !tbaa !24
  store i64 %t328, ptr %l141, !tbaa !24
  %t329 = load i32, ptr %l11, !range !{i32 0, i32 2}
  %t331 = trunc i64 0 to i32
  %t332 = icmp eq i32 %t329, %t331
  br i1 %t332, label %bb61, label %bb62
bb61:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l144, !tbaa !27
  br label %bb63
bb62:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l144, !tbaa !27
  br label %bb63
bb63:
  %t334 = load i32, ptr %l12, !tbaa !23
  %t335 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t340 = add i64 %t337, %t339
  %t342 = sext i32 %t334 to i64
  %t343 = call i64 @__olang_fmt_i64(ptr null, i64 %t342)
  %t344 = add i64 %t340, %t343
  %t345 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t344)
  call void @olang_textcopy(ptr %t345, ptr %t336, i64 %t337)
  %t346 = getelementptr i8, ptr %t345, i64 %t337
  call void @olang_textcopy(ptr %t346, ptr %t338, i64 %t339)
  %t347 = getelementptr i8, ptr %t346, i64 %t339
  %t348 = call i64 @__olang_fmt_i64(ptr %t347, i64 %t342)
  %t349 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t345, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } %t350, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  %t358 = load ptr, ptr %l140, !tbaa !29
  %t359 = load i64, ptr %l141, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s12, ptr %t358, i64 %t359, { i64, ptr } %t357)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s12)
  br label %bb163
bb65:
  %t361 = load ptr, ptr %l1, !tbaa !29
  store ptr %t361, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t362 = load ptr, ptr %l148, !tbaa !29
  %t363 = icmp ne ptr %t362, null
  br i1 %t363, label %bb66, label %bb67
bb66:
  %t365 = load ptr, ptr %l148, !tbaa !29
  %t366 = load i64, ptr %t365, !range !{i64 0, i64 17}
  %t368 = icmp eq i64 %t366, 6
  store i1 %t368, ptr %l149, !tbaa !21
  br label %bb67
bb67:
  %t369 = load i1, ptr %l149, !tbaa !21
  br i1 %t369, label %bb68, label %bb69
bb68:
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t372 = getelementptr { i64, [3 x i64] }, ptr %t370, i32 0, i32 1
  %t373 = getelementptr { %"compiler/source:Span", ptr }, ptr %t372, i32 0, i32 1
  %t374 = load ptr, ptr %t373
  store ptr %t374, ptr %l13, !tbaa !29
  br label %bb70
bb69:
  br label %bb76
bb70:
  store %olang.scope zeroinitializer, ptr %s14
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l154, !tbaa !29
  %t377 = load i64, ptr %l2, !tbaa !24
  store i64 %t377, ptr %l155, !tbaa !24
  %t378 = load ptr, ptr %l13, !tbaa !29
  %t380 = icmp eq ptr %t378, null
  %t382 = xor i1 %t380, true
  br i1 %t382, label %bb71, label %bb72
bb71:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load ptr, ptr %l13, !tbaa !29
  %t389 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s14, ptr %t384, ptr %t385)
  store { i64, ptr } %t389, ptr %l163
  br label %bb73
bb72:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l159, !tbaa !27
  br label %bb74
bb73:
  %t390 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t391 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t392 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = add i64 %t391, %t394
  %t396 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t395)
  call void @olang_textcopy(ptr %t396, ptr %t390, i64 %t391)
  %t397 = getelementptr i8, ptr %t396, i64 %t391
  call void @olang_textcopy(ptr %t397, ptr %t393, i64 %t394)
  %t398 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t396, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = extractvalue { i64, ptr } %t399, 1
  %t403 = mul i64 %t401, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t403)
  call void @llvm.memcpy.p0.p0.i64(ptr %t404, ptr %t402, i64 %t403, i1 false)
  %t405 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  store { i64, ptr } %t406, ptr %l159, !tbaa !27
  br label %bb74
bb74:
  %t408 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t409 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t410 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t410, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = add i64 %t409, %t412
  %t414 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t413)
  call void @olang_textcopy(ptr %t414, ptr %t408, i64 %t409)
  %t415 = getelementptr i8, ptr %t414, i64 %t409
  call void @olang_textcopy(ptr %t415, ptr %t411, i64 %t412)
  %t416 = insertvalue { i64, ptr } undef, i64 %t413, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t414, 1
  %t419 = extractvalue { i64, ptr } %t417, 0
  %t420 = extractvalue { i64, ptr } %t417, 1
  %t421 = mul i64 %t419, 1
  %t422 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t421)
  call void @llvm.memcpy.p0.p0.i64(ptr %t422, ptr %t420, i64 %t421, i1 false)
  %t423 = insertvalue { i64, ptr } undef, i64 %t419, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t422, 1
  %t425 = load ptr, ptr %l154, !tbaa !29
  %t426 = load i64, ptr %l155, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s14, ptr %t425, i64 %t426, { i64, ptr } %t424)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb163
bb76:
  %t428 = load ptr, ptr %l1, !tbaa !29
  store ptr %t428, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t429 = load ptr, ptr %l168, !tbaa !29
  %t430 = icmp ne ptr %t429, null
  br i1 %t430, label %bb77, label %bb78
bb77:
  %t432 = load ptr, ptr %l168, !tbaa !29
  %t433 = load i64, ptr %t432, !range !{i64 0, i64 17}
  %t435 = icmp eq i64 %t433, 7
  store i1 %t435, ptr %l169, !tbaa !21
  br label %bb78
bb78:
  %t436 = load i1, ptr %l169, !tbaa !21
  br i1 %t436, label %bb79, label %bb80
bb79:
  %t437 = load ptr, ptr %l1, !tbaa !29
  %t439 = getelementptr { i64, [3 x i64] }, ptr %t437, i32 0, i32 1
  %t440 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t439, i32 0, i32 1
  %t441 = load i32, ptr %t440
  store i32 %t441, ptr %l14, !tbaa !23
  %t443 = load ptr, ptr %l1, !tbaa !29
  %t445 = getelementptr { i64, [3 x i64] }, ptr %t443, i32 0, i32 1
  %t446 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t445, i32 0, i32 2
  %t447 = load i64, ptr %t446
  store i64 %t447, ptr %l15, !tbaa !24
  br label %bb81
bb80:
  br label %bb84
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t449 = load ptr, ptr %l0, !tbaa !29
  store ptr %t449, ptr %l176, !tbaa !29
  %t450 = load i64, ptr %l2, !tbaa !24
  store i64 %t450, ptr %l177, !tbaa !24
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/typed:printer", ptr %t451, i32 0, i32 0
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t455 = load i32, ptr %l14, !tbaa !23
  %t456 = load ptr, ptr @__olang_prog_scope
  %t459 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t456, ptr %s17, ptr %t454, i32 %t455)
  store { i64, ptr } %t459, ptr %l181
  br label %bb82
bb82:
  %t460 = load i64, ptr %l15, !tbaa !24
  %t461 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t463 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t463, 1
  %t465 = extractvalue { i64, ptr } %t463, 0
  %t466 = add i64 %t462, %t465
  %t467 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t468 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t469 = add i64 %t466, %t468
  %t471 = call i64 @__olang_fmt_i64(ptr null, i64 %t460)
  %t472 = add i64 %t469, %t471
  %t473 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t472)
  call void @olang_textcopy(ptr %t473, ptr %t461, i64 %t462)
  %t474 = getelementptr i8, ptr %t473, i64 %t462
  call void @olang_textcopy(ptr %t474, ptr %t464, i64 %t465)
  %t475 = getelementptr i8, ptr %t474, i64 %t465
  call void @olang_textcopy(ptr %t475, ptr %t467, i64 %t468)
  %t476 = getelementptr i8, ptr %t475, i64 %t468
  %t477 = call i64 @__olang_fmt_i64(ptr %t476, i64 %t460)
  %t478 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t479 = insertvalue { i64, ptr } %t478, ptr %t473, 1
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t482 = extractvalue { i64, ptr } %t479, 1
  %t483 = mul i64 %t481, 1
  %t484 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t483)
  call void @llvm.memcpy.p0.p0.i64(ptr %t484, ptr %t482, i64 %t483, i1 false)
  %t485 = insertvalue { i64, ptr } undef, i64 %t481, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t484, 1
  %t487 = load ptr, ptr %l176, !tbaa !29
  %t488 = load i64, ptr %l177, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s17, ptr %t487, i64 %t488, { i64, ptr } %t486)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb163
bb84:
  %t490 = load ptr, ptr %l1, !tbaa !29
  store ptr %t490, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t491 = load ptr, ptr %l185, !tbaa !29
  %t492 = icmp ne ptr %t491, null
  br i1 %t492, label %bb85, label %bb86
bb85:
  %t494 = load ptr, ptr %l185, !tbaa !29
  %t495 = load i64, ptr %t494, !range !{i64 0, i64 17}
  %t497 = icmp eq i64 %t495, 8
  store i1 %t497, ptr %l186, !tbaa !21
  br label %bb86
bb86:
  %t498 = load i1, ptr %l186, !tbaa !21
  br i1 %t498, label %bb87, label %bb88
bb87:
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = getelementptr { i64, [3 x i64] }, ptr %t499, i32 0, i32 1
  %t502 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t501, i32 0, i32 1
  %t503 = load ptr, ptr %t502
  store ptr %t503, ptr %l16, !tbaa !29
  br label %bb89
bb88:
  br label %bb92
bb89:
  store %olang.scope zeroinitializer, ptr %s19
  %t505 = load ptr, ptr %l0, !tbaa !29
  store ptr %t505, ptr %l191, !tbaa !29
  %t506 = load i64, ptr %l2, !tbaa !24
  store i64 %t506, ptr %l192, !tbaa !24
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load ptr, ptr %l16, !tbaa !29
  %t512 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s19, ptr %t507, ptr %t508)
  store { i64, ptr } %t512, ptr %l196
  br label %bb90
bb90:
  %t513 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t514 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t515 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t515, 1
  %t517 = extractvalue { i64, ptr } %t515, 0
  %t518 = add i64 %t514, %t517
  %t519 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t518)
  call void @olang_textcopy(ptr %t519, ptr %t513, i64 %t514)
  %t520 = getelementptr i8, ptr %t519, i64 %t514
  call void @olang_textcopy(ptr %t520, ptr %t516, i64 %t517)
  %t521 = insertvalue { i64, ptr } undef, i64 %t518, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t519, 1
  %t524 = extractvalue { i64, ptr } %t522, 0
  %t525 = extractvalue { i64, ptr } %t522, 1
  %t526 = mul i64 %t524, 1
  %t527 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t526)
  call void @llvm.memcpy.p0.p0.i64(ptr %t527, ptr %t525, i64 %t526, i1 false)
  %t528 = insertvalue { i64, ptr } undef, i64 %t524, 0
  %t529 = insertvalue { i64, ptr } %t528, ptr %t527, 1
  %t530 = load ptr, ptr %l191, !tbaa !29
  %t531 = load i64, ptr %l192, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s19, ptr %t530, i64 %t531, { i64, ptr } %t529)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s19)
  br label %bb163
bb92:
  %t533 = load ptr, ptr %l1, !tbaa !29
  store ptr %t533, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t534 = load ptr, ptr %l199, !tbaa !29
  %t535 = icmp ne ptr %t534, null
  br i1 %t535, label %bb93, label %bb94
bb93:
  %t537 = load ptr, ptr %l199, !tbaa !29
  %t538 = load i64, ptr %t537, !range !{i64 0, i64 17}
  %t540 = icmp eq i64 %t538, 9
  store i1 %t540, ptr %l200, !tbaa !21
  br label %bb94
bb94:
  %t541 = load i1, ptr %l200, !tbaa !21
  br i1 %t541, label %bb95, label %bb96
bb95:
  %t542 = load ptr, ptr %l1, !tbaa !29
  %t544 = getelementptr { i64, [3 x i64] }, ptr %t542, i32 0, i32 1
  %t545 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t544, i32 0, i32 1
  %t546 = load i32, ptr %t545, !range !{i32 0, i32 2}
  store i32 %t546, ptr %l17
  br label %bb97
bb96:
  br label %bb101
bb97:
  store %olang.scope zeroinitializer, ptr %s21
  %t548 = load ptr, ptr %l0, !tbaa !29
  store ptr %t548, ptr %l205, !tbaa !29
  %t549 = load i64, ptr %l2, !tbaa !24
  store i64 %t549, ptr %l206, !tbaa !24
  %t550 = load i32, ptr %l17, !range !{i32 0, i32 2}
  store i32 %t550, ptr %l207
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s22
  store ptr %s22room, ptr %s22
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aExitKind(ptr %s22, ptr %l207, i64 0)
  br label %bb98
bb98:
  %t552 = load ptr, ptr %s22
  %t553 = getelementptr %olang.builder, ptr %s22, i32 0, i32 1
  %t554 = load i64, ptr %t553
  %t555 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t554)
  call void @olang_textcopy(ptr %t555, ptr %t552, i64 %t554)
  %t556 = insertvalue { i64, ptr } undef, i64 %t554, 0
  %t557 = insertvalue { i64, ptr } %t556, ptr %t555, 1
  store { i64, ptr } %t557, ptr %l209, !tbaa !27
  %t558 = getelementptr %olang.builder, ptr %s22, i32 0, i32 3
  %t559 = load ptr, ptr %t558
  %t560 = icmp ne ptr %t559, null
  br i1 %t560, label %sbgrew.561, label %sbdone.562
sbgrew.561:
  call void @__olang_sb_done(ptr %s22)
  br label %sbdone.562
sbdone.562:
  %t563 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t564 = extractvalue { i64, ptr } %t563, 0
  %t565 = extractvalue { i64, ptr } %t563, 1
  %t566 = mul i64 %t564, 1
  %t567 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t566)
  call void @llvm.memcpy.p0.p0.i64(ptr %t567, ptr %t565, i64 %t566, i1 false)
  %t568 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t567, 1
  %t571 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s21, ptr %s21, { i64, ptr } %t569)
  store { i64, ptr } %t571, ptr %l211
  br label %bb99
bb99:
  %t572 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t573 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t574 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t575 = extractvalue { i64, ptr } %t574, 1
  %t576 = extractvalue { i64, ptr } %t574, 0
  %t577 = add i64 %t573, %t576
  %t578 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t577)
  call void @olang_textcopy(ptr %t578, ptr %t572, i64 %t573)
  %t579 = getelementptr i8, ptr %t578, i64 %t573
  call void @olang_textcopy(ptr %t579, ptr %t575, i64 %t576)
  %t580 = insertvalue { i64, ptr } undef, i64 %t577, 0
  %t581 = insertvalue { i64, ptr } %t580, ptr %t578, 1
  %t583 = extractvalue { i64, ptr } %t581, 0
  %t584 = extractvalue { i64, ptr } %t581, 1
  %t585 = mul i64 %t583, 1
  %t586 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t585)
  call void @llvm.memcpy.p0.p0.i64(ptr %t586, ptr %t584, i64 %t585, i1 false)
  %t587 = insertvalue { i64, ptr } undef, i64 %t583, 0
  %t588 = insertvalue { i64, ptr } %t587, ptr %t586, 1
  %t589 = load ptr, ptr %l205, !tbaa !29
  %t590 = load i64, ptr %l206, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s21, ptr %t589, i64 %t590, { i64, ptr } %t588)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s21)
  br label %bb163
bb101:
  %t592 = load ptr, ptr %l1, !tbaa !29
  store ptr %t592, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t593 = load ptr, ptr %l214, !tbaa !29
  %t594 = icmp ne ptr %t593, null
  br i1 %t594, label %bb102, label %bb103
bb102:
  %t596 = load ptr, ptr %l214, !tbaa !29
  %t597 = load i64, ptr %t596, !range !{i64 0, i64 17}
  %t599 = icmp eq i64 %t597, 10
  store i1 %t599, ptr %l215, !tbaa !21
  br label %bb103
bb103:
  %t600 = load i1, ptr %l215, !tbaa !21
  br i1 %t600, label %bb104, label %bb105
bb104:
  %t601 = load ptr, ptr %l1, !tbaa !29
  %t603 = getelementptr { i64, [3 x i64] }, ptr %t601, i32 0, i32 1
  %t604 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t603, i32 0, i32 1
  %t605 = load ptr, ptr %t604
  store ptr %t605, ptr %l18, !tbaa !29
  br label %bb106
bb105:
  br label %bb109
bb106:
  store %olang.scope zeroinitializer, ptr %s24
  %t607 = load ptr, ptr %l0, !tbaa !29
  store ptr %t607, ptr %l220, !tbaa !29
  %t608 = load i64, ptr %l2, !tbaa !24
  store i64 %t608, ptr %l221, !tbaa !24
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t610 = load ptr, ptr %l18, !tbaa !29
  %t614 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s24, ptr %t609, ptr %t610)
  store { i64, ptr } %t614, ptr %l225
  br label %bb107
bb107:
  %t615 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t616 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t617 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t618 = extractvalue { i64, ptr } %t617, 1
  %t619 = extractvalue { i64, ptr } %t617, 0
  %t620 = add i64 %t616, %t619
  %t621 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t620)
  call void @olang_textcopy(ptr %t621, ptr %t615, i64 %t616)
  %t622 = getelementptr i8, ptr %t621, i64 %t616
  call void @olang_textcopy(ptr %t622, ptr %t618, i64 %t619)
  %t623 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t624 = insertvalue { i64, ptr } %t623, ptr %t621, 1
  %t626 = extractvalue { i64, ptr } %t624, 0
  %t627 = extractvalue { i64, ptr } %t624, 1
  %t628 = mul i64 %t626, 1
  %t629 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t628)
  call void @llvm.memcpy.p0.p0.i64(ptr %t629, ptr %t627, i64 %t628, i1 false)
  %t630 = insertvalue { i64, ptr } undef, i64 %t626, 0
  %t631 = insertvalue { i64, ptr } %t630, ptr %t629, 1
  %t632 = load ptr, ptr %l220, !tbaa !29
  %t633 = load i64, ptr %l221, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s24, ptr %t632, i64 %t633, { i64, ptr } %t631)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s24)
  br label %bb163
bb109:
  %t635 = load ptr, ptr %l1, !tbaa !29
  store ptr %t635, ptr %l228, !tbaa !29
  store i1 false, ptr %l229, !tbaa !21
  %t636 = load ptr, ptr %l228, !tbaa !29
  %t637 = icmp ne ptr %t636, null
  br i1 %t637, label %bb110, label %bb111
bb110:
  %t639 = load ptr, ptr %l228, !tbaa !29
  %t640 = load i64, ptr %t639, !range !{i64 0, i64 17}
  %t642 = icmp eq i64 %t640, 11
  store i1 %t642, ptr %l229, !tbaa !21
  br label %bb111
bb111:
  %t643 = load i1, ptr %l229, !tbaa !21
  br i1 %t643, label %bb112, label %bb113
bb112:
  %t644 = load ptr, ptr %l1, !tbaa !29
  %t646 = getelementptr { i64, [3 x i64] }, ptr %t644, i32 0, i32 1
  %t647 = getelementptr { %"compiler/source:Span", ptr }, ptr %t646, i32 0, i32 1
  %t648 = load ptr, ptr %t647
  store ptr %t648, ptr %l19, !tbaa !29
  br label %bb114
bb113:
  br label %bb116
bb114:
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load ptr, ptr %l19, !tbaa !29
  %t652 = load i64, ptr %l2, !tbaa !24
  %t654 = add i64 %t652, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t650, ptr %t651, i64 %t654)
  br label %bb115
bb115:
  br label %bb163
bb116:
  %t658 = load ptr, ptr %l1, !tbaa !29
  store ptr %t658, ptr %l238, !tbaa !29
  store i1 false, ptr %l239, !tbaa !21
  %t659 = load ptr, ptr %l238, !tbaa !29
  %t660 = icmp ne ptr %t659, null
  br i1 %t660, label %bb117, label %bb118
bb117:
  %t662 = load ptr, ptr %l238, !tbaa !29
  %t663 = load i64, ptr %t662, !range !{i64 0, i64 17}
  %t665 = icmp eq i64 %t663, 12
  store i1 %t665, ptr %l239, !tbaa !21
  br label %bb118
bb118:
  %t666 = load i1, ptr %l239, !tbaa !21
  br i1 %t666, label %bb119, label %bb120
bb119:
  %t667 = load ptr, ptr %l1, !tbaa !29
  %t669 = getelementptr { i64, [3 x i64] }, ptr %t667, i32 0, i32 1
  %t670 = getelementptr { %"compiler/source:Span", ptr }, ptr %t669, i32 0, i32 1
  %t671 = load ptr, ptr %t670
  store ptr %t671, ptr %l20, !tbaa !29
  br label %bb121
bb120:
  br label %bb124
bb121:
  store %olang.scope zeroinitializer, ptr %s27
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t674 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s27, ptr %t673, i64 %t674, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb122
bb122:
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t678 = load ptr, ptr %l20, !tbaa !29
  %t679 = load i64, ptr %l2, !tbaa !24
  %t681 = add i64 %t679, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t677, ptr %t678, i64 %t681)
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s27)
  br label %bb163
bb124:
  %t685 = load ptr, ptr %l1, !tbaa !29
  store ptr %t685, ptr %l250, !tbaa !29
  store i1 false, ptr %l251, !tbaa !21
  %t686 = load ptr, ptr %l250, !tbaa !29
  %t687 = icmp ne ptr %t686, null
  br i1 %t687, label %bb125, label %bb126
bb125:
  %t689 = load ptr, ptr %l250, !tbaa !29
  %t690 = load i64, ptr %t689, !range !{i64 0, i64 17}
  %t692 = icmp eq i64 %t690, 13
  store i1 %t692, ptr %l251, !tbaa !21
  br label %bb126
bb126:
  %t693 = load i1, ptr %l251, !tbaa !21
  br i1 %t693, label %bb127, label %bb128
bb127:
  %t694 = load ptr, ptr %l1, !tbaa !29
  %t696 = getelementptr { i64, [3 x i64] }, ptr %t694, i32 0, i32 1
  %t697 = getelementptr { %"compiler/source:Span", ptr }, ptr %t696, i32 0, i32 1
  %t698 = load ptr, ptr %t697
  store ptr %t698, ptr %l21, !tbaa !29
  br label %bb129
bb128:
  br label %bb135
bb129:
  store %olang.scope zeroinitializer, ptr %s28
  %t700 = load ptr, ptr %l0, !tbaa !29
  store ptr %t700, ptr %l256, !tbaa !29
  %t701 = load i64, ptr %l2, !tbaa !24
  store i64 %t701, ptr %l257, !tbaa !24
  %t702 = load ptr, ptr %l21, !tbaa !29
  %t704 = getelementptr %"compiler/typed:Join", ptr %t702, i32 0, i32 1
  %t705 = load i1, ptr %t704, !tbaa !21
  br i1 %t705, label %bb130, label %bb131
bb130:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l260, !tbaa !27
  br label %bb132
bb131:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l260, !tbaa !27
  br label %bb132
bb132:
  %t707 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t708 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t709 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t710 = extractvalue { i64, ptr } %t709, 1
  %t711 = extractvalue { i64, ptr } %t709, 0
  %t712 = add i64 %t708, %t711
  %t713 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t712)
  call void @olang_textcopy(ptr %t713, ptr %t707, i64 %t708)
  %t714 = getelementptr i8, ptr %t713, i64 %t708
  call void @olang_textcopy(ptr %t714, ptr %t710, i64 %t711)
  %t715 = insertvalue { i64, ptr } undef, i64 %t712, 0
  %t716 = insertvalue { i64, ptr } %t715, ptr %t713, 1
  %t718 = extractvalue { i64, ptr } %t716, 0
  %t719 = extractvalue { i64, ptr } %t716, 1
  %t720 = mul i64 %t718, 1
  %t721 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t720)
  call void @llvm.memcpy.p0.p0.i64(ptr %t721, ptr %t719, i64 %t720, i1 false)
  %t722 = insertvalue { i64, ptr } undef, i64 %t718, 0
  %t723 = insertvalue { i64, ptr } %t722, ptr %t721, 1
  %t724 = load ptr, ptr %l256, !tbaa !29
  %t725 = load i64, ptr %l257, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s28, ptr %t724, i64 %t725, { i64, ptr } %t723)
  br label %bb133
bb133:
  %t727 = load ptr, ptr %l0, !tbaa !29
  %t728 = load ptr, ptr %l21, !tbaa !29
  %t730 = getelementptr %"compiler/typed:Join", ptr %t728, i32 0, i32 0
  %t731 = load ptr, ptr %t730, !tbaa !29
  %t732 = load i64, ptr %l2, !tbaa !24
  %t734 = add i64 %t732, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t727, ptr %t731, i64 %t734)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s28)
  br label %bb163
bb135:
  %t738 = load ptr, ptr %l1, !tbaa !29
  store ptr %t738, ptr %l268, !tbaa !29
  store i1 false, ptr %l269, !tbaa !21
  %t739 = load ptr, ptr %l268, !tbaa !29
  %t740 = icmp ne ptr %t739, null
  br i1 %t740, label %bb136, label %bb137
bb136:
  %t742 = load ptr, ptr %l268, !tbaa !29
  %t743 = load i64, ptr %t742, !range !{i64 0, i64 17}
  %t745 = icmp eq i64 %t743, 14
  store i1 %t745, ptr %l269, !tbaa !21
  br label %bb137
bb137:
  %t746 = load i1, ptr %l269, !tbaa !21
  br i1 %t746, label %bb138, label %bb139
bb138:
  %t747 = load ptr, ptr %l1, !tbaa !29
  %t749 = getelementptr { i64, [3 x i64] }, ptr %t747, i32 0, i32 1
  %t750 = getelementptr { %"compiler/source:Span", ptr }, ptr %t749, i32 0, i32 1
  %t751 = load ptr, ptr %t750
  store ptr %t751, ptr %l22, !tbaa !29
  br label %bb140
bb139:
  br label %bb143
bb140:
  store %olang.scope zeroinitializer, ptr %s30
  %t753 = load ptr, ptr %l0, !tbaa !29
  store ptr %t753, ptr %l274, !tbaa !29
  %t754 = load i64, ptr %l2, !tbaa !24
  store i64 %t754, ptr %l275, !tbaa !24
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t756 = load ptr, ptr %l22, !tbaa !29
  %t758 = getelementptr %"compiler/typed:Spawn", ptr %t756, i32 0, i32 1
  %t759 = load ptr, ptr %t758, !tbaa !29
  %t763 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s30, ptr %t755, ptr %t759)
  store { i64, ptr } %t763, ptr %l280
  br label %bb141
bb141:
  %t764 = load ptr, ptr %l22, !tbaa !29
  %t766 = getelementptr %"compiler/typed:Spawn", ptr %t764, i32 0, i32 3
  %t767 = load i32, ptr %t766, !tbaa !23
  %t768 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t769 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t770 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t771 = extractvalue { i64, ptr } %t770, 1
  %t772 = extractvalue { i64, ptr } %t770, 0
  %t773 = add i64 %t769, %t772
  %t774 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t775 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t776 = add i64 %t773, %t775
  %t778 = sext i32 %t767 to i64
  %t779 = call i64 @__olang_fmt_i64(ptr null, i64 %t778)
  %t780 = add i64 %t776, %t779
  %t781 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t780)
  call void @olang_textcopy(ptr %t781, ptr %t768, i64 %t769)
  %t782 = getelementptr i8, ptr %t781, i64 %t769
  call void @olang_textcopy(ptr %t782, ptr %t771, i64 %t772)
  %t783 = getelementptr i8, ptr %t782, i64 %t772
  call void @olang_textcopy(ptr %t783, ptr %t774, i64 %t775)
  %t784 = getelementptr i8, ptr %t783, i64 %t775
  %t785 = call i64 @__olang_fmt_i64(ptr %t784, i64 %t778)
  %t786 = insertvalue { i64, ptr } undef, i64 %t780, 0
  %t787 = insertvalue { i64, ptr } %t786, ptr %t781, 1
  %t789 = extractvalue { i64, ptr } %t787, 0
  %t790 = extractvalue { i64, ptr } %t787, 1
  %t791 = mul i64 %t789, 1
  %t792 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t791)
  call void @llvm.memcpy.p0.p0.i64(ptr %t792, ptr %t790, i64 %t791, i1 false)
  %t793 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t792, 1
  %t795 = load ptr, ptr %l274, !tbaa !29
  %t796 = load i64, ptr %l275, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s30, ptr %t795, i64 %t796, { i64, ptr } %t794)
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s30)
  br label %bb163
bb143:
  %t798 = load ptr, ptr %l1, !tbaa !29
  store ptr %t798, ptr %l285, !tbaa !29
  store i1 false, ptr %l286, !tbaa !21
  %t799 = load ptr, ptr %l285, !tbaa !29
  %t800 = icmp ne ptr %t799, null
  br i1 %t800, label %bb144, label %bb145
bb144:
  %t802 = load ptr, ptr %l285, !tbaa !29
  %t803 = load i64, ptr %t802, !range !{i64 0, i64 17}
  %t805 = icmp eq i64 %t803, 15
  store i1 %t805, ptr %l286, !tbaa !21
  br label %bb145
bb145:
  %t806 = load i1, ptr %l286, !tbaa !21
  br i1 %t806, label %bb146, label %bb147
bb146:
  %t807 = load ptr, ptr %l1, !tbaa !29
  %t809 = getelementptr { i64, [3 x i64] }, ptr %t807, i32 0, i32 1
  %t810 = getelementptr { %"compiler/source:Span", ptr }, ptr %t809, i32 0, i32 1
  %t811 = load ptr, ptr %t810
  store ptr %t811, ptr %l23, !tbaa !29
  br label %bb148
bb147:
  br label %bb151
bb148:
  store %olang.scope zeroinitializer, ptr %s32
  %t813 = load ptr, ptr %l0, !tbaa !29
  store ptr %t813, ptr %l291, !tbaa !29
  %t814 = load i64, ptr %l2, !tbaa !24
  store i64 %t814, ptr %l292, !tbaa !24
  %t815 = load ptr, ptr %l0, !tbaa !29
  %t816 = load ptr, ptr %l23, !tbaa !29
  %t820 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s32, ptr %t815, ptr %t816)
  store { i64, ptr } %t820, ptr %l296
  br label %bb149
bb149:
  %t821 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t822 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t823 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t824 = extractvalue { i64, ptr } %t823, 1
  %t825 = extractvalue { i64, ptr } %t823, 0
  %t826 = add i64 %t822, %t825
  %t827 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t826)
  call void @olang_textcopy(ptr %t827, ptr %t821, i64 %t822)
  %t828 = getelementptr i8, ptr %t827, i64 %t822
  call void @olang_textcopy(ptr %t828, ptr %t824, i64 %t825)
  %t829 = insertvalue { i64, ptr } undef, i64 %t826, 0
  %t830 = insertvalue { i64, ptr } %t829, ptr %t827, 1
  %t832 = extractvalue { i64, ptr } %t830, 0
  %t833 = extractvalue { i64, ptr } %t830, 1
  %t834 = mul i64 %t832, 1
  %t835 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t834)
  call void @llvm.memcpy.p0.p0.i64(ptr %t835, ptr %t833, i64 %t834, i1 false)
  %t836 = insertvalue { i64, ptr } undef, i64 %t832, 0
  %t837 = insertvalue { i64, ptr } %t836, ptr %t835, 1
  %t838 = load ptr, ptr %l291, !tbaa !29
  %t839 = load i64, ptr %l292, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s32, ptr %t838, i64 %t839, { i64, ptr } %t837)
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s32)
  br label %bb163
bb151:
  %t841 = load ptr, ptr %l1, !tbaa !29
  store ptr %t841, ptr %l299, !tbaa !29
  store i1 false, ptr %l300, !tbaa !21
  %t842 = load ptr, ptr %l299, !tbaa !29
  %t843 = icmp ne ptr %t842, null
  br i1 %t843, label %bb152, label %bb153
bb152:
  %t845 = load ptr, ptr %l299, !tbaa !29
  %t846 = load i64, ptr %t845, !range !{i64 0, i64 17}
  %t848 = icmp eq i64 %t846, 16
  store i1 %t848, ptr %l300, !tbaa !21
  br label %bb153
bb153:
  %t849 = load i1, ptr %l300, !tbaa !21
  br i1 %t849, label %bb154, label %bb155
bb154:
  %t850 = load ptr, ptr %l1, !tbaa !29
  %t852 = getelementptr { i64, [3 x i64] }, ptr %t850, i32 0, i32 1
  %t853 = getelementptr { %"compiler/source:Span", ptr }, ptr %t852, i32 0, i32 1
  %t854 = load ptr, ptr %t853
  store ptr %t854, ptr %l24, !tbaa !29
  br label %bb156
bb155:
  br label %bb162
bb156:
  store %olang.scope zeroinitializer, ptr %s34
  %t856 = load ptr, ptr %l0, !tbaa !29
  store ptr %t856, ptr %l305, !tbaa !29
  %t857 = load i64, ptr %l2, !tbaa !24
  store i64 %t857, ptr %l306, !tbaa !24
  %t858 = load ptr, ptr %l0, !tbaa !29
  store ptr %t858, ptr %l307, !tbaa !29
  %t859 = load ptr, ptr %l24, !tbaa !29
  %t861 = icmp eq ptr %t859, null
  br i1 %t861, label %bb157, label %bb158
bb157:
  call void @__olang_check_failed(ptr @olang_loc_78afbb313fff45b8_957466907ebeb484)
  unreachable
bb158:
  br label %bb159
bb159:
  %t863 = load ptr, ptr %l24, !tbaa !29
  %t865 = load ptr, ptr %l307, !tbaa !29
  %t867 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s34, ptr %t865, ptr %t863)
  store { i64, ptr } %t867, ptr %l312
  br label %bb160
bb160:
  %t868 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t869 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t870 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t871 = extractvalue { i64, ptr } %t870, 1
  %t872 = extractvalue { i64, ptr } %t870, 0
  %t873 = add i64 %t869, %t872
  %t874 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t873)
  call void @olang_textcopy(ptr %t874, ptr %t868, i64 %t869)
  %t875 = getelementptr i8, ptr %t874, i64 %t869
  call void @olang_textcopy(ptr %t875, ptr %t871, i64 %t872)
  %t876 = insertvalue { i64, ptr } undef, i64 %t873, 0
  %t877 = insertvalue { i64, ptr } %t876, ptr %t874, 1
  %t879 = extractvalue { i64, ptr } %t877, 0
  %t880 = extractvalue { i64, ptr } %t877, 1
  %t881 = mul i64 %t879, 1
  %t882 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t881)
  call void @llvm.memcpy.p0.p0.i64(ptr %t882, ptr %t880, i64 %t881, i1 false)
  %t883 = insertvalue { i64, ptr } undef, i64 %t879, 0
  %t884 = insertvalue { i64, ptr } %t883, ptr %t882, 1
  %t885 = load ptr, ptr %l305, !tbaa !29
  %t886 = load i64, ptr %l306, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s34, ptr %t885, i64 %t886, { i64, ptr } %t884)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s34)
  br label %bb163
bb162:
  call void @__olang_check_failed(ptr @olang_loc_90a2a4daf32abd74_d37804826367c570)
  unreachable
bb163:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2econstItems(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 91)
  br label %bb2
bb2:
  store i64 0, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb5:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l18, !tbaa !24
  store i64 %t34, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l15, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb13, label %bb14
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store ptr %l1, ptr %l39, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t59, ptr %l40, !tbaa !27
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t67 = call { i64, ptr } @compiler_2ftyped_2econstText(ptr %v0, ptr %s2, ptr %t65)
  store { i64, ptr } %t67, ptr %l43
  br label %bb17
bb17:
  %t68 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t75, { i64, ptr } %t74)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb9
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 93)
  br label %bb21
bb21:
  %t83 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t83, ptr %l49
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l74 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i1
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l124 = alloca i1
  %l125 = alloca i1
  %l130 = alloca i1
  %l131 = alloca i1
  %l136 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l147 = alloca i1
  %l148 = alloca i1
  %l152 = alloca i1
  %l153 = alloca i1
  %l158 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca i1
  %l168 = alloca i1
  %l169 = alloca i1
  %l173 = alloca i1
  %l174 = alloca ptr
  %l175 = alloca i1
  %l183 = alloca i1
  %l184 = alloca i1
  %l188 = alloca i1
  %l189 = alloca i1
  %l194 = alloca i1
  %l201 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i1
  %l211 = alloca i1
  %l212 = alloca i1
  %l216 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca i1
  %l225 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i1
  %l235 = alloca i1
  %l236 = alloca ptr
  %l237 = alloca i1
  %l245 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t16 = load ptr, ptr %l24, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l24, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l25, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb170
bb13:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t25 = load ptr, ptr %l28, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb14, label %bb15
bb14:
  %t28 = load ptr, ptr %l28, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 2
  store i1 %t31, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t32 = load i1, ptr %l29, !tbaa !21
  br i1 %t32, label %bb16, label %bb17
bb16:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l2, !tbaa !29
  br label %bb26
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t40 = load ptr, ptr %l34, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb18, label %bb19
bb18:
  %t43 = load ptr, ptr %l34, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 3
  store i1 %t46, ptr %l35, !tbaa !21
  br label %bb19
bb19:
  %t47 = load i1, ptr %l35, !tbaa !21
  br i1 %t47, label %bb20, label %bb21
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l2, !tbaa !29
  br label %bb26
bb21:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t55 = load ptr, ptr %l40, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb22, label %bb23
bb22:
  %t58 = load ptr, ptr %l40, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 4
  store i1 %t61, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t62 = load i1, ptr %l41, !tbaa !21
  br i1 %t62, label %bb24, label %bb25
bb24:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t73, ptr %l48
  br label %bb27
bb27:
  %t74 = load i1, ptr %l48, !tbaa !21
  store i1 %t74, ptr %l19, !tbaa !21
  br label %bb170
bb28:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t76 = load ptr, ptr %l49, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb29, label %bb30
bb29:
  %t79 = load ptr, ptr %l49, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 18}
  %t82 = icmp eq i64 %t80, 5
  store i1 %t82, ptr %l50, !tbaa !21
  br label %bb30
bb30:
  %t83 = load i1, ptr %l50, !tbaa !21
  br i1 %t83, label %bb31, label %bb32
bb31:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Promote", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = load i32, ptr %l1, !tbaa !23
  %t98 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t93, i32 %t95)
  store i1 %t98, ptr %l59
  br label %bb34
bb34:
  %t99 = load i1, ptr %l59, !tbaa !21
  store i1 %t99, ptr %l19, !tbaa !21
  br label %bb170
bb35:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t101 = load ptr, ptr %l60, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb36, label %bb37
bb36:
  %t104 = load ptr, ptr %l60, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 18}
  %t107 = icmp eq i64 %t105, 6
  store i1 %t107, ptr %l61, !tbaa !21
  br label %bb37
bb37:
  %t108 = load i1, ptr %l61, !tbaa !21
  br i1 %t108, label %bb38, label %bb39
bb38:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr { i64, [5 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t111, i32 0, i32 2
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb46
bb40:
  %t115 = load ptr, ptr %l4, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Call", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i32, ptr %l1, !tbaa !23
  %t122 = call i1 @compiler_2ftyped_2ecalleeBreaks(ptr %v0, ptr %t118, i32 %t119)
  store i1 %t122, ptr %l69
  br label %bb41
bb41:
  %t123 = load i1, ptr %l69, !tbaa !21
  br i1 %t123, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb45
bb43:
  %t124 = load ptr, ptr %l4, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Call", ptr %t124, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i1 @compiler_2ftyped_2eexprsBreak(ptr %v0, { i64, ptr } %t127, i32 %t128)
  store i1 %t131, ptr %l74
  br label %bb44
bb44:
  %t132 = load i1, ptr %l74, !tbaa !21
  store i1 %t132, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  %t133 = load i1, ptr %l70, !tbaa !21
  store i1 %t133, ptr %l19, !tbaa !21
  br label %bb170
bb46:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t135 = load ptr, ptr %l75, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb47, label %bb48
bb47:
  %t138 = load ptr, ptr %l75, !tbaa !29
  %t139 = load i64, ptr %t138, !range !{i64 0, i64 18}
  %t141 = icmp eq i64 %t139, 7
  store i1 %t141, ptr %l76, !tbaa !21
  br label %bb48
bb48:
  %t142 = load i1, ptr %l76, !tbaa !21
  br i1 %t142, label %bb49, label %bb50
bb49:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t145, i32 0, i32 2
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l5, !tbaa !29
  br label %bb51
bb50:
  br label %bb57
bb51:
  %t149 = load ptr, ptr %l5, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Make", ptr %t149, i32 0, i32 2
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  %t153 = load i32, ptr %l1, !tbaa !23
  %t156 = call i1 @compiler_2ftyped_2eexprsBreak(ptr %v0, { i64, ptr } %t152, i32 %t153)
  store i1 %t156, ptr %l84
  br label %bb52
bb52:
  %t157 = load i1, ptr %l84, !tbaa !21
  br i1 %t157, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb56
bb54:
  %t158 = load ptr, ptr %l5, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Make", ptr %t158, i32 0, i32 3
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load i32, ptr %l1, !tbaa !23
  %t165 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t161, i32 %t162)
  store i1 %t165, ptr %l89
  br label %bb55
bb55:
  %t166 = load i1, ptr %l89, !tbaa !21
  store i1 %t166, ptr %l85, !tbaa !21
  br label %bb56
bb56:
  %t167 = load i1, ptr %l85, !tbaa !21
  store i1 %t167, ptr %l19, !tbaa !21
  br label %bb170
bb57:
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t169 = load ptr, ptr %l90, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb58, label %bb59
bb58:
  %t172 = load ptr, ptr %l90, !tbaa !29
  %t173 = load i64, ptr %t172, !range !{i64 0, i64 18}
  %t175 = icmp eq i64 %t173, 8
  store i1 %t175, ptr %l91, !tbaa !21
  br label %bb59
bb59:
  %t176 = load i1, ptr %l91, !tbaa !21
  br i1 %t176, label %bb60, label %bb61
bb60:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t179, i32 0, i32 2
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l6, !tbaa !29
  br label %bb62
bb61:
  br label %bb68
bb62:
  %t183 = load ptr, ptr %l6, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Collect", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t187 = load i32, ptr %l1, !tbaa !23
  %t190 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t186, i32 %t187)
  store i1 %t190, ptr %l99
  br label %bb63
bb63:
  %t191 = load i1, ptr %l99, !tbaa !21
  br i1 %t191, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb67
bb65:
  %t192 = load ptr, ptr %l6, !tbaa !29
  %t194 = getelementptr %"compiler/typed:Collect", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = load i32, ptr %l1, !tbaa !23
  %t200 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t195, i32 %t197)
  store i1 %t200, ptr %l105
  br label %bb66
bb66:
  %t201 = load i1, ptr %l105, !tbaa !21
  store i1 %t201, ptr %l100, !tbaa !21
  br label %bb67
bb67:
  %t202 = load i1, ptr %l100, !tbaa !21
  store i1 %t202, ptr %l19, !tbaa !21
  br label %bb170
bb68:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t204 = load ptr, ptr %l106, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb69, label %bb70
bb69:
  %t207 = load ptr, ptr %l106, !tbaa !29
  %t208 = load i64, ptr %t207, !range !{i64 0, i64 18}
  %t210 = icmp eq i64 %t208, 9
  store i1 %t210, ptr %l107, !tbaa !21
  br label %bb70
bb70:
  %t211 = load i1, ptr %l107, !tbaa !21
  br i1 %t211, label %bb71, label %bb72
bb71:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t214, i32 0, i32 4
  %t216 = load { i64, ptr }, ptr %t215
  store { i64, ptr } %t216, ptr %l7, !tbaa !27
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t218 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t219 = load i32, ptr %l1, !tbaa !23
  %t222 = call i1 @compiler_2ftyped_2eexprsBreak(ptr %v0, { i64, ptr } %t218, i32 %t219)
  store i1 %t222, ptr %l114
  br label %bb74
bb74:
  %t223 = load i1, ptr %l114, !tbaa !21
  store i1 %t223, ptr %l19, !tbaa !21
  br label %bb170
bb75:
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t225 = load ptr, ptr %l115, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb76, label %bb77
bb76:
  %t228 = load ptr, ptr %l115, !tbaa !29
  %t229 = load i64, ptr %t228, !range !{i64 0, i64 18}
  %t231 = icmp eq i64 %t229, 10
  store i1 %t231, ptr %l116, !tbaa !21
  br label %bb77
bb77:
  %t232 = load i1, ptr %l116, !tbaa !21
  br i1 %t232, label %bb78, label %bb79
bb78:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr { i64, [5 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t235, i32 0, i32 2
  %t237 = load ptr, ptr %t236
  store ptr %t237, ptr %l8, !tbaa !29
  br label %bb80
bb79:
  br label %bb90
bb80:
  %t239 = load ptr, ptr %l8, !tbaa !29
  %t241 = getelementptr %"compiler/typed:Slice", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t243 = load i32, ptr %l1, !tbaa !23
  %t246 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t242, i32 %t243)
  store i1 %t246, ptr %l124
  br label %bb81
bb81:
  %t247 = load i1, ptr %l124, !tbaa !21
  br i1 %t247, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb85
bb83:
  %t248 = load ptr, ptr %l8, !tbaa !29
  %t250 = getelementptr %"compiler/typed:Slice", ptr %t248, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t253 = load i32, ptr %l1, !tbaa !23
  %t256 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t251, i32 %t253)
  store i1 %t256, ptr %l130
  br label %bb84
bb84:
  %t257 = load i1, ptr %l130, !tbaa !21
  store i1 %t257, ptr %l125, !tbaa !21
  br label %bb85
bb85:
  %t258 = load i1, ptr %l125, !tbaa !21
  br i1 %t258, label %bb86, label %bb87
bb86:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb89
bb87:
  %t259 = load ptr, ptr %l8, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Slice", ptr %t259, i32 0, i32 2
  %t262 = load ptr, ptr %t261, !tbaa !29
  %t264 = load i32, ptr %l1, !tbaa !23
  %t267 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t262, i32 %t264)
  store i1 %t267, ptr %l136
  br label %bb88
bb88:
  %t268 = load i1, ptr %l136, !tbaa !21
  store i1 %t268, ptr %l131, !tbaa !21
  br label %bb89
bb89:
  %t269 = load i1, ptr %l131, !tbaa !21
  store i1 %t269, ptr %l19, !tbaa !21
  br label %bb170
bb90:
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t271 = load ptr, ptr %l137, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb91, label %bb92
bb91:
  %t274 = load ptr, ptr %l137, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 18}
  %t277 = icmp eq i64 %t275, 11
  store i1 %t277, ptr %l138, !tbaa !21
  br label %bb92
bb92:
  %t278 = load i1, ptr %l138, !tbaa !21
  br i1 %t278, label %bb93, label %bb94
bb93:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr { i64, [5 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t281, i32 0, i32 2
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l9, !tbaa !29
  br label %bb95
bb94:
  br label %bb105
bb95:
  %t285 = load ptr, ptr %l9, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Cond", ptr %t285, i32 0, i32 0
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t290 = load i32, ptr %l1, !tbaa !23
  %t293 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t288, i32 %t290)
  store i1 %t293, ptr %l147
  br label %bb96
bb96:
  %t294 = load i1, ptr %l147, !tbaa !21
  br i1 %t294, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l148, !tbaa !21
  br label %bb100
bb98:
  %t295 = load ptr, ptr %l9, !tbaa !29
  %t297 = getelementptr %"compiler/typed:Cond", ptr %t295, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t299 = load i32, ptr %l1, !tbaa !23
  %t302 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t298, i32 %t299)
  store i1 %t302, ptr %l152
  br label %bb99
bb99:
  %t303 = load i1, ptr %l152, !tbaa !21
  store i1 %t303, ptr %l148, !tbaa !21
  br label %bb100
bb100:
  %t304 = load i1, ptr %l148, !tbaa !21
  br i1 %t304, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb104
bb102:
  %t305 = load ptr, ptr %l9, !tbaa !29
  %t307 = getelementptr %"compiler/typed:Cond", ptr %t305, i32 0, i32 2
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t310 = load i32, ptr %l1, !tbaa !23
  %t313 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t308, i32 %t310)
  store i1 %t313, ptr %l158
  br label %bb103
bb103:
  %t314 = load i1, ptr %l158, !tbaa !21
  store i1 %t314, ptr %l153, !tbaa !21
  br label %bb104
bb104:
  %t315 = load i1, ptr %l153, !tbaa !21
  store i1 %t315, ptr %l19, !tbaa !21
  br label %bb170
bb105:
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l159, !tbaa !29
  store i1 false, ptr %l160, !tbaa !21
  %t317 = load ptr, ptr %l159, !tbaa !29
  %t318 = icmp ne ptr %t317, null
  br i1 %t318, label %bb106, label %bb107
bb106:
  %t320 = load ptr, ptr %l159, !tbaa !29
  %t321 = load i64, ptr %t320, !range !{i64 0, i64 18}
  %t323 = icmp eq i64 %t321, 12
  store i1 %t323, ptr %l160, !tbaa !21
  br label %bb107
bb107:
  %t324 = load i1, ptr %l160, !tbaa !21
  br i1 %t324, label %bb108, label %bb109
bb108:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr { i64, [5 x i64] }, ptr %t325, i32 0, i32 1
  %t328 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t327, i32 0, i32 2
  %t329 = load ptr, ptr %t328
  store ptr %t329, ptr %l10, !tbaa !29
  br label %bb110
bb109:
  br label %bb116
bb110:
  %t331 = load ptr, ptr %l10, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Seq", ptr %t331, i32 0, i32 0
  %t334 = load { i64, ptr }, ptr %t333, !tbaa !27
  %t335 = load i32, ptr %l1, !tbaa !23
  %t338 = call i1 @compiler_2ftyped_2estmtsBreak(ptr %v0, { i64, ptr } %t334, i32 %t335)
  store i1 %t338, ptr %l168
  br label %bb111
bb111:
  %t339 = load i1, ptr %l168, !tbaa !21
  br i1 %t339, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l169, !tbaa !21
  br label %bb115
bb113:
  %t340 = load ptr, ptr %l10, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Seq", ptr %t340, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t344 = load i32, ptr %l1, !tbaa !23
  %t347 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t343, i32 %t344)
  store i1 %t347, ptr %l173
  br label %bb114
bb114:
  %t348 = load i1, ptr %l173, !tbaa !21
  store i1 %t348, ptr %l169, !tbaa !21
  br label %bb115
bb115:
  %t349 = load i1, ptr %l169, !tbaa !21
  store i1 %t349, ptr %l19, !tbaa !21
  br label %bb170
bb116:
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l174, !tbaa !29
  store i1 false, ptr %l175, !tbaa !21
  %t351 = load ptr, ptr %l174, !tbaa !29
  %t352 = icmp ne ptr %t351, null
  br i1 %t352, label %bb117, label %bb118
bb117:
  %t354 = load ptr, ptr %l174, !tbaa !29
  %t355 = load i64, ptr %t354, !range !{i64 0, i64 18}
  %t357 = icmp eq i64 %t355, 13
  store i1 %t357, ptr %l175, !tbaa !21
  br label %bb118
bb118:
  %t358 = load i1, ptr %l175, !tbaa !21
  br i1 %t358, label %bb119, label %bb120
bb119:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr { i64, [5 x i64] }, ptr %t359, i32 0, i32 1
  %t362 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t361, i32 0, i32 2
  %t363 = load ptr, ptr %t362
  store ptr %t363, ptr %l11, !tbaa !29
  br label %bb121
bb120:
  br label %bb137
bb121:
  %t365 = load ptr, ptr %l11, !tbaa !29
  %t367 = getelementptr %"compiler/typed:Match", ptr %t365, i32 0, i32 0
  %t368 = load { i64, ptr }, ptr %t367, !tbaa !27
  %t369 = load i32, ptr %l1, !tbaa !23
  %t372 = call i1 @compiler_2ftyped_2estmtsBreak(ptr %v0, { i64, ptr } %t368, i32 %t369)
  store i1 %t372, ptr %l183
  br label %bb122
bb122:
  %t373 = load i1, ptr %l183, !tbaa !21
  br i1 %t373, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l184, !tbaa !21
  br label %bb126
bb124:
  %t374 = load ptr, ptr %l11, !tbaa !29
  %t376 = getelementptr %"compiler/typed:Match", ptr %t374, i32 0, i32 1
  %t377 = load { i64, ptr }, ptr %t376, !tbaa !27
  %t378 = load i32, ptr %l1, !tbaa !23
  %t381 = call i1 @compiler_2ftyped_2earmsBreak(ptr %v0, { i64, ptr } %t377, i32 %t378)
  store i1 %t381, ptr %l188
  br label %bb125
bb125:
  %t382 = load i1, ptr %l188, !tbaa !21
  store i1 %t382, ptr %l184, !tbaa !21
  br label %bb126
bb126:
  %t383 = load i1, ptr %l184, !tbaa !21
  br i1 %t383, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l189, !tbaa !21
  br label %bb136
bb128:
  %t384 = load ptr, ptr %l11, !tbaa !29
  %t386 = getelementptr %"compiler/typed:Match", ptr %t384, i32 0, i32 2
  %t387 = load ptr, ptr %t386, !tbaa !29
  %t389 = icmp eq ptr %t387, null
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb129, label %bb130
bb129:
  %t393 = load ptr, ptr %l11, !tbaa !29
  %t395 = getelementptr %"compiler/typed:Match", ptr %t393, i32 0, i32 2
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t398 = icmp eq ptr %t396, null
  br i1 %t398, label %bb131, label %bb132
bb130:
  store i1 false, ptr %l194, !tbaa !21
  br label %bb135
bb131:
  call void @__olang_check_failed(ptr @olang_loc_ef1bdab68bcf0283_bb587b6d5639fda7)
  unreachable
bb132:
  br label %bb133
bb133:
  %t400 = load ptr, ptr %l11, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Match", ptr %t400, i32 0, i32 2
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t404 = load i32, ptr %l1, !tbaa !23
  %t407 = call i1 @compiler_2ftyped_2earmBreaks(ptr %v0, ptr %t403, i32 %t404)
  store i1 %t407, ptr %l201
  br label %bb134
bb134:
  %t408 = load i1, ptr %l201, !tbaa !21
  store i1 %t408, ptr %l194, !tbaa !21
  br label %bb135
bb135:
  %t409 = load i1, ptr %l194, !tbaa !21
  store i1 %t409, ptr %l189, !tbaa !21
  br label %bb136
bb136:
  %t410 = load i1, ptr %l189, !tbaa !21
  store i1 %t410, ptr %l19, !tbaa !21
  br label %bb170
bb137:
  %t411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t411, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t412 = load ptr, ptr %l202, !tbaa !29
  %t413 = icmp ne ptr %t412, null
  br i1 %t413, label %bb138, label %bb139
bb138:
  %t415 = load ptr, ptr %l202, !tbaa !29
  %t416 = load i64, ptr %t415, !range !{i64 0, i64 18}
  %t418 = icmp eq i64 %t416, 14
  store i1 %t418, ptr %l203, !tbaa !21
  br label %bb139
bb139:
  %t419 = load i1, ptr %l203, !tbaa !21
  br i1 %t419, label %bb140, label %bb141
bb140:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr { i64, [5 x i64] }, ptr %t420, i32 0, i32 1
  %t423 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t422, i32 0, i32 2
  %t424 = load ptr, ptr %t423
  store ptr %t424, ptr %l12, !tbaa !29
  br label %bb142
bb141:
  br label %bb148
bb142:
  %t426 = load ptr, ptr %l12, !tbaa !29
  %t428 = getelementptr %"compiler/typed:Try", ptr %t426, i32 0, i32 0
  %t429 = load ptr, ptr %t428, !tbaa !29
  %t430 = load i32, ptr %l1, !tbaa !23
  %t433 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t429, i32 %t430)
  store i1 %t433, ptr %l211
  br label %bb143
bb143:
  %t434 = load i1, ptr %l211, !tbaa !21
  br i1 %t434, label %bb144, label %bb145
bb144:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb147
bb145:
  %t435 = load ptr, ptr %l12, !tbaa !29
  %t437 = getelementptr %"compiler/typed:Try", ptr %t435, i32 0, i32 1
  %t438 = load { i64, ptr }, ptr %t437, !tbaa !27
  %t439 = load i32, ptr %l1, !tbaa !23
  %t442 = call i1 @compiler_2ftyped_2eclausesBreak(ptr %v0, { i64, ptr } %t438, i32 %t439)
  store i1 %t442, ptr %l216
  br label %bb146
bb146:
  %t443 = load i1, ptr %l216, !tbaa !21
  store i1 %t443, ptr %l212, !tbaa !21
  br label %bb147
bb147:
  %t444 = load i1, ptr %l212, !tbaa !21
  store i1 %t444, ptr %l19, !tbaa !21
  br label %bb170
bb148:
  %t445 = load ptr, ptr %l0, !tbaa !29
  store ptr %t445, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t446 = load ptr, ptr %l217, !tbaa !29
  %t447 = icmp ne ptr %t446, null
  br i1 %t447, label %bb149, label %bb150
bb149:
  %t449 = load ptr, ptr %l217, !tbaa !29
  %t450 = load i64, ptr %t449, !range !{i64 0, i64 18}
  %t452 = icmp eq i64 %t450, 15
  store i1 %t452, ptr %l218, !tbaa !21
  br label %bb150
bb150:
  %t453 = load i1, ptr %l218, !tbaa !21
  br i1 %t453, label %bb151, label %bb152
bb151:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr { i64, [5 x i64] }, ptr %t454, i32 0, i32 1
  %t457 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t456, i32 0, i32 2
  %t458 = load ptr, ptr %t457
  store ptr %t458, ptr %l13, !tbaa !29
  br label %bb153
bb152:
  br label %bb155
bb153:
  %t460 = load ptr, ptr %l13, !tbaa !29
  %t461 = load i32, ptr %l1, !tbaa !23
  %t464 = call i1 @compiler_2ftyped_2efnBreaks(ptr %v0, ptr %t460, i32 %t461)
  store i1 %t464, ptr %l225
  br label %bb154
bb154:
  %t465 = load i1, ptr %l225, !tbaa !21
  store i1 %t465, ptr %l19, !tbaa !21
  br label %bb170
bb155:
  %t466 = load ptr, ptr %l0, !tbaa !29
  store ptr %t466, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t467 = load ptr, ptr %l226, !tbaa !29
  %t468 = icmp ne ptr %t467, null
  br i1 %t468, label %bb156, label %bb157
bb156:
  %t470 = load ptr, ptr %l226, !tbaa !29
  %t471 = load i64, ptr %t470, !range !{i64 0, i64 18}
  %t473 = icmp eq i64 %t471, 16
  store i1 %t473, ptr %l227, !tbaa !21
  br label %bb157
bb157:
  %t474 = load i1, ptr %l227, !tbaa !21
  br i1 %t474, label %bb158, label %bb159
bb158:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr { i64, [5 x i64] }, ptr %t475, i32 0, i32 1
  %t478 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t477, i32 0, i32 2
  %t479 = load ptr, ptr %t478
  store ptr %t479, ptr %l14, !tbaa !29
  br label %bb160
bb159:
  br label %bb162
bb160:
  %t481 = load ptr, ptr %l14, !tbaa !29
  %t483 = getelementptr %"compiler/typed:Text", ptr %t481, i32 0, i32 0
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  %t485 = load i32, ptr %l1, !tbaa !23
  %t488 = call i1 @compiler_2ftyped_2epiecesBreak(ptr %v0, { i64, ptr } %t484, i32 %t485)
  store i1 %t488, ptr %l235
  br label %bb161
bb161:
  %t489 = load i1, ptr %l235, !tbaa !21
  store i1 %t489, ptr %l19, !tbaa !21
  br label %bb170
bb162:
  %t490 = load ptr, ptr %l0, !tbaa !29
  store ptr %t490, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t491 = load ptr, ptr %l236, !tbaa !29
  %t492 = icmp ne ptr %t491, null
  br i1 %t492, label %bb163, label %bb164
bb163:
  %t494 = load ptr, ptr %l236, !tbaa !29
  %t495 = load i64, ptr %t494, !range !{i64 0, i64 18}
  %t497 = icmp eq i64 %t495, 17
  store i1 %t497, ptr %l237, !tbaa !21
  br label %bb164
bb164:
  %t498 = load i1, ptr %l237, !tbaa !21
  br i1 %t498, label %bb165, label %bb166
bb165:
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t501 = getelementptr { i64, [5 x i64] }, ptr %t499, i32 0, i32 1
  %t502 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t501, i32 0, i32 2
  %t503 = load ptr, ptr %t502
  store ptr %t503, ptr %l15, !tbaa !29
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t505 = load ptr, ptr %l15, !tbaa !29
  %t507 = load i32, ptr %l1, !tbaa !23
  %t510 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t505, i32 %t507)
  store i1 %t510, ptr %l245
  br label %bb168
bb168:
  %t511 = load i1, ptr %l245, !tbaa !21
  store i1 %t511, ptr %l19, !tbaa !21
  br label %bb170
bb169:
  call void @__olang_check_failed(ptr @olang_loc_b091697a8707c61b_ed3e4d18c76feebf)
  unreachable
bb170:
  %t512 = load i1, ptr %l19, !tbaa !21
  store i1 %t512, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eexprsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t28, i32 %a1)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb24
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Make", ptr %t25, i32 0, i32 0
  %t28 = load i32, ptr %t27, !range !{i32 0, i32 5}
  %t30 = trunc i64 4 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l3, !tbaa !21
  br label %bb24
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb13, label %bb14
bb13:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 17
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l19, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l25
  br label %bb18
bb18:
  %t53 = load i1, ptr %l25, !tbaa !21
  store i1 %t53, ptr %l3, !tbaa !21
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_bea5bf6ffc689610_b71acf810bfa0324)
  unreachable
bb24:
  %t54 = load i1, ptr %l3, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eholdsOwned(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca i32
  %l38 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca i1
  %l51 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i32
  %l59 = alloca i1
  %l62 = alloca ptr
  %l65 = alloca i32
  %l67 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca i32
  %l75 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l11
  br label %bb4
bb4:
  %t11 = load i32, ptr %l11, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l14
  br label %bb5
bb5:
  %t17 = load i32, ptr %l14, !range !{i32 0, i32 33}
  store i32 %t17, ptr %l4
  %t18 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t20 = trunc i64 19 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l19
  br label %bb9
bb9:
  %t28 = load i32, ptr %l19, !tbaa !23
  %t29 = icmp eq i32 %t28, 0
  br i1 %t29, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb14
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l25
  br label %bb12
bb12:
  %t37 = load i64, ptr %l2, !tbaa !24
  %t39 = add i64 %t37, 1
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = load i32, ptr %l25, !tbaa !23
  %t43 = call i1 @compiler_2ftyped_2eholdsOwned(ptr %v0, ptr %t40, i32 %t41, i64 %t39)
  store i1 %t43, ptr %l28
  br label %bb13
bb13:
  %t44 = load i1, ptr %l28, !tbaa !21
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l21, !tbaa !21
  store i1 %t45, ptr %rv
  br label %ret
bb15:
  %t46 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t48 = trunc i64 22 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  %t51 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t53 = trunc i64 23 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l3, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l36
  br label %bb21
bb21:
  %t62 = load i64, ptr %l2, !tbaa !24
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i32, ptr %l36, !tbaa !23
  %t66 = call i1 @compiler_2ftyped_2elistOwned(ptr %v0, ptr %t63, i32 %t64, i64 %t62)
  store i1 %t66, ptr %l38
  br label %bb22
bb22:
  %t67 = load i1, ptr %l38, !tbaa !21
  store i1 %t67, ptr %rv
  br label %ret
bb23:
  %t68 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t70 = trunc i64 24 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l3, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l44
  br label %bb27
bb27:
  %t79 = load i64, ptr %l2, !tbaa !24
  %t80 = load ptr, ptr %l41, !tbaa !29
  %t81 = load i32, ptr %l44, !tbaa !23
  %t83 = call i1 @compiler_2ftyped_2elistOwned(ptr %v0, ptr %t80, i32 %t81, i64 %t79)
  store i1 %t83, ptr %l46
  br label %bb28
bb28:
  %t84 = load i1, ptr %l46, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb29:
  %t85 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb56
bb32:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l51
  br label %bb33
bb33:
  %t95 = load i1, ptr %l51, !tbaa !21
  %t96 = xor i1 %t95, true
  br i1 %t96, label %bb34, label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l54, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l3, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l57
  br label %bb37
bb37:
  %t105 = load ptr, ptr %l54, !tbaa !29
  %t106 = load i32, ptr %l57, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t105, i32 %t106)
  store i32 %t107, ptr %l58
  br label %bb38
bb38:
  %t108 = load i32, ptr %l58, !range !{i32 0, i32 6}
  store i32 %t108, ptr %l5
  %t109 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t111 = trunc i64 0 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l62, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i32, ptr %l3, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l65
  br label %bb42
bb42:
  %t120 = load i64, ptr %l2, !tbaa !24
  %t121 = load ptr, ptr %l62, !tbaa !29
  %t122 = load i32, ptr %l65, !tbaa !23
  %t124 = call i1 @compiler_2ftyped_2elistOwned(ptr %v0, ptr %t121, i32 %t122, i64 %t120)
  store i1 %t124, ptr %l67
  br label %bb43
bb43:
  %t125 = load i1, ptr %l67, !tbaa !21
  store i1 %t125, ptr %l59, !tbaa !21
  br label %bb55
bb44:
  %t126 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t128 = trunc i64 1 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l70, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l3, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l73
  br label %bb48
bb48:
  %t137 = load i64, ptr %l2, !tbaa !24
  %t138 = load ptr, ptr %l70, !tbaa !29
  %t139 = load i32, ptr %l73, !tbaa !23
  %t141 = call i1 @compiler_2ftyped_2elistOwned(ptr %v0, ptr %t138, i32 %t139, i64 %t137)
  store i1 %t141, ptr %l75
  br label %bb49
bb49:
  %t142 = load i1, ptr %l75, !tbaa !21
  store i1 %t142, ptr %l59, !tbaa !21
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_61141ab026762302_86235c78c2d902d6)
  unreachable
bb55:
  %t143 = load i1, ptr %l59, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store i1 false, ptr %rv
  br label %ret
bb60:
  call void @__olang_check_failed(ptr @olang_loc_2566079f8423d483_66fa93375f6766f7)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca i32
  %l26 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i64
  %l47 = alloca { i64, ptr }
  %l49 = alloca i1
  %l55 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 6
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l9
  br label %bb4
bb4:
  %t11 = load i32, ptr %l9, !range !{i32 0, i32 33}
  store i32 %t11, ptr %l3
  %t12 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb14
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l15
  br label %bb8
bb8:
  %t22 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t23 = load i64, ptr %l15, !tbaa !24
  %t25 = and i64 %t23, %t22
  %t27 = icmp ne i64 %t25, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb13
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l23
  br label %bb11
bb11:
  %t35 = load i64, ptr %l2, !tbaa !24
  %t37 = add i64 %t35, 1
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = load i32, ptr %l23, !tbaa !23
  %t41 = call i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %t38, i32 %t39, i64 %t37)
  store i1 %t41, ptr %l26
  br label %bb12
bb12:
  %t42 = load i1, ptr %l26, !tbaa !21
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l19, !tbaa !21
  store i1 %t43, ptr %l10, !tbaa !21
  br label %bb49
bb14:
  %t44 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t46 = trunc i64 19 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l29, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l32
  br label %bb18
bb18:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = add i64 %t55, 1
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = load i32, ptr %l32, !tbaa !23
  %t61 = call i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %t58, i32 %t59, i64 %t57)
  store i1 %t61, ptr %l35
  br label %bb19
bb19:
  %t62 = load i1, ptr %l35, !tbaa !21
  store i1 %t62, ptr %l10, !tbaa !21
  br label %bb49
bb20:
  %t63 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t65 = trunc i64 22 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  %t68 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t70 = trunc i64 23 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l40, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l41, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l44
  br label %bb26
bb26:
  %t80 = load i64, ptr %l44, !tbaa !24
  %t81 = trunc i64 %t80 to i32
  %t83 = load ptr, ptr %l41, !tbaa !29
  %t85 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t83, i32 %t81)
  store { i64, ptr } %t85, ptr %l47
  br label %bb27
bb27:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load ptr, ptr %l40, !tbaa !29
  %t88 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t90 = call i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v0, ptr %t87, { i64, ptr } %t88, i64 %t86)
  store i1 %t90, ptr %l49
  br label %bb28
bb28:
  %t91 = load i1, ptr %l49, !tbaa !21
  store i1 %t91, ptr %l10, !tbaa !21
  br label %bb49
bb29:
  %t92 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t94 = trunc i64 18 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l1, !tbaa !23
  %t99 = load i64, ptr %l2, !tbaa !24
  %t103 = call i1 @compiler_2ftyped_2enamedHoldsWritable(ptr %v0, ptr %t97, i32 %t98, i64 %t99)
  store i1 %t103, ptr %l55
  br label %bb33
bb33:
  %t104 = load i1, ptr %l55, !tbaa !21
  store i1 %t104, ptr %l10, !tbaa !21
  br label %bb49
bb34:
  %t105 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t107 = trunc i64 21 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  %t110 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t112 = trunc i64 29 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb37, label %bb38
bb37:
  br label %bb43
bb38:
  %t115 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t117 = trunc i64 25 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb39, label %bb40
bb39:
  br label %bb43
bb40:
  %t120 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t122 = trunc i64 24 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_897c6ec4bdb8e7c2_3b49e2eddb87c67e)
  unreachable
bb49:
  %t125 = load i1, ptr %l10, !tbaa !21
  store i1 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eisAssertAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 10
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  %t22 = icmp eq i32 %t17, %t19
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  %t26 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = icmp eq i32 %t25, %t27
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l13, !tbaa !21
  store i1 %t32, ptr %l3, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4d8d49a96eb287ee_1dbcd98d7cba02aa)
  unreachable
bb14:
  %t33 = load i1, ptr %l3, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2elistOwned(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l29 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %t7)
  store { i64, ptr } %t10, ptr %l12
  br label %bb4
bb4:
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb17
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l6, !tbaa !23
  %t32 = load i32, ptr %l6, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = add i64 %a2, 1
  %t44 = call i1 @compiler_2ftyped_2eholdsOwned(ptr %v0, ptr %t36, i32 %t37, i64 %t40)
  store i1 %t44, ptr %l29
  br label %bb11
bb10:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb12
bb11:
  %t45 = load i1, ptr %l29, !tbaa !21
  store i1 %t45, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l24, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l4, !tbaa !24
  br label %bb5
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2enamedHoldsWritable(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load i32, ptr %l7, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !range !{i32 0, i32 6}
  store i32 %t10, ptr %l3
  %t11 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t13 = trunc i64 2 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t18 = trunc i64 5 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t25 = trunc i64 3 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb12
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l20
  br label %bb11
bb11:
  %t33 = load i1, ptr %l20, !tbaa !21
  %t34 = xor i1 %t33, true
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t38 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t40 = trunc i64 4 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l28
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = add i64 %t49, 1
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load i32, ptr %l28, !tbaa !23
  %t55 = call i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %t52, i32 %t53, i64 %t51)
  store i1 %t55, ptr %l31
  br label %bb19
bb19:
  %t56 = load i1, ptr %l31, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
bb20:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l1, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l36
  br label %bb21
bb21:
  %t64 = load ptr, ptr %l33, !tbaa !29
  %t65 = load i32, ptr %l36, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t64, i32 %t65)
  store { i64, ptr } %t66, ptr %l37
  br label %bb22
bb22:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load ptr, ptr %l32, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t71 = call i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v0, ptr %t68, { i64, ptr } %t69, i64 %t67)
  store i1 %t71, ptr %l39
  br label %bb23
bb23:
  %t72 = load i1, ptr %l39, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb29
bb25:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l42, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l45
  br label %bb26
bb26:
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = load i32, ptr %l45, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t80, i32 %t81)
  store { i64, ptr } %t82, ptr %l46
  br label %bb27
bb27:
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load ptr, ptr %l41, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t87 = call i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v0, ptr %t84, { i64, ptr } %t85, i64 %t83)
  store i1 %t87, ptr %l48
  br label %bb28
bb28:
  %t88 = load i1, ptr %l48, !tbaa !21
  store i1 %t88, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t89 = load i1, ptr %l40, !tbaa !21
  br i1 %t89, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb35
bb31:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l50, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l51, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l1, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l54
  br label %bb32
bb32:
  %t97 = load ptr, ptr %l51, !tbaa !29
  %t98 = load i32, ptr %l54, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t97, i32 %t98)
  store { i64, ptr } %t99, ptr %l55
  br label %bb33
bb33:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load ptr, ptr %l50, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t104 = call i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v0, ptr %t101, { i64, ptr } %t102, i64 %t100)
  store i1 %t104, ptr %l57
  br label %bb34
bb34:
  %t105 = load i1, ptr %l57, !tbaa !21
  store i1 %t105, ptr %l49, !tbaa !21
  br label %bb35
bb35:
  %t106 = load i1, ptr %l49, !tbaa !21
  store i1 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2eorInto(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l34, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  store i64 %t52, ptr %l35, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l36, !tbaa !27
  %t54 = load i64, ptr %l7, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i1, ptr %t57, i64 %t54
  %t59 = load i1, ptr %t58, !tbaa !31
  br i1 %t59, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb13
bb12:
  store { i64, ptr } %a1, ptr %l40, !tbaa !27
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i1, ptr %t65, i64 %t62
  %t67 = load i1, ptr %t66, !tbaa !31
  store i1 %t67, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t69 = load i1, ptr %l39, !tbaa !21
  %t70 = load i64, ptr %l35, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i1, ptr %t72, i64 %t70
  store i1 %t69, ptr %t73, !tbaa !31
  br label %bb14
bb14:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb7
bb15:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb54
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t43, i32 %t45)
  store i1 %t48, ptr %l29
  br label %bb20
bb20:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l7, !tbaa !21
  br label %bb54
bb21:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb22, label %bb23
bb22:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l38
  br label %bb27
bb27:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l7, !tbaa !21
  br label %bb54
bb28:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb29, label %bb30
bb29:
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 8}
  %t78 = icmp eq i64 %t76, 4
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb30
bb30:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb31, label %bb32
bb31:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Elem", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  %t93 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t89, i32 %t90)
  store i1 %t93, ptr %l48
  br label %bb34
bb34:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb38
bb36:
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Elem", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = load i32, ptr %l1, !tbaa !23
  %t103 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t98, i32 %t100)
  store i1 %t103, ptr %l54
  br label %bb37
bb37:
  %t104 = load i1, ptr %l54, !tbaa !21
  store i1 %t104, ptr %l49, !tbaa !21
  br label %bb38
bb38:
  %t105 = load i1, ptr %l49, !tbaa !21
  store i1 %t105, ptr %l7, !tbaa !21
  br label %bb54
bb39:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t107 = load ptr, ptr %l55, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb40, label %bb41
bb40:
  %t110 = load ptr, ptr %l55, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 8}
  %t113 = icmp eq i64 %t111, 5
  store i1 %t113, ptr %l56, !tbaa !21
  br label %bb41
bb41:
  %t114 = load i1, ptr %l56, !tbaa !21
  br i1 %t114, label %bb42, label %bb43
bb42:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Payload", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = load i32, ptr %l1, !tbaa !23
  %t128 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t124, i32 %t125)
  store i1 %t128, ptr %l64
  br label %bb45
bb45:
  %t129 = load i1, ptr %l64, !tbaa !21
  store i1 %t129, ptr %l7, !tbaa !21
  br label %bb54
bb46:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb47, label %bb48
bb47:
  %t134 = load ptr, ptr %l65, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 6
  store i1 %t137, ptr %l66, !tbaa !21
  br label %bb48
bb48:
  %t138 = load i1, ptr %l66, !tbaa !21
  br i1 %t138, label %bb49, label %bb50
bb49:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l6, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t145 = load ptr, ptr %l6, !tbaa !29
  %t147 = load i32, ptr %l1, !tbaa !23
  %t150 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t145, i32 %t147)
  store i1 %t150, ptr %l74
  br label %bb52
bb52:
  %t151 = load i1, ptr %l74, !tbaa !21
  store i1 %t151, ptr %l7, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_f3346b4d6d82824c_aeee08707a274ea0)
  unreachable
bb54:
  %t152 = load i1, ptr %l7, !tbaa !21
  store i1 %t152, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2eresultScope(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l43 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t75 = alloca { i64, [1 x i64] }, align 8
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i64, ptr %t55, i64 %t52
  %t57 = load i64, ptr %t56, !tbaa !34
  %t58 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t61 = icmp eq i64 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t69 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %t65)
  store { i64, [1 x i64] } %t69, ptr %l43
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t70 = load { i64, [1 x i64] }, ptr %l43
  store { i64, [1 x i64] } %t70, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb7
bb16:
  store { i64, [1 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [1 x i64] }, ptr %t75, i32 0, i32 0
  store i64 0, ptr %t76
  %t77 = load { i64, [1 x i64] }, ptr %t75
  store { i64, [1 x i64] } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i1 @compiler_2ftyped_2etargetsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb16
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t40 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t36, i32 %a1)
  store i1 %t40, ptr %l26
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb11
bb10:
  %t41 = load i1, ptr %l26, !tbaa !21
  store i1 %t41, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l3, !tbaa !24
  br label %bb4
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ftyped_2ewithin(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb23
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 17}
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t30, i32 0, i32 1
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %l4, !tbaa !29
  br label %bb23
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 17}
  %t44 = icmp eq i64 %t42, 13
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr }, ptr %t48, i32 0, i32 1
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Join", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l4, !tbaa !29
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_88f338444ee928b2_cde52f1382e8437e)
  unreachable
bb23:
  %t58 = load ptr, ptr %l4, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Arm"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Arm" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/typed:Arm" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Arm" %t14, ptr %a2, 2
  %t18 = insertvalue %"compiler/typed:Arm" %t16, ptr %a3, 3
  %t20 = insertvalue %"compiler/typed:Arm" %t18, ptr %a4, 4
  store %"compiler/typed:Arm" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Arm", ptr %rv
  ret %"compiler/typed:Arm" %rr
}

define dso_local void @compiler_2ftyped_3aBody_2ector(ptr %out, ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i1
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"compiler/typed:Body"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l5, !tbaa !23
  store { i64, [2 x i64] } %a1, ptr %l6
  store i32 %a2, ptr %l7, !tbaa !23
  store i64 %a3, ptr %l8, !tbaa !24
  store %"compiler/source:Span" %a4, ptr %l9
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l30
  br label %bb1
bb1:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l10
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l31
  br label %bb2
bb2:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l11
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l32
  br label %bb3
bb3:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l33
  br label %bb4
bb4:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l13
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l34
  br label %bb5
bb5:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l14
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l35
  br label %bb6
bb6:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l15
  store ptr null, ptr %l16, !tbaa !29
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l36
  br label %bb7
bb7:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l17
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l37
  br label %bb8
bb8:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l18
  store i1 false, ptr %l19, !tbaa !21
  store i32 -1, ptr %l20, !tbaa !23
  store i1 false, ptr %l21, !tbaa !21
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l38
  br label %bb9
bb9:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l22
  store i1 false, ptr %l23, !tbaa !21
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l39
  br label %bb10
bb10:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  %t31 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 0
  %t32 = load i32, ptr %l5, !tbaa !23
  store i32 %t32, ptr %t31, !tbaa !23
  %t33 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 1
  %t34 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t34, ptr %t33
  %t35 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 2
  %t36 = load i32, ptr %l7, !tbaa !23
  store i32 %t36, ptr %t35, !tbaa !23
  %t37 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 3
  %t38 = load i64, ptr %l8, !tbaa !24
  store i64 %t38, ptr %t37, !tbaa !24
  %t39 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 4
  %t40 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t40, ptr %t39
  %t41 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 5
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %t41
  %t43 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 6
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %t43
  %t45 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 7
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %t45
  %t47 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 8
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %t47
  %t49 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 9
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t49
  %t51 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 10
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %t51
  %t53 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 11
  %t54 = load ptr, ptr %l16, !tbaa !29
  store ptr %t54, ptr %t53, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 12
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %t55
  %t57 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 13
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %t57
  %t59 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 14
  %t60 = load i1, ptr %l19, !tbaa !21
  store i1 %t60, ptr %t59, !tbaa !21
  %t61 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 15
  %t62 = load i32, ptr %l20, !tbaa !23
  store i32 %t62, ptr %t61, !tbaa !23
  %t63 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 16
  %t64 = load i1, ptr %l21, !tbaa !21
  store i1 %t64, ptr %t63, !tbaa !21
  %t65 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 17
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %t65
  %t67 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 18
  %t68 = load i1, ptr %l23, !tbaa !21
  store i1 %t68, ptr %t67, !tbaa !21
  %t69 = getelementptr %"compiler/typed:Body", ptr %l40, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t69
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l40, i64 408, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Call"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Call" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/typed:Call" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Call" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/typed:Call" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/typed:Call" %t18, i1 %a4, 4
  store %"compiler/typed:Call" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Call", ptr %rv
  ret %"compiler/typed:Call" %rr
}

define dso_local %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Capture"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Capture" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Capture" %t6, ptr %a1, 1
  store %"compiler/typed:Capture" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Capture", ptr %rv
  ret %"compiler/typed:Capture" %rr
}

define dso_local %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i32 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Collect"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Collect" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/typed:Collect" %t12, ptr %a1, 1
  %t16 = insertvalue %"compiler/typed:Collect" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/typed:Collect" %t16, i32 %a3, 3
  %t20 = insertvalue %"compiler/typed:Collect" %t18, i1 %a4, 4
  store %"compiler/typed:Collect" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Collect", ptr %rv
  ret %"compiler/typed:Collect" %rr
}

define dso_local %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Cond"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Cond" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Cond" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Cond" %t10, ptr %a2, 2
  store %"compiler/typed:Cond" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Cond", ptr %rv
  ret %"compiler/typed:Cond" %rr
}

define dso_local %"compiler/typed:ContractInfo" @compiler_2ftyped_3aContractInfo_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/typed:ContractInfo"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 %a1, ptr %l3, !tbaa !24
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l4
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l10
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l11
  br label %bb3
bb3:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = insertvalue %"compiler/typed:ContractInfo" undef, { i64, ptr } %t11, 0
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = insertvalue %"compiler/typed:ContractInfo" %t12, i64 %t13, 1
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t16 = insertvalue %"compiler/typed:ContractInfo" %t14, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, 2
  %t17 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t18 = insertvalue %"compiler/typed:ContractInfo" %t16, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, 3
  %t20 = insertvalue %"compiler/typed:ContractInfo" %t18, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, 4
  store %"compiler/typed:ContractInfo" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:ContractInfo", ptr %rv
  ret %"compiler/typed:ContractInfo" %rr
}

define dso_local %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Join"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Join" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Join" %t8, i1 %a1, 1
  %t12 = insertvalue %"compiler/typed:Join" %t10, { i64, ptr } %a2, 2
  store %"compiler/typed:Join" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Join", ptr %rv
  ret %"compiler/typed:Join" %rr
}

define dso_local void @compiler_2ftyped_3aLandings_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i64
  %l44 = alloca i64
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l49 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca %"compiler/typed:Landings"
  %t33 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l4, !tbaa !27
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store { i64, ptr } %a2, ptr %l6, !tbaa !27
  store { i64, ptr } %a3, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l31, !tbaa !24
  %t12 = load i64, ptr %l31, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l31, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l8, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l35, !tbaa !24
  %t24 = load i64, ptr %l35, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6cac4c556ee1b7d9_257131421adb63ad)
  unreachable
bb3:
  %t27 = load i64, ptr %l35, !tbaa !24
  %t28 = icmp sle i64 %t27, 1152921504606846975
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_52c63b14e30804cc_be8191a117211c80)
  unreachable
bb5:
  %t30 = load i64, ptr %l35, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t31)
  store i64 0, ptr %t33
  br label %fill.34
fill.34:
  %t37 = load i64, ptr %t33
  %t38 = icmp slt i64 %t37, %t30
  br i1 %t38, label %fillb.35, label %filld.36
fillb.35:
  %t39 = getelementptr i64, ptr %t32, i64 %t37
  store i64 -1, ptr %t39
  %t40 = add i64 %t37, 1
  store i64 %t40, ptr %t33
  br label %fill.34
filld.36:
  %t41 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t32, 1
  store { i64, ptr } %t42, ptr %l9, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l40, !tbaa !24
  %t47 = load i64, ptr %l40, !tbaa !24
  %t48 = icmp sge i64 %t47, 0
  br i1 %t48, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_52c63b14e30804cc_be8191a117211c80)
  unreachable
bb7:
  %t50 = load i64, ptr %l40, !tbaa !24
  %t51 = mul i64 %t50, 1
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l10, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l44, !tbaa !24
  %t59 = load i64, ptr %l44, !tbaa !24
  %t60 = icmp sge i64 %t59, 0
  br i1 %t60, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_75ea3af438a3ca2f_999b6c305f7ce623)
  unreachable
bb9:
  %t62 = load i64, ptr %l44, !tbaa !24
  %t63 = mul i64 %t62, 1
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l11, !tbaa !27
  store i1 false, ptr %l12, !tbaa !21
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l47
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5a80d8a416bdb25a_ede72ef348da89ae)
  unreachable
bb11:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  %t70 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v4)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t70, ptr %l48
  br label %bb12
bb12:
  %t71 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l48
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t71, ptr %l15
  %t72 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v4)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t72, ptr %l49
  br label %bb13
bb13:
  %t73 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l49
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t73, ptr %l16
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l50
  br label %bb14
bb14:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l17
  %t76 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l51
  br label %bb15
bb15:
  %t77 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l18
  %t78 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l52
  br label %bb16
bb16:
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l19
  %t80 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %l53
  br label %bb17
bb17:
  %t81 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l20
  %t82 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l54
  br label %bb18
bb18:
  %t83 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t83, ptr %l21
  store i64 0, ptr %l22, !tbaa !24
  %t84 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l55
  br label %bb19
bb19:
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %l23
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l56
  br label %bb20
bb20:
  %t87 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  %t88 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t89, ptr %t88, !tbaa !27
  %t90 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 1
  %t91 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t91, ptr %t90, !tbaa !27
  %t92 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 2
  %t93 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t93, ptr %t92, !tbaa !27
  %t94 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 3
  %t95 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t95, ptr %t94, !tbaa !27
  %t96 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 4
  %t97 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t97, ptr %t96, !tbaa !27
  %t98 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 5
  %t99 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t99, ptr %t98, !tbaa !27
  %t100 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 6
  %t101 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t101, ptr %t100, !tbaa !27
  %t102 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 7
  %t103 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t103, ptr %t102, !tbaa !27
  %t104 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 8
  %t105 = load i1, ptr %l12, !tbaa !21
  store i1 %t105, ptr %t104, !tbaa !21
  %t106 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 9
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %t106
  %t108 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 10
  %t109 = load i64, ptr %l14, !tbaa !24
  store i64 %t109, ptr %t108, !tbaa !24
  %t110 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 11
  %t111 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t111, ptr %t110
  %t112 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 12
  %t113 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t113, ptr %t112
  %t114 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 13
  %t115 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %t114
  %t116 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 14
  %t117 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %t116
  %t118 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 15
  %t119 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %t118
  %t120 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 16
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %t120
  %t122 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 17
  %t123 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t123, ptr %t122
  %t124 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 18
  %t125 = load i64, ptr %l22, !tbaa !24
  store i64 %t125, ptr %t124, !tbaa !24
  %t126 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 19
  %t127 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %t126
  %t128 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %t128
  %t130 = getelementptr %"compiler/typed:Landings", ptr %l57, i32 0, i32 21
  store i64 -1, ptr %t130, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l57, i64 560, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_3aLastUses_2ector(ptr %out, ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l16 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"compiler/typed:LastUses"
  %t13 = alloca i64
  %t34 = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l0, !tbaa !24
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sle i64 %t7, 1152921504606846975
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_f4630321a8cc4bc9_818e9b0c99e677c5)
  unreachable
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 8
  %t12 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t11)
  store i64 0, ptr %t13
  br label %fill.14
fill.14:
  %t17 = load i64, ptr %t13
  %t18 = icmp slt i64 %t17, %t10
  br i1 %t18, label %fillb.15, label %filld.16
fillb.15:
  %t19 = getelementptr i64, ptr %t12, i64 %t17
  store i64 -1, ptr %t19
  %t20 = add i64 %t17, 1
  store i64 %t20, ptr %t13
  br label %fill.14
filld.16:
  %t21 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t12, 1
  store { i64, ptr } %t22, ptr %l2, !tbaa !27
  %t24 = load i64, ptr %l0, !tbaa !24
  store i64 %t24, ptr %l16, !tbaa !24
  %t25 = load i64, ptr %l16, !tbaa !24
  %t26 = icmp sge i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f4630321a8cc4bc9_818e9b0c99e677c5)
  unreachable
bb5:
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = icmp sle i64 %t28, 1152921504606846975
  br i1 %t29, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_ed49a40517443f7c_ed7a500f174a658)
  unreachable
bb7:
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = mul i64 %t31, 8
  %t33 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t32)
  store i64 0, ptr %t34
  br label %fill.35
fill.35:
  %t38 = load i64, ptr %t34
  %t39 = icmp slt i64 %t38, %t31
  br i1 %t39, label %fillb.36, label %filld.37
fillb.36:
  %t40 = getelementptr i64, ptr %t33, i64 %t38
  store i64 -1, ptr %t40
  %t41 = add i64 %t38, 1
  store i64 %t41, ptr %t34
  br label %fill.35
filld.37:
  %t42 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t33, 1
  store { i64, ptr } %t43, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l20
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ed49a40517443f7c_ed7a500f174a658)
  unreachable
bb9:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l7
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l21
  br label %bb10
bb10:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l8
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l22
  br label %bb11
bb11:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l9
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l23
  br label %bb12
bb12:
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t53 = getelementptr %"compiler/typed:LastUses", ptr %l24, i32 0, i32 0
  %t54 = load i64, ptr %l1, !tbaa !24
  store i64 %t54, ptr %t53, !tbaa !24
  %t55 = getelementptr %"compiler/typed:LastUses", ptr %l24, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %t55, !tbaa !27
  %t57 = getelementptr %"compiler/typed:LastUses", ptr %l24, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t58, ptr %t57, !tbaa !27
  %t59 = getelementptr %"compiler/typed:LastUses", ptr %l24, i32 0, i32 3
  %t60 = load i64, ptr %l4, !tbaa !24
  store i64 %t60, ptr %t59, !tbaa !24
  %t61 = getelementptr %"compiler/typed:LastUses", ptr %l24, i32 0, i32 4
  %t62 = load i64, ptr %l5, !tbaa !24
  store i64 %t62, ptr %t61, !tbaa !24
  %t63 = getelementptr %"compiler/typed:LastUses", ptr %l24, i32 0, i32 5
  %t64 = load i64, ptr %l6, !tbaa !24
  store i64 %t64, ptr %t63, !tbaa !24
  %t65 = getelementptr %"compiler/typed:LastUses", ptr %l24, i32 0, i32 6
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %t65
  %t67 = getelementptr %"compiler/typed:LastUses", ptr %l24, i32 0, i32 7
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %t67
  %t69 = getelementptr %"compiler/typed:LastUses", ptr %l24, i32 0, i32 8
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t69
  %t71 = getelementptr %"compiler/typed:LastUses", ptr %l24, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %t71
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l24, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6) #0 {
entry:
  %rv = alloca %"compiler/typed:Make"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/typed:Make" undef, i32 %a0, 0
  %t18 = insertvalue %"compiler/typed:Make" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/typed:Make" %t18, { i64, ptr } %a2, 2
  %t22 = insertvalue %"compiler/typed:Make" %t20, ptr %a3, 3
  %t24 = insertvalue %"compiler/typed:Make" %t22, i32 %a4, 4
  %t26 = insertvalue %"compiler/typed:Make" %t24, i32 %a5, 5
  %t28 = insertvalue %"compiler/typed:Make" %t26, i1 %a6, 6
  store %"compiler/typed:Make" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Make", ptr %rv
  ret %"compiler/typed:Make" %rr
}

define dso_local %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Payload"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Payload" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Payload" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/typed:Payload" %t10, i32 %a2, 2
  store %"compiler/typed:Payload" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Payload", ptr %rv
  ret %"compiler/typed:Payload" %rr
}

define dso_local %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Promote"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Promote" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/typed:Promote" %t6, i32 %a1, 1
  store %"compiler/typed:Promote" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Promote", ptr %rv
  ret %"compiler/typed:Promote" %rr
}

define dso_local %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Slice"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Slice" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/typed:Slice" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/typed:Slice" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/typed:Slice" %t14, i32 %a3, 3
  store %"compiler/typed:Slice" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Slice", ptr %rv
  ret %"compiler/typed:Slice" %rr
}

define dso_local %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:TaskClause"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:TaskClause" undef, %"compiler/source:Span" %a0, 0
  %t12 = insertvalue %"compiler/typed:TaskClause" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/typed:TaskClause" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/typed:TaskClause" %t14, ptr %a3, 3
  store %"compiler/typed:TaskClause" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:TaskClause", ptr %rv
  ret %"compiler/typed:TaskClause" %rr
}

define dso_local %"compiler/typed:ViewWalk" @compiler_2ftyped_3aViewWalk_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2, ptr %a3c, ptr %a3e, ptr %a4c, ptr %a4e) #0 {
entry:
  %rv = alloca %"compiler/typed:ViewWalk"
  %pf3 = insertvalue { ptr, ptr } undef, ptr %a3c, 0
  %pg3 = insertvalue { ptr, ptr } %pf3, ptr %a3e, 1
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:ViewWalk" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/typed:ViewWalk" %t12, ptr %a1, 1
  %t16 = insertvalue %"compiler/typed:ViewWalk" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/typed:ViewWalk" %t16, { ptr, ptr } %pg3, 3
  %t20 = insertvalue %"compiler/typed:ViewWalk" %t18, { ptr, ptr } %pg4, 4
  store %"compiler/typed:ViewWalk" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:ViewWalk", ptr %rv
  ret %"compiler/typed:ViewWalk" %rr
}

define dso_local void @compiler_2ftyped_3adropWalk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l29 = alloca %"compiler/typed:dropWalk"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l18
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l19
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l6
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l20
  br label %bb4
bb4:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l7
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l21
  br label %bb5
bb5:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l8
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l22
  br label %bb6
bb6:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l9
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l23
  br label %bb7
bb7:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l10
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l24
  br label %bb8
bb8:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l11
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l25
  br label %bb9
bb9:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l12
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l26
  br label %bb10
bb10:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l13
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l27
  br label %bb11
bb11:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l14
  %t25 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %l28
  br label %bb12
bb12:
  %t26 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28
  %t27 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 0
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %t27, !tbaa !29
  %t29 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 1
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %t29
  %t31 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 2
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %t31
  %t33 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 3
  %t34 = load i1, ptr %l4, !tbaa !21
  store i1 %t34, ptr %t33, !tbaa !21
  %t35 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 4
  %t36 = load i64, ptr %l5, !tbaa !24
  store i64 %t36, ptr %t35, !tbaa !24
  %t37 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 5
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %t37
  %t39 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 6
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t39
  %t41 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 7
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %t41
  %t43 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 8
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %t43
  %t45 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 9
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %t45
  %t47 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 10
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %t47
  %t49 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 11
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t49
  %t51 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 12
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %t51
  %t53 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 13
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %t53
  %t55 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 14
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t26, ptr %t55
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l29, i64 488, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:landState" @compiler_2ftyped_3alandState_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:landState"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:landState" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:landState" %t6, i1 %a1, 1
  store %"compiler/typed:landState" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:landState", ptr %rv
  ret %"compiler/typed:landState" %rr
}

define dso_local %"compiler/typed:leaveWalk" @compiler_2ftyped_3aleaveWalk_2ector(ptr %v0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/typed:leaveWalk"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  %t4 = insertvalue %"compiler/typed:leaveWalk" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, 0
  store %"compiler/typed:leaveWalk" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:leaveWalk", ptr %rv
  ret %"compiler/typed:leaveWalk" %rr
}

define dso_local %"compiler/typed:printer" @compiler_2ftyped_3aprinter_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"compiler/typed:printer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v1)
  store %"std/prelude/text:StringBuilder" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"std/prelude/text:StringBuilder", ptr %l4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = insertvalue %"compiler/typed:printer" undef, ptr %t5, 0
  %t8 = insertvalue %"compiler/typed:printer" %t6, %"std/prelude/text:StringBuilder" %t4, 1
  store %"compiler/typed:printer" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:printer", ptr %rv
  ret %"compiler/typed:printer" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"B" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aHelper(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 2}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d3 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"dispatch " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"#" }>, align 8
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d6 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"let L" }>, align 8
@.d7 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d8 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assign " }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"eval " }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"if " }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"else" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"loop" }>, align 8
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"post" }>, align 8
@.d15 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"break" }>, align 8
@.d16 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"continue" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" {" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"raise " }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d23 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"reraise " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aExitKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 2}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
ret:
  ret void
}

@.d24 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"exit " }>, align 8
@.d25 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assert " }>, align 8
@.d26 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"defer" }>, align 8
@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" try" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"join" }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"spawn " }>, align 8
@.d31 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"yield " }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"suspend " }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d34 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"Helper.Equal" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d35 = private unnamed_addr constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Helper.Hash" }>, align 8
@.d36 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.Unreachable" }>, align 8
@.d37 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"ExitKind.NullReached" }>, align 8
declare i64 @compiler_2ftyped_2ereached(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9640b30413567955_c65a1e6fb20cf981 = external constant [0 x i8]
@olang_loc_c8cee6ec101913bd_743c2b1d0ab2dad9 = external constant [0 x i8]
@olang_loc_d77318aa483254f8_85fb99de392fdbc = external constant [0 x i8]
@olang_loc_831440fdfc819328_dabfa81c01cf773c = external constant [0 x i8]
@olang_loc_7bdf3cb2fb8351f9_389183759a182ed = external constant [0 x i8]
declare ptr @compiler_2ftyped_2ecopied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
@olang_loc_bcb9fe3b91f750d3_ca64047ead3323e7 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
@olang_loc_160fc62cca54a9e9_1017e7cee7f3c75d = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_3aPlan_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %v0, i32 %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ePush_H85e1838377aa8e6b322d82e3edbac596(ptr %v0, ptr %a0, %"compiler/typed:BlockInfo" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2ePush_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ePush_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %a0, %"compiler/typed:SiteInfo" %a1)
@olang_loc_3a838910fbaaf0b4_28daeb84482f7128 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eClosingVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_49a7b0a2550beed6_c54fa6caa81e807a = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ereadIn(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eLen_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:landLoop" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eAt_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2eSetAt_H5ab2aabe0ae7951e8bb06fbe4ca7219a(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/typed:landLoop" %a2)
declare %"compiler/typed:landLoop" @compiler_2ftyped_3alandLoop_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2ePush_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/typed:landLoop" %a1)
declare { i32, %"compiler/typed:landLoop" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2ePop_3ccompiler_2ftyped_3alandLoop_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_17d1ac1d0088a46d_f6898a8fba654071 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_53c662fb23aaf808_98195192fab83824 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eguardedAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2elaterBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c0d697227f379d2a_2050d061979ad5e = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ewholeLocal(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2elaterBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b7d0c4ef23cb16fa_bb49bf88955879a6 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftyped_2escalarType(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eprim(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, [1 x i64] } %a3)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2)
@olang_loc_378ad1b24c170823_353e69e2764e6faf = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, { i64, [1 x i64] } %a2)
@olang_loc_ff24328511a0943b_1b00d38544175a97 = external constant [0 x i8]
@olang_loc_ea76fa4e8d5c92b6_ce360b1ee865cf5a = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b3e084de49f7dfe2_9d51886cee01545e = external constant [0 x i8]
@olang_loc_c889b00966965144_dcfe1455a200f620 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eSet_H54ebfdc15a9c097858a2e264494e7d5a(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f1d97b93b21930ce_df2dd3f10bda1132 = external constant [0 x i8]
@olang_loc_572ff0c594eb7d28_3eb561bfca5d9eb4 = external constant [0 x i8]
@olang_loc_93af16bb2b9103f6_23d1e52eae2906e2 = external constant [0 x i8]
@olang_loc_6333e3fa20d2f5d8_bcafed7a04540454 = external constant [0 x i8]
@olang_loc_43639d7480e3f1b2_6970610da298d01e = external constant [0 x i8]
@olang_loc_13022d0d55ff9b33_d1cf61a4f0453a9f = external constant [0 x i8]
@olang_loc_4f6de7c744c3571c_6f8dca6bf99a5cd8 = external constant [0 x i8]
@olang_loc_2bdab9da3f4d_ded05e4518f32fa9 = external constant [0 x i8]
@olang_loc_4086334666941342_2cd2470309ce51f6 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@olang_loc_d42dce2e5a8639a6_22ec82fe09d5fbba = external constant [0 x i8]
@olang_loc_996d81e577c7faae_f3b4a025cf703a = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2emeetRoots(i64 %a0, i64 %a1)
@olang_loc_dd6dc40ab752fedf_c333d42519625383 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_38f82f633fcbfe78_2a415e18f8868a4c = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_859ef9a416eafd63_e1a98b601ef27d27 = external constant [0 x i8]
@olang_loc_21fa85d53b5eac7b_5a0125da6c5c013f = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5f0c96ba8f37c420_5ca612e1d5c707f4 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloopState(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i64 %a2)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ewiden(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_1a9a85648681e97_fcf9d2fab7c32a6b = external constant [0 x i8]
@olang_loc_54fd08b205476dc4_657f8db756d05b08 = external constant [0 x i8]
@olang_loc_923c0e7922172d2c_3d5b7ddd1cd85e60 = external constant [0 x i8]
@olang_loc_3398753e62525e0a_a26aec7fb7dfed8e = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_8b9fe86f9939495b_ac6312ba480f0d67 = external constant [0 x i8]
@olang_loc_3f464ddbb91b0a38_82918aeeacdcc614 = external constant [0 x i8]
@olang_loc_29167372d5c184b0_5aaac5f2b3f16f1c = external constant [0 x i8]
@olang_loc_18d2a0b724f39c7e_37ab118f04dce49a = external constant [0 x i8]
declare { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_fb0720d2dfee7f_1f99818eb62f02f3 = external constant [0 x i8]
@olang_loc_3cd7aa482e25463c_a46dd5e6d10de4a0 = external constant [0 x i8]
@olang_loc_65fecb72da6e9be9_e6833fce5f1f4ea5 = external constant [0 x i8]
@olang_loc_313fe9555679a06f_fa589a226c49c6eb = external constant [0 x i8]
@olang_loc_f3df993f4c7e1fd4_8419908bae6ac650 = external constant [0 x i8]
@olang_loc_e306d5ccad957c29_6b95b0de26f94a45 = external constant [0 x i8]
@olang_loc_d73b6870bbe51a4d_d845c63f23993221 = external constant [0 x i8]
@olang_loc_2545ce011bc2e3f3_a4cac8bc0a2d8747 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esetLocal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_43e833e67406aee2_76f2107f4f2989fe = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_10efe43793a641ac_2dabf1c43cd6a168 = external constant [0 x i8]
@olang_loc_4c49c2cc391943fc_885b7fff3b4a3180 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eHas_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_d15cb06393d6b10c_f6dc2a2381fafcf0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftyped_2eshort(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c13c66c7f09ff87e_38ebe5e5af81f22 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_7b432bbe8f05f1d7_7deffd42aa472253 = external constant [0 x i8]
@olang_loc_78afbb313fff45b8_957466907ebeb484 = external constant [0 x i8]
@olang_loc_90a2a4daf32abd74_d37804826367c570 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftyped_2econstText(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ftyped_2ecalleeBreaks(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2estmtsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2ftyped_2earmsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
@olang_loc_ef1bdab68bcf0283_bb587b6d5639fda7 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2earmBreaks(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2efnBreaks(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2epiecesBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
@olang_loc_b091697a8707c61b_ed3e4d18c76feebf = external constant [0 x i8]
@olang_loc_bea5bf6ffc689610_b71acf810bfa0324 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_61141ab026762302_86235c78c2d902d6 = external constant [0 x i8]
@olang_loc_2566079f8423d483_66fa93375f6766f7 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
@olang_loc_897c6ec4bdb8e7c2_3b49e2eddb87c67e = external constant [0 x i8]
@olang_loc_4d8d49a96eb287ee_1dbcd98d7cba02aa = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f3346b4d6d82824c_aeee08707a274ea0 = external constant [0 x i8]
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_88f338444ee928b2_cde52f1382e8437e = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_6cac4c556ee1b7d9_257131421adb63ad = external constant [0 x i8]
@olang_loc_52c63b14e30804cc_be8191a117211c80 = external constant [0 x i8]
@olang_loc_75ea3af438a3ca2f_999b6c305f7ce623 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3alandLoop_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_5a80d8a416bdb25a_ede72ef348da89ae = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_f4630321a8cc4bc9_818e9b0c99e677c5 = external constant [0 x i8]
@olang_loc_ed49a40517443f7c_ed7a500f174a658 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
