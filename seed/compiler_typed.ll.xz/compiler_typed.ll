; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:SiteInfo" = type { i32, %"compiler/source:Span" }
%"compiler/typed:printer" = type { ptr, %"std/prelude/text:StringBuilder" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
define dso_local %"compiler/typed:Plan" @compiler_2ftyped_2eNewPlan(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/typed:Plan"
  %rv = alloca %"compiler/typed:Plan"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eLe_Heec836b2f97bed3c10ee7e3cac736d9d(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Body", ptr %t6, i32 0, i32 7
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l6
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 6
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l9
  br label %bb3
bb3:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l9, !tbaa !24
  %t19 = call %"compiler/typed:Plan" @compiler_2ftyped_3aPlan_2ector(ptr %v1, i64 %t16, i64 %t17, i64 %t18)
  store %"compiler/typed:Plan" %t19, ptr %l10
  br label %bb4
bb4:
  %t20 = load %"compiler/typed:Plan", ptr %l10
  store %"compiler/typed:Plan" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Plan", ptr %rv
  ret %"compiler/typed:Plan" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca %"compiler/typed:BlockInfo"
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l5, !tbaa !29
  %t10 = call %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %s0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
  store %"compiler/typed:BlockInfo" %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load %"compiler/typed:BlockInfo", ptr %l9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eP_Hc92177ba48b21a9f8d26c1a49cf2119c(ptr %v0, ptr %t11, %"compiler/typed:BlockInfo" %t12)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 8
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eL_H5b8a0bc03aecb48440b685dbbc0b269c(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = sub i64 %t18, 1
  %t21 = trunc i64 %t19 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 7
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ePush_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t3, %"compiler/typed:Local" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Body", ptr %t7, i32 0, i32 7
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca %"compiler/typed:SiteInfo"
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l4, !tbaa !29
  %t8 = call %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %s0, i32 %a1, %"compiler/source:Span" %a2)
  store %"compiler/typed:SiteInfo" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"compiler/typed:SiteInfo", ptr %l7
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ePu_H5cdcfe4ca3473fd9feeaed4f4a6d3f84(ptr %v0, ptr %t9, %"compiler/typed:SiteInfo" %t10)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 9
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eLe_Heec836b2f97bed3c10ee7e3cac736d9d(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = sub i64 %t16, 1
  %t19 = trunc i64 %t17 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca i32
  %l16 = alloca %"compiler/typed:BlockInfo"
  %s1 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a2, ptr %l3, !tbaa !23
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load i32, ptr %l3, !tbaa !23
  %t5 = icmp sge i32 %t3, 0
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t13 = icmp eq i32 %t9, %a1
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 8
  %t19 = load i32, ptr %l3, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %t18, i64 %t21)
  store %"compiler/typed:BlockInfo" %t24, ptr %l16
  br label %bb8
bb8:
  %t25 = getelementptr %"compiler/typed:BlockInfo", ptr %l16, i32 0, i32 0
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/typed:Local"
  %rv = alloca %"compiler/typed:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 7
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/typed:Local" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load %"compiler/typed:Local", ptr %l6
  store %"compiler/typed:Local" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Local", ptr %rv
  ret %"compiler/typed:Local" %rr
}

define dso_local { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t23 = alloca { i64, [2 x i64] }, align 8
  %t54 = alloca { i64, [2 x i64] }, align 8
  %t58 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %t4, !tbaa !23
  %t6 = load i64, ptr %l2, !tbaa !24
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v1, ptr %t1, i32 %t5, i64 %t6)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 5
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t18, i64 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 0
  store i64 2, ptr %t24
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = insertvalue { i32 } undef, i32 %t25, 0
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 1
  store { i32 } %t26, ptr %t27
  %t28 = load { i64, [2 x i64] }, ptr %t23
  store { i64, [2 x i64] } %t28, ptr %rv
  br label %ret
bb5:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %t35, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t32, i32 %t36)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i32, ptr %t47, i64 %t44
  %t49 = load i32, ptr %t48, !tbaa !33
  %t50 = load ptr, ptr %l16, !tbaa !29
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v1, ptr %t50, i32 %t49)
  store i1 %t52, ptr %l26
  br label %bb8
bb8:
  %t53 = load i1, ptr %l26, !tbaa !21
  br i1 %t53, label %bb9, label %bb10
bb9:
  store { i64, [2 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [2 x i64] }, ptr %t54, i32 0, i32 0
  store i64 1, ptr %t55
  %t56 = load { i64, [2 x i64] }, ptr %t54
  store { i64, [2 x i64] } %t56, ptr %l27
  br label %bb11
bb10:
  store { i64, [2 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 0
  store i64 0, ptr %t59
  %t60 = load { i64, [2 x i64] }, ptr %t58
  store { i64, [2 x i64] } %t60, ptr %l27
  br label %bb11
bb11:
  %t62 = load { i64, [2 x i64] }, ptr %l27
  store { i64, [2 x i64] } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2ePrint(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/typed:printer"
  %l6 = alloca ptr
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/typed:printer" @compiler_2ftyped_3aprinter_2ector(ptr %v1, ptr %v1, ptr %a1)
  store %"compiler/typed:printer" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/typed:printer", ptr %l4
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store %"compiler/typed:printer" %t4, ptr %t5
  store ptr %t5, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 8
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eL_H5b8a0bc03aecb48440b685dbbc0b269c(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 9
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eLe_Heec836b2f97bed3c10ee7e3cac736d9d(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l15
  br label %bb4
bb4:
  %t23 = extractvalue { i64, ptr } { i64 5, ptr @.d0 }, 1
  %t24 = extractvalue { i64, ptr } { i64 5, ptr @.d0 }, 0
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t27 = add i64 %t24, %t26
  %t28 = extractvalue { i64, ptr } { i64 8, ptr @.d1 }, 1
  %t29 = extractvalue { i64, ptr } { i64 8, ptr @.d1 }, 0
  %t30 = add i64 %t27, %t29
  %t31 = load i64, ptr %l12, !tbaa !24
  %t32 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t33 = add i64 %t30, %t32
  %t34 = extractvalue { i64, ptr } { i64 8, ptr @.d2 }, 1
  %t35 = extractvalue { i64, ptr } { i64 8, ptr @.d2 }, 0
  %t36 = add i64 %t33, %t35
  %t37 = load i64, ptr %l15, !tbaa !24
  %t38 = call i64 @__olang_fmt_i64(ptr null, i64 %t37)
  %t39 = add i64 %t36, %t38
  %t40 = extractvalue { i64, ptr } { i64 6, ptr @.d3 }, 1
  %t41 = extractvalue { i64, ptr } { i64 6, ptr @.d3 }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t23, i64 %t24)
  %t44 = getelementptr i8, ptr %t43, i64 %t24
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t25)
  %t46 = getelementptr i8, ptr %t44, i64 %t26
  call void @olang_textcopy(ptr %t46, ptr %t28, i64 %t29)
  %t47 = getelementptr i8, ptr %t46, i64 %t29
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t31)
  %t49 = getelementptr i8, ptr %t47, i64 %t32
  call void @olang_textcopy(ptr %t49, ptr %t34, i64 %t35)
  %t50 = getelementptr i8, ptr %t49, i64 %t35
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t37)
  %t52 = getelementptr i8, ptr %t50, i64 %t38
  call void @olang_textcopy(ptr %t52, ptr %t40, i64 %t41)
  %t53 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t43, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t62 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v1, ptr %s0, ptr %t62, i64 0, { i64, ptr } %t61)
  br label %bb5
bb5:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Body", ptr %t64, i32 0, i32 11
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp ne ptr %t67, null
  br i1 %t69, label %bb6, label %bb7
bb6:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Body", ptr %t72, i32 0, i32 11
  %t75 = load ptr, ptr %t74, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v1, ptr %v0, ptr %t71, ptr %t75, i64 1)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t80 = getelementptr %"compiler/typed:printer", ptr %t78, i32 0, i32 1
  %t82 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v1, ptr %v2, ptr %t80)
  store { i64, ptr } %t82, ptr %l26
  br label %bb10
bb10:
  %t83 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t83, ptr %l27, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l28, !tbaa !24
  %t86 = load i64, ptr %l28, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l29, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l28, !tbaa !24
  %t96 = mul i64 %t95, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t92, ptr %t94, i64 %t96, i1 false)
  %t97 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t97, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t98 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eResultMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i32
  %rv = alloca { i64, [2 x i64] }
  %t18 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t40 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %t4, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v1, ptr %a1, i32 %t5, i64 %a2)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t16 = icmp eq i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t18
  %t19 = getelementptr { i64, [2 x i64] }, ptr %t18, i32 0, i32 0
  store i64 6, ptr %t19
  %t20 = load { i64, [2 x i64] }, ptr %t18
  store { i64, [2 x i64] } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l18
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 2, ptr %t34
  %t35 = load i32, ptr %l18, !tbaa !23
  %t36 = insertvalue { i32 } undef, i32 %t35, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  store { i64, [2 x i64] } %t38, ptr %rv
  br label %ret
bb8:
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 1, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t40
  store { i64, [2 x i64] } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l15 = alloca { i64, ptr }
  %l29 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca { i64, [1 x i64] }
  %l41 = alloca ptr
  %l45 = alloca i32
  %s2 = alloca %olang.scope
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t74 = alloca { i64, [1 x i64] }, align 8
  %t78 = alloca { i64, [1 x i64] }, align 8
  %t84 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  %t27 = icmp eq i64 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 6
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 3, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t31, { i64, [1 x i64] } %t34)
  br label %bb7
bb6:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t38 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t41 = icmp eq i64 %t37, %t38
  br i1 %t41, label %bb8, label %bb9
bb7:
  br label %bb28
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 1
  %t46 = load { i64, [2 x i64] }, ptr %t45
  store { i64, [2 x i64] } %t46, ptr %l6
  %t48 = load { i64, [2 x i64] }, ptr %l6
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb10, label %bb11
bb9:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t53, i32 0, i32 6
  store ptr %t55, ptr %l41, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 5
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t58, i64 %t59)
  store i32 %t62, ptr %l45
  br label %bb25
bb10:
  br label %bb14
bb11:
  %t63 = load { i64, [2 x i64] }, ptr %l6
  %t65 = extractvalue { i64, [2 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 2
  br i1 %t66, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb20:
  %t68 = load i1, ptr %l29, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 6
  store ptr %t71, ptr %l35, !tbaa !29
  br i1 %t68, label %bb21, label %bb22
bb21:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 2, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  store { i64, [1 x i64] } %t76, ptr %l37
  br label %bb23
bb22:
  store { i64, [1 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [1 x i64] }, ptr %t78, i32 0, i32 0
  store i64 1, ptr %t79
  %t80 = load { i64, [1 x i64] }, ptr %t78
  store { i64, [1 x i64] } %t80, ptr %l37
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load { i64, [1 x i64] }, ptr %l37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t82, { i64, [1 x i64] } %t83)
  br label %bb24
bb24:
  br label %bb27
bb25:
  store { i64, [1 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [1 x i64] }, ptr %t84, i32 0, i32 0
  store i64 0, ptr %t85
  %t86 = load i32, ptr %l45, !tbaa !23
  %t87 = insertvalue { i32 } undef, i32 %t86, 0
  %t88 = getelementptr { i64, [1 x i64] }, ptr %t84, i32 0, i32 1
  store { i32 } %t87, ptr %t88
  %t89 = load { i64, [1 x i64] }, ptr %t84
  %t90 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t90, { i64, [1 x i64] } %t89)
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l3, !tbaa !24
  br label %bb1
bb30:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb83
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l6
  br label %bb83
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l3
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t185, ptr %l6
  br label %bb83
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l4
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l4
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l4
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t262, ptr %l6
  br label %bb83
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t265 = load ptr, ptr %l113, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113, !tbaa !29
  %t269 = load i64, ptr %t268
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l114, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 0
  %t277 = load %"compiler/source:Span", ptr %t276
  store %"compiler/source:Span" %t277, ptr %l5
  br label %bb81
bb80:
  br label %bb82
bb81:
  %t279 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t279, ptr %l6
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb83:
  %t281 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t281, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l120 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l1, !tbaa !23
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l1, !tbaa !23
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l1, !tbaa !23
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load i32, ptr %l1, !tbaa !23
  store i32 %t61, ptr %l6, !tbaa !23
  br label %bb84
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l2, !tbaa !23
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l2, !tbaa !23
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l2, !tbaa !23
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l2, !tbaa !23
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i32, ptr %l2, !tbaa !23
  store i32 %t123, ptr %l6, !tbaa !23
  br label %bb84
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 1
  %t138 = load i32, ptr %t137
  store i32 %t138, ptr %l3, !tbaa !23
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 1
  %t153 = load i32, ptr %t152
  store i32 %t153, ptr %l3, !tbaa !23
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 1
  %t168 = load i32, ptr %t167
  store i32 %t168, ptr %l3, !tbaa !23
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 1
  %t183 = load i32, ptr %t182
  store i32 %t183, ptr %l3, !tbaa !23
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load i32, ptr %l3, !tbaa !23
  store i32 %t185, ptr %l6, !tbaa !23
  br label %bb84
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 1
  %t200 = load i32, ptr %t199
  store i32 %t200, ptr %l4, !tbaa !23
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 1
  %t215 = load i32, ptr %t214
  store i32 %t215, ptr %l4, !tbaa !23
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 1
  %t230 = load i32, ptr %t229
  store i32 %t230, ptr %l4, !tbaa !23
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 1
  %t245 = load i32, ptr %t244
  store i32 %t245, ptr %l4, !tbaa !23
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 1
  %t260 = load i32, ptr %t259
  store i32 %t260, ptr %l4, !tbaa !23
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load i32, ptr %l4, !tbaa !23
  store i32 %t262, ptr %l6, !tbaa !23
  br label %bb84
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t265 = load ptr, ptr %l113, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113, !tbaa !29
  %t269 = load i64, ptr %t268
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l114, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 2
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l5, !tbaa !29
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t279 = load ptr, ptr %l5, !tbaa !29
  %t281 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t279)
  store i32 %t281, ptr %l120
  br label %bb82
bb82:
  %t282 = load i32, ptr %l120, !tbaa !23
  store i32 %t282, ptr %l6, !tbaa !23
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @.c6)
  unreachable
bb84:
  %t283 = load i32, ptr %l6, !tbaa !23
  store i32 %t283, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l3
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t94 = load ptr, ptr %l41, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t109 = load ptr, ptr %l47, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l3
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @.c7)
  unreachable
bb37:
  %t125 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t125, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l1, !tbaa !23
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l1, !tbaa !23
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l1, !tbaa !23
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load i32, ptr %l1, !tbaa !23
  store i32 %t61, ptr %l3, !tbaa !23
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l2, !tbaa !23
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l2, !tbaa !23
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t94 = load ptr, ptr %l41, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l2, !tbaa !23
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t109 = load ptr, ptr %l47, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l2, !tbaa !23
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i32, ptr %l2, !tbaa !23
  store i32 %t123, ptr %l3, !tbaa !23
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @.c8)
  unreachable
bb37:
  %t125 = load i32, ptr %l3, !tbaa !23
  store i32 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca i64
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Plan", ptr %t8, i32 0, i32 5
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l13
  br label %bb1
bb1:
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = add i64 %t13, 1
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i64, ptr %t18, i64 %t16
  store i64 %t14, ptr %t19, !tbaa !34
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Plan", ptr %t20, i32 0, i32 4
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i64, ptr %t33, i64 %t26
  store i64 %t29, ptr %t34, !tbaa !34
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t49, ptr %l28, !tbaa !27
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, [1 x i64] }, ptr %t53, i64 %t50
  %t55 = load { i64, [1 x i64] }, ptr %t54
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Plan", ptr %t57, i32 0, i32 5
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t59, { i64, [1 x i64] } %t55)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l11 = alloca i1
  %l14 = alloca { i64, ptr }
  %l26 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t36 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 %t7
  %t12 = load i64, ptr %t11, !tbaa !34
  store i64 %t12, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 4
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l14, !tbaa !27
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t27 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t33 = icmp sge i64 %t18, %t30
  store i1 %t33, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t35 = load i1, ptr %l11, !tbaa !21
  br i1 %t35, label %bb4, label %bb5
bb4:
  store { i64, [1 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [1 x i64] }, ptr %t36, i32 0, i32 0
  store i64 0, ptr %t37
  %t38 = load { i64, [1 x i64] }, ptr %t36
  store { i64, [1 x i64] } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Plan", ptr %t40, i32 0, i32 5
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l2, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t52 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t42, i64 %t49)
  store { i64, [1 x i64] } %t52, ptr %l26
  br label %bb7
bb7:
  %t53 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb21
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb21
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb21
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l23, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l24, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb21
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t62 = load ptr, ptr %l29, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l29, !tbaa !29
  %t66 = load i64, ptr %t65
  %t68 = icmp eq i64 %t66, 4
  store i1 %t68, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t69 = load i1, ptr %l30, !tbaa !21
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l1
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t76 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t76, ptr %l4
  br label %bb67
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t79 = load ptr, ptr %l36, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l36, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb43
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t94 = load ptr, ptr %l42, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l42, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l43, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l43, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [3 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb43
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l48, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l49, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l49, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb43
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t124 = load ptr, ptr %l54, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l54, !tbaa !29
  %t128 = load i64, ptr %t127
  %t130 = icmp eq i64 %t128, 8
  store i1 %t130, ptr %l55, !tbaa !21
  br label %bb36
bb36:
  %t131 = load i1, ptr %l55, !tbaa !21
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l2
  br label %bb43
bb38:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t139 = load ptr, ptr %l60, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb39, label %bb40
bb39:
  %t142 = load ptr, ptr %l60, !tbaa !29
  %t143 = load i64, ptr %t142
  %t145 = icmp eq i64 %t143, 9
  store i1 %t145, ptr %l61, !tbaa !21
  br label %bb40
bb40:
  %t146 = load i1, ptr %l61, !tbaa !21
  br i1 %t146, label %bb41, label %bb42
bb41:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  store %"compiler/source:Span" %t151, ptr %l2
  br label %bb43
bb42:
  br label %bb44
bb43:
  %t153 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t153, ptr %l4
  br label %bb67
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t156 = load ptr, ptr %l67, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l67, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l68, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l68, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb65
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t171 = load ptr, ptr %l73, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l73, !tbaa !29
  %t175 = load i64, ptr %t174
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l74, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l74, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb65
bb52:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t186 = load ptr, ptr %l79, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb53, label %bb54
bb53:
  %t189 = load ptr, ptr %l79, !tbaa !29
  %t190 = load i64, ptr %t189
  %t192 = icmp eq i64 %t190, 12
  store i1 %t192, ptr %l80, !tbaa !21
  br label %bb54
bb54:
  %t193 = load i1, ptr %l80, !tbaa !21
  br i1 %t193, label %bb55, label %bb56
bb55:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr }, ptr %t196, i32 0, i32 0
  %t198 = load %"compiler/source:Span", ptr %t197
  store %"compiler/source:Span" %t198, ptr %l3
  br label %bb65
bb56:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t201 = load ptr, ptr %l85, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb57, label %bb58
bb57:
  %t204 = load ptr, ptr %l85, !tbaa !29
  %t205 = load i64, ptr %t204
  %t207 = icmp eq i64 %t205, 13
  store i1 %t207, ptr %l86, !tbaa !21
  br label %bb58
bb58:
  %t208 = load i1, ptr %l86, !tbaa !21
  br i1 %t208, label %bb59, label %bb60
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr { i64, [3 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", ptr }, ptr %t211, i32 0, i32 0
  %t213 = load %"compiler/source:Span", ptr %t212
  store %"compiler/source:Span" %t213, ptr %l3
  br label %bb65
bb60:
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t216 = load ptr, ptr %l91, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb61, label %bb62
bb61:
  %t219 = load ptr, ptr %l91, !tbaa !29
  %t220 = load i64, ptr %t219
  %t222 = icmp eq i64 %t220, 14
  store i1 %t222, ptr %l92, !tbaa !21
  br label %bb62
bb62:
  %t223 = load i1, ptr %l92, !tbaa !21
  br i1 %t223, label %bb63, label %bb64
bb63:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr { i64, [3 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", ptr }, ptr %t226, i32 0, i32 0
  %t228 = load %"compiler/source:Span", ptr %t227
  store %"compiler/source:Span" %t228, ptr %l3
  br label %bb65
bb64:
  br label %bb66
bb65:
  %t230 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
bb67:
  %t232 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t232, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l22 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t4 = sub i64 %t2, 1
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 0
  %t12 = sext i32 %t8 to i64
  %t13 = call i64 @__olang_fmt_i64(ptr null, i64 %t12)
  %t14 = add i64 %t10, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t9, i64 %t10)
  %t16 = getelementptr i8, ptr %t15, i64 %t10
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s0, ptr %t1, i64 %t4, { i64, ptr } %t26)
  br label %bb1
bb1:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Block", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t47, ptr %l22, !tbaa !27
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %t55, ptr %t53, i64 %t57)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb7
bb7:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l32 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca i32
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 0
  %t20 = sext i32 %t16 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  br label %bb29
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = extractvalue { i64, ptr } { i64 7, ptr @.d12 }, 1
  %t46 = extractvalue { i64, ptr } { i64 7, ptr @.d12 }, 0
  %t48 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t45, i64 %t46)
  %t51 = getelementptr i8, ptr %t50, i64 %t46
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t44)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t50, 1
  store { i64, ptr } %t54, ptr %l7, !tbaa !27
  br label %bb29
bb12:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t57 = load ptr, ptr %l24, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = load ptr, ptr %l24, !tbaa !29
  %t61 = load i64, ptr %t60
  %t63 = icmp eq i64 %t61, 2
  store i1 %t63, ptr %l25, !tbaa !21
  br label %bb14
bb14:
  %t64 = load i1, ptr %l25, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [1 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { ptr }, ptr %t67, i32 0, i32 0
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t75 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t71, ptr %t72)
  store { i64, ptr } %t75, ptr %l32
  br label %bb18
bb18:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t77, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb19:
  %t83 = load ptr, ptr %l1, !tbaa !29
  store ptr %t83, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t84 = load ptr, ptr %l34, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t87 = load ptr, ptr %l34, !tbaa !29
  %t88 = load i64, ptr %t87
  %t90 = icmp eq i64 %t88, 3
  store i1 %t90, ptr %l35, !tbaa !21
  br label %bb21
bb21:
  %t91 = load i1, ptr %l35, !tbaa !21
  br i1 %t91, label %bb22, label %bb23
bb22:
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [1 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { i32, i32 }, ptr %t94, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l5
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [1 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { i32, i32 }, ptr %t100, i32 0, i32 1
  %t102 = load i32, ptr %t101
  store i32 %t102, ptr %l6, !tbaa !23
  br label %bb24
bb23:
  br label %bb28
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t104 = load i32, ptr %l5
  store i32 %t104, ptr %l42
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aHelper(ptr %s8, ptr %l42, i64 0)
  br label %bb25
bb25:
  %t106 = load ptr, ptr %s8
  %t107 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t108 = load i64, ptr %t107
  %t109 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t106, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l44, !tbaa !27
  %t112 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t113 = load ptr, ptr %t112
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %sbgrew.115, label %sbdone.116
sbgrew.115:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.116
sbdone.116:
  %t117 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  %t119 = extractvalue { i64, ptr } %t117, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t125 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s7, { i64, ptr } %t123)
  store { i64, ptr } %t125, ptr %l46
  br label %bb26
bb26:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/typed:printer", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load i32, ptr %l6, !tbaa !23
  %t133 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s7, ptr %t129, i32 %t130)
  store { i64, ptr } %t133, ptr %l50
  br label %bb27
bb27:
  %t134 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = extractvalue { i64, ptr } { i64 1, ptr @.d13 }, 1
  %t138 = extractvalue { i64, ptr } { i64 1, ptr @.d13 }, 0
  %t139 = add i64 %t136, %t138
  %t140 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = add i64 %t139, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t135, i64 %t136)
  %t145 = getelementptr i8, ptr %t144, i64 %t136
  call void @olang_textcopy(ptr %t145, ptr %t137, i64 %t138)
  %t146 = getelementptr i8, ptr %t145, i64 %t138
  call void @olang_textcopy(ptr %t146, ptr %t141, i64 %t142)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t144, 1
  store { i64, ptr } %t148, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb29:
  %t150 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t150, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l58 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca i1
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca i1
  %l84 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca i1
  %l97 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l105 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l114 = alloca i1
  %l122 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l131 = alloca i1
  %l137 = alloca i32
  %l139 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l149 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l168 = alloca i32
  %l170 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l173 = alloca i32
  %l175 = alloca i32
  %l177 = alloca i1
  %l179 = alloca { i64, ptr }
  %l180 = alloca i32
  %l182 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l193 = alloca i1
  %l201 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l212 = alloca i1
  %l220 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l230 = alloca ptr
  %l231 = alloca i1
  %l238 = alloca i64
  %l242 = alloca { i64, ptr }
  %l244 = alloca ptr
  %l245 = alloca i1
  %l259 = alloca ptr
  %l260 = alloca i1
  %l268 = alloca { i64, ptr }
  %l273 = alloca ptr
  %l274 = alloca i1
  %l281 = alloca ptr
  %l282 = alloca i1
  %l293 = alloca ptr
  %l294 = alloca i1
  %l301 = alloca i64
  %l304 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.builder
  %s23room = alloca [64 x i8], align 8
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 1, ptr @.d15 }, ptr %l28, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t5, ptr %l29, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l30, !tbaa !24
  %t8 = load i64, ptr %l30, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l31, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l30, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t19, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/typed:printer", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l33, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t25)
  store i32 %t27, ptr %l35
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l33, !tbaa !29
  %t29 = load i32, ptr %l35, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l36
  br label %bb5
bb5:
  %t31 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t31, ptr %l2, !tbaa !27
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t33 = load ptr, ptr %l38, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l38, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 0
  store i1 %t39, ptr %l39, !tbaa !21
  br label %bb7
bb7:
  %t40 = load i1, ptr %l39, !tbaa !21
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t43, i32 0, i32 2
  %t45 = load i64, ptr %t44
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = extractvalue { i64, ptr } { i64 5, ptr @.d16 }, 1
  %t50 = extractvalue { i64, ptr } { i64 5, ptr @.d16 }, 0
  %t52 = extractvalue { i64, ptr } %t47, 1
  %t53 = extractvalue { i64, ptr } %t47, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 0
  %t57 = add i64 %t54, %t56
  %t59 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t60 = add i64 %t57, %t59
  %t61 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 1
  %t62 = extractvalue { i64, ptr } { i64 1, ptr @.d18 }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t49, i64 %t50)
  %t65 = getelementptr i8, ptr %t64, i64 %t50
  call void @olang_textcopy(ptr %t65, ptr %t52, i64 %t53)
  %t66 = getelementptr i8, ptr %t65, i64 %t53
  call void @olang_textcopy(ptr %t66, ptr %t55, i64 %t56)
  %t67 = getelementptr i8, ptr %t66, i64 %t56
  %t68 = call i64 @__olang_fmt_i64(ptr %t67, i64 %t48)
  %t69 = getelementptr i8, ptr %t67, i64 %t59
  call void @olang_textcopy(ptr %t69, ptr %t61, i64 %t62)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  store { i64, ptr } %t71, ptr %l37, !tbaa !27
  br label %bb145
bb11:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t74 = load ptr, ptr %l47, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb12, label %bb13
bb12:
  %t77 = load ptr, ptr %l47, !tbaa !29
  %t78 = load i64, ptr %t77
  %t80 = icmp eq i64 %t78, 1
  store i1 %t80, ptr %l48, !tbaa !21
  br label %bb13
bb13:
  %t81 = load i1, ptr %l48, !tbaa !21
  br i1 %t81, label %bb14, label %bb15
bb14:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load i64, ptr %t85
  store i64 %t86, ptr %l4, !tbaa !24
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t90, i32 0, i32 3
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t94, ptr %l55, !tbaa !27
  %t95 = load i64, ptr %l4, !tbaa !24
  store i64 %t95, ptr %l56, !tbaa !24
  %t96 = load ptr, ptr %l5, !tbaa !29
  %t98 = call { i64, ptr } @compiler_2ftyped_2econstText(ptr %v1, ptr %s4, ptr %t96)
  store { i64, ptr } %t98, ptr %l58
  br label %bb17
bb17:
  %t99 = extractvalue { i64, ptr } { i64 6, ptr @.d19 }, 1
  %t100 = extractvalue { i64, ptr } { i64 6, ptr @.d19 }, 0
  %t101 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = add i64 %t100, %t103
  %t105 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t106 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  %t107 = add i64 %t104, %t106
  %t108 = load i64, ptr %l56, !tbaa !24
  %t109 = call i64 @__olang_fmt_i64(ptr null, i64 %t108)
  %t110 = add i64 %t107, %t109
  %t111 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 1
  %t112 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 0
  %t113 = add i64 %t110, %t112
  %t114 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 0
  %t120 = add i64 %t117, %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t99, i64 %t100)
  %t122 = getelementptr i8, ptr %t121, i64 %t100
  call void @olang_textcopy(ptr %t122, ptr %t102, i64 %t103)
  %t123 = getelementptr i8, ptr %t122, i64 %t103
  call void @olang_textcopy(ptr %t123, ptr %t105, i64 %t106)
  %t124 = getelementptr i8, ptr %t123, i64 %t106
  %t125 = call i64 @__olang_fmt_i64(ptr %t124, i64 %t108)
  %t126 = getelementptr i8, ptr %t124, i64 %t109
  call void @olang_textcopy(ptr %t126, ptr %t111, i64 %t112)
  %t127 = getelementptr i8, ptr %t126, i64 %t112
  call void @olang_textcopy(ptr %t127, ptr %t115, i64 %t116)
  %t128 = getelementptr i8, ptr %t127, i64 %t116
  call void @olang_textcopy(ptr %t128, ptr %t118, i64 %t119)
  %t129 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t121, 1
  store { i64, ptr } %t130, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb145
bb18:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t133 = load ptr, ptr %l60, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb19, label %bb20
bb19:
  %t136 = load ptr, ptr %l60, !tbaa !29
  %t137 = load i64, ptr %t136
  %t139 = icmp eq i64 %t137, 2
  store i1 %t139, ptr %l61, !tbaa !21
  br label %bb20
bb20:
  %t140 = load i1, ptr %l61, !tbaa !21
  br i1 %t140, label %bb21, label %bb22
bb21:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t143, i32 0, i32 2
  %t145 = load ptr, ptr %t144
  store ptr %t145, ptr %l6, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t149, i32 0, i32 3
  %t151 = load i32, ptr %t150
  store i32 %t151, ptr %l7, !tbaa !23
  br label %bb23
bb22:
  br label %bb28
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l6, !tbaa !29
  %t157 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s6, ptr %t153, ptr %t154)
  store { i64, ptr } %t157, ptr %l70
  br label %bb24
bb24:
  %t158 = load i32, ptr %l7, !tbaa !23
  %t160 = icmp sge i32 %t158, 0
  br i1 %t160, label %bb25, label %bb26
bb25:
  %t162 = load i32, ptr %l7, !tbaa !23
  %t163 = extractvalue { i64, ptr } { i64 6, ptr @.d23 }, 1
  %t164 = extractvalue { i64, ptr } { i64 6, ptr @.d23 }, 0
  %t166 = sext i32 %t162 to i64
  %t167 = call i64 @__olang_fmt_i64(ptr null, i64 %t166)
  %t168 = add i64 %t164, %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t163, i64 %t164)
  %t170 = getelementptr i8, ptr %t169, i64 %t164
  %t171 = call i64 @__olang_fmt_i64(ptr %t170, i64 %t166)
  %t172 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t169, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  store { i64, ptr } %t180, ptr %l73, !tbaa !27
  br label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr @.d24 }, ptr %l73, !tbaa !27
  br label %bb27
bb27:
  %t182 = extractvalue { i64, ptr } { i64 6, ptr @.d25 }, 1
  %t183 = extractvalue { i64, ptr } { i64 6, ptr @.d25 }, 0
  %t184 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = add i64 %t183, %t186
  %t188 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = add i64 %t187, %t190
  %t192 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 1
  %t193 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 0
  %t194 = add i64 %t191, %t193
  %t195 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t182, i64 %t183)
  %t196 = getelementptr i8, ptr %t195, i64 %t183
  call void @olang_textcopy(ptr %t196, ptr %t185, i64 %t186)
  %t197 = getelementptr i8, ptr %t196, i64 %t186
  call void @olang_textcopy(ptr %t197, ptr %t189, i64 %t190)
  %t198 = getelementptr i8, ptr %t197, i64 %t190
  call void @olang_textcopy(ptr %t198, ptr %t192, i64 %t193)
  %t199 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t195, 1
  store { i64, ptr } %t200, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb145
bb28:
  %t202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t202, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t203 = load ptr, ptr %l78, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb29, label %bb30
bb29:
  %t206 = load ptr, ptr %l78, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 3
  store i1 %t209, ptr %l79, !tbaa !21
  br label %bb30
bb30:
  %t210 = load i1, ptr %l79, !tbaa !21
  br i1 %t210, label %bb31, label %bb32
bb31:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 2
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l8, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t217 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t217, ptr %l84, !tbaa !27
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l8, !tbaa !29
  %t222 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s9, ptr %t218, ptr %t219)
  store { i64, ptr } %t222, ptr %l87
  br label %bb34
bb34:
  %t223 = extractvalue { i64, ptr } { i64 8, ptr @.d27 }, 1
  %t224 = extractvalue { i64, ptr } { i64 8, ptr @.d27 }, 0
  %t225 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 0
  %t231 = add i64 %t228, %t230
  %t232 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 1, ptr @.d29 }, 1
  %t237 = extractvalue { i64, ptr } { i64 1, ptr @.d29 }, 0
  %t238 = add i64 %t235, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t223, i64 %t224)
  %t240 = getelementptr i8, ptr %t239, i64 %t224
  call void @olang_textcopy(ptr %t240, ptr %t226, i64 %t227)
  %t241 = getelementptr i8, ptr %t240, i64 %t227
  call void @olang_textcopy(ptr %t241, ptr %t229, i64 %t230)
  %t242 = getelementptr i8, ptr %t241, i64 %t230
  call void @olang_textcopy(ptr %t242, ptr %t233, i64 %t234)
  %t243 = getelementptr i8, ptr %t242, i64 %t234
  call void @olang_textcopy(ptr %t243, ptr %t236, i64 %t237)
  %t244 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t239, 1
  store { i64, ptr } %t245, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb145
bb35:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t248 = load ptr, ptr %l89, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb36, label %bb37
bb36:
  %t251 = load ptr, ptr %l89, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 4
  store i1 %t254, ptr %l90, !tbaa !21
  br label %bb37
bb37:
  %t255 = load i1, ptr %l90, !tbaa !21
  br i1 %t255, label %bb38, label %bb39
bb38:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l9, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  store %olang.scope zeroinitializer, ptr %s11
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l9, !tbaa !29
  %t266 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s11, ptr %t262, ptr %t263)
  store { i64, ptr } %t266, ptr %l97
  br label %bb41
bb41:
  %t267 = extractvalue { i64, ptr } { i64 6, ptr @.d30 }, 1
  %t268 = extractvalue { i64, ptr } { i64 6, ptr @.d30 }, 0
  %t269 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 1
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t272 = add i64 %t268, %t271
  %t273 = extractvalue { i64, ptr } { i64 1, ptr @.d31 }, 1
  %t274 = extractvalue { i64, ptr } { i64 1, ptr @.d31 }, 0
  %t275 = add i64 %t272, %t274
  %t276 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t275)
  call void @olang_textcopy(ptr %t276, ptr %t267, i64 %t268)
  %t277 = getelementptr i8, ptr %t276, i64 %t268
  call void @olang_textcopy(ptr %t277, ptr %t270, i64 %t271)
  %t278 = getelementptr i8, ptr %t277, i64 %t271
  call void @olang_textcopy(ptr %t278, ptr %t273, i64 %t274)
  %t279 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t276, 1
  store { i64, ptr } %t280, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb145
bb42:
  %t282 = load ptr, ptr %l1, !tbaa !29
  store ptr %t282, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t283 = load ptr, ptr %l99, !tbaa !29
  %t284 = icmp ne ptr %t283, null
  br i1 %t284, label %bb43, label %bb44
bb43:
  %t286 = load ptr, ptr %l99, !tbaa !29
  %t287 = load i64, ptr %t286
  %t289 = icmp eq i64 %t287, 5
  store i1 %t289, ptr %l100, !tbaa !21
  br label %bb44
bb44:
  %t290 = load i1, ptr %l100, !tbaa !21
  br i1 %t290, label %bb45, label %bb46
bb45:
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [5 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t293, i32 0, i32 2
  %t295 = load ptr, ptr %t294
  store ptr %t295, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  %t297 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t297, ptr %l105, !tbaa !27
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l10, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Promote", ptr %t299, i32 0, i32 0
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t305 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s13, ptr %t298, ptr %t302)
  store { i64, ptr } %t305, ptr %l109
  br label %bb48
bb48:
  %t306 = load ptr, ptr %l10, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Promote", ptr %t306, i32 0, i32 1
  %t309 = load i32, ptr %t308, !tbaa !23
  %t310 = extractvalue { i64, ptr } { i64 9, ptr @.d32 }, 1
  %t311 = extractvalue { i64, ptr } { i64 9, ptr @.d32 }, 0
  %t312 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t312, 1
  %t314 = extractvalue { i64, ptr } %t312, 0
  %t315 = add i64 %t311, %t314
  %t316 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 1
  %t317 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 0
  %t318 = add i64 %t315, %t317
  %t319 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 1
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t322 = add i64 %t318, %t321
  %t323 = extractvalue { i64, ptr } { i64 6, ptr @.d34 }, 1
  %t324 = extractvalue { i64, ptr } { i64 6, ptr @.d34 }, 0
  %t325 = add i64 %t322, %t324
  %t327 = sext i32 %t309 to i64
  %t328 = call i64 @__olang_fmt_i64(ptr null, i64 %t327)
  %t329 = add i64 %t325, %t328
  %t330 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 1
  %t331 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 0
  %t332 = add i64 %t329, %t331
  %t333 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t310, i64 %t311)
  %t334 = getelementptr i8, ptr %t333, i64 %t311
  call void @olang_textcopy(ptr %t334, ptr %t313, i64 %t314)
  %t335 = getelementptr i8, ptr %t334, i64 %t314
  call void @olang_textcopy(ptr %t335, ptr %t316, i64 %t317)
  %t336 = getelementptr i8, ptr %t335, i64 %t317
  call void @olang_textcopy(ptr %t336, ptr %t320, i64 %t321)
  %t337 = getelementptr i8, ptr %t336, i64 %t321
  call void @olang_textcopy(ptr %t337, ptr %t323, i64 %t324)
  %t338 = getelementptr i8, ptr %t337, i64 %t324
  %t339 = call i64 @__olang_fmt_i64(ptr %t338, i64 %t327)
  %t340 = getelementptr i8, ptr %t338, i64 %t328
  call void @olang_textcopy(ptr %t340, ptr %t330, i64 %t331)
  %t341 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t333, 1
  store { i64, ptr } %t342, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb145
bb49:
  %t344 = load ptr, ptr %l1, !tbaa !29
  store ptr %t344, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t345 = load ptr, ptr %l113, !tbaa !29
  %t346 = icmp ne ptr %t345, null
  br i1 %t346, label %bb50, label %bb51
bb50:
  %t348 = load ptr, ptr %l113, !tbaa !29
  %t349 = load i64, ptr %t348
  %t351 = icmp eq i64 %t349, 6
  store i1 %t351, ptr %l114, !tbaa !21
  br label %bb51
bb51:
  %t352 = load i1, ptr %l114, !tbaa !21
  br i1 %t352, label %bb52, label %bb53
bb52:
  %t353 = load ptr, ptr %l1, !tbaa !29
  %t355 = getelementptr { i64, [5 x i64] }, ptr %t353, i32 0, i32 1
  %t356 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t355, i32 0, i32 2
  %t357 = load ptr, ptr %t356
  store ptr %t357, ptr %l11, !tbaa !29
  br label %bb54
bb53:
  br label %bb57
bb54:
  store %olang.scope zeroinitializer, ptr %s15
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load ptr, ptr %l11, !tbaa !29
  %t362 = getelementptr %"compiler/typed:Call", ptr %t360, i32 0, i32 0
  %t363 = load ptr, ptr %t362, !tbaa !29
  %t366 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2ecallee(ptr %v0, ptr %v1, ptr %s15, ptr %t359, ptr %t363)
  store { i64, ptr } %t366, ptr %l122
  br label %bb55
bb55:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l11, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Call", ptr %t368, i32 0, i32 1
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  %t374 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s15, ptr %t367, { i64, ptr } %t371)
  store { i64, ptr } %t374, ptr %l126
  br label %bb56
bb56:
  %t375 = load ptr, ptr %l11, !tbaa !29
  %t377 = getelementptr %"compiler/typed:Call", ptr %t375, i32 0, i32 3
  %t378 = load i32, ptr %t377, !tbaa !23
  %t379 = extractvalue { i64, ptr } { i64 6, ptr @.d36 }, 1
  %t380 = extractvalue { i64, ptr } { i64 6, ptr @.d36 }, 0
  %t381 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  %t384 = add i64 %t380, %t383
  %t385 = extractvalue { i64, ptr } { i64 1, ptr @.d37 }, 1
  %t386 = extractvalue { i64, ptr } { i64 1, ptr @.d37 }, 0
  %t387 = add i64 %t384, %t386
  %t388 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t388, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = add i64 %t387, %t390
  %t392 = extractvalue { i64, ptr } { i64 6, ptr @.d38 }, 1
  %t393 = extractvalue { i64, ptr } { i64 6, ptr @.d38 }, 0
  %t394 = add i64 %t391, %t393
  %t396 = sext i32 %t378 to i64
  %t397 = call i64 @__olang_fmt_i64(ptr null, i64 %t396)
  %t398 = add i64 %t394, %t397
  %t399 = extractvalue { i64, ptr } { i64 1, ptr @.d39 }, 1
  %t400 = extractvalue { i64, ptr } { i64 1, ptr @.d39 }, 0
  %t401 = add i64 %t398, %t400
  %t402 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t401)
  call void @olang_textcopy(ptr %t402, ptr %t379, i64 %t380)
  %t403 = getelementptr i8, ptr %t402, i64 %t380
  call void @olang_textcopy(ptr %t403, ptr %t382, i64 %t383)
  %t404 = getelementptr i8, ptr %t403, i64 %t383
  call void @olang_textcopy(ptr %t404, ptr %t385, i64 %t386)
  %t405 = getelementptr i8, ptr %t404, i64 %t386
  call void @olang_textcopy(ptr %t405, ptr %t389, i64 %t390)
  %t406 = getelementptr i8, ptr %t405, i64 %t390
  call void @olang_textcopy(ptr %t406, ptr %t392, i64 %t393)
  %t407 = getelementptr i8, ptr %t406, i64 %t393
  %t408 = call i64 @__olang_fmt_i64(ptr %t407, i64 %t396)
  %t409 = getelementptr i8, ptr %t407, i64 %t397
  call void @olang_textcopy(ptr %t409, ptr %t399, i64 %t400)
  %t410 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t411 = insertvalue { i64, ptr } %t410, ptr %t402, 1
  store { i64, ptr } %t411, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  br label %bb145
bb57:
  %t413 = load ptr, ptr %l1, !tbaa !29
  store ptr %t413, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t414 = load ptr, ptr %l130, !tbaa !29
  %t415 = icmp ne ptr %t414, null
  br i1 %t415, label %bb58, label %bb59
bb58:
  %t417 = load ptr, ptr %l130, !tbaa !29
  %t418 = load i64, ptr %t417
  %t420 = icmp eq i64 %t418, 7
  store i1 %t420, ptr %l131, !tbaa !21
  br label %bb59
bb59:
  %t421 = load i1, ptr %l131, !tbaa !21
  br i1 %t421, label %bb60, label %bb61
bb60:
  %t422 = load ptr, ptr %l1, !tbaa !29
  %t424 = getelementptr { i64, [5 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t424, i32 0, i32 2
  %t426 = load ptr, ptr %t425
  store ptr %t426, ptr %l12, !tbaa !29
  br label %bb62
bb61:
  br label %bb66
bb62:
  store %olang.scope zeroinitializer, ptr %s17
  %t428 = load ptr, ptr %l12, !tbaa !29
  %t430 = getelementptr %"compiler/typed:Make", ptr %t428, i32 0, i32 0
  %t431 = load i32, ptr %t430
  store i32 %t431, ptr %l137
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aMakeKind(ptr %s18, ptr %l137, i64 0)
  br label %bb63
bb63:
  %t433 = load ptr, ptr %s18
  %t434 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t435 = load i64, ptr %t434
  %t436 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t435)
  call void @olang_textcopy(ptr %t436, ptr %t433, i64 %t435)
  %t437 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t436, 1
  store { i64, ptr } %t438, ptr %l139, !tbaa !27
  %t439 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t440 = load ptr, ptr %t439
  %t441 = icmp ne ptr %t440, null
  br i1 %t441, label %sbgrew.442, label %sbdone.443
sbgrew.442:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.443
sbdone.443:
  %t444 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 0
  %t446 = extractvalue { i64, ptr } %t444, 1
  %t447 = mul i64 %t445, 1
  %t448 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t447)
  call void @llvm.memcpy.p0.p0.i64(ptr %t448, ptr %t446, i64 %t447, i1 false)
  %t449 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t450 = insertvalue { i64, ptr } %t449, ptr %t448, 1
  %t452 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s17, { i64, ptr } %t450)
  store { i64, ptr } %t452, ptr %l141
  br label %bb64
bb64:
  %t453 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t453, ptr %l142, !tbaa !27
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load ptr, ptr %l12, !tbaa !29
  %t457 = getelementptr %"compiler/typed:Make", ptr %t455, i32 0, i32 2
  %t458 = load { i64, ptr }, ptr %t457, !tbaa !27
  %t461 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s17, ptr %t454, { i64, ptr } %t458)
  store { i64, ptr } %t461, ptr %l146
  br label %bb65
bb65:
  %t462 = extractvalue { i64, ptr } { i64 6, ptr @.d40 }, 1
  %t463 = extractvalue { i64, ptr } { i64 6, ptr @.d40 }, 0
  %t464 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 1
  %t466 = extractvalue { i64, ptr } %t464, 0
  %t467 = add i64 %t463, %t466
  %t468 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 1
  %t469 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 0
  %t470 = add i64 %t467, %t469
  %t471 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t471, 1
  %t473 = extractvalue { i64, ptr } %t471, 0
  %t474 = add i64 %t470, %t473
  %t475 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 1
  %t476 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 0
  %t477 = add i64 %t474, %t476
  %t478 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t478, 1
  %t480 = extractvalue { i64, ptr } %t478, 0
  %t481 = add i64 %t477, %t480
  %t482 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 1
  %t483 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 0
  %t484 = add i64 %t481, %t483
  %t485 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t484)
  call void @olang_textcopy(ptr %t485, ptr %t462, i64 %t463)
  %t486 = getelementptr i8, ptr %t485, i64 %t463
  call void @olang_textcopy(ptr %t486, ptr %t465, i64 %t466)
  %t487 = getelementptr i8, ptr %t486, i64 %t466
  call void @olang_textcopy(ptr %t487, ptr %t468, i64 %t469)
  %t488 = getelementptr i8, ptr %t487, i64 %t469
  call void @olang_textcopy(ptr %t488, ptr %t472, i64 %t473)
  %t489 = getelementptr i8, ptr %t488, i64 %t473
  call void @olang_textcopy(ptr %t489, ptr %t475, i64 %t476)
  %t490 = getelementptr i8, ptr %t489, i64 %t476
  call void @olang_textcopy(ptr %t490, ptr %t479, i64 %t480)
  %t491 = getelementptr i8, ptr %t490, i64 %t480
  call void @olang_textcopy(ptr %t491, ptr %t482, i64 %t483)
  %t492 = insertvalue { i64, ptr } undef, i64 %t484, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t485, 1
  store { i64, ptr } %t493, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb145
bb66:
  %t495 = load ptr, ptr %l1, !tbaa !29
  store ptr %t495, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t496 = load ptr, ptr %l148, !tbaa !29
  %t497 = icmp ne ptr %t496, null
  br i1 %t497, label %bb67, label %bb68
bb67:
  %t499 = load ptr, ptr %l148, !tbaa !29
  %t500 = load i64, ptr %t499
  %t502 = icmp eq i64 %t500, 8
  store i1 %t502, ptr %l149, !tbaa !21
  br label %bb68
bb68:
  %t503 = load i1, ptr %l149, !tbaa !21
  br i1 %t503, label %bb69, label %bb70
bb69:
  %t504 = load ptr, ptr %l1, !tbaa !29
  %t506 = getelementptr { i64, [5 x i64] }, ptr %t504, i32 0, i32 1
  %t507 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t506, i32 0, i32 2
  %t508 = load ptr, ptr %t507
  store ptr %t508, ptr %l13, !tbaa !29
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t510 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t511 = load ptr, ptr %l13, !tbaa !29
  %t513 = getelementptr %"compiler/typed:Collect", ptr %t511, i32 0, i32 2
  %t514 = load i32, ptr %t513, !tbaa !23
  %t515 = extractvalue { i64, ptr } { i64 9, ptr @.d44 }, 1
  %t516 = extractvalue { i64, ptr } { i64 9, ptr @.d44 }, 0
  %t518 = extractvalue { i64, ptr } %t510, 1
  %t519 = extractvalue { i64, ptr } %t510, 0
  %t520 = add i64 %t516, %t519
  %t521 = extractvalue { i64, ptr } { i64 6, ptr @.d45 }, 1
  %t522 = extractvalue { i64, ptr } { i64 6, ptr @.d45 }, 0
  %t523 = add i64 %t520, %t522
  %t525 = sext i32 %t514 to i64
  %t526 = call i64 @__olang_fmt_i64(ptr null, i64 %t525)
  %t527 = add i64 %t523, %t526
  %t528 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 1
  %t529 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 0
  %t530 = add i64 %t527, %t529
  %t531 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t530)
  call void @olang_textcopy(ptr %t531, ptr %t515, i64 %t516)
  %t532 = getelementptr i8, ptr %t531, i64 %t516
  call void @olang_textcopy(ptr %t532, ptr %t518, i64 %t519)
  %t533 = getelementptr i8, ptr %t532, i64 %t519
  call void @olang_textcopy(ptr %t533, ptr %t521, i64 %t522)
  %t534 = getelementptr i8, ptr %t533, i64 %t522
  %t535 = call i64 @__olang_fmt_i64(ptr %t534, i64 %t525)
  %t536 = getelementptr i8, ptr %t534, i64 %t526
  call void @olang_textcopy(ptr %t536, ptr %t528, i64 %t529)
  %t537 = insertvalue { i64, ptr } undef, i64 %t530, 0
  %t538 = insertvalue { i64, ptr } %t537, ptr %t531, 1
  store { i64, ptr } %t538, ptr %l37, !tbaa !27
  br label %bb145
bb72:
  %t540 = load ptr, ptr %l1, !tbaa !29
  store ptr %t540, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t541 = load ptr, ptr %l158, !tbaa !29
  %t542 = icmp ne ptr %t541, null
  br i1 %t542, label %bb73, label %bb74
bb73:
  %t544 = load ptr, ptr %l158, !tbaa !29
  %t545 = load i64, ptr %t544
  %t547 = icmp eq i64 %t545, 9
  store i1 %t547, ptr %l159, !tbaa !21
  br label %bb74
bb74:
  %t548 = load i1, ptr %l159, !tbaa !21
  br i1 %t548, label %bb75, label %bb76
bb75:
  %t549 = load ptr, ptr %l1, !tbaa !29
  %t551 = getelementptr { i64, [5 x i64] }, ptr %t549, i32 0, i32 1
  %t552 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t551, i32 0, i32 2
  %t553 = load i32, ptr %t552
  store i32 %t553, ptr %l14
  %t555 = load ptr, ptr %l1, !tbaa !29
  %t557 = getelementptr { i64, [5 x i64] }, ptr %t555, i32 0, i32 1
  %t558 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t557, i32 0, i32 3
  %t559 = load i32, ptr %t558
  store i32 %t559, ptr %l15
  %t561 = load ptr, ptr %l1, !tbaa !29
  %t563 = getelementptr { i64, [5 x i64] }, ptr %t561, i32 0, i32 1
  %t564 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t563, i32 0, i32 4
  %t565 = load { i64, ptr }, ptr %t564
  store { i64, ptr } %t565, ptr %l16, !tbaa !27
  br label %bb77
bb76:
  br label %bb87
bb77:
  store %olang.scope zeroinitializer, ptr %s22
  %t567 = load i32, ptr %l14
  store i32 %t567, ptr %l168
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s23
  store ptr %s23room, ptr %s23
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s23, ptr %l168, i64 0)
  br label %bb78
bb78:
  %t569 = load ptr, ptr %s23
  %t570 = getelementptr %olang.builder, ptr %s23, i32 0, i32 1
  %t571 = load i64, ptr %t570
  %t572 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t571)
  call void @olang_textcopy(ptr %t572, ptr %t569, i64 %t571)
  %t573 = insertvalue { i64, ptr } undef, i64 %t571, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t572, 1
  store { i64, ptr } %t574, ptr %l170, !tbaa !27
  %t575 = getelementptr %olang.builder, ptr %s23, i32 0, i32 3
  %t576 = load ptr, ptr %t575
  %t577 = icmp ne ptr %t576, null
  br i1 %t577, label %sbgrew.578, label %sbdone.579
sbgrew.578:
  call void @__olang_sb_done(ptr %s23)
  br label %sbdone.579
sbdone.579:
  %t580 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t581 = extractvalue { i64, ptr } %t580, 0
  %t582 = extractvalue { i64, ptr } %t580, 1
  %t583 = mul i64 %t581, 1
  %t584 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t583)
  call void @llvm.memcpy.p0.p0.i64(ptr %t584, ptr %t582, i64 %t583, i1 false)
  %t585 = insertvalue { i64, ptr } undef, i64 %t581, 0
  %t586 = insertvalue { i64, ptr } %t585, ptr %t584, 1
  %t588 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s22, { i64, ptr } %t586)
  store { i64, ptr } %t588, ptr %l172
  br label %bb79
bb79:
  %t589 = load i32, ptr %l15
  store i32 %t589, ptr %l173
  store i32 0, ptr %l175
  %t592 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aCheck(ptr %l173, ptr %l175)
  store i1 %t592, ptr %l177
  br label %bb80
bb80:
  %t593 = load i1, ptr %l177, !tbaa !21
  %t594 = xor i1 %t593, true
  br i1 %t594, label %bb81, label %bb82
bb81:
  %t596 = load i32, ptr %l15
  store i32 %t596, ptr %l180
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aCheck(ptr %s24, ptr %l180, i64 0)
  br label %bb83
bb82:
  store { i64, ptr } { i64 0, ptr @.d47 }, ptr %l179, !tbaa !27
  br label %bb85
bb83:
  %t598 = load ptr, ptr %s24
  %t599 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t600 = load i64, ptr %t599
  %t601 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t600)
  call void @olang_textcopy(ptr %t601, ptr %t598, i64 %t600)
  %t602 = insertvalue { i64, ptr } undef, i64 %t600, 0
  %t603 = insertvalue { i64, ptr } %t602, ptr %t601, 1
  store { i64, ptr } %t603, ptr %l182, !tbaa !27
  %t604 = getelementptr %olang.builder, ptr %s24, i32 0, i32 3
  %t605 = load ptr, ptr %t604
  %t606 = icmp ne ptr %t605, null
  br i1 %t606, label %sbgrew.607, label %sbdone.608
sbgrew.607:
  call void @__olang_sb_done(ptr %s24)
  br label %sbdone.608
sbdone.608:
  %t609 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t610 = extractvalue { i64, ptr } %t609, 0
  %t611 = extractvalue { i64, ptr } %t609, 1
  %t612 = mul i64 %t610, 1
  %t613 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t612)
  call void @llvm.memcpy.p0.p0.i64(ptr %t613, ptr %t611, i64 %t612, i1 false)
  %t614 = insertvalue { i64, ptr } undef, i64 %t610, 0
  %t615 = insertvalue { i64, ptr } %t614, ptr %t613, 1
  %t617 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s22, { i64, ptr } %t615)
  store { i64, ptr } %t617, ptr %l184
  br label %bb84
bb84:
  %t618 = extractvalue { i64, ptr } { i64 1, ptr @.d48 }, 1
  %t619 = extractvalue { i64, ptr } { i64 1, ptr @.d48 }, 0
  %t620 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t621 = extractvalue { i64, ptr } %t620, 1
  %t622 = extractvalue { i64, ptr } %t620, 0
  %t623 = add i64 %t619, %t622
  %t624 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t623)
  call void @olang_textcopy(ptr %t624, ptr %t618, i64 %t619)
  %t625 = getelementptr i8, ptr %t624, i64 %t619
  call void @olang_textcopy(ptr %t625, ptr %t621, i64 %t622)
  %t626 = insertvalue { i64, ptr } undef, i64 %t623, 0
  %t627 = insertvalue { i64, ptr } %t626, ptr %t624, 1
  %t629 = extractvalue { i64, ptr } %t627, 0
  %t630 = extractvalue { i64, ptr } %t627, 1
  %t631 = mul i64 %t629, 1
  %t632 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t631)
  call void @llvm.memcpy.p0.p0.i64(ptr %t632, ptr %t630, i64 %t631, i1 false)
  %t633 = insertvalue { i64, ptr } undef, i64 %t629, 0
  %t634 = insertvalue { i64, ptr } %t633, ptr %t632, 1
  store { i64, ptr } %t634, ptr %l179, !tbaa !27
  br label %bb85
bb85:
  %t636 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t636, ptr %l187, !tbaa !27
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t638 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t641 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s22, ptr %t637, { i64, ptr } %t638)
  store { i64, ptr } %t641, ptr %l190
  br label %bb86
bb86:
  %t642 = extractvalue { i64, ptr } { i64 1, ptr @.d49 }, 1
  %t643 = extractvalue { i64, ptr } { i64 1, ptr @.d49 }, 0
  %t644 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t645 = extractvalue { i64, ptr } %t644, 1
  %t646 = extractvalue { i64, ptr } %t644, 0
  %t647 = add i64 %t643, %t646
  %t648 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t649 = extractvalue { i64, ptr } %t648, 1
  %t650 = extractvalue { i64, ptr } %t648, 0
  %t651 = add i64 %t647, %t650
  %t652 = extractvalue { i64, ptr } { i64 1, ptr @.d50 }, 1
  %t653 = extractvalue { i64, ptr } { i64 1, ptr @.d50 }, 0
  %t654 = add i64 %t651, %t653
  %t655 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t656 = extractvalue { i64, ptr } %t655, 1
  %t657 = extractvalue { i64, ptr } %t655, 0
  %t658 = add i64 %t654, %t657
  %t659 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 1
  %t660 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 0
  %t661 = add i64 %t658, %t660
  %t662 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t663 = extractvalue { i64, ptr } %t662, 1
  %t664 = extractvalue { i64, ptr } %t662, 0
  %t665 = add i64 %t661, %t664
  %t666 = extractvalue { i64, ptr } { i64 1, ptr @.d52 }, 1
  %t667 = extractvalue { i64, ptr } { i64 1, ptr @.d52 }, 0
  %t668 = add i64 %t665, %t667
  %t669 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t668)
  call void @olang_textcopy(ptr %t669, ptr %t642, i64 %t643)
  %t670 = getelementptr i8, ptr %t669, i64 %t643
  call void @olang_textcopy(ptr %t670, ptr %t645, i64 %t646)
  %t671 = getelementptr i8, ptr %t670, i64 %t646
  call void @olang_textcopy(ptr %t671, ptr %t649, i64 %t650)
  %t672 = getelementptr i8, ptr %t671, i64 %t650
  call void @olang_textcopy(ptr %t672, ptr %t652, i64 %t653)
  %t673 = getelementptr i8, ptr %t672, i64 %t653
  call void @olang_textcopy(ptr %t673, ptr %t656, i64 %t657)
  %t674 = getelementptr i8, ptr %t673, i64 %t657
  call void @olang_textcopy(ptr %t674, ptr %t659, i64 %t660)
  %t675 = getelementptr i8, ptr %t674, i64 %t660
  call void @olang_textcopy(ptr %t675, ptr %t663, i64 %t664)
  %t676 = getelementptr i8, ptr %t675, i64 %t664
  call void @olang_textcopy(ptr %t676, ptr %t666, i64 %t667)
  %t677 = insertvalue { i64, ptr } undef, i64 %t668, 0
  %t678 = insertvalue { i64, ptr } %t677, ptr %t669, 1
  store { i64, ptr } %t678, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb145
bb87:
  %t680 = load ptr, ptr %l1, !tbaa !29
  store ptr %t680, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t681 = load ptr, ptr %l192, !tbaa !29
  %t682 = icmp ne ptr %t681, null
  br i1 %t682, label %bb88, label %bb89
bb88:
  %t684 = load ptr, ptr %l192, !tbaa !29
  %t685 = load i64, ptr %t684
  %t687 = icmp eq i64 %t685, 10
  store i1 %t687, ptr %l193, !tbaa !21
  br label %bb89
bb89:
  %t688 = load i1, ptr %l193, !tbaa !21
  br i1 %t688, label %bb90, label %bb91
bb90:
  %t689 = load ptr, ptr %l1, !tbaa !29
  %t691 = getelementptr { i64, [5 x i64] }, ptr %t689, i32 0, i32 1
  %t692 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t691, i32 0, i32 2
  %t693 = load ptr, ptr %t692
  store ptr %t693, ptr %l17, !tbaa !29
  br label %bb92
bb91:
  br label %bb96
bb92:
  store %olang.scope zeroinitializer, ptr %s27
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t696 = load ptr, ptr %l17, !tbaa !29
  %t698 = getelementptr %"compiler/typed:Slice", ptr %t696, i32 0, i32 0
  %t699 = load ptr, ptr %t698, !tbaa !29
  %t702 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s27, ptr %t695, ptr %t699)
  store { i64, ptr } %t702, ptr %l201
  br label %bb93
bb93:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load ptr, ptr %l17, !tbaa !29
  %t706 = getelementptr %"compiler/typed:Slice", ptr %t704, i32 0, i32 1
  %t707 = load ptr, ptr %t706, !tbaa !29
  %t710 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %t703, ptr %t707)
  store { i64, ptr } %t710, ptr %l205
  br label %bb94
bb94:
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t712 = load ptr, ptr %l17, !tbaa !29
  %t714 = getelementptr %"compiler/typed:Slice", ptr %t712, i32 0, i32 2
  %t715 = load ptr, ptr %t714, !tbaa !29
  %t718 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %t711, ptr %t715)
  store { i64, ptr } %t718, ptr %l209
  br label %bb95
bb95:
  %t719 = extractvalue { i64, ptr } { i64 7, ptr @.d53 }, 1
  %t720 = extractvalue { i64, ptr } { i64 7, ptr @.d53 }, 0
  %t721 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t722 = extractvalue { i64, ptr } %t721, 1
  %t723 = extractvalue { i64, ptr } %t721, 0
  %t724 = add i64 %t720, %t723
  %t725 = extractvalue { i64, ptr } { i64 1, ptr @.d54 }, 1
  %t726 = extractvalue { i64, ptr } { i64 1, ptr @.d54 }, 0
  %t727 = add i64 %t724, %t726
  %t728 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t729 = extractvalue { i64, ptr } %t728, 1
  %t730 = extractvalue { i64, ptr } %t728, 0
  %t731 = add i64 %t727, %t730
  %t732 = extractvalue { i64, ptr } { i64 1, ptr @.d55 }, 1
  %t733 = extractvalue { i64, ptr } { i64 1, ptr @.d55 }, 0
  %t734 = add i64 %t731, %t733
  %t735 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t736 = extractvalue { i64, ptr } %t735, 1
  %t737 = extractvalue { i64, ptr } %t735, 0
  %t738 = add i64 %t734, %t737
  %t739 = extractvalue { i64, ptr } { i64 1, ptr @.d56 }, 1
  %t740 = extractvalue { i64, ptr } { i64 1, ptr @.d56 }, 0
  %t741 = add i64 %t738, %t740
  %t742 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t741)
  call void @olang_textcopy(ptr %t742, ptr %t719, i64 %t720)
  %t743 = getelementptr i8, ptr %t742, i64 %t720
  call void @olang_textcopy(ptr %t743, ptr %t722, i64 %t723)
  %t744 = getelementptr i8, ptr %t743, i64 %t723
  call void @olang_textcopy(ptr %t744, ptr %t725, i64 %t726)
  %t745 = getelementptr i8, ptr %t744, i64 %t726
  call void @olang_textcopy(ptr %t745, ptr %t729, i64 %t730)
  %t746 = getelementptr i8, ptr %t745, i64 %t730
  call void @olang_textcopy(ptr %t746, ptr %t732, i64 %t733)
  %t747 = getelementptr i8, ptr %t746, i64 %t733
  call void @olang_textcopy(ptr %t747, ptr %t736, i64 %t737)
  %t748 = getelementptr i8, ptr %t747, i64 %t737
  call void @olang_textcopy(ptr %t748, ptr %t739, i64 %t740)
  %t749 = insertvalue { i64, ptr } undef, i64 %t741, 0
  %t750 = insertvalue { i64, ptr } %t749, ptr %t742, 1
  store { i64, ptr } %t750, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s27)
  br label %bb145
bb96:
  %t752 = load ptr, ptr %l1, !tbaa !29
  store ptr %t752, ptr %l211, !tbaa !29
  store i1 false, ptr %l212, !tbaa !21
  %t753 = load ptr, ptr %l211, !tbaa !29
  %t754 = icmp ne ptr %t753, null
  br i1 %t754, label %bb97, label %bb98
bb97:
  %t756 = load ptr, ptr %l211, !tbaa !29
  %t757 = load i64, ptr %t756
  %t759 = icmp eq i64 %t757, 11
  store i1 %t759, ptr %l212, !tbaa !21
  br label %bb98
bb98:
  %t760 = load i1, ptr %l212, !tbaa !21
  br i1 %t760, label %bb99, label %bb100
bb99:
  %t761 = load ptr, ptr %l1, !tbaa !29
  %t763 = getelementptr { i64, [5 x i64] }, ptr %t761, i32 0, i32 1
  %t764 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t763, i32 0, i32 2
  %t765 = load ptr, ptr %t764
  store ptr %t765, ptr %l18, !tbaa !29
  br label %bb101
bb100:
  br label %bb105
bb101:
  store %olang.scope zeroinitializer, ptr %s29
  %t767 = load ptr, ptr %l0, !tbaa !29
  %t768 = load ptr, ptr %l18, !tbaa !29
  %t770 = getelementptr %"compiler/typed:Cond", ptr %t768, i32 0, i32 0
  %t771 = load ptr, ptr %t770, !tbaa !29
  %t774 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %t767, ptr %t771)
  store { i64, ptr } %t774, ptr %l220
  br label %bb102
bb102:
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t776 = load ptr, ptr %l18, !tbaa !29
  %t778 = getelementptr %"compiler/typed:Cond", ptr %t776, i32 0, i32 1
  %t779 = load ptr, ptr %t778, !tbaa !29
  %t782 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %t775, ptr %t779)
  store { i64, ptr } %t782, ptr %l224
  br label %bb103
bb103:
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load ptr, ptr %l18, !tbaa !29
  %t786 = getelementptr %"compiler/typed:Cond", ptr %t784, i32 0, i32 2
  %t787 = load ptr, ptr %t786, !tbaa !29
  %t790 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %t783, ptr %t787)
  store { i64, ptr } %t790, ptr %l228
  br label %bb104
bb104:
  %t791 = extractvalue { i64, ptr } { i64 6, ptr @.d57 }, 1
  %t792 = extractvalue { i64, ptr } { i64 6, ptr @.d57 }, 0
  %t793 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t794 = extractvalue { i64, ptr } %t793, 1
  %t795 = extractvalue { i64, ptr } %t793, 0
  %t796 = add i64 %t792, %t795
  %t797 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 1
  %t798 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 0
  %t799 = add i64 %t796, %t798
  %t800 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t801 = extractvalue { i64, ptr } %t800, 1
  %t802 = extractvalue { i64, ptr } %t800, 0
  %t803 = add i64 %t799, %t802
  %t804 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 1
  %t805 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 0
  %t806 = add i64 %t803, %t805
  %t807 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t808 = extractvalue { i64, ptr } %t807, 1
  %t809 = extractvalue { i64, ptr } %t807, 0
  %t810 = add i64 %t806, %t809
  %t811 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 1
  %t812 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 0
  %t813 = add i64 %t810, %t812
  %t814 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t813)
  call void @olang_textcopy(ptr %t814, ptr %t791, i64 %t792)
  %t815 = getelementptr i8, ptr %t814, i64 %t792
  call void @olang_textcopy(ptr %t815, ptr %t794, i64 %t795)
  %t816 = getelementptr i8, ptr %t815, i64 %t795
  call void @olang_textcopy(ptr %t816, ptr %t797, i64 %t798)
  %t817 = getelementptr i8, ptr %t816, i64 %t798
  call void @olang_textcopy(ptr %t817, ptr %t801, i64 %t802)
  %t818 = getelementptr i8, ptr %t817, i64 %t802
  call void @olang_textcopy(ptr %t818, ptr %t804, i64 %t805)
  %t819 = getelementptr i8, ptr %t818, i64 %t805
  call void @olang_textcopy(ptr %t819, ptr %t808, i64 %t809)
  %t820 = getelementptr i8, ptr %t819, i64 %t809
  call void @olang_textcopy(ptr %t820, ptr %t811, i64 %t812)
  %t821 = insertvalue { i64, ptr } undef, i64 %t813, 0
  %t822 = insertvalue { i64, ptr } %t821, ptr %t814, 1
  store { i64, ptr } %t822, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s29)
  br label %bb145
bb105:
  %t824 = load ptr, ptr %l1, !tbaa !29
  store ptr %t824, ptr %l230, !tbaa !29
  store i1 false, ptr %l231, !tbaa !21
  %t825 = load ptr, ptr %l230, !tbaa !29
  %t826 = icmp ne ptr %t825, null
  br i1 %t826, label %bb106, label %bb107
bb106:
  %t828 = load ptr, ptr %l230, !tbaa !29
  %t829 = load i64, ptr %t828
  %t831 = icmp eq i64 %t829, 12
  store i1 %t831, ptr %l231, !tbaa !21
  br label %bb107
bb107:
  %t832 = load i1, ptr %l231, !tbaa !21
  br i1 %t832, label %bb108, label %bb109
bb108:
  %t833 = load ptr, ptr %l1, !tbaa !29
  %t835 = getelementptr { i64, [5 x i64] }, ptr %t833, i32 0, i32 1
  %t836 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t835, i32 0, i32 2
  %t837 = load ptr, ptr %t836
  store ptr %t837, ptr %l19, !tbaa !29
  br label %bb110
bb109:
  br label %bb112
bb110:
  store %olang.scope zeroinitializer, ptr %s31
  %t839 = load ptr, ptr %l19, !tbaa !29
  %t841 = getelementptr %"compiler/typed:Seq", ptr %t839, i32 0, i32 0
  %t842 = load { i64, ptr }, ptr %t841, !tbaa !27
  %t844 = extractvalue { i64, ptr } %t842, 0
  store i64 %t844, ptr %l238, !tbaa !24
  %t845 = load ptr, ptr %l0, !tbaa !29
  %t846 = load ptr, ptr %l19, !tbaa !29
  %t848 = getelementptr %"compiler/typed:Seq", ptr %t846, i32 0, i32 1
  %t849 = load ptr, ptr %t848, !tbaa !29
  %t852 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s31, ptr %t845, ptr %t849)
  store { i64, ptr } %t852, ptr %l242
  br label %bb111
bb111:
  %t853 = extractvalue { i64, ptr } { i64 5, ptr @.d61 }, 1
  %t854 = extractvalue { i64, ptr } { i64 5, ptr @.d61 }, 0
  %t855 = load i64, ptr %l238, !tbaa !24
  %t856 = call i64 @__olang_fmt_i64(ptr null, i64 %t855)
  %t857 = add i64 %t854, %t856
  %t858 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 1
  %t859 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 0
  %t860 = add i64 %t857, %t859
  %t861 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t862 = extractvalue { i64, ptr } %t861, 1
  %t863 = extractvalue { i64, ptr } %t861, 0
  %t864 = add i64 %t860, %t863
  %t865 = extractvalue { i64, ptr } { i64 1, ptr @.d63 }, 1
  %t866 = extractvalue { i64, ptr } { i64 1, ptr @.d63 }, 0
  %t867 = add i64 %t864, %t866
  %t868 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t867)
  call void @olang_textcopy(ptr %t868, ptr %t853, i64 %t854)
  %t869 = getelementptr i8, ptr %t868, i64 %t854
  %t870 = call i64 @__olang_fmt_i64(ptr %t869, i64 %t855)
  %t871 = getelementptr i8, ptr %t869, i64 %t856
  call void @olang_textcopy(ptr %t871, ptr %t858, i64 %t859)
  %t872 = getelementptr i8, ptr %t871, i64 %t859
  call void @olang_textcopy(ptr %t872, ptr %t862, i64 %t863)
  %t873 = getelementptr i8, ptr %t872, i64 %t863
  call void @olang_textcopy(ptr %t873, ptr %t865, i64 %t866)
  %t874 = insertvalue { i64, ptr } undef, i64 %t867, 0
  %t875 = insertvalue { i64, ptr } %t874, ptr %t868, 1
  store { i64, ptr } %t875, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s31)
  br label %bb145
bb112:
  %t877 = load ptr, ptr %l1, !tbaa !29
  store ptr %t877, ptr %l244, !tbaa !29
  store i1 false, ptr %l245, !tbaa !21
  %t878 = load ptr, ptr %l244, !tbaa !29
  %t879 = icmp ne ptr %t878, null
  br i1 %t879, label %bb113, label %bb114
bb113:
  %t881 = load ptr, ptr %l244, !tbaa !29
  %t882 = load i64, ptr %t881
  %t884 = icmp eq i64 %t882, 13
  store i1 %t884, ptr %l245, !tbaa !21
  br label %bb114
bb114:
  %t885 = load i1, ptr %l245, !tbaa !21
  br i1 %t885, label %bb115, label %bb116
bb115:
  %t886 = load ptr, ptr %l1, !tbaa !29
  %t888 = getelementptr { i64, [5 x i64] }, ptr %t886, i32 0, i32 1
  %t889 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t888, i32 0, i32 2
  %t890 = load ptr, ptr %t889
  store ptr %t890, ptr %l20, !tbaa !29
  br label %bb117
bb116:
  br label %bb118
bb117:
  %t892 = load ptr, ptr %l20, !tbaa !29
  %t894 = getelementptr %"compiler/typed:Match", ptr %t892, i32 0, i32 1
  %t895 = load { i64, ptr }, ptr %t894, !tbaa !27
  %t897 = extractvalue { i64, ptr } %t895, 0
  %t898 = load ptr, ptr %l20, !tbaa !29
  %t900 = getelementptr %"compiler/typed:Match", ptr %t898, i32 0, i32 2
  %t901 = load ptr, ptr %t900, !tbaa !29
  %t903 = getelementptr %"compiler/typed:Arm", ptr %t901, i32 0, i32 3
  %t904 = load ptr, ptr %t903, !tbaa !29
  %t906 = getelementptr %"compiler/typed:Block", ptr %t904, i32 0, i32 1
  %t907 = load { i64, ptr }, ptr %t906, !tbaa !27
  %t909 = extractvalue { i64, ptr } %t907, 0
  %t910 = extractvalue { i64, ptr } { i64 7, ptr @.d64 }, 1
  %t911 = extractvalue { i64, ptr } { i64 7, ptr @.d64 }, 0
  %t913 = call i64 @__olang_fmt_i64(ptr null, i64 %t897)
  %t914 = add i64 %t911, %t913
  %t915 = extractvalue { i64, ptr } { i64 15, ptr @.d65 }, 1
  %t916 = extractvalue { i64, ptr } { i64 15, ptr @.d65 }, 0
  %t917 = add i64 %t914, %t916
  %t919 = call i64 @__olang_fmt_i64(ptr null, i64 %t909)
  %t920 = add i64 %t917, %t919
  %t921 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 1
  %t922 = extractvalue { i64, ptr } { i64 1, ptr @.d66 }, 0
  %t923 = add i64 %t920, %t922
  %t924 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t923)
  call void @olang_textcopy(ptr %t924, ptr %t910, i64 %t911)
  %t925 = getelementptr i8, ptr %t924, i64 %t911
  %t926 = call i64 @__olang_fmt_i64(ptr %t925, i64 %t897)
  %t927 = getelementptr i8, ptr %t925, i64 %t913
  call void @olang_textcopy(ptr %t927, ptr %t915, i64 %t916)
  %t928 = getelementptr i8, ptr %t927, i64 %t916
  %t929 = call i64 @__olang_fmt_i64(ptr %t928, i64 %t909)
  %t930 = getelementptr i8, ptr %t928, i64 %t919
  call void @olang_textcopy(ptr %t930, ptr %t921, i64 %t922)
  %t931 = insertvalue { i64, ptr } undef, i64 %t923, 0
  %t932 = insertvalue { i64, ptr } %t931, ptr %t924, 1
  store { i64, ptr } %t932, ptr %l37, !tbaa !27
  br label %bb145
bb118:
  %t934 = load ptr, ptr %l1, !tbaa !29
  store ptr %t934, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t935 = load ptr, ptr %l259, !tbaa !29
  %t936 = icmp ne ptr %t935, null
  br i1 %t936, label %bb119, label %bb120
bb119:
  %t938 = load ptr, ptr %l259, !tbaa !29
  %t939 = load i64, ptr %t938
  %t941 = icmp eq i64 %t939, 14
  store i1 %t941, ptr %l260, !tbaa !21
  br label %bb120
bb120:
  %t942 = load i1, ptr %l260, !tbaa !21
  br i1 %t942, label %bb121, label %bb122
bb121:
  %t943 = load ptr, ptr %l1, !tbaa !29
  %t945 = getelementptr { i64, [5 x i64] }, ptr %t943, i32 0, i32 1
  %t946 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t945, i32 0, i32 2
  %t947 = load ptr, ptr %t946
  store ptr %t947, ptr %l21, !tbaa !29
  br label %bb123
bb122:
  br label %bb125
bb123:
  store %olang.scope zeroinitializer, ptr %s35
  %t949 = load ptr, ptr %l0, !tbaa !29
  %t950 = load ptr, ptr %l21, !tbaa !29
  %t952 = getelementptr %"compiler/typed:Try", ptr %t950, i32 0, i32 0
  %t953 = load ptr, ptr %t952, !tbaa !29
  %t956 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s35, ptr %t949, ptr %t953)
  store { i64, ptr } %t956, ptr %l268
  br label %bb124
bb124:
  %t957 = load ptr, ptr %l21, !tbaa !29
  %t959 = getelementptr %"compiler/typed:Try", ptr %t957, i32 0, i32 1
  %t960 = load { i64, ptr }, ptr %t959, !tbaa !27
  %t962 = extractvalue { i64, ptr } %t960, 0
  %t963 = extractvalue { i64, ptr } { i64 5, ptr @.d67 }, 1
  %t964 = extractvalue { i64, ptr } { i64 5, ptr @.d67 }, 0
  %t965 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t966 = extractvalue { i64, ptr } %t965, 1
  %t967 = extractvalue { i64, ptr } %t965, 0
  %t968 = add i64 %t964, %t967
  %t969 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 1
  %t970 = extractvalue { i64, ptr } { i64 1, ptr @.d68 }, 0
  %t971 = add i64 %t968, %t970
  %t973 = call i64 @__olang_fmt_i64(ptr null, i64 %t962)
  %t974 = add i64 %t971, %t973
  %t975 = extractvalue { i64, ptr } { i64 9, ptr @.d69 }, 1
  %t976 = extractvalue { i64, ptr } { i64 9, ptr @.d69 }, 0
  %t977 = add i64 %t974, %t976
  %t978 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t977)
  call void @olang_textcopy(ptr %t978, ptr %t963, i64 %t964)
  %t979 = getelementptr i8, ptr %t978, i64 %t964
  call void @olang_textcopy(ptr %t979, ptr %t966, i64 %t967)
  %t980 = getelementptr i8, ptr %t979, i64 %t967
  call void @olang_textcopy(ptr %t980, ptr %t969, i64 %t970)
  %t981 = getelementptr i8, ptr %t980, i64 %t970
  %t982 = call i64 @__olang_fmt_i64(ptr %t981, i64 %t962)
  %t983 = getelementptr i8, ptr %t981, i64 %t973
  call void @olang_textcopy(ptr %t983, ptr %t975, i64 %t976)
  %t984 = insertvalue { i64, ptr } undef, i64 %t977, 0
  %t985 = insertvalue { i64, ptr } %t984, ptr %t978, 1
  store { i64, ptr } %t985, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s35)
  br label %bb145
bb125:
  %t987 = load ptr, ptr %l1, !tbaa !29
  store ptr %t987, ptr %l273, !tbaa !29
  store i1 false, ptr %l274, !tbaa !21
  %t988 = load ptr, ptr %l273, !tbaa !29
  %t989 = icmp ne ptr %t988, null
  br i1 %t989, label %bb126, label %bb127
bb126:
  %t991 = load ptr, ptr %l273, !tbaa !29
  %t992 = load i64, ptr %t991
  %t994 = icmp eq i64 %t992, 15
  store i1 %t994, ptr %l274, !tbaa !21
  br label %bb127
bb127:
  %t995 = load i1, ptr %l274, !tbaa !21
  br i1 %t995, label %bb128, label %bb129
bb128:
  %t996 = load ptr, ptr %l1, !tbaa !29
  %t998 = getelementptr { i64, [5 x i64] }, ptr %t996, i32 0, i32 1
  %t999 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t998, i32 0, i32 2
  %t1000 = load ptr, ptr %t999
  store ptr %t1000, ptr %l22, !tbaa !29
  br label %bb130
bb129:
  br label %bb131
bb130:
  %t1002 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1003 = extractvalue { i64, ptr } { i64 4, ptr @.d70 }, 1
  %t1004 = extractvalue { i64, ptr } { i64 4, ptr @.d70 }, 0
  %t1006 = extractvalue { i64, ptr } %t1002, 1
  %t1007 = extractvalue { i64, ptr } %t1002, 0
  %t1008 = add i64 %t1004, %t1007
  %t1009 = extractvalue { i64, ptr } { i64 1, ptr @.d71 }, 1
  %t1010 = extractvalue { i64, ptr } { i64 1, ptr @.d71 }, 0
  %t1011 = add i64 %t1008, %t1010
  %t1012 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1011)
  call void @olang_textcopy(ptr %t1012, ptr %t1003, i64 %t1004)
  %t1013 = getelementptr i8, ptr %t1012, i64 %t1004
  call void @olang_textcopy(ptr %t1013, ptr %t1006, i64 %t1007)
  %t1014 = getelementptr i8, ptr %t1013, i64 %t1007
  call void @olang_textcopy(ptr %t1014, ptr %t1009, i64 %t1010)
  %t1015 = insertvalue { i64, ptr } undef, i64 %t1011, 0
  %t1016 = insertvalue { i64, ptr } %t1015, ptr %t1012, 1
  store { i64, ptr } %t1016, ptr %l37, !tbaa !27
  br label %bb145
bb131:
  %t1018 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1018, ptr %l281, !tbaa !29
  store i1 false, ptr %l282, !tbaa !21
  %t1019 = load ptr, ptr %l281, !tbaa !29
  %t1020 = icmp ne ptr %t1019, null
  br i1 %t1020, label %bb132, label %bb133
bb132:
  %t1022 = load ptr, ptr %l281, !tbaa !29
  %t1023 = load i64, ptr %t1022
  %t1025 = icmp eq i64 %t1023, 16
  store i1 %t1025, ptr %l282, !tbaa !21
  br label %bb133
bb133:
  %t1026 = load i1, ptr %l282, !tbaa !21
  br i1 %t1026, label %bb134, label %bb135
bb134:
  %t1027 = load ptr, ptr %l1, !tbaa !29
  %t1029 = getelementptr { i64, [5 x i64] }, ptr %t1027, i32 0, i32 1
  %t1030 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1029, i32 0, i32 2
  %t1031 = load ptr, ptr %t1030
  store ptr %t1031, ptr %l23, !tbaa !29
  br label %bb136
bb135:
  br label %bb137
bb136:
  %t1033 = load ptr, ptr %l23, !tbaa !29
  %t1035 = getelementptr %"compiler/typed:Text", ptr %t1033, i32 0, i32 0
  %t1036 = load { i64, ptr }, ptr %t1035, !tbaa !27
  %t1038 = extractvalue { i64, ptr } %t1036, 0
  %t1039 = load ptr, ptr %l23, !tbaa !29
  %t1041 = getelementptr %"compiler/typed:Text", ptr %t1039, i32 0, i32 1
  %t1042 = load i32, ptr %t1041, !tbaa !23
  %t1043 = extractvalue { i64, ptr } { i64 6, ptr @.d72 }, 1
  %t1044 = extractvalue { i64, ptr } { i64 6, ptr @.d72 }, 0
  %t1046 = call i64 @__olang_fmt_i64(ptr null, i64 %t1038)
  %t1047 = add i64 %t1044, %t1046
  %t1048 = extractvalue { i64, ptr } { i64 6, ptr @.d73 }, 1
  %t1049 = extractvalue { i64, ptr } { i64 6, ptr @.d73 }, 0
  %t1050 = add i64 %t1047, %t1049
  %t1052 = sext i32 %t1042 to i64
  %t1053 = call i64 @__olang_fmt_i64(ptr null, i64 %t1052)
  %t1054 = add i64 %t1050, %t1053
  %t1055 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 1
  %t1056 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 0
  %t1057 = add i64 %t1054, %t1056
  %t1058 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1057)
  call void @olang_textcopy(ptr %t1058, ptr %t1043, i64 %t1044)
  %t1059 = getelementptr i8, ptr %t1058, i64 %t1044
  %t1060 = call i64 @__olang_fmt_i64(ptr %t1059, i64 %t1038)
  %t1061 = getelementptr i8, ptr %t1059, i64 %t1046
  call void @olang_textcopy(ptr %t1061, ptr %t1048, i64 %t1049)
  %t1062 = getelementptr i8, ptr %t1061, i64 %t1049
  %t1063 = call i64 @__olang_fmt_i64(ptr %t1062, i64 %t1052)
  %t1064 = getelementptr i8, ptr %t1062, i64 %t1053
  call void @olang_textcopy(ptr %t1064, ptr %t1055, i64 %t1056)
  %t1065 = insertvalue { i64, ptr } undef, i64 %t1057, 0
  %t1066 = insertvalue { i64, ptr } %t1065, ptr %t1058, 1
  store { i64, ptr } %t1066, ptr %l37, !tbaa !27
  br label %bb145
bb137:
  %t1068 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1068, ptr %l293, !tbaa !29
  store i1 false, ptr %l294, !tbaa !21
  %t1069 = load ptr, ptr %l293, !tbaa !29
  %t1070 = icmp ne ptr %t1069, null
  br i1 %t1070, label %bb138, label %bb139
bb138:
  %t1072 = load ptr, ptr %l293, !tbaa !29
  %t1073 = load i64, ptr %t1072
  %t1075 = icmp eq i64 %t1073, 17
  store i1 %t1075, ptr %l294, !tbaa !21
  br label %bb139
bb139:
  %t1076 = load i1, ptr %l294, !tbaa !21
  br i1 %t1076, label %bb140, label %bb141
bb140:
  %t1077 = load ptr, ptr %l1, !tbaa !29
  %t1079 = getelementptr { i64, [5 x i64] }, ptr %t1077, i32 0, i32 1
  %t1080 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1079, i32 0, i32 1
  %t1081 = load i64, ptr %t1080
  store i64 %t1081, ptr %l24, !tbaa !24
  %t1083 = load ptr, ptr %l1, !tbaa !29
  %t1085 = getelementptr { i64, [5 x i64] }, ptr %t1083, i32 0, i32 1
  %t1086 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1085, i32 0, i32 2
  %t1087 = load ptr, ptr %t1086
  store ptr %t1087, ptr %l25, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  store %olang.scope zeroinitializer, ptr %s41
  %t1089 = load i64, ptr %l24, !tbaa !24
  store i64 %t1089, ptr %l301, !tbaa !24
  %t1090 = load ptr, ptr %l0, !tbaa !29
  %t1091 = load ptr, ptr %l25, !tbaa !29
  %t1094 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s41, ptr %t1090, ptr %t1091)
  store { i64, ptr } %t1094, ptr %l304
  br label %bb143
bb143:
  %t1095 = extractvalue { i64, ptr } { i64 6, ptr @.d75 }, 1
  %t1096 = extractvalue { i64, ptr } { i64 6, ptr @.d75 }, 0
  %t1097 = load i64, ptr %l301, !tbaa !24
  %t1098 = call i64 @__olang_fmt_i64(ptr null, i64 %t1097)
  %t1099 = add i64 %t1096, %t1098
  %t1100 = extractvalue { i64, ptr } { i64 1, ptr @.d76 }, 1
  %t1101 = extractvalue { i64, ptr } { i64 1, ptr @.d76 }, 0
  %t1102 = add i64 %t1099, %t1101
  %t1103 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t1104 = extractvalue { i64, ptr } %t1103, 1
  %t1105 = extractvalue { i64, ptr } %t1103, 0
  %t1106 = add i64 %t1102, %t1105
  %t1107 = extractvalue { i64, ptr } { i64 1, ptr @.d77 }, 1
  %t1108 = extractvalue { i64, ptr } { i64 1, ptr @.d77 }, 0
  %t1109 = add i64 %t1106, %t1108
  %t1110 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1109)
  call void @olang_textcopy(ptr %t1110, ptr %t1095, i64 %t1096)
  %t1111 = getelementptr i8, ptr %t1110, i64 %t1096
  %t1112 = call i64 @__olang_fmt_i64(ptr %t1111, i64 %t1097)
  %t1113 = getelementptr i8, ptr %t1111, i64 %t1098
  call void @olang_textcopy(ptr %t1113, ptr %t1100, i64 %t1101)
  %t1114 = getelementptr i8, ptr %t1113, i64 %t1101
  call void @olang_textcopy(ptr %t1114, ptr %t1104, i64 %t1105)
  %t1115 = getelementptr i8, ptr %t1114, i64 %t1105
  call void @olang_textcopy(ptr %t1115, ptr %t1107, i64 %t1108)
  %t1116 = insertvalue { i64, ptr } undef, i64 %t1109, 0
  %t1117 = insertvalue { i64, ptr } %t1116, ptr %t1110, 1
  store { i64, ptr } %t1117, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s41)
  br label %bb145
bb144:
  call void @__olang_check_failed(ptr @.c78)
  unreachable
bb145:
  call void @__olang_scope_close(ptr %s0)
  %t1119 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t1119, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 32)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  store ptr %l2, ptr %l39, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t59, ptr %l41, !tbaa !27
  %t60 = load i64, ptr %l8, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t68 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %a0, ptr %t65)
  store { i64, ptr } %t68, ptr %l44
  br label %bb16
bb16:
  %t69 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t76, { i64, ptr } %t75)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l7, !tbaa !24
  br label %bb8
bb19:
  %t83 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t83, ptr %l49
  br label %bb20
bb20:
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l51, !tbaa !24
  %t87 = load i64, ptr %l51, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l52, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t98, ptr %l50, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t99 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t99, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:printer", ptr %t49, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t51, { i64, ptr } { i64 2, ptr @.d79 })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb7
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:printer", ptr %t57, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t59, { i64, ptr } %a2)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:printer", ptr %t63, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t65, i8 10)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca i1
  %l79 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca i1
  %l93 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l97 = alloca i1
  %l100 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d80 }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr @.d80 }, 0
  %t20 = sext i32 %t16 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  br label %bb55
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t46, i32 0, i32 3
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i32, ptr %l4, !tbaa !23
  %t52 = extractvalue { i64, ptr } { i64 1, ptr @.d81 }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr @.d81 }, 0
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t50)
  %t56 = add i64 %t53, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 0
  %t59 = add i64 %t56, %t58
  %t61 = sext i32 %t51 to i64
  %t62 = call i64 @__olang_fmt_i64(ptr null, i64 %t61)
  %t63 = add i64 %t59, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t52, i64 %t53)
  %t65 = getelementptr i8, ptr %t64, i64 %t53
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t50)
  %t67 = getelementptr i8, ptr %t65, i64 %t55
  call void @olang_textcopy(ptr %t67, ptr %t57, i64 %t58)
  %t68 = getelementptr i8, ptr %t67, i64 %t58
  %t69 = call i64 @__olang_fmt_i64(ptr %t68, i64 %t61)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  store { i64, ptr } %t71, ptr %l12, !tbaa !27
  br label %bb55
bb12:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t74 = load ptr, ptr %l32, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb13, label %bb14
bb13:
  %t77 = load ptr, ptr %l32, !tbaa !29
  %t78 = load i64, ptr %t77
  %t80 = icmp eq i64 %t78, 2
  store i1 %t80, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t81 = load i1, ptr %l33, !tbaa !21
  br i1 %t81, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t92 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t88, ptr %t89)
  store { i64, ptr } %t92, ptr %l40
  br label %bb18
bb18:
  %t93 = extractvalue { i64, ptr } { i64 1, ptr @.d83 }, 1
  %t94 = extractvalue { i64, ptr } { i64 1, ptr @.d83 }, 0
  %t95 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = add i64 %t94, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t93, i64 %t94)
  %t100 = getelementptr i8, ptr %t99, i64 %t94
  call void @olang_textcopy(ptr %t100, ptr %t96, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  store { i64, ptr } %t102, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb19:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t105 = load ptr, ptr %l42, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb20, label %bb21
bb20:
  %t108 = load ptr, ptr %l42, !tbaa !29
  %t109 = load i64, ptr %t108
  %t111 = icmp eq i64 %t109, 3
  store i1 %t111, ptr %l43, !tbaa !21
  br label %bb21
bb21:
  %t112 = load i1, ptr %l43, !tbaa !21
  br i1 %t112, label %bb22, label %bb23
bb22:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t115, i32 0, i32 2
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l6, !tbaa !29
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t121, i32 0, i32 3
  %t123 = load i64, ptr %t122
  store i64 %t123, ptr %l7, !tbaa !24
  br label %bb24
bb23:
  br label %bb26
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l6, !tbaa !29
  %t129 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s7, ptr %t125, ptr %t126)
  store { i64, ptr } %t129, ptr %l52
  br label %bb25
bb25:
  %t130 = load i64, ptr %l7, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = extractvalue { i64, ptr } { i64 1, ptr @.d84 }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr @.d84 }, 0
  %t136 = add i64 %t133, %t135
  %t138 = call i64 @__olang_fmt_i64(ptr null, i64 %t130)
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t132, i64 %t133)
  %t141 = getelementptr i8, ptr %t140, i64 %t133
  call void @olang_textcopy(ptr %t141, ptr %t134, i64 %t135)
  %t142 = getelementptr i8, ptr %t141, i64 %t135
  %t143 = call i64 @__olang_fmt_i64(ptr %t142, i64 %t130)
  %t144 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t140, 1
  store { i64, ptr } %t145, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb26:
  %t147 = load ptr, ptr %l1, !tbaa !29
  store ptr %t147, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t148 = load ptr, ptr %l55, !tbaa !29
  %t149 = icmp ne ptr %t148, null
  br i1 %t149, label %bb27, label %bb28
bb27:
  %t151 = load ptr, ptr %l55, !tbaa !29
  %t152 = load i64, ptr %t151
  %t154 = icmp eq i64 %t152, 4
  store i1 %t154, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t155 = load i1, ptr %l56, !tbaa !21
  br i1 %t155, label %bb29, label %bb30
bb29:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr { i64, [4 x i64] }, ptr %t156, i32 0, i32 1
  %t159 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t158, i32 0, i32 2
  %t160 = load ptr, ptr %t159
  store ptr %t160, ptr %l8, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l8, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Elem", ptr %t163, i32 0, i32 0
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t169 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s9, ptr %t162, ptr %t166)
  store { i64, ptr } %t169, ptr %l64
  br label %bb32
bb32:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l8, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Elem", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t177 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %t170, ptr %t174)
  store { i64, ptr } %t177, ptr %l68
  br label %bb33
bb33:
  %t178 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } { i64 1, ptr @.d85 }, 1
  %t182 = extractvalue { i64, ptr } { i64 1, ptr @.d85 }, 0
  %t183 = add i64 %t180, %t182
  %t184 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = add i64 %t183, %t186
  %t188 = extractvalue { i64, ptr } { i64 1, ptr @.d86 }, 1
  %t189 = extractvalue { i64, ptr } { i64 1, ptr @.d86 }, 0
  %t190 = add i64 %t187, %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t179, i64 %t180)
  %t192 = getelementptr i8, ptr %t191, i64 %t180
  call void @olang_textcopy(ptr %t192, ptr %t181, i64 %t182)
  %t193 = getelementptr i8, ptr %t192, i64 %t182
  call void @olang_textcopy(ptr %t193, ptr %t185, i64 %t186)
  %t194 = getelementptr i8, ptr %t193, i64 %t186
  call void @olang_textcopy(ptr %t194, ptr %t188, i64 %t189)
  %t195 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t191, 1
  store { i64, ptr } %t196, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb34:
  %t198 = load ptr, ptr %l1, !tbaa !29
  store ptr %t198, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t199 = load ptr, ptr %l70, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb35, label %bb36
bb35:
  %t202 = load ptr, ptr %l70, !tbaa !29
  %t203 = load i64, ptr %t202
  %t205 = icmp eq i64 %t203, 5
  store i1 %t205, ptr %l71, !tbaa !21
  br label %bb36
bb36:
  %t206 = load i1, ptr %l71, !tbaa !21
  br i1 %t206, label %bb37, label %bb38
bb37:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t209, i32 0, i32 2
  %t211 = load ptr, ptr %t210
  store ptr %t211, ptr %l9, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l9, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Payload", ptr %t214, i32 0, i32 0
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t220 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s11, ptr %t213, ptr %t217)
  store { i64, ptr } %t220, ptr %l79
  br label %bb40
bb40:
  %t221 = load ptr, ptr %l9, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Payload", ptr %t221, i32 0, i32 1
  %t224 = load i64, ptr %t223, !tbaa !24
  %t225 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = extractvalue { i64, ptr } { i64 4, ptr @.d87 }, 1
  %t229 = extractvalue { i64, ptr } { i64 4, ptr @.d87 }, 0
  %t230 = add i64 %t227, %t229
  %t232 = call i64 @__olang_fmt_i64(ptr null, i64 %t224)
  %t233 = add i64 %t230, %t232
  %t234 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t233)
  call void @olang_textcopy(ptr %t234, ptr %t226, i64 %t227)
  %t235 = getelementptr i8, ptr %t234, i64 %t227
  call void @olang_textcopy(ptr %t235, ptr %t228, i64 %t229)
  %t236 = getelementptr i8, ptr %t235, i64 %t229
  %t237 = call i64 @__olang_fmt_i64(ptr %t236, i64 %t224)
  %t238 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t234, 1
  store { i64, ptr } %t239, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb41:
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t242 = load ptr, ptr %l83, !tbaa !29
  %t243 = icmp ne ptr %t242, null
  br i1 %t243, label %bb42, label %bb43
bb42:
  %t245 = load ptr, ptr %l83, !tbaa !29
  %t246 = load i64, ptr %t245
  %t248 = icmp eq i64 %t246, 6
  store i1 %t248, ptr %l84, !tbaa !21
  br label %bb43
bb43:
  %t249 = load i1, ptr %l84, !tbaa !21
  br i1 %t249, label %bb44, label %bb45
bb44:
  %t250 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr { i64, [4 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t252, i32 0, i32 2
  %t254 = load ptr, ptr %t253
  store ptr %t254, ptr %l10, !tbaa !29
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t258, i32 0, i32 3
  %t260 = load i32, ptr %t259
  store i32 %t260, ptr %l11, !tbaa !23
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l10, !tbaa !29
  %t266 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s13, ptr %t262, ptr %t263)
  store { i64, ptr } %t266, ptr %l93
  br label %bb47
bb47:
  %t267 = load i32, ptr %l11, !tbaa !23
  %t268 = extractvalue { i64, ptr } { i64 4, ptr @.d88 }, 1
  %t269 = extractvalue { i64, ptr } { i64 4, ptr @.d88 }, 0
  %t270 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t270, 1
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 6, ptr @.d89 }, 1
  %t275 = extractvalue { i64, ptr } { i64 6, ptr @.d89 }, 0
  %t276 = add i64 %t273, %t275
  %t278 = sext i32 %t267 to i64
  %t279 = call i64 @__olang_fmt_i64(ptr null, i64 %t278)
  %t280 = add i64 %t276, %t279
  %t281 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t280)
  call void @olang_textcopy(ptr %t281, ptr %t268, i64 %t269)
  %t282 = getelementptr i8, ptr %t281, i64 %t269
  call void @olang_textcopy(ptr %t282, ptr %t271, i64 %t272)
  %t283 = getelementptr i8, ptr %t282, i64 %t272
  call void @olang_textcopy(ptr %t283, ptr %t274, i64 %t275)
  %t284 = getelementptr i8, ptr %t283, i64 %t275
  %t285 = call i64 @__olang_fmt_i64(ptr %t284, i64 %t278)
  %t286 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t281, 1
  store { i64, ptr } %t287, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb55
bb48:
  %t289 = load ptr, ptr %l1, !tbaa !29
  store ptr %t289, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t290 = load ptr, ptr %l96, !tbaa !29
  %t291 = icmp ne ptr %t290, null
  br i1 %t291, label %bb49, label %bb50
bb49:
  %t293 = load ptr, ptr %l96, !tbaa !29
  %t294 = load i64, ptr %t293
  %t296 = icmp eq i64 %t294, 7
  store i1 %t296, ptr %l97, !tbaa !21
  br label %bb50
bb50:
  %t297 = load i1, ptr %l97, !tbaa !21
  br i1 %t297, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 6, ptr @.d90 }, ptr %l100, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t298, ptr %l12, !tbaa !27
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb55:
  %t300 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t300, 0
  store i64 %t301, ptr %l102, !tbaa !24
  %t302 = load i64, ptr %l102, !tbaa !24
  %t303 = mul i64 %t302, 1
  %t304 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t303)
  %t305 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  store { i64, ptr } %t306, ptr %l103, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = load i64, ptr %l102, !tbaa !24
  %t312 = mul i64 %t311, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t308, ptr %t310, i64 %t312, i1 false)
  %t313 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t313, ptr %l12, !tbaa !27
  %t314 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t314, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i32
  %l36 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i64
  %l51 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i64
  %l81 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i64
  %l131 = alloca i32
  %l133 = alloca i32
  %l135 = alloca i1
  %l136 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l141 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i64
  %l150 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l159 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i64
  %l171 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l176 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca i64
  %l183 = alloca i32
  %l185 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l191 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca i64
  %l200 = alloca { i64, ptr }
  %l203 = alloca ptr
  %l204 = alloca i1
  %l213 = alloca ptr
  %l214 = alloca i1
  %l225 = alloca ptr
  %l226 = alloca i1
  %l231 = alloca ptr
  %l232 = alloca i64
  %l235 = alloca { i64, ptr }
  %l243 = alloca ptr
  %l244 = alloca i1
  %l249 = alloca ptr
  %l250 = alloca i64
  %l254 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l260 = alloca i1
  %l265 = alloca ptr
  %l266 = alloca i64
  %l269 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.builder
  %s20room = alloca [64 x i8], align 8
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l31, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  store i64 %t23, ptr %l32, !tbaa !24
  %t24 = load i32, ptr %l3, !tbaa !23
  store i32 %t24, ptr %l33, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t29 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s1, ptr %t25, ptr %t26)
  store { i64, ptr } %t29, ptr %l36
  br label %bb6
bb6:
  %t30 = extractvalue { i64, ptr } { i64 5, ptr @.d92 }, 1
  %t31 = extractvalue { i64, ptr } { i64 5, ptr @.d92 }, 0
  %t32 = load i32, ptr %l33, !tbaa !23
  %t33 = sext i32 %t32 to i64
  %t34 = call i64 @__olang_fmt_i64(ptr null, i64 %t33)
  %t35 = add i64 %t31, %t34
  %t36 = extractvalue { i64, ptr } { i64 3, ptr @.d93 }, 1
  %t37 = extractvalue { i64, ptr } { i64 3, ptr @.d93 }, 0
  %t38 = add i64 %t35, %t37
  %t39 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = add i64 %t38, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t30, i64 %t31)
  %t44 = getelementptr i8, ptr %t43, i64 %t31
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t33)
  %t46 = getelementptr i8, ptr %t44, i64 %t34
  call void @olang_textcopy(ptr %t46, ptr %t36, i64 %t37)
  %t47 = getelementptr i8, ptr %t46, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t40, i64 %t41)
  %t48 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t43, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } %t49, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %l32, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s1, ptr %t57, i64 %t58, { i64, ptr } %t56)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb142
bb8:
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t61 = load ptr, ptr %l39, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load ptr, ptr %l39, !tbaa !29
  %t65 = load i64, ptr %t64
  %t67 = icmp eq i64 %t65, 1
  store i1 %t67, ptr %l40, !tbaa !21
  br label %bb10
bb10:
  %t68 = load i1, ptr %l40, !tbaa !21
  br i1 %t68, label %bb11, label %bb12
bb11:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [3 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t71, i32 0, i32 1
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l5, !tbaa !29
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [3 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l47, !tbaa !29
  %t82 = load i64, ptr %l2, !tbaa !24
  store i64 %t82, ptr %l48, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l5, !tbaa !29
  %t87 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s3, ptr %t83, ptr %t84)
  store { i64, ptr } %t87, ptr %l51
  br label %bb14
bb14:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l6, !tbaa !29
  %t92 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s3, ptr %t88, ptr %t89)
  store { i64, ptr } %t92, ptr %l54
  br label %bb15
bb15:
  %t93 = extractvalue { i64, ptr } { i64 7, ptr @.d94 }, 1
  %t94 = extractvalue { i64, ptr } { i64 7, ptr @.d94 }, 0
  %t95 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = add i64 %t94, %t97
  %t99 = extractvalue { i64, ptr } { i64 3, ptr @.d95 }, 1
  %t100 = extractvalue { i64, ptr } { i64 3, ptr @.d95 }, 0
  %t101 = add i64 %t98, %t100
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t105 = add i64 %t101, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t93, i64 %t94)
  %t107 = getelementptr i8, ptr %t106, i64 %t94
  call void @olang_textcopy(ptr %t107, ptr %t96, i64 %t97)
  %t108 = getelementptr i8, ptr %t107, i64 %t97
  call void @olang_textcopy(ptr %t108, ptr %t99, i64 %t100)
  %t109 = getelementptr i8, ptr %t108, i64 %t100
  call void @olang_textcopy(ptr %t109, ptr %t103, i64 %t104)
  %t110 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t106, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = extractvalue { i64, ptr } %t111, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t119 = load ptr, ptr %l47, !tbaa !29
  %t120 = load i64, ptr %l48, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s3, ptr %t119, i64 %t120, { i64, ptr } %t118)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb142
bb17:
  %t122 = load ptr, ptr %l1, !tbaa !29
  store ptr %t122, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t123 = load ptr, ptr %l57, !tbaa !29
  %t124 = icmp ne ptr %t123, null
  br i1 %t124, label %bb18, label %bb19
bb18:
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = load i64, ptr %t126
  %t129 = icmp eq i64 %t127, 2
  store i1 %t129, ptr %l58, !tbaa !21
  br label %bb19
bb19:
  %t130 = load i1, ptr %l58, !tbaa !21
  br i1 %t130, label %bb20, label %bb21
bb20:
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr { i64, [3 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", ptr }, ptr %t133, i32 0, i32 1
  %t135 = load ptr, ptr %t134
  store ptr %t135, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l63, !tbaa !29
  %t138 = load i64, ptr %l2, !tbaa !24
  store i64 %t138, ptr %l64, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l7, !tbaa !29
  %t143 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t139, ptr %t140)
  store { i64, ptr } %t143, ptr %l67
  br label %bb23
bb23:
  %t144 = extractvalue { i64, ptr } { i64 5, ptr @.d96 }, 1
  %t145 = extractvalue { i64, ptr } { i64 5, ptr @.d96 }, 0
  %t146 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = add i64 %t145, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t144, i64 %t145)
  %t151 = getelementptr i8, ptr %t150, i64 %t145
  call void @olang_textcopy(ptr %t151, ptr %t147, i64 %t148)
  %t152 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t150, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t161 = load ptr, ptr %l63, !tbaa !29
  %t162 = load i64, ptr %l64, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s5, ptr %t161, i64 %t162, { i64, ptr } %t160)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb142
bb25:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t165 = load ptr, ptr %l70, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb26, label %bb27
bb26:
  %t168 = load ptr, ptr %l70, !tbaa !29
  %t169 = load i64, ptr %t168
  %t171 = icmp eq i64 %t169, 3
  store i1 %t171, ptr %l71, !tbaa !21
  br label %bb27
bb27:
  %t172 = load i1, ptr %l71, !tbaa !21
  br i1 %t172, label %bb28, label %bb29
bb28:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l8, !tbaa !29
  br label %bb30
bb29:
  br label %bb39
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l76, !tbaa !29
  %t180 = load i64, ptr %l2, !tbaa !24
  store i64 %t180, ptr %l77, !tbaa !24
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load ptr, ptr %l8, !tbaa !29
  %t184 = getelementptr %"compiler/typed:If", ptr %t182, i32 0, i32 0
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t188 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %t181, ptr %t185)
  store { i64, ptr } %t188, ptr %l81
  br label %bb31
bb31:
  %t189 = extractvalue { i64, ptr } { i64 3, ptr @.d97 }, 1
  %t190 = extractvalue { i64, ptr } { i64 3, ptr @.d97 }, 0
  %t191 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = add i64 %t190, %t193
  %t195 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t189, i64 %t190)
  %t196 = getelementptr i8, ptr %t195, i64 %t190
  call void @olang_textcopy(ptr %t196, ptr %t192, i64 %t193)
  %t197 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t195, 1
  %t200 = extractvalue { i64, ptr } %t198, 0
  %t201 = extractvalue { i64, ptr } %t198, 1
  %t202 = mul i64 %t200, 1
  %t203 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t202)
  call void @llvm.memcpy.p0.p0.i64(ptr %t203, ptr %t201, i64 %t202, i1 false)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  %t206 = load ptr, ptr %l76, !tbaa !29
  %t207 = load i64, ptr %l77, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s7, ptr %t206, i64 %t207, { i64, ptr } %t205)
  br label %bb32
bb32:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %l8, !tbaa !29
  %t212 = getelementptr %"compiler/typed:If", ptr %t210, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t214 = load i64, ptr %l2, !tbaa !24
  %t216 = add i64 %t214, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t209, ptr %t213, i64 %t216)
  br label %bb33
bb33:
  %t220 = load ptr, ptr %l8, !tbaa !29
  %t222 = getelementptr %"compiler/typed:If", ptr %t220, i32 0, i32 2
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = icmp ne ptr %t223, null
  br i1 %t225, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s9, ptr %t227, i64 %t228, { i64, ptr } { i64 4, ptr @.d98 })
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l8, !tbaa !29
  %t234 = getelementptr %"compiler/typed:If", ptr %t232, i32 0, i32 2
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t236 = load i64, ptr %l2, !tbaa !24
  %t238 = add i64 %t236, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t231, ptr %t235, i64 %t238)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s9)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s7)
  br label %bb142
bb39:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t243 = load ptr, ptr %l99, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb40, label %bb41
bb40:
  %t246 = load ptr, ptr %l99, !tbaa !29
  %t247 = load i64, ptr %t246
  %t249 = icmp eq i64 %t247, 4
  store i1 %t249, ptr %l100, !tbaa !21
  br label %bb41
bb41:
  %t250 = load i1, ptr %l100, !tbaa !21
  br i1 %t250, label %bb42, label %bb43
bb42:
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [3 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l9, !tbaa !29
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr { i64, [3 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t259, i32 0, i32 2
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l10, !tbaa !29
  br label %bb44
bb43:
  br label %bb52
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s10, ptr %t263, i64 %t264, { i64, ptr } { i64 4, ptr @.d99 })
  br label %bb45
bb45:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load ptr, ptr %l9, !tbaa !29
  %t269 = load i64, ptr %l2, !tbaa !24
  %t271 = add i64 %t269, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t267, ptr %t268, i64 %t271)
  br label %bb46
bb46:
  %t275 = load ptr, ptr %l10, !tbaa !29
  %t277 = icmp ne ptr %t275, null
  br i1 %t277, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s11
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s11, ptr %t279, i64 %t280, { i64, ptr } { i64 4, ptr @.d100 })
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l10, !tbaa !29
  %t285 = load i64, ptr %l2, !tbaa !24
  %t287 = add i64 %t285, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t283, ptr %t284, i64 %t287)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s11)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s10)
  br label %bb142
bb52:
  %t291 = load ptr, ptr %l1, !tbaa !29
  store ptr %t291, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t292 = load ptr, ptr %l121, !tbaa !29
  %t293 = icmp ne ptr %t292, null
  br i1 %t293, label %bb53, label %bb54
bb53:
  %t295 = load ptr, ptr %l121, !tbaa !29
  %t296 = load i64, ptr %t295
  %t298 = icmp eq i64 %t296, 5
  store i1 %t298, ptr %l122, !tbaa !21
  br label %bb54
bb54:
  %t299 = load i1, ptr %l122, !tbaa !21
  br i1 %t299, label %bb55, label %bb56
bb55:
  %t300 = load ptr, ptr %l1, !tbaa !29
  %t302 = getelementptr { i64, [3 x i64] }, ptr %t300, i32 0, i32 1
  %t303 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t302, i32 0, i32 1
  %t304 = load i32, ptr %t303
  store i32 %t304, ptr %l11
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t308 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 1
  %t309 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t308, i32 0, i32 2
  %t310 = load i32, ptr %t309
  store i32 %t310, ptr %l12, !tbaa !23
  br label %bb57
bb56:
  br label %bb63
bb57:
  store %olang.scope zeroinitializer, ptr %s12
  %t312 = load ptr, ptr %l0, !tbaa !29
  store ptr %t312, ptr %l129, !tbaa !29
  %t313 = load i64, ptr %l2, !tbaa !24
  store i64 %t313, ptr %l130, !tbaa !24
  %t314 = load i32, ptr %l11
  store i32 %t314, ptr %l131
  store i32 0, ptr %l133
  %t317 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aJumpKind(ptr %l131, ptr %l133)
  store i1 %t317, ptr %l135
  br label %bb58
bb58:
  %t318 = load i1, ptr %l135, !tbaa !21
  br i1 %t318, label %bb59, label %bb60
bb59:
  store { i64, ptr } { i64 5, ptr @.d101 }, ptr %l136, !tbaa !27
  br label %bb61
bb60:
  store { i64, ptr } { i64 8, ptr @.d102 }, ptr %l136, !tbaa !27
  br label %bb61
bb61:
  %t319 = load i32, ptr %l12, !tbaa !23
  %t320 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } { i64 2, ptr @.d103 }, 1
  %t324 = extractvalue { i64, ptr } { i64 2, ptr @.d103 }, 0
  %t325 = add i64 %t322, %t324
  %t327 = sext i32 %t319 to i64
  %t328 = call i64 @__olang_fmt_i64(ptr null, i64 %t327)
  %t329 = add i64 %t325, %t328
  %t330 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t329)
  call void @olang_textcopy(ptr %t330, ptr %t321, i64 %t322)
  %t331 = getelementptr i8, ptr %t330, i64 %t322
  call void @olang_textcopy(ptr %t331, ptr %t323, i64 %t324)
  %t332 = getelementptr i8, ptr %t331, i64 %t324
  %t333 = call i64 @__olang_fmt_i64(ptr %t332, i64 %t327)
  %t334 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t330, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } %t335, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  %t343 = load ptr, ptr %l129, !tbaa !29
  %t344 = load i64, ptr %l130, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s12, ptr %t343, i64 %t344, { i64, ptr } %t342)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s12)
  br label %bb142
bb63:
  %t346 = load ptr, ptr %l1, !tbaa !29
  store ptr %t346, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t347 = load ptr, ptr %l140, !tbaa !29
  %t348 = icmp ne ptr %t347, null
  br i1 %t348, label %bb64, label %bb65
bb64:
  %t350 = load ptr, ptr %l140, !tbaa !29
  %t351 = load i64, ptr %t350
  %t353 = icmp eq i64 %t351, 6
  store i1 %t353, ptr %l141, !tbaa !21
  br label %bb65
bb65:
  %t354 = load i1, ptr %l141, !tbaa !21
  br i1 %t354, label %bb66, label %bb67
bb66:
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr { i64, [3 x i64] }, ptr %t355, i32 0, i32 1
  %t358 = getelementptr { %"compiler/source:Span", ptr }, ptr %t357, i32 0, i32 1
  %t359 = load ptr, ptr %t358
  store ptr %t359, ptr %l13, !tbaa !29
  br label %bb68
bb67:
  br label %bb74
bb68:
  store %olang.scope zeroinitializer, ptr %s14
  %t361 = load ptr, ptr %l0, !tbaa !29
  store ptr %t361, ptr %l146, !tbaa !29
  %t362 = load i64, ptr %l2, !tbaa !24
  store i64 %t362, ptr %l147, !tbaa !24
  %t363 = load ptr, ptr %l13, !tbaa !29
  %t365 = icmp ne ptr %t363, null
  br i1 %t365, label %bb69, label %bb70
bb69:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l13, !tbaa !29
  %t371 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s14, ptr %t367, ptr %t368)
  store { i64, ptr } %t371, ptr %l153
  br label %bb71
bb70:
  store { i64, ptr } { i64 0, ptr @.d104 }, ptr %l150, !tbaa !27
  br label %bb72
bb71:
  %t372 = extractvalue { i64, ptr } { i64 1, ptr @.d105 }, 1
  %t373 = extractvalue { i64, ptr } { i64 1, ptr @.d105 }, 0
  %t374 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = add i64 %t373, %t376
  %t378 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t377)
  call void @olang_textcopy(ptr %t378, ptr %t372, i64 %t373)
  %t379 = getelementptr i8, ptr %t378, i64 %t373
  call void @olang_textcopy(ptr %t379, ptr %t375, i64 %t376)
  %t380 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t378, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  %t384 = extractvalue { i64, ptr } %t381, 1
  %t385 = mul i64 %t383, 1
  %t386 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t385)
  call void @llvm.memcpy.p0.p0.i64(ptr %t386, ptr %t384, i64 %t385, i1 false)
  %t387 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t386, 1
  store { i64, ptr } %t388, ptr %l150, !tbaa !27
  br label %bb72
bb72:
  %t390 = extractvalue { i64, ptr } { i64 6, ptr @.d106 }, 1
  %t391 = extractvalue { i64, ptr } { i64 6, ptr @.d106 }, 0
  %t392 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = add i64 %t391, %t394
  %t396 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t395)
  call void @olang_textcopy(ptr %t396, ptr %t390, i64 %t391)
  %t397 = getelementptr i8, ptr %t396, i64 %t391
  call void @olang_textcopy(ptr %t397, ptr %t393, i64 %t394)
  %t398 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t396, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = extractvalue { i64, ptr } %t399, 1
  %t403 = mul i64 %t401, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t403)
  call void @llvm.memcpy.p0.p0.i64(ptr %t404, ptr %t402, i64 %t403, i1 false)
  %t405 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  %t407 = load ptr, ptr %l146, !tbaa !29
  %t408 = load i64, ptr %l147, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s14, ptr %t407, i64 %t408, { i64, ptr } %t406)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s14)
  br label %bb142
bb74:
  %t410 = load ptr, ptr %l1, !tbaa !29
  store ptr %t410, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t411 = load ptr, ptr %l158, !tbaa !29
  %t412 = icmp ne ptr %t411, null
  br i1 %t412, label %bb75, label %bb76
bb75:
  %t414 = load ptr, ptr %l158, !tbaa !29
  %t415 = load i64, ptr %t414
  %t417 = icmp eq i64 %t415, 7
  store i1 %t417, ptr %l159, !tbaa !21
  br label %bb76
bb76:
  %t418 = load i1, ptr %l159, !tbaa !21
  br i1 %t418, label %bb77, label %bb78
bb77:
  %t419 = load ptr, ptr %l1, !tbaa !29
  %t421 = getelementptr { i64, [3 x i64] }, ptr %t419, i32 0, i32 1
  %t422 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t421, i32 0, i32 1
  %t423 = load i32, ptr %t422
  store i32 %t423, ptr %l14, !tbaa !23
  %t425 = load ptr, ptr %l1, !tbaa !29
  %t427 = getelementptr { i64, [3 x i64] }, ptr %t425, i32 0, i32 1
  %t428 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t427, i32 0, i32 2
  %t429 = load i64, ptr %t428
  store i64 %t429, ptr %l15, !tbaa !24
  br label %bb79
bb78:
  br label %bb82
bb79:
  store %olang.scope zeroinitializer, ptr %s17
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l166, !tbaa !29
  %t432 = load i64, ptr %l2, !tbaa !24
  store i64 %t432, ptr %l167, !tbaa !24
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/typed:printer", ptr %t433, i32 0, i32 0
  %t436 = load ptr, ptr %t435, !tbaa !29
  %t437 = load i32, ptr %l14, !tbaa !23
  %t440 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s17, ptr %t436, i32 %t437)
  store { i64, ptr } %t440, ptr %l171
  br label %bb80
bb80:
  %t441 = load i64, ptr %l15, !tbaa !24
  %t442 = extractvalue { i64, ptr } { i64 6, ptr @.d107 }, 1
  %t443 = extractvalue { i64, ptr } { i64 6, ptr @.d107 }, 0
  %t444 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 1
  %t446 = extractvalue { i64, ptr } %t444, 0
  %t447 = add i64 %t443, %t446
  %t448 = extractvalue { i64, ptr } { i64 1, ptr @.d108 }, 1
  %t449 = extractvalue { i64, ptr } { i64 1, ptr @.d108 }, 0
  %t450 = add i64 %t447, %t449
  %t452 = call i64 @__olang_fmt_i64(ptr null, i64 %t441)
  %t453 = add i64 %t450, %t452
  %t454 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t453)
  call void @olang_textcopy(ptr %t454, ptr %t442, i64 %t443)
  %t455 = getelementptr i8, ptr %t454, i64 %t443
  call void @olang_textcopy(ptr %t455, ptr %t445, i64 %t446)
  %t456 = getelementptr i8, ptr %t455, i64 %t446
  call void @olang_textcopy(ptr %t456, ptr %t448, i64 %t449)
  %t457 = getelementptr i8, ptr %t456, i64 %t449
  %t458 = call i64 @__olang_fmt_i64(ptr %t457, i64 %t441)
  %t459 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t460 = insertvalue { i64, ptr } %t459, ptr %t454, 1
  %t462 = extractvalue { i64, ptr } %t460, 0
  %t463 = extractvalue { i64, ptr } %t460, 1
  %t464 = mul i64 %t462, 1
  %t465 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t464)
  call void @llvm.memcpy.p0.p0.i64(ptr %t465, ptr %t463, i64 %t464, i1 false)
  %t466 = insertvalue { i64, ptr } undef, i64 %t462, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t465, 1
  %t468 = load ptr, ptr %l166, !tbaa !29
  %t469 = load i64, ptr %l167, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s17, ptr %t468, i64 %t469, { i64, ptr } %t467)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s17)
  br label %bb142
bb82:
  %t471 = load ptr, ptr %l1, !tbaa !29
  store ptr %t471, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t472 = load ptr, ptr %l175, !tbaa !29
  %t473 = icmp ne ptr %t472, null
  br i1 %t473, label %bb83, label %bb84
bb83:
  %t475 = load ptr, ptr %l175, !tbaa !29
  %t476 = load i64, ptr %t475
  %t478 = icmp eq i64 %t476, 8
  store i1 %t478, ptr %l176, !tbaa !21
  br label %bb84
bb84:
  %t479 = load i1, ptr %l176, !tbaa !21
  br i1 %t479, label %bb85, label %bb86
bb85:
  %t480 = load ptr, ptr %l1, !tbaa !29
  %t482 = getelementptr { i64, [3 x i64] }, ptr %t480, i32 0, i32 1
  %t483 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t482, i32 0, i32 1
  %t484 = load i32, ptr %t483
  store i32 %t484, ptr %l16
  br label %bb87
bb86:
  br label %bb91
bb87:
  store %olang.scope zeroinitializer, ptr %s19
  %t486 = load ptr, ptr %l0, !tbaa !29
  store ptr %t486, ptr %l181, !tbaa !29
  %t487 = load i64, ptr %l2, !tbaa !24
  store i64 %t487, ptr %l182, !tbaa !24
  %t488 = load i32, ptr %l16
  store i32 %t488, ptr %l183
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s20
  store ptr %s20room, ptr %s20
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aExitKind(ptr %s20, ptr %l183, i64 0)
  br label %bb88
bb88:
  %t490 = load ptr, ptr %s20
  %t491 = getelementptr %olang.builder, ptr %s20, i32 0, i32 1
  %t492 = load i64, ptr %t491
  %t493 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t492)
  call void @olang_textcopy(ptr %t493, ptr %t490, i64 %t492)
  %t494 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t493, 1
  store { i64, ptr } %t495, ptr %l185, !tbaa !27
  %t496 = getelementptr %olang.builder, ptr %s20, i32 0, i32 3
  %t497 = load ptr, ptr %t496
  %t498 = icmp ne ptr %t497, null
  br i1 %t498, label %sbgrew.499, label %sbdone.500
sbgrew.499:
  call void @__olang_sb_done(ptr %s20)
  br label %sbdone.500
sbdone.500:
  %t501 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 0
  %t503 = extractvalue { i64, ptr } %t501, 1
  %t504 = mul i64 %t502, 1
  %t505 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t504)
  call void @llvm.memcpy.p0.p0.i64(ptr %t505, ptr %t503, i64 %t504, i1 false)
  %t506 = insertvalue { i64, ptr } undef, i64 %t502, 0
  %t507 = insertvalue { i64, ptr } %t506, ptr %t505, 1
  %t509 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s19, { i64, ptr } %t507)
  store { i64, ptr } %t509, ptr %l187
  br label %bb89
bb89:
  %t510 = extractvalue { i64, ptr } { i64 5, ptr @.d109 }, 1
  %t511 = extractvalue { i64, ptr } { i64 5, ptr @.d109 }, 0
  %t512 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t512, 1
  %t514 = extractvalue { i64, ptr } %t512, 0
  %t515 = add i64 %t511, %t514
  %t516 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t515)
  call void @olang_textcopy(ptr %t516, ptr %t510, i64 %t511)
  %t517 = getelementptr i8, ptr %t516, i64 %t511
  call void @olang_textcopy(ptr %t517, ptr %t513, i64 %t514)
  %t518 = insertvalue { i64, ptr } undef, i64 %t515, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t516, 1
  %t521 = extractvalue { i64, ptr } %t519, 0
  %t522 = extractvalue { i64, ptr } %t519, 1
  %t523 = mul i64 %t521, 1
  %t524 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t523)
  call void @llvm.memcpy.p0.p0.i64(ptr %t524, ptr %t522, i64 %t523, i1 false)
  %t525 = insertvalue { i64, ptr } undef, i64 %t521, 0
  %t526 = insertvalue { i64, ptr } %t525, ptr %t524, 1
  %t527 = load ptr, ptr %l181, !tbaa !29
  %t528 = load i64, ptr %l182, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s19, ptr %t527, i64 %t528, { i64, ptr } %t526)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s19)
  br label %bb142
bb91:
  %t530 = load ptr, ptr %l1, !tbaa !29
  store ptr %t530, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t531 = load ptr, ptr %l190, !tbaa !29
  %t532 = icmp ne ptr %t531, null
  br i1 %t532, label %bb92, label %bb93
bb92:
  %t534 = load ptr, ptr %l190, !tbaa !29
  %t535 = load i64, ptr %t534
  %t537 = icmp eq i64 %t535, 9
  store i1 %t537, ptr %l191, !tbaa !21
  br label %bb93
bb93:
  %t538 = load i1, ptr %l191, !tbaa !21
  br i1 %t538, label %bb94, label %bb95
bb94:
  %t539 = load ptr, ptr %l1, !tbaa !29
  %t541 = getelementptr { i64, [3 x i64] }, ptr %t539, i32 0, i32 1
  %t542 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t541, i32 0, i32 1
  %t543 = load ptr, ptr %t542
  store ptr %t543, ptr %l17, !tbaa !29
  br label %bb96
bb95:
  br label %bb99
bb96:
  store %olang.scope zeroinitializer, ptr %s22
  %t545 = load ptr, ptr %l0, !tbaa !29
  store ptr %t545, ptr %l196, !tbaa !29
  %t546 = load i64, ptr %l2, !tbaa !24
  store i64 %t546, ptr %l197, !tbaa !24
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load ptr, ptr %l17, !tbaa !29
  %t551 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s22, ptr %t547, ptr %t548)
  store { i64, ptr } %t551, ptr %l200
  br label %bb97
bb97:
  %t552 = extractvalue { i64, ptr } { i64 7, ptr @.d110 }, 1
  %t553 = extractvalue { i64, ptr } { i64 7, ptr @.d110 }, 0
  %t554 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t554, 1
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t557 = add i64 %t553, %t556
  %t558 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t557)
  call void @olang_textcopy(ptr %t558, ptr %t552, i64 %t553)
  %t559 = getelementptr i8, ptr %t558, i64 %t553
  call void @olang_textcopy(ptr %t559, ptr %t555, i64 %t556)
  %t560 = insertvalue { i64, ptr } undef, i64 %t557, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t558, 1
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t564 = extractvalue { i64, ptr } %t561, 1
  %t565 = mul i64 %t563, 1
  %t566 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t565)
  call void @llvm.memcpy.p0.p0.i64(ptr %t566, ptr %t564, i64 %t565, i1 false)
  %t567 = insertvalue { i64, ptr } undef, i64 %t563, 0
  %t568 = insertvalue { i64, ptr } %t567, ptr %t566, 1
  %t569 = load ptr, ptr %l196, !tbaa !29
  %t570 = load i64, ptr %l197, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s22, ptr %t569, i64 %t570, { i64, ptr } %t568)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s22)
  br label %bb142
bb99:
  %t572 = load ptr, ptr %l1, !tbaa !29
  store ptr %t572, ptr %l203, !tbaa !29
  store i1 false, ptr %l204, !tbaa !21
  %t573 = load ptr, ptr %l203, !tbaa !29
  %t574 = icmp ne ptr %t573, null
  br i1 %t574, label %bb100, label %bb101
bb100:
  %t576 = load ptr, ptr %l203, !tbaa !29
  %t577 = load i64, ptr %t576
  %t579 = icmp eq i64 %t577, 10
  store i1 %t579, ptr %l204, !tbaa !21
  br label %bb101
bb101:
  %t580 = load i1, ptr %l204, !tbaa !21
  br i1 %t580, label %bb102, label %bb103
bb102:
  %t581 = load ptr, ptr %l1, !tbaa !29
  %t583 = getelementptr { i64, [3 x i64] }, ptr %t581, i32 0, i32 1
  %t584 = getelementptr { %"compiler/source:Span", ptr }, ptr %t583, i32 0, i32 1
  %t585 = load ptr, ptr %t584
  store ptr %t585, ptr %l18, !tbaa !29
  br label %bb104
bb103:
  br label %bb106
bb104:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load ptr, ptr %l18, !tbaa !29
  %t589 = load i64, ptr %l2, !tbaa !24
  %t591 = add i64 %t589, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t587, ptr %t588, i64 %t591)
  br label %bb105
bb105:
  br label %bb142
bb106:
  %t595 = load ptr, ptr %l1, !tbaa !29
  store ptr %t595, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t596 = load ptr, ptr %l213, !tbaa !29
  %t597 = icmp ne ptr %t596, null
  br i1 %t597, label %bb107, label %bb108
bb107:
  %t599 = load ptr, ptr %l213, !tbaa !29
  %t600 = load i64, ptr %t599
  %t602 = icmp eq i64 %t600, 11
  store i1 %t602, ptr %l214, !tbaa !21
  br label %bb108
bb108:
  %t603 = load i1, ptr %l214, !tbaa !21
  br i1 %t603, label %bb109, label %bb110
bb109:
  %t604 = load ptr, ptr %l1, !tbaa !29
  %t606 = getelementptr { i64, [3 x i64] }, ptr %t604, i32 0, i32 1
  %t607 = getelementptr { %"compiler/source:Span", ptr }, ptr %t606, i32 0, i32 1
  %t608 = load ptr, ptr %t607
  store ptr %t608, ptr %l19, !tbaa !29
  br label %bb111
bb110:
  br label %bb114
bb111:
  store %olang.scope zeroinitializer, ptr %s25
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t611 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s25, ptr %t610, i64 %t611, { i64, ptr } { i64 5, ptr @.d111 })
  br label %bb112
bb112:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load ptr, ptr %l19, !tbaa !29
  %t616 = load i64, ptr %l2, !tbaa !24
  %t618 = add i64 %t616, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t614, ptr %t615, i64 %t618)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s25)
  br label %bb142
bb114:
  %t622 = load ptr, ptr %l1, !tbaa !29
  store ptr %t622, ptr %l225, !tbaa !29
  store i1 false, ptr %l226, !tbaa !21
  %t623 = load ptr, ptr %l225, !tbaa !29
  %t624 = icmp ne ptr %t623, null
  br i1 %t624, label %bb115, label %bb116
bb115:
  %t626 = load ptr, ptr %l225, !tbaa !29
  %t627 = load i64, ptr %t626
  %t629 = icmp eq i64 %t627, 12
  store i1 %t629, ptr %l226, !tbaa !21
  br label %bb116
bb116:
  %t630 = load i1, ptr %l226, !tbaa !21
  br i1 %t630, label %bb117, label %bb118
bb117:
  %t631 = load ptr, ptr %l1, !tbaa !29
  %t633 = getelementptr { i64, [3 x i64] }, ptr %t631, i32 0, i32 1
  %t634 = getelementptr { %"compiler/source:Span", ptr }, ptr %t633, i32 0, i32 1
  %t635 = load ptr, ptr %t634
  store ptr %t635, ptr %l20, !tbaa !29
  br label %bb119
bb118:
  br label %bb125
bb119:
  store %olang.scope zeroinitializer, ptr %s26
  %t637 = load ptr, ptr %l0, !tbaa !29
  store ptr %t637, ptr %l231, !tbaa !29
  %t638 = load i64, ptr %l2, !tbaa !24
  store i64 %t638, ptr %l232, !tbaa !24
  %t639 = load ptr, ptr %l20, !tbaa !29
  %t641 = getelementptr %"compiler/typed:Join", ptr %t639, i32 0, i32 1
  %t642 = load i1, ptr %t641, !tbaa !21
  br i1 %t642, label %bb120, label %bb121
bb120:
  store { i64, ptr } { i64 4, ptr @.d112 }, ptr %l235, !tbaa !27
  br label %bb122
bb121:
  store { i64, ptr } { i64 0, ptr @.d113 }, ptr %l235, !tbaa !27
  br label %bb122
bb122:
  %t644 = extractvalue { i64, ptr } { i64 4, ptr @.d114 }, 1
  %t645 = extractvalue { i64, ptr } { i64 4, ptr @.d114 }, 0
  %t646 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t647 = extractvalue { i64, ptr } %t646, 1
  %t648 = extractvalue { i64, ptr } %t646, 0
  %t649 = add i64 %t645, %t648
  %t650 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t649)
  call void @olang_textcopy(ptr %t650, ptr %t644, i64 %t645)
  %t651 = getelementptr i8, ptr %t650, i64 %t645
  call void @olang_textcopy(ptr %t651, ptr %t647, i64 %t648)
  %t652 = insertvalue { i64, ptr } undef, i64 %t649, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t650, 1
  %t655 = extractvalue { i64, ptr } %t653, 0
  %t656 = extractvalue { i64, ptr } %t653, 1
  %t657 = mul i64 %t655, 1
  %t658 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t657)
  call void @llvm.memcpy.p0.p0.i64(ptr %t658, ptr %t656, i64 %t657, i1 false)
  %t659 = insertvalue { i64, ptr } undef, i64 %t655, 0
  %t660 = insertvalue { i64, ptr } %t659, ptr %t658, 1
  %t661 = load ptr, ptr %l231, !tbaa !29
  %t662 = load i64, ptr %l232, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s26, ptr %t661, i64 %t662, { i64, ptr } %t660)
  br label %bb123
bb123:
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t665 = load ptr, ptr %l20, !tbaa !29
  %t667 = getelementptr %"compiler/typed:Join", ptr %t665, i32 0, i32 0
  %t668 = load ptr, ptr %t667, !tbaa !29
  %t669 = load i64, ptr %l2, !tbaa !24
  %t671 = add i64 %t669, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t664, ptr %t668, i64 %t671)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s26)
  br label %bb142
bb125:
  %t675 = load ptr, ptr %l1, !tbaa !29
  store ptr %t675, ptr %l243, !tbaa !29
  store i1 false, ptr %l244, !tbaa !21
  %t676 = load ptr, ptr %l243, !tbaa !29
  %t677 = icmp ne ptr %t676, null
  br i1 %t677, label %bb126, label %bb127
bb126:
  %t679 = load ptr, ptr %l243, !tbaa !29
  %t680 = load i64, ptr %t679
  %t682 = icmp eq i64 %t680, 13
  store i1 %t682, ptr %l244, !tbaa !21
  br label %bb127
bb127:
  %t683 = load i1, ptr %l244, !tbaa !21
  br i1 %t683, label %bb128, label %bb129
bb128:
  %t684 = load ptr, ptr %l1, !tbaa !29
  %t686 = getelementptr { i64, [3 x i64] }, ptr %t684, i32 0, i32 1
  %t687 = getelementptr { %"compiler/source:Span", ptr }, ptr %t686, i32 0, i32 1
  %t688 = load ptr, ptr %t687
  store ptr %t688, ptr %l21, !tbaa !29
  br label %bb130
bb129:
  br label %bb133
bb130:
  store %olang.scope zeroinitializer, ptr %s28
  %t690 = load ptr, ptr %l0, !tbaa !29
  store ptr %t690, ptr %l249, !tbaa !29
  %t691 = load i64, ptr %l2, !tbaa !24
  store i64 %t691, ptr %l250, !tbaa !24
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t693 = load ptr, ptr %l21, !tbaa !29
  %t695 = getelementptr %"compiler/typed:Spawn", ptr %t693, i32 0, i32 1
  %t696 = load ptr, ptr %t695, !tbaa !29
  %t699 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s28, ptr %t692, ptr %t696)
  store { i64, ptr } %t699, ptr %l254
  br label %bb131
bb131:
  %t700 = load ptr, ptr %l21, !tbaa !29
  %t702 = getelementptr %"compiler/typed:Spawn", ptr %t700, i32 0, i32 3
  %t703 = load i32, ptr %t702, !tbaa !23
  %t704 = extractvalue { i64, ptr } { i64 6, ptr @.d115 }, 1
  %t705 = extractvalue { i64, ptr } { i64 6, ptr @.d115 }, 0
  %t706 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t707 = extractvalue { i64, ptr } %t706, 1
  %t708 = extractvalue { i64, ptr } %t706, 0
  %t709 = add i64 %t705, %t708
  %t710 = extractvalue { i64, ptr } { i64 6, ptr @.d116 }, 1
  %t711 = extractvalue { i64, ptr } { i64 6, ptr @.d116 }, 0
  %t712 = add i64 %t709, %t711
  %t714 = sext i32 %t703 to i64
  %t715 = call i64 @__olang_fmt_i64(ptr null, i64 %t714)
  %t716 = add i64 %t712, %t715
  %t717 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t716)
  call void @olang_textcopy(ptr %t717, ptr %t704, i64 %t705)
  %t718 = getelementptr i8, ptr %t717, i64 %t705
  call void @olang_textcopy(ptr %t718, ptr %t707, i64 %t708)
  %t719 = getelementptr i8, ptr %t718, i64 %t708
  call void @olang_textcopy(ptr %t719, ptr %t710, i64 %t711)
  %t720 = getelementptr i8, ptr %t719, i64 %t711
  %t721 = call i64 @__olang_fmt_i64(ptr %t720, i64 %t714)
  %t722 = insertvalue { i64, ptr } undef, i64 %t716, 0
  %t723 = insertvalue { i64, ptr } %t722, ptr %t717, 1
  %t725 = extractvalue { i64, ptr } %t723, 0
  %t726 = extractvalue { i64, ptr } %t723, 1
  %t727 = mul i64 %t725, 1
  %t728 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t727)
  call void @llvm.memcpy.p0.p0.i64(ptr %t728, ptr %t726, i64 %t727, i1 false)
  %t729 = insertvalue { i64, ptr } undef, i64 %t725, 0
  %t730 = insertvalue { i64, ptr } %t729, ptr %t728, 1
  %t731 = load ptr, ptr %l249, !tbaa !29
  %t732 = load i64, ptr %l250, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s28, ptr %t731, i64 %t732, { i64, ptr } %t730)
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s28)
  br label %bb142
bb133:
  %t734 = load ptr, ptr %l1, !tbaa !29
  store ptr %t734, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t735 = load ptr, ptr %l259, !tbaa !29
  %t736 = icmp ne ptr %t735, null
  br i1 %t736, label %bb134, label %bb135
bb134:
  %t738 = load ptr, ptr %l259, !tbaa !29
  %t739 = load i64, ptr %t738
  %t741 = icmp eq i64 %t739, 14
  store i1 %t741, ptr %l260, !tbaa !21
  br label %bb135
bb135:
  %t742 = load i1, ptr %l260, !tbaa !21
  br i1 %t742, label %bb136, label %bb137
bb136:
  %t743 = load ptr, ptr %l1, !tbaa !29
  %t745 = getelementptr { i64, [3 x i64] }, ptr %t743, i32 0, i32 1
  %t746 = getelementptr { %"compiler/source:Span", ptr }, ptr %t745, i32 0, i32 1
  %t747 = load ptr, ptr %t746
  store ptr %t747, ptr %l22, !tbaa !29
  br label %bb138
bb137:
  br label %bb141
bb138:
  store %olang.scope zeroinitializer, ptr %s30
  %t749 = load ptr, ptr %l0, !tbaa !29
  store ptr %t749, ptr %l265, !tbaa !29
  %t750 = load i64, ptr %l2, !tbaa !24
  store i64 %t750, ptr %l266, !tbaa !24
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t752 = load ptr, ptr %l22, !tbaa !29
  %t755 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s30, ptr %t751, ptr %t752)
  store { i64, ptr } %t755, ptr %l269
  br label %bb139
bb139:
  %t756 = extractvalue { i64, ptr } { i64 6, ptr @.d117 }, 1
  %t757 = extractvalue { i64, ptr } { i64 6, ptr @.d117 }, 0
  %t758 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t759 = extractvalue { i64, ptr } %t758, 1
  %t760 = extractvalue { i64, ptr } %t758, 0
  %t761 = add i64 %t757, %t760
  %t762 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t761)
  call void @olang_textcopy(ptr %t762, ptr %t756, i64 %t757)
  %t763 = getelementptr i8, ptr %t762, i64 %t757
  call void @olang_textcopy(ptr %t763, ptr %t759, i64 %t760)
  %t764 = insertvalue { i64, ptr } undef, i64 %t761, 0
  %t765 = insertvalue { i64, ptr } %t764, ptr %t762, 1
  %t767 = extractvalue { i64, ptr } %t765, 0
  %t768 = extractvalue { i64, ptr } %t765, 1
  %t769 = mul i64 %t767, 1
  %t770 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t769)
  call void @llvm.memcpy.p0.p0.i64(ptr %t770, ptr %t768, i64 %t769, i1 false)
  %t771 = insertvalue { i64, ptr } undef, i64 %t767, 0
  %t772 = insertvalue { i64, ptr } %t771, ptr %t770, 1
  %t773 = load ptr, ptr %l265, !tbaa !29
  %t774 = load i64, ptr %l266, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s30, ptr %t773, i64 %t774, { i64, ptr } %t772)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s30)
  br label %bb142
bb141:
  call void @__olang_check_failed(ptr @.c118)
  unreachable
bb142:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2econstItems(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 91)
  br label %bb2
bb2:
  store i64 0, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb5:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l18, !tbaa !24
  store i64 %t34, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l15, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb13, label %bb14
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store ptr %l1, ptr %l39, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t59, ptr %l40, !tbaa !27
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t67 = call { i64, ptr } @compiler_2ftyped_2econstText(ptr %v0, ptr %s2, ptr %t65)
  store { i64, ptr } %t67, ptr %l43
  br label %bb17
bb17:
  %t68 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t75, { i64, ptr } %t74)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb9
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 93)
  br label %bb21
bb21:
  %t83 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t83, ptr %l49
  br label %bb22
bb22:
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l51, !tbaa !24
  %t87 = load i64, ptr %l51, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l52, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t98, ptr %l50, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t99 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t99, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2econstText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l1, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = call i64 @__olang_fmt_i64(ptr null, i64 %t16)
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t16)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t19, 1
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  br label %bb20
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l13, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l14, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr } }, ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = extractvalue { i64, ptr } { i64 5, ptr @.d119 }, 1
  %t43 = extractvalue { i64, ptr } { i64 5, ptr @.d119 }, 0
  %t45 = call i64 @__olang_fmt_i64(ptr null, i64 %t41)
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = getelementptr i8, ptr %t47, i64 %t43
  %t49 = call i64 @__olang_fmt_i64(ptr %t48, i64 %t41)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t47, 1
  store { i64, ptr } %t51, ptr %l4, !tbaa !27
  br label %bb20
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t54 = load ptr, ptr %l22, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l22, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 2
  store i1 %t60, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t61 = load i1, ptr %l23, !tbaa !21
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { { i64, ptr } }, ptr %t64, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65
  store { i64, ptr } %t66, ptr %l3, !tbaa !27
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = call { i64, ptr } @compiler_2ftyped_2econstItems(ptr %v0, ptr %v1, { i64, ptr } %t68)
  store { i64, ptr } %t70, ptr %l29
  br label %bb18
bb18:
  %t71 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t71, ptr %l4, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @.c120)
  unreachable
bb20:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2eshort(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr @.d121 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t9, ptr %rv
  br label %ret
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t15 = add i64 %t11, 1
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 0
  store i64 %t19, ptr %l12, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c122)
  unreachable
bb7:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c122)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l12, !tbaa !24
  %t37 = getelementptr i8, ptr %t34, i64 %t35
  %t38 = sub i64 %t36, %t35
  %t39 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @.c122)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/typed:Alt" @compiler_2ftyped_3aAlt_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Alt"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Alt" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/typed:Alt" %t6, { i64, ptr } %a1, 1
  store %"compiler/typed:Alt" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Alt", ptr %rv
  ret %"compiler/typed:Alt" %rr
}

define dso_local %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Arm"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Arm" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/typed:Arm" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Arm" %t14, ptr %a2, 2
  %t18 = insertvalue %"compiler/typed:Arm" %t16, ptr %a3, 3
  %t20 = insertvalue %"compiler/typed:Arm" %t18, ptr %a4, 4
  store %"compiler/typed:Arm" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Arm", ptr %rv
  ret %"compiler/typed:Arm" %rr
}

define dso_local %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Bind"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Bind" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Bind" %t6, ptr %a1, 1
  store %"compiler/typed:Bind" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Bind", ptr %rv
  ret %"compiler/typed:Bind" %rr
}

define dso_local %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %v0, i32 %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:BlockInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:BlockInfo" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/typed:BlockInfo" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/typed:BlockInfo" %t10, %"compiler/source:Span" %a2, 2
  store %"compiler/typed:BlockInfo" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:BlockInfo", ptr %rv
  ret %"compiler/typed:BlockInfo" %rr
}

define dso_local %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Block"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Block" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Block" %t6, { i64, ptr } %a1, 1
  store %"compiler/typed:Block" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Block", ptr %rv
  ret %"compiler/typed:Block" %rr
}

define dso_local %"compiler/typed:Body" @compiler_2ftyped_3aBody_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/typed:Body"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l5, !tbaa !23
  store { i64, [2 x i64] } %a1, ptr %l6
  store i32 %a2, ptr %l7, !tbaa !23
  store i64 %a3, ptr %l8, !tbaa !24
  store %"compiler/source:Span" %a4, ptr %l9
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e(ptr %t11)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l22
  br label %bb1
bb1:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l10
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e(ptr %t14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l23
  br label %bb2
bb2:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l11
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e(ptr %t17)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l24
  br label %bb3
bb3:
  %t19 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l12
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %t20)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l25
  br label %bb4
bb4:
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l13
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %t23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l26
  br label %bb5
bb5:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l14
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e(ptr %t26)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l27
  br label %bb6
bb6:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  %t29 = load i32, ptr %l5, !tbaa !23
  %t30 = insertvalue %"compiler/typed:Body" undef, i32 %t29, 0
  %t31 = load { i64, [2 x i64] }, ptr %l6
  %t32 = insertvalue %"compiler/typed:Body" %t30, { i64, [2 x i64] } %t31, 1
  %t33 = load i32, ptr %l7, !tbaa !23
  %t34 = insertvalue %"compiler/typed:Body" %t32, i32 %t33, 2
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = insertvalue %"compiler/typed:Body" %t34, i64 %t35, 3
  %t37 = load %"compiler/source:Span", ptr %l9
  %t38 = insertvalue %"compiler/typed:Body" %t36, %"compiler/source:Span" %t37, 4
  %t39 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t40 = insertvalue %"compiler/typed:Body" %t38, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, 5
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t42 = insertvalue %"compiler/typed:Body" %t40, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, 6
  %t43 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t44 = insertvalue %"compiler/typed:Body" %t42, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, 7
  %t45 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t46 = insertvalue %"compiler/typed:Body" %t44, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, 8
  %t47 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  %t48 = insertvalue %"compiler/typed:Body" %t46, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, 9
  %t50 = insertvalue %"compiler/typed:Body" %t48, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, 10
  %t52 = insertvalue %"compiler/typed:Body" %t50, ptr null, 11
  store %"compiler/typed:Body" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Body", ptr %rv
  ret %"compiler/typed:Body" %rr
}

define dso_local %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Call"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Call" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/typed:Call" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Call" %t14, { i64, [2 x i64] } %a2, 2
  %t18 = insertvalue %"compiler/typed:Call" %t16, i32 %a3, 3
  %t20 = insertvalue %"compiler/typed:Call" %t18, i1 %a4, 4
  store %"compiler/typed:Call" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Call", ptr %rv
  ret %"compiler/typed:Call" %rr
}

define dso_local %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Capture"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Capture" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Capture" %t6, ptr %a1, 1
  store %"compiler/typed:Capture" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Capture", ptr %rv
  ret %"compiler/typed:Capture" %rr
}

define dso_local %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Clause"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Clause" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/typed:Clause" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Clause" %t14, i1 %a2, 2
  %t18 = insertvalue %"compiler/typed:Clause" %t16, ptr %a3, 3
  %t20 = insertvalue %"compiler/typed:Clause" %t18, { i64, ptr } %a4, 4
  store %"compiler/typed:Clause" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Clause", ptr %rv
  ret %"compiler/typed:Clause" %rr
}

define dso_local %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Collect"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Collect" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/typed:Collect" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/typed:Collect" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/typed:Collect" %t14, i32 %a3, 3
  store %"compiler/typed:Collect" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Collect", ptr %rv
  ret %"compiler/typed:Collect" %rr
}

define dso_local %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Cond"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Cond" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Cond" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Cond" %t10, ptr %a2, 2
  store %"compiler/typed:Cond" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Cond", ptr %rv
  ret %"compiler/typed:Cond" %rr
}

define dso_local %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Elem"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Elem" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Elem" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Elem" %t10, i32 %a2, 2
  store %"compiler/typed:Elem" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Elem", ptr %rv
  ret %"compiler/typed:Elem" %rr
}

define dso_local %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:If"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:If" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:If" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:If" %t10, ptr %a2, 2
  store %"compiler/typed:If" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:If", ptr %rv
  ret %"compiler/typed:If" %rr
}

define dso_local %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Item"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Item" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Item" %t6, i64 %a1, 1
  store %"compiler/typed:Item" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Item", ptr %rv
  ret %"compiler/typed:Item" %rr
}

define dso_local %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Join"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Join" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Join" %t8, i1 %a1, 1
  %t12 = insertvalue %"compiler/typed:Join" %t10, { i64, ptr } %a2, 2
  store %"compiler/typed:Join" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Join", ptr %rv
  ret %"compiler/typed:Join" %rr
}

define dso_local %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5) #0 {
entry:
  %rv = alloca %"compiler/typed:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/typed:Local" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/typed:Local" %t14, %"compiler/source:Span" %a1, 1
  %t18 = insertvalue %"compiler/typed:Local" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/typed:Local" %t18, i32 %a3, 3
  %t22 = insertvalue %"compiler/typed:Local" %t20, i32 %a4, 4
  %t24 = insertvalue %"compiler/typed:Local" %t22, { i64, [2 x i64] } %a5, 5
  store %"compiler/typed:Local" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Local", ptr %rv
  ret %"compiler/typed:Local" %rr
}

define dso_local %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5) #0 {
entry:
  %rv = alloca %"compiler/typed:Make"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/typed:Make" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/typed:Make" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/typed:Make" %t16, { i64, ptr } %a2, 2
  %t20 = insertvalue %"compiler/typed:Make" %t18, ptr %a3, 3
  %t22 = insertvalue %"compiler/typed:Make" %t20, i32 %a4, 4
  %t24 = insertvalue %"compiler/typed:Make" %t22, i32 %a5, 5
  store %"compiler/typed:Make" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Make", ptr %rv
  ret %"compiler/typed:Make" %rr
}

define dso_local %"compiler/typed:Match" @compiler_2ftyped_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Match"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Match" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/typed:Match" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/typed:Match" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/typed:Match" %t14, i1 %a3, 3
  store %"compiler/typed:Match" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Match", ptr %rv
  ret %"compiler/typed:Match" %rr
}

define dso_local %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Payload"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Payload" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Payload" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/typed:Payload" %t10, i32 %a2, 2
  store %"compiler/typed:Payload" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Payload", ptr %rv
  ret %"compiler/typed:Payload" %rr
}

define dso_local %"compiler/typed:Plan" @compiler_2ftyped_3aPlan_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, [1 x i64] }
  %l18 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/typed:Plan"
  %t15 = alloca { i64, [1 x i64] }, align 8
  %t28 = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l9, !tbaa !24
  %t2 = load i64, ptr %l9, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l9, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c123)
  unreachable
bb3:
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 %a1, ptr %l13, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [1 x i64] }, ptr %t15, i32 0, i32 0
  store i64 5, ptr %t16
  %t17 = load { i64, [1 x i64] }, ptr %t15
  store { i64, [1 x i64] } %t17, ptr %l14
  %t18 = load i64, ptr %l13, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c123)
  unreachable
bb5:
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = icmp sle i64 %t21, 576460752303423487
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c124)
  unreachable
bb7:
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = mul i64 %t24, 16
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = load { i64, [1 x i64] }, ptr %l14
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, %t24
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr { i64, [1 x i64] }, ptr %t26, i64 %t32
  store { i64, [1 x i64] } %t27, ptr %t34
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t26, 1
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  store i64 %a2, ptr %l18, !tbaa !24
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c124)
  unreachable
bb9:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = mul i64 %t43, 1
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l5, !tbaa !27
  %t49 = load i64, ptr %l0, !tbaa !24
  store i64 %t49, ptr %l21, !tbaa !24
  %t50 = load i64, ptr %l21, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c125)
  unreachable
bb11:
  %t53 = load i64, ptr %l21, !tbaa !24
  %t54 = icmp sle i64 %t53, 1152921504606846975
  br i1 %t54, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c126)
  unreachable
bb13:
  %t56 = load i64, ptr %l21, !tbaa !24
  %t57 = mul i64 %t56, 8
  %t58 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l6, !tbaa !27
  %t62 = load i64, ptr %l0, !tbaa !24
  store i64 %t62, ptr %l25, !tbaa !24
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  br i1 %t64, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c126)
  unreachable
bb15:
  %t66 = load i64, ptr %l25, !tbaa !24
  %t67 = icmp sle i64 %t66, 1152921504606846975
  br i1 %t67, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c127)
  unreachable
bb17:
  %t69 = load i64, ptr %l25, !tbaa !24
  %t70 = mul i64 %t69, 8
  %t71 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l7, !tbaa !27
  %t75 = load ptr, ptr @__olang_prog_scope
  %t76 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e(ptr %t75)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l29
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @.c127)
  unreachable
bb19:
  %t77 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = insertvalue %"compiler/typed:Plan" undef, { i64, ptr } %t78, 0
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t81 = insertvalue %"compiler/typed:Plan" %t79, { i64, ptr } %t80, 1
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t83 = insertvalue %"compiler/typed:Plan" %t81, { i64, ptr } %t82, 2
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = insertvalue %"compiler/typed:Plan" %t83, { i64, ptr } %t84, 3
  %t86 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t87 = insertvalue %"compiler/typed:Plan" %t85, { i64, ptr } %t86, 4
  %t89 = insertvalue %"compiler/typed:Plan" %t87, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, 5
  store %"compiler/typed:Plan" %t89, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Plan", ptr %rv
  ret %"compiler/typed:Plan" %rr
}

define dso_local %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Promote"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Promote" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/typed:Promote" %t6, i32 %a1, 1
  store %"compiler/typed:Promote" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Promote", ptr %rv
  ret %"compiler/typed:Promote" %rr
}

define dso_local %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Seq"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Seq" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:Seq" %t6, ptr %a1, 1
  store %"compiler/typed:Seq" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Seq", ptr %rv
  ret %"compiler/typed:Seq" %rr
}

define dso_local %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:SiteInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:SiteInfo" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:SiteInfo" %t6, %"compiler/source:Span" %a1, 1
  store %"compiler/typed:SiteInfo" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:SiteInfo", ptr %rv
  ret %"compiler/typed:SiteInfo" %rr
}

define dso_local %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Slice"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Slice" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/typed:Slice" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/typed:Slice" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/typed:Slice" %t14, i32 %a3, 3
  store %"compiler/typed:Slice" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Slice", ptr %rv
  ret %"compiler/typed:Slice" %rr
}

define dso_local %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Spawn"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Spawn" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/typed:Spawn" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/typed:Spawn" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/typed:Spawn" %t14, i32 %a3, 3
  store %"compiler/typed:Spawn" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Spawn", ptr %rv
  ret %"compiler/typed:Spawn" %rr
}

define dso_local %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:TaskClause"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:TaskClause" undef, %"compiler/source:Span" %a0, 0
  %t12 = insertvalue %"compiler/typed:TaskClause" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/typed:TaskClause" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/typed:TaskClause" %t14, ptr %a3, 3
  store %"compiler/typed:TaskClause" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:TaskClause", ptr %rv
  ret %"compiler/typed:TaskClause" %rr
}

define dso_local %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Text"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Text" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:Text" %t6, i32 %a1, 1
  store %"compiler/typed:Text" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Text", ptr %rv
  ret %"compiler/typed:Text" %rr
}

define dso_local %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Try"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Try" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/typed:Try" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/typed:Try" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/typed:Try" %t14, i1 %a3, 3
  store %"compiler/typed:Try" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Try", ptr %rv
  ret %"compiler/typed:Try" %rr
}

define dso_local %"compiler/typed:printer" @compiler_2ftyped_3aprinter_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"compiler/typed:printer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %t3)
  store %"std/prelude/text:StringBuilder" %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load %"std/prelude/text:StringBuilder", ptr %l4
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t7 = insertvalue %"compiler/typed:printer" undef, ptr %t6, 0
  %t9 = insertvalue %"compiler/typed:printer" %t7, %"std/prelude/text:StringBuilder" %t5, 1
  store %"compiler/typed:printer" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:printer", ptr %rv
  ret %"compiler/typed:printer" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d0 = private constant [5 x i8] c"body "
declare i64 @__olang_fmt_i64(ptr, i64)
@.d1 = private constant [8 x i8] c" locals "
@.d2 = private constant [8 x i8] c" blocks "
@.d3 = private constant [6 x i8] c" sites"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr)
@.c4 = private unnamed_addr constant [47 x i8] c"compiler/typed.olang:554: unreachable reached\0A\00"
@.c5 = private unnamed_addr constant [47 x i8] c"compiler/typed.olang:643: unreachable reached\0A\00"
@.c6 = private unnamed_addr constant [47 x i8] c"compiler/typed.olang:653: unreachable reached\0A\00"
@.c7 = private unnamed_addr constant [47 x i8] c"compiler/typed.olang:670: unreachable reached\0A\00"
@.c8 = private unnamed_addr constant [47 x i8] c"compiler/typed.olang:663: unreachable reached\0A\00"
@.c9 = private unnamed_addr constant [47 x i8] c"compiler/typed.olang:677: unreachable reached\0A\00"
@.d10 = private constant [1 x i8] c"{"
@.d11 = private constant [1 x i8] c"B"
@.d12 = private constant [7 x i8] c"extern "
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aHelper(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 12, ptr @.d128 }, 1
  %t6 = extractvalue { i64, ptr } { i64 12, ptr @.d128 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 11, ptr @.d129 }, 1
  %t8 = extractvalue { i64, ptr } { i64 11, ptr @.d129 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d13 = private constant [1 x i8] c" "
@.c14 = private unnamed_addr constant [47 x i8] c"compiler/typed.olang:811: unreachable reached\0A\00"
@.d15 = private constant [1 x i8] c"_"
@.d16 = private constant [5 x i8] c"(lit "
@.d17 = private constant [1 x i8] c" "
@.d18 = private constant [1 x i8] c")"
@.d19 = private constant [6 x i8] c"(data "
@.d20 = private constant [1 x i8] c" "
@.d21 = private constant [1 x i8] c" "
@.d22 = private constant [1 x i8] c")"
@.d23 = private constant [6 x i8] c" site "
@.d24 = private constant [0 x i8] c""
@.d25 = private constant [6 x i8] c"(read "
@.d26 = private constant [1 x i8] c")"
@.d27 = private constant [8 x i8] c"(borrow "
@.d28 = private constant [1 x i8] c" "
@.d29 = private constant [1 x i8] c")"
@.d30 = private constant [6 x i8] c"(take "
@.d31 = private constant [1 x i8] c")"
@.d32 = private constant [9 x i8] c"(promote "
@.d33 = private constant [1 x i8] c" "
@.d34 = private constant [6 x i8] c" site "
@.d35 = private constant [1 x i8] c")"
@.d36 = private constant [6 x i8] c"(call "
@.d37 = private constant [1 x i8] c" "
@.d38 = private constant [6 x i8] c" site "
@.d39 = private constant [1 x i8] c")"
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aMakeKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 14, ptr @.d130 }, 1
  %t6 = extractvalue { i64, ptr } { i64 14, ptr @.d130 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d131 }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr @.d131 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr @.d132 }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr @.d132 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 13, ptr @.d133 }, 1
  %t12 = extractvalue { i64, ptr } { i64 13, ptr @.d133 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
ret:
  ret void
}

@.d40 = private constant [6 x i8] c"(make "
@.d41 = private constant [1 x i8] c" "
@.d42 = private constant [1 x i8] c" "
@.d43 = private constant [1 x i8] c")"
@.d44 = private constant [9 x i8] c"(collect "
@.d45 = private constant [6 x i8] c" site "
@.d46 = private constant [1 x i8] c")"
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr @.d134 }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr @.d134 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d135 }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr @.d135 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 10, ptr @.d136 }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr @.d136 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 10, ptr @.d137 }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr @.d137 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 10, ptr @.d138 }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr @.d138 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 10, ptr @.d139 }, 1
  %t16 = extractvalue { i64, ptr } { i64 10, ptr @.d139 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 10, ptr @.d140 }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr @.d140 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 10, ptr @.d141 }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr @.d141 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 10, ptr @.d142 }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr @.d142 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 10, ptr @.d143 }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr @.d143 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 13, ptr @.d144 }, 1
  %t26 = extractvalue { i64, ptr } { i64 13, ptr @.d144 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 12, ptr @.d145 }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr @.d145 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 13, ptr @.d146 }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr @.d146 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 9, ptr @.d147 }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr @.d147 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 9, ptr @.d148 }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr @.d148 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 9, ptr @.d149 }, 1
  %t36 = extractvalue { i64, ptr } { i64 9, ptr @.d149 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 9, ptr @.d150 }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr @.d150 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr @.d151 }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr @.d151 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 9, ptr @.d152 }, 1
  %t42 = extractvalue { i64, ptr } { i64 9, ptr @.d152 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 11, ptr @.d153 }, 1
  %t44 = extractvalue { i64, ptr } { i64 11, ptr @.d153 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 14, ptr @.d154 }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr @.d154 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 14, ptr @.d155 }, 1
  %t48 = extractvalue { i64, ptr } { i64 14, ptr @.d155 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 10, ptr @.d156 }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr @.d156 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 13, ptr @.d157 }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr @.d157 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 14, ptr @.d158 }, 1
  %t54 = extractvalue { i64, ptr } { i64 14, ptr @.d158 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 18, ptr @.d159 }, 1
  %t56 = extractvalue { i64, ptr } { i64 18, ptr @.d159 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 17, ptr @.d160 }, 1
  %t58 = extractvalue { i64, ptr } { i64 17, ptr @.d160 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 18, ptr @.d161 }, 1
  %t60 = extractvalue { i64, ptr } { i64 18, ptr @.d161 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 16, ptr @.d162 }, 1
  %t62 = extractvalue { i64, ptr } { i64 16, ptr @.d162 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 17, ptr @.d163 }, 1
  %t64 = extractvalue { i64, ptr } { i64 17, ptr @.d163 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 24, ptr @.d164 }, 1
  %t66 = extractvalue { i64, ptr } { i64 24, ptr @.d164 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 13, ptr @.d165 }, 1
  %t68 = extractvalue { i64, ptr } { i64 13, ptr @.d165 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
ret:
  ret void
}

define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aCheck(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aCheck(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr @.d166 }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr @.d166 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 11, ptr @.d167 }, 1
  %t8 = extractvalue { i64, ptr } { i64 11, ptr @.d167 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 9, ptr @.d168 }, 1
  %t10 = extractvalue { i64, ptr } { i64 9, ptr @.d168 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
ret:
  ret void
}

@.d47 = private constant [0 x i8] c""
@.d48 = private constant [1 x i8] c" "
@.d49 = private constant [1 x i8] c"("
@.d50 = private constant [1 x i8] c" "
@.d51 = private constant [1 x i8] c" "
@.d52 = private constant [1 x i8] c")"
@.d53 = private constant [7 x i8] c"(slice "
@.d54 = private constant [1 x i8] c" "
@.d55 = private constant [1 x i8] c" "
@.d56 = private constant [1 x i8] c")"
@.d57 = private constant [6 x i8] c"(cond "
@.d58 = private constant [1 x i8] c" "
@.d59 = private constant [1 x i8] c" "
@.d60 = private constant [1 x i8] c")"
@.d61 = private constant [5 x i8] c"(seq "
@.d62 = private constant [1 x i8] c" "
@.d63 = private constant [1 x i8] c")"
@.d64 = private constant [7 x i8] c"(match "
@.d65 = private constant [15 x i8] c" arms, nomatch "
@.d66 = private constant [1 x i8] c")"
@.d67 = private constant [5 x i8] c"(try "
@.d68 = private constant [1 x i8] c" "
@.d69 = private constant [9 x i8] c" clauses)"
@.d70 = private constant [4 x i8] c"(fn "
@.d71 = private constant [1 x i8] c")"
@.d72 = private constant [6 x i8] c"(text "
@.d73 = private constant [6 x i8] c" site "
@.d74 = private constant [1 x i8] c")"
@.d75 = private constant [6 x i8] c"(away "
@.d76 = private constant [1 x i8] c" "
@.d77 = private constant [1 x i8] c")"
@.c78 = private unnamed_addr constant [47 x i8] c"compiler/typed.olang:762: unreachable reached\0A\00"
@.d79 = private constant [2 x i8] c"  "
@.d80 = private constant [1 x i8] c"L"
@.d81 = private constant [1 x i8] c"G"
@.d82 = private constant [1 x i8] c":"
@.d83 = private constant [1 x i8] c"*"
@.d84 = private constant [1 x i8] c"."
@.d85 = private constant [1 x i8] c"["
@.d86 = private constant [1 x i8] c"]"
@.d87 = private constant [4 x i8] c" as "
@.d88 = private constant [4 x i8] c"tmp "
@.d89 = private constant [6 x i8] c" site "
@.d90 = private constant [6 x i8] c"target"
@.c91 = private unnamed_addr constant [47 x i8] c"compiler/typed.olang:820: unreachable reached\0A\00"
@.d92 = private constant [5 x i8] c"let L"
@.d93 = private constant [3 x i8] c" = "
@.d94 = private constant [7 x i8] c"assign "
@.d95 = private constant [3 x i8] c" = "
@.d96 = private constant [5 x i8] c"eval "
@.d97 = private constant [3 x i8] c"if "
@.d98 = private constant [4 x i8] c"else"
@.d99 = private constant [4 x i8] c"loop"
@.d100 = private constant [4 x i8] c"post"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aJumpKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d101 = private constant [5 x i8] c"break"
@.d102 = private constant [8 x i8] c"continue"
@.d103 = private constant [2 x i8] c" {"
@.d104 = private constant [0 x i8] c""
@.d105 = private constant [1 x i8] c" "
@.d106 = private constant [6 x i8] c"return"
@.d107 = private constant [6 x i8] c"raise "
@.d108 = private constant [1 x i8] c"."
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aExitKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 20, ptr @.d169 }, 1
  %t6 = extractvalue { i64, ptr } { i64 20, ptr @.d169 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
ret:
  ret void
}

@.d109 = private constant [5 x i8] c"exit "
@.d110 = private constant [7 x i8] c"assert "
@.d111 = private constant [5 x i8] c"defer"
@.d112 = private constant [4 x i8] c" try"
@.d113 = private constant [0 x i8] c""
@.d114 = private constant [4 x i8] c"join"
@.d115 = private constant [6 x i8] c"spawn "
@.d116 = private constant [6 x i8] c" site "
@.d117 = private constant [6 x i8] c"yield "
@.c118 = private unnamed_addr constant [47 x i8] c"compiler/typed.olang:711: unreachable reached\0A\00"
@.d119 = private constant [5 x i8] c"text "
@.c120 = private unnamed_addr constant [47 x i8] c"compiler/typed.olang:786: unreachable reached\0A\00"
@.d121 = private constant [1 x i8] c"."
@.c122 = private unnamed_addr constant [53 x i8] c"compiler/typed.olang:807: slice bounds out of range\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.c123 = private unnamed_addr constant [53 x i8] c"compiler/typed.olang:616: array length out of range\0A\00"
@.c124 = private unnamed_addr constant [53 x i8] c"compiler/typed.olang:617: array length out of range\0A\00"
@.c125 = private unnamed_addr constant [53 x i8] c"compiler/typed.olang:618: array length out of range\0A\00"
@.c126 = private unnamed_addr constant [53 x i8] c"compiler/typed.olang:619: array length out of range\0A\00"
@.c127 = private unnamed_addr constant [53 x i8] c"compiler/typed.olang:620: array length out of range\0A\00"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t1)
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d128 = private unnamed_addr constant [12 x i8] c"Helper.Equal"
declare void @__olang_sb_put(ptr, ptr, i64)
@.d129 = private unnamed_addr constant [11 x i8] c"Helper.Hash"
@.d130 = private unnamed_addr constant [14 x i8] c"MakeKind.Tuple"
@.d131 = private unnamed_addr constant [13 x i8] c"MakeKind.Case"
@.d132 = private unnamed_addr constant [14 x i8] c"MakeKind.Array"
@.d133 = private unnamed_addr constant [13 x i8] c"MakeKind.Fill"
@.d134 = private unnamed_addr constant [10 x i8] c"PrimOp.Neg"
@.d135 = private unnamed_addr constant [13 x i8] c"PrimOp.BitNot"
@.d136 = private unnamed_addr constant [10 x i8] c"PrimOp.Not"
@.d137 = private unnamed_addr constant [10 x i8] c"PrimOp.Add"
@.d138 = private unnamed_addr constant [10 x i8] c"PrimOp.Sub"
@.d139 = private unnamed_addr constant [10 x i8] c"PrimOp.Mul"
@.d140 = private unnamed_addr constant [10 x i8] c"PrimOp.Div"
@.d141 = private unnamed_addr constant [10 x i8] c"PrimOp.Rem"
@.d142 = private unnamed_addr constant [10 x i8] c"PrimOp.Shl"
@.d143 = private unnamed_addr constant [10 x i8] c"PrimOp.Shr"
@.d144 = private unnamed_addr constant [13 x i8] c"PrimOp.BitAnd"
@.d145 = private unnamed_addr constant [12 x i8] c"PrimOp.BitOr"
@.d146 = private unnamed_addr constant [13 x i8] c"PrimOp.BitXor"
@.d147 = private unnamed_addr constant [9 x i8] c"PrimOp.Eq"
@.d148 = private unnamed_addr constant [9 x i8] c"PrimOp.Ne"
@.d149 = private unnamed_addr constant [9 x i8] c"PrimOp.Lt"
@.d150 = private unnamed_addr constant [9 x i8] c"PrimOp.Le"
@.d151 = private unnamed_addr constant [9 x i8] c"PrimOp.Gt"
@.d152 = private unnamed_addr constant [9 x i8] c"PrimOp.Ge"
@.d153 = private unnamed_addr constant [11 x i8] c"PrimOp.Same"
@.d154 = private unnamed_addr constant [14 x i8] c"PrimOp.Convert"
@.d155 = private unnamed_addr constant [14 x i8] c"PrimOp.Bitcast"
@.d156 = private unnamed_addr constant [10 x i8] c"PrimOp.Len"
@.d157 = private unnamed_addr constant [13 x i8] c"PrimOp.IsCase"
@.d158 = private unnamed_addr constant [14 x i8] c"PrimOp.InRange"
@.d159 = private unnamed_addr constant [18 x i8] c"PrimOp.InRangeIncl"
@.d160 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicLoad"
@.d161 = private unnamed_addr constant [18 x i8] c"PrimOp.AtomicStore"
@.d162 = private unnamed_addr constant [16 x i8] c"PrimOp.AtomicAdd"
@.d163 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicSwap"
@.d164 = private unnamed_addr constant [24 x i8] c"PrimOp.AtomicCompareSwap"
@.d165 = private unnamed_addr constant [13 x i8] c"PrimOp.Retire"
@.d166 = private unnamed_addr constant [10 x i8] c"Check.None"
@.d167 = private unnamed_addr constant [11 x i8] c"Check.Abort"
@.d168 = private unnamed_addr constant [9 x i8] c"Check.Try"
@.d169 = private unnamed_addr constant [20 x i8] c"ExitKind.Unreachable"
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eLe_Heec836b2f97bed3c10ee7e3cac736d9d(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eP_Hc92177ba48b21a9f8d26c1a49cf2119c(ptr %v0, ptr %a0, %"compiler/typed:BlockInfo" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eL_H5b8a0bc03aecb48440b685dbbc0b269c(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ePush_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ePu_H5cdcfe4ca3473fd9feeaed4f4a6d3f84(ptr %v0, ptr %a0, %"compiler/typed:SiteInfo" %a1)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eClosingVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
