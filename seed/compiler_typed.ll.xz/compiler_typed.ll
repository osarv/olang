; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:SiteInfo" = type { i32, %"compiler/source:Span" }
%"compiler/typed:printer" = type { ptr, %"std/prelude/text:StringBuilder" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
define dso_local %"compiler/typed:Plan" @compiler_2ftyped_2eNewPlan(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/typed:Plan"
  %rv = alloca %"compiler/typed:Plan"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eLe_Heec836b2f97bed3c10ee7e3cac736d9d(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Body", ptr %t6, i32 0, i32 7
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l6
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 6
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l9
  br label %bb3
bb3:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l9, !tbaa !24
  %t19 = call %"compiler/typed:Plan" @compiler_2ftyped_3aPlan_2ector(ptr %v1, i64 %t16, i64 %t17, i64 %t18)
  store %"compiler/typed:Plan" %t19, ptr %l10
  br label %bb4
bb4:
  %t20 = load %"compiler/typed:Plan", ptr %l10
  store %"compiler/typed:Plan" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Plan", ptr %rv
  ret %"compiler/typed:Plan" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca %"compiler/typed:BlockInfo"
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l5, !tbaa !29
  %t10 = call %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %s0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
  store %"compiler/typed:BlockInfo" %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load %"compiler/typed:BlockInfo", ptr %l9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eP_Hc92177ba48b21a9f8d26c1a49cf2119c(ptr %v0, ptr %t11, %"compiler/typed:BlockInfo" %t12)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 8
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eL_H5b8a0bc03aecb48440b685dbbc0b269c(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = sub i64 %t18, 1
  %t21 = trunc i64 %t19 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 7
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ePush_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t3, %"compiler/typed:Local" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Body", ptr %t7, i32 0, i32 7
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca %"compiler/typed:SiteInfo"
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l4, !tbaa !29
  %t8 = call %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %s0, i32 %a1, %"compiler/source:Span" %a2)
  store %"compiler/typed:SiteInfo" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"compiler/typed:SiteInfo", ptr %l7
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ePu_H5cdcfe4ca3473fd9feeaed4f4a6d3f84(ptr %v0, ptr %t9, %"compiler/typed:SiteInfo" %t10)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 9
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eLe_Heec836b2f97bed3c10ee7e3cac736d9d(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = sub i64 %t16, 1
  %t19 = trunc i64 %t17 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca i32
  %l16 = alloca %"compiler/typed:BlockInfo"
  %s1 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a2, ptr %l3, !tbaa !23
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load i32, ptr %l3, !tbaa !23
  %t5 = icmp sge i32 %t3, 0
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t13 = icmp eq i32 %t9, %a1
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 8
  %t19 = load i32, ptr %l3, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %t18, i64 %t21)
  store %"compiler/typed:BlockInfo" %t24, ptr %l16
  br label %bb8
bb8:
  %t25 = getelementptr %"compiler/typed:BlockInfo", ptr %l16, i32 0, i32 0
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/typed:Local"
  %rv = alloca %"compiler/typed:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 7
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/typed:Local" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load %"compiler/typed:Local", ptr %l6
  store %"compiler/typed:Local" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Local", ptr %rv
  ret %"compiler/typed:Local" %rr
}

define dso_local { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t23 = alloca { i64, [2 x i64] }, align 8
  %t54 = alloca { i64, [2 x i64] }, align 8
  %t58 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %t4, !tbaa !23
  %t6 = load i64, ptr %l2, !tbaa !24
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v1, ptr %t1, i32 %t5, i64 %t6)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 5
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t18, i64 %t19)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 0
  store i64 2, ptr %t24
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = insertvalue { i32 } undef, i32 %t25, 0
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 1
  store { i32 } %t26, ptr %t27
  %t28 = load { i64, [2 x i64] }, ptr %t23
  store { i64, [2 x i64] } %t28, ptr %rv
  br label %ret
bb5:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %t35, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t32, i32 %t36)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i32, ptr %t47, i64 %t44
  %t49 = load i32, ptr %t48, !tbaa !33
  %t50 = load ptr, ptr %l16, !tbaa !29
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v1, ptr %t50, i32 %t49)
  store i1 %t52, ptr %l26
  br label %bb8
bb8:
  %t53 = load i1, ptr %l26, !tbaa !21
  br i1 %t53, label %bb9, label %bb10
bb9:
  store { i64, [2 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [2 x i64] }, ptr %t54, i32 0, i32 0
  store i64 1, ptr %t55
  %t56 = load { i64, [2 x i64] }, ptr %t54
  store { i64, [2 x i64] } %t56, ptr %l27
  br label %bb11
bb10:
  store { i64, [2 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 0
  store i64 0, ptr %t59
  %t60 = load { i64, [2 x i64] }, ptr %t58
  store { i64, [2 x i64] } %t60, ptr %l27
  br label %bb11
bb11:
  %t62 = load { i64, [2 x i64] }, ptr %l27
  store { i64, [2 x i64] } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2ePrint(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/typed:printer"
  %l6 = alloca ptr
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l22 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/typed:printer" @compiler_2ftyped_3aprinter_2ector(ptr %v1, ptr %v1, ptr %a1)
  store %"compiler/typed:printer" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/typed:printer", ptr %l4
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store %"compiler/typed:printer" %t4, ptr %t5
  store ptr %t5, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 8
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eL_H5b8a0bc03aecb48440b685dbbc0b269c(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 9
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eLe_Heec836b2f97bed3c10ee7e3cac736d9d(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l15
  br label %bb4
bb4:
  %t23 = extractvalue { i64, ptr } { i64 5, ptr @.d0 }, 1
  %t24 = extractvalue { i64, ptr } { i64 5, ptr @.d0 }, 0
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t27 = add i64 %t24, %t26
  %t28 = extractvalue { i64, ptr } { i64 8, ptr @.d1 }, 1
  %t29 = extractvalue { i64, ptr } { i64 8, ptr @.d1 }, 0
  %t30 = add i64 %t27, %t29
  %t31 = load i64, ptr %l12, !tbaa !24
  %t32 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t33 = add i64 %t30, %t32
  %t34 = extractvalue { i64, ptr } { i64 8, ptr @.d2 }, 1
  %t35 = extractvalue { i64, ptr } { i64 8, ptr @.d2 }, 0
  %t36 = add i64 %t33, %t35
  %t37 = load i64, ptr %l15, !tbaa !24
  %t38 = call i64 @__olang_fmt_i64(ptr null, i64 %t37)
  %t39 = add i64 %t36, %t38
  %t40 = extractvalue { i64, ptr } { i64 6, ptr @.d3 }, 1
  %t41 = extractvalue { i64, ptr } { i64 6, ptr @.d3 }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t23, i64 %t24)
  %t44 = getelementptr i8, ptr %t43, i64 %t24
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t25)
  %t46 = getelementptr i8, ptr %t44, i64 %t26
  call void @olang_textcopy(ptr %t46, ptr %t28, i64 %t29)
  %t47 = getelementptr i8, ptr %t46, i64 %t29
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t31)
  %t49 = getelementptr i8, ptr %t47, i64 %t32
  call void @olang_textcopy(ptr %t49, ptr %t34, i64 %t35)
  %t50 = getelementptr i8, ptr %t49, i64 %t35
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t37)
  %t52 = getelementptr i8, ptr %t50, i64 %t38
  call void @olang_textcopy(ptr %t52, ptr %t40, i64 %t41)
  %t53 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t43, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t62 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v1, ptr %s0, ptr %t62, i64 0, { i64, ptr } %t61)
  br label %bb5
bb5:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Body", ptr %t64, i32 0, i32 11
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb6, label %bb7
bb6:
  %t73 = load ptr, ptr %l2, !tbaa !29
  store ptr %t73, ptr %l22, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 11
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb8, label %bb9
bb7:
  br label %bb12
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b47e7a13871964ca_e65b2c3f8690a096)
  unreachable
bb9:
  br label %bb10
bb10:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Body", ptr %t81, i32 0, i32 11
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v1, ptr %v0, ptr %t85, ptr %t84, i64 1)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr %"compiler/typed:printer", ptr %t87, i32 0, i32 1
  %t91 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v1, ptr %v2, ptr %t89)
  store { i64, ptr } %t91, ptr %l30
  br label %bb13
bb13:
  %t92 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t92, ptr %l31, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l32, !tbaa !24
  %t95 = load i64, ptr %l32, !tbaa !24
  %t96 = mul i64 %t95, 1
  %t97 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t96)
  %t98 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l33, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l32, !tbaa !24
  %t105 = mul i64 %t104, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t101, ptr %t103, i64 %t105, i1 false)
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t106, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t107 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t107, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eResultMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i32
  %rv = alloca { i64, [2 x i64] }
  %t18 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t40 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %t4, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v1, ptr %a1, i32 %t5, i64 %a2)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t16 = icmp eq i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t18
  %t19 = getelementptr { i64, [2 x i64] }, ptr %t18, i32 0, i32 0
  store i64 6, ptr %t19
  %t20 = load { i64, [2 x i64] }, ptr %t18
  store { i64, [2 x i64] } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l18
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 2, ptr %t34
  %t35 = load i32, ptr %l18, !tbaa !23
  %t36 = insertvalue { i32 } undef, i32 %t35, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  store { i64, [2 x i64] } %t38, ptr %rv
  br label %ret
bb8:
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 1, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t40
  store { i64, [2 x i64] } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l15 = alloca { i64, ptr }
  %l29 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca { i64, [1 x i64] }
  %l41 = alloca ptr
  %l45 = alloca i32
  %s2 = alloca %olang.scope
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t74 = alloca { i64, [1 x i64] }, align 8
  %t78 = alloca { i64, [1 x i64] }, align 8
  %t84 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  %t27 = icmp eq i64 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 6
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 3, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t31, { i64, [1 x i64] } %t34)
  br label %bb7
bb6:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t38 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t41 = icmp eq i64 %t37, %t38
  br i1 %t41, label %bb8, label %bb9
bb7:
  br label %bb28
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 1
  %t46 = load { i64, [2 x i64] }, ptr %t45
  store { i64, [2 x i64] } %t46, ptr %l6
  %t48 = load { i64, [2 x i64] }, ptr %l6
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb10, label %bb11
bb9:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t53, i32 0, i32 6
  store ptr %t55, ptr %l41, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 5
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t58, i64 %t59)
  store i32 %t62, ptr %l45
  br label %bb25
bb10:
  br label %bb14
bb11:
  %t63 = load { i64, [2 x i64] }, ptr %l6
  %t65 = extractvalue { i64, [2 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 2
  br i1 %t66, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_49a7b0a2550beed6_c54fa6caa81e807a)
  unreachable
bb20:
  %t68 = load i1, ptr %l29, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 6
  store ptr %t71, ptr %l35, !tbaa !29
  br i1 %t68, label %bb21, label %bb22
bb21:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 2, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  store { i64, [1 x i64] } %t76, ptr %l37
  br label %bb23
bb22:
  store { i64, [1 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [1 x i64] }, ptr %t78, i32 0, i32 0
  store i64 1, ptr %t79
  %t80 = load { i64, [1 x i64] }, ptr %t78
  store { i64, [1 x i64] } %t80, ptr %l37
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load { i64, [1 x i64] }, ptr %l37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t82, { i64, [1 x i64] } %t83)
  br label %bb24
bb24:
  br label %bb27
bb25:
  store { i64, [1 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [1 x i64] }, ptr %t84, i32 0, i32 0
  store i64 0, ptr %t85
  %t86 = load i32, ptr %l45, !tbaa !23
  %t87 = insertvalue { i32 } undef, i32 %t86, 0
  %t88 = getelementptr { i64, [1 x i64] }, ptr %t84, i32 0, i32 1
  store { i32 } %t87, ptr %t88
  %t89 = load { i64, [1 x i64] }, ptr %t84
  %t90 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t90, { i64, [1 x i64] } %t89)
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l3, !tbaa !24
  br label %bb1
bb30:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb83
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l6
  br label %bb83
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l3
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t185, ptr %l6
  br label %bb83
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l4
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l4
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l4
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t262, ptr %l6
  br label %bb83
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t265 = load ptr, ptr %l113, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113, !tbaa !29
  %t269 = load i64, ptr %t268
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l114, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 0
  %t277 = load %"compiler/source:Span", ptr %t276
  store %"compiler/source:Span" %t277, ptr %l5
  br label %bb81
bb80:
  br label %bb82
bb81:
  %t279 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t279, ptr %l6
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_6690d985632b6de7_b13460b3c8232d4b)
  unreachable
bb83:
  %t281 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t281, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l120 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l1, !tbaa !23
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l1, !tbaa !23
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l1, !tbaa !23
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load i32, ptr %l1, !tbaa !23
  store i32 %t61, ptr %l6, !tbaa !23
  br label %bb84
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l2, !tbaa !23
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l2, !tbaa !23
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l2, !tbaa !23
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l2, !tbaa !23
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i32, ptr %l2, !tbaa !23
  store i32 %t123, ptr %l6, !tbaa !23
  br label %bb84
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 1
  %t138 = load i32, ptr %t137
  store i32 %t138, ptr %l3, !tbaa !23
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 1
  %t153 = load i32, ptr %t152
  store i32 %t153, ptr %l3, !tbaa !23
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 1
  %t168 = load i32, ptr %t167
  store i32 %t168, ptr %l3, !tbaa !23
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 1
  %t183 = load i32, ptr %t182
  store i32 %t183, ptr %l3, !tbaa !23
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load i32, ptr %l3, !tbaa !23
  store i32 %t185, ptr %l6, !tbaa !23
  br label %bb84
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 1
  %t200 = load i32, ptr %t199
  store i32 %t200, ptr %l4, !tbaa !23
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 1
  %t215 = load i32, ptr %t214
  store i32 %t215, ptr %l4, !tbaa !23
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 1
  %t230 = load i32, ptr %t229
  store i32 %t230, ptr %l4, !tbaa !23
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 1
  %t245 = load i32, ptr %t244
  store i32 %t245, ptr %l4, !tbaa !23
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 1
  %t260 = load i32, ptr %t259
  store i32 %t260, ptr %l4, !tbaa !23
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load i32, ptr %l4, !tbaa !23
  store i32 %t262, ptr %l6, !tbaa !23
  br label %bb84
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t265 = load ptr, ptr %l113, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113, !tbaa !29
  %t269 = load i64, ptr %t268
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l114, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 2
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l5, !tbaa !29
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t279 = load ptr, ptr %l5, !tbaa !29
  %t281 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t279)
  store i32 %t281, ptr %l120
  br label %bb82
bb82:
  %t282 = load i32, ptr %l120, !tbaa !23
  store i32 %t282, ptr %l6, !tbaa !23
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_9fe0426b44bbec6b_25abfcb63d66fb57)
  unreachable
bb84:
  %t283 = load i32, ptr %l6, !tbaa !23
  store i32 %t283, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l3
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t94 = load ptr, ptr %l41, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t109 = load ptr, ptr %l47, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l3
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_b480914c084fa00b_37b3876b1583fa8f)
  unreachable
bb37:
  %t125 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t125, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l1, !tbaa !23
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l1, !tbaa !23
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l1, !tbaa !23
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load i32, ptr %l1, !tbaa !23
  store i32 %t61, ptr %l3, !tbaa !23
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l2, !tbaa !23
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l2, !tbaa !23
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t94 = load ptr, ptr %l41, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l2, !tbaa !23
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t109 = load ptr, ptr %l47, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l2, !tbaa !23
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i32, ptr %l2, !tbaa !23
  store i32 %t123, ptr %l3, !tbaa !23
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_bffece1bd34fa117_11d44807ae5b6b33)
  unreachable
bb37:
  %t125 = load i32, ptr %l3, !tbaa !23
  store i32 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l10 = alloca i64
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Plan", ptr %t8, i32 0, i32 5
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l13
  br label %bb1
bb1:
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = add i64 %t13, 1
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i64, ptr %t18, i64 %t16
  store i64 %t14, ptr %t19, !tbaa !34
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Plan", ptr %t20, i32 0, i32 4
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i64, ptr %t33, i64 %t26
  store i64 %t29, ptr %t34, !tbaa !34
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t49, ptr %l28, !tbaa !27
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, [1 x i64] }, ptr %t53, i64 %t50
  %t55 = load { i64, [1 x i64] }, ptr %t54
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Plan", ptr %t57, i32 0, i32 5
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t59, { i64, [1 x i64] } %t55)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l11 = alloca i1
  %l14 = alloca { i64, ptr }
  %l26 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t36 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 %t7
  %t12 = load i64, ptr %t11, !tbaa !34
  store i64 %t12, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 4
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l14, !tbaa !27
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t27 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t33 = icmp sge i64 %t18, %t30
  store i1 %t33, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t35 = load i1, ptr %l11, !tbaa !21
  br i1 %t35, label %bb4, label %bb5
bb4:
  store { i64, [1 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [1 x i64] }, ptr %t36, i32 0, i32 0
  store i64 0, ptr %t37
  %t38 = load { i64, [1 x i64] }, ptr %t36
  store { i64, [1 x i64] } %t38, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Plan", ptr %t40, i32 0, i32 5
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l2, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t52 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t42, i64 %t49)
  store { i64, [1 x i64] } %t52, ptr %l26
  br label %bb7
bb7:
  %t53 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb21
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb21
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb21
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l23, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l24, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb21
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t62 = load ptr, ptr %l29, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l29, !tbaa !29
  %t66 = load i64, ptr %t65
  %t68 = icmp eq i64 %t66, 4
  store i1 %t68, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t69 = load i1, ptr %l30, !tbaa !21
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l1
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t76 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t76, ptr %l4
  br label %bb67
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t79 = load ptr, ptr %l36, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l36, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb43
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t94 = load ptr, ptr %l42, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l42, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l43, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l43, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [3 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb43
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l48, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l49, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l49, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb43
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t124 = load ptr, ptr %l54, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l54, !tbaa !29
  %t128 = load i64, ptr %t127
  %t130 = icmp eq i64 %t128, 8
  store i1 %t130, ptr %l55, !tbaa !21
  br label %bb36
bb36:
  %t131 = load i1, ptr %l55, !tbaa !21
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l2
  br label %bb43
bb38:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t139 = load ptr, ptr %l60, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb39, label %bb40
bb39:
  %t142 = load ptr, ptr %l60, !tbaa !29
  %t143 = load i64, ptr %t142
  %t145 = icmp eq i64 %t143, 9
  store i1 %t145, ptr %l61, !tbaa !21
  br label %bb40
bb40:
  %t146 = load i1, ptr %l61, !tbaa !21
  br i1 %t146, label %bb41, label %bb42
bb41:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  store %"compiler/source:Span" %t151, ptr %l2
  br label %bb43
bb42:
  br label %bb44
bb43:
  %t153 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t153, ptr %l4
  br label %bb67
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t156 = load ptr, ptr %l67, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l67, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l68, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l68, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb65
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t171 = load ptr, ptr %l73, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l73, !tbaa !29
  %t175 = load i64, ptr %t174
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l74, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l74, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb65
bb52:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t186 = load ptr, ptr %l79, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb53, label %bb54
bb53:
  %t189 = load ptr, ptr %l79, !tbaa !29
  %t190 = load i64, ptr %t189
  %t192 = icmp eq i64 %t190, 12
  store i1 %t192, ptr %l80, !tbaa !21
  br label %bb54
bb54:
  %t193 = load i1, ptr %l80, !tbaa !21
  br i1 %t193, label %bb55, label %bb56
bb55:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr }, ptr %t196, i32 0, i32 0
  %t198 = load %"compiler/source:Span", ptr %t197
  store %"compiler/source:Span" %t198, ptr %l3
  br label %bb65
bb56:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t201 = load ptr, ptr %l85, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb57, label %bb58
bb57:
  %t204 = load ptr, ptr %l85, !tbaa !29
  %t205 = load i64, ptr %t204
  %t207 = icmp eq i64 %t205, 13
  store i1 %t207, ptr %l86, !tbaa !21
  br label %bb58
bb58:
  %t208 = load i1, ptr %l86, !tbaa !21
  br i1 %t208, label %bb59, label %bb60
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr { i64, [3 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", ptr }, ptr %t211, i32 0, i32 0
  %t213 = load %"compiler/source:Span", ptr %t212
  store %"compiler/source:Span" %t213, ptr %l3
  br label %bb65
bb60:
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t216 = load ptr, ptr %l91, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb61, label %bb62
bb61:
  %t219 = load ptr, ptr %l91, !tbaa !29
  %t220 = load i64, ptr %t219
  %t222 = icmp eq i64 %t220, 14
  store i1 %t222, ptr %l92, !tbaa !21
  br label %bb62
bb62:
  %t223 = load i1, ptr %l92, !tbaa !21
  br i1 %t223, label %bb63, label %bb64
bb63:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr { i64, [3 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", ptr }, ptr %t226, i32 0, i32 0
  %t228 = load %"compiler/source:Span", ptr %t227
  store %"compiler/source:Span" %t228, ptr %l3
  br label %bb65
bb64:
  br label %bb66
bb65:
  %t230 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_d42dce2e5a8639a6_22ec82fe09d5fbba)
  unreachable
bb67:
  %t232 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t232, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l22 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t4 = sub i64 %t2, 1
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 0
  %t12 = sext i32 %t8 to i64
  %t13 = call i64 @__olang_fmt_i64(ptr null, i64 %t12)
  %t14 = add i64 %t10, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t9, i64 %t10)
  %t16 = getelementptr i8, ptr %t15, i64 %t10
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s0, ptr %t1, i64 %t4, { i64, ptr } %t26)
  br label %bb1
bb1:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Block", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t47, ptr %l22, !tbaa !27
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %t55, ptr %t53, i64 %t57)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb7
bb7:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca i32
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 0
  %t20 = sext i32 %t16 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  br label %bb29
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = extractvalue { i64, ptr } { i64 7, ptr @.d6 }, 1
  %t46 = extractvalue { i64, ptr } { i64 7, ptr @.d6 }, 0
  %t48 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t49 = add i64 %t46, %t48
  %t50 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t49)
  call void @olang_textcopy(ptr %t50, ptr %t45, i64 %t46)
  %t51 = getelementptr i8, ptr %t50, i64 %t46
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t44)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t50, 1
  store { i64, ptr } %t54, ptr %l7, !tbaa !27
  br label %bb29
bb12:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t57 = load ptr, ptr %l24, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = load ptr, ptr %l24, !tbaa !29
  %t61 = load i64, ptr %t60
  %t63 = icmp eq i64 %t61, 2
  store i1 %t63, ptr %l25, !tbaa !21
  br label %bb14
bb14:
  %t64 = load i1, ptr %l25, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [1 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { ptr }, ptr %t67, i32 0, i32 0
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t76 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t71, ptr %t72)
  store { i64, ptr } %t76, ptr %l33
  br label %bb18
bb18:
  %t77 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t80 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t78, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb19:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t85 = load ptr, ptr %l35, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb20, label %bb21
bb20:
  %t88 = load ptr, ptr %l35, !tbaa !29
  %t89 = load i64, ptr %t88
  %t91 = icmp eq i64 %t89, 3
  store i1 %t91, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l36, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [1 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { i32, i32 }, ptr %t95, i32 0, i32 0
  %t97 = load i32, ptr %t96
  store i32 %t97, ptr %l5
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr { i64, [1 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { i32, i32 }, ptr %t101, i32 0, i32 1
  %t103 = load i32, ptr %t102
  store i32 %t103, ptr %l6, !tbaa !23
  br label %bb24
bb23:
  br label %bb28
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t105 = load i32, ptr %l5
  store i32 %t105, ptr %l43
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aHelper(ptr %s8, ptr %l43, i64 0)
  br label %bb25
bb25:
  %t107 = load ptr, ptr %s8
  %t108 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t109 = load i64, ptr %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t107, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  %t113 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t114 = load ptr, ptr %t113
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %sbgrew.116, label %sbdone.117
sbgrew.116:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.117
sbdone.117:
  %t118 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s7, { i64, ptr } %t124)
  store { i64, ptr } %t126, ptr %l47
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/typed:printer", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load i32, ptr %l6, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s7, ptr %t130, i32 %t131)
  store { i64, ptr } %t134, ptr %l51
  br label %bb27
bb27:
  %t135 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 0
  %t140 = add i64 %t137, %t139
  %t141 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = add i64 %t140, %t143
  %t145 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t136, i64 %t137)
  %t146 = getelementptr i8, ptr %t145, i64 %t137
  call void @olang_textcopy(ptr %t146, ptr %t138, i64 %t139)
  %t147 = getelementptr i8, ptr %t146, i64 %t139
  call void @olang_textcopy(ptr %t147, ptr %t142, i64 %t143)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t145, 1
  store { i64, ptr } %t149, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_c13c66c7f09ff87e_38ebe5e5af81f22)
  unreachable
bb29:
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t151, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l59 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca i1
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca i1
  %l98 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l116 = alloca i1
  %l124 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l133 = alloca i1
  %l139 = alloca i32
  %l141 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l151 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i1
  %l170 = alloca i32
  %l172 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca i32
  %l181 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l192 = alloca i1
  %l200 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l212 = alloca ptr
  %l213 = alloca i1
  %l222 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l233 = alloca ptr
  %l234 = alloca i1
  %l241 = alloca i64
  %l245 = alloca { i64, ptr }
  %l247 = alloca ptr
  %l248 = alloca i1
  %l255 = alloca i64
  %l270 = alloca ptr
  %l271 = alloca i1
  %l279 = alloca { i64, ptr }
  %l284 = alloca ptr
  %l285 = alloca i1
  %l292 = alloca ptr
  %l293 = alloca i1
  %l304 = alloca ptr
  %l305 = alloca i1
  %l312 = alloca i64
  %l316 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.builder
  %s23room = alloca [64 x i8], align 8
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 1, ptr @.d8 }, ptr %l29, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t5, ptr %l30, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l31, !tbaa !24
  %t8 = load i64, ptr %l31, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l32, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l31, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t19, ptr %l30, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/typed:printer", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l34, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t25)
  store i32 %t27, ptr %l36
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l34, !tbaa !29
  %t29 = load i32, ptr %l36, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s0, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l37
  br label %bb5
bb5:
  %t31 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t31, ptr %l2, !tbaa !27
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t33 = load ptr, ptr %l39, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l39, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 0
  store i1 %t39, ptr %l40, !tbaa !21
  br label %bb7
bb7:
  %t40 = load i1, ptr %l40, !tbaa !21
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t43, i32 0, i32 2
  %t45 = load i64, ptr %t44
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = extractvalue { i64, ptr } { i64 5, ptr @.d9 }, 1
  %t50 = extractvalue { i64, ptr } { i64 5, ptr @.d9 }, 0
  %t52 = extractvalue { i64, ptr } %t47, 1
  %t53 = extractvalue { i64, ptr } %t47, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 0
  %t57 = add i64 %t54, %t56
  %t59 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t60 = add i64 %t57, %t59
  %t61 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 1
  %t62 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t49, i64 %t50)
  %t65 = getelementptr i8, ptr %t64, i64 %t50
  call void @olang_textcopy(ptr %t65, ptr %t52, i64 %t53)
  %t66 = getelementptr i8, ptr %t65, i64 %t53
  call void @olang_textcopy(ptr %t66, ptr %t55, i64 %t56)
  %t67 = getelementptr i8, ptr %t66, i64 %t56
  %t68 = call i64 @__olang_fmt_i64(ptr %t67, i64 %t48)
  %t69 = getelementptr i8, ptr %t67, i64 %t59
  call void @olang_textcopy(ptr %t69, ptr %t61, i64 %t62)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  store { i64, ptr } %t71, ptr %l38, !tbaa !27
  br label %bb150
bb11:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t74 = load ptr, ptr %l48, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb12, label %bb13
bb12:
  %t77 = load ptr, ptr %l48, !tbaa !29
  %t78 = load i64, ptr %t77
  %t80 = icmp eq i64 %t78, 1
  store i1 %t80, ptr %l49, !tbaa !21
  br label %bb13
bb13:
  %t81 = load i1, ptr %l49, !tbaa !21
  br i1 %t81, label %bb14, label %bb15
bb14:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load i64, ptr %t85
  store i64 %t86, ptr %l4, !tbaa !24
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t90, i32 0, i32 3
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t94, ptr %l56, !tbaa !27
  %t95 = load i64, ptr %l4, !tbaa !24
  store i64 %t95, ptr %l57, !tbaa !24
  %t96 = load ptr, ptr %l5, !tbaa !29
  %t98 = call { i64, ptr } @compiler_2ftyped_2econstText(ptr %v1, ptr %s4, ptr %t96)
  store { i64, ptr } %t98, ptr %l59
  br label %bb17
bb17:
  %t99 = extractvalue { i64, ptr } { i64 6, ptr @.d12 }, 1
  %t100 = extractvalue { i64, ptr } { i64 6, ptr @.d12 }, 0
  %t101 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = add i64 %t100, %t103
  %t105 = extractvalue { i64, ptr } { i64 1, ptr @.d13 }, 1
  %t106 = extractvalue { i64, ptr } { i64 1, ptr @.d13 }, 0
  %t107 = add i64 %t104, %t106
  %t108 = load i64, ptr %l57, !tbaa !24
  %t109 = call i64 @__olang_fmt_i64(ptr null, i64 %t108)
  %t110 = add i64 %t107, %t109
  %t111 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 1
  %t112 = extractvalue { i64, ptr } { i64 1, ptr @.d14 }, 0
  %t113 = add i64 %t110, %t112
  %t114 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 0
  %t120 = add i64 %t117, %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t99, i64 %t100)
  %t122 = getelementptr i8, ptr %t121, i64 %t100
  call void @olang_textcopy(ptr %t122, ptr %t102, i64 %t103)
  %t123 = getelementptr i8, ptr %t122, i64 %t103
  call void @olang_textcopy(ptr %t123, ptr %t105, i64 %t106)
  %t124 = getelementptr i8, ptr %t123, i64 %t106
  %t125 = call i64 @__olang_fmt_i64(ptr %t124, i64 %t108)
  %t126 = getelementptr i8, ptr %t124, i64 %t109
  call void @olang_textcopy(ptr %t126, ptr %t111, i64 %t112)
  %t127 = getelementptr i8, ptr %t126, i64 %t112
  call void @olang_textcopy(ptr %t127, ptr %t115, i64 %t116)
  %t128 = getelementptr i8, ptr %t127, i64 %t116
  call void @olang_textcopy(ptr %t128, ptr %t118, i64 %t119)
  %t129 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t121, 1
  store { i64, ptr } %t130, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb150
bb18:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t133 = load ptr, ptr %l61, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb19, label %bb20
bb19:
  %t136 = load ptr, ptr %l61, !tbaa !29
  %t137 = load i64, ptr %t136
  %t139 = icmp eq i64 %t137, 2
  store i1 %t139, ptr %l62, !tbaa !21
  br label %bb20
bb20:
  %t140 = load i1, ptr %l62, !tbaa !21
  br i1 %t140, label %bb21, label %bb22
bb21:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t143, i32 0, i32 2
  %t145 = load ptr, ptr %t144
  store ptr %t145, ptr %l6, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t149, i32 0, i32 3
  %t151 = load i32, ptr %t150
  store i32 %t151, ptr %l7, !tbaa !23
  br label %bb23
bb22:
  br label %bb28
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l6, !tbaa !29
  %t157 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s6, ptr %t153, ptr %t154)
  store { i64, ptr } %t157, ptr %l71
  br label %bb24
bb24:
  %t158 = load i32, ptr %l7, !tbaa !23
  %t160 = icmp sge i32 %t158, 0
  br i1 %t160, label %bb25, label %bb26
bb25:
  %t162 = load i32, ptr %l7, !tbaa !23
  %t163 = extractvalue { i64, ptr } { i64 6, ptr @.d16 }, 1
  %t164 = extractvalue { i64, ptr } { i64 6, ptr @.d16 }, 0
  %t166 = sext i32 %t162 to i64
  %t167 = call i64 @__olang_fmt_i64(ptr null, i64 %t166)
  %t168 = add i64 %t164, %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t163, i64 %t164)
  %t170 = getelementptr i8, ptr %t169, i64 %t164
  %t171 = call i64 @__olang_fmt_i64(ptr %t170, i64 %t166)
  %t172 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t169, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  store { i64, ptr } %t180, ptr %l74, !tbaa !27
  br label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr @.d17 }, ptr %l74, !tbaa !27
  br label %bb27
bb27:
  %t182 = extractvalue { i64, ptr } { i64 6, ptr @.d18 }, 1
  %t183 = extractvalue { i64, ptr } { i64 6, ptr @.d18 }, 0
  %t184 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = add i64 %t183, %t186
  %t188 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = add i64 %t187, %t190
  %t192 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 1
  %t193 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 0
  %t194 = add i64 %t191, %t193
  %t195 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t182, i64 %t183)
  %t196 = getelementptr i8, ptr %t195, i64 %t183
  call void @olang_textcopy(ptr %t196, ptr %t185, i64 %t186)
  %t197 = getelementptr i8, ptr %t196, i64 %t186
  call void @olang_textcopy(ptr %t197, ptr %t189, i64 %t190)
  %t198 = getelementptr i8, ptr %t197, i64 %t190
  call void @olang_textcopy(ptr %t198, ptr %t192, i64 %t193)
  %t199 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t195, 1
  store { i64, ptr } %t200, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb150
bb28:
  %t202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t202, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t203 = load ptr, ptr %l79, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb29, label %bb30
bb29:
  %t206 = load ptr, ptr %l79, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 3
  store i1 %t209, ptr %l80, !tbaa !21
  br label %bb30
bb30:
  %t210 = load i1, ptr %l80, !tbaa !21
  br i1 %t210, label %bb31, label %bb32
bb31:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 2
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l8, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t217 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t217, ptr %l85, !tbaa !27
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l8, !tbaa !29
  %t222 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s9, ptr %t218, ptr %t219)
  store { i64, ptr } %t222, ptr %l88
  br label %bb34
bb34:
  %t223 = extractvalue { i64, ptr } { i64 8, ptr @.d20 }, 1
  %t224 = extractvalue { i64, ptr } { i64 8, ptr @.d20 }, 0
  %t225 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 1
  %t227 = extractvalue { i64, ptr } %t225, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 0
  %t231 = add i64 %t228, %t230
  %t232 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 1
  %t237 = extractvalue { i64, ptr } { i64 1, ptr @.d22 }, 0
  %t238 = add i64 %t235, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t223, i64 %t224)
  %t240 = getelementptr i8, ptr %t239, i64 %t224
  call void @olang_textcopy(ptr %t240, ptr %t226, i64 %t227)
  %t241 = getelementptr i8, ptr %t240, i64 %t227
  call void @olang_textcopy(ptr %t241, ptr %t229, i64 %t230)
  %t242 = getelementptr i8, ptr %t241, i64 %t230
  call void @olang_textcopy(ptr %t242, ptr %t233, i64 %t234)
  %t243 = getelementptr i8, ptr %t242, i64 %t234
  call void @olang_textcopy(ptr %t243, ptr %t236, i64 %t237)
  %t244 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t239, 1
  store { i64, ptr } %t245, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb150
bb35:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t248 = load ptr, ptr %l90, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb36, label %bb37
bb36:
  %t251 = load ptr, ptr %l90, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 4
  store i1 %t254, ptr %l91, !tbaa !21
  br label %bb37
bb37:
  %t255 = load i1, ptr %l91, !tbaa !21
  br i1 %t255, label %bb38, label %bb39
bb38:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l9, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  store %olang.scope zeroinitializer, ptr %s11
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l9, !tbaa !29
  %t266 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s11, ptr %t262, ptr %t263)
  store { i64, ptr } %t266, ptr %l98
  br label %bb41
bb41:
  %t267 = extractvalue { i64, ptr } { i64 6, ptr @.d23 }, 1
  %t268 = extractvalue { i64, ptr } { i64 6, ptr @.d23 }, 0
  %t269 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 1
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t272 = add i64 %t268, %t271
  %t273 = extractvalue { i64, ptr } { i64 1, ptr @.d24 }, 1
  %t274 = extractvalue { i64, ptr } { i64 1, ptr @.d24 }, 0
  %t275 = add i64 %t272, %t274
  %t276 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t275)
  call void @olang_textcopy(ptr %t276, ptr %t267, i64 %t268)
  %t277 = getelementptr i8, ptr %t276, i64 %t268
  call void @olang_textcopy(ptr %t277, ptr %t270, i64 %t271)
  %t278 = getelementptr i8, ptr %t277, i64 %t271
  call void @olang_textcopy(ptr %t278, ptr %t273, i64 %t274)
  %t279 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t276, 1
  store { i64, ptr } %t280, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb150
bb42:
  %t282 = load ptr, ptr %l1, !tbaa !29
  store ptr %t282, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t283 = load ptr, ptr %l100, !tbaa !29
  %t284 = icmp ne ptr %t283, null
  br i1 %t284, label %bb43, label %bb44
bb43:
  %t286 = load ptr, ptr %l100, !tbaa !29
  %t287 = load i64, ptr %t286
  %t289 = icmp eq i64 %t287, 5
  store i1 %t289, ptr %l101, !tbaa !21
  br label %bb44
bb44:
  %t290 = load i1, ptr %l101, !tbaa !21
  br i1 %t290, label %bb45, label %bb46
bb45:
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [5 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t293, i32 0, i32 2
  %t295 = load ptr, ptr %t294
  store ptr %t295, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  %t297 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t297, ptr %l106, !tbaa !27
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l10, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Promote", ptr %t299, i32 0, i32 0
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t306 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s13, ptr %t298, ptr %t302)
  store { i64, ptr } %t306, ptr %l111
  br label %bb48
bb48:
  %t307 = load ptr, ptr %l10, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Promote", ptr %t307, i32 0, i32 1
  %t310 = load i32, ptr %t309, !tbaa !23
  %t311 = extractvalue { i64, ptr } { i64 9, ptr @.d25 }, 1
  %t312 = extractvalue { i64, ptr } { i64 9, ptr @.d25 }, 0
  %t313 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t316 = add i64 %t312, %t315
  %t317 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 1
  %t318 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 0
  %t319 = add i64 %t316, %t318
  %t320 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = add i64 %t319, %t322
  %t324 = extractvalue { i64, ptr } { i64 6, ptr @.d27 }, 1
  %t325 = extractvalue { i64, ptr } { i64 6, ptr @.d27 }, 0
  %t326 = add i64 %t323, %t325
  %t328 = sext i32 %t310 to i64
  %t329 = call i64 @__olang_fmt_i64(ptr null, i64 %t328)
  %t330 = add i64 %t326, %t329
  %t331 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 1
  %t332 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 0
  %t333 = add i64 %t330, %t332
  %t334 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t333)
  call void @olang_textcopy(ptr %t334, ptr %t311, i64 %t312)
  %t335 = getelementptr i8, ptr %t334, i64 %t312
  call void @olang_textcopy(ptr %t335, ptr %t314, i64 %t315)
  %t336 = getelementptr i8, ptr %t335, i64 %t315
  call void @olang_textcopy(ptr %t336, ptr %t317, i64 %t318)
  %t337 = getelementptr i8, ptr %t336, i64 %t318
  call void @olang_textcopy(ptr %t337, ptr %t321, i64 %t322)
  %t338 = getelementptr i8, ptr %t337, i64 %t322
  call void @olang_textcopy(ptr %t338, ptr %t324, i64 %t325)
  %t339 = getelementptr i8, ptr %t338, i64 %t325
  %t340 = call i64 @__olang_fmt_i64(ptr %t339, i64 %t328)
  %t341 = getelementptr i8, ptr %t339, i64 %t329
  call void @olang_textcopy(ptr %t341, ptr %t331, i64 %t332)
  %t342 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t334, 1
  store { i64, ptr } %t343, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb150
bb49:
  %t345 = load ptr, ptr %l1, !tbaa !29
  store ptr %t345, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t346 = load ptr, ptr %l115, !tbaa !29
  %t347 = icmp ne ptr %t346, null
  br i1 %t347, label %bb50, label %bb51
bb50:
  %t349 = load ptr, ptr %l115, !tbaa !29
  %t350 = load i64, ptr %t349
  %t352 = icmp eq i64 %t350, 6
  store i1 %t352, ptr %l116, !tbaa !21
  br label %bb51
bb51:
  %t353 = load i1, ptr %l116, !tbaa !21
  br i1 %t353, label %bb52, label %bb53
bb52:
  %t354 = load ptr, ptr %l1, !tbaa !29
  %t356 = getelementptr { i64, [5 x i64] }, ptr %t354, i32 0, i32 1
  %t357 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t356, i32 0, i32 2
  %t358 = load ptr, ptr %t357
  store ptr %t358, ptr %l11, !tbaa !29
  br label %bb54
bb53:
  br label %bb57
bb54:
  store %olang.scope zeroinitializer, ptr %s15
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load ptr, ptr %l11, !tbaa !29
  %t363 = getelementptr %"compiler/typed:Call", ptr %t361, i32 0, i32 0
  %t364 = load ptr, ptr %t363, !tbaa !29
  %t367 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2ecallee(ptr %v0, ptr %v1, ptr %s15, ptr %t360, ptr %t364)
  store { i64, ptr } %t367, ptr %l124
  br label %bb55
bb55:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load ptr, ptr %l11, !tbaa !29
  %t371 = getelementptr %"compiler/typed:Call", ptr %t369, i32 0, i32 1
  %t372 = load { i64, ptr }, ptr %t371, !tbaa !27
  %t375 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s15, ptr %t368, { i64, ptr } %t372)
  store { i64, ptr } %t375, ptr %l128
  br label %bb56
bb56:
  %t376 = load ptr, ptr %l11, !tbaa !29
  %t378 = getelementptr %"compiler/typed:Call", ptr %t376, i32 0, i32 3
  %t379 = load i32, ptr %t378, !tbaa !23
  %t380 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 1
  %t381 = extractvalue { i64, ptr } { i64 6, ptr @.d29 }, 0
  %t382 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t383 = extractvalue { i64, ptr } %t382, 1
  %t384 = extractvalue { i64, ptr } %t382, 0
  %t385 = add i64 %t381, %t384
  %t386 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 1
  %t387 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 0
  %t388 = add i64 %t385, %t387
  %t389 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = add i64 %t388, %t391
  %t393 = extractvalue { i64, ptr } { i64 6, ptr @.d31 }, 1
  %t394 = extractvalue { i64, ptr } { i64 6, ptr @.d31 }, 0
  %t395 = add i64 %t392, %t394
  %t397 = sext i32 %t379 to i64
  %t398 = call i64 @__olang_fmt_i64(ptr null, i64 %t397)
  %t399 = add i64 %t395, %t398
  %t400 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 1
  %t401 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 0
  %t402 = add i64 %t399, %t401
  %t403 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t380, i64 %t381)
  %t404 = getelementptr i8, ptr %t403, i64 %t381
  call void @olang_textcopy(ptr %t404, ptr %t383, i64 %t384)
  %t405 = getelementptr i8, ptr %t404, i64 %t384
  call void @olang_textcopy(ptr %t405, ptr %t386, i64 %t387)
  %t406 = getelementptr i8, ptr %t405, i64 %t387
  call void @olang_textcopy(ptr %t406, ptr %t390, i64 %t391)
  %t407 = getelementptr i8, ptr %t406, i64 %t391
  call void @olang_textcopy(ptr %t407, ptr %t393, i64 %t394)
  %t408 = getelementptr i8, ptr %t407, i64 %t394
  %t409 = call i64 @__olang_fmt_i64(ptr %t408, i64 %t397)
  %t410 = getelementptr i8, ptr %t408, i64 %t398
  call void @olang_textcopy(ptr %t410, ptr %t400, i64 %t401)
  %t411 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t403, 1
  store { i64, ptr } %t412, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  br label %bb150
bb57:
  %t414 = load ptr, ptr %l1, !tbaa !29
  store ptr %t414, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t415 = load ptr, ptr %l132, !tbaa !29
  %t416 = icmp ne ptr %t415, null
  br i1 %t416, label %bb58, label %bb59
bb58:
  %t418 = load ptr, ptr %l132, !tbaa !29
  %t419 = load i64, ptr %t418
  %t421 = icmp eq i64 %t419, 7
  store i1 %t421, ptr %l133, !tbaa !21
  br label %bb59
bb59:
  %t422 = load i1, ptr %l133, !tbaa !21
  br i1 %t422, label %bb60, label %bb61
bb60:
  %t423 = load ptr, ptr %l1, !tbaa !29
  %t425 = getelementptr { i64, [5 x i64] }, ptr %t423, i32 0, i32 1
  %t426 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t425, i32 0, i32 2
  %t427 = load ptr, ptr %t426
  store ptr %t427, ptr %l12, !tbaa !29
  br label %bb62
bb61:
  br label %bb66
bb62:
  store %olang.scope zeroinitializer, ptr %s17
  %t429 = load ptr, ptr %l12, !tbaa !29
  %t431 = getelementptr %"compiler/typed:Make", ptr %t429, i32 0, i32 0
  %t432 = load i32, ptr %t431
  store i32 %t432, ptr %l139
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aMakeKind(ptr %s18, ptr %l139, i64 0)
  br label %bb63
bb63:
  %t434 = load ptr, ptr %s18
  %t435 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t436 = load i64, ptr %t435
  %t437 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t436)
  call void @olang_textcopy(ptr %t437, ptr %t434, i64 %t436)
  %t438 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t437, 1
  store { i64, ptr } %t439, ptr %l141, !tbaa !27
  %t440 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t441 = load ptr, ptr %t440
  %t442 = icmp ne ptr %t441, null
  br i1 %t442, label %sbgrew.443, label %sbdone.444
sbgrew.443:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.444
sbdone.444:
  %t445 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t445, 0
  %t447 = extractvalue { i64, ptr } %t445, 1
  %t448 = mul i64 %t446, 1
  %t449 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t448)
  call void @llvm.memcpy.p0.p0.i64(ptr %t449, ptr %t447, i64 %t448, i1 false)
  %t450 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t449, 1
  %t453 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s17, { i64, ptr } %t451)
  store { i64, ptr } %t453, ptr %l143
  br label %bb64
bb64:
  %t454 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t454, ptr %l144, !tbaa !27
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load ptr, ptr %l12, !tbaa !29
  %t458 = getelementptr %"compiler/typed:Make", ptr %t456, i32 0, i32 2
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  %t462 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s17, ptr %t455, { i64, ptr } %t459)
  store { i64, ptr } %t462, ptr %l148
  br label %bb65
bb65:
  %t463 = extractvalue { i64, ptr } { i64 6, ptr @.d33 }, 1
  %t464 = extractvalue { i64, ptr } { i64 6, ptr @.d33 }, 0
  %t465 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 1
  %t467 = extractvalue { i64, ptr } %t465, 0
  %t468 = add i64 %t464, %t467
  %t469 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 1
  %t470 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 0
  %t471 = add i64 %t468, %t470
  %t472 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t472, 1
  %t474 = extractvalue { i64, ptr } %t472, 0
  %t475 = add i64 %t471, %t474
  %t476 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 1
  %t477 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 0
  %t478 = add i64 %t475, %t477
  %t479 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t479, 1
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t482 = add i64 %t478, %t481
  %t483 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 1
  %t484 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 0
  %t485 = add i64 %t482, %t484
  %t486 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t485)
  call void @olang_textcopy(ptr %t486, ptr %t463, i64 %t464)
  %t487 = getelementptr i8, ptr %t486, i64 %t464
  call void @olang_textcopy(ptr %t487, ptr %t466, i64 %t467)
  %t488 = getelementptr i8, ptr %t487, i64 %t467
  call void @olang_textcopy(ptr %t488, ptr %t469, i64 %t470)
  %t489 = getelementptr i8, ptr %t488, i64 %t470
  call void @olang_textcopy(ptr %t489, ptr %t473, i64 %t474)
  %t490 = getelementptr i8, ptr %t489, i64 %t474
  call void @olang_textcopy(ptr %t490, ptr %t476, i64 %t477)
  %t491 = getelementptr i8, ptr %t490, i64 %t477
  call void @olang_textcopy(ptr %t491, ptr %t480, i64 %t481)
  %t492 = getelementptr i8, ptr %t491, i64 %t481
  call void @olang_textcopy(ptr %t492, ptr %t483, i64 %t484)
  %t493 = insertvalue { i64, ptr } undef, i64 %t485, 0
  %t494 = insertvalue { i64, ptr } %t493, ptr %t486, 1
  store { i64, ptr } %t494, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb150
bb66:
  %t496 = load ptr, ptr %l1, !tbaa !29
  store ptr %t496, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t497 = load ptr, ptr %l150, !tbaa !29
  %t498 = icmp ne ptr %t497, null
  br i1 %t498, label %bb67, label %bb68
bb67:
  %t500 = load ptr, ptr %l150, !tbaa !29
  %t501 = load i64, ptr %t500
  %t503 = icmp eq i64 %t501, 8
  store i1 %t503, ptr %l151, !tbaa !21
  br label %bb68
bb68:
  %t504 = load i1, ptr %l151, !tbaa !21
  br i1 %t504, label %bb69, label %bb70
bb69:
  %t505 = load ptr, ptr %l1, !tbaa !29
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t507, i32 0, i32 2
  %t509 = load ptr, ptr %t508
  store ptr %t509, ptr %l13, !tbaa !29
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t511 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t512 = load ptr, ptr %l13, !tbaa !29
  %t514 = getelementptr %"compiler/typed:Collect", ptr %t512, i32 0, i32 2
  %t515 = load i32, ptr %t514, !tbaa !23
  %t516 = extractvalue { i64, ptr } { i64 9, ptr @.d37 }, 1
  %t517 = extractvalue { i64, ptr } { i64 9, ptr @.d37 }, 0
  %t519 = extractvalue { i64, ptr } %t511, 1
  %t520 = extractvalue { i64, ptr } %t511, 0
  %t521 = add i64 %t517, %t520
  %t522 = extractvalue { i64, ptr } { i64 6, ptr @.d38 }, 1
  %t523 = extractvalue { i64, ptr } { i64 6, ptr @.d38 }, 0
  %t524 = add i64 %t521, %t523
  %t526 = sext i32 %t515 to i64
  %t527 = call i64 @__olang_fmt_i64(ptr null, i64 %t526)
  %t528 = add i64 %t524, %t527
  %t529 = extractvalue { i64, ptr } { i64 1, ptr @.d39 }, 1
  %t530 = extractvalue { i64, ptr } { i64 1, ptr @.d39 }, 0
  %t531 = add i64 %t528, %t530
  %t532 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t531)
  call void @olang_textcopy(ptr %t532, ptr %t516, i64 %t517)
  %t533 = getelementptr i8, ptr %t532, i64 %t517
  call void @olang_textcopy(ptr %t533, ptr %t519, i64 %t520)
  %t534 = getelementptr i8, ptr %t533, i64 %t520
  call void @olang_textcopy(ptr %t534, ptr %t522, i64 %t523)
  %t535 = getelementptr i8, ptr %t534, i64 %t523
  %t536 = call i64 @__olang_fmt_i64(ptr %t535, i64 %t526)
  %t537 = getelementptr i8, ptr %t535, i64 %t527
  call void @olang_textcopy(ptr %t537, ptr %t529, i64 %t530)
  %t538 = insertvalue { i64, ptr } undef, i64 %t531, 0
  %t539 = insertvalue { i64, ptr } %t538, ptr %t532, 1
  store { i64, ptr } %t539, ptr %l38, !tbaa !27
  br label %bb150
bb72:
  %t541 = load ptr, ptr %l1, !tbaa !29
  store ptr %t541, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t542 = load ptr, ptr %l160, !tbaa !29
  %t543 = icmp ne ptr %t542, null
  br i1 %t543, label %bb73, label %bb74
bb73:
  %t545 = load ptr, ptr %l160, !tbaa !29
  %t546 = load i64, ptr %t545
  %t548 = icmp eq i64 %t546, 9
  store i1 %t548, ptr %l161, !tbaa !21
  br label %bb74
bb74:
  %t549 = load i1, ptr %l161, !tbaa !21
  br i1 %t549, label %bb75, label %bb76
bb75:
  %t550 = load ptr, ptr %l1, !tbaa !29
  %t552 = getelementptr { i64, [5 x i64] }, ptr %t550, i32 0, i32 1
  %t553 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t552, i32 0, i32 2
  %t554 = load i32, ptr %t553
  store i32 %t554, ptr %l14
  %t556 = load ptr, ptr %l1, !tbaa !29
  %t558 = getelementptr { i64, [5 x i64] }, ptr %t556, i32 0, i32 1
  %t559 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t558, i32 0, i32 3
  %t560 = load i32, ptr %t559
  store i32 %t560, ptr %l15
  %t562 = load ptr, ptr %l1, !tbaa !29
  %t564 = getelementptr { i64, [5 x i64] }, ptr %t562, i32 0, i32 1
  %t565 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t564, i32 0, i32 4
  %t566 = load { i64, ptr }, ptr %t565
  store { i64, ptr } %t566, ptr %l16, !tbaa !27
  br label %bb77
bb76:
  br label %bb86
bb77:
  store %olang.scope zeroinitializer, ptr %s22
  %t568 = load i32, ptr %l14
  store i32 %t568, ptr %l170
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s23
  store ptr %s23room, ptr %s23
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s23, ptr %l170, i64 0)
  br label %bb78
bb78:
  %t570 = load ptr, ptr %s23
  %t571 = getelementptr %olang.builder, ptr %s23, i32 0, i32 1
  %t572 = load i64, ptr %t571
  %t573 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t572)
  call void @olang_textcopy(ptr %t573, ptr %t570, i64 %t572)
  %t574 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t575 = insertvalue { i64, ptr } %t574, ptr %t573, 1
  store { i64, ptr } %t575, ptr %l172, !tbaa !27
  %t576 = getelementptr %olang.builder, ptr %s23, i32 0, i32 3
  %t577 = load ptr, ptr %t576
  %t578 = icmp ne ptr %t577, null
  br i1 %t578, label %sbgrew.579, label %sbdone.580
sbgrew.579:
  call void @__olang_sb_done(ptr %s23)
  br label %sbdone.580
sbdone.580:
  %t581 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t582 = extractvalue { i64, ptr } %t581, 0
  %t583 = extractvalue { i64, ptr } %t581, 1
  %t584 = mul i64 %t582, 1
  %t585 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t584)
  call void @llvm.memcpy.p0.p0.i64(ptr %t585, ptr %t583, i64 %t584, i1 false)
  %t586 = insertvalue { i64, ptr } undef, i64 %t582, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t585, 1
  %t589 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s22, { i64, ptr } %t587)
  store { i64, ptr } %t589, ptr %l174
  br label %bb79
bb79:
  %t590 = load i32, ptr %l15
  %t592 = trunc i64 0 to i32
  %t593 = icmp eq i32 %t590, %t592
  %t595 = xor i1 %t593, true
  br i1 %t595, label %bb80, label %bb81
bb80:
  %t597 = load i32, ptr %l15
  store i32 %t597, ptr %l179
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aCheck(ptr %s24, ptr %l179, i64 0)
  br label %bb82
bb81:
  store { i64, ptr } { i64 0, ptr @.d40 }, ptr %l178, !tbaa !27
  br label %bb84
bb82:
  %t599 = load ptr, ptr %s24
  %t600 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t601 = load i64, ptr %t600
  %t602 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t601)
  call void @olang_textcopy(ptr %t602, ptr %t599, i64 %t601)
  %t603 = insertvalue { i64, ptr } undef, i64 %t601, 0
  %t604 = insertvalue { i64, ptr } %t603, ptr %t602, 1
  store { i64, ptr } %t604, ptr %l181, !tbaa !27
  %t605 = getelementptr %olang.builder, ptr %s24, i32 0, i32 3
  %t606 = load ptr, ptr %t605
  %t607 = icmp ne ptr %t606, null
  br i1 %t607, label %sbgrew.608, label %sbdone.609
sbgrew.608:
  call void @__olang_sb_done(ptr %s24)
  br label %sbdone.609
sbdone.609:
  %t610 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t611 = extractvalue { i64, ptr } %t610, 0
  %t612 = extractvalue { i64, ptr } %t610, 1
  %t613 = mul i64 %t611, 1
  %t614 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t613)
  call void @llvm.memcpy.p0.p0.i64(ptr %t614, ptr %t612, i64 %t613, i1 false)
  %t615 = insertvalue { i64, ptr } undef, i64 %t611, 0
  %t616 = insertvalue { i64, ptr } %t615, ptr %t614, 1
  %t618 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s22, { i64, ptr } %t616)
  store { i64, ptr } %t618, ptr %l183
  br label %bb83
bb83:
  %t619 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 1
  %t620 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 0
  %t621 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t622 = extractvalue { i64, ptr } %t621, 1
  %t623 = extractvalue { i64, ptr } %t621, 0
  %t624 = add i64 %t620, %t623
  %t625 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t624)
  call void @olang_textcopy(ptr %t625, ptr %t619, i64 %t620)
  %t626 = getelementptr i8, ptr %t625, i64 %t620
  call void @olang_textcopy(ptr %t626, ptr %t622, i64 %t623)
  %t627 = insertvalue { i64, ptr } undef, i64 %t624, 0
  %t628 = insertvalue { i64, ptr } %t627, ptr %t625, 1
  %t630 = extractvalue { i64, ptr } %t628, 0
  %t631 = extractvalue { i64, ptr } %t628, 1
  %t632 = mul i64 %t630, 1
  %t633 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t632)
  call void @llvm.memcpy.p0.p0.i64(ptr %t633, ptr %t631, i64 %t632, i1 false)
  %t634 = insertvalue { i64, ptr } undef, i64 %t630, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t633, 1
  store { i64, ptr } %t635, ptr %l178, !tbaa !27
  br label %bb84
bb84:
  %t637 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t637, ptr %l186, !tbaa !27
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t639 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t642 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s22, ptr %t638, { i64, ptr } %t639)
  store { i64, ptr } %t642, ptr %l189
  br label %bb85
bb85:
  %t643 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 1
  %t644 = extractvalue { i64, ptr } { i64 1, ptr @.d42 }, 0
  %t645 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t646 = extractvalue { i64, ptr } %t645, 1
  %t647 = extractvalue { i64, ptr } %t645, 0
  %t648 = add i64 %t644, %t647
  %t649 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t650 = extractvalue { i64, ptr } %t649, 1
  %t651 = extractvalue { i64, ptr } %t649, 0
  %t652 = add i64 %t648, %t651
  %t653 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 1
  %t654 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 0
  %t655 = add i64 %t652, %t654
  %t656 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t657 = extractvalue { i64, ptr } %t656, 1
  %t658 = extractvalue { i64, ptr } %t656, 0
  %t659 = add i64 %t655, %t658
  %t660 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 1
  %t661 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 0
  %t662 = add i64 %t659, %t661
  %t663 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t664 = extractvalue { i64, ptr } %t663, 1
  %t665 = extractvalue { i64, ptr } %t663, 0
  %t666 = add i64 %t662, %t665
  %t667 = extractvalue { i64, ptr } { i64 1, ptr @.d45 }, 1
  %t668 = extractvalue { i64, ptr } { i64 1, ptr @.d45 }, 0
  %t669 = add i64 %t666, %t668
  %t670 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t669)
  call void @olang_textcopy(ptr %t670, ptr %t643, i64 %t644)
  %t671 = getelementptr i8, ptr %t670, i64 %t644
  call void @olang_textcopy(ptr %t671, ptr %t646, i64 %t647)
  %t672 = getelementptr i8, ptr %t671, i64 %t647
  call void @olang_textcopy(ptr %t672, ptr %t650, i64 %t651)
  %t673 = getelementptr i8, ptr %t672, i64 %t651
  call void @olang_textcopy(ptr %t673, ptr %t653, i64 %t654)
  %t674 = getelementptr i8, ptr %t673, i64 %t654
  call void @olang_textcopy(ptr %t674, ptr %t657, i64 %t658)
  %t675 = getelementptr i8, ptr %t674, i64 %t658
  call void @olang_textcopy(ptr %t675, ptr %t660, i64 %t661)
  %t676 = getelementptr i8, ptr %t675, i64 %t661
  call void @olang_textcopy(ptr %t676, ptr %t664, i64 %t665)
  %t677 = getelementptr i8, ptr %t676, i64 %t665
  call void @olang_textcopy(ptr %t677, ptr %t667, i64 %t668)
  %t678 = insertvalue { i64, ptr } undef, i64 %t669, 0
  %t679 = insertvalue { i64, ptr } %t678, ptr %t670, 1
  store { i64, ptr } %t679, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb150
bb86:
  %t681 = load ptr, ptr %l1, !tbaa !29
  store ptr %t681, ptr %l191, !tbaa !29
  store i1 false, ptr %l192, !tbaa !21
  %t682 = load ptr, ptr %l191, !tbaa !29
  %t683 = icmp ne ptr %t682, null
  br i1 %t683, label %bb87, label %bb88
bb87:
  %t685 = load ptr, ptr %l191, !tbaa !29
  %t686 = load i64, ptr %t685
  %t688 = icmp eq i64 %t686, 10
  store i1 %t688, ptr %l192, !tbaa !21
  br label %bb88
bb88:
  %t689 = load i1, ptr %l192, !tbaa !21
  br i1 %t689, label %bb89, label %bb90
bb89:
  %t690 = load ptr, ptr %l1, !tbaa !29
  %t692 = getelementptr { i64, [5 x i64] }, ptr %t690, i32 0, i32 1
  %t693 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t692, i32 0, i32 2
  %t694 = load ptr, ptr %t693
  store ptr %t694, ptr %l17, !tbaa !29
  br label %bb91
bb90:
  br label %bb95
bb91:
  store %olang.scope zeroinitializer, ptr %s27
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t697 = load ptr, ptr %l17, !tbaa !29
  %t699 = getelementptr %"compiler/typed:Slice", ptr %t697, i32 0, i32 0
  %t700 = load ptr, ptr %t699, !tbaa !29
  %t703 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s27, ptr %t696, ptr %t700)
  store { i64, ptr } %t703, ptr %l200
  br label %bb92
bb92:
  %t704 = load ptr, ptr %l0, !tbaa !29
  %t705 = load ptr, ptr %l17, !tbaa !29
  %t707 = getelementptr %"compiler/typed:Slice", ptr %t705, i32 0, i32 1
  %t708 = load ptr, ptr %t707, !tbaa !29
  %t712 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %t704, ptr %t708)
  store { i64, ptr } %t712, ptr %l205
  br label %bb93
bb93:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load ptr, ptr %l17, !tbaa !29
  %t716 = getelementptr %"compiler/typed:Slice", ptr %t714, i32 0, i32 2
  %t717 = load ptr, ptr %t716, !tbaa !29
  %t721 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %t713, ptr %t717)
  store { i64, ptr } %t721, ptr %l210
  br label %bb94
bb94:
  %t722 = extractvalue { i64, ptr } { i64 7, ptr @.d46 }, 1
  %t723 = extractvalue { i64, ptr } { i64 7, ptr @.d46 }, 0
  %t724 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t725 = extractvalue { i64, ptr } %t724, 1
  %t726 = extractvalue { i64, ptr } %t724, 0
  %t727 = add i64 %t723, %t726
  %t728 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 1
  %t729 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 0
  %t730 = add i64 %t727, %t729
  %t731 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t732 = extractvalue { i64, ptr } %t731, 1
  %t733 = extractvalue { i64, ptr } %t731, 0
  %t734 = add i64 %t730, %t733
  %t735 = extractvalue { i64, ptr } { i64 1, ptr @.d48 }, 1
  %t736 = extractvalue { i64, ptr } { i64 1, ptr @.d48 }, 0
  %t737 = add i64 %t734, %t736
  %t738 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t739 = extractvalue { i64, ptr } %t738, 1
  %t740 = extractvalue { i64, ptr } %t738, 0
  %t741 = add i64 %t737, %t740
  %t742 = extractvalue { i64, ptr } { i64 1, ptr @.d49 }, 1
  %t743 = extractvalue { i64, ptr } { i64 1, ptr @.d49 }, 0
  %t744 = add i64 %t741, %t743
  %t745 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t744)
  call void @olang_textcopy(ptr %t745, ptr %t722, i64 %t723)
  %t746 = getelementptr i8, ptr %t745, i64 %t723
  call void @olang_textcopy(ptr %t746, ptr %t725, i64 %t726)
  %t747 = getelementptr i8, ptr %t746, i64 %t726
  call void @olang_textcopy(ptr %t747, ptr %t728, i64 %t729)
  %t748 = getelementptr i8, ptr %t747, i64 %t729
  call void @olang_textcopy(ptr %t748, ptr %t732, i64 %t733)
  %t749 = getelementptr i8, ptr %t748, i64 %t733
  call void @olang_textcopy(ptr %t749, ptr %t735, i64 %t736)
  %t750 = getelementptr i8, ptr %t749, i64 %t736
  call void @olang_textcopy(ptr %t750, ptr %t739, i64 %t740)
  %t751 = getelementptr i8, ptr %t750, i64 %t740
  call void @olang_textcopy(ptr %t751, ptr %t742, i64 %t743)
  %t752 = insertvalue { i64, ptr } undef, i64 %t744, 0
  %t753 = insertvalue { i64, ptr } %t752, ptr %t745, 1
  store { i64, ptr } %t753, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s27)
  br label %bb150
bb95:
  %t755 = load ptr, ptr %l1, !tbaa !29
  store ptr %t755, ptr %l212, !tbaa !29
  store i1 false, ptr %l213, !tbaa !21
  %t756 = load ptr, ptr %l212, !tbaa !29
  %t757 = icmp ne ptr %t756, null
  br i1 %t757, label %bb96, label %bb97
bb96:
  %t759 = load ptr, ptr %l212, !tbaa !29
  %t760 = load i64, ptr %t759
  %t762 = icmp eq i64 %t760, 11
  store i1 %t762, ptr %l213, !tbaa !21
  br label %bb97
bb97:
  %t763 = load i1, ptr %l213, !tbaa !21
  br i1 %t763, label %bb98, label %bb99
bb98:
  %t764 = load ptr, ptr %l1, !tbaa !29
  %t766 = getelementptr { i64, [5 x i64] }, ptr %t764, i32 0, i32 1
  %t767 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t766, i32 0, i32 2
  %t768 = load ptr, ptr %t767
  store ptr %t768, ptr %l18, !tbaa !29
  br label %bb100
bb99:
  br label %bb104
bb100:
  store %olang.scope zeroinitializer, ptr %s29
  %t770 = load ptr, ptr %l0, !tbaa !29
  %t771 = load ptr, ptr %l18, !tbaa !29
  %t773 = getelementptr %"compiler/typed:Cond", ptr %t771, i32 0, i32 0
  %t774 = load ptr, ptr %t773, !tbaa !29
  %t778 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %t770, ptr %t774)
  store { i64, ptr } %t778, ptr %l222
  br label %bb101
bb101:
  %t779 = load ptr, ptr %l0, !tbaa !29
  %t780 = load ptr, ptr %l18, !tbaa !29
  %t782 = getelementptr %"compiler/typed:Cond", ptr %t780, i32 0, i32 1
  %t783 = load ptr, ptr %t782, !tbaa !29
  %t786 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %t779, ptr %t783)
  store { i64, ptr } %t786, ptr %l226
  br label %bb102
bb102:
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t788 = load ptr, ptr %l18, !tbaa !29
  %t790 = getelementptr %"compiler/typed:Cond", ptr %t788, i32 0, i32 2
  %t791 = load ptr, ptr %t790, !tbaa !29
  %t795 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %t787, ptr %t791)
  store { i64, ptr } %t795, ptr %l231
  br label %bb103
bb103:
  %t796 = extractvalue { i64, ptr } { i64 6, ptr @.d50 }, 1
  %t797 = extractvalue { i64, ptr } { i64 6, ptr @.d50 }, 0
  %t798 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t799 = extractvalue { i64, ptr } %t798, 1
  %t800 = extractvalue { i64, ptr } %t798, 0
  %t801 = add i64 %t797, %t800
  %t802 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 1
  %t803 = extractvalue { i64, ptr } { i64 1, ptr @.d51 }, 0
  %t804 = add i64 %t801, %t803
  %t805 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t806 = extractvalue { i64, ptr } %t805, 1
  %t807 = extractvalue { i64, ptr } %t805, 0
  %t808 = add i64 %t804, %t807
  %t809 = extractvalue { i64, ptr } { i64 1, ptr @.d52 }, 1
  %t810 = extractvalue { i64, ptr } { i64 1, ptr @.d52 }, 0
  %t811 = add i64 %t808, %t810
  %t812 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t813 = extractvalue { i64, ptr } %t812, 1
  %t814 = extractvalue { i64, ptr } %t812, 0
  %t815 = add i64 %t811, %t814
  %t816 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 1
  %t817 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 0
  %t818 = add i64 %t815, %t817
  %t819 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t818)
  call void @olang_textcopy(ptr %t819, ptr %t796, i64 %t797)
  %t820 = getelementptr i8, ptr %t819, i64 %t797
  call void @olang_textcopy(ptr %t820, ptr %t799, i64 %t800)
  %t821 = getelementptr i8, ptr %t820, i64 %t800
  call void @olang_textcopy(ptr %t821, ptr %t802, i64 %t803)
  %t822 = getelementptr i8, ptr %t821, i64 %t803
  call void @olang_textcopy(ptr %t822, ptr %t806, i64 %t807)
  %t823 = getelementptr i8, ptr %t822, i64 %t807
  call void @olang_textcopy(ptr %t823, ptr %t809, i64 %t810)
  %t824 = getelementptr i8, ptr %t823, i64 %t810
  call void @olang_textcopy(ptr %t824, ptr %t813, i64 %t814)
  %t825 = getelementptr i8, ptr %t824, i64 %t814
  call void @olang_textcopy(ptr %t825, ptr %t816, i64 %t817)
  %t826 = insertvalue { i64, ptr } undef, i64 %t818, 0
  %t827 = insertvalue { i64, ptr } %t826, ptr %t819, 1
  store { i64, ptr } %t827, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s29)
  br label %bb150
bb104:
  %t829 = load ptr, ptr %l1, !tbaa !29
  store ptr %t829, ptr %l233, !tbaa !29
  store i1 false, ptr %l234, !tbaa !21
  %t830 = load ptr, ptr %l233, !tbaa !29
  %t831 = icmp ne ptr %t830, null
  br i1 %t831, label %bb105, label %bb106
bb105:
  %t833 = load ptr, ptr %l233, !tbaa !29
  %t834 = load i64, ptr %t833
  %t836 = icmp eq i64 %t834, 12
  store i1 %t836, ptr %l234, !tbaa !21
  br label %bb106
bb106:
  %t837 = load i1, ptr %l234, !tbaa !21
  br i1 %t837, label %bb107, label %bb108
bb107:
  %t838 = load ptr, ptr %l1, !tbaa !29
  %t840 = getelementptr { i64, [5 x i64] }, ptr %t838, i32 0, i32 1
  %t841 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t840, i32 0, i32 2
  %t842 = load ptr, ptr %t841
  store ptr %t842, ptr %l19, !tbaa !29
  br label %bb109
bb108:
  br label %bb111
bb109:
  store %olang.scope zeroinitializer, ptr %s31
  %t844 = load ptr, ptr %l19, !tbaa !29
  %t846 = getelementptr %"compiler/typed:Seq", ptr %t844, i32 0, i32 0
  %t847 = load { i64, ptr }, ptr %t846, !tbaa !27
  %t849 = extractvalue { i64, ptr } %t847, 0
  store i64 %t849, ptr %l241, !tbaa !24
  %t850 = load ptr, ptr %l0, !tbaa !29
  %t851 = load ptr, ptr %l19, !tbaa !29
  %t853 = getelementptr %"compiler/typed:Seq", ptr %t851, i32 0, i32 1
  %t854 = load ptr, ptr %t853, !tbaa !29
  %t857 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s31, ptr %t850, ptr %t854)
  store { i64, ptr } %t857, ptr %l245
  br label %bb110
bb110:
  %t858 = extractvalue { i64, ptr } { i64 5, ptr @.d54 }, 1
  %t859 = extractvalue { i64, ptr } { i64 5, ptr @.d54 }, 0
  %t860 = load i64, ptr %l241, !tbaa !24
  %t861 = call i64 @__olang_fmt_i64(ptr null, i64 %t860)
  %t862 = add i64 %t859, %t861
  %t863 = extractvalue { i64, ptr } { i64 1, ptr @.d55 }, 1
  %t864 = extractvalue { i64, ptr } { i64 1, ptr @.d55 }, 0
  %t865 = add i64 %t862, %t864
  %t866 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t867 = extractvalue { i64, ptr } %t866, 1
  %t868 = extractvalue { i64, ptr } %t866, 0
  %t869 = add i64 %t865, %t868
  %t870 = extractvalue { i64, ptr } { i64 1, ptr @.d56 }, 1
  %t871 = extractvalue { i64, ptr } { i64 1, ptr @.d56 }, 0
  %t872 = add i64 %t869, %t871
  %t873 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t872)
  call void @olang_textcopy(ptr %t873, ptr %t858, i64 %t859)
  %t874 = getelementptr i8, ptr %t873, i64 %t859
  %t875 = call i64 @__olang_fmt_i64(ptr %t874, i64 %t860)
  %t876 = getelementptr i8, ptr %t874, i64 %t861
  call void @olang_textcopy(ptr %t876, ptr %t863, i64 %t864)
  %t877 = getelementptr i8, ptr %t876, i64 %t864
  call void @olang_textcopy(ptr %t877, ptr %t867, i64 %t868)
  %t878 = getelementptr i8, ptr %t877, i64 %t868
  call void @olang_textcopy(ptr %t878, ptr %t870, i64 %t871)
  %t879 = insertvalue { i64, ptr } undef, i64 %t872, 0
  %t880 = insertvalue { i64, ptr } %t879, ptr %t873, 1
  store { i64, ptr } %t880, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s31)
  br label %bb150
bb111:
  %t882 = load ptr, ptr %l1, !tbaa !29
  store ptr %t882, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t883 = load ptr, ptr %l247, !tbaa !29
  %t884 = icmp ne ptr %t883, null
  br i1 %t884, label %bb112, label %bb113
bb112:
  %t886 = load ptr, ptr %l247, !tbaa !29
  %t887 = load i64, ptr %t886
  %t889 = icmp eq i64 %t887, 13
  store i1 %t889, ptr %l248, !tbaa !21
  br label %bb113
bb113:
  %t890 = load i1, ptr %l248, !tbaa !21
  br i1 %t890, label %bb114, label %bb115
bb114:
  %t891 = load ptr, ptr %l1, !tbaa !29
  %t893 = getelementptr { i64, [5 x i64] }, ptr %t891, i32 0, i32 1
  %t894 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t893, i32 0, i32 2
  %t895 = load ptr, ptr %t894
  store ptr %t895, ptr %l20, !tbaa !29
  br label %bb116
bb115:
  br label %bb123
bb116:
  %t897 = load ptr, ptr %l20, !tbaa !29
  %t899 = getelementptr %"compiler/typed:Match", ptr %t897, i32 0, i32 1
  %t900 = load { i64, ptr }, ptr %t899, !tbaa !27
  %t902 = extractvalue { i64, ptr } %t900, 0
  store i64 %t902, ptr %l255, !tbaa !24
  %t903 = load ptr, ptr %l20, !tbaa !29
  %t905 = getelementptr %"compiler/typed:Match", ptr %t903, i32 0, i32 2
  %t906 = load ptr, ptr %t905, !tbaa !29
  %t908 = icmp eq ptr %t906, null
  br i1 %t908, label %bb117, label %bb118
bb117:
  call void @__olang_check_failed(ptr @olang_loc_a4fa64762613be8a_d12da9b666f393e6)
  unreachable
bb118:
  br label %bb119
bb119:
  %t910 = load ptr, ptr %l20, !tbaa !29
  %t912 = getelementptr %"compiler/typed:Match", ptr %t910, i32 0, i32 2
  %t913 = load ptr, ptr %t912, !tbaa !29
  %t916 = getelementptr %"compiler/typed:Arm", ptr %t913, i32 0, i32 3
  %t917 = load ptr, ptr %t916, !tbaa !29
  store ptr %t917, ptr %l21, !tbaa !29
  %t919 = load ptr, ptr %l21, !tbaa !29
  %t921 = icmp eq ptr %t919, null
  br i1 %t921, label %bb120, label %bb121
bb120:
  call void @__olang_check_failed(ptr @olang_loc_a4fa64762613be8a_d12da9b666f393e6)
  unreachable
bb121:
  br label %bb122
bb122:
  %t923 = load ptr, ptr %l21, !tbaa !29
  %t926 = getelementptr %"compiler/typed:Block", ptr %t923, i32 0, i32 1
  %t927 = load { i64, ptr }, ptr %t926, !tbaa !27
  %t929 = extractvalue { i64, ptr } %t927, 0
  %t930 = extractvalue { i64, ptr } { i64 7, ptr @.d57 }, 1
  %t931 = extractvalue { i64, ptr } { i64 7, ptr @.d57 }, 0
  %t932 = load i64, ptr %l255, !tbaa !24
  %t933 = call i64 @__olang_fmt_i64(ptr null, i64 %t932)
  %t934 = add i64 %t931, %t933
  %t935 = extractvalue { i64, ptr } { i64 15, ptr @.d58 }, 1
  %t936 = extractvalue { i64, ptr } { i64 15, ptr @.d58 }, 0
  %t937 = add i64 %t934, %t936
  %t939 = call i64 @__olang_fmt_i64(ptr null, i64 %t929)
  %t940 = add i64 %t937, %t939
  %t941 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 1
  %t942 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 0
  %t943 = add i64 %t940, %t942
  %t944 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t943)
  call void @olang_textcopy(ptr %t944, ptr %t930, i64 %t931)
  %t945 = getelementptr i8, ptr %t944, i64 %t931
  %t946 = call i64 @__olang_fmt_i64(ptr %t945, i64 %t932)
  %t947 = getelementptr i8, ptr %t945, i64 %t933
  call void @olang_textcopy(ptr %t947, ptr %t935, i64 %t936)
  %t948 = getelementptr i8, ptr %t947, i64 %t936
  %t949 = call i64 @__olang_fmt_i64(ptr %t948, i64 %t929)
  %t950 = getelementptr i8, ptr %t948, i64 %t939
  call void @olang_textcopy(ptr %t950, ptr %t941, i64 %t942)
  %t951 = insertvalue { i64, ptr } undef, i64 %t943, 0
  %t952 = insertvalue { i64, ptr } %t951, ptr %t944, 1
  store { i64, ptr } %t952, ptr %l38, !tbaa !27
  br label %bb150
bb123:
  %t954 = load ptr, ptr %l1, !tbaa !29
  store ptr %t954, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t955 = load ptr, ptr %l270, !tbaa !29
  %t956 = icmp ne ptr %t955, null
  br i1 %t956, label %bb124, label %bb125
bb124:
  %t958 = load ptr, ptr %l270, !tbaa !29
  %t959 = load i64, ptr %t958
  %t961 = icmp eq i64 %t959, 14
  store i1 %t961, ptr %l271, !tbaa !21
  br label %bb125
bb125:
  %t962 = load i1, ptr %l271, !tbaa !21
  br i1 %t962, label %bb126, label %bb127
bb126:
  %t963 = load ptr, ptr %l1, !tbaa !29
  %t965 = getelementptr { i64, [5 x i64] }, ptr %t963, i32 0, i32 1
  %t966 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t965, i32 0, i32 2
  %t967 = load ptr, ptr %t966
  store ptr %t967, ptr %l22, !tbaa !29
  br label %bb128
bb127:
  br label %bb130
bb128:
  store %olang.scope zeroinitializer, ptr %s35
  %t969 = load ptr, ptr %l0, !tbaa !29
  %t970 = load ptr, ptr %l22, !tbaa !29
  %t972 = getelementptr %"compiler/typed:Try", ptr %t970, i32 0, i32 0
  %t973 = load ptr, ptr %t972, !tbaa !29
  %t976 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s35, ptr %t969, ptr %t973)
  store { i64, ptr } %t976, ptr %l279
  br label %bb129
bb129:
  %t977 = load ptr, ptr %l22, !tbaa !29
  %t979 = getelementptr %"compiler/typed:Try", ptr %t977, i32 0, i32 1
  %t980 = load { i64, ptr }, ptr %t979, !tbaa !27
  %t982 = extractvalue { i64, ptr } %t980, 0
  %t983 = extractvalue { i64, ptr } { i64 5, ptr @.d60 }, 1
  %t984 = extractvalue { i64, ptr } { i64 5, ptr @.d60 }, 0
  %t985 = load { i64, ptr }, ptr %l279, !tbaa !27
  %t986 = extractvalue { i64, ptr } %t985, 1
  %t987 = extractvalue { i64, ptr } %t985, 0
  %t988 = add i64 %t984, %t987
  %t989 = extractvalue { i64, ptr } { i64 1, ptr @.d61 }, 1
  %t990 = extractvalue { i64, ptr } { i64 1, ptr @.d61 }, 0
  %t991 = add i64 %t988, %t990
  %t993 = call i64 @__olang_fmt_i64(ptr null, i64 %t982)
  %t994 = add i64 %t991, %t993
  %t995 = extractvalue { i64, ptr } { i64 9, ptr @.d62 }, 1
  %t996 = extractvalue { i64, ptr } { i64 9, ptr @.d62 }, 0
  %t997 = add i64 %t994, %t996
  %t998 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t997)
  call void @olang_textcopy(ptr %t998, ptr %t983, i64 %t984)
  %t999 = getelementptr i8, ptr %t998, i64 %t984
  call void @olang_textcopy(ptr %t999, ptr %t986, i64 %t987)
  %t1000 = getelementptr i8, ptr %t999, i64 %t987
  call void @olang_textcopy(ptr %t1000, ptr %t989, i64 %t990)
  %t1001 = getelementptr i8, ptr %t1000, i64 %t990
  %t1002 = call i64 @__olang_fmt_i64(ptr %t1001, i64 %t982)
  %t1003 = getelementptr i8, ptr %t1001, i64 %t993
  call void @olang_textcopy(ptr %t1003, ptr %t995, i64 %t996)
  %t1004 = insertvalue { i64, ptr } undef, i64 %t997, 0
  %t1005 = insertvalue { i64, ptr } %t1004, ptr %t998, 1
  store { i64, ptr } %t1005, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s35)
  br label %bb150
bb130:
  %t1007 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1007, ptr %l284, !tbaa !29
  store i1 false, ptr %l285, !tbaa !21
  %t1008 = load ptr, ptr %l284, !tbaa !29
  %t1009 = icmp ne ptr %t1008, null
  br i1 %t1009, label %bb131, label %bb132
bb131:
  %t1011 = load ptr, ptr %l284, !tbaa !29
  %t1012 = load i64, ptr %t1011
  %t1014 = icmp eq i64 %t1012, 15
  store i1 %t1014, ptr %l285, !tbaa !21
  br label %bb132
bb132:
  %t1015 = load i1, ptr %l285, !tbaa !21
  br i1 %t1015, label %bb133, label %bb134
bb133:
  %t1016 = load ptr, ptr %l1, !tbaa !29
  %t1018 = getelementptr { i64, [5 x i64] }, ptr %t1016, i32 0, i32 1
  %t1019 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1018, i32 0, i32 2
  %t1020 = load ptr, ptr %t1019
  store ptr %t1020, ptr %l23, !tbaa !29
  br label %bb135
bb134:
  br label %bb136
bb135:
  %t1022 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1023 = extractvalue { i64, ptr } { i64 4, ptr @.d63 }, 1
  %t1024 = extractvalue { i64, ptr } { i64 4, ptr @.d63 }, 0
  %t1026 = extractvalue { i64, ptr } %t1022, 1
  %t1027 = extractvalue { i64, ptr } %t1022, 0
  %t1028 = add i64 %t1024, %t1027
  %t1029 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 1
  %t1030 = extractvalue { i64, ptr } { i64 1, ptr @.d64 }, 0
  %t1031 = add i64 %t1028, %t1030
  %t1032 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1031)
  call void @olang_textcopy(ptr %t1032, ptr %t1023, i64 %t1024)
  %t1033 = getelementptr i8, ptr %t1032, i64 %t1024
  call void @olang_textcopy(ptr %t1033, ptr %t1026, i64 %t1027)
  %t1034 = getelementptr i8, ptr %t1033, i64 %t1027
  call void @olang_textcopy(ptr %t1034, ptr %t1029, i64 %t1030)
  %t1035 = insertvalue { i64, ptr } undef, i64 %t1031, 0
  %t1036 = insertvalue { i64, ptr } %t1035, ptr %t1032, 1
  store { i64, ptr } %t1036, ptr %l38, !tbaa !27
  br label %bb150
bb136:
  %t1038 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1038, ptr %l292, !tbaa !29
  store i1 false, ptr %l293, !tbaa !21
  %t1039 = load ptr, ptr %l292, !tbaa !29
  %t1040 = icmp ne ptr %t1039, null
  br i1 %t1040, label %bb137, label %bb138
bb137:
  %t1042 = load ptr, ptr %l292, !tbaa !29
  %t1043 = load i64, ptr %t1042
  %t1045 = icmp eq i64 %t1043, 16
  store i1 %t1045, ptr %l293, !tbaa !21
  br label %bb138
bb138:
  %t1046 = load i1, ptr %l293, !tbaa !21
  br i1 %t1046, label %bb139, label %bb140
bb139:
  %t1047 = load ptr, ptr %l1, !tbaa !29
  %t1049 = getelementptr { i64, [5 x i64] }, ptr %t1047, i32 0, i32 1
  %t1050 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1049, i32 0, i32 2
  %t1051 = load ptr, ptr %t1050
  store ptr %t1051, ptr %l24, !tbaa !29
  br label %bb141
bb140:
  br label %bb142
bb141:
  %t1053 = load ptr, ptr %l24, !tbaa !29
  %t1055 = getelementptr %"compiler/typed:Text", ptr %t1053, i32 0, i32 0
  %t1056 = load { i64, ptr }, ptr %t1055, !tbaa !27
  %t1058 = extractvalue { i64, ptr } %t1056, 0
  %t1059 = load ptr, ptr %l24, !tbaa !29
  %t1061 = getelementptr %"compiler/typed:Text", ptr %t1059, i32 0, i32 1
  %t1062 = load i32, ptr %t1061, !tbaa !23
  %t1063 = extractvalue { i64, ptr } { i64 6, ptr @.d65 }, 1
  %t1064 = extractvalue { i64, ptr } { i64 6, ptr @.d65 }, 0
  %t1066 = call i64 @__olang_fmt_i64(ptr null, i64 %t1058)
  %t1067 = add i64 %t1064, %t1066
  %t1068 = extractvalue { i64, ptr } { i64 6, ptr @.d66 }, 1
  %t1069 = extractvalue { i64, ptr } { i64 6, ptr @.d66 }, 0
  %t1070 = add i64 %t1067, %t1069
  %t1072 = sext i32 %t1062 to i64
  %t1073 = call i64 @__olang_fmt_i64(ptr null, i64 %t1072)
  %t1074 = add i64 %t1070, %t1073
  %t1075 = extractvalue { i64, ptr } { i64 1, ptr @.d67 }, 1
  %t1076 = extractvalue { i64, ptr } { i64 1, ptr @.d67 }, 0
  %t1077 = add i64 %t1074, %t1076
  %t1078 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1077)
  call void @olang_textcopy(ptr %t1078, ptr %t1063, i64 %t1064)
  %t1079 = getelementptr i8, ptr %t1078, i64 %t1064
  %t1080 = call i64 @__olang_fmt_i64(ptr %t1079, i64 %t1058)
  %t1081 = getelementptr i8, ptr %t1079, i64 %t1066
  call void @olang_textcopy(ptr %t1081, ptr %t1068, i64 %t1069)
  %t1082 = getelementptr i8, ptr %t1081, i64 %t1069
  %t1083 = call i64 @__olang_fmt_i64(ptr %t1082, i64 %t1072)
  %t1084 = getelementptr i8, ptr %t1082, i64 %t1073
  call void @olang_textcopy(ptr %t1084, ptr %t1075, i64 %t1076)
  %t1085 = insertvalue { i64, ptr } undef, i64 %t1077, 0
  %t1086 = insertvalue { i64, ptr } %t1085, ptr %t1078, 1
  store { i64, ptr } %t1086, ptr %l38, !tbaa !27
  br label %bb150
bb142:
  %t1088 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1088, ptr %l304, !tbaa !29
  store i1 false, ptr %l305, !tbaa !21
  %t1089 = load ptr, ptr %l304, !tbaa !29
  %t1090 = icmp ne ptr %t1089, null
  br i1 %t1090, label %bb143, label %bb144
bb143:
  %t1092 = load ptr, ptr %l304, !tbaa !29
  %t1093 = load i64, ptr %t1092
  %t1095 = icmp eq i64 %t1093, 17
  store i1 %t1095, ptr %l305, !tbaa !21
  br label %bb144
bb144:
  %t1096 = load i1, ptr %l305, !tbaa !21
  br i1 %t1096, label %bb145, label %bb146
bb145:
  %t1097 = load ptr, ptr %l1, !tbaa !29
  %t1099 = getelementptr { i64, [5 x i64] }, ptr %t1097, i32 0, i32 1
  %t1100 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1099, i32 0, i32 1
  %t1101 = load i64, ptr %t1100
  store i64 %t1101, ptr %l25, !tbaa !24
  %t1103 = load ptr, ptr %l1, !tbaa !29
  %t1105 = getelementptr { i64, [5 x i64] }, ptr %t1103, i32 0, i32 1
  %t1106 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1105, i32 0, i32 2
  %t1107 = load ptr, ptr %t1106
  store ptr %t1107, ptr %l26, !tbaa !29
  br label %bb147
bb146:
  br label %bb149
bb147:
  store %olang.scope zeroinitializer, ptr %s41
  %t1109 = load i64, ptr %l25, !tbaa !24
  store i64 %t1109, ptr %l312, !tbaa !24
  %t1110 = load ptr, ptr %l0, !tbaa !29
  %t1111 = load ptr, ptr %l26, !tbaa !29
  %t1115 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s41, ptr %t1110, ptr %t1111)
  store { i64, ptr } %t1115, ptr %l316
  br label %bb148
bb148:
  %t1116 = extractvalue { i64, ptr } { i64 6, ptr @.d68 }, 1
  %t1117 = extractvalue { i64, ptr } { i64 6, ptr @.d68 }, 0
  %t1118 = load i64, ptr %l312, !tbaa !24
  %t1119 = call i64 @__olang_fmt_i64(ptr null, i64 %t1118)
  %t1120 = add i64 %t1117, %t1119
  %t1121 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 1
  %t1122 = extractvalue { i64, ptr } { i64 1, ptr @.d69 }, 0
  %t1123 = add i64 %t1120, %t1122
  %t1124 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t1125 = extractvalue { i64, ptr } %t1124, 1
  %t1126 = extractvalue { i64, ptr } %t1124, 0
  %t1127 = add i64 %t1123, %t1126
  %t1128 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 1
  %t1129 = extractvalue { i64, ptr } { i64 1, ptr @.d70 }, 0
  %t1130 = add i64 %t1127, %t1129
  %t1131 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1130)
  call void @olang_textcopy(ptr %t1131, ptr %t1116, i64 %t1117)
  %t1132 = getelementptr i8, ptr %t1131, i64 %t1117
  %t1133 = call i64 @__olang_fmt_i64(ptr %t1132, i64 %t1118)
  %t1134 = getelementptr i8, ptr %t1132, i64 %t1119
  call void @olang_textcopy(ptr %t1134, ptr %t1121, i64 %t1122)
  %t1135 = getelementptr i8, ptr %t1134, i64 %t1122
  call void @olang_textcopy(ptr %t1135, ptr %t1125, i64 %t1126)
  %t1136 = getelementptr i8, ptr %t1135, i64 %t1126
  call void @olang_textcopy(ptr %t1136, ptr %t1128, i64 %t1129)
  %t1137 = insertvalue { i64, ptr } undef, i64 %t1130, 0
  %t1138 = insertvalue { i64, ptr } %t1137, ptr %t1131, 1
  store { i64, ptr } %t1138, ptr %l38, !tbaa !27
  call void @__olang_scope_close(ptr %s41)
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_a387a9465b9f2118_49b9af8105801174)
  unreachable
bb150:
  call void @__olang_scope_close(ptr %s0)
  %t1140 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t1140, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 32)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  store ptr %l2, ptr %l39, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t59, ptr %l41, !tbaa !27
  %t60 = load i64, ptr %l8, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t69 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %a0, ptr %t65)
  store { i64, ptr } %t69, ptr %l45
  br label %bb16
bb16:
  %t70 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t77 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t77, { i64, ptr } %t76)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l7, !tbaa !24
  br label %bb8
bb19:
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t84, ptr %l50
  br label %bb20
bb20:
  %t85 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t85, ptr %l51, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l52, !tbaa !24
  %t88 = load i64, ptr %l52, !tbaa !24
  %t89 = mul i64 %t88, 1
  %t90 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l53, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l52, !tbaa !24
  %t98 = mul i64 %t97, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t94, ptr %t96, i64 %t98, i1 false)
  %t99 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t99, ptr %l51, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t100 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:printer", ptr %t49, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t51, { i64, ptr } { i64 2, ptr @.d71 })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb7
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:printer", ptr %t57, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t59, { i64, ptr } %a2)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:printer", ptr %t63, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t65, i8 10)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca i1
  %l96 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d72 }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr @.d72 }, 0
  %t20 = sext i32 %t16 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  br label %bb55
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t46, i32 0, i32 3
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i32, ptr %l4, !tbaa !23
  %t52 = extractvalue { i64, ptr } { i64 1, ptr @.d73 }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr @.d73 }, 0
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t50)
  %t56 = add i64 %t53, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 0
  %t59 = add i64 %t56, %t58
  %t61 = sext i32 %t51 to i64
  %t62 = call i64 @__olang_fmt_i64(ptr null, i64 %t61)
  %t63 = add i64 %t59, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t52, i64 %t53)
  %t65 = getelementptr i8, ptr %t64, i64 %t53
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t50)
  %t67 = getelementptr i8, ptr %t65, i64 %t55
  call void @olang_textcopy(ptr %t67, ptr %t57, i64 %t58)
  %t68 = getelementptr i8, ptr %t67, i64 %t58
  %t69 = call i64 @__olang_fmt_i64(ptr %t68, i64 %t61)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  store { i64, ptr } %t71, ptr %l12, !tbaa !27
  br label %bb55
bb12:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t74 = load ptr, ptr %l32, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb13, label %bb14
bb13:
  %t77 = load ptr, ptr %l32, !tbaa !29
  %t78 = load i64, ptr %t77
  %t80 = icmp eq i64 %t78, 2
  store i1 %t80, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t81 = load i1, ptr %l33, !tbaa !21
  br i1 %t81, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t93 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t88, ptr %t89)
  store { i64, ptr } %t93, ptr %l41
  br label %bb18
bb18:
  %t94 = extractvalue { i64, ptr } { i64 1, ptr @.d75 }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr @.d75 }, 0
  %t96 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = add i64 %t95, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t94, i64 %t95)
  %t101 = getelementptr i8, ptr %t100, i64 %t95
  call void @olang_textcopy(ptr %t101, ptr %t97, i64 %t98)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  store { i64, ptr } %t103, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb19:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t106 = load ptr, ptr %l43, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb20, label %bb21
bb20:
  %t109 = load ptr, ptr %l43, !tbaa !29
  %t110 = load i64, ptr %t109
  %t112 = icmp eq i64 %t110, 3
  store i1 %t112, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t113 = load i1, ptr %l44, !tbaa !21
  br i1 %t113, label %bb22, label %bb23
bb22:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l6, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t122, i32 0, i32 3
  %t124 = load i64, ptr %t123
  store i64 %t124, ptr %l7, !tbaa !24
  br label %bb24
bb23:
  br label %bb26
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t130 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s7, ptr %t126, ptr %t127)
  store { i64, ptr } %t130, ptr %l53
  br label %bb25
bb25:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr @.d76 }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr @.d76 }, 0
  %t137 = add i64 %t134, %t136
  %t139 = call i64 @__olang_fmt_i64(ptr null, i64 %t131)
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t133, i64 %t134)
  %t142 = getelementptr i8, ptr %t141, i64 %t134
  call void @olang_textcopy(ptr %t142, ptr %t135, i64 %t136)
  %t143 = getelementptr i8, ptr %t142, i64 %t136
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t131)
  %t145 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t141, 1
  store { i64, ptr } %t146, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb26:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t149 = load ptr, ptr %l56, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb27, label %bb28
bb27:
  %t152 = load ptr, ptr %l56, !tbaa !29
  %t153 = load i64, ptr %t152
  %t155 = icmp eq i64 %t153, 4
  store i1 %t155, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t156 = load i1, ptr %l57, !tbaa !21
  br i1 %t156, label %bb29, label %bb30
bb29:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t159, i32 0, i32 2
  %t161 = load ptr, ptr %t160
  store ptr %t161, ptr %l8, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Elem", ptr %t164, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t170 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s9, ptr %t163, ptr %t167)
  store { i64, ptr } %t170, ptr %l65
  br label %bb32
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l8, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Elem", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %t171, ptr %t175)
  store { i64, ptr } %t179, ptr %l70
  br label %bb33
bb33:
  %t180 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = extractvalue { i64, ptr } { i64 1, ptr @.d77 }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr @.d77 }, 0
  %t185 = add i64 %t182, %t184
  %t186 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t181, i64 %t182)
  %t194 = getelementptr i8, ptr %t193, i64 %t182
  call void @olang_textcopy(ptr %t194, ptr %t183, i64 %t184)
  %t195 = getelementptr i8, ptr %t194, i64 %t184
  call void @olang_textcopy(ptr %t195, ptr %t187, i64 %t188)
  %t196 = getelementptr i8, ptr %t195, i64 %t188
  call void @olang_textcopy(ptr %t196, ptr %t190, i64 %t191)
  %t197 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t193, 1
  store { i64, ptr } %t198, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb34:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t201 = load ptr, ptr %l72, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb35, label %bb36
bb35:
  %t204 = load ptr, ptr %l72, !tbaa !29
  %t205 = load i64, ptr %t204
  %t207 = icmp eq i64 %t205, 5
  store i1 %t207, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t208 = load i1, ptr %l73, !tbaa !21
  br i1 %t208, label %bb37, label %bb38
bb37:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [4 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l9, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l9, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Payload", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t222 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s11, ptr %t215, ptr %t219)
  store { i64, ptr } %t222, ptr %l81
  br label %bb40
bb40:
  %t223 = load ptr, ptr %l9, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Payload", ptr %t223, i32 0, i32 1
  %t226 = load i64, ptr %t225, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = extractvalue { i64, ptr } { i64 4, ptr @.d79 }, 1
  %t231 = extractvalue { i64, ptr } { i64 4, ptr @.d79 }, 0
  %t232 = add i64 %t229, %t231
  %t234 = call i64 @__olang_fmt_i64(ptr null, i64 %t226)
  %t235 = add i64 %t232, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t228, i64 %t229)
  %t237 = getelementptr i8, ptr %t236, i64 %t229
  call void @olang_textcopy(ptr %t237, ptr %t230, i64 %t231)
  %t238 = getelementptr i8, ptr %t237, i64 %t231
  %t239 = call i64 @__olang_fmt_i64(ptr %t238, i64 %t226)
  %t240 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t236, 1
  store { i64, ptr } %t241, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb41:
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t244 = load ptr, ptr %l85, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb42, label %bb43
bb42:
  %t247 = load ptr, ptr %l85, !tbaa !29
  %t248 = load i64, ptr %t247
  %t250 = icmp eq i64 %t248, 6
  store i1 %t250, ptr %l86, !tbaa !21
  br label %bb43
bb43:
  %t251 = load i1, ptr %l86, !tbaa !21
  br i1 %t251, label %bb44, label %bb45
bb44:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t254, i32 0, i32 2
  %t256 = load ptr, ptr %t255
  store ptr %t256, ptr %l10, !tbaa !29
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t260, i32 0, i32 3
  %t262 = load i32, ptr %t261
  store i32 %t262, ptr %l11, !tbaa !23
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l10, !tbaa !29
  %t269 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s13, ptr %t264, ptr %t265)
  store { i64, ptr } %t269, ptr %l96
  br label %bb47
bb47:
  %t270 = load i32, ptr %l11, !tbaa !23
  %t271 = extractvalue { i64, ptr } { i64 4, ptr @.d80 }, 1
  %t272 = extractvalue { i64, ptr } { i64 4, ptr @.d80 }, 0
  %t273 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = extractvalue { i64, ptr } { i64 6, ptr @.d81 }, 1
  %t278 = extractvalue { i64, ptr } { i64 6, ptr @.d81 }, 0
  %t279 = add i64 %t276, %t278
  %t281 = sext i32 %t270 to i64
  %t282 = call i64 @__olang_fmt_i64(ptr null, i64 %t281)
  %t283 = add i64 %t279, %t282
  %t284 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t283)
  call void @olang_textcopy(ptr %t284, ptr %t271, i64 %t272)
  %t285 = getelementptr i8, ptr %t284, i64 %t272
  call void @olang_textcopy(ptr %t285, ptr %t274, i64 %t275)
  %t286 = getelementptr i8, ptr %t285, i64 %t275
  call void @olang_textcopy(ptr %t286, ptr %t277, i64 %t278)
  %t287 = getelementptr i8, ptr %t286, i64 %t278
  %t288 = call i64 @__olang_fmt_i64(ptr %t287, i64 %t281)
  %t289 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t284, 1
  store { i64, ptr } %t290, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb55
bb48:
  %t292 = load ptr, ptr %l1, !tbaa !29
  store ptr %t292, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t293 = load ptr, ptr %l99, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb49, label %bb50
bb49:
  %t296 = load ptr, ptr %l99, !tbaa !29
  %t297 = load i64, ptr %t296
  %t299 = icmp eq i64 %t297, 7
  store i1 %t299, ptr %l100, !tbaa !21
  br label %bb50
bb50:
  %t300 = load i1, ptr %l100, !tbaa !21
  br i1 %t300, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 6, ptr @.d82 }, ptr %l103, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t301, ptr %l12, !tbaa !27
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_16612f18a9afa54d_299c1e15a68a5059)
  unreachable
bb55:
  %t303 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  store i64 %t304, ptr %l105, !tbaa !24
  %t305 = load i64, ptr %l105, !tbaa !24
  %t306 = mul i64 %t305, 1
  %t307 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t306)
  %t308 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  store { i64, ptr } %t309, ptr %l106, !tbaa !27
  %t310 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l105, !tbaa !24
  %t315 = mul i64 %t314, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t311, ptr %t313, i64 %t315, i1 false)
  %t316 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t316, ptr %l12, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t317, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i32
  %l37 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i64
  %l70 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l74 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i64
  %l85 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i64
  %l142 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l147 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i64
  %l157 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l167 = alloca i1
  %l174 = alloca ptr
  %l175 = alloca i64
  %l179 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l184 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca i64
  %l191 = alloca i32
  %l193 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l198 = alloca ptr
  %l199 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca i64
  %l209 = alloca { i64, ptr }
  %l212 = alloca ptr
  %l213 = alloca i1
  %l222 = alloca ptr
  %l223 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i64
  %l244 = alloca { i64, ptr }
  %l252 = alloca ptr
  %l253 = alloca i1
  %l258 = alloca ptr
  %l259 = alloca i64
  %l264 = alloca { i64, ptr }
  %l269 = alloca ptr
  %l270 = alloca i1
  %l275 = alloca ptr
  %l276 = alloca i64
  %l280 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.builder
  %s20room = alloca [64 x i8], align 8
  %s22 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l31, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  store i64 %t23, ptr %l32, !tbaa !24
  %t24 = load i32, ptr %l3, !tbaa !23
  store i32 %t24, ptr %l33, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s1, ptr %t25, ptr %t26)
  store { i64, ptr } %t30, ptr %l37
  br label %bb6
bb6:
  %t31 = extractvalue { i64, ptr } { i64 5, ptr @.d83 }, 1
  %t32 = extractvalue { i64, ptr } { i64 5, ptr @.d83 }, 0
  %t33 = load i32, ptr %l33, !tbaa !23
  %t34 = sext i32 %t33 to i64
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 3, ptr @.d84 }, 1
  %t38 = extractvalue { i64, ptr } { i64 3, ptr @.d84 }, 0
  %t39 = add i64 %t36, %t38
  %t40 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = add i64 %t39, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t31, i64 %t32)
  %t45 = getelementptr i8, ptr %t44, i64 %t32
  %t46 = call i64 @__olang_fmt_i64(ptr %t45, i64 %t34)
  %t47 = getelementptr i8, ptr %t45, i64 %t35
  call void @olang_textcopy(ptr %t47, ptr %t37, i64 %t38)
  %t48 = getelementptr i8, ptr %t47, i64 %t38
  call void @olang_textcopy(ptr %t48, ptr %t41, i64 %t42)
  %t49 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t44, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %l32, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s1, ptr %t58, i64 %t59, { i64, ptr } %t57)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb144
bb8:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t62 = load ptr, ptr %l40, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb9, label %bb10
bb9:
  %t65 = load ptr, ptr %l40, !tbaa !29
  %t66 = load i64, ptr %t65
  %t68 = icmp eq i64 %t66, 1
  store i1 %t68, ptr %l41, !tbaa !21
  br label %bb10
bb10:
  %t69 = load i1, ptr %l41, !tbaa !21
  br i1 %t69, label %bb11, label %bb12
bb11:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 1
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l5, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [3 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l48, !tbaa !29
  %t83 = load i64, ptr %l2, !tbaa !24
  store i64 %t83, ptr %l49, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t88 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s3, ptr %t84, ptr %t85)
  store { i64, ptr } %t88, ptr %l52
  br label %bb14
bb14:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t94 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s3, ptr %t89, ptr %t90)
  store { i64, ptr } %t94, ptr %l56
  br label %bb15
bb15:
  %t95 = extractvalue { i64, ptr } { i64 7, ptr @.d85 }, 1
  %t96 = extractvalue { i64, ptr } { i64 7, ptr @.d85 }, 0
  %t97 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = add i64 %t96, %t99
  %t101 = extractvalue { i64, ptr } { i64 3, ptr @.d86 }, 1
  %t102 = extractvalue { i64, ptr } { i64 3, ptr @.d86 }, 0
  %t103 = add i64 %t100, %t102
  %t104 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = add i64 %t103, %t106
  %t108 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t107)
  call void @olang_textcopy(ptr %t108, ptr %t95, i64 %t96)
  %t109 = getelementptr i8, ptr %t108, i64 %t96
  call void @olang_textcopy(ptr %t109, ptr %t98, i64 %t99)
  %t110 = getelementptr i8, ptr %t109, i64 %t99
  call void @olang_textcopy(ptr %t110, ptr %t101, i64 %t102)
  %t111 = getelementptr i8, ptr %t110, i64 %t102
  call void @olang_textcopy(ptr %t111, ptr %t105, i64 %t106)
  %t112 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t108, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = extractvalue { i64, ptr } %t113, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t121 = load ptr, ptr %l48, !tbaa !29
  %t122 = load i64, ptr %l49, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s3, ptr %t121, i64 %t122, { i64, ptr } %t120)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb144
bb17:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t125 = load ptr, ptr %l59, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb18, label %bb19
bb18:
  %t128 = load ptr, ptr %l59, !tbaa !29
  %t129 = load i64, ptr %t128
  %t131 = icmp eq i64 %t129, 2
  store i1 %t131, ptr %l60, !tbaa !21
  br label %bb19
bb19:
  %t132 = load i1, ptr %l60, !tbaa !21
  br i1 %t132, label %bb20, label %bb21
bb20:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", ptr }, ptr %t135, i32 0, i32 1
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l65, !tbaa !29
  %t140 = load i64, ptr %l2, !tbaa !24
  store i64 %t140, ptr %l66, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l7, !tbaa !29
  %t146 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t141, ptr %t142)
  store { i64, ptr } %t146, ptr %l70
  br label %bb23
bb23:
  %t147 = extractvalue { i64, ptr } { i64 5, ptr @.d87 }, 1
  %t148 = extractvalue { i64, ptr } { i64 5, ptr @.d87 }, 0
  %t149 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = add i64 %t148, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t147, i64 %t148)
  %t154 = getelementptr i8, ptr %t153, i64 %t148
  call void @olang_textcopy(ptr %t154, ptr %t150, i64 %t151)
  %t155 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = load ptr, ptr %l65, !tbaa !29
  %t165 = load i64, ptr %l66, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s5, ptr %t164, i64 %t165, { i64, ptr } %t163)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb144
bb25:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t168 = load ptr, ptr %l73, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb26, label %bb27
bb26:
  %t171 = load ptr, ptr %l73, !tbaa !29
  %t172 = load i64, ptr %t171
  %t174 = icmp eq i64 %t172, 3
  store i1 %t174, ptr %l74, !tbaa !21
  br label %bb27
bb27:
  %t175 = load i1, ptr %l74, !tbaa !21
  br i1 %t175, label %bb28, label %bb29
bb28:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l8, !tbaa !29
  br label %bb30
bb29:
  br label %bb42
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l79, !tbaa !29
  %t183 = load i64, ptr %l2, !tbaa !24
  store i64 %t183, ptr %l80, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load ptr, ptr %l8, !tbaa !29
  %t187 = getelementptr %"compiler/typed:If", ptr %t185, i32 0, i32 0
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t192 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %t184, ptr %t188)
  store { i64, ptr } %t192, ptr %l85
  br label %bb31
bb31:
  %t193 = extractvalue { i64, ptr } { i64 3, ptr @.d88 }, 1
  %t194 = extractvalue { i64, ptr } { i64 3, ptr @.d88 }, 0
  %t195 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = add i64 %t194, %t197
  %t199 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t198)
  call void @olang_textcopy(ptr %t199, ptr %t193, i64 %t194)
  %t200 = getelementptr i8, ptr %t199, i64 %t194
  call void @olang_textcopy(ptr %t200, ptr %t196, i64 %t197)
  %t201 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t199, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  %t210 = load ptr, ptr %l79, !tbaa !29
  %t211 = load i64, ptr %l80, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s7, ptr %t210, i64 %t211, { i64, ptr } %t209)
  br label %bb32
bb32:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l8, !tbaa !29
  %t216 = getelementptr %"compiler/typed:If", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t218 = load i64, ptr %l2, !tbaa !24
  %t220 = add i64 %t218, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t213, ptr %t217, i64 %t220)
  br label %bb33
bb33:
  %t224 = load ptr, ptr %l8, !tbaa !29
  %t226 = getelementptr %"compiler/typed:If", ptr %t224, i32 0, i32 2
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s9
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s9, ptr %t233, i64 %t234, { i64, ptr } { i64 4, ptr @.d89 })
  br label %bb36
bb35:
  br label %bb41
bb36:
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l99, !tbaa !29
  %t238 = load ptr, ptr %l8, !tbaa !29
  %t240 = getelementptr %"compiler/typed:If", ptr %t238, i32 0, i32 2
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = icmp eq ptr %t241, null
  br i1 %t243, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_7b432bbe8f05f1d7_7deffd42aa472253)
  unreachable
bb38:
  br label %bb39
bb39:
  %t245 = load ptr, ptr %l8, !tbaa !29
  %t247 = getelementptr %"compiler/typed:If", ptr %t245, i32 0, i32 2
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t249 = load i64, ptr %l2, !tbaa !24
  %t251 = add i64 %t249, 1
  %t252 = load ptr, ptr %l99, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t252, ptr %t248, i64 %t251)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb144
bb42:
  %t255 = load ptr, ptr %l1, !tbaa !29
  store ptr %t255, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t256 = load ptr, ptr %l107, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb43, label %bb44
bb43:
  %t259 = load ptr, ptr %l107, !tbaa !29
  %t260 = load i64, ptr %t259
  %t262 = icmp eq i64 %t260, 4
  store i1 %t262, ptr %l108, !tbaa !21
  br label %bb44
bb44:
  %t263 = load i1, ptr %l108, !tbaa !21
  br i1 %t263, label %bb45, label %bb46
bb45:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [3 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t266, i32 0, i32 1
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l9, !tbaa !29
  %t270 = load ptr, ptr %l1, !tbaa !29
  %t272 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  %t273 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t272, i32 0, i32 2
  %t274 = load ptr, ptr %t273
  store ptr %t274, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb55
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s10, ptr %t276, i64 %t277, { i64, ptr } { i64 4, ptr @.d90 })
  br label %bb48
bb48:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l9, !tbaa !29
  %t282 = load i64, ptr %l2, !tbaa !24
  %t284 = add i64 %t282, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t280, ptr %t281, i64 %t284)
  br label %bb49
bb49:
  %t288 = load ptr, ptr %l10, !tbaa !29
  %t290 = icmp eq ptr %t288, null
  %t292 = xor i1 %t290, true
  br i1 %t292, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s11, ptr %t294, i64 %t295, { i64, ptr } { i64 4, ptr @.d91 })
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l10, !tbaa !29
  %t300 = load i64, ptr %l2, !tbaa !24
  %t302 = add i64 %t300, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t298, ptr %t299, i64 %t302)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb144
bb55:
  %t306 = load ptr, ptr %l1, !tbaa !29
  store ptr %t306, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t307 = load ptr, ptr %l130, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb56, label %bb57
bb56:
  %t310 = load ptr, ptr %l130, !tbaa !29
  %t311 = load i64, ptr %t310
  %t313 = icmp eq i64 %t311, 5
  store i1 %t313, ptr %l131, !tbaa !21
  br label %bb57
bb57:
  %t314 = load i1, ptr %l131, !tbaa !21
  br i1 %t314, label %bb58, label %bb59
bb58:
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t317 = getelementptr { i64, [3 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t317, i32 0, i32 1
  %t319 = load i32, ptr %t318
  store i32 %t319, ptr %l11
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr { i64, [3 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t323, i32 0, i32 2
  %t325 = load i32, ptr %t324
  store i32 %t325, ptr %l12, !tbaa !23
  br label %bb60
bb59:
  br label %bb65
bb60:
  store %olang.scope zeroinitializer, ptr %s12
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l138, !tbaa !29
  %t328 = load i64, ptr %l2, !tbaa !24
  store i64 %t328, ptr %l139, !tbaa !24
  %t329 = load i32, ptr %l11
  %t331 = trunc i64 0 to i32
  %t332 = icmp eq i32 %t329, %t331
  br i1 %t332, label %bb61, label %bb62
bb61:
  store { i64, ptr } { i64 5, ptr @.d92 }, ptr %l142, !tbaa !27
  br label %bb63
bb62:
  store { i64, ptr } { i64 8, ptr @.d93 }, ptr %l142, !tbaa !27
  br label %bb63
bb63:
  %t334 = load i32, ptr %l12, !tbaa !23
  %t335 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } { i64 2, ptr @.d94 }, 1
  %t339 = extractvalue { i64, ptr } { i64 2, ptr @.d94 }, 0
  %t340 = add i64 %t337, %t339
  %t342 = sext i32 %t334 to i64
  %t343 = call i64 @__olang_fmt_i64(ptr null, i64 %t342)
  %t344 = add i64 %t340, %t343
  %t345 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t344)
  call void @olang_textcopy(ptr %t345, ptr %t336, i64 %t337)
  %t346 = getelementptr i8, ptr %t345, i64 %t337
  call void @olang_textcopy(ptr %t346, ptr %t338, i64 %t339)
  %t347 = getelementptr i8, ptr %t346, i64 %t339
  %t348 = call i64 @__olang_fmt_i64(ptr %t347, i64 %t342)
  %t349 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t345, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } %t350, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  %t358 = load ptr, ptr %l138, !tbaa !29
  %t359 = load i64, ptr %l139, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s12, ptr %t358, i64 %t359, { i64, ptr } %t357)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s12)
  br label %bb144
bb65:
  %t361 = load ptr, ptr %l1, !tbaa !29
  store ptr %t361, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t362 = load ptr, ptr %l146, !tbaa !29
  %t363 = icmp ne ptr %t362, null
  br i1 %t363, label %bb66, label %bb67
bb66:
  %t365 = load ptr, ptr %l146, !tbaa !29
  %t366 = load i64, ptr %t365
  %t368 = icmp eq i64 %t366, 6
  store i1 %t368, ptr %l147, !tbaa !21
  br label %bb67
bb67:
  %t369 = load i1, ptr %l147, !tbaa !21
  br i1 %t369, label %bb68, label %bb69
bb68:
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t372 = getelementptr { i64, [3 x i64] }, ptr %t370, i32 0, i32 1
  %t373 = getelementptr { %"compiler/source:Span", ptr }, ptr %t372, i32 0, i32 1
  %t374 = load ptr, ptr %t373
  store ptr %t374, ptr %l13, !tbaa !29
  br label %bb70
bb69:
  br label %bb76
bb70:
  store %olang.scope zeroinitializer, ptr %s14
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l152, !tbaa !29
  %t377 = load i64, ptr %l2, !tbaa !24
  store i64 %t377, ptr %l153, !tbaa !24
  %t378 = load ptr, ptr %l13, !tbaa !29
  %t380 = icmp eq ptr %t378, null
  %t382 = xor i1 %t380, true
  br i1 %t382, label %bb71, label %bb72
bb71:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load ptr, ptr %l13, !tbaa !29
  %t389 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s14, ptr %t384, ptr %t385)
  store { i64, ptr } %t389, ptr %l161
  br label %bb73
bb72:
  store { i64, ptr } { i64 0, ptr @.d95 }, ptr %l157, !tbaa !27
  br label %bb74
bb73:
  %t390 = extractvalue { i64, ptr } { i64 1, ptr @.d96 }, 1
  %t391 = extractvalue { i64, ptr } { i64 1, ptr @.d96 }, 0
  %t392 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = add i64 %t391, %t394
  %t396 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t395)
  call void @olang_textcopy(ptr %t396, ptr %t390, i64 %t391)
  %t397 = getelementptr i8, ptr %t396, i64 %t391
  call void @olang_textcopy(ptr %t397, ptr %t393, i64 %t394)
  %t398 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t396, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = extractvalue { i64, ptr } %t399, 1
  %t403 = mul i64 %t401, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t403)
  call void @llvm.memcpy.p0.p0.i64(ptr %t404, ptr %t402, i64 %t403, i1 false)
  %t405 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  store { i64, ptr } %t406, ptr %l157, !tbaa !27
  br label %bb74
bb74:
  %t408 = extractvalue { i64, ptr } { i64 6, ptr @.d97 }, 1
  %t409 = extractvalue { i64, ptr } { i64 6, ptr @.d97 }, 0
  %t410 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t410, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = add i64 %t409, %t412
  %t414 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t413)
  call void @olang_textcopy(ptr %t414, ptr %t408, i64 %t409)
  %t415 = getelementptr i8, ptr %t414, i64 %t409
  call void @olang_textcopy(ptr %t415, ptr %t411, i64 %t412)
  %t416 = insertvalue { i64, ptr } undef, i64 %t413, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t414, 1
  %t419 = extractvalue { i64, ptr } %t417, 0
  %t420 = extractvalue { i64, ptr } %t417, 1
  %t421 = mul i64 %t419, 1
  %t422 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t421)
  call void @llvm.memcpy.p0.p0.i64(ptr %t422, ptr %t420, i64 %t421, i1 false)
  %t423 = insertvalue { i64, ptr } undef, i64 %t419, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t422, 1
  %t425 = load ptr, ptr %l152, !tbaa !29
  %t426 = load i64, ptr %l153, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s14, ptr %t425, i64 %t426, { i64, ptr } %t424)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s14)
  br label %bb144
bb76:
  %t428 = load ptr, ptr %l1, !tbaa !29
  store ptr %t428, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t429 = load ptr, ptr %l166, !tbaa !29
  %t430 = icmp ne ptr %t429, null
  br i1 %t430, label %bb77, label %bb78
bb77:
  %t432 = load ptr, ptr %l166, !tbaa !29
  %t433 = load i64, ptr %t432
  %t435 = icmp eq i64 %t433, 7
  store i1 %t435, ptr %l167, !tbaa !21
  br label %bb78
bb78:
  %t436 = load i1, ptr %l167, !tbaa !21
  br i1 %t436, label %bb79, label %bb80
bb79:
  %t437 = load ptr, ptr %l1, !tbaa !29
  %t439 = getelementptr { i64, [3 x i64] }, ptr %t437, i32 0, i32 1
  %t440 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t439, i32 0, i32 1
  %t441 = load i32, ptr %t440
  store i32 %t441, ptr %l14, !tbaa !23
  %t443 = load ptr, ptr %l1, !tbaa !29
  %t445 = getelementptr { i64, [3 x i64] }, ptr %t443, i32 0, i32 1
  %t446 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t445, i32 0, i32 2
  %t447 = load i64, ptr %t446
  store i64 %t447, ptr %l15, !tbaa !24
  br label %bb81
bb80:
  br label %bb84
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t449 = load ptr, ptr %l0, !tbaa !29
  store ptr %t449, ptr %l174, !tbaa !29
  %t450 = load i64, ptr %l2, !tbaa !24
  store i64 %t450, ptr %l175, !tbaa !24
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/typed:printer", ptr %t451, i32 0, i32 0
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t455 = load i32, ptr %l14, !tbaa !23
  %t458 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s17, ptr %t454, i32 %t455)
  store { i64, ptr } %t458, ptr %l179
  br label %bb82
bb82:
  %t459 = load i64, ptr %l15, !tbaa !24
  %t460 = extractvalue { i64, ptr } { i64 6, ptr @.d98 }, 1
  %t461 = extractvalue { i64, ptr } { i64 6, ptr @.d98 }, 0
  %t462 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t463 = extractvalue { i64, ptr } %t462, 1
  %t464 = extractvalue { i64, ptr } %t462, 0
  %t465 = add i64 %t461, %t464
  %t466 = extractvalue { i64, ptr } { i64 1, ptr @.d99 }, 1
  %t467 = extractvalue { i64, ptr } { i64 1, ptr @.d99 }, 0
  %t468 = add i64 %t465, %t467
  %t470 = call i64 @__olang_fmt_i64(ptr null, i64 %t459)
  %t471 = add i64 %t468, %t470
  %t472 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t471)
  call void @olang_textcopy(ptr %t472, ptr %t460, i64 %t461)
  %t473 = getelementptr i8, ptr %t472, i64 %t461
  call void @olang_textcopy(ptr %t473, ptr %t463, i64 %t464)
  %t474 = getelementptr i8, ptr %t473, i64 %t464
  call void @olang_textcopy(ptr %t474, ptr %t466, i64 %t467)
  %t475 = getelementptr i8, ptr %t474, i64 %t467
  %t476 = call i64 @__olang_fmt_i64(ptr %t475, i64 %t459)
  %t477 = insertvalue { i64, ptr } undef, i64 %t471, 0
  %t478 = insertvalue { i64, ptr } %t477, ptr %t472, 1
  %t480 = extractvalue { i64, ptr } %t478, 0
  %t481 = extractvalue { i64, ptr } %t478, 1
  %t482 = mul i64 %t480, 1
  %t483 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t482)
  call void @llvm.memcpy.p0.p0.i64(ptr %t483, ptr %t481, i64 %t482, i1 false)
  %t484 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t485 = insertvalue { i64, ptr } %t484, ptr %t483, 1
  %t486 = load ptr, ptr %l174, !tbaa !29
  %t487 = load i64, ptr %l175, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s17, ptr %t486, i64 %t487, { i64, ptr } %t485)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s17)
  br label %bb144
bb84:
  %t489 = load ptr, ptr %l1, !tbaa !29
  store ptr %t489, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t490 = load ptr, ptr %l183, !tbaa !29
  %t491 = icmp ne ptr %t490, null
  br i1 %t491, label %bb85, label %bb86
bb85:
  %t493 = load ptr, ptr %l183, !tbaa !29
  %t494 = load i64, ptr %t493
  %t496 = icmp eq i64 %t494, 8
  store i1 %t496, ptr %l184, !tbaa !21
  br label %bb86
bb86:
  %t497 = load i1, ptr %l184, !tbaa !21
  br i1 %t497, label %bb87, label %bb88
bb87:
  %t498 = load ptr, ptr %l1, !tbaa !29
  %t500 = getelementptr { i64, [3 x i64] }, ptr %t498, i32 0, i32 1
  %t501 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t500, i32 0, i32 1
  %t502 = load i32, ptr %t501
  store i32 %t502, ptr %l16
  br label %bb89
bb88:
  br label %bb93
bb89:
  store %olang.scope zeroinitializer, ptr %s19
  %t504 = load ptr, ptr %l0, !tbaa !29
  store ptr %t504, ptr %l189, !tbaa !29
  %t505 = load i64, ptr %l2, !tbaa !24
  store i64 %t505, ptr %l190, !tbaa !24
  %t506 = load i32, ptr %l16
  store i32 %t506, ptr %l191
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s20
  store ptr %s20room, ptr %s20
  call void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aExitKind(ptr %s20, ptr %l191, i64 0)
  br label %bb90
bb90:
  %t508 = load ptr, ptr %s20
  %t509 = getelementptr %olang.builder, ptr %s20, i32 0, i32 1
  %t510 = load i64, ptr %t509
  %t511 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t510)
  call void @olang_textcopy(ptr %t511, ptr %t508, i64 %t510)
  %t512 = insertvalue { i64, ptr } undef, i64 %t510, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  store { i64, ptr } %t513, ptr %l193, !tbaa !27
  %t514 = getelementptr %olang.builder, ptr %s20, i32 0, i32 3
  %t515 = load ptr, ptr %t514
  %t516 = icmp ne ptr %t515, null
  br i1 %t516, label %sbgrew.517, label %sbdone.518
sbgrew.517:
  call void @__olang_sb_done(ptr %s20)
  br label %sbdone.518
sbdone.518:
  %t519 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t520 = extractvalue { i64, ptr } %t519, 0
  %t521 = extractvalue { i64, ptr } %t519, 1
  %t522 = mul i64 %t520, 1
  %t523 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t522)
  call void @llvm.memcpy.p0.p0.i64(ptr %t523, ptr %t521, i64 %t522, i1 false)
  %t524 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t525 = insertvalue { i64, ptr } %t524, ptr %t523, 1
  %t527 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s19, { i64, ptr } %t525)
  store { i64, ptr } %t527, ptr %l195
  br label %bb91
bb91:
  %t528 = extractvalue { i64, ptr } { i64 5, ptr @.d100 }, 1
  %t529 = extractvalue { i64, ptr } { i64 5, ptr @.d100 }, 0
  %t530 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t531 = extractvalue { i64, ptr } %t530, 1
  %t532 = extractvalue { i64, ptr } %t530, 0
  %t533 = add i64 %t529, %t532
  %t534 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t533)
  call void @olang_textcopy(ptr %t534, ptr %t528, i64 %t529)
  %t535 = getelementptr i8, ptr %t534, i64 %t529
  call void @olang_textcopy(ptr %t535, ptr %t531, i64 %t532)
  %t536 = insertvalue { i64, ptr } undef, i64 %t533, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t534, 1
  %t539 = extractvalue { i64, ptr } %t537, 0
  %t540 = extractvalue { i64, ptr } %t537, 1
  %t541 = mul i64 %t539, 1
  %t542 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t541)
  call void @llvm.memcpy.p0.p0.i64(ptr %t542, ptr %t540, i64 %t541, i1 false)
  %t543 = insertvalue { i64, ptr } undef, i64 %t539, 0
  %t544 = insertvalue { i64, ptr } %t543, ptr %t542, 1
  %t545 = load ptr, ptr %l189, !tbaa !29
  %t546 = load i64, ptr %l190, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s19, ptr %t545, i64 %t546, { i64, ptr } %t544)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s19)
  br label %bb144
bb93:
  %t548 = load ptr, ptr %l1, !tbaa !29
  store ptr %t548, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t549 = load ptr, ptr %l198, !tbaa !29
  %t550 = icmp ne ptr %t549, null
  br i1 %t550, label %bb94, label %bb95
bb94:
  %t552 = load ptr, ptr %l198, !tbaa !29
  %t553 = load i64, ptr %t552
  %t555 = icmp eq i64 %t553, 9
  store i1 %t555, ptr %l199, !tbaa !21
  br label %bb95
bb95:
  %t556 = load i1, ptr %l199, !tbaa !21
  br i1 %t556, label %bb96, label %bb97
bb96:
  %t557 = load ptr, ptr %l1, !tbaa !29
  %t559 = getelementptr { i64, [3 x i64] }, ptr %t557, i32 0, i32 1
  %t560 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t559, i32 0, i32 1
  %t561 = load ptr, ptr %t560
  store ptr %t561, ptr %l17, !tbaa !29
  br label %bb98
bb97:
  br label %bb101
bb98:
  store %olang.scope zeroinitializer, ptr %s22
  %t563 = load ptr, ptr %l0, !tbaa !29
  store ptr %t563, ptr %l204, !tbaa !29
  %t564 = load i64, ptr %l2, !tbaa !24
  store i64 %t564, ptr %l205, !tbaa !24
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load ptr, ptr %l17, !tbaa !29
  %t570 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s22, ptr %t565, ptr %t566)
  store { i64, ptr } %t570, ptr %l209
  br label %bb99
bb99:
  %t571 = extractvalue { i64, ptr } { i64 7, ptr @.d101 }, 1
  %t572 = extractvalue { i64, ptr } { i64 7, ptr @.d101 }, 0
  %t573 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t573, 1
  %t575 = extractvalue { i64, ptr } %t573, 0
  %t576 = add i64 %t572, %t575
  %t577 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t576)
  call void @olang_textcopy(ptr %t577, ptr %t571, i64 %t572)
  %t578 = getelementptr i8, ptr %t577, i64 %t572
  call void @olang_textcopy(ptr %t578, ptr %t574, i64 %t575)
  %t579 = insertvalue { i64, ptr } undef, i64 %t576, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t577, 1
  %t582 = extractvalue { i64, ptr } %t580, 0
  %t583 = extractvalue { i64, ptr } %t580, 1
  %t584 = mul i64 %t582, 1
  %t585 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t584)
  call void @llvm.memcpy.p0.p0.i64(ptr %t585, ptr %t583, i64 %t584, i1 false)
  %t586 = insertvalue { i64, ptr } undef, i64 %t582, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t585, 1
  %t588 = load ptr, ptr %l204, !tbaa !29
  %t589 = load i64, ptr %l205, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s22, ptr %t588, i64 %t589, { i64, ptr } %t587)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s22)
  br label %bb144
bb101:
  %t591 = load ptr, ptr %l1, !tbaa !29
  store ptr %t591, ptr %l212, !tbaa !29
  store i1 false, ptr %l213, !tbaa !21
  %t592 = load ptr, ptr %l212, !tbaa !29
  %t593 = icmp ne ptr %t592, null
  br i1 %t593, label %bb102, label %bb103
bb102:
  %t595 = load ptr, ptr %l212, !tbaa !29
  %t596 = load i64, ptr %t595
  %t598 = icmp eq i64 %t596, 10
  store i1 %t598, ptr %l213, !tbaa !21
  br label %bb103
bb103:
  %t599 = load i1, ptr %l213, !tbaa !21
  br i1 %t599, label %bb104, label %bb105
bb104:
  %t600 = load ptr, ptr %l1, !tbaa !29
  %t602 = getelementptr { i64, [3 x i64] }, ptr %t600, i32 0, i32 1
  %t603 = getelementptr { %"compiler/source:Span", ptr }, ptr %t602, i32 0, i32 1
  %t604 = load ptr, ptr %t603
  store ptr %t604, ptr %l18, !tbaa !29
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load ptr, ptr %l18, !tbaa !29
  %t608 = load i64, ptr %l2, !tbaa !24
  %t610 = add i64 %t608, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t606, ptr %t607, i64 %t610)
  br label %bb107
bb107:
  br label %bb144
bb108:
  %t614 = load ptr, ptr %l1, !tbaa !29
  store ptr %t614, ptr %l222, !tbaa !29
  store i1 false, ptr %l223, !tbaa !21
  %t615 = load ptr, ptr %l222, !tbaa !29
  %t616 = icmp ne ptr %t615, null
  br i1 %t616, label %bb109, label %bb110
bb109:
  %t618 = load ptr, ptr %l222, !tbaa !29
  %t619 = load i64, ptr %t618
  %t621 = icmp eq i64 %t619, 11
  store i1 %t621, ptr %l223, !tbaa !21
  br label %bb110
bb110:
  %t622 = load i1, ptr %l223, !tbaa !21
  br i1 %t622, label %bb111, label %bb112
bb111:
  %t623 = load ptr, ptr %l1, !tbaa !29
  %t625 = getelementptr { i64, [3 x i64] }, ptr %t623, i32 0, i32 1
  %t626 = getelementptr { %"compiler/source:Span", ptr }, ptr %t625, i32 0, i32 1
  %t627 = load ptr, ptr %t626
  store ptr %t627, ptr %l19, !tbaa !29
  br label %bb113
bb112:
  br label %bb116
bb113:
  store %olang.scope zeroinitializer, ptr %s25
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t630 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s25, ptr %t629, i64 %t630, { i64, ptr } { i64 5, ptr @.d102 })
  br label %bb114
bb114:
  %t633 = load ptr, ptr %l0, !tbaa !29
  %t634 = load ptr, ptr %l19, !tbaa !29
  %t635 = load i64, ptr %l2, !tbaa !24
  %t637 = add i64 %t635, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t633, ptr %t634, i64 %t637)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s25)
  br label %bb144
bb116:
  %t641 = load ptr, ptr %l1, !tbaa !29
  store ptr %t641, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t642 = load ptr, ptr %l234, !tbaa !29
  %t643 = icmp ne ptr %t642, null
  br i1 %t643, label %bb117, label %bb118
bb117:
  %t645 = load ptr, ptr %l234, !tbaa !29
  %t646 = load i64, ptr %t645
  %t648 = icmp eq i64 %t646, 12
  store i1 %t648, ptr %l235, !tbaa !21
  br label %bb118
bb118:
  %t649 = load i1, ptr %l235, !tbaa !21
  br i1 %t649, label %bb119, label %bb120
bb119:
  %t650 = load ptr, ptr %l1, !tbaa !29
  %t652 = getelementptr { i64, [3 x i64] }, ptr %t650, i32 0, i32 1
  %t653 = getelementptr { %"compiler/source:Span", ptr }, ptr %t652, i32 0, i32 1
  %t654 = load ptr, ptr %t653
  store ptr %t654, ptr %l20, !tbaa !29
  br label %bb121
bb120:
  br label %bb127
bb121:
  store %olang.scope zeroinitializer, ptr %s26
  %t656 = load ptr, ptr %l0, !tbaa !29
  store ptr %t656, ptr %l240, !tbaa !29
  %t657 = load i64, ptr %l2, !tbaa !24
  store i64 %t657, ptr %l241, !tbaa !24
  %t658 = load ptr, ptr %l20, !tbaa !29
  %t660 = getelementptr %"compiler/typed:Join", ptr %t658, i32 0, i32 1
  %t661 = load i1, ptr %t660, !tbaa !21
  br i1 %t661, label %bb122, label %bb123
bb122:
  store { i64, ptr } { i64 4, ptr @.d103 }, ptr %l244, !tbaa !27
  br label %bb124
bb123:
  store { i64, ptr } { i64 0, ptr @.d104 }, ptr %l244, !tbaa !27
  br label %bb124
bb124:
  %t663 = extractvalue { i64, ptr } { i64 4, ptr @.d105 }, 1
  %t664 = extractvalue { i64, ptr } { i64 4, ptr @.d105 }, 0
  %t665 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t665, 1
  %t667 = extractvalue { i64, ptr } %t665, 0
  %t668 = add i64 %t664, %t667
  %t669 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t668)
  call void @olang_textcopy(ptr %t669, ptr %t663, i64 %t664)
  %t670 = getelementptr i8, ptr %t669, i64 %t664
  call void @olang_textcopy(ptr %t670, ptr %t666, i64 %t667)
  %t671 = insertvalue { i64, ptr } undef, i64 %t668, 0
  %t672 = insertvalue { i64, ptr } %t671, ptr %t669, 1
  %t674 = extractvalue { i64, ptr } %t672, 0
  %t675 = extractvalue { i64, ptr } %t672, 1
  %t676 = mul i64 %t674, 1
  %t677 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t676)
  call void @llvm.memcpy.p0.p0.i64(ptr %t677, ptr %t675, i64 %t676, i1 false)
  %t678 = insertvalue { i64, ptr } undef, i64 %t674, 0
  %t679 = insertvalue { i64, ptr } %t678, ptr %t677, 1
  %t680 = load ptr, ptr %l240, !tbaa !29
  %t681 = load i64, ptr %l241, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s26, ptr %t680, i64 %t681, { i64, ptr } %t679)
  br label %bb125
bb125:
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t684 = load ptr, ptr %l20, !tbaa !29
  %t686 = getelementptr %"compiler/typed:Join", ptr %t684, i32 0, i32 0
  %t687 = load ptr, ptr %t686, !tbaa !29
  %t688 = load i64, ptr %l2, !tbaa !24
  %t690 = add i64 %t688, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %t683, ptr %t687, i64 %t690)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s26)
  br label %bb144
bb127:
  %t694 = load ptr, ptr %l1, !tbaa !29
  store ptr %t694, ptr %l252, !tbaa !29
  store i1 false, ptr %l253, !tbaa !21
  %t695 = load ptr, ptr %l252, !tbaa !29
  %t696 = icmp ne ptr %t695, null
  br i1 %t696, label %bb128, label %bb129
bb128:
  %t698 = load ptr, ptr %l252, !tbaa !29
  %t699 = load i64, ptr %t698
  %t701 = icmp eq i64 %t699, 13
  store i1 %t701, ptr %l253, !tbaa !21
  br label %bb129
bb129:
  %t702 = load i1, ptr %l253, !tbaa !21
  br i1 %t702, label %bb130, label %bb131
bb130:
  %t703 = load ptr, ptr %l1, !tbaa !29
  %t705 = getelementptr { i64, [3 x i64] }, ptr %t703, i32 0, i32 1
  %t706 = getelementptr { %"compiler/source:Span", ptr }, ptr %t705, i32 0, i32 1
  %t707 = load ptr, ptr %t706
  store ptr %t707, ptr %l21, !tbaa !29
  br label %bb132
bb131:
  br label %bb135
bb132:
  store %olang.scope zeroinitializer, ptr %s28
  %t709 = load ptr, ptr %l0, !tbaa !29
  store ptr %t709, ptr %l258, !tbaa !29
  %t710 = load i64, ptr %l2, !tbaa !24
  store i64 %t710, ptr %l259, !tbaa !24
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t712 = load ptr, ptr %l21, !tbaa !29
  %t714 = getelementptr %"compiler/typed:Spawn", ptr %t712, i32 0, i32 1
  %t715 = load ptr, ptr %t714, !tbaa !29
  %t719 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s28, ptr %t711, ptr %t715)
  store { i64, ptr } %t719, ptr %l264
  br label %bb133
bb133:
  %t720 = load ptr, ptr %l21, !tbaa !29
  %t722 = getelementptr %"compiler/typed:Spawn", ptr %t720, i32 0, i32 3
  %t723 = load i32, ptr %t722, !tbaa !23
  %t724 = extractvalue { i64, ptr } { i64 6, ptr @.d106 }, 1
  %t725 = extractvalue { i64, ptr } { i64 6, ptr @.d106 }, 0
  %t726 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t727 = extractvalue { i64, ptr } %t726, 1
  %t728 = extractvalue { i64, ptr } %t726, 0
  %t729 = add i64 %t725, %t728
  %t730 = extractvalue { i64, ptr } { i64 6, ptr @.d107 }, 1
  %t731 = extractvalue { i64, ptr } { i64 6, ptr @.d107 }, 0
  %t732 = add i64 %t729, %t731
  %t734 = sext i32 %t723 to i64
  %t735 = call i64 @__olang_fmt_i64(ptr null, i64 %t734)
  %t736 = add i64 %t732, %t735
  %t737 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t736)
  call void @olang_textcopy(ptr %t737, ptr %t724, i64 %t725)
  %t738 = getelementptr i8, ptr %t737, i64 %t725
  call void @olang_textcopy(ptr %t738, ptr %t727, i64 %t728)
  %t739 = getelementptr i8, ptr %t738, i64 %t728
  call void @olang_textcopy(ptr %t739, ptr %t730, i64 %t731)
  %t740 = getelementptr i8, ptr %t739, i64 %t731
  %t741 = call i64 @__olang_fmt_i64(ptr %t740, i64 %t734)
  %t742 = insertvalue { i64, ptr } undef, i64 %t736, 0
  %t743 = insertvalue { i64, ptr } %t742, ptr %t737, 1
  %t745 = extractvalue { i64, ptr } %t743, 0
  %t746 = extractvalue { i64, ptr } %t743, 1
  %t747 = mul i64 %t745, 1
  %t748 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t747)
  call void @llvm.memcpy.p0.p0.i64(ptr %t748, ptr %t746, i64 %t747, i1 false)
  %t749 = insertvalue { i64, ptr } undef, i64 %t745, 0
  %t750 = insertvalue { i64, ptr } %t749, ptr %t748, 1
  %t751 = load ptr, ptr %l258, !tbaa !29
  %t752 = load i64, ptr %l259, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s28, ptr %t751, i64 %t752, { i64, ptr } %t750)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s28)
  br label %bb144
bb135:
  %t754 = load ptr, ptr %l1, !tbaa !29
  store ptr %t754, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t755 = load ptr, ptr %l269, !tbaa !29
  %t756 = icmp ne ptr %t755, null
  br i1 %t756, label %bb136, label %bb137
bb136:
  %t758 = load ptr, ptr %l269, !tbaa !29
  %t759 = load i64, ptr %t758
  %t761 = icmp eq i64 %t759, 14
  store i1 %t761, ptr %l270, !tbaa !21
  br label %bb137
bb137:
  %t762 = load i1, ptr %l270, !tbaa !21
  br i1 %t762, label %bb138, label %bb139
bb138:
  %t763 = load ptr, ptr %l1, !tbaa !29
  %t765 = getelementptr { i64, [3 x i64] }, ptr %t763, i32 0, i32 1
  %t766 = getelementptr { %"compiler/source:Span", ptr }, ptr %t765, i32 0, i32 1
  %t767 = load ptr, ptr %t766
  store ptr %t767, ptr %l22, !tbaa !29
  br label %bb140
bb139:
  br label %bb143
bb140:
  store %olang.scope zeroinitializer, ptr %s30
  %t769 = load ptr, ptr %l0, !tbaa !29
  store ptr %t769, ptr %l275, !tbaa !29
  %t770 = load i64, ptr %l2, !tbaa !24
  store i64 %t770, ptr %l276, !tbaa !24
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t772 = load ptr, ptr %l22, !tbaa !29
  %t776 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s30, ptr %t771, ptr %t772)
  store { i64, ptr } %t776, ptr %l280
  br label %bb141
bb141:
  %t777 = extractvalue { i64, ptr } { i64 6, ptr @.d108 }, 1
  %t778 = extractvalue { i64, ptr } { i64 6, ptr @.d108 }, 0
  %t779 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t780 = extractvalue { i64, ptr } %t779, 1
  %t781 = extractvalue { i64, ptr } %t779, 0
  %t782 = add i64 %t778, %t781
  %t783 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t782)
  call void @olang_textcopy(ptr %t783, ptr %t777, i64 %t778)
  %t784 = getelementptr i8, ptr %t783, i64 %t778
  call void @olang_textcopy(ptr %t784, ptr %t780, i64 %t781)
  %t785 = insertvalue { i64, ptr } undef, i64 %t782, 0
  %t786 = insertvalue { i64, ptr } %t785, ptr %t783, 1
  %t788 = extractvalue { i64, ptr } %t786, 0
  %t789 = extractvalue { i64, ptr } %t786, 1
  %t790 = mul i64 %t788, 1
  %t791 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t790)
  call void @llvm.memcpy.p0.p0.i64(ptr %t791, ptr %t789, i64 %t790, i1 false)
  %t792 = insertvalue { i64, ptr } undef, i64 %t788, 0
  %t793 = insertvalue { i64, ptr } %t792, ptr %t791, 1
  %t794 = load ptr, ptr %l275, !tbaa !29
  %t795 = load i64, ptr %l276, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s30, ptr %t794, i64 %t795, { i64, ptr } %t793)
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s30)
  br label %bb144
bb143:
  call void @__olang_check_failed(ptr @olang_loc_c849604dc8cd9caf_344d20d2e301b9ab)
  unreachable
bb144:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2econstItems(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 91)
  br label %bb2
bb2:
  store i64 0, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb5:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l18, !tbaa !24
  store i64 %t34, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l15, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb13, label %bb14
bb13:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 32)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store ptr %l1, ptr %l39, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t59, ptr %l40, !tbaa !27
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 %t60
  %t65 = load ptr, ptr %t64, !tbaa !39
  %t67 = call { i64, ptr } @compiler_2ftyped_2econstText(ptr %v0, ptr %s2, ptr %t65)
  store { i64, ptr } %t67, ptr %l43
  br label %bb17
bb17:
  %t68 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t75, { i64, ptr } %t74)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb9
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 93)
  br label %bb21
bb21:
  %t83 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t83, ptr %l49
  br label %bb22
bb22:
  %t84 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l51, !tbaa !24
  %t87 = load i64, ptr %l51, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l52, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t98, ptr %l50, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t99 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t99, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2econstText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l1, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = call i64 @__olang_fmt_i64(ptr null, i64 %t16)
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t16)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t19, 1
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  br label %bb20
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l13, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l14, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr } }, ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = extractvalue { i64, ptr } { i64 5, ptr @.d109 }, 1
  %t43 = extractvalue { i64, ptr } { i64 5, ptr @.d109 }, 0
  %t45 = call i64 @__olang_fmt_i64(ptr null, i64 %t41)
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = getelementptr i8, ptr %t47, i64 %t43
  %t49 = call i64 @__olang_fmt_i64(ptr %t48, i64 %t41)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t47, 1
  store { i64, ptr } %t51, ptr %l4, !tbaa !27
  br label %bb20
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t54 = load ptr, ptr %l22, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l22, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 2
  store i1 %t60, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t61 = load i1, ptr %l23, !tbaa !21
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { { i64, ptr } }, ptr %t64, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65
  store { i64, ptr } %t66, ptr %l3, !tbaa !27
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = call { i64, ptr } @compiler_2ftyped_2econstItems(ptr %v0, ptr %v1, { i64, ptr } %t68)
  store { i64, ptr } %t70, ptr %l29
  br label %bb18
bb18:
  %t71 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t71, ptr %l4, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_411550143d3b0e9d_42067e02948bd729)
  unreachable
bb20:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2eshort(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr @.d110 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t9, ptr %rv
  br label %ret
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t15 = add i64 %t11, 1
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 0
  store i64 %t19, ptr %l12, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
bb7:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l12, !tbaa !24
  %t37 = getelementptr i8, ptr %t34, i64 %t35
  %t38 = sub i64 %t36, %t35
  %t39 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/typed:Alt" @compiler_2ftyped_3aAlt_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Alt"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Alt" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/typed:Alt" %t6, { i64, ptr } %a1, 1
  store %"compiler/typed:Alt" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Alt", ptr %rv
  ret %"compiler/typed:Alt" %rr
}

define dso_local %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Arm"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Arm" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/typed:Arm" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Arm" %t14, ptr %a2, 2
  %t18 = insertvalue %"compiler/typed:Arm" %t16, ptr %a3, 3
  %t20 = insertvalue %"compiler/typed:Arm" %t18, ptr %a4, 4
  store %"compiler/typed:Arm" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Arm", ptr %rv
  ret %"compiler/typed:Arm" %rr
}

define dso_local %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Bind"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Bind" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Bind" %t6, ptr %a1, 1
  store %"compiler/typed:Bind" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Bind", ptr %rv
  ret %"compiler/typed:Bind" %rr
}

define dso_local %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %v0, i32 %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:BlockInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:BlockInfo" undef, i32 %a0, 0
  %t10 = insertvalue %"compiler/typed:BlockInfo" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/typed:BlockInfo" %t10, %"compiler/source:Span" %a2, 2
  store %"compiler/typed:BlockInfo" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:BlockInfo", ptr %rv
  ret %"compiler/typed:BlockInfo" %rr
}

define dso_local %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Block"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Block" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Block" %t6, { i64, ptr } %a1, 1
  store %"compiler/typed:Block" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Block", ptr %rv
  ret %"compiler/typed:Block" %rr
}

define dso_local %"compiler/typed:Body" @compiler_2ftyped_3aBody_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/typed:Body"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l5, !tbaa !23
  store { i64, [2 x i64] } %a1, ptr %l6
  store i32 %a2, ptr %l7, !tbaa !23
  store i64 %a3, ptr %l8, !tbaa !24
  store %"compiler/source:Span" %a4, ptr %l9
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e(ptr %t11)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l22
  br label %bb1
bb1:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l10
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e(ptr %t14)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l23
  br label %bb2
bb2:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l11
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e(ptr %t17)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l24
  br label %bb3
bb3:
  %t19 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l12
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %t20)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l25
  br label %bb4
bb4:
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l13
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %t23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l26
  br label %bb5
bb5:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l14
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e(ptr %t26)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l27
  br label %bb6
bb6:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  %t29 = load i32, ptr %l5, !tbaa !23
  %t30 = insertvalue %"compiler/typed:Body" undef, i32 %t29, 0
  %t31 = load { i64, [2 x i64] }, ptr %l6
  %t32 = insertvalue %"compiler/typed:Body" %t30, { i64, [2 x i64] } %t31, 1
  %t33 = load i32, ptr %l7, !tbaa !23
  %t34 = insertvalue %"compiler/typed:Body" %t32, i32 %t33, 2
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = insertvalue %"compiler/typed:Body" %t34, i64 %t35, 3
  %t37 = load %"compiler/source:Span", ptr %l9
  %t38 = insertvalue %"compiler/typed:Body" %t36, %"compiler/source:Span" %t37, 4
  %t39 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t40 = insertvalue %"compiler/typed:Body" %t38, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, 5
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t42 = insertvalue %"compiler/typed:Body" %t40, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, 6
  %t43 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t44 = insertvalue %"compiler/typed:Body" %t42, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, 7
  %t45 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t46 = insertvalue %"compiler/typed:Body" %t44, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, 8
  %t47 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  %t48 = insertvalue %"compiler/typed:Body" %t46, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, 9
  %t50 = insertvalue %"compiler/typed:Body" %t48, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, 10
  %t52 = insertvalue %"compiler/typed:Body" %t50, ptr null, 11
  store %"compiler/typed:Body" %t52, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Body", ptr %rv
  ret %"compiler/typed:Body" %rr
}

define dso_local %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Call"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Call" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/typed:Call" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Call" %t14, { i64, [2 x i64] } %a2, 2
  %t18 = insertvalue %"compiler/typed:Call" %t16, i32 %a3, 3
  %t20 = insertvalue %"compiler/typed:Call" %t18, i1 %a4, 4
  store %"compiler/typed:Call" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Call", ptr %rv
  ret %"compiler/typed:Call" %rr
}

define dso_local %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Capture"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Capture" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Capture" %t6, ptr %a1, 1
  store %"compiler/typed:Capture" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Capture", ptr %rv
  ret %"compiler/typed:Capture" %rr
}

define dso_local %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Clause"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Clause" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/typed:Clause" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Clause" %t14, i1 %a2, 2
  %t18 = insertvalue %"compiler/typed:Clause" %t16, ptr %a3, 3
  %t20 = insertvalue %"compiler/typed:Clause" %t18, { i64, ptr } %a4, 4
  store %"compiler/typed:Clause" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Clause", ptr %rv
  ret %"compiler/typed:Clause" %rr
}

define dso_local %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Collect"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Collect" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/typed:Collect" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/typed:Collect" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/typed:Collect" %t14, i32 %a3, 3
  store %"compiler/typed:Collect" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Collect", ptr %rv
  ret %"compiler/typed:Collect" %rr
}

define dso_local %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Cond"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Cond" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Cond" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Cond" %t10, ptr %a2, 2
  store %"compiler/typed:Cond" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Cond", ptr %rv
  ret %"compiler/typed:Cond" %rr
}

define dso_local %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Elem"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Elem" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Elem" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Elem" %t10, i32 %a2, 2
  store %"compiler/typed:Elem" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Elem", ptr %rv
  ret %"compiler/typed:Elem" %rr
}

define dso_local %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:If"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:If" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:If" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:If" %t10, ptr %a2, 2
  store %"compiler/typed:If" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:If", ptr %rv
  ret %"compiler/typed:If" %rr
}

define dso_local %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Item"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Item" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Item" %t6, i64 %a1, 1
  store %"compiler/typed:Item" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Item", ptr %rv
  ret %"compiler/typed:Item" %rr
}

define dso_local %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Join"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Join" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Join" %t8, i1 %a1, 1
  %t12 = insertvalue %"compiler/typed:Join" %t10, { i64, ptr } %a2, 2
  store %"compiler/typed:Join" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Join", ptr %rv
  ret %"compiler/typed:Join" %rr
}

define dso_local %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5) #0 {
entry:
  %rv = alloca %"compiler/typed:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/typed:Local" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/typed:Local" %t14, %"compiler/source:Span" %a1, 1
  %t18 = insertvalue %"compiler/typed:Local" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/typed:Local" %t18, i32 %a3, 3
  %t22 = insertvalue %"compiler/typed:Local" %t20, i32 %a4, 4
  %t24 = insertvalue %"compiler/typed:Local" %t22, { i64, [2 x i64] } %a5, 5
  store %"compiler/typed:Local" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Local", ptr %rv
  ret %"compiler/typed:Local" %rr
}

define dso_local %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5) #0 {
entry:
  %rv = alloca %"compiler/typed:Make"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/typed:Make" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/typed:Make" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/typed:Make" %t16, { i64, ptr } %a2, 2
  %t20 = insertvalue %"compiler/typed:Make" %t18, ptr %a3, 3
  %t22 = insertvalue %"compiler/typed:Make" %t20, i32 %a4, 4
  %t24 = insertvalue %"compiler/typed:Make" %t22, i32 %a5, 5
  store %"compiler/typed:Make" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Make", ptr %rv
  ret %"compiler/typed:Make" %rr
}

define dso_local %"compiler/typed:Match" @compiler_2ftyped_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Match"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Match" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/typed:Match" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/typed:Match" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/typed:Match" %t14, i1 %a3, 3
  store %"compiler/typed:Match" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Match", ptr %rv
  ret %"compiler/typed:Match" %rr
}

define dso_local %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Payload"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Payload" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Payload" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/typed:Payload" %t10, i32 %a2, 2
  store %"compiler/typed:Payload" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Payload", ptr %rv
  ret %"compiler/typed:Payload" %rr
}

define dso_local %"compiler/typed:Plan" @compiler_2ftyped_3aPlan_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, [1 x i64] }
  %l18 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/typed:Plan"
  %t15 = alloca { i64, [1 x i64] }, align 8
  %t28 = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l9, !tbaa !24
  %t2 = load i64, ptr %l9, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l9, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_480f1658b5360f56_487a5534952ab742)
  unreachable
bb3:
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 %a1, ptr %l13, !tbaa !24
  store { i64, [1 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [1 x i64] }, ptr %t15, i32 0, i32 0
  store i64 5, ptr %t16
  %t17 = load { i64, [1 x i64] }, ptr %t15
  store { i64, [1 x i64] } %t17, ptr %l14
  %t18 = load i64, ptr %l13, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_480f1658b5360f56_487a5534952ab742)
  unreachable
bb5:
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = icmp sle i64 %t21, 576460752303423487
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_8f643c1a2619646b_285ffd8328f7aef7)
  unreachable
bb7:
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = mul i64 %t24, 16
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = load { i64, [1 x i64] }, ptr %l14
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, %t24
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr { i64, [1 x i64] }, ptr %t26, i64 %t32
  store { i64, [1 x i64] } %t27, ptr %t34
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t26, 1
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  store i64 %a2, ptr %l18, !tbaa !24
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_8f643c1a2619646b_285ffd8328f7aef7)
  unreachable
bb9:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = mul i64 %t43, 1
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l5, !tbaa !27
  %t49 = load i64, ptr %l0, !tbaa !24
  store i64 %t49, ptr %l21, !tbaa !24
  %t50 = load i64, ptr %l21, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_879aacf2d1a22b08_c7cef0899cf1454)
  unreachable
bb11:
  %t53 = load i64, ptr %l21, !tbaa !24
  %t54 = icmp sle i64 %t53, 1152921504606846975
  br i1 %t54, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_642fe669e8876d75_a0626c7162644c61)
  unreachable
bb13:
  %t56 = load i64, ptr %l21, !tbaa !24
  %t57 = mul i64 %t56, 8
  %t58 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l6, !tbaa !27
  %t62 = load i64, ptr %l0, !tbaa !24
  store i64 %t62, ptr %l25, !tbaa !24
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  br i1 %t64, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_642fe669e8876d75_a0626c7162644c61)
  unreachable
bb15:
  %t66 = load i64, ptr %l25, !tbaa !24
  %t67 = icmp sle i64 %t66, 1152921504606846975
  br i1 %t67, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_d6ddef0f5c032242_b9ab7c7dee5da456)
  unreachable
bb17:
  %t69 = load i64, ptr %l25, !tbaa !24
  %t70 = mul i64 %t69, 8
  %t71 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l7, !tbaa !27
  %t75 = load ptr, ptr @__olang_prog_scope
  %t76 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e(ptr %t75)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l29
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d6ddef0f5c032242_b9ab7c7dee5da456)
  unreachable
bb19:
  %t77 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = insertvalue %"compiler/typed:Plan" undef, { i64, ptr } %t78, 0
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t81 = insertvalue %"compiler/typed:Plan" %t79, { i64, ptr } %t80, 1
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t83 = insertvalue %"compiler/typed:Plan" %t81, { i64, ptr } %t82, 2
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = insertvalue %"compiler/typed:Plan" %t83, { i64, ptr } %t84, 3
  %t86 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t87 = insertvalue %"compiler/typed:Plan" %t85, { i64, ptr } %t86, 4
  %t89 = insertvalue %"compiler/typed:Plan" %t87, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, 5
  store %"compiler/typed:Plan" %t89, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Plan", ptr %rv
  ret %"compiler/typed:Plan" %rr
}

define dso_local %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Promote"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Promote" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/typed:Promote" %t6, i32 %a1, 1
  store %"compiler/typed:Promote" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Promote", ptr %rv
  ret %"compiler/typed:Promote" %rr
}

define dso_local %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Seq"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Seq" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:Seq" %t6, ptr %a1, 1
  store %"compiler/typed:Seq" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Seq", ptr %rv
  ret %"compiler/typed:Seq" %rr
}

define dso_local %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:SiteInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:SiteInfo" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:SiteInfo" %t6, %"compiler/source:Span" %a1, 1
  store %"compiler/typed:SiteInfo" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:SiteInfo", ptr %rv
  ret %"compiler/typed:SiteInfo" %rr
}

define dso_local %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Slice"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Slice" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/typed:Slice" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/typed:Slice" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/typed:Slice" %t14, i32 %a3, 3
  store %"compiler/typed:Slice" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Slice", ptr %rv
  ret %"compiler/typed:Slice" %rr
}

define dso_local %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Spawn"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Spawn" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/typed:Spawn" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/typed:Spawn" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/typed:Spawn" %t14, i32 %a3, 3
  store %"compiler/typed:Spawn" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Spawn", ptr %rv
  ret %"compiler/typed:Spawn" %rr
}

define dso_local %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:TaskClause"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:TaskClause" undef, %"compiler/source:Span" %a0, 0
  %t12 = insertvalue %"compiler/typed:TaskClause" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/typed:TaskClause" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/typed:TaskClause" %t14, ptr %a3, 3
  store %"compiler/typed:TaskClause" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:TaskClause", ptr %rv
  ret %"compiler/typed:TaskClause" %rr
}

define dso_local %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Text"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Text" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:Text" %t6, i32 %a1, 1
  store %"compiler/typed:Text" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Text", ptr %rv
  ret %"compiler/typed:Text" %rr
}

define dso_local %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Try"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Try" undef, ptr %a0, 0
  %t12 = insertvalue %"compiler/typed:Try" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/typed:Try" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/typed:Try" %t14, i1 %a3, 3
  store %"compiler/typed:Try" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Try", ptr %rv
  ret %"compiler/typed:Try" %rr
}

define dso_local %"compiler/typed:printer" @compiler_2ftyped_3aprinter_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"compiler/typed:printer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %t3)
  store %"std/prelude/text:StringBuilder" %t4, ptr %l4
  br label %bb1
bb1:
  %t5 = load %"std/prelude/text:StringBuilder", ptr %l4
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t7 = insertvalue %"compiler/typed:printer" undef, ptr %t6, 0
  %t9 = insertvalue %"compiler/typed:printer" %t7, %"std/prelude/text:StringBuilder" %t5, 1
  store %"compiler/typed:printer" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:printer", ptr %rv
  ret %"compiler/typed:printer" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d0 = private constant [5 x i8] c"body "
declare i64 @__olang_fmt_i64(ptr, i64)
@.d1 = private constant [8 x i8] c" locals "
@.d2 = private constant [8 x i8] c" blocks "
@.d3 = private constant [6 x i8] c" sites"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d4 = private constant [1 x i8] c"{"
@.d5 = private constant [1 x i8] c"B"
@.d6 = private constant [7 x i8] c"extern "
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aHelper(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 12, ptr @.d111 }, 1
  %t6 = extractvalue { i64, ptr } { i64 12, ptr @.d111 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 11, ptr @.d112 }, 1
  %t8 = extractvalue { i64, ptr } { i64 11, ptr @.d112 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d7 = private constant [1 x i8] c" "
@.d8 = private constant [1 x i8] c"_"
@.d9 = private constant [5 x i8] c"(lit "
@.d10 = private constant [1 x i8] c" "
@.d11 = private constant [1 x i8] c")"
@.d12 = private constant [6 x i8] c"(data "
@.d13 = private constant [1 x i8] c" "
@.d14 = private constant [1 x i8] c" "
@.d15 = private constant [1 x i8] c")"
@.d16 = private constant [6 x i8] c" site "
@.d17 = private constant [0 x i8] c""
@.d18 = private constant [6 x i8] c"(read "
@.d19 = private constant [1 x i8] c")"
@.d20 = private constant [8 x i8] c"(borrow "
@.d21 = private constant [1 x i8] c" "
@.d22 = private constant [1 x i8] c")"
@.d23 = private constant [6 x i8] c"(take "
@.d24 = private constant [1 x i8] c")"
@.d25 = private constant [9 x i8] c"(promote "
@.d26 = private constant [1 x i8] c" "
@.d27 = private constant [6 x i8] c" site "
@.d28 = private constant [1 x i8] c")"
@.d29 = private constant [6 x i8] c"(call "
@.d30 = private constant [1 x i8] c" "
@.d31 = private constant [6 x i8] c" site "
@.d32 = private constant [1 x i8] c")"
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aMakeKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 14, ptr @.d113 }, 1
  %t6 = extractvalue { i64, ptr } { i64 14, ptr @.d113 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d114 }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr @.d114 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr @.d115 }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr @.d115 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 13, ptr @.d116 }, 1
  %t12 = extractvalue { i64, ptr } { i64 13, ptr @.d116 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
ret:
  ret void
}

@.d33 = private constant [6 x i8] c"(make "
@.d34 = private constant [1 x i8] c" "
@.d35 = private constant [1 x i8] c" "
@.d36 = private constant [1 x i8] c")"
@.d37 = private constant [9 x i8] c"(collect "
@.d38 = private constant [6 x i8] c" site "
@.d39 = private constant [1 x i8] c")"
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr @.d117 }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr @.d117 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 13, ptr @.d118 }, 1
  %t8 = extractvalue { i64, ptr } { i64 13, ptr @.d118 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 10, ptr @.d119 }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr @.d119 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 10, ptr @.d120 }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr @.d120 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 10, ptr @.d121 }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr @.d121 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 10, ptr @.d122 }, 1
  %t16 = extractvalue { i64, ptr } { i64 10, ptr @.d122 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 10, ptr @.d123 }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr @.d123 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 10, ptr @.d124 }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr @.d124 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 10, ptr @.d125 }, 1
  %t22 = extractvalue { i64, ptr } { i64 10, ptr @.d125 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 10, ptr @.d126 }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr @.d126 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 13, ptr @.d127 }, 1
  %t26 = extractvalue { i64, ptr } { i64 13, ptr @.d127 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 12, ptr @.d128 }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr @.d128 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 13, ptr @.d129 }, 1
  %t30 = extractvalue { i64, ptr } { i64 13, ptr @.d129 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 9, ptr @.d130 }, 1
  %t32 = extractvalue { i64, ptr } { i64 9, ptr @.d130 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 9, ptr @.d131 }, 1
  %t34 = extractvalue { i64, ptr } { i64 9, ptr @.d131 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 9, ptr @.d132 }, 1
  %t36 = extractvalue { i64, ptr } { i64 9, ptr @.d132 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 9, ptr @.d133 }, 1
  %t38 = extractvalue { i64, ptr } { i64 9, ptr @.d133 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr @.d134 }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr @.d134 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 9, ptr @.d135 }, 1
  %t42 = extractvalue { i64, ptr } { i64 9, ptr @.d135 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 11, ptr @.d136 }, 1
  %t44 = extractvalue { i64, ptr } { i64 11, ptr @.d136 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 14, ptr @.d137 }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr @.d137 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 14, ptr @.d138 }, 1
  %t48 = extractvalue { i64, ptr } { i64 14, ptr @.d138 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 10, ptr @.d139 }, 1
  %t50 = extractvalue { i64, ptr } { i64 10, ptr @.d139 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 13, ptr @.d140 }, 1
  %t52 = extractvalue { i64, ptr } { i64 13, ptr @.d140 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 14, ptr @.d141 }, 1
  %t54 = extractvalue { i64, ptr } { i64 14, ptr @.d141 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 18, ptr @.d142 }, 1
  %t56 = extractvalue { i64, ptr } { i64 18, ptr @.d142 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 17, ptr @.d143 }, 1
  %t58 = extractvalue { i64, ptr } { i64 17, ptr @.d143 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 18, ptr @.d144 }, 1
  %t60 = extractvalue { i64, ptr } { i64 18, ptr @.d144 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 16, ptr @.d145 }, 1
  %t62 = extractvalue { i64, ptr } { i64 16, ptr @.d145 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 17, ptr @.d146 }, 1
  %t64 = extractvalue { i64, ptr } { i64 17, ptr @.d146 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 24, ptr @.d147 }, 1
  %t66 = extractvalue { i64, ptr } { i64 24, ptr @.d147 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 13, ptr @.d148 }, 1
  %t68 = extractvalue { i64, ptr } { i64 13, ptr @.d148 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
ret:
  ret void
}

define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aCheck(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 10, ptr @.d149 }, 1
  %t6 = extractvalue { i64, ptr } { i64 10, ptr @.d149 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 11, ptr @.d150 }, 1
  %t8 = extractvalue { i64, ptr } { i64 11, ptr @.d150 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 9, ptr @.d151 }, 1
  %t10 = extractvalue { i64, ptr } { i64 9, ptr @.d151 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
ret:
  ret void
}

@.d40 = private constant [0 x i8] c""
@.d41 = private constant [1 x i8] c" "
@.d42 = private constant [1 x i8] c"("
@.d43 = private constant [1 x i8] c" "
@.d44 = private constant [1 x i8] c" "
@.d45 = private constant [1 x i8] c")"
@.d46 = private constant [7 x i8] c"(slice "
@.d47 = private constant [1 x i8] c" "
@.d48 = private constant [1 x i8] c" "
@.d49 = private constant [1 x i8] c")"
@.d50 = private constant [6 x i8] c"(cond "
@.d51 = private constant [1 x i8] c" "
@.d52 = private constant [1 x i8] c" "
@.d53 = private constant [1 x i8] c")"
@.d54 = private constant [5 x i8] c"(seq "
@.d55 = private constant [1 x i8] c" "
@.d56 = private constant [1 x i8] c")"
@.d57 = private constant [7 x i8] c"(match "
@.d58 = private constant [15 x i8] c" arms, nomatch "
@.d59 = private constant [1 x i8] c")"
@.d60 = private constant [5 x i8] c"(try "
@.d61 = private constant [1 x i8] c" "
@.d62 = private constant [9 x i8] c" clauses)"
@.d63 = private constant [4 x i8] c"(fn "
@.d64 = private constant [1 x i8] c")"
@.d65 = private constant [6 x i8] c"(text "
@.d66 = private constant [6 x i8] c" site "
@.d67 = private constant [1 x i8] c")"
@.d68 = private constant [6 x i8] c"(away "
@.d69 = private constant [1 x i8] c" "
@.d70 = private constant [1 x i8] c")"
@.d71 = private constant [2 x i8] c"  "
@.d72 = private constant [1 x i8] c"L"
@.d73 = private constant [1 x i8] c"G"
@.d74 = private constant [1 x i8] c":"
@.d75 = private constant [1 x i8] c"*"
@.d76 = private constant [1 x i8] c"."
@.d77 = private constant [1 x i8] c"["
@.d78 = private constant [1 x i8] c"]"
@.d79 = private constant [4 x i8] c" as "
@.d80 = private constant [4 x i8] c"tmp "
@.d81 = private constant [6 x i8] c" site "
@.d82 = private constant [6 x i8] c"target"
@.d83 = private constant [5 x i8] c"let L"
@.d84 = private constant [3 x i8] c" = "
@.d85 = private constant [7 x i8] c"assign "
@.d86 = private constant [3 x i8] c" = "
@.d87 = private constant [5 x i8] c"eval "
@.d88 = private constant [3 x i8] c"if "
@.d89 = private constant [4 x i8] c"else"
@.d90 = private constant [4 x i8] c"loop"
@.d91 = private constant [4 x i8] c"post"
@.d92 = private constant [5 x i8] c"break"
@.d93 = private constant [8 x i8] c"continue"
@.d94 = private constant [2 x i8] c" {"
@.d95 = private constant [0 x i8] c""
@.d96 = private constant [1 x i8] c" "
@.d97 = private constant [6 x i8] c"return"
@.d98 = private constant [6 x i8] c"raise "
@.d99 = private constant [1 x i8] c"."
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2ftyped_3aExitKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 20, ptr @.d152 }, 1
  %t6 = extractvalue { i64, ptr } { i64 20, ptr @.d152 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 20, ptr @.d153 }, 1
  %t8 = extractvalue { i64, ptr } { i64 20, ptr @.d153 }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
ret:
  ret void
}

@.d100 = private constant [5 x i8] c"exit "
@.d101 = private constant [7 x i8] c"assert "
@.d102 = private constant [5 x i8] c"defer"
@.d103 = private constant [4 x i8] c" try"
@.d104 = private constant [0 x i8] c""
@.d105 = private constant [4 x i8] c"join"
@.d106 = private constant [6 x i8] c"spawn "
@.d107 = private constant [6 x i8] c" site "
@.d108 = private constant [6 x i8] c"yield "
@.d109 = private constant [5 x i8] c"text "
@.d110 = private constant [1 x i8] c"."
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t1)
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d111 = private unnamed_addr constant [12 x i8] c"Helper.Equal"
declare void @__olang_sb_put(ptr, ptr, i64)
@.d112 = private unnamed_addr constant [11 x i8] c"Helper.Hash"
@.d113 = private unnamed_addr constant [14 x i8] c"MakeKind.Tuple"
@.d114 = private unnamed_addr constant [13 x i8] c"MakeKind.Case"
@.d115 = private unnamed_addr constant [14 x i8] c"MakeKind.Array"
@.d116 = private unnamed_addr constant [13 x i8] c"MakeKind.Fill"
@.d117 = private unnamed_addr constant [10 x i8] c"PrimOp.Neg"
@.d118 = private unnamed_addr constant [13 x i8] c"PrimOp.BitNot"
@.d119 = private unnamed_addr constant [10 x i8] c"PrimOp.Not"
@.d120 = private unnamed_addr constant [10 x i8] c"PrimOp.Add"
@.d121 = private unnamed_addr constant [10 x i8] c"PrimOp.Sub"
@.d122 = private unnamed_addr constant [10 x i8] c"PrimOp.Mul"
@.d123 = private unnamed_addr constant [10 x i8] c"PrimOp.Div"
@.d124 = private unnamed_addr constant [10 x i8] c"PrimOp.Rem"
@.d125 = private unnamed_addr constant [10 x i8] c"PrimOp.Shl"
@.d126 = private unnamed_addr constant [10 x i8] c"PrimOp.Shr"
@.d127 = private unnamed_addr constant [13 x i8] c"PrimOp.BitAnd"
@.d128 = private unnamed_addr constant [12 x i8] c"PrimOp.BitOr"
@.d129 = private unnamed_addr constant [13 x i8] c"PrimOp.BitXor"
@.d130 = private unnamed_addr constant [9 x i8] c"PrimOp.Eq"
@.d131 = private unnamed_addr constant [9 x i8] c"PrimOp.Ne"
@.d132 = private unnamed_addr constant [9 x i8] c"PrimOp.Lt"
@.d133 = private unnamed_addr constant [9 x i8] c"PrimOp.Le"
@.d134 = private unnamed_addr constant [9 x i8] c"PrimOp.Gt"
@.d135 = private unnamed_addr constant [9 x i8] c"PrimOp.Ge"
@.d136 = private unnamed_addr constant [11 x i8] c"PrimOp.Same"
@.d137 = private unnamed_addr constant [14 x i8] c"PrimOp.Convert"
@.d138 = private unnamed_addr constant [14 x i8] c"PrimOp.Bitcast"
@.d139 = private unnamed_addr constant [10 x i8] c"PrimOp.Len"
@.d140 = private unnamed_addr constant [13 x i8] c"PrimOp.IsCase"
@.d141 = private unnamed_addr constant [14 x i8] c"PrimOp.InRange"
@.d142 = private unnamed_addr constant [18 x i8] c"PrimOp.InRangeIncl"
@.d143 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicLoad"
@.d144 = private unnamed_addr constant [18 x i8] c"PrimOp.AtomicStore"
@.d145 = private unnamed_addr constant [16 x i8] c"PrimOp.AtomicAdd"
@.d146 = private unnamed_addr constant [17 x i8] c"PrimOp.AtomicSwap"
@.d147 = private unnamed_addr constant [24 x i8] c"PrimOp.AtomicCompareSwap"
@.d148 = private unnamed_addr constant [13 x i8] c"PrimOp.Retire"
@.d149 = private unnamed_addr constant [10 x i8] c"Check.None"
@.d150 = private unnamed_addr constant [11 x i8] c"Check.Abort"
@.d151 = private unnamed_addr constant [9 x i8] c"Check.Try"
@.d152 = private unnamed_addr constant [20 x i8] c"ExitKind.Unreachable"
@.d153 = private unnamed_addr constant [20 x i8] c"ExitKind.NullReached"
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eLe_Heec836b2f97bed3c10ee7e3cac736d9d(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eP_Hc92177ba48b21a9f8d26c1a49cf2119c(ptr %v0, ptr %a0, %"compiler/typed:BlockInfo" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eL_H5b8a0bc03aecb48440b685dbbc0b269c(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ePush_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ePu_H5cdcfe4ca3473fd9feeaed4f4a6d3f84(ptr %v0, ptr %a0, %"compiler/typed:SiteInfo" %a1)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b47e7a13871964ca_e65b2c3f8690a096 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eClosingVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_49a7b0a2550beed6_c54fa6caa81e807a = external constant [0 x i8]
@olang_loc_6690d985632b6de7_b13460b3c8232d4b = external constant [0 x i8]
@olang_loc_9fe0426b44bbec6b_25abfcb63d66fb57 = external constant [0 x i8]
@olang_loc_b480914c084fa00b_37b3876b1583fa8f = external constant [0 x i8]
@olang_loc_bffece1bd34fa117_11d44807ae5b6b33 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d42dce2e5a8639a6_22ec82fe09d5fbba = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_c13c66c7f09ff87e_38ebe5e5af81f22 = external constant [0 x i8]
@olang_loc_a4fa64762613be8a_d12da9b666f393e6 = external constant [0 x i8]
@olang_loc_a387a9465b9f2118_49b9af8105801174 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_16612f18a9afa54d_299c1e15a68a5059 = external constant [0 x i8]
@olang_loc_7b432bbe8f05f1d7_7deffd42aa472253 = external constant [0 x i8]
@olang_loc_c849604dc8cd9caf_344d20d2e301b9ab = external constant [0 x i8]
@olang_loc_411550143d3b0e9d_42067e02948bd729 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_942c69358f77327c_b8abecb88c811c88 = external constant [0 x i8]
@olang_loc_480f1658b5360f56_487a5534952ab742 = external constant [0 x i8]
@olang_loc_8f643c1a2619646b_285ffd8328f7aef7 = external constant [0 x i8]
@olang_loc_879aacf2d1a22b08_c7cef0899cf1454 = external constant [0 x i8]
@olang_loc_642fe669e8876d75_a0626c7162644c61 = external constant [0 x i8]
@olang_loc_d6ddef0f5c032242_b9ab7c7dee5da456 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
