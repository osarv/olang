; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List<compiler/typed:Scope>" }
%"std/prelude/list:List<compiler/typed:Scope>" = type { ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List<compiler/typed:LocalId>", %"std/prelude/list:List<compiler/typed:ScopeVar>", %"std/prelude/list:List<compiler/typed:Local>", %"std/prelude/list:List<compiler/typed:BlockInfo>", %"std/prelude/list:List<compiler/typed:SiteInfo>", %"std/prelude/list:List<compiler/typed:LocalId>", ptr }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/list:List<compiler/typed:LocalId>" = type { ptr }
%"std/prelude/list:List<compiler/typed:ScopeVar>" = type { ptr }
%"std/prelude/list:List<compiler/typed:Local>" = type { ptr }
%"std/prelude/list:List<compiler/typed:BlockInfo>" = type { ptr }
%"std/prelude/list:List<compiler/typed:SiteInfo>" = type { ptr }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:SiteInfo" = type { i32, %"compiler/source:Span" }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32, i1 }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
define dso_local %"compiler/typed:Plan" @compiler_2ftyped_2eNewPlan(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/typed:Plan"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Plan"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l1
  %t2 = load ptr, ptr %l1
  %t3 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 9
  store ptr %t3, ptr %l2
  %t4 = load ptr, ptr %l2
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eLe_Heec836b2f97bed3c10ee7e3cac736d9d(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0
  store ptr %t6, ptr %l4
  %t7 = load ptr, ptr %l4
  %t8 = getelementptr %"compiler/typed:Body", ptr %t7, i32 0, i32 7
  store ptr %t8, ptr %l5
  %t9 = load ptr, ptr %l5
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t9)
  store i64 %t10, ptr %l6
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0
  store ptr %t11, ptr %l7
  %t12 = load ptr, ptr %l7
  %t13 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 6
  store ptr %t13, ptr %l8
  %t14 = load ptr, ptr %l8
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %t14)
  store i64 %t15, ptr %l9
  br label %bb3
bb3:
  %t16 = load i64, ptr %l3
  %t17 = load i64, ptr %l6
  %t18 = load i64, ptr %l9
  %t19 = call %"compiler/typed:Plan" @compiler_2ftyped_3aPlan_2ector(ptr %v1, i64 %t16, i64 %t17, i64 %t18)
  store %"compiler/typed:Plan" %t19, ptr %l10
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load %"compiler/typed:Plan", ptr %l10
  store %"compiler/typed:Plan" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Plan", ptr %rv
  ret %"compiler/typed:Plan" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/typed:BlockInfo"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l4
  %t3 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 8
  store ptr %t3, ptr %l5
  %t4 = load i32, ptr %l1
  store i32 %t4, ptr %l6
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l7
  %t6 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t6, ptr %l8
  %t7 = load i32, ptr %l6
  %t8 = load i32, ptr %l7
  %t9 = load %"compiler/source:Span", ptr %l8
  %t10 = call %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %s0, i32 %t7, i32 %t8, %"compiler/source:Span" %t9)
  store %"compiler/typed:BlockInfo" %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l5
  %t12 = load %"compiler/typed:BlockInfo", ptr %l9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eP_Hc92177ba48b21a9f8d26c1a49cf2119c(ptr %v0, ptr %t11, %"compiler/typed:BlockInfo" %t12)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0
  store ptr %t13, ptr %l10
  %t14 = load ptr, ptr %l10
  %t15 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 8
  store ptr %t15, ptr %l11
  %t16 = load ptr, ptr %l11
  %t17 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eL_H5b8a0bc03aecb48440b685dbbc0b269c(ptr %v0, ptr %t16)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i64, ptr %l12
  %t19 = sub i64 %t18, 1
  store i64 %t19, ptr %l13
  %t20 = load i64, ptr %l13
  %t21 = trunc i64 %t20 to i32
  store i32 %t21, ptr %l14
  %t22 = load i32, ptr %l14
  store i32 %t22, ptr %l15
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l15
  store i32 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/typed:Local"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/typed:Local" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l2
  %t2 = load ptr, ptr %l2
  %t3 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 7
  store ptr %t3, ptr %l3
  %t4 = load %"compiler/typed:Local", ptr %l1
  store %"compiler/typed:Local" %t4, ptr %l4
  %t5 = load ptr, ptr %l3
  %t6 = load %"compiler/typed:Local", ptr %l4
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ePush_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t5, %"compiler/typed:Local" %t6)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0
  store ptr %t7, ptr %l5
  %t8 = load ptr, ptr %l5
  %t9 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  store ptr %t9, ptr %l6
  %t10 = load ptr, ptr %l6
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t10)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7
  %t13 = sub i64 %t12, 1
  store i64 %t13, ptr %l8
  %t14 = load i64, ptr %l8
  %t15 = trunc i64 %t14 to i32
  store i32 %t15, ptr %l9
  %t16 = load i32, ptr %l9
  store i32 %t16, ptr %l10
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i32, ptr %l10
  store i32 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/typed:SiteInfo"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  %t3 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 9
  store ptr %t3, ptr %l4
  %t4 = load i32, ptr %l1
  store i32 %t4, ptr %l5
  %t5 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t5, ptr %l6
  %t6 = load i32, ptr %l5
  %t7 = load %"compiler/source:Span", ptr %l6
  %t8 = call %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %s0, i32 %t6, %"compiler/source:Span" %t7)
  store %"compiler/typed:SiteInfo" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4
  %t10 = load %"compiler/typed:SiteInfo", ptr %l7
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ePu_H5cdcfe4ca3473fd9feeaed4f4a6d3f84(ptr %v0, ptr %t9, %"compiler/typed:SiteInfo" %t10)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0
  store ptr %t11, ptr %l8
  %t12 = load ptr, ptr %l8
  %t13 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 9
  store ptr %t13, ptr %l9
  %t14 = load ptr, ptr %l9
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eLe_Heec836b2f97bed3c10ee7e3cac736d9d(ptr %v0, ptr %t14)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l10
  %t17 = sub i64 %t16, 1
  store i64 %t17, ptr %l11
  %t18 = load i64, ptr %l11
  %t19 = trunc i64 %t18 to i32
  store i32 %t19, ptr %l12
  %t20 = load i32, ptr %l12
  store i32 %t20, ptr %l13
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i32, ptr %l13
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca %"compiler/typed:BlockInfo"
  %l17 = alloca i32
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  store i32 %t1, ptr %l4
  %t2 = load i32, ptr %l4
  store i32 %t2, ptr %l3
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load i32, ptr %l3
  store i32 %t3, ptr %l5
  %t4 = load i32, ptr %l5
  %t5 = icmp sge i32 %t4, 0
  store i1 %t5, ptr %l6
  %t6 = load i1, ptr %l6
  %t7 = xor i1 %t6, true
  store i1 %t7, ptr %l7
  %t8 = load i1, ptr %l7
  br i1 %t8, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t9 = load i32, ptr %l3
  store i32 %t9, ptr %l8
  %t10 = load i32, ptr %l1
  store i32 %t10, ptr %l9
  %t11 = load i32, ptr %l8
  %t12 = load i32, ptr %l9
  %t13 = icmp eq i32 %t11, %t12
  store i1 %t13, ptr %l10
  %t14 = load i1, ptr %l10
  br i1 %t14, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 true, ptr %l11
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i1, ptr %l11
  store i1 %t15, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l12
  %t17 = load ptr, ptr %l12
  %t18 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 8
  store ptr %t18, ptr %l13
  %t19 = load i32, ptr %l3
  store i32 %t19, ptr %l14
  %t20 = load i32, ptr %l14
  %t21 = sext i32 %t20 to i64
  store i64 %t21, ptr %l15
  %t22 = load ptr, ptr %l13
  %t23 = load i64, ptr %l15
  %t24 = call %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %t22, i64 %t23)
  store %"compiler/typed:BlockInfo" %t24, ptr %l16
  br label %bb8
bb8:
  %t25 = getelementptr %"compiler/typed:BlockInfo", ptr %l16, i32 0, i32 0
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l17
  %t27 = load i32, ptr %l17
  store i32 %t27, ptr %l3
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb1
bb10:
  store i1 false, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l18
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Local"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Local"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l2
  %t2 = load ptr, ptr %l2
  %t3 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 7
  store ptr %t3, ptr %l3
  %t4 = load i32, ptr %l1
  store i32 %t4, ptr %l4
  %t5 = load i32, ptr %l4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5
  %t7 = load ptr, ptr %l3
  %t8 = load i64, ptr %l5
  %t9 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t7, i64 %t8)
  store %"compiler/typed:Local" %t9, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load %"compiler/typed:Local", ptr %l6
  store %"compiler/typed:Local" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Local", ptr %rv
  ret %"compiler/typed:Local" %rr
}

define dso_local { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eParamMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca { i64, [2 x i64] }
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t23 = alloca { i64, [2 x i64] }, align 8
  %t54 = alloca { i64, [2 x i64] }, align 8
  %t58 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l0
  store ptr %t2, ptr %l5
  %t3 = load ptr, ptr %l5
  %t4 = getelementptr %"compiler/typed:Body", ptr %t3, i32 0, i32 2
  %t5 = load i32, ptr %t4
  store i32 %t5, ptr %l6
  %t6 = load i64, ptr %l2
  store i64 %t6, ptr %l7
  %t7 = load ptr, ptr %l4
  %t8 = load i32, ptr %l6
  %t9 = load i64, ptr %l7
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v1, ptr %t7, i32 %t8, i64 %t9)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8
  store i64 %t11, ptr %l3
  %t12 = load i64, ptr %l3
  store i64 %t12, ptr %l9
  %t13 = load i64, ptr %l9
  %t14 = icmp sge i64 %t13, 0
  store i1 %t14, ptr %l10
  %t15 = load i1, ptr %l10
  br i1 %t15, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l11
  %t17 = load ptr, ptr %l11
  %t18 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 5
  store ptr %t18, ptr %l12
  %t19 = load i64, ptr %l3
  store i64 %t19, ptr %l13
  %t20 = load ptr, ptr %l12
  %t21 = load i64, ptr %l13
  %t22 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t22, ptr %l14
  br label %bb4
bb3:
  br label %bb5
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 0
  store i64 2, ptr %t24
  %t25 = load i32, ptr %l14
  %t26 = insertvalue { i32 } undef, i32 %t25, 0
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 1
  store { i32 } %t26, ptr %t27
  %t28 = load { i64, [2 x i64] }, ptr %t23
  store { i64, [2 x i64] } %t28, ptr %l15
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, [2 x i64] }, ptr %l15
  store { i64, [2 x i64] } %t29, ptr %rv
  br label %ret
bb5:
  %t30 = load ptr, ptr %l1
  store ptr %t30, ptr %l16
  %t31 = load ptr, ptr %l1
  store ptr %t31, ptr %l17
  %t32 = load ptr, ptr %l1
  store ptr %t32, ptr %l18
  %t33 = load ptr, ptr %l0
  store ptr %t33, ptr %l19
  %t34 = load ptr, ptr %l19
  %t35 = getelementptr %"compiler/typed:Body", ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l20
  %t37 = load ptr, ptr %l18
  %t38 = load i32, ptr %l20
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l17
  %t41 = load i32, ptr %l21
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22
  store { i64, ptr } %t43, ptr %l23
  %t44 = load i64, ptr %l2
  store i64 %t44, ptr %l24
  %t45 = load i64, ptr %l24
  %t46 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  %t48 = getelementptr i32, ptr %t47, i64 %t45
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l25
  %t50 = load ptr, ptr %l16
  %t51 = load i32, ptr %l25
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v1, ptr %t50, i32 %t51)
  store i1 %t52, ptr %l26
  br label %bb8
bb8:
  %t53 = load i1, ptr %l26
  br i1 %t53, label %bb9, label %bb10
bb9:
  store { i64, [2 x i64] } zeroinitializer, ptr %t54
  %t55 = getelementptr { i64, [2 x i64] }, ptr %t54, i32 0, i32 0
  store i64 1, ptr %t55
  %t56 = load { i64, [2 x i64] }, ptr %t54
  store { i64, [2 x i64] } %t56, ptr %l28
  %t57 = load { i64, [2 x i64] }, ptr %l28
  store { i64, [2 x i64] } %t57, ptr %l27
  br label %bb11
bb10:
  store { i64, [2 x i64] } zeroinitializer, ptr %t58
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 0
  store i64 0, ptr %t59
  %t60 = load { i64, [2 x i64] }, ptr %t58
  store { i64, [2 x i64] } %t60, ptr %l29
  %t61 = load { i64, [2 x i64] }, ptr %l29
  store { i64, [2 x i64] } %t61, ptr %l27
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, [2 x i64] }, ptr %l27
  store { i64, [2 x i64] } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eResultMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, [2 x i64] }
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca { i64, [2 x i64] }
  %l20 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t18 = alloca { i64, [2 x i64] }, align 8
  %t33 = alloca { i64, [2 x i64] }, align 8
  %t40 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l0
  store ptr %t2, ptr %l5
  %t3 = load ptr, ptr %l5
  %t4 = getelementptr %"compiler/typed:Body", ptr %t3, i32 0, i32 2
  %t5 = load i32, ptr %t4
  store i32 %t5, ptr %l6
  %t6 = load i64, ptr %l2
  store i64 %t6, ptr %l7
  %t7 = load ptr, ptr %l4
  %t8 = load i32, ptr %l6
  %t9 = load i64, ptr %l7
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v1, ptr %t7, i32 %t8, i64 %t9)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8
  store i64 %t11, ptr %l3
  %t12 = load i64, ptr %l3
  store i64 %t12, ptr %l9
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar
  store i64 %t13, ptr %l10
  %t14 = load i64, ptr %l9
  %t15 = load i64, ptr %l10
  %t16 = icmp eq i64 %t14, %t15
  store i1 %t16, ptr %l11
  %t17 = load i1, ptr %l11
  br i1 %t17, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, [2 x i64] } zeroinitializer, ptr %t18
  %t19 = getelementptr { i64, [2 x i64] }, ptr %t18, i32 0, i32 0
  store i64 6, ptr %t19
  %t20 = load { i64, [2 x i64] }, ptr %t18
  store { i64, [2 x i64] } %t20, ptr %l12
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, [2 x i64] }, ptr %l12
  store { i64, [2 x i64] } %t21, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load i64, ptr %l3
  store i64 %t22, ptr %l13
  %t23 = load i64, ptr %l13
  %t24 = icmp sge i64 %t23, 0
  store i1 %t24, ptr %l14
  %t25 = load i1, ptr %l14
  br i1 %t25, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0
  store ptr %t26, ptr %l15
  %t27 = load ptr, ptr %l15
  %t28 = getelementptr %"compiler/typed:Body", ptr %t27, i32 0, i32 5
  store ptr %t28, ptr %l16
  %t29 = load i64, ptr %l3
  store i64 %t29, ptr %l17
  %t30 = load ptr, ptr %l16
  %t31 = load i64, ptr %l17
  %t32 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t30, i64 %t31)
  store i32 %t32, ptr %l18
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, [2 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 0
  store i64 2, ptr %t34
  %t35 = load i32, ptr %l18
  %t36 = insertvalue { i32 } undef, i32 %t35, 0
  %t37 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [2 x i64] }, ptr %t33
  store { i64, [2 x i64] } %t38, ptr %l19
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load { i64, [2 x i64] }, ptr %l19
  store { i64, [2 x i64] } %t39, ptr %rv
  br label %ret
bb8:
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 1, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t40
  store { i64, [2 x i64] } %t42, ptr %l20
  call void @__olang_scope_close(ptr %s0)
  %t43 = load { i64, [2 x i64] }, ptr %l20
  store { i64, [2 x i64] } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, [1 x i64] }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca i1
  %l30 = alloca { i64, [2 x i64] }
  %l31 = alloca i1
  %l32 = alloca { i64, [2 x i64] }
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca { i64, [1 x i64] }
  %l38 = alloca { i64, [1 x i64] }
  %l39 = alloca { i64, [1 x i64] }
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca i32
  %l46 = alloca { i64, [1 x i64] }
  %l47 = alloca i64
  %l48 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t74 = alloca { i64, [1 x i64] }, align 8
  %t78 = alloca { i64, [1 x i64] }, align 8
  %t84 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t1, ptr %l8
  %t2 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t2, ptr %l2
  store i64 0, ptr %l3
  %t3 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t3, ptr %l9
  %t4 = load { i64, ptr }, ptr %l9
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l10
  %t6 = load i64, ptr %l10
  store i64 %t6, ptr %l4
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3
  store i64 %t7, ptr %l11
  %t8 = load i64, ptr %l4
  store i64 %t8, ptr %l12
  %t9 = load i64, ptr %l11
  %t10 = load i64, ptr %l12
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l13
  %t12 = load i1, ptr %l13
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l14
  %t14 = load i1, ptr %l14
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t15, ptr %l15
  %t16 = load i64, ptr %l3
  store i64 %t16, ptr %l16
  %t17 = load i64, ptr %l16
  %t18 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  %t20 = getelementptr i64, ptr %t19, i64 %t17
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l17
  %t22 = load i64, ptr %l17
  store i64 %t22, ptr %l5
  %t23 = load i64, ptr %l5
  store i64 %t23, ptr %l18
  %t24 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar
  store i64 %t24, ptr %l19
  %t25 = load i64, ptr %l18
  %t26 = load i64, ptr %l19
  %t27 = icmp eq i64 %t25, %t26
  store i1 %t27, ptr %l20
  %t28 = load i1, ptr %l20
  br i1 %t28, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0
  store ptr %t29, ptr %l21
  %t30 = load ptr, ptr %l21
  %t31 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 6
  store ptr %t31, ptr %l22
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 3, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  store { i64, [1 x i64] } %t34, ptr %l23
  %t35 = load ptr, ptr %l22
  %t36 = load { i64, [1 x i64] }, ptr %l23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t35, { i64, [1 x i64] } %t36)
  br label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t37 = load i64, ptr %l5
  store i64 %t37, ptr %l24
  %t38 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar
  store i64 %t38, ptr %l25
  %t39 = load i64, ptr %l24
  %t40 = load i64, ptr %l25
  %t41 = icmp eq i64 %t39, %t40
  store i1 %t41, ptr %l26
  %t42 = load i1, ptr %l26
  br i1 %t42, label %bb8, label %bb9
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb8:
  store %olang.scope zeroinitializer, ptr %s5
  %t43 = load ptr, ptr %l0
  store ptr %t43, ptr %l27
  %t44 = load ptr, ptr %l27
  %t45 = getelementptr %"compiler/typed:Body", ptr %t44, i32 0, i32 1
  %t46 = load { i64, [2 x i64] }, ptr %t45
  store { i64, [2 x i64] } %t46, ptr %l28
  %t47 = load { i64, [2 x i64] }, ptr %l28
  store { i64, [2 x i64] } %t47, ptr %l6
  %t48 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t48, ptr %l30
  %t49 = load { i64, [2 x i64] }, ptr %l30
  %t50 = extractvalue { i64, [2 x i64] } %t49, 0
  %t51 = icmp eq i64 %t50, 1
  store i1 %t51, ptr %l31
  %t52 = load i1, ptr %l31
  br i1 %t52, label %bb10, label %bb11
bb9:
  store %olang.scope zeroinitializer, ptr %s8
  %t53 = load ptr, ptr %l0
  store ptr %t53, ptr %l40
  %t54 = load ptr, ptr %l40
  %t55 = getelementptr %"compiler/typed:Body", ptr %t54, i32 0, i32 6
  store ptr %t55, ptr %l41
  %t56 = load ptr, ptr %l0
  store ptr %t56, ptr %l42
  %t57 = load ptr, ptr %l42
  %t58 = getelementptr %"compiler/typed:Body", ptr %t57, i32 0, i32 5
  store ptr %t58, ptr %l43
  %t59 = load i64, ptr %l5
  store i64 %t59, ptr %l44
  %t60 = load ptr, ptr %l43
  %t61 = load i64, ptr %l44
  %t62 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t60, i64 %t61)
  store i32 %t62, ptr %l45
  br label %bb25
bb10:
  br label %bb14
bb11:
  %t63 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t63, ptr %l32
  %t64 = load { i64, [2 x i64] }, ptr %l32
  %t65 = extractvalue { i64, [2 x i64] } %t64, 0
  %t66 = icmp eq i64 %t65, 2
  store i1 %t66, ptr %l33
  %t67 = load i1, ptr %l33
  br i1 %t67, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  store i1 true, ptr %l29
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s7
  store i1 false, ptr %l29
  call void @__olang_scope_close(ptr %s7)
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb20:
  %t68 = load i1, ptr %l29
  store i1 %t68, ptr %l7
  %t69 = load ptr, ptr %l0
  store ptr %t69, ptr %l34
  %t70 = load ptr, ptr %l34
  %t71 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 6
  store ptr %t71, ptr %l35
  %t72 = load i1, ptr %l7
  store i1 %t72, ptr %l36
  %t73 = load i1, ptr %l36
  br i1 %t73, label %bb21, label %bb22
bb21:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 2, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  store { i64, [1 x i64] } %t76, ptr %l38
  %t77 = load { i64, [1 x i64] }, ptr %l38
  store { i64, [1 x i64] } %t77, ptr %l37
  br label %bb23
bb22:
  store { i64, [1 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [1 x i64] }, ptr %t78, i32 0, i32 0
  store i64 1, ptr %t79
  %t80 = load { i64, [1 x i64] }, ptr %t78
  store { i64, [1 x i64] } %t80, ptr %l39
  %t81 = load { i64, [1 x i64] }, ptr %l39
  store { i64, [1 x i64] } %t81, ptr %l37
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l35
  %t83 = load { i64, [1 x i64] }, ptr %l37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t82, { i64, [1 x i64] } %t83)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb25:
  store { i64, [1 x i64] } zeroinitializer, ptr %t84
  %t85 = getelementptr { i64, [1 x i64] }, ptr %t84, i32 0, i32 0
  store i64 0, ptr %t85
  %t86 = load i32, ptr %l45
  %t87 = insertvalue { i32 } undef, i32 %t86, 0
  %t88 = getelementptr { i64, [1 x i64] }, ptr %t84, i32 0, i32 1
  store { i32 } %t87, ptr %t88
  %t89 = load { i64, [1 x i64] }, ptr %t84
  store { i64, [1 x i64] } %t89, ptr %l46
  %t90 = load ptr, ptr %l41
  %t91 = load { i64, [1 x i64] }, ptr %l46
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %t90, { i64, [1 x i64] } %t91)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s8)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s9
  %t92 = load i64, ptr %l3
  store i64 %t92, ptr %l47
  %t93 = load i64, ptr %l47
  %t94 = add i64 %t93, 1
  store i64 %t94, ptr %l48
  %t95 = load i64, ptr %l48
  store i64 %t95, ptr %l3
  call void @__olang_scope_close(ptr %s9)
  br label %bb1
bb30:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca ptr
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l69 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca ptr
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca ptr
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca ptr
  %l89 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca ptr
  %l95 = alloca i1
  %l96 = alloca i1
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l100 = alloca ptr
  %l101 = alloca i1
  %l102 = alloca i1
  %l103 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l106 = alloca ptr
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l7
  store i1 false, ptr %l8
  %t2 = load ptr, ptr %l7
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l9
  %t4 = load i1, ptr %l9
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l10
  %t7 = load i64, ptr %l10
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0
  store ptr %t10, ptr %l11
  %t11 = load ptr, ptr %l11
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l12
  %t15 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t15, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l13
  store i1 false, ptr %l14
  %t17 = load ptr, ptr %l13
  %t18 = icmp ne ptr %t17, null
  store i1 %t18, ptr %l15
  %t19 = load i1, ptr %l15
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l16
  %t22 = load i64, ptr %l16
  %t23 = icmp eq i64 %t22, 1
  store i1 %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0
  store ptr %t25, ptr %l17
  %t26 = load ptr, ptr %l17
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l18
  %t30 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t30, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0
  store ptr %t31, ptr %l19
  store i1 false, ptr %l20
  %t32 = load ptr, ptr %l19
  %t33 = icmp ne ptr %t32, null
  store i1 %t33, ptr %l21
  %t34 = load i1, ptr %l21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l22
  %t37 = load i64, ptr %l22
  %t38 = icmp eq i64 %t37, 2
  store i1 %t38, ptr %l20
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0
  store ptr %t40, ptr %l23
  %t41 = load ptr, ptr %l23
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l24
  %t45 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t45, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0
  store ptr %t46, ptr %l25
  store i1 false, ptr %l26
  %t47 = load ptr, ptr %l25
  %t48 = icmp ne ptr %t47, null
  store i1 %t48, ptr %l27
  %t49 = load i1, ptr %l27
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l28
  %t52 = load i64, ptr %l28
  %t53 = icmp eq i64 %t52, 3
  store i1 %t53, ptr %l26
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l29
  %t56 = load ptr, ptr %l29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l30
  %t60 = load %"compiler/source:Span", ptr %l30
  store %"compiler/source:Span" %t60, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l31
  %t62 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t62, ptr %l6
  call void @__olang_scope_close(ptr %s1)
  br label %bb83
bb18:
  %t63 = load ptr, ptr %l0
  store ptr %t63, ptr %l32
  store i1 false, ptr %l33
  %t64 = load ptr, ptr %l32
  %t65 = icmp ne ptr %t64, null
  store i1 %t65, ptr %l34
  %t66 = load i1, ptr %l34
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32
  %t68 = load i64, ptr %t67
  store i64 %t68, ptr %l35
  %t69 = load i64, ptr %l35
  %t70 = icmp eq i64 %t69, 4
  store i1 %t70, ptr %l33
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0
  store ptr %t72, ptr %l36
  %t73 = load ptr, ptr %l36
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l37
  %t77 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t77, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0
  store ptr %t78, ptr %l38
  store i1 false, ptr %l39
  %t79 = load ptr, ptr %l38
  %t80 = icmp ne ptr %t79, null
  store i1 %t80, ptr %l40
  %t81 = load i1, ptr %l40
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l41
  %t84 = load i64, ptr %l41
  %t85 = icmp eq i64 %t84, 5
  store i1 %t85, ptr %l39
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0
  store ptr %t87, ptr %l42
  %t88 = load ptr, ptr %l42
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l43
  %t92 = load %"compiler/source:Span", ptr %l43
  store %"compiler/source:Span" %t92, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0
  store ptr %t93, ptr %l44
  store i1 false, ptr %l45
  %t94 = load ptr, ptr %l44
  %t95 = icmp ne ptr %t94, null
  store i1 %t95, ptr %l46
  %t96 = load i1, ptr %l46
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44
  %t98 = load i64, ptr %t97
  store i64 %t98, ptr %l47
  %t99 = load i64, ptr %l47
  %t100 = icmp eq i64 %t99, 6
  store i1 %t100, ptr %l45
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0
  store ptr %t102, ptr %l48
  %t103 = load ptr, ptr %l48
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l49
  %t107 = load %"compiler/source:Span", ptr %l49
  store %"compiler/source:Span" %t107, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0
  store ptr %t108, ptr %l50
  store i1 false, ptr %l51
  %t109 = load ptr, ptr %l50
  %t110 = icmp ne ptr %t109, null
  store i1 %t110, ptr %l52
  %t111 = load i1, ptr %l52
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50
  %t113 = load i64, ptr %t112
  store i64 %t113, ptr %l53
  %t114 = load i64, ptr %l53
  %t115 = icmp eq i64 %t114, 7
  store i1 %t115, ptr %l51
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0
  store ptr %t117, ptr %l54
  %t118 = load ptr, ptr %l54
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l55
  %t122 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t122, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s2
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l56
  %t124 = load %"compiler/source:Span", ptr %l56
  store %"compiler/source:Span" %t124, ptr %l6
  call void @__olang_scope_close(ptr %s2)
  br label %bb83
bb36:
  %t125 = load ptr, ptr %l0
  store ptr %t125, ptr %l57
  store i1 false, ptr %l58
  %t126 = load ptr, ptr %l57
  %t127 = icmp ne ptr %t126, null
  store i1 %t127, ptr %l59
  %t128 = load i1, ptr %l59
  br i1 %t128, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57
  %t130 = load i64, ptr %t129
  store i64 %t130, ptr %l60
  %t131 = load i64, ptr %l60
  %t132 = icmp eq i64 %t131, 8
  store i1 %t132, ptr %l58
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0
  store ptr %t134, ptr %l61
  %t135 = load ptr, ptr %l61
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l62
  %t139 = load %"compiler/source:Span", ptr %l62
  store %"compiler/source:Span" %t139, ptr %l3
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0
  store ptr %t140, ptr %l63
  store i1 false, ptr %l64
  %t141 = load ptr, ptr %l63
  %t142 = icmp ne ptr %t141, null
  store i1 %t142, ptr %l65
  %t143 = load i1, ptr %l65
  br i1 %t143, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63
  %t145 = load i64, ptr %t144
  store i64 %t145, ptr %l66
  %t146 = load i64, ptr %l66
  %t147 = icmp eq i64 %t146, 9
  store i1 %t147, ptr %l64
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0
  store ptr %t149, ptr %l67
  %t150 = load ptr, ptr %l67
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t150, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l68
  %t154 = load %"compiler/source:Span", ptr %l68
  store %"compiler/source:Span" %t154, ptr %l3
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0
  store ptr %t155, ptr %l69
  store i1 false, ptr %l70
  %t156 = load ptr, ptr %l69
  %t157 = icmp ne ptr %t156, null
  store i1 %t157, ptr %l71
  %t158 = load i1, ptr %l71
  br i1 %t158, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69
  %t160 = load i64, ptr %t159
  store i64 %t160, ptr %l72
  %t161 = load i64, ptr %l72
  %t162 = icmp eq i64 %t161, 10
  store i1 %t162, ptr %l70
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0
  store ptr %t164, ptr %l73
  %t165 = load ptr, ptr %l73
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l74
  %t169 = load %"compiler/source:Span", ptr %l74
  store %"compiler/source:Span" %t169, ptr %l3
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0
  store ptr %t170, ptr %l75
  store i1 false, ptr %l76
  %t171 = load ptr, ptr %l75
  %t172 = icmp ne ptr %t171, null
  store i1 %t172, ptr %l77
  %t173 = load i1, ptr %l77
  br i1 %t173, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75
  %t175 = load i64, ptr %t174
  store i64 %t175, ptr %l78
  %t176 = load i64, ptr %l78
  %t177 = icmp eq i64 %t176, 11
  store i1 %t177, ptr %l76
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0
  store ptr %t179, ptr %l79
  %t180 = load ptr, ptr %l79
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l80
  %t184 = load %"compiler/source:Span", ptr %l80
  store %"compiler/source:Span" %t184, ptr %l3
  br label %bb53
bb52:
  br label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s3
  %t185 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t185, ptr %l81
  %t186 = load %"compiler/source:Span", ptr %l81
  store %"compiler/source:Span" %t186, ptr %l6
  call void @__olang_scope_close(ptr %s3)
  br label %bb83
bb54:
  %t187 = load ptr, ptr %l0
  store ptr %t187, ptr %l82
  store i1 false, ptr %l83
  %t188 = load ptr, ptr %l82
  %t189 = icmp ne ptr %t188, null
  store i1 %t189, ptr %l84
  %t190 = load i1, ptr %l84
  br i1 %t190, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82
  %t192 = load i64, ptr %t191
  store i64 %t192, ptr %l85
  %t193 = load i64, ptr %l85
  %t194 = icmp eq i64 %t193, 12
  store i1 %t194, ptr %l83
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0
  store ptr %t196, ptr %l86
  %t197 = load ptr, ptr %l86
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l87
  %t201 = load %"compiler/source:Span", ptr %l87
  store %"compiler/source:Span" %t201, ptr %l4
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0
  store ptr %t202, ptr %l88
  store i1 false, ptr %l89
  %t203 = load ptr, ptr %l88
  %t204 = icmp ne ptr %t203, null
  store i1 %t204, ptr %l90
  %t205 = load i1, ptr %l90
  br i1 %t205, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88
  %t207 = load i64, ptr %t206
  store i64 %t207, ptr %l91
  %t208 = load i64, ptr %l91
  %t209 = icmp eq i64 %t208, 13
  store i1 %t209, ptr %l89
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0
  store ptr %t211, ptr %l92
  %t212 = load ptr, ptr %l92
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l93
  %t216 = load %"compiler/source:Span", ptr %l93
  store %"compiler/source:Span" %t216, ptr %l4
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0
  store ptr %t217, ptr %l94
  store i1 false, ptr %l95
  %t218 = load ptr, ptr %l94
  %t219 = icmp ne ptr %t218, null
  store i1 %t219, ptr %l96
  %t220 = load i1, ptr %l96
  br i1 %t220, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94
  %t222 = load i64, ptr %t221
  store i64 %t222, ptr %l97
  %t223 = load i64, ptr %l97
  %t224 = icmp eq i64 %t223, 14
  store i1 %t224, ptr %l95
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0
  store ptr %t226, ptr %l98
  %t227 = load ptr, ptr %l98
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t227, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l99
  %t231 = load %"compiler/source:Span", ptr %l99
  store %"compiler/source:Span" %t231, ptr %l4
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0
  store ptr %t232, ptr %l100
  store i1 false, ptr %l101
  %t233 = load ptr, ptr %l100
  %t234 = icmp ne ptr %t233, null
  store i1 %t234, ptr %l102
  %t235 = load i1, ptr %l102
  br i1 %t235, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100
  %t237 = load i64, ptr %t236
  store i64 %t237, ptr %l103
  %t238 = load i64, ptr %l103
  %t239 = icmp eq i64 %t238, 15
  store i1 %t239, ptr %l101
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0
  store ptr %t241, ptr %l104
  %t242 = load ptr, ptr %l104
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t242, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l105
  %t246 = load %"compiler/source:Span", ptr %l105
  store %"compiler/source:Span" %t246, ptr %l4
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0
  store ptr %t247, ptr %l106
  store i1 false, ptr %l107
  %t248 = load ptr, ptr %l106
  %t249 = icmp ne ptr %t248, null
  store i1 %t249, ptr %l108
  %t250 = load i1, ptr %l108
  br i1 %t250, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106
  %t252 = load i64, ptr %t251
  store i64 %t252, ptr %l109
  %t253 = load i64, ptr %l109
  %t254 = icmp eq i64 %t253, 16
  store i1 %t254, ptr %l107
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0
  store ptr %t256, ptr %l110
  %t257 = load ptr, ptr %l110
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t257, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l111
  %t261 = load %"compiler/source:Span", ptr %l111
  store %"compiler/source:Span" %t261, ptr %l4
  br label %bb75
bb74:
  br label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s4
  %t262 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t262, ptr %l112
  %t263 = load %"compiler/source:Span", ptr %l112
  store %"compiler/source:Span" %t263, ptr %l6
  call void @__olang_scope_close(ptr %s4)
  br label %bb83
bb76:
  %t264 = load ptr, ptr %l0
  store ptr %t264, ptr %l113
  store i1 false, ptr %l114
  %t265 = load ptr, ptr %l113
  %t266 = icmp ne ptr %t265, null
  store i1 %t266, ptr %l115
  %t267 = load i1, ptr %l115
  br i1 %t267, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113
  %t269 = load i64, ptr %t268
  store i64 %t269, ptr %l116
  %t270 = load i64, ptr %l116
  %t271 = icmp eq i64 %t270, 17
  store i1 %t271, ptr %l114
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0
  store ptr %t273, ptr %l117
  %t274 = load ptr, ptr %l117
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t274, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 0
  %t277 = load %"compiler/source:Span", ptr %t276
  store %"compiler/source:Span" %t277, ptr %l118
  %t278 = load %"compiler/source:Span", ptr %l118
  store %"compiler/source:Span" %t278, ptr %l5
  br label %bb81
bb80:
  br label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s5
  %t279 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t279, ptr %l119
  %t280 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t280, ptr %l6
  call void @__olang_scope_close(ptr %s5)
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb83:
  call void @__olang_scope_close(ptr %s0)
  %t281 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t281, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca ptr
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca i32
  %l82 = alloca ptr
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca ptr
  %l89 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca i32
  %l94 = alloca ptr
  %l95 = alloca i1
  %l96 = alloca i1
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca ptr
  %l101 = alloca i1
  %l102 = alloca i1
  %l103 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca ptr
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca i32
  %l112 = alloca i32
  %l113 = alloca ptr
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca ptr
  %l120 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l7
  store i1 false, ptr %l8
  %t2 = load ptr, ptr %l7
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l9
  %t4 = load i1, ptr %l9
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l10
  %t7 = load i64, ptr %l10
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0
  store ptr %t10, ptr %l11
  %t11 = load ptr, ptr %l11
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l12
  %t15 = load i32, ptr %l12
  store i32 %t15, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l13
  store i1 false, ptr %l14
  %t17 = load ptr, ptr %l13
  %t18 = icmp ne ptr %t17, null
  store i1 %t18, ptr %l15
  %t19 = load i1, ptr %l15
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l16
  %t22 = load i64, ptr %l16
  %t23 = icmp eq i64 %t22, 1
  store i1 %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0
  store ptr %t25, ptr %l17
  %t26 = load ptr, ptr %l17
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l18
  %t30 = load i32, ptr %l18
  store i32 %t30, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0
  store ptr %t31, ptr %l19
  store i1 false, ptr %l20
  %t32 = load ptr, ptr %l19
  %t33 = icmp ne ptr %t32, null
  store i1 %t33, ptr %l21
  %t34 = load i1, ptr %l21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l22
  %t37 = load i64, ptr %l22
  %t38 = icmp eq i64 %t37, 2
  store i1 %t38, ptr %l20
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0
  store ptr %t40, ptr %l23
  %t41 = load ptr, ptr %l23
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l24
  %t45 = load i32, ptr %l24
  store i32 %t45, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0
  store ptr %t46, ptr %l25
  store i1 false, ptr %l26
  %t47 = load ptr, ptr %l25
  %t48 = icmp ne ptr %t47, null
  store i1 %t48, ptr %l27
  %t49 = load i1, ptr %l27
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l28
  %t52 = load i64, ptr %l28
  %t53 = icmp eq i64 %t52, 3
  store i1 %t53, ptr %l26
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l29
  %t56 = load ptr, ptr %l29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l30
  %t60 = load i32, ptr %l30
  store i32 %t60, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  %t61 = load i32, ptr %l1
  store i32 %t61, ptr %l31
  %t62 = load i32, ptr %l31
  store i32 %t62, ptr %l6
  call void @__olang_scope_close(ptr %s1)
  br label %bb84
bb18:
  %t63 = load ptr, ptr %l0
  store ptr %t63, ptr %l32
  store i1 false, ptr %l33
  %t64 = load ptr, ptr %l32
  %t65 = icmp ne ptr %t64, null
  store i1 %t65, ptr %l34
  %t66 = load i1, ptr %l34
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32
  %t68 = load i64, ptr %t67
  store i64 %t68, ptr %l35
  %t69 = load i64, ptr %l35
  %t70 = icmp eq i64 %t69, 4
  store i1 %t70, ptr %l33
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0
  store ptr %t72, ptr %l36
  %t73 = load ptr, ptr %l36
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l37
  %t77 = load i32, ptr %l37
  store i32 %t77, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0
  store ptr %t78, ptr %l38
  store i1 false, ptr %l39
  %t79 = load ptr, ptr %l38
  %t80 = icmp ne ptr %t79, null
  store i1 %t80, ptr %l40
  %t81 = load i1, ptr %l40
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l41
  %t84 = load i64, ptr %l41
  %t85 = icmp eq i64 %t84, 5
  store i1 %t85, ptr %l39
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0
  store ptr %t87, ptr %l42
  %t88 = load ptr, ptr %l42
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l43
  %t92 = load i32, ptr %l43
  store i32 %t92, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0
  store ptr %t93, ptr %l44
  store i1 false, ptr %l45
  %t94 = load ptr, ptr %l44
  %t95 = icmp ne ptr %t94, null
  store i1 %t95, ptr %l46
  %t96 = load i1, ptr %l46
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44
  %t98 = load i64, ptr %t97
  store i64 %t98, ptr %l47
  %t99 = load i64, ptr %l47
  %t100 = icmp eq i64 %t99, 6
  store i1 %t100, ptr %l45
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0
  store ptr %t102, ptr %l48
  %t103 = load ptr, ptr %l48
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l49
  %t107 = load i32, ptr %l49
  store i32 %t107, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0
  store ptr %t108, ptr %l50
  store i1 false, ptr %l51
  %t109 = load ptr, ptr %l50
  %t110 = icmp ne ptr %t109, null
  store i1 %t110, ptr %l52
  %t111 = load i1, ptr %l52
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50
  %t113 = load i64, ptr %t112
  store i64 %t113, ptr %l53
  %t114 = load i64, ptr %l53
  %t115 = icmp eq i64 %t114, 7
  store i1 %t115, ptr %l51
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0
  store ptr %t117, ptr %l54
  %t118 = load ptr, ptr %l54
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t118, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l55
  %t122 = load i32, ptr %l55
  store i32 %t122, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s2
  %t123 = load i32, ptr %l2
  store i32 %t123, ptr %l56
  %t124 = load i32, ptr %l56
  store i32 %t124, ptr %l6
  call void @__olang_scope_close(ptr %s2)
  br label %bb84
bb36:
  %t125 = load ptr, ptr %l0
  store ptr %t125, ptr %l57
  store i1 false, ptr %l58
  %t126 = load ptr, ptr %l57
  %t127 = icmp ne ptr %t126, null
  store i1 %t127, ptr %l59
  %t128 = load i1, ptr %l59
  br i1 %t128, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57
  %t130 = load i64, ptr %t129
  store i64 %t130, ptr %l60
  %t131 = load i64, ptr %l60
  %t132 = icmp eq i64 %t131, 8
  store i1 %t132, ptr %l58
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0
  store ptr %t134, ptr %l61
  %t135 = load ptr, ptr %l61
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 1
  %t138 = load i32, ptr %t137
  store i32 %t138, ptr %l62
  %t139 = load i32, ptr %l62
  store i32 %t139, ptr %l3
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0
  store ptr %t140, ptr %l63
  store i1 false, ptr %l64
  %t141 = load ptr, ptr %l63
  %t142 = icmp ne ptr %t141, null
  store i1 %t142, ptr %l65
  %t143 = load i1, ptr %l65
  br i1 %t143, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63
  %t145 = load i64, ptr %t144
  store i64 %t145, ptr %l66
  %t146 = load i64, ptr %l66
  %t147 = icmp eq i64 %t146, 9
  store i1 %t147, ptr %l64
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0
  store ptr %t149, ptr %l67
  %t150 = load ptr, ptr %l67
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t150, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 1
  %t153 = load i32, ptr %t152
  store i32 %t153, ptr %l68
  %t154 = load i32, ptr %l68
  store i32 %t154, ptr %l3
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0
  store ptr %t155, ptr %l69
  store i1 false, ptr %l70
  %t156 = load ptr, ptr %l69
  %t157 = icmp ne ptr %t156, null
  store i1 %t157, ptr %l71
  %t158 = load i1, ptr %l71
  br i1 %t158, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69
  %t160 = load i64, ptr %t159
  store i64 %t160, ptr %l72
  %t161 = load i64, ptr %l72
  %t162 = icmp eq i64 %t161, 10
  store i1 %t162, ptr %l70
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0
  store ptr %t164, ptr %l73
  %t165 = load ptr, ptr %l73
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 1
  %t168 = load i32, ptr %t167
  store i32 %t168, ptr %l74
  %t169 = load i32, ptr %l74
  store i32 %t169, ptr %l3
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0
  store ptr %t170, ptr %l75
  store i1 false, ptr %l76
  %t171 = load ptr, ptr %l75
  %t172 = icmp ne ptr %t171, null
  store i1 %t172, ptr %l77
  %t173 = load i1, ptr %l77
  br i1 %t173, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75
  %t175 = load i64, ptr %t174
  store i64 %t175, ptr %l78
  %t176 = load i64, ptr %l78
  %t177 = icmp eq i64 %t176, 11
  store i1 %t177, ptr %l76
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0
  store ptr %t179, ptr %l79
  %t180 = load ptr, ptr %l79
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 1
  %t183 = load i32, ptr %t182
  store i32 %t183, ptr %l80
  %t184 = load i32, ptr %l80
  store i32 %t184, ptr %l3
  br label %bb53
bb52:
  br label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s3
  %t185 = load i32, ptr %l3
  store i32 %t185, ptr %l81
  %t186 = load i32, ptr %l81
  store i32 %t186, ptr %l6
  call void @__olang_scope_close(ptr %s3)
  br label %bb84
bb54:
  %t187 = load ptr, ptr %l0
  store ptr %t187, ptr %l82
  store i1 false, ptr %l83
  %t188 = load ptr, ptr %l82
  %t189 = icmp ne ptr %t188, null
  store i1 %t189, ptr %l84
  %t190 = load i1, ptr %l84
  br i1 %t190, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82
  %t192 = load i64, ptr %t191
  store i64 %t192, ptr %l85
  %t193 = load i64, ptr %l85
  %t194 = icmp eq i64 %t193, 12
  store i1 %t194, ptr %l83
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0
  store ptr %t196, ptr %l86
  %t197 = load ptr, ptr %l86
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 1
  %t200 = load i32, ptr %t199
  store i32 %t200, ptr %l87
  %t201 = load i32, ptr %l87
  store i32 %t201, ptr %l4
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0
  store ptr %t202, ptr %l88
  store i1 false, ptr %l89
  %t203 = load ptr, ptr %l88
  %t204 = icmp ne ptr %t203, null
  store i1 %t204, ptr %l90
  %t205 = load i1, ptr %l90
  br i1 %t205, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88
  %t207 = load i64, ptr %t206
  store i64 %t207, ptr %l91
  %t208 = load i64, ptr %l91
  %t209 = icmp eq i64 %t208, 13
  store i1 %t209, ptr %l89
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0
  store ptr %t211, ptr %l92
  %t212 = load ptr, ptr %l92
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 1
  %t215 = load i32, ptr %t214
  store i32 %t215, ptr %l93
  %t216 = load i32, ptr %l93
  store i32 %t216, ptr %l4
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0
  store ptr %t217, ptr %l94
  store i1 false, ptr %l95
  %t218 = load ptr, ptr %l94
  %t219 = icmp ne ptr %t218, null
  store i1 %t219, ptr %l96
  %t220 = load i1, ptr %l96
  br i1 %t220, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94
  %t222 = load i64, ptr %t221
  store i64 %t222, ptr %l97
  %t223 = load i64, ptr %l97
  %t224 = icmp eq i64 %t223, 14
  store i1 %t224, ptr %l95
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0
  store ptr %t226, ptr %l98
  %t227 = load ptr, ptr %l98
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t227, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 1
  %t230 = load i32, ptr %t229
  store i32 %t230, ptr %l99
  %t231 = load i32, ptr %l99
  store i32 %t231, ptr %l4
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0
  store ptr %t232, ptr %l100
  store i1 false, ptr %l101
  %t233 = load ptr, ptr %l100
  %t234 = icmp ne ptr %t233, null
  store i1 %t234, ptr %l102
  %t235 = load i1, ptr %l102
  br i1 %t235, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100
  %t237 = load i64, ptr %t236
  store i64 %t237, ptr %l103
  %t238 = load i64, ptr %l103
  %t239 = icmp eq i64 %t238, 15
  store i1 %t239, ptr %l101
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0
  store ptr %t241, ptr %l104
  %t242 = load ptr, ptr %l104
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t242, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 1
  %t245 = load i32, ptr %t244
  store i32 %t245, ptr %l105
  %t246 = load i32, ptr %l105
  store i32 %t246, ptr %l4
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0
  store ptr %t247, ptr %l106
  store i1 false, ptr %l107
  %t248 = load ptr, ptr %l106
  %t249 = icmp ne ptr %t248, null
  store i1 %t249, ptr %l108
  %t250 = load i1, ptr %l108
  br i1 %t250, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106
  %t252 = load i64, ptr %t251
  store i64 %t252, ptr %l109
  %t253 = load i64, ptr %l109
  %t254 = icmp eq i64 %t253, 16
  store i1 %t254, ptr %l107
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0
  store ptr %t256, ptr %l110
  %t257 = load ptr, ptr %l110
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t257, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 1
  %t260 = load i32, ptr %t259
  store i32 %t260, ptr %l111
  %t261 = load i32, ptr %l111
  store i32 %t261, ptr %l4
  br label %bb75
bb74:
  br label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s4
  %t262 = load i32, ptr %l4
  store i32 %t262, ptr %l112
  %t263 = load i32, ptr %l112
  store i32 %t263, ptr %l6
  call void @__olang_scope_close(ptr %s4)
  br label %bb84
bb76:
  %t264 = load ptr, ptr %l0
  store ptr %t264, ptr %l113
  store i1 false, ptr %l114
  %t265 = load ptr, ptr %l113
  %t266 = icmp ne ptr %t265, null
  store i1 %t266, ptr %l115
  %t267 = load i1, ptr %l115
  br i1 %t267, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113
  %t269 = load i64, ptr %t268
  store i64 %t269, ptr %l116
  %t270 = load i64, ptr %l116
  %t271 = icmp eq i64 %t270, 17
  store i1 %t271, ptr %l114
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0
  store ptr %t273, ptr %l117
  %t274 = load ptr, ptr %l117
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t274, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 2
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l118
  %t278 = load ptr, ptr %l118
  store ptr %t278, ptr %l5
  br label %bb81
bb80:
  br label %bb83
bb81:
  store %olang.scope zeroinitializer, ptr %s5
  %t279 = load ptr, ptr %l5
  store ptr %t279, ptr %l119
  %t280 = load ptr, ptr %l119
  %t281 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t280)
  store i32 %t281, ptr %l120
  br label %bb82
bb82:
  %t282 = load i32, ptr %l120
  store i32 %t282, ptr %l6
  call void @__olang_scope_close(ptr %s5)
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb84:
  call void @__olang_scope_close(ptr %s0)
  %t283 = load i32, ptr %l6
  store i32 %t283, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  store i1 false, ptr %l5
  %t2 = load ptr, ptr %l4
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l6
  %t4 = load i1, ptr %l6
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l7
  %t7 = load i64, ptr %l7
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l5
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0
  store ptr %t10, ptr %l8
  %t11 = load ptr, ptr %l8
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l9
  %t15 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t15, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l10
  store i1 false, ptr %l11
  %t17 = load ptr, ptr %l10
  %t18 = icmp ne ptr %t17, null
  store i1 %t18, ptr %l12
  %t19 = load i1, ptr %l12
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l13
  %t22 = load i64, ptr %l13
  %t23 = icmp eq i64 %t22, 1
  store i1 %t23, ptr %l11
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0
  store ptr %t25, ptr %l14
  %t26 = load ptr, ptr %l14
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l15
  %t30 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t30, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0
  store ptr %t31, ptr %l16
  store i1 false, ptr %l17
  %t32 = load ptr, ptr %l16
  %t33 = icmp ne ptr %t32, null
  store i1 %t33, ptr %l18
  %t34 = load i1, ptr %l18
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l19
  %t37 = load i64, ptr %l19
  %t38 = icmp eq i64 %t37, 2
  store i1 %t38, ptr %l17
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0
  store ptr %t40, ptr %l20
  %t41 = load ptr, ptr %l20
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l21
  %t45 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t45, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0
  store ptr %t46, ptr %l22
  store i1 false, ptr %l23
  %t47 = load ptr, ptr %l22
  %t48 = icmp ne ptr %t47, null
  store i1 %t48, ptr %l24
  %t49 = load i1, ptr %l24
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l25
  %t52 = load i64, ptr %l25
  %t53 = icmp eq i64 %t52, 3
  store i1 %t53, ptr %l23
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l26
  %t56 = load ptr, ptr %l26
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l27
  %t60 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t60, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l28
  %t62 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t62, ptr %l3
  call void @__olang_scope_close(ptr %s1)
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0
  store ptr %t63, ptr %l29
  store i1 false, ptr %l30
  %t64 = load ptr, ptr %l29
  %t65 = icmp ne ptr %t64, null
  store i1 %t65, ptr %l31
  %t66 = load i1, ptr %l31
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29
  %t68 = load i64, ptr %t67
  store i64 %t68, ptr %l32
  %t69 = load i64, ptr %l32
  %t70 = icmp eq i64 %t69, 4
  store i1 %t70, ptr %l30
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0
  store ptr %t72, ptr %l33
  %t73 = load ptr, ptr %l33
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l34
  %t77 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t77, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0
  store ptr %t78, ptr %l35
  store i1 false, ptr %l36
  %t79 = load ptr, ptr %l35
  %t80 = icmp ne ptr %t79, null
  store i1 %t80, ptr %l37
  %t81 = load i1, ptr %l37
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l38
  %t84 = load i64, ptr %l38
  %t85 = icmp eq i64 %t84, 5
  store i1 %t85, ptr %l36
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0
  store ptr %t87, ptr %l39
  %t88 = load ptr, ptr %l39
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l40
  %t92 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t92, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0
  store ptr %t93, ptr %l41
  store i1 false, ptr %l42
  %t94 = load ptr, ptr %l41
  %t95 = icmp ne ptr %t94, null
  store i1 %t95, ptr %l43
  %t96 = load i1, ptr %l43
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41
  %t98 = load i64, ptr %t97
  store i64 %t98, ptr %l44
  %t99 = load i64, ptr %l44
  %t100 = icmp eq i64 %t99, 6
  store i1 %t100, ptr %l42
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0
  store ptr %t102, ptr %l45
  %t103 = load ptr, ptr %l45
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l46
  %t107 = load %"compiler/source:Span", ptr %l46
  store %"compiler/source:Span" %t107, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0
  store ptr %t108, ptr %l47
  store i1 false, ptr %l48
  %t109 = load ptr, ptr %l47
  %t110 = icmp ne ptr %t109, null
  store i1 %t110, ptr %l49
  %t111 = load i1, ptr %l49
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47
  %t113 = load i64, ptr %t112
  store i64 %t113, ptr %l50
  %t114 = load i64, ptr %l50
  %t115 = icmp eq i64 %t114, 7
  store i1 %t115, ptr %l48
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0
  store ptr %t117, ptr %l51
  %t118 = load ptr, ptr %l51
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l52
  %t122 = load %"compiler/source:Span", ptr %l52
  store %"compiler/source:Span" %t122, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s2
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l53
  %t124 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t124, ptr %l3
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb37:
  call void @__olang_scope_close(ptr %s0)
  %t125 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t125, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  store i1 false, ptr %l5
  %t2 = load ptr, ptr %l4
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l6
  %t4 = load i1, ptr %l6
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l7
  %t7 = load i64, ptr %l7
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l5
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0
  store ptr %t10, ptr %l8
  %t11 = load ptr, ptr %l8
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l9
  %t15 = load i32, ptr %l9
  store i32 %t15, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l10
  store i1 false, ptr %l11
  %t17 = load ptr, ptr %l10
  %t18 = icmp ne ptr %t17, null
  store i1 %t18, ptr %l12
  %t19 = load i1, ptr %l12
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l13
  %t22 = load i64, ptr %l13
  %t23 = icmp eq i64 %t22, 1
  store i1 %t23, ptr %l11
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0
  store ptr %t25, ptr %l14
  %t26 = load ptr, ptr %l14
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l15
  %t30 = load i32, ptr %l15
  store i32 %t30, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0
  store ptr %t31, ptr %l16
  store i1 false, ptr %l17
  %t32 = load ptr, ptr %l16
  %t33 = icmp ne ptr %t32, null
  store i1 %t33, ptr %l18
  %t34 = load i1, ptr %l18
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l19
  %t37 = load i64, ptr %l19
  %t38 = icmp eq i64 %t37, 2
  store i1 %t38, ptr %l17
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0
  store ptr %t40, ptr %l20
  %t41 = load ptr, ptr %l20
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l21
  %t45 = load i32, ptr %l21
  store i32 %t45, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0
  store ptr %t46, ptr %l22
  store i1 false, ptr %l23
  %t47 = load ptr, ptr %l22
  %t48 = icmp ne ptr %t47, null
  store i1 %t48, ptr %l24
  %t49 = load i1, ptr %l24
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l25
  %t52 = load i64, ptr %l25
  %t53 = icmp eq i64 %t52, 3
  store i1 %t53, ptr %l23
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l26
  %t56 = load ptr, ptr %l26
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l27
  %t60 = load i32, ptr %l27
  store i32 %t60, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s1
  %t61 = load i32, ptr %l1
  store i32 %t61, ptr %l28
  %t62 = load i32, ptr %l28
  store i32 %t62, ptr %l3
  call void @__olang_scope_close(ptr %s1)
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0
  store ptr %t63, ptr %l29
  store i1 false, ptr %l30
  %t64 = load ptr, ptr %l29
  %t65 = icmp ne ptr %t64, null
  store i1 %t65, ptr %l31
  %t66 = load i1, ptr %l31
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29
  %t68 = load i64, ptr %t67
  store i64 %t68, ptr %l32
  %t69 = load i64, ptr %l32
  %t70 = icmp eq i64 %t69, 4
  store i1 %t70, ptr %l30
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0
  store ptr %t72, ptr %l33
  %t73 = load ptr, ptr %l33
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l34
  %t77 = load i32, ptr %l34
  store i32 %t77, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0
  store ptr %t78, ptr %l35
  store i1 false, ptr %l36
  %t79 = load ptr, ptr %l35
  %t80 = icmp ne ptr %t79, null
  store i1 %t80, ptr %l37
  %t81 = load i1, ptr %l37
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l38
  %t84 = load i64, ptr %l38
  %t85 = icmp eq i64 %t84, 5
  store i1 %t85, ptr %l36
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0
  store ptr %t87, ptr %l39
  %t88 = load ptr, ptr %l39
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l40
  %t92 = load i32, ptr %l40
  store i32 %t92, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0
  store ptr %t93, ptr %l41
  store i1 false, ptr %l42
  %t94 = load ptr, ptr %l41
  %t95 = icmp ne ptr %t94, null
  store i1 %t95, ptr %l43
  %t96 = load i1, ptr %l43
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41
  %t98 = load i64, ptr %t97
  store i64 %t98, ptr %l44
  %t99 = load i64, ptr %l44
  %t100 = icmp eq i64 %t99, 6
  store i1 %t100, ptr %l42
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0
  store ptr %t102, ptr %l45
  %t103 = load ptr, ptr %l45
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l46
  %t107 = load i32, ptr %l46
  store i32 %t107, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0
  store ptr %t108, ptr %l47
  store i1 false, ptr %l48
  %t109 = load ptr, ptr %l47
  %t110 = icmp ne ptr %t109, null
  store i1 %t110, ptr %l49
  %t111 = load i1, ptr %l49
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47
  %t113 = load i64, ptr %t112
  store i64 %t113, ptr %l50
  %t114 = load i64, ptr %l50
  %t115 = icmp eq i64 %t114, 7
  store i1 %t115, ptr %l48
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0
  store ptr %t117, ptr %l51
  %t118 = load ptr, ptr %l51
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l52
  %t122 = load i32, ptr %l52
  store i32 %t122, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s2
  %t123 = load i32, ptr %l2
  store i32 %t123, ptr %l53
  %t124 = load i32, ptr %l53
  store i32 %t124, ptr %l3
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb37:
  call void @__olang_scope_close(ptr %s0)
  %t125 = load i32, ptr %l3
  store i32 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, [1 x i64] }
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca { i64, [1 x i64] }
  %l34 = alloca i64
  %l35 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l7
  %t2 = load ptr, ptr %l7
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t2, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3
  store { i64, ptr } %t4, ptr %l8
  %t5 = load i32, ptr %l1
  store i32 %t5, ptr %l9
  %t6 = load i32, ptr %l9
  %t7 = sext i32 %t6 to i64
  store i64 %t7, ptr %l10
  %t8 = load ptr, ptr %l0
  store ptr %t8, ptr %l11
  %t9 = load ptr, ptr %l11
  %t10 = getelementptr %"compiler/typed:Plan", ptr %t9, i32 0, i32 5
  store ptr %t10, ptr %l12
  %t11 = load ptr, ptr %l12
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t11)
  store i64 %t12, ptr %l13
  br label %bb1
bb1:
  %t13 = load i64, ptr %l13
  %t14 = add i64 %t13, 1
  store i64 %t14, ptr %l14
  %t15 = load i64, ptr %l14
  %t16 = load i64, ptr %l10
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  %t19 = getelementptr i64, ptr %t18, i64 %t16
  store i64 %t15, ptr %t19
  %t20 = load ptr, ptr %l0
  store ptr %t20, ptr %l15
  %t21 = load ptr, ptr %l15
  %t22 = getelementptr %"compiler/typed:Plan", ptr %t21, i32 0, i32 4
  %t23 = load { i64, ptr }, ptr %t22
  store { i64, ptr } %t23, ptr %l16
  %t24 = load i32, ptr %l1
  store i32 %t24, ptr %l17
  %t25 = load i32, ptr %l17
  %t26 = sext i32 %t25 to i64
  store i64 %t26, ptr %l18
  %t27 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t27, ptr %l19
  %t28 = load { i64, ptr }, ptr %l19
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l20
  %t30 = load i64, ptr %l20
  %t31 = load i64, ptr %l18
  %t32 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  %t34 = getelementptr i64, ptr %t33, i64 %t31
  store i64 %t30, ptr %t34
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t35, ptr %l21
  %t36 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t36, ptr %l3
  store i64 0, ptr %l4
  %t37 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t37, ptr %l22
  %t38 = load { i64, ptr }, ptr %l22
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l23
  %t40 = load i64, ptr %l23
  store i64 %t40, ptr %l5
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l4
  store i64 %t41, ptr %l24
  %t42 = load i64, ptr %l5
  store i64 %t42, ptr %l25
  %t43 = load i64, ptr %l24
  %t44 = load i64, ptr %l25
  %t45 = icmp slt i64 %t43, %t44
  store i1 %t45, ptr %l26
  %t46 = load i1, ptr %l26
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l27
  %t48 = load i1, ptr %l27
  br i1 %t48, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t49 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t49, ptr %l28
  %t50 = load i64, ptr %l4
  store i64 %t50, ptr %l29
  %t51 = load i64, ptr %l29
  %t52 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t53 = load ptr, ptr %t52
  %t54 = getelementptr { i64, [1 x i64] }, ptr %t53, i64 %t51
  %t55 = load { i64, [1 x i64] }, ptr %t54
  store { i64, [1 x i64] } %t55, ptr %l30
  %t56 = load { i64, [1 x i64] }, ptr %l30
  store { i64, [1 x i64] } %t56, ptr %l6
  %t57 = load ptr, ptr %l0
  store ptr %t57, ptr %l31
  %t58 = load ptr, ptr %l31
  %t59 = getelementptr %"compiler/typed:Plan", ptr %t58, i32 0, i32 5
  store ptr %t59, ptr %l32
  %t60 = load { i64, [1 x i64] }, ptr %l6
  store { i64, [1 x i64] } %t60, ptr %l33
  %t61 = load ptr, ptr %l32
  %t62 = load { i64, [1 x i64] }, ptr %l33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t61, { i64, [1 x i64] } %t62)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t63 = load i64, ptr %l4
  store i64 %t63, ptr %l34
  %t64 = load i64, ptr %l34
  %t65 = add i64 %t64, 1
  store i64 %t65, ptr %l35
  %t66 = load i64, ptr %l35
  store i64 %t66, ptr %l4
  call void @__olang_scope_close(ptr %s3)
  br label %bb2
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca { i64, [1 x i64] }
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, [1 x i64] }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, [1 x i64] }
  %t36 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l4
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t2, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3
  store { i64, ptr } %t4, ptr %l5
  %t5 = load i32, ptr %l1
  store i32 %t5, ptr %l6
  %t6 = load i32, ptr %l6
  %t7 = sext i32 %t6 to i64
  store i64 %t7, ptr %l7
  %t8 = load i64, ptr %l7
  %t9 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t10 = load ptr, ptr %t9
  %t11 = getelementptr i64, ptr %t10, i64 %t8
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l8
  %t13 = load i64, ptr %l8
  store i64 %t13, ptr %l3
  %t14 = load i64, ptr %l3
  store i64 %t14, ptr %l9
  %t15 = load i64, ptr %l9
  %t16 = icmp eq i64 %t15, 0
  store i1 %t16, ptr %l10
  %t17 = load i1, ptr %l10
  br i1 %t17, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11
  br label %bb3
bb2:
  %t18 = load i64, ptr %l2
  store i64 %t18, ptr %l12
  %t19 = load ptr, ptr %l0
  store ptr %t19, ptr %l13
  %t20 = load ptr, ptr %l13
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t20, i32 0, i32 4
  %t22 = load { i64, ptr }, ptr %t21
  store { i64, ptr } %t22, ptr %l14
  %t23 = load i32, ptr %l1
  store i32 %t23, ptr %l15
  %t24 = load i32, ptr %l15
  %t25 = sext i32 %t24 to i64
  store i64 %t25, ptr %l16
  %t26 = load i64, ptr %l16
  %t27 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t28 = load ptr, ptr %t27
  %t29 = getelementptr i64, ptr %t28, i64 %t26
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l17
  %t31 = load i64, ptr %l12
  %t32 = load i64, ptr %l17
  %t33 = icmp sge i64 %t31, %t32
  store i1 %t33, ptr %l18
  %t34 = load i1, ptr %l18
  store i1 %t34, ptr %l11
  br label %bb3
bb3:
  %t35 = load i1, ptr %l11
  br i1 %t35, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, [1 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [1 x i64] }, ptr %t36, i32 0, i32 0
  store i64 0, ptr %t37
  %t38 = load { i64, [1 x i64] }, ptr %t36
  store { i64, [1 x i64] } %t38, ptr %l19
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load { i64, [1 x i64] }, ptr %l19
  store { i64, [1 x i64] } %t39, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l0
  store ptr %t40, ptr %l20
  %t41 = load ptr, ptr %l20
  %t42 = getelementptr %"compiler/typed:Plan", ptr %t41, i32 0, i32 5
  store ptr %t42, ptr %l21
  %t43 = load i64, ptr %l3
  store i64 %t43, ptr %l22
  %t44 = load i64, ptr %l22
  %t45 = sub i64 %t44, 1
  store i64 %t45, ptr %l23
  %t46 = load i64, ptr %l2
  store i64 %t46, ptr %l24
  %t47 = load i64, ptr %l23
  %t48 = load i64, ptr %l24
  %t49 = add i64 %t47, %t48
  store i64 %t49, ptr %l25
  %t50 = load ptr, ptr %l21
  %t51 = load i64, ptr %l25
  %t52 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t50, i64 %t51)
  store { i64, [1 x i64] } %t52, ptr %l26
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load { i64, [1 x i64] }, ptr %l26
  store { i64, [1 x i64] } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca ptr
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca ptr
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca ptr
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca %"compiler/source:Span"
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l68 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca ptr
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca ptr
  %l80 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i64
  %l89 = alloca ptr
  %l90 = alloca %"compiler/source:Span"
  %l91 = alloca ptr
  %l92 = alloca i1
  %l93 = alloca i1
  %l94 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l5
  store i1 false, ptr %l6
  %t2 = load ptr, ptr %l5
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l7
  %t4 = load i1, ptr %l7
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l8
  %t7 = load i64, ptr %l8
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l6
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0
  store ptr %t10, ptr %l9
  %t11 = load ptr, ptr %l9
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l10
  %t15 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t15, ptr %l1
  br label %bb21
bb4:
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l11
  store i1 false, ptr %l12
  %t17 = load ptr, ptr %l11
  %t18 = icmp ne ptr %t17, null
  store i1 %t18, ptr %l13
  %t19 = load i1, ptr %l13
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l11
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l14
  %t22 = load i64, ptr %l14
  %t23 = icmp eq i64 %t22, 1
  store i1 %t23, ptr %l12
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0
  store ptr %t25, ptr %l15
  %t26 = load ptr, ptr %l15
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l16
  %t30 = load %"compiler/source:Span", ptr %l16
  store %"compiler/source:Span" %t30, ptr %l1
  br label %bb21
bb8:
  %t31 = load ptr, ptr %l0
  store ptr %t31, ptr %l17
  store i1 false, ptr %l18
  %t32 = load ptr, ptr %l17
  %t33 = icmp ne ptr %t32, null
  store i1 %t33, ptr %l19
  %t34 = load i1, ptr %l19
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l17
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l20
  %t37 = load i64, ptr %l20
  %t38 = icmp eq i64 %t37, 2
  store i1 %t38, ptr %l18
  br label %bb10
bb10:
  %t39 = load i1, ptr %l18
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0
  store ptr %t40, ptr %l21
  %t41 = load ptr, ptr %l21
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t41, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l22
  %t45 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t45, ptr %l1
  br label %bb21
bb12:
  %t46 = load ptr, ptr %l0
  store ptr %t46, ptr %l23
  store i1 false, ptr %l24
  %t47 = load ptr, ptr %l23
  %t48 = icmp ne ptr %t47, null
  store i1 %t48, ptr %l25
  %t49 = load i1, ptr %l25
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l23
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l26
  %t52 = load i64, ptr %l26
  %t53 = icmp eq i64 %t52, 3
  store i1 %t53, ptr %l24
  br label %bb14
bb14:
  %t54 = load i1, ptr %l24
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0
  store ptr %t55, ptr %l27
  %t56 = load ptr, ptr %l27
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t56, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l28
  %t60 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t60, ptr %l1
  br label %bb21
bb16:
  %t61 = load ptr, ptr %l0
  store ptr %t61, ptr %l29
  store i1 false, ptr %l30
  %t62 = load ptr, ptr %l29
  %t63 = icmp ne ptr %t62, null
  store i1 %t63, ptr %l31
  %t64 = load i1, ptr %l31
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l29
  %t66 = load i64, ptr %t65
  store i64 %t66, ptr %l32
  %t67 = load i64, ptr %l32
  %t68 = icmp eq i64 %t67, 4
  store i1 %t68, ptr %l30
  br label %bb18
bb18:
  %t69 = load i1, ptr %l30
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0
  store ptr %t70, ptr %l33
  %t71 = load ptr, ptr %l33
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l34
  %t75 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t75, ptr %l1
  br label %bb21
bb20:
  br label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s1
  %t76 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t76, ptr %l35
  %t77 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t77, ptr %l4
  call void @__olang_scope_close(ptr %s1)
  br label %bb67
bb22:
  %t78 = load ptr, ptr %l0
  store ptr %t78, ptr %l36
  store i1 false, ptr %l37
  %t79 = load ptr, ptr %l36
  %t80 = icmp ne ptr %t79, null
  store i1 %t80, ptr %l38
  %t81 = load i1, ptr %l38
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l36
  %t83 = load i64, ptr %t82
  store i64 %t83, ptr %l39
  %t84 = load i64, ptr %l39
  %t85 = icmp eq i64 %t84, 5
  store i1 %t85, ptr %l37
  br label %bb24
bb24:
  %t86 = load i1, ptr %l37
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0
  store ptr %t87, ptr %l40
  %t88 = load ptr, ptr %l40
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l41
  %t92 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t92, ptr %l2
  br label %bb43
bb26:
  %t93 = load ptr, ptr %l0
  store ptr %t93, ptr %l42
  store i1 false, ptr %l43
  %t94 = load ptr, ptr %l42
  %t95 = icmp ne ptr %t94, null
  store i1 %t95, ptr %l44
  %t96 = load i1, ptr %l44
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l42
  %t98 = load i64, ptr %t97
  store i64 %t98, ptr %l45
  %t99 = load i64, ptr %l45
  %t100 = icmp eq i64 %t99, 6
  store i1 %t100, ptr %l43
  br label %bb28
bb28:
  %t101 = load i1, ptr %l43
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0
  store ptr %t102, ptr %l46
  %t103 = load ptr, ptr %l46
  %t104 = getelementptr { i64, [3 x i64] }, ptr %t103, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l47
  %t107 = load %"compiler/source:Span", ptr %l47
  store %"compiler/source:Span" %t107, ptr %l2
  br label %bb43
bb30:
  %t108 = load ptr, ptr %l0
  store ptr %t108, ptr %l48
  store i1 false, ptr %l49
  %t109 = load ptr, ptr %l48
  %t110 = icmp ne ptr %t109, null
  store i1 %t110, ptr %l50
  %t111 = load i1, ptr %l50
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l48
  %t113 = load i64, ptr %t112
  store i64 %t113, ptr %l51
  %t114 = load i64, ptr %l51
  %t115 = icmp eq i64 %t114, 7
  store i1 %t115, ptr %l49
  br label %bb32
bb32:
  %t116 = load i1, ptr %l49
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0
  store ptr %t117, ptr %l52
  %t118 = load ptr, ptr %l52
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l53
  %t122 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t122, ptr %l2
  br label %bb43
bb34:
  %t123 = load ptr, ptr %l0
  store ptr %t123, ptr %l54
  store i1 false, ptr %l55
  %t124 = load ptr, ptr %l54
  %t125 = icmp ne ptr %t124, null
  store i1 %t125, ptr %l56
  %t126 = load i1, ptr %l56
  br i1 %t126, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l54
  %t128 = load i64, ptr %t127
  store i64 %t128, ptr %l57
  %t129 = load i64, ptr %l57
  %t130 = icmp eq i64 %t129, 8
  store i1 %t130, ptr %l55
  br label %bb36
bb36:
  %t131 = load i1, ptr %l55
  br i1 %t131, label %bb37, label %bb38
bb37:
  %t132 = load ptr, ptr %l0
  store ptr %t132, ptr %l58
  %t133 = load ptr, ptr %l58
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t133, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32 }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l59
  %t137 = load %"compiler/source:Span", ptr %l59
  store %"compiler/source:Span" %t137, ptr %l2
  br label %bb43
bb38:
  %t138 = load ptr, ptr %l0
  store ptr %t138, ptr %l60
  store i1 false, ptr %l61
  %t139 = load ptr, ptr %l60
  %t140 = icmp ne ptr %t139, null
  store i1 %t140, ptr %l62
  %t141 = load i1, ptr %l62
  br i1 %t141, label %bb39, label %bb40
bb39:
  %t142 = load ptr, ptr %l60
  %t143 = load i64, ptr %t142
  store i64 %t143, ptr %l63
  %t144 = load i64, ptr %l63
  %t145 = icmp eq i64 %t144, 9
  store i1 %t145, ptr %l61
  br label %bb40
bb40:
  %t146 = load i1, ptr %l61
  br i1 %t146, label %bb41, label %bb42
bb41:
  %t147 = load ptr, ptr %l0
  store ptr %t147, ptr %l64
  %t148 = load ptr, ptr %l64
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t148, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  store %"compiler/source:Span" %t151, ptr %l65
  %t152 = load %"compiler/source:Span", ptr %l65
  store %"compiler/source:Span" %t152, ptr %l2
  br label %bb43
bb42:
  br label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s2
  %t153 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t153, ptr %l66
  %t154 = load %"compiler/source:Span", ptr %l66
  store %"compiler/source:Span" %t154, ptr %l4
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb44:
  %t155 = load ptr, ptr %l0
  store ptr %t155, ptr %l67
  store i1 false, ptr %l68
  %t156 = load ptr, ptr %l67
  %t157 = icmp ne ptr %t156, null
  store i1 %t157, ptr %l69
  %t158 = load i1, ptr %l69
  br i1 %t158, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l67
  %t160 = load i64, ptr %t159
  store i64 %t160, ptr %l70
  %t161 = load i64, ptr %l70
  %t162 = icmp eq i64 %t161, 10
  store i1 %t162, ptr %l68
  br label %bb46
bb46:
  %t163 = load i1, ptr %l68
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0
  store ptr %t164, ptr %l71
  %t165 = load ptr, ptr %l71
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t165, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l72
  %t169 = load %"compiler/source:Span", ptr %l72
  store %"compiler/source:Span" %t169, ptr %l3
  br label %bb65
bb48:
  %t170 = load ptr, ptr %l0
  store ptr %t170, ptr %l73
  store i1 false, ptr %l74
  %t171 = load ptr, ptr %l73
  %t172 = icmp ne ptr %t171, null
  store i1 %t172, ptr %l75
  %t173 = load i1, ptr %l75
  br i1 %t173, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l73
  %t175 = load i64, ptr %t174
  store i64 %t175, ptr %l76
  %t176 = load i64, ptr %l76
  %t177 = icmp eq i64 %t176, 11
  store i1 %t177, ptr %l74
  br label %bb50
bb50:
  %t178 = load i1, ptr %l74
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0
  store ptr %t179, ptr %l77
  %t180 = load ptr, ptr %l77
  %t181 = getelementptr { i64, [3 x i64] }, ptr %t180, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l78
  %t184 = load %"compiler/source:Span", ptr %l78
  store %"compiler/source:Span" %t184, ptr %l3
  br label %bb65
bb52:
  %t185 = load ptr, ptr %l0
  store ptr %t185, ptr %l79
  store i1 false, ptr %l80
  %t186 = load ptr, ptr %l79
  %t187 = icmp ne ptr %t186, null
  store i1 %t187, ptr %l81
  %t188 = load i1, ptr %l81
  br i1 %t188, label %bb53, label %bb54
bb53:
  %t189 = load ptr, ptr %l79
  %t190 = load i64, ptr %t189
  store i64 %t190, ptr %l82
  %t191 = load i64, ptr %l82
  %t192 = icmp eq i64 %t191, 12
  store i1 %t192, ptr %l80
  br label %bb54
bb54:
  %t193 = load i1, ptr %l80
  br i1 %t193, label %bb55, label %bb56
bb55:
  %t194 = load ptr, ptr %l0
  store ptr %t194, ptr %l83
  %t195 = load ptr, ptr %l83
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t195, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr }, ptr %t196, i32 0, i32 0
  %t198 = load %"compiler/source:Span", ptr %t197
  store %"compiler/source:Span" %t198, ptr %l84
  %t199 = load %"compiler/source:Span", ptr %l84
  store %"compiler/source:Span" %t199, ptr %l3
  br label %bb65
bb56:
  %t200 = load ptr, ptr %l0
  store ptr %t200, ptr %l85
  store i1 false, ptr %l86
  %t201 = load ptr, ptr %l85
  %t202 = icmp ne ptr %t201, null
  store i1 %t202, ptr %l87
  %t203 = load i1, ptr %l87
  br i1 %t203, label %bb57, label %bb58
bb57:
  %t204 = load ptr, ptr %l85
  %t205 = load i64, ptr %t204
  store i64 %t205, ptr %l88
  %t206 = load i64, ptr %l88
  %t207 = icmp eq i64 %t206, 13
  store i1 %t207, ptr %l86
  br label %bb58
bb58:
  %t208 = load i1, ptr %l86
  br i1 %t208, label %bb59, label %bb60
bb59:
  %t209 = load ptr, ptr %l0
  store ptr %t209, ptr %l89
  %t210 = load ptr, ptr %l89
  %t211 = getelementptr { i64, [3 x i64] }, ptr %t210, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", ptr }, ptr %t211, i32 0, i32 0
  %t213 = load %"compiler/source:Span", ptr %t212
  store %"compiler/source:Span" %t213, ptr %l90
  %t214 = load %"compiler/source:Span", ptr %l90
  store %"compiler/source:Span" %t214, ptr %l3
  br label %bb65
bb60:
  %t215 = load ptr, ptr %l0
  store ptr %t215, ptr %l91
  store i1 false, ptr %l92
  %t216 = load ptr, ptr %l91
  %t217 = icmp ne ptr %t216, null
  store i1 %t217, ptr %l93
  %t218 = load i1, ptr %l93
  br i1 %t218, label %bb61, label %bb62
bb61:
  %t219 = load ptr, ptr %l91
  %t220 = load i64, ptr %t219
  store i64 %t220, ptr %l94
  %t221 = load i64, ptr %l94
  %t222 = icmp eq i64 %t221, 14
  store i1 %t222, ptr %l92
  br label %bb62
bb62:
  %t223 = load i1, ptr %l92
  br i1 %t223, label %bb63, label %bb64
bb63:
  %t224 = load ptr, ptr %l0
  store ptr %t224, ptr %l95
  %t225 = load ptr, ptr %l95
  %t226 = getelementptr { i64, [3 x i64] }, ptr %t225, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", ptr }, ptr %t226, i32 0, i32 0
  %t228 = load %"compiler/source:Span", ptr %t227
  store %"compiler/source:Span" %t228, ptr %l96
  %t229 = load %"compiler/source:Span", ptr %l96
  store %"compiler/source:Span" %t229, ptr %l3
  br label %bb65
bb64:
  br label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s3
  %t230 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t230, ptr %l97
  %t231 = load %"compiler/source:Span", ptr %l97
  store %"compiler/source:Span" %t231, ptr %l4
  call void @__olang_scope_close(ptr %s3)
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t232 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t232, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/typed:Alt" @compiler_2ftyped_3aAlt_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/typed:Alt"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Alt"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l4
  store ptr %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l5
  %t4 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t4, ptr %l3
  %t5 = load ptr, ptr %l2
  %t6 = insertvalue %"compiler/typed:Alt" undef, ptr %t5, 0
  %t7 = load { i64, ptr }, ptr %l3
  %t8 = insertvalue %"compiler/typed:Alt" %t6, { i64, ptr } %t7, 1
  store %"compiler/typed:Alt" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/typed:Alt", ptr %l6
  store %"compiler/typed:Alt" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Alt", ptr %rv
  ret %"compiler/typed:Alt" %rr
}

define dso_local %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca %"compiler/typed:Arm"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Arm"
  store %"compiler/source:Span" %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l10
  %t2 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l11
  %t4 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t4, ptr %l6
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l12
  %t6 = load ptr, ptr %l12
  store ptr %t6, ptr %l7
  %t7 = load ptr, ptr %l3
  store ptr %t7, ptr %l13
  %t8 = load ptr, ptr %l13
  store ptr %t8, ptr %l8
  %t9 = load ptr, ptr %l4
  store ptr %t9, ptr %l14
  %t10 = load ptr, ptr %l14
  store ptr %t10, ptr %l9
  %t11 = load %"compiler/source:Span", ptr %l5
  %t12 = insertvalue %"compiler/typed:Arm" undef, %"compiler/source:Span" %t11, 0
  %t13 = load { i64, ptr }, ptr %l6
  %t14 = insertvalue %"compiler/typed:Arm" %t12, { i64, ptr } %t13, 1
  %t15 = load ptr, ptr %l7
  %t16 = insertvalue %"compiler/typed:Arm" %t14, ptr %t15, 2
  %t17 = load ptr, ptr %l8
  %t18 = insertvalue %"compiler/typed:Arm" %t16, ptr %t17, 3
  %t19 = load ptr, ptr %l9
  %t20 = insertvalue %"compiler/typed:Arm" %t18, ptr %t19, 4
  store %"compiler/typed:Arm" %t20, ptr %l15
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/typed:Arm", ptr %l15
  store %"compiler/typed:Arm" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Arm", ptr %rv
  ret %"compiler/typed:Arm" %rr
}

define dso_local %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/typed:Bind"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Bind"
  store i32 %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l4
  %t2 = load i32, ptr %l4
  store i32 %t2, ptr %l2
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l5
  %t4 = load ptr, ptr %l5
  store ptr %t4, ptr %l3
  %t5 = load i32, ptr %l2
  %t6 = insertvalue %"compiler/typed:Bind" undef, i32 %t5, 0
  %t7 = load ptr, ptr %l3
  %t8 = insertvalue %"compiler/typed:Bind" %t6, ptr %t7, 1
  store %"compiler/typed:Bind" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/typed:Bind", ptr %l6
  store %"compiler/typed:Bind" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Bind", ptr %rv
  ret %"compiler/typed:Bind" %rr
}

define dso_local %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %v0, i32 %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/typed:BlockInfo"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:BlockInfo"
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l6
  %t2 = load i32, ptr %l6
  store i32 %t2, ptr %l3
  %t3 = load i32, ptr %l1
  store i32 %t3, ptr %l7
  %t4 = load i32, ptr %l7
  store i32 %t4, ptr %l4
  %t5 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t5, ptr %l8
  %t6 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t6, ptr %l5
  %t7 = load i32, ptr %l3
  %t8 = insertvalue %"compiler/typed:BlockInfo" undef, i32 %t7, 0
  %t9 = load i32, ptr %l4
  %t10 = insertvalue %"compiler/typed:BlockInfo" %t8, i32 %t9, 1
  %t11 = load %"compiler/source:Span", ptr %l5
  %t12 = insertvalue %"compiler/typed:BlockInfo" %t10, %"compiler/source:Span" %t11, 2
  store %"compiler/typed:BlockInfo" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/typed:BlockInfo", ptr %l9
  store %"compiler/typed:BlockInfo" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:BlockInfo", ptr %rv
  ret %"compiler/typed:BlockInfo" %rr
}

define dso_local %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Block"
  store i32 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l4
  %t2 = load i32, ptr %l4
  store i32 %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l5
  %t4 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t4, ptr %l3
  %t5 = load i32, ptr %l2
  %t6 = insertvalue %"compiler/typed:Block" undef, i32 %t5, 0
  %t7 = load { i64, ptr }, ptr %l3
  %t8 = insertvalue %"compiler/typed:Block" %t6, { i64, ptr } %t7, 1
  store %"compiler/typed:Block" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/typed:Block", ptr %l6
  store %"compiler/typed:Block" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Block", ptr %rv
  ret %"compiler/typed:Block" %rr
}

define dso_local %"compiler/typed:Body" @compiler_2ftyped_3aBody_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"std/prelude/list:List<compiler/typed:LocalId>"
  %l11 = alloca %"std/prelude/list:List<compiler/typed:ScopeVar>"
  %l12 = alloca %"std/prelude/list:List<compiler/typed:Local>"
  %l13 = alloca %"std/prelude/list:List<compiler/typed:BlockInfo>"
  %l14 = alloca %"std/prelude/list:List<compiler/typed:SiteInfo>"
  %l15 = alloca %"std/prelude/list:List<compiler/typed:LocalId>"
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca %"std/prelude/list:List<compiler/typed:LocalId>"
  %l23 = alloca %"std/prelude/list:List<compiler/typed:ScopeVar>"
  %l24 = alloca %"std/prelude/list:List<compiler/typed:Local>"
  %l25 = alloca %"std/prelude/list:List<compiler/typed:BlockInfo>"
  %l26 = alloca %"std/prelude/list:List<compiler/typed:SiteInfo>"
  %l27 = alloca %"std/prelude/list:List<compiler/typed:LocalId>"
  %l28 = alloca %"compiler/typed:Body"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Body"
  store i32 %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l17
  %t2 = load i32, ptr %l17
  store i32 %t2, ptr %l5
  %t3 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t3, ptr %l18
  %t4 = load { i64, [2 x i64] }, ptr %l18
  store { i64, [2 x i64] } %t4, ptr %l6
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l19
  %t6 = load i32, ptr %l19
  store i32 %t6, ptr %l7
  %t7 = load i64, ptr %l3
  store i64 %t7, ptr %l20
  %t8 = load i64, ptr %l20
  store i64 %t8, ptr %l8
  %t9 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t9, ptr %l21
  %t10 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t10, ptr %l9
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call %"std/prelude/list:List<compiler/typed:LocalId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e(ptr %t11)
  store %"std/prelude/list:List<compiler/typed:LocalId>" %t12, ptr %l22
  br label %bb1
bb1:
  %t13 = load %"std/prelude/list:List<compiler/typed:LocalId>", ptr %l22
  store %"std/prelude/list:List<compiler/typed:LocalId>" %t13, ptr %l10
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call %"std/prelude/list:List<compiler/typed:ScopeVar>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e(ptr %t14)
  store %"std/prelude/list:List<compiler/typed:ScopeVar>" %t15, ptr %l23
  br label %bb2
bb2:
  %t16 = load %"std/prelude/list:List<compiler/typed:ScopeVar>", ptr %l23
  store %"std/prelude/list:List<compiler/typed:ScopeVar>" %t16, ptr %l11
  %t17 = load ptr, ptr @__olang_prog_scope
  %t18 = call %"std/prelude/list:List<compiler/typed:Local>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e(ptr %t17)
  store %"std/prelude/list:List<compiler/typed:Local>" %t18, ptr %l24
  br label %bb3
bb3:
  %t19 = load %"std/prelude/list:List<compiler/typed:Local>", ptr %l24
  store %"std/prelude/list:List<compiler/typed:Local>" %t19, ptr %l12
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/list:List<compiler/typed:BlockInfo>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %t20)
  store %"std/prelude/list:List<compiler/typed:BlockInfo>" %t21, ptr %l25
  br label %bb4
bb4:
  %t22 = load %"std/prelude/list:List<compiler/typed:BlockInfo>", ptr %l25
  store %"std/prelude/list:List<compiler/typed:BlockInfo>" %t22, ptr %l13
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/list:List<compiler/typed:SiteInfo>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %t23)
  store %"std/prelude/list:List<compiler/typed:SiteInfo>" %t24, ptr %l26
  br label %bb5
bb5:
  %t25 = load %"std/prelude/list:List<compiler/typed:SiteInfo>", ptr %l26
  store %"std/prelude/list:List<compiler/typed:SiteInfo>" %t25, ptr %l14
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = call %"std/prelude/list:List<compiler/typed:LocalId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e(ptr %t26)
  store %"std/prelude/list:List<compiler/typed:LocalId>" %t27, ptr %l27
  br label %bb6
bb6:
  %t28 = load %"std/prelude/list:List<compiler/typed:LocalId>", ptr %l27
  store %"std/prelude/list:List<compiler/typed:LocalId>" %t28, ptr %l15
  store ptr null, ptr %l16
  %t29 = load i32, ptr %l5
  %t30 = insertvalue %"compiler/typed:Body" undef, i32 %t29, 0
  %t31 = load { i64, [2 x i64] }, ptr %l6
  %t32 = insertvalue %"compiler/typed:Body" %t30, { i64, [2 x i64] } %t31, 1
  %t33 = load i32, ptr %l7
  %t34 = insertvalue %"compiler/typed:Body" %t32, i32 %t33, 2
  %t35 = load i64, ptr %l8
  %t36 = insertvalue %"compiler/typed:Body" %t34, i64 %t35, 3
  %t37 = load %"compiler/source:Span", ptr %l9
  %t38 = insertvalue %"compiler/typed:Body" %t36, %"compiler/source:Span" %t37, 4
  %t39 = load %"std/prelude/list:List<compiler/typed:LocalId>", ptr %l10
  %t40 = insertvalue %"compiler/typed:Body" %t38, %"std/prelude/list:List<compiler/typed:LocalId>" %t39, 5
  %t41 = load %"std/prelude/list:List<compiler/typed:ScopeVar>", ptr %l11
  %t42 = insertvalue %"compiler/typed:Body" %t40, %"std/prelude/list:List<compiler/typed:ScopeVar>" %t41, 6
  %t43 = load %"std/prelude/list:List<compiler/typed:Local>", ptr %l12
  %t44 = insertvalue %"compiler/typed:Body" %t42, %"std/prelude/list:List<compiler/typed:Local>" %t43, 7
  %t45 = load %"std/prelude/list:List<compiler/typed:BlockInfo>", ptr %l13
  %t46 = insertvalue %"compiler/typed:Body" %t44, %"std/prelude/list:List<compiler/typed:BlockInfo>" %t45, 8
  %t47 = load %"std/prelude/list:List<compiler/typed:SiteInfo>", ptr %l14
  %t48 = insertvalue %"compiler/typed:Body" %t46, %"std/prelude/list:List<compiler/typed:SiteInfo>" %t47, 9
  %t49 = load %"std/prelude/list:List<compiler/typed:LocalId>", ptr %l15
  %t50 = insertvalue %"compiler/typed:Body" %t48, %"std/prelude/list:List<compiler/typed:LocalId>" %t49, 10
  %t51 = load ptr, ptr %l16
  %t52 = insertvalue %"compiler/typed:Body" %t50, ptr %t51, 11
  store %"compiler/typed:Body" %t52, ptr %l28
  call void @__olang_scope_close(ptr %s0)
  %t53 = load %"compiler/typed:Body", ptr %l28
  store %"compiler/typed:Body" %t53, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Body", ptr %rv
  ret %"compiler/typed:Body" %rr
}

define dso_local %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, [2 x i64] }
  %l13 = alloca i32
  %l14 = alloca i1
  %l15 = alloca %"compiler/typed:Call"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Call"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l10
  %t2 = load ptr, ptr %l10
  store ptr %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l11
  %t4 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t4, ptr %l6
  %t5 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t5, ptr %l12
  %t6 = load { i64, [2 x i64] }, ptr %l12
  store { i64, [2 x i64] } %t6, ptr %l7
  %t7 = load i32, ptr %l3
  store i32 %t7, ptr %l13
  %t8 = load i32, ptr %l13
  store i32 %t8, ptr %l8
  %t9 = load i1, ptr %l4
  store i1 %t9, ptr %l14
  %t10 = load i1, ptr %l14
  store i1 %t10, ptr %l9
  %t11 = load ptr, ptr %l5
  %t12 = insertvalue %"compiler/typed:Call" undef, ptr %t11, 0
  %t13 = load { i64, ptr }, ptr %l6
  %t14 = insertvalue %"compiler/typed:Call" %t12, { i64, ptr } %t13, 1
  %t15 = load { i64, [2 x i64] }, ptr %l7
  %t16 = insertvalue %"compiler/typed:Call" %t14, { i64, [2 x i64] } %t15, 2
  %t17 = load i32, ptr %l8
  %t18 = insertvalue %"compiler/typed:Call" %t16, i32 %t17, 3
  %t19 = load i1, ptr %l9
  %t20 = insertvalue %"compiler/typed:Call" %t18, i1 %t19, 4
  store %"compiler/typed:Call" %t20, ptr %l15
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/typed:Call", ptr %l15
  store %"compiler/typed:Call" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Call", ptr %rv
  ret %"compiler/typed:Call" %rr
}

define dso_local %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/typed:Capture"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Capture"
  store i32 %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l4
  %t2 = load i32, ptr %l4
  store i32 %t2, ptr %l2
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l5
  %t4 = load ptr, ptr %l5
  store ptr %t4, ptr %l3
  %t5 = load i32, ptr %l2
  %t6 = insertvalue %"compiler/typed:Capture" undef, i32 %t5, 0
  %t7 = load ptr, ptr %l3
  %t8 = insertvalue %"compiler/typed:Capture" %t6, ptr %t7, 1
  store %"compiler/typed:Capture" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/typed:Capture", ptr %l6
  store %"compiler/typed:Capture" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Capture", ptr %rv
  ret %"compiler/typed:Capture" %rr
}

define dso_local %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/typed:Clause"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Clause"
  store %"compiler/source:Span" %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l10
  %t2 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t2, ptr %l5
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l11
  %t4 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t4, ptr %l6
  %t5 = load i1, ptr %l2
  store i1 %t5, ptr %l12
  %t6 = load i1, ptr %l12
  store i1 %t6, ptr %l7
  %t7 = load ptr, ptr %l3
  store ptr %t7, ptr %l13
  %t8 = load ptr, ptr %l13
  store ptr %t8, ptr %l8
  %t9 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t9, ptr %l14
  %t10 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t10, ptr %l9
  %t11 = load %"compiler/source:Span", ptr %l5
  %t12 = insertvalue %"compiler/typed:Clause" undef, %"compiler/source:Span" %t11, 0
  %t13 = load { i64, ptr }, ptr %l6
  %t14 = insertvalue %"compiler/typed:Clause" %t12, { i64, ptr } %t13, 1
  %t15 = load i1, ptr %l7
  %t16 = insertvalue %"compiler/typed:Clause" %t14, i1 %t15, 2
  %t17 = load ptr, ptr %l8
  %t18 = insertvalue %"compiler/typed:Clause" %t16, ptr %t17, 3
  %t19 = load { i64, ptr }, ptr %l9
  %t20 = insertvalue %"compiler/typed:Clause" %t18, { i64, ptr } %t19, 4
  store %"compiler/typed:Clause" %t20, ptr %l15
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/typed:Clause", ptr %l15
  store %"compiler/typed:Clause" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Clause", ptr %rv
  ret %"compiler/typed:Clause" %rr
}

define dso_local %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"compiler/typed:Collect"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Collect"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l8
  %t2 = load ptr, ptr %l8
  store ptr %t2, ptr %l4
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l9
  %t4 = load ptr, ptr %l9
  store ptr %t4, ptr %l5
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l10
  %t6 = load i32, ptr %l10
  store i32 %t6, ptr %l6
  %t7 = load i32, ptr %l3
  store i32 %t7, ptr %l11
  %t8 = load i32, ptr %l11
  store i32 %t8, ptr %l7
  %t9 = load ptr, ptr %l4
  %t10 = insertvalue %"compiler/typed:Collect" undef, ptr %t9, 0
  %t11 = load ptr, ptr %l5
  %t12 = insertvalue %"compiler/typed:Collect" %t10, ptr %t11, 1
  %t13 = load i32, ptr %l6
  %t14 = insertvalue %"compiler/typed:Collect" %t12, i32 %t13, 2
  %t15 = load i32, ptr %l7
  %t16 = insertvalue %"compiler/typed:Collect" %t14, i32 %t15, 3
  store %"compiler/typed:Collect" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/typed:Collect", ptr %l12
  store %"compiler/typed:Collect" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Collect", ptr %rv
  ret %"compiler/typed:Collect" %rr
}

define dso_local %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"compiler/typed:Cond"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Cond"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l6
  %t2 = load ptr, ptr %l6
  store ptr %t2, ptr %l3
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l7
  %t4 = load ptr, ptr %l7
  store ptr %t4, ptr %l4
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l8
  %t6 = load ptr, ptr %l8
  store ptr %t6, ptr %l5
  %t7 = load ptr, ptr %l3
  %t8 = insertvalue %"compiler/typed:Cond" undef, ptr %t7, 0
  %t9 = load ptr, ptr %l4
  %t10 = insertvalue %"compiler/typed:Cond" %t8, ptr %t9, 1
  %t11 = load ptr, ptr %l5
  %t12 = insertvalue %"compiler/typed:Cond" %t10, ptr %t11, 2
  store %"compiler/typed:Cond" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/typed:Cond", ptr %l9
  store %"compiler/typed:Cond" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Cond", ptr %rv
  ret %"compiler/typed:Cond" %rr
}

define dso_local %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"compiler/typed:Elem"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Elem"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l6
  %t2 = load ptr, ptr %l6
  store ptr %t2, ptr %l3
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l7
  %t4 = load ptr, ptr %l7
  store ptr %t4, ptr %l4
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l8
  %t6 = load i32, ptr %l8
  store i32 %t6, ptr %l5
  %t7 = load ptr, ptr %l3
  %t8 = insertvalue %"compiler/typed:Elem" undef, ptr %t7, 0
  %t9 = load ptr, ptr %l4
  %t10 = insertvalue %"compiler/typed:Elem" %t8, ptr %t9, 1
  %t11 = load i32, ptr %l5
  %t12 = insertvalue %"compiler/typed:Elem" %t10, i32 %t11, 2
  store %"compiler/typed:Elem" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/typed:Elem", ptr %l9
  store %"compiler/typed:Elem" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Elem", ptr %rv
  ret %"compiler/typed:Elem" %rr
}

define dso_local %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"compiler/typed:If"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:If"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l6
  %t2 = load ptr, ptr %l6
  store ptr %t2, ptr %l3
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l7
  %t4 = load ptr, ptr %l7
  store ptr %t4, ptr %l4
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l8
  %t6 = load ptr, ptr %l8
  store ptr %t6, ptr %l5
  %t7 = load ptr, ptr %l3
  %t8 = insertvalue %"compiler/typed:If" undef, ptr %t7, 0
  %t9 = load ptr, ptr %l4
  %t10 = insertvalue %"compiler/typed:If" %t8, ptr %t9, 1
  %t11 = load ptr, ptr %l5
  %t12 = insertvalue %"compiler/typed:If" %t10, ptr %t11, 2
  store %"compiler/typed:If" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/typed:If", ptr %l9
  store %"compiler/typed:If" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:If", ptr %rv
  ret %"compiler/typed:If" %rr
}

define dso_local %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Item"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Item"
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l4
  %t2 = load i32, ptr %l4
  store i32 %t2, ptr %l2
  %t3 = load i64, ptr %l1
  store i64 %t3, ptr %l5
  %t4 = load i64, ptr %l5
  store i64 %t4, ptr %l3
  %t5 = load i32, ptr %l2
  %t6 = insertvalue %"compiler/typed:Item" undef, i32 %t5, 0
  %t7 = load i64, ptr %l3
  %t8 = insertvalue %"compiler/typed:Item" %t6, i64 %t7, 1
  store %"compiler/typed:Item" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/typed:Item", ptr %l6
  store %"compiler/typed:Item" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Item", ptr %rv
  ret %"compiler/typed:Item" %rr
}

define dso_local %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/typed:Join"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Join"
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l6
  %t2 = load ptr, ptr %l6
  store ptr %t2, ptr %l3
  %t3 = load i1, ptr %l1
  store i1 %t3, ptr %l7
  %t4 = load i1, ptr %l7
  store i1 %t4, ptr %l4
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l8
  %t6 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t6, ptr %l5
  %t7 = load ptr, ptr %l3
  %t8 = insertvalue %"compiler/typed:Join" undef, ptr %t7, 0
  %t9 = load i1, ptr %l4
  %t10 = insertvalue %"compiler/typed:Join" %t8, i1 %t9, 1
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/typed:Join" %t10, { i64, ptr } %t11, 2
  store %"compiler/typed:Join" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/typed:Join", ptr %l9
  store %"compiler/typed:Join" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Join", ptr %rv
  ret %"compiler/typed:Join" %rr
}

define dso_local %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca { i64, [2 x i64] }
  %l18 = alloca %"compiler/typed:Local"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Local"
  store i32 %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store { i64, [2 x i64] } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l12
  %t2 = load i32, ptr %l12
  store i32 %t2, ptr %l6
  %t3 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t3, ptr %l13
  %t4 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t4, ptr %l7
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l14
  %t6 = load i32, ptr %l14
  store i32 %t6, ptr %l8
  %t7 = load i32, ptr %l3
  store i32 %t7, ptr %l15
  %t8 = load i32, ptr %l15
  store i32 %t8, ptr %l9
  %t9 = load i32, ptr %l4
  store i32 %t9, ptr %l16
  %t10 = load i32, ptr %l16
  store i32 %t10, ptr %l10
  %t11 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t11, ptr %l17
  %t12 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t12, ptr %l11
  %t13 = load i32, ptr %l6
  %t14 = insertvalue %"compiler/typed:Local" undef, i32 %t13, 0
  %t15 = load %"compiler/source:Span", ptr %l7
  %t16 = insertvalue %"compiler/typed:Local" %t14, %"compiler/source:Span" %t15, 1
  %t17 = load i32, ptr %l8
  %t18 = insertvalue %"compiler/typed:Local" %t16, i32 %t17, 2
  %t19 = load i32, ptr %l9
  %t20 = insertvalue %"compiler/typed:Local" %t18, i32 %t19, 3
  %t21 = load i32, ptr %l10
  %t22 = insertvalue %"compiler/typed:Local" %t20, i32 %t21, 4
  %t23 = load { i64, [2 x i64] }, ptr %l11
  %t24 = insertvalue %"compiler/typed:Local" %t22, { i64, [2 x i64] } %t23, 5
  store %"compiler/typed:Local" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/typed:Local", ptr %l18
  store %"compiler/typed:Local" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Local", ptr %rv
  ret %"compiler/typed:Local" %rr
}

define dso_local %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Make"
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l12
  %t2 = load i32, ptr %l12
  store i32 %t2, ptr %l6
  %t3 = load i64, ptr %l1
  store i64 %t3, ptr %l13
  %t4 = load i64, ptr %l13
  store i64 %t4, ptr %l7
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l14
  %t6 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t6, ptr %l8
  %t7 = load ptr, ptr %l3
  store ptr %t7, ptr %l15
  %t8 = load ptr, ptr %l15
  store ptr %t8, ptr %l9
  %t9 = load i32, ptr %l4
  store i32 %t9, ptr %l16
  %t10 = load i32, ptr %l16
  store i32 %t10, ptr %l10
  %t11 = load i32, ptr %l5
  store i32 %t11, ptr %l17
  %t12 = load i32, ptr %l17
  store i32 %t12, ptr %l11
  %t13 = load i32, ptr %l6
  %t14 = insertvalue %"compiler/typed:Make" undef, i32 %t13, 0
  %t15 = load i64, ptr %l7
  %t16 = insertvalue %"compiler/typed:Make" %t14, i64 %t15, 1
  %t17 = load { i64, ptr }, ptr %l8
  %t18 = insertvalue %"compiler/typed:Make" %t16, { i64, ptr } %t17, 2
  %t19 = load ptr, ptr %l9
  %t20 = insertvalue %"compiler/typed:Make" %t18, ptr %t19, 3
  %t21 = load i32, ptr %l10
  %t22 = insertvalue %"compiler/typed:Make" %t20, i32 %t21, 4
  %t23 = load i32, ptr %l11
  %t24 = insertvalue %"compiler/typed:Make" %t22, i32 %t23, 5
  store %"compiler/typed:Make" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/typed:Make", ptr %l18
  store %"compiler/typed:Make" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Make", ptr %rv
  ret %"compiler/typed:Make" %rr
}

define dso_local %"compiler/typed:Match" @compiler_2ftyped_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca %"compiler/typed:Match"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Match"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l8
  %t2 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t2, ptr %l4
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l9
  %t4 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t4, ptr %l5
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l10
  %t6 = load ptr, ptr %l10
  store ptr %t6, ptr %l6
  %t7 = load i1, ptr %l3
  store i1 %t7, ptr %l11
  %t8 = load i1, ptr %l11
  store i1 %t8, ptr %l7
  %t9 = load { i64, ptr }, ptr %l4
  %t10 = insertvalue %"compiler/typed:Match" undef, { i64, ptr } %t9, 0
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/typed:Match" %t10, { i64, ptr } %t11, 1
  %t13 = load ptr, ptr %l6
  %t14 = insertvalue %"compiler/typed:Match" %t12, ptr %t13, 2
  %t15 = load i1, ptr %l7
  %t16 = insertvalue %"compiler/typed:Match" %t14, i1 %t15, 3
  store %"compiler/typed:Match" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/typed:Match", ptr %l12
  store %"compiler/typed:Match" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Match", ptr %rv
  ret %"compiler/typed:Match" %rr
}

define dso_local %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"compiler/typed:Payload"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Payload"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l6
  %t2 = load ptr, ptr %l6
  store ptr %t2, ptr %l3
  %t3 = load i64, ptr %l1
  store i64 %t3, ptr %l7
  %t4 = load i64, ptr %l7
  store i64 %t4, ptr %l4
  %t5 = load i32, ptr %l2
  store i32 %t5, ptr %l8
  %t6 = load i32, ptr %l8
  store i32 %t6, ptr %l5
  %t7 = load ptr, ptr %l3
  %t8 = insertvalue %"compiler/typed:Payload" undef, ptr %t7, 0
  %t9 = load i64, ptr %l4
  %t10 = insertvalue %"compiler/typed:Payload" %t8, i64 %t9, 1
  %t11 = load i32, ptr %l5
  %t12 = insertvalue %"compiler/typed:Payload" %t10, i32 %t11, 2
  store %"compiler/typed:Payload" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/typed:Payload", ptr %l9
  store %"compiler/typed:Payload" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Payload", ptr %rv
  ret %"compiler/typed:Payload" %rr
}

define dso_local %"compiler/typed:Plan" @compiler_2ftyped_3aPlan_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/list:List<compiler/typed:Scope>"
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"std/prelude/list:List<compiler/typed:Scope>"
  %l35 = alloca %"compiler/typed:Plan"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Plan"
  %t22 = alloca { i64, [1 x i64] }, align 8
  %t35 = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l9
  %t2 = load i64, ptr %l9
  %t3 = icmp sge i64 %t2, 0
  store i1 %t3, ptr %l10
  %t4 = load i1, ptr %l10
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l9
  %t6 = icmp sle i64 %t5, 576460752303423487
  store i1 %t6, ptr %l11
  %t7 = load i1, ptr %l11
  br i1 %t7, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c6)
  unreachable
bb3:
  %t8 = load i64, ptr %l9
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l12
  %t13 = load { i64, ptr }, ptr %l12
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 16
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l13
  %t20 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t20, ptr %l3
  %t21 = load i64, ptr %l1
  store i64 %t21, ptr %l14
  store { i64, [1 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 0
  store i64 5, ptr %t23
  %t24 = load { i64, [1 x i64] }, ptr %t22
  store { i64, [1 x i64] } %t24, ptr %l15
  %t25 = load i64, ptr %l14
  %t26 = icmp sge i64 %t25, 0
  store i1 %t26, ptr %l16
  %t27 = load i1, ptr %l16
  br i1 %t27, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c6)
  unreachable
bb5:
  %t28 = load i64, ptr %l14
  %t29 = icmp sle i64 %t28, 576460752303423487
  store i1 %t29, ptr %l17
  %t30 = load i1, ptr %l17
  br i1 %t30, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c7)
  unreachable
bb7:
  %t31 = load i64, ptr %l14
  %t32 = mul i64 %t31, 16
  %t33 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t32)
  %t34 = load { i64, [1 x i64] }, ptr %l15
  store i64 0, ptr %t35
  br label %fill.36
fill.36:
  %t39 = load i64, ptr %t35
  %t40 = icmp slt i64 %t39, %t31
  br i1 %t40, label %fillb.37, label %filld.38
fillb.37:
  %t41 = getelementptr { i64, [1 x i64] }, ptr %t33, i64 %t39
  store { i64, [1 x i64] } %t34, ptr %t41
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %t35
  br label %fill.36
filld.38:
  %t43 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t33, 1
  store { i64, ptr } %t44, ptr %l18
  %t45 = load { i64, ptr }, ptr %l18
  %t46 = extractvalue { i64, ptr } %t45, 0
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = mul i64 %t46, 16
  %t49 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l19
  %t52 = load { i64, ptr }, ptr %l19
  store { i64, ptr } %t52, ptr %l4
  %t53 = load i64, ptr %l2
  store i64 %t53, ptr %l20
  %t54 = load i64, ptr %l20
  %t55 = icmp sge i64 %t54, 0
  store i1 %t55, ptr %l21
  %t56 = load i1, ptr %l21
  br i1 %t56, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c7)
  unreachable
bb9:
  %t57 = load i64, ptr %l20
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l22
  %t62 = load { i64, ptr }, ptr %l22
  %t63 = extractvalue { i64, ptr } %t62, 0
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l23
  %t69 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t69, ptr %l5
  %t70 = load i64, ptr %l0
  store i64 %t70, ptr %l24
  %t71 = load i64, ptr %l24
  %t72 = icmp sge i64 %t71, 0
  store i1 %t72, ptr %l25
  %t73 = load i1, ptr %l25
  br i1 %t73, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c8)
  unreachable
bb11:
  %t74 = load i64, ptr %l24
  %t75 = icmp sle i64 %t74, 1152921504606846975
  store i1 %t75, ptr %l26
  %t76 = load i1, ptr %l26
  br i1 %t76, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
bb13:
  %t77 = load i64, ptr %l24
  %t78 = mul i64 %t77, 8
  %t79 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l27
  %t82 = load { i64, ptr }, ptr %l27
  %t83 = extractvalue { i64, ptr } %t82, 0
  %t84 = extractvalue { i64, ptr } %t82, 1
  %t85 = mul i64 %t83, 8
  %t86 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l28
  %t89 = load { i64, ptr }, ptr %l28
  store { i64, ptr } %t89, ptr %l6
  %t90 = load i64, ptr %l0
  store i64 %t90, ptr %l29
  %t91 = load i64, ptr %l29
  %t92 = icmp sge i64 %t91, 0
  store i1 %t92, ptr %l30
  %t93 = load i1, ptr %l30
  br i1 %t93, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
bb15:
  %t94 = load i64, ptr %l29
  %t95 = icmp sle i64 %t94, 1152921504606846975
  store i1 %t95, ptr %l31
  %t96 = load i1, ptr %l31
  br i1 %t96, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb17:
  %t97 = load i64, ptr %l29
  %t98 = mul i64 %t97, 8
  %t99 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l32
  %t102 = load { i64, ptr }, ptr %l32
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 8
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l33
  %t109 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t109, ptr %l7
  %t110 = load ptr, ptr @__olang_prog_scope
  %t111 = call %"std/prelude/list:List<compiler/typed:Scope>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e(ptr %t110)
  store %"std/prelude/list:List<compiler/typed:Scope>" %t111, ptr %l34
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb19:
  %t112 = load %"std/prelude/list:List<compiler/typed:Scope>", ptr %l34
  store %"std/prelude/list:List<compiler/typed:Scope>" %t112, ptr %l8
  %t113 = load { i64, ptr }, ptr %l3
  %t114 = insertvalue %"compiler/typed:Plan" undef, { i64, ptr } %t113, 0
  %t115 = load { i64, ptr }, ptr %l4
  %t116 = insertvalue %"compiler/typed:Plan" %t114, { i64, ptr } %t115, 1
  %t117 = load { i64, ptr }, ptr %l5
  %t118 = insertvalue %"compiler/typed:Plan" %t116, { i64, ptr } %t117, 2
  %t119 = load { i64, ptr }, ptr %l6
  %t120 = insertvalue %"compiler/typed:Plan" %t118, { i64, ptr } %t119, 3
  %t121 = load { i64, ptr }, ptr %l7
  %t122 = insertvalue %"compiler/typed:Plan" %t120, { i64, ptr } %t121, 4
  %t123 = load %"std/prelude/list:List<compiler/typed:Scope>", ptr %l8
  %t124 = insertvalue %"compiler/typed:Plan" %t122, %"std/prelude/list:List<compiler/typed:Scope>" %t123, 5
  store %"compiler/typed:Plan" %t124, ptr %l35
  call void @__olang_scope_close(ptr %s0)
  %t125 = load %"compiler/typed:Plan", ptr %l35
  store %"compiler/typed:Plan" %t125, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Plan", ptr %rv
  ret %"compiler/typed:Plan" %rr
}

define dso_local %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"compiler/typed:Promote"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Promote"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l4
  store ptr %t2, ptr %l2
  %t3 = load i32, ptr %l1
  store i32 %t3, ptr %l5
  %t4 = load i32, ptr %l5
  store i32 %t4, ptr %l3
  %t5 = load ptr, ptr %l2
  %t6 = insertvalue %"compiler/typed:Promote" undef, ptr %t5, 0
  %t7 = load i32, ptr %l3
  %t8 = insertvalue %"compiler/typed:Promote" %t6, i32 %t7, 1
  store %"compiler/typed:Promote" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/typed:Promote", ptr %l6
  store %"compiler/typed:Promote" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Promote", ptr %rv
  ret %"compiler/typed:Promote" %rr
}

define dso_local %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Seq"
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t2, ptr %l2
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l5
  %t4 = load ptr, ptr %l5
  store ptr %t4, ptr %l3
  %t5 = load { i64, ptr }, ptr %l2
  %t6 = insertvalue %"compiler/typed:Seq" undef, { i64, ptr } %t5, 0
  %t7 = load ptr, ptr %l3
  %t8 = insertvalue %"compiler/typed:Seq" %t6, ptr %t7, 1
  store %"compiler/typed:Seq" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/typed:Seq", ptr %l6
  store %"compiler/typed:Seq" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Seq", ptr %rv
  ret %"compiler/typed:Seq" %rr
}

define dso_local %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/typed:SiteInfo"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:SiteInfo"
  store i32 %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l4
  %t2 = load i32, ptr %l4
  store i32 %t2, ptr %l2
  %t3 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t3, ptr %l5
  %t4 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t4, ptr %l3
  %t5 = load i32, ptr %l2
  %t6 = insertvalue %"compiler/typed:SiteInfo" undef, i32 %t5, 0
  %t7 = load %"compiler/source:Span", ptr %l3
  %t8 = insertvalue %"compiler/typed:SiteInfo" %t6, %"compiler/source:Span" %t7, 1
  store %"compiler/typed:SiteInfo" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/typed:SiteInfo", ptr %l6
  store %"compiler/typed:SiteInfo" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:SiteInfo", ptr %rv
  ret %"compiler/typed:SiteInfo" %rr
}

define dso_local %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i1
  %l15 = alloca %"compiler/typed:Slice"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Slice"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l10
  %t2 = load ptr, ptr %l10
  store ptr %t2, ptr %l5
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l11
  %t4 = load ptr, ptr %l11
  store ptr %t4, ptr %l6
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l12
  %t6 = load ptr, ptr %l12
  store ptr %t6, ptr %l7
  %t7 = load i32, ptr %l3
  store i32 %t7, ptr %l13
  %t8 = load i32, ptr %l13
  store i32 %t8, ptr %l8
  %t9 = load i1, ptr %l4
  store i1 %t9, ptr %l14
  %t10 = load i1, ptr %l14
  store i1 %t10, ptr %l9
  %t11 = load ptr, ptr %l5
  %t12 = insertvalue %"compiler/typed:Slice" undef, ptr %t11, 0
  %t13 = load ptr, ptr %l6
  %t14 = insertvalue %"compiler/typed:Slice" %t12, ptr %t13, 1
  %t15 = load ptr, ptr %l7
  %t16 = insertvalue %"compiler/typed:Slice" %t14, ptr %t15, 2
  %t17 = load i32, ptr %l8
  %t18 = insertvalue %"compiler/typed:Slice" %t16, i32 %t17, 3
  %t19 = load i1, ptr %l9
  %t20 = insertvalue %"compiler/typed:Slice" %t18, i1 %t19, 4
  store %"compiler/typed:Slice" %t20, ptr %l15
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/typed:Slice", ptr %l15
  store %"compiler/typed:Slice" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Slice", ptr %rv
  ret %"compiler/typed:Slice" %rr
}

define dso_local %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca %"compiler/typed:Spawn"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Spawn"
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l8
  %t2 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t2, ptr %l4
  %t3 = load ptr, ptr %l1
  store ptr %t3, ptr %l9
  %t4 = load ptr, ptr %l9
  store ptr %t4, ptr %l5
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l10
  %t6 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t6, ptr %l6
  %t7 = load i32, ptr %l3
  store i32 %t7, ptr %l11
  %t8 = load i32, ptr %l11
  store i32 %t8, ptr %l7
  %t9 = load { i64, ptr }, ptr %l4
  %t10 = insertvalue %"compiler/typed:Spawn" undef, { i64, ptr } %t9, 0
  %t11 = load ptr, ptr %l5
  %t12 = insertvalue %"compiler/typed:Spawn" %t10, ptr %t11, 1
  %t13 = load { i64, ptr }, ptr %l6
  %t14 = insertvalue %"compiler/typed:Spawn" %t12, { i64, ptr } %t13, 2
  %t15 = load i32, ptr %l7
  %t16 = insertvalue %"compiler/typed:Spawn" %t14, i32 %t15, 3
  store %"compiler/typed:Spawn" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/typed:Spawn", ptr %l12
  store %"compiler/typed:Spawn" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Spawn", ptr %rv
  ret %"compiler/typed:Spawn" %rr
}

define dso_local %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca %"compiler/typed:TaskClause"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:TaskClause"
  store %"compiler/source:Span" %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t1, ptr %l8
  %t2 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t2, ptr %l4
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l9
  %t4 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t4, ptr %l5
  %t5 = load i1, ptr %l2
  store i1 %t5, ptr %l10
  %t6 = load i1, ptr %l10
  store i1 %t6, ptr %l6
  %t7 = load ptr, ptr %l3
  store ptr %t7, ptr %l11
  %t8 = load ptr, ptr %l11
  store ptr %t8, ptr %l7
  %t9 = load %"compiler/source:Span", ptr %l4
  %t10 = insertvalue %"compiler/typed:TaskClause" undef, %"compiler/source:Span" %t9, 0
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/typed:TaskClause" %t10, { i64, ptr } %t11, 1
  %t13 = load i1, ptr %l6
  %t14 = insertvalue %"compiler/typed:TaskClause" %t12, i1 %t13, 2
  %t15 = load ptr, ptr %l7
  %t16 = insertvalue %"compiler/typed:TaskClause" %t14, ptr %t15, 3
  store %"compiler/typed:TaskClause" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/typed:TaskClause", ptr %l12
  store %"compiler/typed:TaskClause" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:TaskClause", ptr %rv
  ret %"compiler/typed:TaskClause" %rr
}

define dso_local %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca %"compiler/typed:Text"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Text"
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t2, ptr %l2
  %t3 = load i32, ptr %l1
  store i32 %t3, ptr %l5
  %t4 = load i32, ptr %l5
  store i32 %t4, ptr %l3
  %t5 = load { i64, ptr }, ptr %l2
  %t6 = insertvalue %"compiler/typed:Text" undef, { i64, ptr } %t5, 0
  %t7 = load i32, ptr %l3
  %t8 = insertvalue %"compiler/typed:Text" %t6, i32 %t7, 1
  store %"compiler/typed:Text" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/typed:Text", ptr %l6
  store %"compiler/typed:Text" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Text", ptr %rv
  ret %"compiler/typed:Text" %rr
}

define dso_local %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/typed:Try"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l8
  %t2 = load ptr, ptr %l8
  store ptr %t2, ptr %l4
  %t3 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t3, ptr %l9
  %t4 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t4, ptr %l5
  %t5 = load i1, ptr %l2
  store i1 %t5, ptr %l10
  %t6 = load i1, ptr %l10
  store i1 %t6, ptr %l6
  %t7 = load i1, ptr %l3
  store i1 %t7, ptr %l11
  %t8 = load i1, ptr %l11
  store i1 %t8, ptr %l7
  %t9 = load ptr, ptr %l4
  %t10 = insertvalue %"compiler/typed:Try" undef, ptr %t9, 0
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/typed:Try" %t10, { i64, ptr } %t11, 1
  %t13 = load i1, ptr %l6
  %t14 = insertvalue %"compiler/typed:Try" %t12, i1 %t13, 2
  %t15 = load i1, ptr %l7
  %t16 = insertvalue %"compiler/typed:Try" %t14, i1 %t15, 3
  store %"compiler/typed:Try" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/typed:Try", ptr %l12
  store %"compiler/typed:Try" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Try", ptr %rv
  ret %"compiler/typed:Try" %rr
}

declare void @__olang_scope_close(ptr)
declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [52 x i8] c"compiler/typed.olang:551: reached unreachable code\0A\00"
@.c1 = private unnamed_addr constant [52 x i8] c"compiler/typed.olang:640: reached unreachable code\0A\00"
@.c2 = private unnamed_addr constant [52 x i8] c"compiler/typed.olang:650: reached unreachable code\0A\00"
@.c3 = private unnamed_addr constant [52 x i8] c"compiler/typed.olang:667: reached unreachable code\0A\00"
@.c4 = private unnamed_addr constant [52 x i8] c"compiler/typed.olang:660: reached unreachable code\0A\00"
@.c5 = private unnamed_addr constant [52 x i8] c"compiler/typed.olang:674: reached unreachable code\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List<compiler/typed:LocalId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/typed:LocalId>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/typed:LocalId>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/typed:LocalId>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/typed:LocalId>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/typed:LocalId>", ptr %l0
  store %"std/prelude/list:List<compiler/typed:LocalId>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/typed:LocalId>", ptr %rv
  ret %"std/prelude/list:List<compiler/typed:LocalId>" %rr
}

define linkonce_odr %"std/prelude/list:List<compiler/typed:ScopeVar>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/typed:ScopeVar>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/typed:ScopeVar>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/typed:ScopeVar>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/typed:ScopeVar>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/typed:ScopeVar>", ptr %l0
  store %"std/prelude/list:List<compiler/typed:ScopeVar>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/typed:ScopeVar>", ptr %rv
  ret %"std/prelude/list:List<compiler/typed:ScopeVar>" %rr
}

define linkonce_odr %"std/prelude/list:List<compiler/typed:Local>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/typed:Local>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/typed:Local>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/typed:Local>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/typed:Local>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/typed:Local>", ptr %l0
  store %"std/prelude/list:List<compiler/typed:Local>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/typed:Local>", ptr %rv
  ret %"std/prelude/list:List<compiler/typed:Local>" %rr
}

define linkonce_odr %"std/prelude/list:List<compiler/typed:BlockInfo>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/typed:BlockInfo>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/typed:BlockInfo>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/typed:BlockInfo>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/typed:BlockInfo>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/typed:BlockInfo>", ptr %l0
  store %"std/prelude/list:List<compiler/typed:BlockInfo>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/typed:BlockInfo>", ptr %rv
  ret %"std/prelude/list:List<compiler/typed:BlockInfo>" %rr
}

define linkonce_odr %"std/prelude/list:List<compiler/typed:SiteInfo>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/typed:SiteInfo>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/typed:SiteInfo>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/typed:SiteInfo>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/typed:SiteInfo>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/typed:SiteInfo>", ptr %l0
  store %"std/prelude/list:List<compiler/typed:SiteInfo>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/typed:SiteInfo>", ptr %rv
  ret %"std/prelude/list:List<compiler/typed:SiteInfo>" %rr
}

@.c6 = private unnamed_addr constant [53 x i8] c"compiler/typed.olang:613: array length out of range\0A\00"
declare ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare ptr @__olang_scope_alloc(ptr, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.c7 = private unnamed_addr constant [53 x i8] c"compiler/typed.olang:614: array length out of range\0A\00"
@.c8 = private unnamed_addr constant [53 x i8] c"compiler/typed.olang:615: array length out of range\0A\00"
@.c9 = private unnamed_addr constant [53 x i8] c"compiler/typed.olang:616: array length out of range\0A\00"
@.c10 = private unnamed_addr constant [53 x i8] c"compiler/typed.olang:617: array length out of range\0A\00"
define linkonce_odr %"std/prelude/list:List<compiler/typed:Scope>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/typed:Scope>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/typed:Scope>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/typed:Scope>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/typed:Scope>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/typed:Scope>", ptr %l0
  store %"std/prelude/list:List<compiler/typed:Scope>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/typed:Scope>", ptr %rv
  ret %"std/prelude/list:List<compiler/typed:Scope>" %rr
}

declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2eLe_Heec836b2f97bed3c10ee7e3cac736d9d(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eP_Hc92177ba48b21a9f8d26c1a49cf2119c(ptr %v0, ptr %a0, %"compiler/typed:BlockInfo" %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eL_H5b8a0bc03aecb48440b685dbbc0b269c(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ePush_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ePu_H5cdcfe4ca3473fd9feeaed4f4a6d3f84(ptr %v0, ptr %a0, %"compiler/typed:SiteInfo" %a1)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = external global i64
@G_2ecompiler_2ftypes_2eClosingVar = external global i64
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ePu_Hdbf2db28b3dbd7714059bb41361f5f89(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
@G_2ecompiler_2ftypes_2eResultVar = external global i64
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eLen_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2eAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/list:List<compiler/typed:LocalId>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/typed:ScopeVar>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/typed:Local>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/typed:BlockInfo>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/typed:SiteInfo>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aSiteInfo_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/typed:Scope>" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %v0)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
