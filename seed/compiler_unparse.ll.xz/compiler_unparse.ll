; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/unparse:writer" = type { ptr, { i64, ptr }, ptr, %"std/prelude/text:StringBuilder", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
@G_2ecompiler_2funparse_2eMaxIndent = constant <{ [8 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00" }>, align 8
define dso_local { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/unparse:writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca %"compiler/unparse:writer"
  %l20 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %a1, { i64, ptr } %a2, ptr %a3)
  store %"compiler/unparse:writer" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/unparse:writer", ptr %l12
  store %"compiler/unparse:writer" %t8, ptr %l4
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %s0, ptr %v0, ptr %l4, ptr %t29)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l6, !tbaa !24
  br label %bb2
bb8:
  %t38 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 5
  %t40 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %v4, ptr %t38)
  store { i64, ptr } %t40, ptr %l28
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l30, !tbaa !24
  %t45 = mul i64 %t44, 8
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l31, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l30, !tbaa !24
  %t54 = mul i64 %t53, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2funparse_2eMaxIndent_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 64, ptr @G_2ecompiler_2funparse_2eMaxIndent, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2funparse_2eUnparse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/unparse:writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca %"compiler/unparse:writer"
  %l20 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %a1, { i64, ptr } %a2, ptr %a3)
  store %"compiler/unparse:writer" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/unparse:writer", ptr %l12
  store %"compiler/unparse:writer" %t8, ptr %l4
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %s0, ptr %v0, ptr %l4, ptr %t29)
  br label %bb6
bb6:
  %t34 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t34, i8 10)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l6, !tbaa !24
  br label %bb2
bb9:
  %t40 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 3
  %t42 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %t40)
  store { i64, ptr } %t42, ptr %l29
  br label %bb10
bb10:
  %t43 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load i64, ptr %l31, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l12 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l35 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t7, { i64, ptr } { i64 3, ptr @.d0 })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 1, ptr @.d1 })
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l12, !tbaa !29
  %t12 = load ptr, ptr %l12, !tbaa !29
  %t13 = getelementptr %"compiler/unparse:writer", ptr %t12, i32 0, i32 4
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = add i64 %t14, 1
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = getelementptr %"compiler/unparse:writer", ptr %t18, i32 0, i32 4
  store i64 %t16, ptr %t19, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t20, i32 0, i32 6
  %t23 = load i1, ptr %t22, !tbaa !21
  store i1 %t23, ptr %l2, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/unparse:writer", ptr %t25, i32 0, i32 6
  store i1 false, ptr %t27, !tbaa !21
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t28, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l25, !tbaa !27
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l6, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t50)
  br label %bb10
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l4, !tbaa !24
  br label %bb6
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i1, ptr %l2, !tbaa !21
  %t64 = getelementptr %"compiler/unparse:writer", ptr %t60, i32 0, i32 6
  store i1 %t61, ptr %t64, !tbaa !21
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l35, !tbaa !29
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = getelementptr %"compiler/unparse:writer", ptr %t66, i32 0, i32 4
  %t68 = load i64, ptr %t67, !tbaa !24
  %t70 = sub i64 %t68, 1
  %t72 = load ptr, ptr %l35, !tbaa !29
  %t73 = getelementptr %"compiler/unparse:writer", ptr %t72, i32 0, i32 4
  store i64 %t70, ptr %t73, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t74)
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t76, { i64, ptr } { i64 1, ptr @.d2 })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l31 = alloca i1
  %l33 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr ptr, ptr %t9, i64 0
  %t11 = load ptr, ptr %t10, !tbaa !39
  %t13 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t11)
  store %"compiler/source:Span" %t13, ptr %l8
  br label %bb3
bb2:
  br label %bb24
bb3:
  %t14 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t19 = sub i64 %t17, 1
  store i64 %t19, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/unparse:writer", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l16, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i8, ptr %t32, i64 %t29
  %t34 = load i8, ptr %t33, !tbaa !32
  %t36 = icmp eq i8 %t34, 32
  br i1 %t36, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/unparse:writer", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp eq i8 %t47, 9
  store i1 %t49, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t51 = load i1, ptr %l20, !tbaa !21
  store i1 %t51, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t52 = load i1, ptr %l14, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = sub i64 %t55, 1
  store i64 %t57, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %bb4
bb15:
  %t59 = load i64, ptr %l2, !tbaa !24
  %t61 = icmp sge i64 %t59, 0
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/unparse:writer", ptr %t63, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l33, !tbaa !27
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 58
  store i1 %t74, ptr %l31, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t76 = load i1, ptr %l31, !tbaa !21
  br i1 %t76, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t77, { i64, ptr } { i64 2, ptr @.d3 })
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t80, ptr %l39, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr ptr, ptr %t82, i64 0
  %t84 = load ptr, ptr %t83, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t79, ptr %t84)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t87, { i64, ptr } { i64 1, ptr @.d4 })
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t89, { i64, ptr } %t90)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/unparse:writer", ptr %t10, i32 0, i32 2
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Branch", ptr %t14, i32 0, i32 2
  %t17 = load i64, ptr %t16, !tbaa !24
  %t20 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t13, i64 %t17)
  store i1 %t20, ptr %l11
  br label %bb3
bb3:
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l6, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/unparse:writer", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l13, !tbaa !27
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Branch", ptr %t27, i32 0, i32 0
  %t30 = getelementptr %"compiler/source:Span", ptr %t29, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t35 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t33
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = icmp ne i8 %t38, 58
  br i1 %t40, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t42, { i64, ptr } { i64 1, ptr @.d5 })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Branch", ptr %t45, i32 0, i32 0
  %t48 = load %"compiler/source:Span", ptr %t47
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t44, %"compiler/source:Span" %t48)
  br label %bb11
bb11:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/unparse:writer", ptr %t51, i32 0, i32 5
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Branch", ptr %t54, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t53, %"compiler/source:Span" %t57)
  br label %bb12
bb12:
  br label %ret
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Branch", ptr %t61, i32 0, i32 1
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t60, { i64, ptr } %t64)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l7 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 5
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 4, ptr @.d6 })
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Case", ptr %t13, i32 0, i32 5
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6d411809e3c45284_6ddb613e25dacce8)
  unreachable
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Case", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t24, ptr %t23)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t26, { i64, ptr } { i64 1, ptr @.d7 })
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Case", ptr %t29, i32 0, i32 4
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %t32)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t23, { i64, ptr } { i64 6, ptr @.d8 })
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Catch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l10, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l34, !tbaa !29
  %t55 = icmp sgt i64 %t42, 0
  br i1 %t55, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 2, ptr @.d9 }, ptr %l37, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 1, ptr @.d10 }, ptr %l37, !tbaa !27
  br label %bb12
bb12:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t57, { i64, ptr } %t58)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t59, ptr %t60)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l7, !tbaa !24
  br label %bb6
bb16:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Catch", ptr %t67, i32 0, i32 4
  %t70 = load i1, ptr %t69, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t72, { i64, ptr } { i64 1, ptr @.d11 })
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Catch", ptr %t75, i32 0, i32 2
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t74, { i64, ptr } %t78)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Catch", ptr %t81, i32 0, i32 3
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t88 = icmp sgt i64 %t86, 0
  br i1 %t88, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t90 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t90, { i64, ptr } { i64 9, ptr @.d12 })
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Catch", ptr %t93, i32 0, i32 3
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t92, { i64, ptr } %t96)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l3, !tbaa !24
  br label %bb1
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l82 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb80
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t21 = load ptr, ptr %l25, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l25, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l26, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { ptr }, ptr %t31, i32 0, i32 0
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t35, { i64, ptr } { i64 10, ptr @.d13 })
  br label %bb13
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Func", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t37, i32 %t41)
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t44, ptr %t48)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb80
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l38, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 2
  store i1 %t58, ptr %l39, !tbaa !21
  br label %bb18
bb18:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", ptr }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l4, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  br label %bb22
bb22:
  br label %bb80
bb23:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t71 = load ptr, ptr %l46, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t74 = load ptr, ptr %l46, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 3
  store i1 %t77, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  %t78 = load i1, ptr %l47, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  br label %bb29
bb29:
  br label %bb80
bb30:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t90 = load ptr, ptr %l54, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb31, label %bb32
bb31:
  %t93 = load ptr, ptr %l54, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 4
  store i1 %t96, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l55, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t100, i32 0, i32 1
  %t102 = load i32, ptr %t101
  store i32 %t102, ptr %l6, !tbaa !23
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t106, i32 0, i32 2
  %t108 = load %"compiler/source:Span", ptr %t107
  store %"compiler/source:Span" %t108, ptr %l7
  br label %bb35
bb34:
  br label %bb43
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t110, { i64, ptr } { i64 7, ptr @.d14 })
  br label %bb36
bb36:
  %t112 = load i32, ptr %l6, !tbaa !23
  %t114 = icmp ne i32 %t112, 0
  br i1 %t114, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t116, i32 %t117)
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t120, { i64, ptr } { i64 1, ptr @.d15 })
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t122, %"compiler/source:Span" %t123)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb80
bb43:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb44, label %bb45
bb44:
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = load i64, ptr %t130
  %t133 = icmp eq i64 %t131, 5
  store i1 %t133, ptr %l71, !tbaa !21
  br label %bb45
bb45:
  %t134 = load i1, ptr %l71, !tbaa !21
  br i1 %t134, label %bb46, label %bb47
bb46:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, { i64, ptr } }, ptr %t137, i32 0, i32 1
  %t139 = load i32, ptr %t138
  store i32 %t139, ptr %l8, !tbaa !23
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [4 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, { i64, ptr } }, ptr %t143, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %t144
  store { i64, ptr } %t145, ptr %l9, !tbaa !27
  br label %bb48
bb47:
  br label %bb62
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t147, { i64, ptr } { i64 6, ptr @.d16 })
  br label %bb49
bb49:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t149, i32 %t150)
  br label %bb50
bb50:
  %t153 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t153, { i64, ptr } { i64 2, ptr @.d17 })
  br label %bb51
bb51:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l82, !tbaa !29
  %t156 = load ptr, ptr %l82, !tbaa !29
  %t157 = getelementptr %"compiler/unparse:writer", ptr %t156, i32 0, i32 4
  %t158 = load i64, ptr %t157, !tbaa !24
  %t160 = add i64 %t158, 1
  %t162 = load ptr, ptr %l82, !tbaa !29
  %t163 = getelementptr %"compiler/unparse:writer", ptr %t162, i32 0, i32 4
  store i64 %t160, ptr %t163, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t164, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  store i64 %t168, ptr %l12, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t170 = load i64, ptr %l11, !tbaa !24
  %t171 = load i64, ptr %l12, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb54:
  br label %bb55
bb55:
  %t178 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t178, ptr %l92, !tbaa !27
  %t179 = load i64, ptr %l11, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr i32, ptr %t182, i64 %t179
  %t184 = load i32, ptr %t183, !tbaa !33
  store i32 %t184, ptr %l13, !tbaa !23
  %t186 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t186)
  br label %bb56
bb56:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t188, i32 %t189)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb58:
  %t192 = load i64, ptr %l11, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l11, !tbaa !24
  br label %bb52
bb59:
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l100, !tbaa !29
  %t197 = load ptr, ptr %l100, !tbaa !29
  %t198 = getelementptr %"compiler/unparse:writer", ptr %t197, i32 0, i32 4
  %t199 = load i64, ptr %t198, !tbaa !24
  %t201 = sub i64 %t199, 1
  %t203 = load ptr, ptr %l100, !tbaa !29
  %t204 = getelementptr %"compiler/unparse:writer", ptr %t203, i32 0, i32 4
  store i64 %t201, ptr %t204, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t205)
  br label %bb60
bb60:
  %t207 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t207, { i64, ptr } { i64 1, ptr @.d18 })
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  br label %bb80
bb62:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t210 = load ptr, ptr %l105, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb63, label %bb64
bb63:
  %t213 = load ptr, ptr %l105, !tbaa !29
  %t214 = load i64, ptr %t213
  %t216 = icmp eq i64 %t214, 6
  store i1 %t216, ptr %l106, !tbaa !21
  br label %bb64
bb64:
  %t217 = load i1, ptr %l106, !tbaa !21
  br i1 %t217, label %bb65, label %bb66
bb65:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t220, i32 0, i32 1
  %t222 = load %"compiler/source:Span", ptr %t221
  store %"compiler/source:Span" %t222, ptr %l14
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t226, i32 0, i32 2
  %t228 = load { i64, ptr }, ptr %t227
  store { i64, ptr } %t228, ptr %l15, !tbaa !27
  br label %bb67
bb66:
  br label %bb72
bb67:
  store %olang.scope zeroinitializer, ptr %s11
  %t230 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t230, { i64, ptr } { i64 5, ptr @.d19 })
  br label %bb68
bb68:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l14
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t232, %"compiler/source:Span" %t233)
  br label %bb69
bb69:
  %t236 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t236, { i64, ptr } { i64 1, ptr @.d20 })
  br label %bb70
bb70:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t238, { i64, ptr } %t239)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb72:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t243 = load ptr, ptr %l119, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb73, label %bb74
bb73:
  %t246 = load ptr, ptr %l119, !tbaa !29
  %t247 = load i64, ptr %t246
  %t249 = icmp eq i64 %t247, 7
  store i1 %t249, ptr %l120, !tbaa !21
  br label %bb74
bb74:
  %t250 = load i1, ptr %l120, !tbaa !21
  br i1 %t250, label %bb75, label %bb76
bb75:
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l16, !tbaa !29
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  br label %bb78
bb78:
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_7f8607ca82c86e8f_41d7f7ff4057cd03)
  unreachable
bb80:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t8, { i64, ptr } { i64 2, ptr @.d21 })
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Sig", ptr %t10, i32 0, i32 3
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb7:
  br label %bb8
bb8:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr ptr, ptr %t33, i64 %t30
  %t35 = load ptr, ptr %t34, !tbaa !39
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l23, !tbaa !29
  %t40 = icmp sgt i64 %t27, 0
  br i1 %t40, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 2, ptr @.d22 }, ptr %l26, !tbaa !27
  br label %bb11
bb10:
  store { i64, ptr } { i64 1, ptr @.d23 }, ptr %l26, !tbaa !27
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l23, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t42, { i64, ptr } %t43)
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb5
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l102 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l110 = alloca i1
  %l113 = alloca i1
  %l115 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %l129 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l133 = alloca i1
  %l145 = alloca ptr
  %l147 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca i1
  %l164 = alloca ptr
  %l165 = alloca i1
  %l179 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l187 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l198 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i1
  %l227 = alloca ptr
  %l229 = alloca { i64, ptr }
  %l232 = alloca ptr
  %l233 = alloca i1
  %l244 = alloca ptr
  %l246 = alloca { i64, ptr }
  %l249 = alloca ptr
  %l250 = alloca i1
  %l262 = alloca ptr
  %l263 = alloca i1
  %l276 = alloca ptr
  %l277 = alloca i1
  %l295 = alloca ptr
  %l296 = alloca i1
  %l309 = alloca ptr
  %l310 = alloca i1
  %l322 = alloca ptr
  %l323 = alloca i1
  %l336 = alloca ptr
  %l337 = alloca i1
  %l361 = alloca ptr
  %l362 = alloca i1
  %l369 = alloca ptr
  %l377 = alloca ptr
  %l378 = alloca i1
  %l387 = alloca ptr
  %l388 = alloca i1
  %l393 = alloca ptr
  %l423 = alloca ptr
  %l430 = alloca ptr
  %l431 = alloca i1
  %l444 = alloca { i64, ptr }
  %l454 = alloca ptr
  %l455 = alloca i1
  %l464 = alloca ptr
  %l466 = alloca { i64, ptr }
  %l471 = alloca ptr
  %l472 = alloca i1
  %l490 = alloca ptr
  %l491 = alloca i1
  %l498 = alloca ptr
  %l499 = alloca i1
  %l507 = alloca ptr
  %l508 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t2 = load ptr, ptr %l63, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l63, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l64, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l64, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t16, i32 %t17)
  br label %bb6
bb6:
  br label %bb324
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t21 = load ptr, ptr %l71, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l71, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l72, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l72, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32 }, ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/source:Span", ptr %t32
  store %"compiler/source:Span" %t33, ptr %l3
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t35, %"compiler/source:Span" %t36)
  br label %bb13
bb13:
  br label %bb324
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t40 = load ptr, ptr %l79, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l79, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l80, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l80, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb23
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t54, { i64, ptr } { i64 1, ptr @.d24 })
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/unparse:writer", ptr %t56, i32 0, i32 6
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l5, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/unparse:writer", ptr %t61, i32 0, i32 6
  store i1 false, ptr %t63, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  br label %bb21
bb21:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i1, ptr %l5, !tbaa !21
  %t72 = getelementptr %"compiler/unparse:writer", ptr %t68, i32 0, i32 6
  store i1 %t69, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t73, { i64, ptr } { i64 1, ptr @.d25 })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb324
bb23:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t76 = load ptr, ptr %l94, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l94, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 3
  store i1 %t82, ptr %l95, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l95, !tbaa !21
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l6
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb47
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l102, !tbaa !29
  %t97 = load i32, ptr %l6
  %t99 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t97)
  store { i64, ptr } %t99, ptr %l104
  br label %bb29
bb29:
  %t100 = load ptr, ptr %l102, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l104, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t100, { i64, ptr } %t101)
  br label %bb30
bb30:
  %t102 = load i32, ptr %l6
  %t104 = trunc i64 48 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t107, { i64, ptr } { i64 1, ptr @.d26 })
  br label %bb33
bb32:
  %t109 = load i32, ptr %l6
  %t111 = trunc i64 50 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb34, label %bb35
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb34:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb36
bb35:
  %t114 = load i32, ptr %l6
  %t116 = trunc i64 72 to i32
  %t117 = icmp eq i32 %t114, %t116
  store i1 %t117, ptr %l110, !tbaa !21
  br label %bb36
bb36:
  %t119 = load i1, ptr %l110, !tbaa !21
  br i1 %t119, label %bb37, label %bb38
bb37:
  %t120 = load ptr, ptr %l7, !tbaa !29
  %t122 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v1, ptr %t120)
  store i1 %t122, ptr %l115
  br label %bb39
bb38:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb40
bb39:
  %t123 = load i1, ptr %l115, !tbaa !21
  store i1 %t123, ptr %l113, !tbaa !21
  br label %bb40
bb40:
  %t124 = load i1, ptr %l113, !tbaa !21
  br i1 %t124, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t125 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t125, { i64, ptr } { i64 1, ptr @.d27 })
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t127, ptr %t128)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s4)
  br label %bb324
bb47:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t132 = load ptr, ptr %l119, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb48, label %bb49
bb48:
  %t135 = load ptr, ptr %l119, !tbaa !29
  %t136 = load i64, ptr %t135
  %t138 = icmp eq i64 %t136, 4
  store i1 %t138, ptr %l120, !tbaa !21
  br label %bb49
bb49:
  %t139 = load i1, ptr %l120, !tbaa !21
  br i1 %t139, label %bb50, label %bb51
bb50:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l8
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l9, !tbaa !29
  br label %bb52
bb51:
  br label %bb56
bb52:
  store %olang.scope zeroinitializer, ptr %s8
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t152, ptr %t153)
  br label %bb53
bb53:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l129, !tbaa !29
  %t157 = load i32, ptr %l8
  %t159 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t157)
  store { i64, ptr } %t159, ptr %l131
  br label %bb54
bb54:
  %t160 = load ptr, ptr %l129, !tbaa !29
  %t161 = load { i64, ptr }, ptr %l131, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t160, { i64, ptr } %t161)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  br label %bb324
bb56:
  %t162 = load ptr, ptr %l1, !tbaa !29
  store ptr %t162, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t163 = load ptr, ptr %l132, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb57, label %bb58
bb57:
  %t166 = load ptr, ptr %l132, !tbaa !29
  %t167 = load i64, ptr %t166
  %t169 = icmp eq i64 %t167, 5
  store i1 %t169, ptr %l133, !tbaa !21
  br label %bb58
bb58:
  %t170 = load i1, ptr %l133, !tbaa !21
  br i1 %t170, label %bb59, label %bb60
bb59:
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t173, i32 0, i32 1
  %t175 = load i32, ptr %t174
  store i32 %t175, ptr %l10
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t179, i32 0, i32 2
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l11, !tbaa !29
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t185, i32 0, i32 3
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l12, !tbaa !29
  br label %bb61
bb60:
  br label %bb68
bb61:
  store %olang.scope zeroinitializer, ptr %s9
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t189, ptr %t190)
  br label %bb62
bb62:
  %t193 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t193, { i64, ptr } { i64 1, ptr @.d28 })
  br label %bb63
bb63:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l145, !tbaa !29
  %t196 = load i32, ptr %l10
  %t198 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t196)
  store { i64, ptr } %t198, ptr %l147
  br label %bb64
bb64:
  %t199 = load ptr, ptr %l145, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l147, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t199, { i64, ptr } %t200)
  br label %bb65
bb65:
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t201, { i64, ptr } { i64 1, ptr @.d29 })
  br label %bb66
bb66:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t203, ptr %t204)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s9)
  br label %bb324
bb68:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %l151, !tbaa !29
  store i1 false, ptr %l152, !tbaa !21
  %t208 = load ptr, ptr %l151, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb69, label %bb70
bb69:
  %t211 = load ptr, ptr %l151, !tbaa !29
  %t212 = load i64, ptr %t211
  %t214 = icmp eq i64 %t212, 6
  store i1 %t214, ptr %l152, !tbaa !21
  br label %bb70
bb70:
  %t215 = load i1, ptr %l152, !tbaa !21
  br i1 %t215, label %bb71, label %bb72
bb71:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t218, i32 0, i32 1
  %t220 = load ptr, ptr %t219
  store ptr %t220, ptr %l13, !tbaa !29
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t224, i32 0, i32 2
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l14, !tbaa !29
  br label %bb73
bb72:
  br label %bb77
bb73:
  store %olang.scope zeroinitializer, ptr %s10
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t228, ptr %t229)
  br label %bb74
bb74:
  %t232 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t232, { i64, ptr } { i64 8, ptr @.d30 })
  br label %bb75
bb75:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t234, ptr %t235)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s10)
  br label %bb324
bb77:
  %t238 = load ptr, ptr %l1, !tbaa !29
  store ptr %t238, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t239 = load ptr, ptr %l164, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb78, label %bb79
bb78:
  %t242 = load ptr, ptr %l164, !tbaa !29
  %t243 = load i64, ptr %t242
  %t245 = icmp eq i64 %t243, 7
  store i1 %t245, ptr %l165, !tbaa !21
  br label %bb79
bb79:
  %t246 = load i1, ptr %l165, !tbaa !21
  br i1 %t246, label %bb80, label %bb81
bb80:
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t249 = getelementptr { i64, [5 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", ptr }, ptr %t249, i32 0, i32 1
  %t251 = load ptr, ptr %t250
  store ptr %t251, ptr %l15, !tbaa !29
  br label %bb82
bb81:
  br label %bb97
bb82:
  %t253 = load ptr, ptr %l15, !tbaa !29
  %t255 = getelementptr %"compiler/ast:Chain", ptr %t253, i32 0, i32 1
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  store { i64, ptr } %t256, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t258 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 0
  store i64 %t260, ptr %l18, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s13
  %t262 = load i64, ptr %l17, !tbaa !24
  %t263 = load i64, ptr %l18, !tbaa !24
  %t266 = icmp slt i64 %t262, %t263
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s13)
  br label %bb96
bb85:
  br label %bb86
bb86:
  %t270 = load i64, ptr %l17, !tbaa !24
  store i64 %t270, ptr %l19, !tbaa !24
  %t272 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t272, ptr %l179, !tbaa !27
  %t273 = load i64, ptr %l17, !tbaa !24
  %t275 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr ptr, ptr %t276, i64 %t273
  %t278 = load ptr, ptr %t277, !tbaa !39
  store ptr %t278, ptr %l20, !tbaa !29
  %t280 = load i64, ptr %l19, !tbaa !24
  %t282 = icmp sgt i64 %t280, 0
  br i1 %t282, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s14
  %t284 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t284, { i64, ptr } { i64 1, ptr @.d31 })
  br label %bb89
bb88:
  br label %bb93
bb89:
  %t286 = load ptr, ptr %l0, !tbaa !29
  store ptr %t286, ptr %l185, !tbaa !29
  %t287 = load ptr, ptr %l15, !tbaa !29
  %t289 = getelementptr %"compiler/ast:Chain", ptr %t287, i32 0, i32 0
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  store { i64, ptr } %t290, ptr %l187, !tbaa !27
  %t291 = load i64, ptr %l19, !tbaa !24
  %t293 = sub i64 %t291, 1
  %t295 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr i32, ptr %t296, i64 %t293
  %t298 = load i32, ptr %t297
  %t300 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s14, i32 %t298)
  store { i64, ptr } %t300, ptr %l191
  br label %bb90
bb90:
  %t301 = load ptr, ptr %l185, !tbaa !29
  %t302 = load { i64, ptr }, ptr %l191, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t301, { i64, ptr } %t302)
  br label %bb91
bb91:
  %t303 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t303, { i64, ptr } { i64 1, ptr @.d32 })
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s14)
  br label %bb93
bb93:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t305, ptr %t306)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s13)
  br label %bb95
bb95:
  %t309 = load i64, ptr %l17, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l17, !tbaa !24
  br label %bb83
bb96:
  br label %bb324
bb97:
  %t313 = load ptr, ptr %l1, !tbaa !29
  store ptr %t313, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t314 = load ptr, ptr %l197, !tbaa !29
  %t315 = icmp ne ptr %t314, null
  br i1 %t315, label %bb98, label %bb99
bb98:
  %t317 = load ptr, ptr %l197, !tbaa !29
  %t318 = load i64, ptr %t317
  %t320 = icmp eq i64 %t318, 8
  store i1 %t320, ptr %l198, !tbaa !21
  br label %bb99
bb99:
  %t321 = load i1, ptr %l198, !tbaa !21
  br i1 %t321, label %bb100, label %bb101
bb100:
  %t322 = load ptr, ptr %l1, !tbaa !29
  %t324 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 1
  %t325 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t324, i32 0, i32 1
  %t326 = load ptr, ptr %t325
  store ptr %t326, ptr %l21, !tbaa !29
  %t328 = load ptr, ptr %l1, !tbaa !29
  %t330 = getelementptr { i64, [5 x i64] }, ptr %t328, i32 0, i32 1
  %t331 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t330, i32 0, i32 2
  %t332 = load ptr, ptr %t331
  store ptr %t332, ptr %l22, !tbaa !29
  %t334 = load ptr, ptr %l1, !tbaa !29
  %t336 = getelementptr { i64, [5 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t336, i32 0, i32 3
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l23, !tbaa !29
  br label %bb102
bb101:
  br label %bb108
bb102:
  store %olang.scope zeroinitializer, ptr %s16
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t340, ptr %t341)
  br label %bb103
bb103:
  %t344 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t344, { i64, ptr } { i64 4, ptr @.d33 })
  br label %bb104
bb104:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t346, ptr %t347)
  br label %bb105
bb105:
  %t350 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t350, { i64, ptr } { i64 6, ptr @.d34 })
  br label %bb106
bb106:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t352, ptr %t353)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s16)
  br label %bb324
bb108:
  %t356 = load ptr, ptr %l1, !tbaa !29
  store ptr %t356, ptr %l215, !tbaa !29
  store i1 false, ptr %l216, !tbaa !21
  %t357 = load ptr, ptr %l215, !tbaa !29
  %t358 = icmp ne ptr %t357, null
  br i1 %t358, label %bb109, label %bb110
bb109:
  %t360 = load ptr, ptr %l215, !tbaa !29
  %t361 = load i64, ptr %t360
  %t363 = icmp eq i64 %t361, 9
  store i1 %t363, ptr %l216, !tbaa !21
  br label %bb110
bb110:
  %t364 = load i1, ptr %l216, !tbaa !21
  br i1 %t364, label %bb111, label %bb112
bb111:
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t367, i32 0, i32 1
  %t369 = load ptr, ptr %t368
  store ptr %t369, ptr %l24, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [5 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t373, i32 0, i32 2
  %t375 = load ptr, ptr %t374
  store ptr %t375, ptr %l25, !tbaa !29
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr { i64, [5 x i64] }, ptr %t377, i32 0, i32 1
  %t380 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t379, i32 0, i32 3
  %t381 = load i1, ptr %t380
  store i1 %t381, ptr %l26, !tbaa !21
  br label %bb113
bb112:
  br label %bb120
bb113:
  store %olang.scope zeroinitializer, ptr %s17
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t383, ptr %t384)
  br label %bb114
bb114:
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l227, !tbaa !29
  %t388 = load i1, ptr %l26, !tbaa !21
  br i1 %t388, label %bb115, label %bb116
bb115:
  store { i64, ptr } { i64 8, ptr @.d35 }, ptr %l229, !tbaa !27
  br label %bb117
bb116:
  store { i64, ptr } { i64 4, ptr @.d36 }, ptr %l229, !tbaa !27
  br label %bb117
bb117:
  %t390 = load ptr, ptr %l227, !tbaa !29
  %t391 = load { i64, ptr }, ptr %l229, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t390, { i64, ptr } %t391)
  br label %bb118
bb118:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t392, ptr %t393)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s17)
  br label %bb324
bb120:
  %t396 = load ptr, ptr %l1, !tbaa !29
  store ptr %t396, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t397 = load ptr, ptr %l232, !tbaa !29
  %t398 = icmp ne ptr %t397, null
  br i1 %t398, label %bb121, label %bb122
bb121:
  %t400 = load ptr, ptr %l232, !tbaa !29
  %t401 = load i64, ptr %t400
  %t403 = icmp eq i64 %t401, 10
  store i1 %t403, ptr %l233, !tbaa !21
  br label %bb122
bb122:
  %t404 = load i1, ptr %l233, !tbaa !21
  br i1 %t404, label %bb123, label %bb124
bb123:
  %t405 = load ptr, ptr %l1, !tbaa !29
  %t407 = getelementptr { i64, [5 x i64] }, ptr %t405, i32 0, i32 1
  %t408 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t407, i32 0, i32 1
  %t409 = load ptr, ptr %t408
  store ptr %t409, ptr %l27, !tbaa !29
  %t411 = load ptr, ptr %l1, !tbaa !29
  %t413 = getelementptr { i64, [5 x i64] }, ptr %t411, i32 0, i32 1
  %t414 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t413, i32 0, i32 2
  %t415 = load ptr, ptr %t414
  store ptr %t415, ptr %l28, !tbaa !29
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr { i64, [5 x i64] }, ptr %t417, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t419, i32 0, i32 3
  %t421 = load i1, ptr %t420
  store i1 %t421, ptr %l29, !tbaa !21
  br label %bb125
bb124:
  br label %bb132
bb125:
  store %olang.scope zeroinitializer, ptr %s18
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t423, ptr %t424)
  br label %bb126
bb126:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l244, !tbaa !29
  %t428 = load i1, ptr %l29, !tbaa !21
  br i1 %t428, label %bb127, label %bb128
bb127:
  store { i64, ptr } { i64 8, ptr @.d37 }, ptr %l246, !tbaa !27
  br label %bb129
bb128:
  store { i64, ptr } { i64 4, ptr @.d38 }, ptr %l246, !tbaa !27
  br label %bb129
bb129:
  %t430 = load ptr, ptr %l244, !tbaa !29
  %t431 = load { i64, ptr }, ptr %l246, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t430, { i64, ptr } %t431)
  br label %bb130
bb130:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t432, ptr %t433)
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s18)
  br label %bb324
bb132:
  %t436 = load ptr, ptr %l1, !tbaa !29
  store ptr %t436, ptr %l249, !tbaa !29
  store i1 false, ptr %l250, !tbaa !21
  %t437 = load ptr, ptr %l249, !tbaa !29
  %t438 = icmp ne ptr %t437, null
  br i1 %t438, label %bb133, label %bb134
bb133:
  %t440 = load ptr, ptr %l249, !tbaa !29
  %t441 = load i64, ptr %t440
  %t443 = icmp eq i64 %t441, 11
  store i1 %t443, ptr %l250, !tbaa !21
  br label %bb134
bb134:
  %t444 = load i1, ptr %l250, !tbaa !21
  br i1 %t444, label %bb135, label %bb136
bb135:
  %t445 = load ptr, ptr %l1, !tbaa !29
  %t447 = getelementptr { i64, [5 x i64] }, ptr %t445, i32 0, i32 1
  %t448 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t447, i32 0, i32 1
  %t449 = load ptr, ptr %t448
  store ptr %t449, ptr %l30, !tbaa !29
  %t451 = load ptr, ptr %l1, !tbaa !29
  %t453 = getelementptr { i64, [5 x i64] }, ptr %t451, i32 0, i32 1
  %t454 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t453, i32 0, i32 2
  %t455 = load ptr, ptr %t454
  store ptr %t455, ptr %l31, !tbaa !29
  br label %bb137
bb136:
  br label %bb141
bb137:
  store %olang.scope zeroinitializer, ptr %s19
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t457, ptr %t458)
  br label %bb138
bb138:
  %t461 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t461, { i64, ptr } { i64 4, ptr @.d39 })
  br label %bb139
bb139:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t463, ptr %t464)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s19)
  br label %bb324
bb141:
  %t467 = load ptr, ptr %l1, !tbaa !29
  store ptr %t467, ptr %l262, !tbaa !29
  store i1 false, ptr %l263, !tbaa !21
  %t468 = load ptr, ptr %l262, !tbaa !29
  %t469 = icmp ne ptr %t468, null
  br i1 %t469, label %bb142, label %bb143
bb142:
  %t471 = load ptr, ptr %l262, !tbaa !29
  %t472 = load i64, ptr %t471
  %t474 = icmp eq i64 %t472, 12
  store i1 %t474, ptr %l263, !tbaa !21
  br label %bb143
bb143:
  %t475 = load i1, ptr %l263, !tbaa !21
  br i1 %t475, label %bb144, label %bb145
bb144:
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr { i64, [5 x i64] }, ptr %t476, i32 0, i32 1
  %t479 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t478, i32 0, i32 1
  %t480 = load ptr, ptr %t479
  store ptr %t480, ptr %l32, !tbaa !29
  %t482 = load ptr, ptr %l1, !tbaa !29
  %t484 = getelementptr { i64, [5 x i64] }, ptr %t482, i32 0, i32 1
  %t485 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t484, i32 0, i32 2
  %t486 = load { i64, ptr }, ptr %t485
  store { i64, ptr } %t486, ptr %l33, !tbaa !27
  br label %bb146
bb145:
  br label %bb151
bb146:
  store %olang.scope zeroinitializer, ptr %s20
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t488, ptr %t489)
  br label %bb147
bb147:
  %t492 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t492, { i64, ptr } { i64 1, ptr @.d40 })
  br label %bb148
bb148:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t494, { i64, ptr } %t495)
  br label %bb149
bb149:
  %t498 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t498, { i64, ptr } { i64 1, ptr @.d41 })
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s20)
  br label %bb324
bb151:
  %t500 = load ptr, ptr %l1, !tbaa !29
  store ptr %t500, ptr %l276, !tbaa !29
  store i1 false, ptr %l277, !tbaa !21
  %t501 = load ptr, ptr %l276, !tbaa !29
  %t502 = icmp ne ptr %t501, null
  br i1 %t502, label %bb152, label %bb153
bb152:
  %t504 = load ptr, ptr %l276, !tbaa !29
  %t505 = load i64, ptr %t504
  %t507 = icmp eq i64 %t505, 13
  store i1 %t507, ptr %l277, !tbaa !21
  br label %bb153
bb153:
  %t508 = load i1, ptr %l277, !tbaa !21
  br i1 %t508, label %bb154, label %bb155
bb154:
  %t509 = load ptr, ptr %l1, !tbaa !29
  %t511 = getelementptr { i64, [5 x i64] }, ptr %t509, i32 0, i32 1
  %t512 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t511, i32 0, i32 1
  %t513 = load ptr, ptr %t512
  store ptr %t513, ptr %l34, !tbaa !29
  %t515 = load ptr, ptr %l1, !tbaa !29
  %t517 = getelementptr { i64, [5 x i64] }, ptr %t515, i32 0, i32 1
  %t518 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t517, i32 0, i32 2
  %t519 = load i32, ptr %t518
  store i32 %t519, ptr %l35, !tbaa !23
  %t521 = load ptr, ptr %l1, !tbaa !29
  %t523 = getelementptr { i64, [5 x i64] }, ptr %t521, i32 0, i32 1
  %t524 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t523, i32 0, i32 3
  %t525 = load { i64, ptr }, ptr %t524
  store { i64, ptr } %t525, ptr %l36, !tbaa !27
  br label %bb156
bb155:
  br label %bb163
bb156:
  store %olang.scope zeroinitializer, ptr %s21
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t527, ptr %t528)
  br label %bb157
bb157:
  %t531 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t531, { i64, ptr } { i64 1, ptr @.d42 })
  br label %bb158
bb158:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load i32, ptr %l35, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t533, i32 %t534)
  br label %bb159
bb159:
  %t537 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t537, { i64, ptr } { i64 1, ptr @.d43 })
  br label %bb160
bb160:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t539, { i64, ptr } %t540)
  br label %bb161
bb161:
  %t543 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t543, { i64, ptr } { i64 1, ptr @.d44 })
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s21)
  br label %bb324
bb163:
  %t545 = load ptr, ptr %l1, !tbaa !29
  store ptr %t545, ptr %l295, !tbaa !29
  store i1 false, ptr %l296, !tbaa !21
  %t546 = load ptr, ptr %l295, !tbaa !29
  %t547 = icmp ne ptr %t546, null
  br i1 %t547, label %bb164, label %bb165
bb164:
  %t549 = load ptr, ptr %l295, !tbaa !29
  %t550 = load i64, ptr %t549
  %t552 = icmp eq i64 %t550, 14
  store i1 %t552, ptr %l296, !tbaa !21
  br label %bb165
bb165:
  %t553 = load i1, ptr %l296, !tbaa !21
  br i1 %t553, label %bb166, label %bb167
bb166:
  %t554 = load ptr, ptr %l1, !tbaa !29
  %t556 = getelementptr { i64, [5 x i64] }, ptr %t554, i32 0, i32 1
  %t557 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t556, i32 0, i32 1
  %t558 = load ptr, ptr %t557
  store ptr %t558, ptr %l37, !tbaa !29
  %t560 = load ptr, ptr %l1, !tbaa !29
  %t562 = getelementptr { i64, [5 x i64] }, ptr %t560, i32 0, i32 1
  %t563 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t562, i32 0, i32 2
  %t564 = load { i64, ptr }, ptr %t563
  store { i64, ptr } %t564, ptr %l38, !tbaa !27
  br label %bb168
bb167:
  br label %bb173
bb168:
  store %olang.scope zeroinitializer, ptr %s22
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t566, ptr %t567)
  br label %bb169
bb169:
  %t570 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t570, { i64, ptr } { i64 1, ptr @.d45 })
  br label %bb170
bb170:
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t573 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t572, { i64, ptr } %t573)
  br label %bb171
bb171:
  %t576 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t576, { i64, ptr } { i64 1, ptr @.d46 })
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s22)
  br label %bb324
bb173:
  %t578 = load ptr, ptr %l1, !tbaa !29
  store ptr %t578, ptr %l309, !tbaa !29
  store i1 false, ptr %l310, !tbaa !21
  %t579 = load ptr, ptr %l309, !tbaa !29
  %t580 = icmp ne ptr %t579, null
  br i1 %t580, label %bb174, label %bb175
bb174:
  %t582 = load ptr, ptr %l309, !tbaa !29
  %t583 = load i64, ptr %t582
  %t585 = icmp eq i64 %t583, 15
  store i1 %t585, ptr %l310, !tbaa !21
  br label %bb175
bb175:
  %t586 = load i1, ptr %l310, !tbaa !21
  br i1 %t586, label %bb176, label %bb177
bb176:
  %t587 = load ptr, ptr %l1, !tbaa !29
  %t589 = getelementptr { i64, [5 x i64] }, ptr %t587, i32 0, i32 1
  %t590 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t589, i32 0, i32 1
  %t591 = load ptr, ptr %t590
  store ptr %t591, ptr %l39, !tbaa !29
  %t593 = load ptr, ptr %l1, !tbaa !29
  %t595 = getelementptr { i64, [5 x i64] }, ptr %t593, i32 0, i32 1
  %t596 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t595, i32 0, i32 2
  %t597 = load i32, ptr %t596
  store i32 %t597, ptr %l40, !tbaa !23
  br label %bb178
bb177:
  br label %bb182
bb178:
  store %olang.scope zeroinitializer, ptr %s23
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t600 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t599, ptr %t600)
  br label %bb179
bb179:
  %t603 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t603, { i64, ptr } { i64 1, ptr @.d47 })
  br label %bb180
bb180:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load i32, ptr %l40, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t605, i32 %t606)
  br label %bb181
bb181:
  call void @__olang_scope_close(ptr %s23)
  br label %bb324
bb182:
  %t609 = load ptr, ptr %l1, !tbaa !29
  store ptr %t609, ptr %l322, !tbaa !29
  store i1 false, ptr %l323, !tbaa !21
  %t610 = load ptr, ptr %l322, !tbaa !29
  %t611 = icmp ne ptr %t610, null
  br i1 %t611, label %bb183, label %bb184
bb183:
  %t613 = load ptr, ptr %l322, !tbaa !29
  %t614 = load i64, ptr %t613
  %t616 = icmp eq i64 %t614, 16
  store i1 %t616, ptr %l323, !tbaa !21
  br label %bb184
bb184:
  %t617 = load i1, ptr %l323, !tbaa !21
  br i1 %t617, label %bb185, label %bb186
bb185:
  %t618 = load ptr, ptr %l1, !tbaa !29
  %t620 = getelementptr { i64, [5 x i64] }, ptr %t618, i32 0, i32 1
  %t621 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t620, i32 0, i32 1
  %t622 = load ptr, ptr %t621
  store ptr %t622, ptr %l41, !tbaa !29
  %t624 = load ptr, ptr %l1, !tbaa !29
  %t626 = getelementptr { i64, [5 x i64] }, ptr %t624, i32 0, i32 1
  %t627 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t626, i32 0, i32 2
  %t628 = load { i64, ptr }, ptr %t627
  store { i64, ptr } %t628, ptr %l42, !tbaa !27
  br label %bb187
bb186:
  br label %bb192
bb187:
  store %olang.scope zeroinitializer, ptr %s24
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t631 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t630, ptr %t631)
  br label %bb188
bb188:
  %t634 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t634, { i64, ptr } { i64 1, ptr @.d48 })
  br label %bb189
bb189:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t637 = load { i64, ptr }, ptr %l42, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t636, { i64, ptr } %t637)
  br label %bb190
bb190:
  %t640 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t640, { i64, ptr } { i64 1, ptr @.d49 })
  br label %bb191
bb191:
  call void @__olang_scope_close(ptr %s24)
  br label %bb324
bb192:
  %t642 = load ptr, ptr %l1, !tbaa !29
  store ptr %t642, ptr %l336, !tbaa !29
  store i1 false, ptr %l337, !tbaa !21
  %t643 = load ptr, ptr %l336, !tbaa !29
  %t644 = icmp ne ptr %t643, null
  br i1 %t644, label %bb193, label %bb194
bb193:
  %t646 = load ptr, ptr %l336, !tbaa !29
  %t647 = load i64, ptr %t646
  %t649 = icmp eq i64 %t647, 17
  store i1 %t649, ptr %l337, !tbaa !21
  br label %bb194
bb194:
  %t650 = load i1, ptr %l337, !tbaa !21
  br i1 %t650, label %bb195, label %bb196
bb195:
  %t651 = load ptr, ptr %l1, !tbaa !29
  %t653 = getelementptr { i64, [5 x i64] }, ptr %t651, i32 0, i32 1
  %t654 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t653, i32 0, i32 1
  %t655 = load ptr, ptr %t654
  store ptr %t655, ptr %l43, !tbaa !29
  %t657 = load ptr, ptr %l1, !tbaa !29
  %t659 = getelementptr { i64, [5 x i64] }, ptr %t657, i32 0, i32 1
  %t660 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t659, i32 0, i32 2
  %t661 = load ptr, ptr %t660
  store ptr %t661, ptr %l44, !tbaa !29
  %t663 = load ptr, ptr %l1, !tbaa !29
  %t665 = getelementptr { i64, [5 x i64] }, ptr %t663, i32 0, i32 1
  %t666 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t665, i32 0, i32 3
  %t667 = load ptr, ptr %t666
  store ptr %t667, ptr %l45, !tbaa !29
  br label %bb197
bb196:
  br label %bb210
bb197:
  store %olang.scope zeroinitializer, ptr %s25
  %t669 = load ptr, ptr %l0, !tbaa !29
  %t670 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t669, ptr %t670)
  br label %bb198
bb198:
  %t673 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t673, { i64, ptr } { i64 1, ptr @.d50 })
  br label %bb199
bb199:
  %t675 = load ptr, ptr %l44, !tbaa !29
  %t677 = icmp eq ptr %t675, null
  %t679 = xor i1 %t677, true
  br i1 %t679, label %bb200, label %bb201
bb200:
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t682 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t681, ptr %t682)
  br label %bb202
bb201:
  br label %bb203
bb202:
  br label %bb203
bb203:
  %t685 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t685, { i64, ptr } { i64 1, ptr @.d51 })
  br label %bb204
bb204:
  %t687 = load ptr, ptr %l45, !tbaa !29
  %t689 = icmp eq ptr %t687, null
  %t691 = xor i1 %t689, true
  br i1 %t691, label %bb205, label %bb206
bb205:
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t694 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t693, ptr %t694)
  br label %bb207
bb206:
  br label %bb208
bb207:
  br label %bb208
bb208:
  %t697 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t697, { i64, ptr } { i64 1, ptr @.d52 })
  br label %bb209
bb209:
  call void @__olang_scope_close(ptr %s25)
  br label %bb324
bb210:
  %t699 = load ptr, ptr %l1, !tbaa !29
  store ptr %t699, ptr %l361, !tbaa !29
  store i1 false, ptr %l362, !tbaa !21
  %t700 = load ptr, ptr %l361, !tbaa !29
  %t701 = icmp ne ptr %t700, null
  br i1 %t701, label %bb211, label %bb212
bb211:
  %t703 = load ptr, ptr %l361, !tbaa !29
  %t704 = load i64, ptr %t703
  %t706 = icmp eq i64 %t704, 18
  store i1 %t706, ptr %l362, !tbaa !21
  br label %bb212
bb212:
  %t707 = load i1, ptr %l362, !tbaa !21
  br i1 %t707, label %bb213, label %bb214
bb213:
  %t708 = load ptr, ptr %l1, !tbaa !29
  %t710 = getelementptr { i64, [5 x i64] }, ptr %t708, i32 0, i32 1
  %t711 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t710, i32 0, i32 1
  %t712 = load ptr, ptr %t711
  store ptr %t712, ptr %l46, !tbaa !29
  %t714 = load ptr, ptr %l1, !tbaa !29
  %t716 = getelementptr { i64, [5 x i64] }, ptr %t714, i32 0, i32 1
  %t717 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t716, i32 0, i32 2
  %t718 = load { i64, ptr }, ptr %t717
  store { i64, ptr } %t718, ptr %l47, !tbaa !27
  br label %bb215
bb214:
  br label %bb223
bb215:
  store %olang.scope zeroinitializer, ptr %s28
  %t720 = load ptr, ptr %l0, !tbaa !29
  store ptr %t720, ptr %l369, !tbaa !29
  %t721 = load ptr, ptr %l46, !tbaa !29
  %t723 = icmp eq ptr %t721, null
  br i1 %t723, label %bb216, label %bb217
bb216:
  call void @__olang_check_failed(ptr @olang_loc_577bb2401887ee03_bd83bee27b444ed7)
  unreachable
bb217:
  br label %bb218
bb218:
  %t725 = load ptr, ptr %l46, !tbaa !29
  %t726 = load ptr, ptr %l369, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t726, ptr %t725)
  br label %bb219
bb219:
  %t728 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t728, { i64, ptr } { i64 1, ptr @.d53 })
  br label %bb220
bb220:
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t731 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t730, { i64, ptr } %t731)
  br label %bb221
bb221:
  %t734 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t734, { i64, ptr } { i64 1, ptr @.d54 })
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s28)
  br label %bb324
bb223:
  %t736 = load ptr, ptr %l1, !tbaa !29
  store ptr %t736, ptr %l377, !tbaa !29
  store i1 false, ptr %l378, !tbaa !21
  %t737 = load ptr, ptr %l377, !tbaa !29
  %t738 = icmp ne ptr %t737, null
  br i1 %t738, label %bb224, label %bb225
bb224:
  %t740 = load ptr, ptr %l377, !tbaa !29
  %t741 = load i64, ptr %t740
  %t743 = icmp eq i64 %t741, 19
  store i1 %t743, ptr %l378, !tbaa !21
  br label %bb225
bb225:
  %t744 = load i1, ptr %l378, !tbaa !21
  br i1 %t744, label %bb226, label %bb227
bb226:
  %t745 = load ptr, ptr %l1, !tbaa !29
  %t747 = getelementptr { i64, [5 x i64] }, ptr %t745, i32 0, i32 1
  %t748 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t747, i32 0, i32 1
  %t749 = load { i64, ptr }, ptr %t748
  store { i64, ptr } %t749, ptr %l48, !tbaa !27
  br label %bb228
bb227:
  br label %bb232
bb228:
  store %olang.scope zeroinitializer, ptr %s29
  %t751 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t751, { i64, ptr } { i64 1, ptr @.d55 })
  br label %bb229
bb229:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t754 = load { i64, ptr }, ptr %l48, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t753, { i64, ptr } %t754)
  br label %bb230
bb230:
  %t757 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t757, { i64, ptr } { i64 1, ptr @.d56 })
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s29)
  br label %bb324
bb232:
  %t759 = load ptr, ptr %l1, !tbaa !29
  store ptr %t759, ptr %l387, !tbaa !29
  store i1 false, ptr %l388, !tbaa !21
  %t760 = load ptr, ptr %l387, !tbaa !29
  %t761 = icmp ne ptr %t760, null
  br i1 %t761, label %bb233, label %bb234
bb233:
  %t763 = load ptr, ptr %l387, !tbaa !29
  %t764 = load i64, ptr %t763
  %t766 = icmp eq i64 %t764, 20
  store i1 %t766, ptr %l388, !tbaa !21
  br label %bb234
bb234:
  %t767 = load i1, ptr %l388, !tbaa !21
  br i1 %t767, label %bb235, label %bb236
bb235:
  %t768 = load ptr, ptr %l1, !tbaa !29
  %t770 = getelementptr { i64, [5 x i64] }, ptr %t768, i32 0, i32 1
  %t771 = getelementptr { %"compiler/source:Span", ptr }, ptr %t770, i32 0, i32 1
  %t772 = load ptr, ptr %t771
  store ptr %t772, ptr %l49, !tbaa !29
  br label %bb237
bb236:
  br label %bb262
bb237:
  store %olang.scope zeroinitializer, ptr %s30
  %t774 = load ptr, ptr %l0, !tbaa !29
  store ptr %t774, ptr %l393, !tbaa !29
  %t775 = load ptr, ptr %l49, !tbaa !29
  %t777 = getelementptr %"compiler/ast:Compr", ptr %t775, i32 0, i32 0
  %t778 = load ptr, ptr %t777, !tbaa !29
  %t780 = icmp eq ptr %t778, null
  br i1 %t780, label %bb238, label %bb239
bb238:
  call void @__olang_check_failed(ptr @olang_loc_47b511f5ef6d9e74_baf04e552c3da2b8)
  unreachable
bb239:
  br label %bb240
bb240:
  %t782 = load ptr, ptr %l49, !tbaa !29
  %t784 = getelementptr %"compiler/ast:Compr", ptr %t782, i32 0, i32 0
  %t785 = load ptr, ptr %t784, !tbaa !29
  %t786 = load ptr, ptr %l393, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t786, ptr %t785)
  br label %bb241
bb241:
  %t788 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t788, { i64, ptr } { i64 1, ptr @.d57 })
  br label %bb242
bb242:
  %t790 = load ptr, ptr %l0, !tbaa !29
  %t791 = load ptr, ptr %l49, !tbaa !29
  %t793 = getelementptr %"compiler/ast:Compr", ptr %t791, i32 0, i32 1
  %t794 = load ptr, ptr %t793, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t790, ptr %t794)
  br label %bb243
bb243:
  %t797 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t797, { i64, ptr } { i64 5, ptr @.d58 })
  br label %bb244
bb244:
  %t799 = load ptr, ptr %l49, !tbaa !29
  %t801 = getelementptr %"compiler/ast:Compr", ptr %t799, i32 0, i32 2
  %t802 = load i32, ptr %t801, !tbaa !23
  %t804 = icmp ne i32 %t802, 0
  br i1 %t804, label %bb245, label %bb246
bb245:
  store %olang.scope zeroinitializer, ptr %s31
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t807 = load ptr, ptr %l49, !tbaa !29
  %t809 = getelementptr %"compiler/ast:Compr", ptr %t807, i32 0, i32 2
  %t810 = load i32, ptr %t809, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t806, i32 %t810)
  br label %bb247
bb246:
  br label %bb249
bb247:
  %t813 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t813, { i64, ptr } { i64 2, ptr @.d59 })
  br label %bb248
bb248:
  call void @__olang_scope_close(ptr %s31)
  br label %bb249
bb249:
  %t815 = load ptr, ptr %l0, !tbaa !29
  %t816 = load ptr, ptr %l49, !tbaa !29
  %t818 = getelementptr %"compiler/ast:Compr", ptr %t816, i32 0, i32 3
  %t819 = load i32, ptr %t818, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t815, i32 %t819)
  br label %bb250
bb250:
  %t822 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t822, { i64, ptr } { i64 4, ptr @.d60 })
  br label %bb251
bb251:
  %t824 = load ptr, ptr %l0, !tbaa !29
  %t825 = load ptr, ptr %l49, !tbaa !29
  %t827 = getelementptr %"compiler/ast:Compr", ptr %t825, i32 0, i32 4
  %t828 = load ptr, ptr %t827, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t824, ptr %t828)
  br label %bb252
bb252:
  %t831 = load ptr, ptr %l49, !tbaa !29
  %t833 = getelementptr %"compiler/ast:Compr", ptr %t831, i32 0, i32 5
  %t834 = load ptr, ptr %t833, !tbaa !29
  %t836 = icmp eq ptr %t834, null
  %t838 = xor i1 %t836, true
  br i1 %t838, label %bb253, label %bb254
bb253:
  store %olang.scope zeroinitializer, ptr %s32
  %t840 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s32, ptr %t840, { i64, ptr } { i64 4, ptr @.d61 })
  br label %bb255
bb254:
  br label %bb260
bb255:
  %t842 = load ptr, ptr %l0, !tbaa !29
  store ptr %t842, ptr %l423, !tbaa !29
  %t843 = load ptr, ptr %l49, !tbaa !29
  %t845 = getelementptr %"compiler/ast:Compr", ptr %t843, i32 0, i32 5
  %t846 = load ptr, ptr %t845, !tbaa !29
  %t848 = icmp eq ptr %t846, null
  br i1 %t848, label %bb256, label %bb257
bb256:
  call void @__olang_check_failed(ptr @olang_loc_e6dde321a76d1169_ef8c066898e78ecd)
  unreachable
bb257:
  br label %bb258
bb258:
  %t850 = load ptr, ptr %l49, !tbaa !29
  %t852 = getelementptr %"compiler/ast:Compr", ptr %t850, i32 0, i32 5
  %t853 = load ptr, ptr %t852, !tbaa !29
  %t854 = load ptr, ptr %l423, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t854, ptr %t853)
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s32)
  br label %bb260
bb260:
  %t856 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t856, { i64, ptr } { i64 1, ptr @.d62 })
  br label %bb261
bb261:
  call void @__olang_scope_close(ptr %s30)
  br label %bb324
bb262:
  %t858 = load ptr, ptr %l1, !tbaa !29
  store ptr %t858, ptr %l430, !tbaa !29
  store i1 false, ptr %l431, !tbaa !21
  %t859 = load ptr, ptr %l430, !tbaa !29
  %t860 = icmp ne ptr %t859, null
  br i1 %t860, label %bb263, label %bb264
bb263:
  %t862 = load ptr, ptr %l430, !tbaa !29
  %t863 = load i64, ptr %t862
  %t865 = icmp eq i64 %t863, 21
  store i1 %t865, ptr %l431, !tbaa !21
  br label %bb264
bb264:
  %t866 = load i1, ptr %l431, !tbaa !21
  br i1 %t866, label %bb265, label %bb266
bb265:
  %t867 = load ptr, ptr %l1, !tbaa !29
  %t869 = getelementptr { i64, [5 x i64] }, ptr %t867, i32 0, i32 1
  %t870 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t869, i32 0, i32 1
  %t871 = load { i64, ptr }, ptr %t870
  store { i64, ptr } %t871, ptr %l50, !tbaa !27
  br label %bb267
bb266:
  br label %bb279
bb267:
  %t873 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t873, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t875 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t877 = extractvalue { i64, ptr } %t875, 0
  store i64 %t877, ptr %l53, !tbaa !24
  br label %bb268
bb268:
  store %olang.scope zeroinitializer, ptr %s35
  %t879 = load i64, ptr %l52, !tbaa !24
  %t880 = load i64, ptr %l53, !tbaa !24
  %t883 = icmp slt i64 %t879, %t880
  %t885 = xor i1 %t883, true
  br i1 %t885, label %bb269, label %bb270
bb269:
  call void @__olang_scope_close(ptr %s35)
  br label %bb278
bb270:
  br label %bb271
bb271:
  %t887 = load i64, ptr %l52, !tbaa !24
  %t889 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t889, ptr %l444, !tbaa !27
  %t890 = load i64, ptr %l52, !tbaa !24
  %t892 = getelementptr { i64, ptr }, ptr %l444, i32 0, i32 1
  %t893 = load ptr, ptr %t892, !tbaa !27
  %t894 = getelementptr ptr, ptr %t893, i64 %t890
  %t895 = load ptr, ptr %t894, !tbaa !39
  store ptr %t895, ptr %l55, !tbaa !29
  %t899 = icmp sgt i64 %t887, 0
  br i1 %t899, label %bb272, label %bb273
bb272:
  store %olang.scope zeroinitializer, ptr %s36
  %t901 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s36, ptr %t901, { i64, ptr } { i64 1, ptr @.d63 })
  br label %bb274
bb273:
  br label %bb275
bb274:
  call void @__olang_scope_close(ptr %s36)
  br label %bb275
bb275:
  %t903 = load ptr, ptr %l0, !tbaa !29
  %t904 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t903, ptr %t904)
  br label %bb276
bb276:
  call void @__olang_scope_close(ptr %s35)
  br label %bb277
bb277:
  %t907 = load i64, ptr %l52, !tbaa !24
  %t909 = add i64 %t907, 1
  store i64 %t909, ptr %l52, !tbaa !24
  br label %bb268
bb278:
  br label %bb324
bb279:
  %t911 = load ptr, ptr %l1, !tbaa !29
  store ptr %t911, ptr %l454, !tbaa !29
  store i1 false, ptr %l455, !tbaa !21
  %t912 = load ptr, ptr %l454, !tbaa !29
  %t913 = icmp ne ptr %t912, null
  br i1 %t913, label %bb280, label %bb281
bb280:
  %t915 = load ptr, ptr %l454, !tbaa !29
  %t916 = load i64, ptr %t915
  %t918 = icmp eq i64 %t916, 22
  store i1 %t918, ptr %l455, !tbaa !21
  br label %bb281
bb281:
  %t919 = load i1, ptr %l455, !tbaa !21
  br i1 %t919, label %bb282, label %bb283
bb282:
  %t920 = load ptr, ptr %l1, !tbaa !29
  %t922 = getelementptr { i64, [5 x i64] }, ptr %t920, i32 0, i32 1
  %t923 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t922, i32 0, i32 1
  %t924 = load ptr, ptr %t923
  store ptr %t924, ptr %l56, !tbaa !29
  %t926 = load ptr, ptr %l1, !tbaa !29
  %t928 = getelementptr { i64, [5 x i64] }, ptr %t926, i32 0, i32 1
  %t929 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t928, i32 0, i32 2
  %t930 = load { i64, ptr }, ptr %t929
  store { i64, ptr } %t930, ptr %l57, !tbaa !27
  %t932 = load ptr, ptr %l1, !tbaa !29
  %t934 = getelementptr { i64, [5 x i64] }, ptr %t932, i32 0, i32 1
  %t935 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t934, i32 0, i32 3
  %t936 = load i1, ptr %t935
  store i1 %t936, ptr %l58, !tbaa !21
  br label %bb284
bb283:
  br label %bb291
bb284:
  store %olang.scope zeroinitializer, ptr %s38
  %t938 = load ptr, ptr %l0, !tbaa !29
  store ptr %t938, ptr %l464, !tbaa !29
  %t939 = load i1, ptr %l58, !tbaa !21
  br i1 %t939, label %bb285, label %bb286
bb285:
  store { i64, ptr } { i64 8, ptr @.d64 }, ptr %l466, !tbaa !27
  br label %bb287
bb286:
  store { i64, ptr } { i64 4, ptr @.d65 }, ptr %l466, !tbaa !27
  br label %bb287
bb287:
  %t941 = load ptr, ptr %l464, !tbaa !29
  %t942 = load { i64, ptr }, ptr %l466, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s38, ptr %t941, { i64, ptr } %t942)
  br label %bb288
bb288:
  %t943 = load ptr, ptr %l0, !tbaa !29
  %t944 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t943, ptr %t944)
  br label %bb289
bb289:
  %t947 = load ptr, ptr %l0, !tbaa !29
  %t948 = load { i64, ptr }, ptr %l57, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t947, { i64, ptr } %t948)
  br label %bb290
bb290:
  call void @__olang_scope_close(ptr %s38)
  br label %bb324
bb291:
  %t951 = load ptr, ptr %l1, !tbaa !29
  store ptr %t951, ptr %l471, !tbaa !29
  store i1 false, ptr %l472, !tbaa !21
  %t952 = load ptr, ptr %l471, !tbaa !29
  %t953 = icmp ne ptr %t952, null
  br i1 %t953, label %bb292, label %bb293
bb292:
  %t955 = load ptr, ptr %l471, !tbaa !29
  %t956 = load i64, ptr %t955
  %t958 = icmp eq i64 %t956, 23
  store i1 %t958, ptr %l472, !tbaa !21
  br label %bb293
bb293:
  %t959 = load i1, ptr %l472, !tbaa !21
  br i1 %t959, label %bb294, label %bb295
bb294:
  %t960 = load ptr, ptr %l1, !tbaa !29
  %t962 = getelementptr { i64, [5 x i64] }, ptr %t960, i32 0, i32 1
  %t963 = getelementptr { %"compiler/source:Span", ptr }, ptr %t962, i32 0, i32 1
  %t964 = load ptr, ptr %t963
  store ptr %t964, ptr %l59, !tbaa !29
  br label %bb296
bb295:
  br label %bb301
bb296:
  store %olang.scope zeroinitializer, ptr %s39
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t968 = getelementptr %"compiler/unparse:writer", ptr %t966, i32 0, i32 6
  %t969 = load i1, ptr %t968, !tbaa !21
  store i1 %t969, ptr %l60, !tbaa !21
  %t971 = load ptr, ptr %l0, !tbaa !29
  %t973 = getelementptr %"compiler/unparse:writer", ptr %t971, i32 0, i32 6
  store i1 false, ptr %t973, !tbaa !21
  %t974 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s39, ptr %t974, { i64, ptr } { i64 2, ptr @.d66 })
  br label %bb297
bb297:
  %t976 = load ptr, ptr %l0, !tbaa !29
  %t977 = load ptr, ptr %l59, !tbaa !29
  %t979 = getelementptr %"compiler/ast:Func", ptr %t977, i32 0, i32 3
  %t980 = load ptr, ptr %t979, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t976, ptr %t980)
  br label %bb298
bb298:
  %t983 = load ptr, ptr %l0, !tbaa !29
  %t984 = load i1, ptr %l60, !tbaa !21
  %t987 = getelementptr %"compiler/unparse:writer", ptr %t983, i32 0, i32 6
  store i1 %t984, ptr %t987, !tbaa !21
  %t988 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s39, ptr %t988, { i64, ptr } { i64 1, ptr @.d67 })
  br label %bb299
bb299:
  %t990 = load ptr, ptr %l0, !tbaa !29
  %t991 = load ptr, ptr %l59, !tbaa !29
  %t993 = getelementptr %"compiler/ast:Func", ptr %t991, i32 0, i32 4
  %t994 = load { i64, ptr }, ptr %t993, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t990, { i64, ptr } %t994)
  br label %bb300
bb300:
  call void @__olang_scope_close(ptr %s39)
  br label %bb324
bb301:
  %t997 = load ptr, ptr %l1, !tbaa !29
  store ptr %t997, ptr %l490, !tbaa !29
  store i1 false, ptr %l491, !tbaa !21
  %t998 = load ptr, ptr %l490, !tbaa !29
  %t999 = icmp ne ptr %t998, null
  br i1 %t999, label %bb302, label %bb303
bb302:
  %t1001 = load ptr, ptr %l490, !tbaa !29
  %t1002 = load i64, ptr %t1001
  %t1004 = icmp eq i64 %t1002, 24
  store i1 %t1004, ptr %l491, !tbaa !21
  br label %bb303
bb303:
  %t1005 = load i1, ptr %l491, !tbaa !21
  br i1 %t1005, label %bb304, label %bb305
bb304:
  %t1006 = load ptr, ptr %l1, !tbaa !29
  %t1008 = getelementptr { i64, [5 x i64] }, ptr %t1006, i32 0, i32 1
  %t1009 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1008, i32 0, i32 1
  %t1010 = load ptr, ptr %t1009
  store ptr %t1010, ptr %l61, !tbaa !29
  br label %bb306
bb305:
  br label %bb308
bb306:
  %t1012 = load ptr, ptr %l0, !tbaa !29
  %t1013 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t1012, ptr %t1013)
  br label %bb307
bb307:
  br label %bb324
bb308:
  %t1016 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1016, ptr %l498, !tbaa !29
  store i1 false, ptr %l499, !tbaa !21
  %t1017 = load ptr, ptr %l498, !tbaa !29
  %t1018 = icmp ne ptr %t1017, null
  br i1 %t1018, label %bb309, label %bb310
bb309:
  %t1020 = load ptr, ptr %l498, !tbaa !29
  %t1021 = load i64, ptr %t1020
  %t1023 = icmp eq i64 %t1021, 25
  store i1 %t1023, ptr %l499, !tbaa !21
  br label %bb310
bb310:
  %t1024 = load i1, ptr %l499, !tbaa !21
  br i1 %t1024, label %bb311, label %bb312
bb311:
  %t1025 = load ptr, ptr %l1, !tbaa !29
  %t1027 = getelementptr { i64, [5 x i64] }, ptr %t1025, i32 0, i32 1
  %t1028 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t1027, i32 0, i32 1
  %t1029 = load { i64, ptr }, ptr %t1028
  store { i64, ptr } %t1029, ptr %l62, !tbaa !27
  br label %bb313
bb312:
  br label %bb316
bb313:
  store %olang.scope zeroinitializer, ptr %s41
  %t1031 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s41, ptr %t1031, { i64, ptr } { i64 6, ptr @.d68 })
  br label %bb314
bb314:
  %t1033 = load ptr, ptr %l0, !tbaa !29
  %t1034 = load { i64, ptr }, ptr %l62, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t1033, { i64, ptr } %t1034)
  br label %bb315
bb315:
  call void @__olang_scope_close(ptr %s41)
  br label %bb324
bb316:
  %t1037 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1037, ptr %l507, !tbaa !29
  store i1 false, ptr %l508, !tbaa !21
  %t1038 = load ptr, ptr %l507, !tbaa !29
  %t1039 = icmp ne ptr %t1038, null
  br i1 %t1039, label %bb317, label %bb318
bb317:
  %t1041 = load ptr, ptr %l507, !tbaa !29
  %t1042 = load i64, ptr %t1041
  %t1044 = icmp eq i64 %t1042, 26
  store i1 %t1044, ptr %l508, !tbaa !21
  br label %bb318
bb318:
  %t1045 = load i1, ptr %l508, !tbaa !21
  br i1 %t1045, label %bb319, label %bb320
bb319:
  br label %bb321
bb320:
  br label %bb323
bb321:
  store %olang.scope zeroinitializer, ptr %s42
  %t1046 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s42, ptr %t1046, { i64, ptr } { i64 7, ptr @.d69 })
  br label %bb322
bb322:
  call void @__olang_scope_close(ptr %s42)
  br label %bb324
bb323:
  call void @__olang_check_failed(ptr @olang_loc_af8532b2afdd02b1_ed9973e7a2ad66a5)
  unreachable
bb324:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t27 = icmp sgt i64 %t15, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t29, { i64, ptr } { i64 2, ptr @.d70 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l8 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr @.d71 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/ast:Func", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t12, { i64, ptr } { i64 1, ptr @.d72 })
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l8, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Func", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_240300a98391f326_30555605a48ff2da)
  unreachable
bb6:
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t26, ptr %t25)
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t28, { i64, ptr } { i64 2, ptr @.d73 })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Func", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %t33, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t30, i32 %t34)
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Func", ptr %t38, i32 0, i32 5
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t37, { i64, ptr } %t41)
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t44, ptr %t48)
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t51, { i64, ptr } { i64 1, ptr @.d74 })
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Func", ptr %t54, i32 0, i32 4
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t53, { i64, ptr } %t57)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l14 = alloca ptr
  %l20 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l42 = alloca ptr
  %l49 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:If", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_450b6e4c0e54f911_1dcad8b8a27ff01d)
  unreachable
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:If", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t20, ptr %t19)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t22, { i64, ptr } { i64 3, ptr @.d75 })
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:If", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_375b6e3c7dc4e00a_588d095da59240b6)
  unreachable
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/ast:If", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t36, ptr %t35)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l20, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:If", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_e1b6c554c381b10b_f727e5cc4e37ef67)
  unreachable
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/ast:If", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t50, ptr %t49)
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/ast:If", ptr %t52, i32 0, i32 2
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t61, { i64, ptr } { i64 5, ptr @.d76 })
  br label %bb19
bb18:
  br label %bb43
bb19:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/ast:If", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l2, !tbaa !29
  %t68 = load ptr, ptr %l2, !tbaa !29
  store ptr %t68, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t69 = load ptr, ptr %l33, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load ptr, ptr %l33, !tbaa !29
  %t73 = load i64, ptr %t72
  %t75 = icmp eq i64 %t73, 5
  store i1 %t75, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t76 = load i1, ptr %l34, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", ptr }, ptr %t79, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t83 = load ptr, ptr %l3, !tbaa !29
  %t85 = getelementptr %"compiler/ast:If", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = icmp eq ptr %t86, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l42, !tbaa !29
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/ast:If", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb27, label %bb28
bb26:
  br label %bb31
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ba8e182b2fbe7a1c_99d493faf8d7cb48)
  unreachable
bb28:
  br label %bb29
bb29:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/ast:If", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t102, ptr %t101)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_a676b6f90e9ab794_adfa384105d75b88)
  unreachable
bb37:
  %t104 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t104, { i64, ptr } { i64 1, ptr @.d77 })
  br label %bb38
bb38:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l49, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/ast:If", ptr %t107, i32 0, i32 2
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_8218e8270bec8206_ca247080b262927a)
  unreachable
bb40:
  br label %bb41
bb41:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/ast:If", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t118, ptr %t117)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t9, { i64, ptr } %a1)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i1, ptr %l2, !tbaa !21
  %t17 = getelementptr %"compiler/unparse:writer", ptr %t13, i32 0, i32 6
  store i1 %t14, ptr %t17, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l21 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l96 = alloca ptr
  %l102 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 6, ptr @.d78 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Match", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t3, ptr %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 2, ptr @.d79 })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l21, !tbaa !29
  %t13 = load ptr, ptr %l21, !tbaa !29
  %t14 = getelementptr %"compiler/unparse:writer", ptr %t13, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = add i64 %t15, 1
  %t19 = load ptr, ptr %l21, !tbaa !29
  %t20 = getelementptr %"compiler/unparse:writer", ptr %t19, i32 0, i32 4
  store i64 %t17, ptr %t20, !tbaa !24
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Match", ptr %t21, i32 0, i32 3
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb6:
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l32, !tbaa !27
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  store ptr %t44, ptr %l5, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t46)
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t48, { i64, ptr } { i64 5, ptr @.d80 })
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Case", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l46, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l10, !tbaa !29
  %t79 = icmp sgt i64 %t67, 0
  br i1 %t79, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t81, { i64, ptr } { i64 2, ptr @.d81 })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb10
bb20:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Case", ptr %t91, i32 0, i32 2
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t110, ptr %l65, !tbaa !27
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr ptr, ptr %t114, i64 %t111
  %t116 = load ptr, ptr %t115, !tbaa !39
  store ptr %t116, ptr %l15, !tbaa !29
  %t120 = icmp sgt i64 %t108, 0
  br i1 %t120, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t122 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t122, { i64, ptr } { i64 2, ptr @.d82 })
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb28:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb30
bb30:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l12, !tbaa !24
  br label %bb21
bb31:
  %t132 = load ptr, ptr %l5, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Case", ptr %t132, i32 0, i32 3
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = icmp eq ptr %t135, null
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s11
  %t141 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t141, { i64, ptr } { i64 4, ptr @.d83 })
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l80, !tbaa !29
  %t144 = load ptr, ptr %l5, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_212921701ccd28fb_40c266614e32415f)
  unreachable
bb36:
  br label %bb37
bb37:
  %t151 = load ptr, ptr %l5, !tbaa !29
  %t153 = getelementptr %"compiler/ast:Case", ptr %t151, i32 0, i32 3
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t155, ptr %t154)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s11)
  br label %bb39
bb39:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %t157, ptr %t158)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t161 = load i64, ptr %l3, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l3, !tbaa !24
  br label %bb4
bb42:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/ast:Match", ptr %t165, i32 0, i32 4
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = icmp eq ptr %t168, null
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s13
  %t174 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t174)
  br label %bb45
bb44:
  br label %bb51
bb45:
  %t176 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t176, { i64, ptr } { i64 7, ptr @.d84 })
  br label %bb46
bb46:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l96, !tbaa !29
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr %"compiler/ast:Match", ptr %t179, i32 0, i32 4
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = icmp eq ptr %t182, null
  br i1 %t184, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_a89566c82002a68c_50a6017df30325c0)
  unreachable
bb48:
  br label %bb49
bb49:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr %"compiler/ast:Match", ptr %t186, i32 0, i32 4
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t190 = load ptr, ptr %l96, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %t190, ptr %t189)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s13)
  br label %bb51
bb51:
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l102, !tbaa !29
  %t193 = load ptr, ptr %l102, !tbaa !29
  %t194 = getelementptr %"compiler/unparse:writer", ptr %t193, i32 0, i32 4
  %t195 = load i64, ptr %t194, !tbaa !24
  %t197 = sub i64 %t195, 1
  %t199 = load ptr, ptr %l102, !tbaa !29
  %t200 = getelementptr %"compiler/unparse:writer", ptr %t199, i32 0, i32 4
  store i64 %t197, ptr %t200, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t201)
  br label %bb52
bb52:
  %t203 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t203, { i64, ptr } { i64 1, ptr @.d85 })
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t7, i32 %a1)
  store { i64, ptr } %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t12, { i64, ptr } %t13)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t3, i8 10)
  br label %bb1
bb1:
  store i64 0, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/unparse:writer", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2funparse_2eMaxIndent, !tbaa !24
  %t12 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t8, i64 %t9)
  store i64 %t12, ptr %l12
  br label %bb2
bb2:
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb8
bb5:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l19, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l19, !tbaa !24
  store i64 %t40, ptr %l16, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l16, !tbaa !24
  store i64 %t41, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l1, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l6, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/unparse:writer", ptr %t60, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t62, { i64, ptr } { i64 4, ptr @.d86 })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l5, !tbaa !24
  br label %bb9
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l16 = alloca ptr
  %l27 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Param", ptr %t1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t8, i32 %t12)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Param", ptr %t15, i32 0, i32 2
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Param", ptr %t24, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = icmp ne i32 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb6:
  br label %bb15
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t31, { i64, ptr } { i64 1, ptr @.d87 })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l16, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/ast:Param", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_2301005a90ba30f7_2e0b8cd6b5bb3c83)
  unreachable
bb12:
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/ast:Param", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t45, ptr %t44)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Param", ptr %t47, i32 0, i32 3
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t56, { i64, ptr } { i64 3, ptr @.d88 })
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l27, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Param", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_6385ebb2fa48e0d8_1e44ec8c8ca0ecf4)
  unreachable
bb20:
  br label %bb21
bb21:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Param", ptr %t66, i32 0, i32 3
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t70, ptr %t69)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l19 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l7, !tbaa !29
  %t35 = icmp sgt i64 %t23, 0
  br i1 %t35, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t37, { i64, ptr } { i64 2, ptr @.d89 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i1, ptr %l2, !tbaa !21
  %t51 = getelementptr %"compiler/unparse:writer", ptr %t47, i32 0, i32 6
  store i1 %t48, ptr %t51, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:Path", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t30 = icmp sgt i64 %t18, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t32, { i64, ptr } { i64 1, ptr @.d90 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t34, i32 %t35)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l44 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 1, ptr @.d91 })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb49
bb7:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb8, label %bb9
bb8:
  %t16 = load ptr, ptr %l17, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 1
  store i1 %t19, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb10, label %bb11
bb10:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", ptr }, ptr %t23, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  br label %bb13
bb13:
  br label %bb49
bb14:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t35 = load ptr, ptr %l25, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l26, !tbaa !21
  br i1 %t39, label %bb17, label %bb18
bb17:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t48, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49
  store { i64, ptr } %t50, ptr %l4, !tbaa !27
  br label %bb19
bb18:
  br label %bb34
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t56, { i64, ptr } { i64 1, ptr @.d92 })
  br label %bb21
bb21:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l44, !tbaa !27
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l9, !tbaa !29
  %t84 = icmp sgt i64 %t72, 0
  br i1 %t84, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t86, { i64, ptr } { i64 2, ptr @.d93 })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t88, ptr %t89)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l6, !tbaa !24
  br label %bb22
bb32:
  %t96 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t96, { i64, ptr } { i64 1, ptr @.d94 })
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t99 = load ptr, ptr %l55, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb35, label %bb36
bb35:
  %t102 = load ptr, ptr %l55, !tbaa !29
  %t103 = load i64, ptr %t102
  %t105 = icmp eq i64 %t103, 3
  store i1 %t105, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb37, label %bb38
bb37:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32 }, ptr %t109, i32 0, i32 1
  %t111 = load i32, ptr %t110
  store i32 %t111, ptr %l10, !tbaa !23
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t113, i32 %t114)
  br label %bb40
bb40:
  br label %bb49
bb41:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb42, label %bb43
bb42:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load i64, ptr %t121
  %t124 = icmp eq i64 %t122, 4
  store i1 %t124, ptr %l64, !tbaa !21
  br label %bb43
bb43:
  %t125 = load i1, ptr %l64, !tbaa !21
  br i1 %t125, label %bb44, label %bb45
bb44:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", ptr }, ptr %t128, i32 0, i32 1
  %t130 = load ptr, ptr %t129
  store ptr %t130, ptr %l11, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t132, ptr %t133)
  br label %bb47
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_19d95224243c5dd3_a108b37826b1917)
  unreachable
bb49:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/unparse:writer", ptr %a0, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l41 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 1, ptr @.d95 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 1, ptr @.d96 })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Sig", ptr %t12, i32 0, i32 4
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t17, { i64, ptr } { i64 9, ptr @.d97 })
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/unparse:writer", ptr %t19, i32 0, i32 6
  %t22 = load i1, ptr %t21, !tbaa !21
  store i1 %t22, ptr %l2, !tbaa !21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/unparse:writer", ptr %t24, i32 0, i32 6
  store i1 true, ptr %t26, !tbaa !21
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Sig", ptr %t27, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l4, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t46, ptr %l28, !tbaa !27
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t47
  %t52 = load ptr, ptr %t51, !tbaa !39
  store ptr %t52, ptr %l7, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 2, ptr @.d98 }, ptr %l34, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 1, ptr @.d99 }, ptr %l34, !tbaa !27
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l34, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t59, { i64, ptr } %t60)
  br label %bb15
bb15:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Sig", ptr %t62, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t69 = sub i64 %t67, 1
  %t72 = icmp eq i64 %t61, %t69
  br i1 %t72, label %bb16, label %bb17
bb16:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Sig", ptr %t74, i32 0, i32 2
  %t77 = load i1, ptr %t76, !tbaa !21
  store i1 %t77, ptr %l41, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb18
bb18:
  %t79 = load i1, ptr %l41, !tbaa !21
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l44, !tbaa !29
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t83 = call i1 @compiler_2funparse_2enoErrorsOf(ptr %v1, ptr %t81)
  store i1 %t83, ptr %l46
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t84 = load i1, ptr %l46, !tbaa !21
  %t85 = load ptr, ptr %l44, !tbaa !29
  %t86 = getelementptr %"compiler/unparse:writer", ptr %t85, i32 0, i32 7
  store i1 %t84, ptr %t86, !tbaa !21
  br label %bb22
bb22:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/unparse:writer", ptr %t91, i32 0, i32 7
  store i1 false, ptr %t93, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t94 = load i64, ptr %l4, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l4, !tbaa !24
  br label %bb8
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i1, ptr %l2, !tbaa !21
  %t102 = getelementptr %"compiler/unparse:writer", ptr %t98, i32 0, i32 6
  store i1 %t99, ptr %t102, !tbaa !21
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t103, ptr %t104)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l10, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9c4378154f5f7dac_a032de2992525ef0)
  unreachable
bb3:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9c4378154f5f7dac_a032de2992525ef0)
  unreachable
bb5:
  %t29 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l9, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t37, { i64, ptr } %t36)
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9c4378154f5f7dac_a032de2992525ef0)
  unreachable
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l83 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l140 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca i1
  %l218 = alloca ptr
  %l219 = alloca i1
  %l226 = alloca ptr
  %l228 = alloca { i64, ptr }
  %l235 = alloca ptr
  %l236 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca i1
  %l265 = alloca ptr
  %l266 = alloca i1
  %l282 = alloca ptr
  %l283 = alloca i1
  %l298 = alloca ptr
  %l299 = alloca i1
  %l307 = alloca ptr
  %l308 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t2 = load ptr, ptr %l31, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l31, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l32, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l32, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb220
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t21 = load ptr, ptr %l39, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l39, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l40, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l40, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb220
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t40 = load ptr, ptr %l47, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l47, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l48, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l48, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb26
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Multi", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t54, { i64, ptr } %t58)
  br label %bb20
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l56, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Multi", ptr %t62, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr @.d100 }, ptr %l59, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 3, ptr @.d101 }, ptr %l59, !tbaa !27
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l56, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l59, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t67, { i64, ptr } %t68)
  br label %bb24
bb24:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Multi", ptr %t70, i32 0, i32 2
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t69, { i64, ptr } %t73)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb220
bb26:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t77 = load ptr, ptr %l63, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l63, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l64, !tbaa !21
  br label %bb28
bb28:
  %t84 = load i1, ptr %l64, !tbaa !21
  br i1 %t84, label %bb29, label %bb30
bb29:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l5
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l6, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t99, i32 0, i32 3
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l7, !tbaa !29
  br label %bb31
bb30:
  br label %bb38
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t103, ptr %t104)
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t107, { i64, ptr } { i64 1, ptr @.d102 })
  br label %bb33
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l76, !tbaa !29
  %t110 = load i32, ptr %l5
  %t112 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t110)
  store { i64, ptr } %t112, ptr %l78
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l76, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l78, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t113, { i64, ptr } %t114)
  br label %bb35
bb35:
  %t115 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t115, { i64, ptr } { i64 1, ptr @.d103 })
  br label %bb36
bb36:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb220
bb38:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t122 = load ptr, ptr %l82, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %l82, !tbaa !29
  %t126 = load i64, ptr %t125
  %t128 = icmp eq i64 %t126, 4
  store i1 %t128, ptr %l83, !tbaa !21
  br label %bb40
bb40:
  %t129 = load i1, ptr %l83, !tbaa !21
  br i1 %t129, label %bb41, label %bb42
bb41:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l8, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [5 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t138, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139
  store { i64, ptr } %t140, ptr %l9, !tbaa !27
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [5 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t144, i32 0, i32 3
  %t146 = load i1, ptr %t145
  store i1 %t146, ptr %l10, !tbaa !21
  br label %bb43
bb42:
  br label %bb50
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l92, !tbaa !29
  %t149 = load i1, ptr %l10, !tbaa !21
  br i1 %t149, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 8, ptr @.d104 }, ptr %l94, !tbaa !27
  br label %bb46
bb45:
  store { i64, ptr } { i64 4, ptr @.d105 }, ptr %l94, !tbaa !27
  br label %bb46
bb46:
  %t151 = load ptr, ptr %l92, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l94, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t151, { i64, ptr } %t152)
  br label %bb47
bb47:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t153, ptr %t154)
  br label %bb48
bb48:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t157, { i64, ptr } %t158)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb220
bb50:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t162 = load ptr, ptr %l99, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb51, label %bb52
bb51:
  %t165 = load ptr, ptr %l99, !tbaa !29
  %t166 = load i64, ptr %t165
  %t168 = icmp eq i64 %t166, 5
  store i1 %t168, ptr %l100, !tbaa !21
  br label %bb52
bb52:
  %t169 = load i1, ptr %l100, !tbaa !21
  br i1 %t169, label %bb53, label %bb54
bb53:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", ptr }, ptr %t172, i32 0, i32 1
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l11, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %t176, ptr %t177)
  br label %bb56
bb56:
  br label %bb220
bb57:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t181 = load ptr, ptr %l107, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb58, label %bb59
bb58:
  %t184 = load ptr, ptr %l107, !tbaa !29
  %t185 = load i64, ptr %t184
  %t187 = icmp eq i64 %t185, 6
  store i1 %t187, ptr %l108, !tbaa !21
  br label %bb59
bb59:
  %t188 = load i1, ptr %l108, !tbaa !21
  br i1 %t188, label %bb60, label %bb61
bb60:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t191, i32 0, i32 1
  %t193 = load { i64, ptr }, ptr %t192
  store { i64, ptr } %t193, ptr %l12, !tbaa !27
  br label %bb62
bb61:
  br label %bb65
bb62:
  store %olang.scope zeroinitializer, ptr %s7
  %t195 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t195, { i64, ptr } { i64 4, ptr @.d106 })
  br label %bb63
bb63:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t197, { i64, ptr } %t198)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb220
bb65:
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t202 = load ptr, ptr %l116, !tbaa !29
  %t203 = icmp ne ptr %t202, null
  br i1 %t203, label %bb66, label %bb67
bb66:
  %t205 = load ptr, ptr %l116, !tbaa !29
  %t206 = load i64, ptr %t205
  %t208 = icmp eq i64 %t206, 7
  store i1 %t208, ptr %l117, !tbaa !21
  br label %bb67
bb67:
  %t209 = load i1, ptr %l117, !tbaa !21
  br i1 %t209, label %bb68, label %bb69
bb68:
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t212, i32 0, i32 1
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l13, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t218, i32 0, i32 2
  %t220 = load { i64, ptr }, ptr %t219
  store { i64, ptr } %t220, ptr %l14, !tbaa !27
  br label %bb70
bb69:
  br label %bb74
bb70:
  store %olang.scope zeroinitializer, ptr %s8
  %t222 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t222, { i64, ptr } { i64 4, ptr @.d107 })
  br label %bb71
bb71:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t224, ptr %t225)
  br label %bb72
bb72:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t228, { i64, ptr } %t229)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s8)
  br label %bb220
bb74:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t233 = load ptr, ptr %l129, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb75, label %bb76
bb75:
  %t236 = load ptr, ptr %l129, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 8
  store i1 %t239, ptr %l130, !tbaa !21
  br label %bb76
bb76:
  %t240 = load i1, ptr %l130, !tbaa !21
  br i1 %t240, label %bb77, label %bb78
bb77:
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 1
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l15, !tbaa !29
  br label %bb79
bb78:
  br label %bb90
bb79:
  store %olang.scope zeroinitializer, ptr %s9
  %t247 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t247, { i64, ptr } { i64 4, ptr @.d108 })
  br label %bb80
bb80:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load ptr, ptr %l15, !tbaa !29
  %t252 = getelementptr %"compiler/ast:For3", ptr %t250, i32 0, i32 0
  %t253 = load ptr, ptr %t252, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t249, ptr %t253)
  br label %bb81
bb81:
  %t256 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t256, { i64, ptr } { i64 2, ptr @.d109 })
  br label %bb82
bb82:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l140, !tbaa !29
  %t259 = load ptr, ptr %l15, !tbaa !29
  %t261 = getelementptr %"compiler/ast:For3", ptr %t259, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !29
  %t264 = icmp eq ptr %t262, null
  br i1 %t264, label %bb83, label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_b263a57856eac862_46b7b1031f9001a6)
  unreachable
bb84:
  br label %bb85
bb85:
  %t266 = load ptr, ptr %l15, !tbaa !29
  %t268 = getelementptr %"compiler/ast:For3", ptr %t266, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t270 = load ptr, ptr %l140, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t270, ptr %t269)
  br label %bb86
bb86:
  %t272 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t272, { i64, ptr } { i64 2, ptr @.d110 })
  br label %bb87
bb87:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l15, !tbaa !29
  %t277 = getelementptr %"compiler/ast:For3", ptr %t275, i32 0, i32 2
  %t278 = load ptr, ptr %t277, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t274, ptr %t278)
  br label %bb88
bb88:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l15, !tbaa !29
  %t284 = getelementptr %"compiler/ast:For3", ptr %t282, i32 0, i32 3
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t281, { i64, ptr } %t285)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s9)
  br label %bb220
bb90:
  %t288 = load ptr, ptr %l1, !tbaa !29
  store ptr %t288, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t289 = load ptr, ptr %l153, !tbaa !29
  %t290 = icmp ne ptr %t289, null
  br i1 %t290, label %bb91, label %bb92
bb91:
  %t292 = load ptr, ptr %l153, !tbaa !29
  %t293 = load i64, ptr %t292
  %t295 = icmp eq i64 %t293, 9
  store i1 %t295, ptr %l154, !tbaa !21
  br label %bb92
bb92:
  %t296 = load i1, ptr %l154, !tbaa !21
  br i1 %t296, label %bb93, label %bb94
bb93:
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr { i64, [5 x i64] }, ptr %t297, i32 0, i32 1
  %t300 = getelementptr { %"compiler/source:Span", ptr }, ptr %t299, i32 0, i32 1
  %t301 = load ptr, ptr %t300
  store ptr %t301, ptr %l16, !tbaa !29
  br label %bb95
bb94:
  br label %bb111
bb95:
  store %olang.scope zeroinitializer, ptr %s10
  %t303 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t303, { i64, ptr } { i64 4, ptr @.d111 })
  br label %bb96
bb96:
  %t305 = load ptr, ptr %l16, !tbaa !29
  %t307 = getelementptr %"compiler/ast:ForIn", ptr %t305, i32 0, i32 0
  %t308 = load i32, ptr %t307, !tbaa !23
  %t310 = icmp ne i32 %t308, 0
  br i1 %t310, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s11
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load ptr, ptr %l16, !tbaa !29
  %t315 = getelementptr %"compiler/ast:ForIn", ptr %t313, i32 0, i32 0
  %t316 = load i32, ptr %t315, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t312, i32 %t316)
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t319 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t319, { i64, ptr } { i64 2, ptr @.d112 })
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s11)
  br label %bb101
bb101:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l16, !tbaa !29
  %t324 = getelementptr %"compiler/ast:ForIn", ptr %t322, i32 0, i32 1
  %t325 = load i32, ptr %t324, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t321, i32 %t325)
  br label %bb102
bb102:
  %t328 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t328, { i64, ptr } { i64 4, ptr @.d113 })
  br label %bb103
bb103:
  %t330 = load ptr, ptr %l16, !tbaa !29
  %t332 = getelementptr %"compiler/ast:ForIn", ptr %t330, i32 0, i32 3
  %t333 = load i1, ptr %t332, !tbaa !21
  br i1 %t333, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s12
  %t335 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t335, { i64, ptr } { i64 4, ptr @.d114 })
  br label %bb106
bb105:
  br label %bb107
bb106:
  call void @__olang_scope_close(ptr %s12)
  br label %bb107
bb107:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load ptr, ptr %l16, !tbaa !29
  %t340 = getelementptr %"compiler/ast:ForIn", ptr %t338, i32 0, i32 2
  %t341 = load ptr, ptr %t340, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t337, ptr %t341)
  br label %bb108
bb108:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l16, !tbaa !29
  %t347 = getelementptr %"compiler/ast:ForIn", ptr %t345, i32 0, i32 4
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t344, { i64, ptr } %t348)
  br label %bb109
bb109:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load ptr, ptr %l16, !tbaa !29
  %t354 = getelementptr %"compiler/ast:ForIn", ptr %t352, i32 0, i32 5
  %t355 = load { i64, ptr }, ptr %t354, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t351, { i64, ptr } %t355)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s10)
  br label %bb220
bb111:
  %t358 = load ptr, ptr %l1, !tbaa !29
  store ptr %t358, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t359 = load ptr, ptr %l183, !tbaa !29
  %t360 = icmp ne ptr %t359, null
  br i1 %t360, label %bb112, label %bb113
bb112:
  %t362 = load ptr, ptr %l183, !tbaa !29
  %t363 = load i64, ptr %t362
  %t365 = icmp eq i64 %t363, 10
  store i1 %t365, ptr %l184, !tbaa !21
  br label %bb113
bb113:
  %t366 = load i1, ptr %l184, !tbaa !21
  br i1 %t366, label %bb114, label %bb115
bb114:
  %t367 = load ptr, ptr %l1, !tbaa !29
  %t369 = getelementptr { i64, [5 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t369, i32 0, i32 1
  %t371 = load { i64, ptr }, ptr %t370
  store { i64, ptr } %t371, ptr %l17, !tbaa !27
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [5 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t375, i32 0, i32 2
  %t377 = load ptr, ptr %t376
  store ptr %t377, ptr %l18, !tbaa !29
  br label %bb116
bb115:
  br label %bb121
bb116:
  store %olang.scope zeroinitializer, ptr %s13
  %t379 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t379, { i64, ptr } { i64 3, ptr @.d115 })
  br label %bb117
bb117:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t381, { i64, ptr } %t382)
  br label %bb118
bb118:
  %t385 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t385, { i64, ptr } { i64 5, ptr @.d116 })
  br label %bb119
bb119:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t387, ptr %t388)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s13)
  br label %bb220
bb121:
  %t391 = load ptr, ptr %l1, !tbaa !29
  store ptr %t391, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t392 = load ptr, ptr %l197, !tbaa !29
  %t393 = icmp ne ptr %t392, null
  br i1 %t393, label %bb122, label %bb123
bb122:
  %t395 = load ptr, ptr %l197, !tbaa !29
  %t396 = load i64, ptr %t395
  %t398 = icmp eq i64 %t396, 11
  store i1 %t398, ptr %l198, !tbaa !21
  br label %bb123
bb123:
  %t399 = load i1, ptr %l198, !tbaa !21
  br i1 %t399, label %bb124, label %bb125
bb124:
  %t400 = load ptr, ptr %l1, !tbaa !29
  %t402 = getelementptr { i64, [5 x i64] }, ptr %t400, i32 0, i32 1
  %t403 = getelementptr { %"compiler/source:Span", ptr }, ptr %t402, i32 0, i32 1
  %t404 = load ptr, ptr %t403
  store ptr %t404, ptr %l19, !tbaa !29
  br label %bb126
bb125:
  br label %bb128
bb126:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t406, ptr %t407)
  br label %bb127
bb127:
  br label %bb220
bb128:
  %t410 = load ptr, ptr %l1, !tbaa !29
  store ptr %t410, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t411 = load ptr, ptr %l205, !tbaa !29
  %t412 = icmp ne ptr %t411, null
  br i1 %t412, label %bb129, label %bb130
bb129:
  %t414 = load ptr, ptr %l205, !tbaa !29
  %t415 = load i64, ptr %t414
  %t417 = icmp eq i64 %t415, 12
  store i1 %t417, ptr %l206, !tbaa !21
  br label %bb130
bb130:
  %t418 = load i1, ptr %l206, !tbaa !21
  br i1 %t418, label %bb131, label %bb132
bb131:
  %t419 = load ptr, ptr %l1, !tbaa !29
  %t421 = getelementptr { i64, [5 x i64] }, ptr %t419, i32 0, i32 1
  %t422 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t421, i32 0, i32 1
  %t423 = load { i64, ptr }, ptr %t422
  store { i64, ptr } %t423, ptr %l20, !tbaa !27
  br label %bb133
bb132:
  br label %bb140
bb133:
  store %olang.scope zeroinitializer, ptr %s15
  %t425 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t425, { i64, ptr } { i64 6, ptr @.d117 })
  br label %bb134
bb134:
  %t427 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t429 = extractvalue { i64, ptr } %t427, 0
  %t431 = icmp sgt i64 %t429, 0
  br i1 %t431, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s16
  %t433 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t433, { i64, ptr } { i64 1, ptr @.d118 })
  br label %bb137
bb136:
  br label %bb139
bb137:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t435, { i64, ptr } %t436)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s16)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s15)
  br label %bb220
bb140:
  %t439 = load ptr, ptr %l1, !tbaa !29
  store ptr %t439, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t440 = load ptr, ptr %l218, !tbaa !29
  %t441 = icmp ne ptr %t440, null
  br i1 %t441, label %bb141, label %bb142
bb141:
  %t443 = load ptr, ptr %l218, !tbaa !29
  %t444 = load i64, ptr %t443
  %t446 = icmp eq i64 %t444, 13
  store i1 %t446, ptr %l219, !tbaa !21
  br label %bb142
bb142:
  %t447 = load i1, ptr %l219, !tbaa !21
  br i1 %t447, label %bb143, label %bb144
bb143:
  %t448 = load ptr, ptr %l1, !tbaa !29
  %t450 = getelementptr { i64, [5 x i64] }, ptr %t448, i32 0, i32 1
  %t451 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t450, i32 0, i32 1
  %t452 = load i32, ptr %t451
  store i32 %t452, ptr %l21
  %t454 = load ptr, ptr %l1, !tbaa !29
  %t456 = getelementptr { i64, [5 x i64] }, ptr %t454, i32 0, i32 1
  %t457 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t456, i32 0, i32 2
  %t458 = load ptr, ptr %t457
  store ptr %t458, ptr %l22, !tbaa !29
  br label %bb145
bb144:
  br label %bb153
bb145:
  store %olang.scope zeroinitializer, ptr %s17
  %t460 = load ptr, ptr %l0, !tbaa !29
  store ptr %t460, ptr %l226, !tbaa !29
  %t461 = load i32, ptr %l21
  %t463 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s17, i32 %t461)
  store { i64, ptr } %t463, ptr %l228
  br label %bb146
bb146:
  %t464 = load ptr, ptr %l226, !tbaa !29
  %t465 = load { i64, ptr }, ptr %l228, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t464, { i64, ptr } %t465)
  br label %bb147
bb147:
  %t466 = load ptr, ptr %l22, !tbaa !29
  %t468 = icmp eq ptr %t466, null
  %t470 = xor i1 %t468, true
  br i1 %t470, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s18
  %t472 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t472, { i64, ptr } { i64 1, ptr @.d119 })
  br label %bb150
bb149:
  br label %bb152
bb150:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t474, ptr %t475)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s18)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s17)
  br label %bb220
bb153:
  %t478 = load ptr, ptr %l1, !tbaa !29
  store ptr %t478, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t479 = load ptr, ptr %l235, !tbaa !29
  %t480 = icmp ne ptr %t479, null
  br i1 %t480, label %bb154, label %bb155
bb154:
  %t482 = load ptr, ptr %l235, !tbaa !29
  %t483 = load i64, ptr %t482
  %t485 = icmp eq i64 %t483, 14
  store i1 %t485, ptr %l236, !tbaa !21
  br label %bb155
bb155:
  %t486 = load i1, ptr %l236, !tbaa !21
  br i1 %t486, label %bb156, label %bb157
bb156:
  %t487 = load ptr, ptr %l1, !tbaa !29
  %t489 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 1
  %t490 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t489, i32 0, i32 1
  %t491 = load ptr, ptr %t490
  store ptr %t491, ptr %l23, !tbaa !29
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t495 = getelementptr { i64, [5 x i64] }, ptr %t493, i32 0, i32 1
  %t496 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t495, i32 0, i32 2
  %t497 = load ptr, ptr %t496
  store ptr %t497, ptr %l24, !tbaa !29
  br label %bb158
bb157:
  br label %bb166
bb158:
  store %olang.scope zeroinitializer, ptr %s19
  %t499 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t499, { i64, ptr } { i64 7, ptr @.d120 })
  br label %bb159
bb159:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t501, ptr %t502)
  br label %bb160
bb160:
  %t505 = load ptr, ptr %l24, !tbaa !29
  %t507 = icmp eq ptr %t505, null
  %t509 = xor i1 %t507, true
  br i1 %t509, label %bb161, label %bb162
bb161:
  store %olang.scope zeroinitializer, ptr %s20
  %t511 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t511, { i64, ptr } { i64 2, ptr @.d121 })
  br label %bb163
bb162:
  br label %bb165
bb163:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t513, ptr %t514)
  br label %bb164
bb164:
  call void @__olang_scope_close(ptr %s20)
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s19)
  br label %bb220
bb166:
  %t517 = load ptr, ptr %l1, !tbaa !29
  store ptr %t517, ptr %l252, !tbaa !29
  store i1 false, ptr %l253, !tbaa !21
  %t518 = load ptr, ptr %l252, !tbaa !29
  %t519 = icmp ne ptr %t518, null
  br i1 %t519, label %bb167, label %bb168
bb167:
  %t521 = load ptr, ptr %l252, !tbaa !29
  %t522 = load i64, ptr %t521
  %t524 = icmp eq i64 %t522, 15
  store i1 %t524, ptr %l253, !tbaa !21
  br label %bb168
bb168:
  %t525 = load i1, ptr %l253, !tbaa !21
  br i1 %t525, label %bb169, label %bb170
bb169:
  %t526 = load ptr, ptr %l1, !tbaa !29
  %t528 = getelementptr { i64, [5 x i64] }, ptr %t526, i32 0, i32 1
  %t529 = getelementptr { %"compiler/source:Span", ptr }, ptr %t528, i32 0, i32 1
  %t530 = load ptr, ptr %t529
  store ptr %t530, ptr %l25, !tbaa !29
  br label %bb171
bb170:
  br label %bb178
bb171:
  store %olang.scope zeroinitializer, ptr %s21
  %t532 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t532, { i64, ptr } { i64 5, ptr @.d122 })
  br label %bb172
bb172:
  %t534 = load ptr, ptr %l25, !tbaa !29
  %t536 = icmp eq ptr %t534, null
  %t538 = xor i1 %t536, true
  br i1 %t538, label %bb173, label %bb174
bb173:
  store %olang.scope zeroinitializer, ptr %s22
  %t540 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t540, { i64, ptr } { i64 1, ptr @.d123 })
  br label %bb175
bb174:
  br label %bb177
bb175:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t542, ptr %t543)
  br label %bb176
bb176:
  call void @__olang_scope_close(ptr %s22)
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s21)
  br label %bb220
bb178:
  %t546 = load ptr, ptr %l1, !tbaa !29
  store ptr %t546, ptr %l265, !tbaa !29
  store i1 false, ptr %l266, !tbaa !21
  %t547 = load ptr, ptr %l265, !tbaa !29
  %t548 = icmp ne ptr %t547, null
  br i1 %t548, label %bb179, label %bb180
bb179:
  %t550 = load ptr, ptr %l265, !tbaa !29
  %t551 = load i64, ptr %t550
  %t553 = icmp eq i64 %t551, 16
  store i1 %t553, ptr %l266, !tbaa !21
  br label %bb180
bb180:
  %t554 = load i1, ptr %l266, !tbaa !21
  br i1 %t554, label %bb181, label %bb182
bb181:
  %t555 = load ptr, ptr %l1, !tbaa !29
  %t557 = getelementptr { i64, [5 x i64] }, ptr %t555, i32 0, i32 1
  %t558 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t557, i32 0, i32 1
  %t559 = load { i64, ptr }, ptr %t558
  store { i64, ptr } %t559, ptr %l26, !tbaa !27
  %t561 = load ptr, ptr %l1, !tbaa !29
  %t563 = getelementptr { i64, [5 x i64] }, ptr %t561, i32 0, i32 1
  %t564 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t563, i32 0, i32 2
  %t565 = load ptr, ptr %t564
  store ptr %t565, ptr %l27, !tbaa !29
  br label %bb183
bb182:
  br label %bb191
bb183:
  store %olang.scope zeroinitializer, ptr %s23
  %t567 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t567, { i64, ptr } { i64 6, ptr @.d124 })
  br label %bb184
bb184:
  %t569 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t571 = extractvalue { i64, ptr } %t569, 0
  %t573 = icmp sgt i64 %t571, 0
  br i1 %t573, label %bb185, label %bb186
bb185:
  store %olang.scope zeroinitializer, ptr %s24
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t576 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t575, { i64, ptr } %t576)
  br label %bb187
bb186:
  br label %bb189
bb187:
  %t579 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t579, { i64, ptr } { i64 3, ptr @.d125 })
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s24)
  br label %bb189
bb189:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t581, ptr %t582)
  br label %bb190
bb190:
  call void @__olang_scope_close(ptr %s23)
  br label %bb220
bb191:
  %t585 = load ptr, ptr %l1, !tbaa !29
  store ptr %t585, ptr %l282, !tbaa !29
  store i1 false, ptr %l283, !tbaa !21
  %t586 = load ptr, ptr %l282, !tbaa !29
  %t587 = icmp ne ptr %t586, null
  br i1 %t587, label %bb192, label %bb193
bb192:
  %t589 = load ptr, ptr %l282, !tbaa !29
  %t590 = load i64, ptr %t589
  %t592 = icmp eq i64 %t590, 17
  store i1 %t592, ptr %l283, !tbaa !21
  br label %bb193
bb193:
  %t593 = load i1, ptr %l283, !tbaa !21
  br i1 %t593, label %bb194, label %bb195
bb194:
  %t594 = load ptr, ptr %l1, !tbaa !29
  %t596 = getelementptr { i64, [5 x i64] }, ptr %t594, i32 0, i32 1
  %t597 = getelementptr { %"compiler/source:Span", ptr }, ptr %t596, i32 0, i32 1
  %t598 = load ptr, ptr %t597
  store ptr %t598, ptr %l28, !tbaa !29
  br label %bb196
bb195:
  br label %bb204
bb196:
  store %olang.scope zeroinitializer, ptr %s25
  %t600 = load ptr, ptr %l28, !tbaa !29
  %t602 = getelementptr %"compiler/ast:JoinS", ptr %t600, i32 0, i32 0
  %t603 = load i1, ptr %t602, !tbaa !21
  br i1 %t603, label %bb197, label %bb198
bb197:
  store %olang.scope zeroinitializer, ptr %s26
  %t605 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t605, { i64, ptr } { i64 4, ptr @.d126 })
  br label %bb199
bb198:
  br label %bb200
bb199:
  call void @__olang_scope_close(ptr %s26)
  br label %bb200
bb200:
  %t607 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t607, { i64, ptr } { i64 5, ptr @.d127 })
  br label %bb201
bb201:
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t610 = load ptr, ptr %l28, !tbaa !29
  %t612 = getelementptr %"compiler/ast:JoinS", ptr %t610, i32 0, i32 1
  %t613 = load { i64, ptr }, ptr %t612, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t609, { i64, ptr } %t613)
  br label %bb202
bb202:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t617 = load ptr, ptr %l28, !tbaa !29
  %t619 = getelementptr %"compiler/ast:JoinS", ptr %t617, i32 0, i32 2
  %t620 = load { i64, ptr }, ptr %t619, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t616, { i64, ptr } %t620)
  br label %bb203
bb203:
  call void @__olang_scope_close(ptr %s25)
  br label %bb220
bb204:
  %t623 = load ptr, ptr %l1, !tbaa !29
  store ptr %t623, ptr %l298, !tbaa !29
  store i1 false, ptr %l299, !tbaa !21
  %t624 = load ptr, ptr %l298, !tbaa !29
  %t625 = icmp ne ptr %t624, null
  br i1 %t625, label %bb205, label %bb206
bb205:
  %t627 = load ptr, ptr %l298, !tbaa !29
  %t628 = load i64, ptr %t627
  %t630 = icmp eq i64 %t628, 18
  store i1 %t630, ptr %l299, !tbaa !21
  br label %bb206
bb206:
  %t631 = load i1, ptr %l299, !tbaa !21
  br i1 %t631, label %bb207, label %bb208
bb207:
  %t632 = load ptr, ptr %l1, !tbaa !29
  %t634 = getelementptr { i64, [5 x i64] }, ptr %t632, i32 0, i32 1
  %t635 = getelementptr { %"compiler/source:Span", ptr }, ptr %t634, i32 0, i32 1
  %t636 = load ptr, ptr %t635
  store ptr %t636, ptr %l29, !tbaa !29
  br label %bb209
bb208:
  br label %bb212
bb209:
  store %olang.scope zeroinitializer, ptr %s27
  %t638 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s27, ptr %t638, { i64, ptr } { i64 6, ptr @.d128 })
  br label %bb210
bb210:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t641 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t640, ptr %t641)
  br label %bb211
bb211:
  call void @__olang_scope_close(ptr %s27)
  br label %bb220
bb212:
  %t644 = load ptr, ptr %l1, !tbaa !29
  store ptr %t644, ptr %l307, !tbaa !29
  store i1 false, ptr %l308, !tbaa !21
  %t645 = load ptr, ptr %l307, !tbaa !29
  %t646 = icmp ne ptr %t645, null
  br i1 %t646, label %bb213, label %bb214
bb213:
  %t648 = load ptr, ptr %l307, !tbaa !29
  %t649 = load i64, ptr %t648
  %t651 = icmp eq i64 %t649, 19
  store i1 %t651, ptr %l308, !tbaa !21
  br label %bb214
bb214:
  %t652 = load i1, ptr %l308, !tbaa !21
  br i1 %t652, label %bb215, label %bb216
bb215:
  %t653 = load ptr, ptr %l1, !tbaa !29
  %t655 = getelementptr { i64, [5 x i64] }, ptr %t653, i32 0, i32 1
  %t656 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t655, i32 0, i32 1
  %t657 = load { i64, ptr }, ptr %t656
  store { i64, ptr } %t657, ptr %l30, !tbaa !27
  br label %bb217
bb216:
  br label %bb219
bb217:
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t660 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t659, { i64, ptr } %t660)
  br label %bb218
bb218:
  br label %bb220
bb219:
  call void @__olang_check_failed(ptr @olang_loc_9166140a1ac8280_ddd22134593fa34)
  unreachable
bb220:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l38 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopBranch", ptr %t5, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t4, i64 %t8)
  store i1 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopBranch", ptr %t14, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t13, %"compiler/source:Span" %t17)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TopBranch", ptr %t23, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t22, %"compiler/source:Span" %t26)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t29, { i64, ptr } { i64 1, ptr @.d129 })
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = getelementptr %"compiler/unparse:writer", ptr %t32, i32 0, i32 4
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = add i64 %t34, 1
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = getelementptr %"compiler/unparse:writer", ptr %t38, i32 0, i32 4
  store i64 %t36, ptr %t39, !tbaa !24
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  store ptr %t63, ptr %l5, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t65)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l3, !tbaa !24
  br label %bb8
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l38, !tbaa !29
  %t76 = load ptr, ptr %l38, !tbaa !29
  %t77 = getelementptr %"compiler/unparse:writer", ptr %t76, i32 0, i32 4
  %t78 = load i64, ptr %t77, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"compiler/unparse:writer", ptr %t82, i32 0, i32 4
  store i64 %t80, ptr %t83, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t84)
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t86, { i64, ptr } { i64 1, ptr @.d130 })
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l10 = alloca ptr
  %l21 = alloca ptr
  %l32 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr @.d131 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:TopIf", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_69b21e264e8a714a_b3e97d9d77526506)
  unreachable
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:TopIf", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t15, ptr %t14)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t17, { i64, ptr } { i64 1, ptr @.d132 })
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:TopIf", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8585d6fe8f316a51_b60a12ce50df87ed)
  unreachable
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TopIf", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t31, ptr %t30)
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/ast:TopIf", ptr %t33, i32 0, i32 2
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t42, { i64, ptr } { i64 6, ptr @.d133 })
  br label %bb13
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TopIf", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = icmp eq ptr %t47, null
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb18, label %bb19
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l21, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:TopIf", ptr %t54, i32 0, i32 2
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_eabe3ddcfaef285c_106dba970e52f8d8)
  unreachable
bb15:
  br label %bb16
bb16:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:TopIf", ptr %t61, i32 0, i32 2
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t65, ptr %t64)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t67, { i64, ptr } { i64 6, ptr @.d134 })
  br label %bb20
bb19:
  br label %bb25
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l32, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/ast:TopIf", ptr %t70, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_14b8182deed7e34b_cfe8cf3ea4c448f7)
  unreachable
bb22:
  br label %bb23
bb23:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/ast:TopIf", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t81, ptr %t80)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l35 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l68 = alloca i1
  %l74 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l106 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l114 = alloca i1
  %l126 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t2 = load ptr, ptr %l19, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l19, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l20, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb23
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t38, ptr %l35, !tbaa !27
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i32, ptr %t42, i64 %t39
  %t44 = load i32, ptr %t43, !tbaa !33
  store i32 %t44, ptr %l8, !tbaa !23
  %t48 = icmp sgt i64 %t36, 0
  br i1 %t48, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t50, { i64, ptr } { i64 1, ptr @.d135 })
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t52, i32 %t53)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb6
bb16:
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t66 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t66, { i64, ptr } { i64 1, ptr @.d136 })
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t68, { i64, ptr } %t69)
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t72, { i64, ptr } { i64 1, ptr @.d137 })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  br label %bb96
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t75 = load ptr, ptr %l52, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l52, !tbaa !29
  %t79 = load i64, ptr %t78
  %t81 = icmp eq i64 %t79, 1
  store i1 %t81, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l53, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l9, !tbaa !29
  br label %bb28
bb27:
  br label %bb47
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/unparse:writer", ptr %t89, i32 0, i32 7
  %t92 = load i1, ptr %t91, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb37
bb30:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/unparse:writer", ptr %t94, i32 0, i32 6
  %t97 = load i1, ptr %t96, !tbaa !21
  br i1 %t97, label %bb31, label %bb32
bb31:
  %t99 = load ptr, ptr %l9, !tbaa !29
  %t101 = getelementptr %"compiler/ast:Sig", ptr %t99, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t106 = icmp sgt i64 %t104, 1
  br i1 %t106, label %bb33, label %bb34
bb32:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb36
bb33:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb35
bb34:
  %t108 = load ptr, ptr %l9, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Sig", ptr %t108, i32 0, i32 3
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t115 = icmp sgt i64 %t113, 1
  store i1 %t115, ptr %l68, !tbaa !21
  br label %bb35
bb35:
  %t117 = load i1, ptr %l68, !tbaa !21
  store i1 %t117, ptr %l63, !tbaa !21
  br label %bb36
bb36:
  %t118 = load i1, ptr %l63, !tbaa !21
  store i1 %t118, ptr %l60, !tbaa !21
  br label %bb37
bb37:
  %t119 = load i1, ptr %l60, !tbaa !21
  store i1 %t119, ptr %l10, !tbaa !21
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/unparse:writer", ptr %t120, i32 0, i32 7
  store i1 false, ptr %t122, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l74, !tbaa !29
  %t124 = load i1, ptr %l10, !tbaa !21
  br i1 %t124, label %bb38, label %bb39
bb38:
  store { i64, ptr } { i64 3, ptr @.d138 }, ptr %l76, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 2, ptr @.d139 }, ptr %l76, !tbaa !27
  br label %bb40
bb40:
  %t126 = load ptr, ptr %l74, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l76, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t126, { i64, ptr } %t127)
  br label %bb41
bb41:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/unparse:writer", ptr %t128, i32 0, i32 6
  %t131 = load i1, ptr %t130, !tbaa !21
  store i1 %t131, ptr %l11, !tbaa !21
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/unparse:writer", ptr %t133, i32 0, i32 6
  store i1 false, ptr %t135, !tbaa !21
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t136, ptr %t137)
  br label %bb42
bb42:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i1, ptr %l11, !tbaa !21
  %t144 = getelementptr %"compiler/unparse:writer", ptr %t140, i32 0, i32 6
  store i1 %t141, ptr %t144, !tbaa !21
  %t145 = load i1, ptr %l10, !tbaa !21
  br i1 %t145, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t147, { i64, ptr } { i64 1, ptr @.d140 })
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb96
bb47:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t150 = load ptr, ptr %l86, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb48, label %bb49
bb48:
  %t153 = load ptr, ptr %l86, !tbaa !29
  %t154 = load i64, ptr %t153
  %t156 = icmp eq i64 %t154, 2
  store i1 %t156, ptr %l87, !tbaa !21
  br label %bb49
bb49:
  %t157 = load i1, ptr %l87, !tbaa !21
  br i1 %t157, label %bb50, label %bb51
bb50:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l12, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t164, ptr %t165)
  br label %bb53
bb53:
  br label %bb96
bb54:
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t169 = load ptr, ptr %l94, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb55, label %bb56
bb55:
  %t172 = load ptr, ptr %l94, !tbaa !29
  %t173 = load i64, ptr %t172
  %t175 = icmp eq i64 %t173, 3
  store i1 %t175, ptr %l95, !tbaa !21
  br label %bb56
bb56:
  %t176 = load i1, ptr %l95, !tbaa !21
  br i1 %t176, label %bb57, label %bb58
bb57:
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t179, i32 0, i32 1
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l13, !tbaa !29
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t185, i32 0, i32 2
  %t187 = load i32, ptr %t186
  store i32 %t187, ptr %l14, !tbaa !23
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t191, i32 0, i32 3
  %t193 = load i1, ptr %t192
  store i1 %t193, ptr %l15, !tbaa !21
  br label %bb59
bb58:
  br label %bb69
bb59:
  store %olang.scope zeroinitializer, ptr %s10
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t195, ptr %t196)
  br label %bb60
bb60:
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l106, !tbaa !29
  %t200 = load i1, ptr %l15, !tbaa !21
  br i1 %t200, label %bb61, label %bb62
bb61:
  store { i64, ptr } { i64 2, ptr @.d141 }, ptr %l108, !tbaa !27
  br label %bb63
bb62:
  store { i64, ptr } { i64 1, ptr @.d142 }, ptr %l108, !tbaa !27
  br label %bb63
bb63:
  %t202 = load ptr, ptr %l106, !tbaa !29
  %t203 = load { i64, ptr }, ptr %l108, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t202, { i64, ptr } %t203)
  br label %bb64
bb64:
  %t204 = load i32, ptr %l14, !tbaa !23
  %t206 = icmp ne i32 %t204, 0
  br i1 %t206, label %bb65, label %bb66
bb65:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t208, i32 %t209)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s10)
  br label %bb96
bb69:
  %t212 = load ptr, ptr %l1, !tbaa !29
  store ptr %t212, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t213 = load ptr, ptr %l113, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb70, label %bb71
bb70:
  %t216 = load ptr, ptr %l113, !tbaa !29
  %t217 = load i64, ptr %t216
  %t219 = icmp eq i64 %t217, 4
  store i1 %t219, ptr %l114, !tbaa !21
  br label %bb71
bb71:
  %t220 = load i1, ptr %l114, !tbaa !21
  br i1 %t220, label %bb72, label %bb73
bb72:
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t223, i32 0, i32 1
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l16, !tbaa !29
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr { i64, [5 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t229, i32 0, i32 2
  %t231 = load i1, ptr %t230
  store i1 %t231, ptr %l17, !tbaa !21
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [5 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t235, i32 0, i32 3
  %t237 = load i1, ptr %t236
  store i1 %t237, ptr %l18, !tbaa !21
  br label %bb74
bb73:
  br label %bb95
bb74:
  %t239 = load i1, ptr %l18, !tbaa !21
  br i1 %t239, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s13
  %t241 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t241, { i64, ptr } { i64 3, ptr @.d143 })
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_scope_close(ptr %s13)
  br label %bb78
bb78:
  %t243 = load i1, ptr %l18, !tbaa !21
  br i1 %t243, label %bb79, label %bb80
bb79:
  %t245 = load i1, ptr %l17, !tbaa !21
  store i1 %t245, ptr %l126, !tbaa !21
  br label %bb81
bb80:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb81
bb81:
  %t247 = load i1, ptr %l126, !tbaa !21
  br i1 %t247, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s14
  %t248 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t248, { i64, ptr } { i64 1, ptr @.d144 })
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_scope_close(ptr %s14)
  br label %bb85
bb85:
  %t250 = load i1, ptr %l17, !tbaa !21
  br i1 %t250, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s15
  %t252 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t252, { i64, ptr } { i64 3, ptr @.d145 })
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_scope_close(ptr %s15)
  br label %bb89
bb89:
  %t254 = load ptr, ptr %l16, !tbaa !29
  %t256 = icmp eq ptr %t254, null
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s16
  %t260 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t260, { i64, ptr } { i64 1, ptr @.d146 })
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t262, ptr %t263)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s16)
  br label %bb94
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_9034b6aed20fb51a_d179ca40c5e654ce)
  unreachable
bb96:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l43 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i1
  %l67 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i1
  %l134 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l169 = alloca ptr
  %l179 = alloca { i64, ptr }
  %l196 = alloca ptr
  %l201 = alloca ptr
  %l202 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t2 = load ptr, ptr %l28, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l28, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l29, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l29, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [6 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t16, { i64, ptr } { i64 6, ptr @.d147 })
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:StructBody", ptr %t19, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t18, { i64, ptr } %t22)
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t25, { i64, ptr } { i64 1, ptr @.d148 })
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/ast:StructBody", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t27, { i64, ptr } %t31)
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t34, { i64, ptr } { i64 1, ptr @.d149 })
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l43, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:StructBody", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  br i1 %t42, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8cd05a7785ffddf0_abfc69165374635c)
  unreachable
bb12:
  br label %bb13
bb13:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/ast:StructBody", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t48, ptr %t47)
  br label %bb14
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t50, { i64, ptr } { i64 1, ptr @.d150 })
  br label %bb15
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:StructBody", ptr %t53, i32 0, i32 2
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t52, { i64, ptr } %t56)
  br label %bb16
bb16:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/ast:StructBody", ptr %t59, i32 0, i32 3
  %t62 = getelementptr %"compiler/source:Span", ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62, !tbaa !23
  %t65 = icmp sgt i32 %t63, 0
  br i1 %t65, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t67 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t67, { i64, ptr } { i64 10, ptr @.d151 })
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t72 = getelementptr %"compiler/ast:StructBody", ptr %t70, i32 0, i32 4
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t69, { i64, ptr } %t73)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb125
bb22:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t77 = load ptr, ptr %l60, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb23, label %bb24
bb23:
  %t80 = load ptr, ptr %l60, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 1
  store i1 %t83, ptr %l61, !tbaa !21
  br label %bb24
bb24:
  %t84 = load i1, ptr %l61, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [6 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { { i64, ptr } }, ptr %t87, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88
  store { i64, ptr } %t89, ptr %l3, !tbaa !27
  br label %bb27
bb26:
  br label %bb53
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t91 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t91, { i64, ptr } { i64 6, ptr @.d152 })
  br label %bb28
bb28:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l67, !tbaa !29
  %t94 = load ptr, ptr %l67, !tbaa !29
  %t95 = getelementptr %"compiler/unparse:writer", ptr %t94, i32 0, i32 4
  %t96 = load i64, ptr %t95, !tbaa !24
  %t98 = add i64 %t96, 1
  %t100 = load ptr, ptr %l67, !tbaa !29
  %t101 = getelementptr %"compiler/unparse:writer", ptr %t100, i32 0, i32 4
  store i64 %t98, ptr %t101, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t102, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l6, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = load i64, ptr %l5, !tbaa !24
  %t109 = load i64, ptr %l6, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb31:
  br label %bb32
bb32:
  %t116 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t116, ptr %l77, !tbaa !27
  %t117 = load i64, ptr %l5, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr ptr, ptr %t120, i64 %t117
  %t122 = load ptr, ptr %t121, !tbaa !39
  store ptr %t122, ptr %l7, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t124)
  br label %bb33
bb33:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t129 = getelementptr %"compiler/ast:CaseDecl", ptr %t127, i32 0, i32 1
  %t130 = load i32, ptr %t129, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t126, i32 %t130)
  br label %bb34
bb34:
  %t133 = load ptr, ptr %l7, !tbaa !29
  %t135 = getelementptr %"compiler/ast:CaseDecl", ptr %t133, i32 0, i32 3
  %t136 = load i1, ptr %t135, !tbaa !21
  br i1 %t136, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t138 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t138, { i64, ptr } { i64 1, ptr @.d153 })
  br label %bb37
bb36:
  %t140 = load ptr, ptr %l7, !tbaa !29
  %t142 = getelementptr %"compiler/ast:CaseDecl", ptr %t140, i32 0, i32 2
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb42, label %bb43
bb37:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l87, !tbaa !29
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t152 = getelementptr %"compiler/ast:CaseDecl", ptr %t150, i32 0, i32 2
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l89, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr ptr, ptr %t155, i64 0
  %t157 = load ptr, ptr %t156, !tbaa !39
  %t159 = getelementptr %"compiler/ast:Param", ptr %t157, i32 0, i32 2
  %t160 = load ptr, ptr %t159, !tbaa !29
  store ptr %t160, ptr %l8, !tbaa !29
  %t162 = load ptr, ptr %l8, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_c53cd7dd70350acf_d5f64367475d1e4b)
  unreachable
bb39:
  br label %bb40
bb40:
  %t166 = load ptr, ptr %l8, !tbaa !29
  %t167 = load ptr, ptr %l87, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t167, ptr %t166)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t169 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t169, { i64, ptr } { i64 1, ptr @.d154 })
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l7, !tbaa !29
  %t174 = getelementptr %"compiler/ast:CaseDecl", ptr %t172, i32 0, i32 2
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t171, { i64, ptr } %t175)
  br label %bb45
bb45:
  %t178 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t178, { i64, ptr } { i64 1, ptr @.d155 })
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s8)
  br label %bb47
bb47:
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb49:
  %t180 = load i64, ptr %l5, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l5, !tbaa !24
  br label %bb29
bb50:
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l106, !tbaa !29
  %t185 = load ptr, ptr %l106, !tbaa !29
  %t186 = getelementptr %"compiler/unparse:writer", ptr %t185, i32 0, i32 4
  %t187 = load i64, ptr %t186, !tbaa !24
  %t189 = sub i64 %t187, 1
  %t191 = load ptr, ptr %l106, !tbaa !29
  %t192 = getelementptr %"compiler/unparse:writer", ptr %t191, i32 0, i32 4
  store i64 %t189, ptr %t192, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t193)
  br label %bb51
bb51:
  %t195 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t195, { i64, ptr } { i64 1, ptr @.d156 })
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s3)
  br label %bb125
bb53:
  %t197 = load ptr, ptr %l1, !tbaa !29
  store ptr %t197, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t198 = load ptr, ptr %l111, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb54, label %bb55
bb54:
  %t201 = load ptr, ptr %l111, !tbaa !29
  %t202 = load i64, ptr %t201
  %t204 = icmp eq i64 %t202, 2
  store i1 %t204, ptr %l112, !tbaa !21
  br label %bb55
bb55:
  %t205 = load i1, ptr %l112, !tbaa !21
  br i1 %t205, label %bb56, label %bb57
bb56:
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [6 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t208, i32 0, i32 0
  %t210 = load { i64, ptr }, ptr %t209
  store { i64, ptr } %t210, ptr %l9, !tbaa !27
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [6 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t214, i32 0, i32 1
  %t216 = load { i64, ptr }, ptr %t215
  store { i64, ptr } %t216, ptr %l10, !tbaa !27
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [6 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t220, i32 0, i32 2
  %t222 = load { i64, ptr }, ptr %t221
  store { i64, ptr } %t222, ptr %l11, !tbaa !27
  br label %bb58
bb57:
  br label %bb108
bb58:
  store %olang.scope zeroinitializer, ptr %s10
  %t224 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t224, { i64, ptr } { i64 6, ptr @.d157 })
  br label %bb59
bb59:
  %t226 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t230 = icmp sgt i64 %t228, 0
  br i1 %t230, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t232 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t232, { i64, ptr } { i64 8, ptr @.d158 })
  br label %bb62
bb61:
  br label %bb75
bb62:
  %t234 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t234, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t236 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 0
  store i64 %t238, ptr %l14, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s13
  %t240 = load i64, ptr %l13, !tbaa !24
  %t241 = load i64, ptr %l14, !tbaa !24
  %t244 = icmp slt i64 %t240, %t241
  %t246 = xor i1 %t244, true
  br i1 %t246, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s13)
  br label %bb73
bb65:
  br label %bb66
bb66:
  %t248 = load i64, ptr %l13, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t250, ptr %l134, !tbaa !27
  %t251 = load i64, ptr %l13, !tbaa !24
  %t253 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr ptr, ptr %t254, i64 %t251
  %t256 = load ptr, ptr %t255, !tbaa !39
  store ptr %t256, ptr %l16, !tbaa !29
  %t260 = icmp sgt i64 %t248, 0
  br i1 %t260, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s14
  %t262 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t262, { i64, ptr } { i64 2, ptr @.d159 })
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_scope_close(ptr %s14)
  br label %bb70
bb70:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t264, ptr %t265)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s13)
  br label %bb72
bb72:
  %t268 = load i64, ptr %l13, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l13, !tbaa !24
  br label %bb63
bb73:
  %t272 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t272, { i64, ptr } { i64 1, ptr @.d160 })
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s11)
  br label %bb75
bb75:
  %t274 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t274, 0
  %t278 = icmp sgt i64 %t276, 0
  br i1 %t278, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s16
  %t280 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t280, { i64, ptr } { i64 4, ptr @.d161 })
  br label %bb78
bb77:
  br label %bb91
bb78:
  %t282 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t282, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t284 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t284, 0
  store i64 %t286, ptr %l19, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s18
  %t288 = load i64, ptr %l18, !tbaa !24
  %t289 = load i64, ptr %l19, !tbaa !24
  %t292 = icmp slt i64 %t288, %t289
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s18)
  br label %bb89
bb81:
  br label %bb82
bb82:
  %t296 = load i64, ptr %l18, !tbaa !24
  %t298 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t298, ptr %l157, !tbaa !27
  %t299 = load i64, ptr %l18, !tbaa !24
  %t301 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr ptr, ptr %t302, i64 %t299
  %t304 = load ptr, ptr %t303, !tbaa !39
  store ptr %t304, ptr %l21, !tbaa !29
  %t308 = icmp sgt i64 %t296, 0
  br i1 %t308, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s19
  %t310 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t310, { i64, ptr } { i64 2, ptr @.d162 })
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s19)
  br label %bb86
bb86:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t312, ptr %t313)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s18)
  br label %bb88
bb88:
  %t316 = load i64, ptr %l18, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l18, !tbaa !24
  br label %bb79
bb89:
  %t320 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t320, { i64, ptr } { i64 1, ptr @.d163 })
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s16)
  br label %bb91
bb91:
  %t322 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t322, { i64, ptr } { i64 1, ptr @.d164 })
  br label %bb92
bb92:
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l169, !tbaa !29
  %t325 = load ptr, ptr %l169, !tbaa !29
  %t326 = getelementptr %"compiler/unparse:writer", ptr %t325, i32 0, i32 4
  %t327 = load i64, ptr %t326, !tbaa !24
  %t329 = add i64 %t327, 1
  %t331 = load ptr, ptr %l169, !tbaa !29
  %t332 = getelementptr %"compiler/unparse:writer", ptr %t331, i32 0, i32 4
  store i64 %t329, ptr %t332, !tbaa !24
  %t333 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t333, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  store i64 %t337, ptr %l24, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s22
  %t339 = load i64, ptr %l23, !tbaa !24
  %t340 = load i64, ptr %l24, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s22)
  br label %bb105
bb95:
  br label %bb96
bb96:
  %t347 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t347, ptr %l179, !tbaa !27
  %t348 = load i64, ptr %l23, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr ptr, ptr %t351, i64 %t348
  %t353 = load ptr, ptr %t352, !tbaa !39
  store ptr %t353, ptr %l25, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t355)
  br label %bb97
bb97:
  %t357 = load ptr, ptr %l25, !tbaa !29
  %t359 = getelementptr %"compiler/ast:Func", ptr %t357, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = icmp eq ptr %t360, null
  %t364 = xor i1 %t362, true
  br i1 %t364, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s23
  %t366 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t366, { i64, ptr } { i64 4, ptr @.d165 })
  br label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_scope_close(ptr %s23)
  br label %bb101
bb101:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load ptr, ptr %l25, !tbaa !29
  %t371 = getelementptr %"compiler/ast:Func", ptr %t369, i32 0, i32 2
  %t372 = load i32, ptr %t371, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t368, i32 %t372)
  br label %bb102
bb102:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load ptr, ptr %l25, !tbaa !29
  %t378 = getelementptr %"compiler/ast:Func", ptr %t376, i32 0, i32 3
  %t379 = load ptr, ptr %t378, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t375, ptr %t379)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s22)
  br label %bb104
bb104:
  %t382 = load i64, ptr %l23, !tbaa !24
  %t384 = add i64 %t382, 1
  store i64 %t384, ptr %l23, !tbaa !24
  br label %bb93
bb105:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l196, !tbaa !29
  %t387 = load ptr, ptr %l196, !tbaa !29
  %t388 = getelementptr %"compiler/unparse:writer", ptr %t387, i32 0, i32 4
  %t389 = load i64, ptr %t388, !tbaa !24
  %t391 = sub i64 %t389, 1
  %t393 = load ptr, ptr %l196, !tbaa !29
  %t394 = getelementptr %"compiler/unparse:writer", ptr %t393, i32 0, i32 4
  store i64 %t391, ptr %t394, !tbaa !24
  %t395 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t395)
  br label %bb106
bb106:
  %t397 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t397, { i64, ptr } { i64 1, ptr @.d166 })
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s10)
  br label %bb125
bb108:
  %t399 = load ptr, ptr %l1, !tbaa !29
  store ptr %t399, ptr %l201, !tbaa !29
  store i1 false, ptr %l202, !tbaa !21
  %t400 = load ptr, ptr %l201, !tbaa !29
  %t401 = icmp ne ptr %t400, null
  br i1 %t401, label %bb109, label %bb110
bb109:
  %t403 = load ptr, ptr %l201, !tbaa !29
  %t404 = load i64, ptr %t403
  %t406 = icmp eq i64 %t404, 3
  store i1 %t406, ptr %l202, !tbaa !21
  br label %bb110
bb110:
  %t407 = load i1, ptr %l202, !tbaa !21
  br i1 %t407, label %bb111, label %bb112
bb111:
  %t408 = load ptr, ptr %l1, !tbaa !29
  %t410 = getelementptr { i64, [6 x i64] }, ptr %t408, i32 0, i32 1
  %t411 = getelementptr { ptr, ptr }, ptr %t410, i32 0, i32 0
  %t412 = load ptr, ptr %t411
  store ptr %t412, ptr %l26, !tbaa !29
  %t414 = load ptr, ptr %l1, !tbaa !29
  %t416 = getelementptr { i64, [6 x i64] }, ptr %t414, i32 0, i32 1
  %t417 = getelementptr { ptr, ptr }, ptr %t416, i32 0, i32 1
  %t418 = load ptr, ptr %t417
  store ptr %t418, ptr %l27, !tbaa !29
  br label %bb113
bb112:
  br label %bb124
bb113:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t420, ptr %t421)
  br label %bb114
bb114:
  %t424 = load ptr, ptr %l27, !tbaa !29
  %t426 = icmp eq ptr %t424, null
  %t428 = xor i1 %t426, true
  br i1 %t428, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s26
  %t430 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t430, { i64, ptr } { i64 1, ptr @.d167 })
  br label %bb117
bb116:
  br label %bb123
bb117:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load ptr, ptr %l27, !tbaa !29
  %t435 = getelementptr %"compiler/ast:Func", ptr %t433, i32 0, i32 3
  %t436 = load ptr, ptr %t435, !tbaa !29
  %t438 = getelementptr %"compiler/ast:Sig", ptr %t436, i32 0, i32 0
  %t439 = load { i64, ptr }, ptr %t438, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t432, { i64, ptr } %t439)
  br label %bb118
bb118:
  %t442 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t442, { i64, ptr } { i64 1, ptr @.d168 })
  br label %bb119
bb119:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l27, !tbaa !29
  %t447 = getelementptr %"compiler/ast:Func", ptr %t445, i32 0, i32 3
  %t448 = load ptr, ptr %t447, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t444, ptr %t448)
  br label %bb120
bb120:
  %t451 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t451, { i64, ptr } { i64 1, ptr @.d169 })
  br label %bb121
bb121:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load ptr, ptr %l27, !tbaa !29
  %t456 = getelementptr %"compiler/ast:Func", ptr %t454, i32 0, i32 4
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t453, { i64, ptr } %t457)
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s26)
  br label %bb123
bb123:
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_9e0e80da8565932d_348a542961ec57a9)
  unreachable
bb125:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l13 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 5, ptr @.d170 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:TypeDecl", ptr %t4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t3, i32 %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:TypeDecl", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t14)
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TypeDecl", ptr %t17, i32 0, i32 2
  %t20 = load i1, ptr %t19, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t22, { i64, ptr } { i64 8, ptr @.d171 })
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t24, { i64, ptr } { i64 1, ptr @.d172 })
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l13, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TypeDecl", ptr %t27, i32 0, i32 3
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_5bab8da58715fcd0_e7391da9b8dff344)
  unreachable
bb10:
  br label %bb11
bb11:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeDecl", ptr %t34, i32 0, i32 3
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t38, ptr %t37)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t7, { i64, ptr } { i64 1, ptr @.d173 })
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/unparse:writer", ptr %t9, i32 0, i32 6
  %t12 = load i1, ptr %t11, !tbaa !21
  store i1 %t12, ptr %l2, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/unparse:writer", ptr %t14, i32 0, i32 6
  store i1 true, ptr %t16, !tbaa !21
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb7:
  br label %bb8
bb8:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l27, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  store ptr %t39, ptr %l7, !tbaa !29
  %t43 = icmp sgt i64 %t31, 0
  br i1 %t43, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t45, { i64, ptr } { i64 2, ptr @.d174 })
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t50 = getelementptr %"compiler/ast:TypeParam", ptr %t48, i32 0, i32 1
  %t51 = load i32, ptr %t50, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t47, i32 %t51)
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t56 = getelementptr %"compiler/ast:TypeParam", ptr %t54, i32 0, i32 2
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t63 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t63, { i64, ptr } { i64 1, ptr @.d175 })
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l41, !tbaa !29
  %t66 = load ptr, ptr %l7, !tbaa !29
  %t68 = getelementptr %"compiler/ast:TypeParam", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b36b34168d540f92_3d8b83b8d4d4846)
  unreachable
bb18:
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l7, !tbaa !29
  %t75 = getelementptr %"compiler/ast:TypeParam", ptr %t73, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t77, ptr %t76)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb21:
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t81 = getelementptr %"compiler/ast:TypeParam", ptr %t79, i32 0, i32 3
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l10, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t88 = load i64, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb24:
  br label %bb25
bb25:
  %t96 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t96, ptr %l55, !tbaa !27
  %t97 = load i64, ptr %l9, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 %t97
  %t102 = load ptr, ptr %t101, !tbaa !39
  store ptr %t102, ptr %l11, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t104, { i64, ptr } { i64 1, ptr @.d176 })
  br label %bb26
bb26:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t106, ptr %t107)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s7)
  br label %bb28
bb28:
  %t110 = load i64, ptr %l9, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l9, !tbaa !24
  br label %bb22
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t114 = load i64, ptr %l4, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l4, !tbaa !24
  br label %bb5
bb31:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i1, ptr %l2, !tbaa !21
  %t122 = getelementptr %"compiler/unparse:writer", ptr %t118, i32 0, i32 6
  store i1 %t119, ptr %t122, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t123, { i64, ptr } { i64 1, ptr @.d177 })
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l19 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l7, !tbaa !29
  %t35 = icmp sgt i64 %t23, 0
  br i1 %t35, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t37, { i64, ptr } { i64 2, ptr @.d178 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i1, ptr %l2, !tbaa !21
  %t51 = getelementptr %"compiler/unparse:writer", ptr %t47, i32 0, i32 6
  store i1 %t48, ptr %t51, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l47 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t30 = icmp sgt i64 %t18, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t32, { i64, ptr } { i64 2, ptr @.d179 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t34, i32 %t35)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/ast:VarDecl", ptr %t42, i32 0, i32 4
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t47, i32 0, i32 2
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb14, label %bb15
bb13:
  br label %bb24
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t56, { i64, ptr } { i64 1, ptr @.d180 })
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/ast:VarDecl", ptr %t59, i32 0, i32 2
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_45ada3313b7506a3_5e369560cd76ab37)
  unreachable
bb18:
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:VarDecl", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t70, ptr %t69)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t72, { i64, ptr } { i64 4, ptr @.d181 })
  br label %bb22
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/ast:VarDecl", ptr %t75, i32 0, i32 3
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t74, { i64, ptr } %t78)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/ast:VarDecl", ptr %t81, i32 0, i32 2
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t88, { i64, ptr } { i64 1, ptr @.d182 })
  br label %bb28
bb28:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l47, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/ast:VarDecl", ptr %t91, i32 0, i32 2
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb29, label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_89b7cc3957ccbb94_42e76e0711c83918)
  unreachable
bb30:
  br label %bb31
bb31:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/ast:VarDecl", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t102, ptr %t101)
  br label %bb32
bb32:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/ast:VarDecl", ptr %t104, i32 0, i32 3
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t111 = icmp sgt i64 %t109, 0
  br i1 %t111, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t113 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t113, { i64, ptr } { i64 3, ptr @.d183 })
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/ast:VarDecl", ptr %t116, i32 0, i32 3
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t115, { i64, ptr } %t119)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2funparse_2enoErrorsOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Sig", ptr %t16, i32 0, i32 2
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  store i1 %t21, ptr %l2, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_234a8883e8ade8b2_a53ba9ebf2e3f7c6)
  unreachable
bb11:
  %t23 = load i1, ptr %l2, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 50 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb7:
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 72 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l7, !tbaa !21
  br label %bb51
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 1
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb51
bb15:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb16, label %bb17
bb16:
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t41 = load i64, ptr %t40
  %t43 = icmp eq i64 %t41, 5
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb18, label %bb19
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l2, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t51)
  store i1 %t53, ptr %l30
  br label %bb21
bb21:
  %t54 = load i1, ptr %l30, !tbaa !21
  store i1 %t54, ptr %l7, !tbaa !21
  br label %bb51
bb22:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb23, label %bb24
bb23:
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb24
bb24:
  %t63 = load i1, ptr %l32, !tbaa !21
  br i1 %t63, label %bb25, label %bb26
bb25:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l3, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t70)
  store i1 %t72, ptr %l38
  br label %bb28
bb28:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l7, !tbaa !21
  br label %bb51
bb29:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb30, label %bb31
bb30:
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load i64, ptr %t78
  %t81 = icmp eq i64 %t79, 12
  store i1 %t81, ptr %l40, !tbaa !21
  br label %bb31
bb31:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb32, label %bb33
bb32:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t89)
  store i1 %t91, ptr %l46
  br label %bb35
bb35:
  %t92 = load i1, ptr %l46, !tbaa !21
  store i1 %t92, ptr %l7, !tbaa !21
  br label %bb51
bb36:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t94 = load ptr, ptr %l47, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb37, label %bb38
bb37:
  %t97 = load ptr, ptr %l47, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 15
  store i1 %t100, ptr %l48, !tbaa !21
  br label %bb38
bb38:
  %t101 = load i1, ptr %l48, !tbaa !21
  br i1 %t101, label %bb39, label %bb40
bb39:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l5, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t108)
  store i1 %t110, ptr %l54
  br label %bb42
bb42:
  %t111 = load i1, ptr %l54, !tbaa !21
  store i1 %t111, ptr %l7, !tbaa !21
  br label %bb51
bb43:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t113 = load ptr, ptr %l55, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb44, label %bb45
bb44:
  %t116 = load ptr, ptr %l55, !tbaa !29
  %t117 = load i64, ptr %t116
  %t119 = icmp eq i64 %t117, 16
  store i1 %t119, ptr %l56, !tbaa !21
  br label %bb45
bb45:
  %t120 = load i1, ptr %l56, !tbaa !21
  br i1 %t120, label %bb46, label %bb47
bb46:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l6, !tbaa !29
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t129 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t127)
  store i1 %t129, ptr %l62
  br label %bb49
bb49:
  %t130 = load i1, ptr %l62, !tbaa !21
  store i1 %t130, ptr %l7, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb51
bb51:
  %t131 = load i1, ptr %l7, !tbaa !21
  store i1 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/unparse:writer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store ptr %a2, ptr %l5, !tbaa !29
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v3)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t8, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = insertvalue %"compiler/unparse:writer" undef, ptr %t12, 0
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = insertvalue %"compiler/unparse:writer" %t13, { i64, ptr } %t14, 1
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t17 = insertvalue %"compiler/unparse:writer" %t15, ptr %t16, 2
  %t18 = load %"std/prelude/text:StringBuilder", ptr %l6
  %t19 = insertvalue %"compiler/unparse:writer" %t17, %"std/prelude/text:StringBuilder" %t18, 3
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = insertvalue %"compiler/unparse:writer" %t19, i64 %t20, 4
  %t23 = insertvalue %"compiler/unparse:writer" %t21, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 5
  %t25 = insertvalue %"compiler/unparse:writer" %t23, i1 false, 6
  %t27 = insertvalue %"compiler/unparse:writer" %t25, i1 false, 7
  store %"compiler/unparse:writer" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/unparse:writer", ptr %rv
  ret %"compiler/unparse:writer" %rr
}

define dso_local void @olang_2einit_2ecompiler_2funparse() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2funparse_2eMaxIndent_2einit()
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant [3 x i8] c"{ }"
@.d1 = private constant [1 x i8] c"{"
@.d2 = private constant [1 x i8] c"}"
@.d3 = private constant [2 x i8] c": "
@.d4 = private constant [1 x i8] c" "
@.d5 = private constant [1 x i8] c" "
@.d6 = private constant [4 x i8] c" => "
declare void @__olang_check_failed(ptr)
@.d7 = private constant [1 x i8] c" "
@.d8 = private constant [6 x i8] c" catch"
@.d9 = private constant [2 x i8] c", "
@.d10 = private constant [1 x i8] c" "
@.d11 = private constant [1 x i8] c" "
@.d12 = private constant [9 x i8] c" default "
@.d13 = private constant [10 x i8] c"extern fn "
@.d14 = private constant [7 x i8] c"import "
@.d15 = private constant [1 x i8] c" "
@.d16 = private constant [6 x i8] c"error "
@.d17 = private constant [2 x i8] c" {"
@.d18 = private constant [1 x i8] c"}"
@.d19 = private constant [5 x i8] c"test "
@.d20 = private constant [1 x i8] c" "
@.d21 = private constant [2 x i8] c" ?"
@.d22 = private constant [2 x i8] c", "
@.d23 = private constant [1 x i8] c" "
@.d24 = private constant [1 x i8] c"("
@.d25 = private constant [1 x i8] c")"
@.d26 = private constant [1 x i8] c" "
@.d27 = private constant [1 x i8] c" "
@.d28 = private constant [1 x i8] c" "
@.d29 = private constant [1 x i8] c" "
@.d30 = private constant [8 x i8] c" not in "
@.d31 = private constant [1 x i8] c" "
@.d32 = private constant [1 x i8] c" "
@.d33 = private constant [4 x i8] c" if "
@.d34 = private constant [6 x i8] c" else "
@.d35 = private constant [8 x i8] c" is not "
@.d36 = private constant [4 x i8] c" is "
@.d37 = private constant [8 x i8] c" is not "
@.d38 = private constant [4 x i8] c" is "
@.d39 = private constant [4 x i8] c" as "
@.d40 = private constant [1 x i8] c"("
@.d41 = private constant [1 x i8] c")"
@.d42 = private constant [1 x i8] c"&"
@.d43 = private constant [1 x i8] c"("
@.d44 = private constant [1 x i8] c")"
@.d45 = private constant [1 x i8] c"<"
@.d46 = private constant [1 x i8] c">"
@.d47 = private constant [1 x i8] c"."
@.d48 = private constant [1 x i8] c"["
@.d49 = private constant [1 x i8] c"]"
@.d50 = private constant [1 x i8] c"["
@.d51 = private constant [1 x i8] c":"
@.d52 = private constant [1 x i8] c"]"
@.d53 = private constant [1 x i8] c"["
@.d54 = private constant [1 x i8] c"]"
@.d55 = private constant [1 x i8] c"["
@.d56 = private constant [1 x i8] c"]"
@.d57 = private constant [1 x i8] c"["
@.d58 = private constant [5 x i8] c" for "
@.d59 = private constant [2 x i8] c", "
@.d60 = private constant [4 x i8] c" in "
@.d61 = private constant [4 x i8] c" if "
@.d62 = private constant [1 x i8] c"]"
@.d63 = private constant [1 x i8] c" "
@.d64 = private constant [8 x i8] c"checked "
@.d65 = private constant [4 x i8] c"try "
@.d66 = private constant [2 x i8] c"fn"
@.d67 = private constant [1 x i8] c" "
@.d68 = private constant [6 x i8] c"range "
@.d69 = private constant [7 x i8] c"default"
@.d70 = private constant [2 x i8] c", "
@.d71 = private constant [3 x i8] c"fn "
@.d72 = private constant [1 x i8] c"("
@.d73 = private constant [2 x i8] c") "
@.d74 = private constant [1 x i8] c" "
@.d75 = private constant [3 x i8] c"if "
@.d76 = private constant [5 x i8] c" else"
@.d77 = private constant [1 x i8] c" "
@.d78 = private constant [6 x i8] c"match "
@.d79 = private constant [2 x i8] c" {"
@.d80 = private constant [5 x i8] c"case "
@.d81 = private constant [2 x i8] c", "
@.d82 = private constant [2 x i8] c", "
@.d83 = private constant [4 x i8] c" if "
@.d84 = private constant [7 x i8] c"nomatch"
@.d85 = private constant [1 x i8] c"}"
@.d86 = private constant [4 x i8] c"    "
@.d87 = private constant [1 x i8] c" "
@.d88 = private constant [3 x i8] c" = "
@.d89 = private constant [2 x i8] c", "
@.d90 = private constant [1 x i8] c"."
@.d91 = private constant [1 x i8] c"_"
@.d92 = private constant [1 x i8] c"("
@.d93 = private constant [2 x i8] c", "
@.d94 = private constant [1 x i8] c")"
@.d95 = private constant [1 x i8] c"("
@.d96 = private constant [1 x i8] c")"
@.d97 = private constant [9 x i8] c" noreturn"
@.d98 = private constant [2 x i8] c", "
@.d99 = private constant [1 x i8] c" "
@.d100 = private constant [4 x i8] c" := "
@.d101 = private constant [3 x i8] c" = "
@.d102 = private constant [1 x i8] c" "
@.d103 = private constant [1 x i8] c" "
@.d104 = private constant [8 x i8] c"checked "
@.d105 = private constant [4 x i8] c"try "
@.d106 = private constant [4 x i8] c"for "
@.d107 = private constant [4 x i8] c"for "
@.d108 = private constant [4 x i8] c"for "
@.d109 = private constant [2 x i8] c", "
@.d110 = private constant [2 x i8] c", "
@.d111 = private constant [4 x i8] c"for "
@.d112 = private constant [2 x i8] c", "
@.d113 = private constant [4 x i8] c" in "
@.d114 = private constant [4 x i8] c"try "
@.d115 = private constant [3 x i8] c"do "
@.d116 = private constant [5 x i8] c" for "
@.d117 = private constant [6 x i8] c"return"
@.d118 = private constant [1 x i8] c" "
@.d119 = private constant [1 x i8] c" "
@.d120 = private constant [7 x i8] c"assert "
@.d121 = private constant [2 x i8] c", "
@.d122 = private constant [5 x i8] c"error"
@.d123 = private constant [1 x i8] c" "
@.d124 = private constant [6 x i8] c"spawn "
@.d125 = private constant [3 x i8] c" = "
@.d126 = private constant [4 x i8] c"try "
@.d127 = private constant [5 x i8] c"join "
@.d128 = private constant [6 x i8] c"defer "
@.d129 = private constant [1 x i8] c"{"
@.d130 = private constant [1 x i8] c"}"
@.d131 = private constant [3 x i8] c"if "
@.d132 = private constant [1 x i8] c" "
@.d133 = private constant [6 x i8] c" else "
@.d134 = private constant [6 x i8] c" else "
@.d135 = private constant [1 x i8] c"."
@.d136 = private constant [1 x i8] c"<"
@.d137 = private constant [1 x i8] c">"
@.d138 = private constant [3 x i8] c"(fn"
@.d139 = private constant [2 x i8] c"fn"
@.d140 = private constant [1 x i8] c")"
@.d141 = private constant [2 x i8] c"?&"
@.d142 = private constant [1 x i8] c"&"
@.d143 = private constant [3 x i8] c"own"
@.d144 = private constant [1 x i8] c" "
@.d145 = private constant [3 x i8] c"mut"
@.d146 = private constant [1 x i8] c" "
@.d147 = private constant [6 x i8] c"struct"
@.d148 = private constant [1 x i8] c"("
@.d149 = private constant [1 x i8] c")"
@.d150 = private constant [1 x i8] c" "
@.d151 = private constant [10 x i8] c" destruct "
@.d152 = private constant [6 x i8] c"enum {"
@.d153 = private constant [1 x i8] c" "
@.d154 = private constant [1 x i8] c"("
@.d155 = private constant [1 x i8] c")"
@.d156 = private constant [1 x i8] c"}"
@.d157 = private constant [6 x i8] c"trait "
@.d158 = private constant [8 x i8] c"extends "
@.d159 = private constant [2 x i8] c", "
@.d160 = private constant [1 x i8] c" "
@.d161 = private constant [4 x i8] c"for "
@.d162 = private constant [2 x i8] c", "
@.d163 = private constant [1 x i8] c" "
@.d164 = private constant [1 x i8] c"{"
@.d165 = private constant [4 x i8] c"mut "
@.d166 = private constant [1 x i8] c"}"
@.d167 = private constant [1 x i8] c"("
@.d168 = private constant [1 x i8] c")"
@.d169 = private constant [1 x i8] c" "
@.d170 = private constant [5 x i8] c"type "
@.d171 = private constant [8 x i8] c" extends"
@.d172 = private constant [1 x i8] c" "
@.d173 = private constant [1 x i8] c"<"
@.d174 = private constant [2 x i8] c", "
@.d175 = private constant [1 x i8] c" "
@.d176 = private constant [1 x i8] c" "
@.d177 = private constant [1 x i8] c">"
@.d178 = private constant [2 x i8] c", "
@.d179 = private constant [2 x i8] c", "
@.d180 = private constant [1 x i8] c" "
@.d181 = private constant [4 x i8] c" := "
@.d182 = private constant [1 x i8] c" "
@.d183 = private constant [3 x i8] c" = "
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_6d411809e3c45284_6ddb613e25dacce8 = external constant [0 x i8]
@olang_loc_7f8607ca82c86e8f_41d7f7ff4057cd03 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
@olang_loc_577bb2401887ee03_bd83bee27b444ed7 = external constant [0 x i8]
@olang_loc_47b511f5ef6d9e74_baf04e552c3da2b8 = external constant [0 x i8]
@olang_loc_e6dde321a76d1169_ef8c066898e78ecd = external constant [0 x i8]
@olang_loc_af8532b2afdd02b1_ed9973e7a2ad66a5 = external constant [0 x i8]
@olang_loc_240300a98391f326_30555605a48ff2da = external constant [0 x i8]
@olang_loc_450b6e4c0e54f911_1dcad8b8a27ff01d = external constant [0 x i8]
@olang_loc_375b6e3c7dc4e00a_588d095da59240b6 = external constant [0 x i8]
@olang_loc_e1b6c554c381b10b_f727e5cc4e37ef67 = external constant [0 x i8]
@olang_loc_ba8e182b2fbe7a1c_99d493faf8d7cb48 = external constant [0 x i8]
@olang_loc_a676b6f90e9ab794_adfa384105d75b88 = external constant [0 x i8]
@olang_loc_8218e8270bec8206_ca247080b262927a = external constant [0 x i8]
@olang_loc_212921701ccd28fb_40c266614e32415f = external constant [0 x i8]
@olang_loc_a89566c82002a68c_50a6017df30325c0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_2301005a90ba30f7_2e0b8cd6b5bb3c83 = external constant [0 x i8]
@olang_loc_6385ebb2fa48e0d8_1e44ec8c8ca0ecf4 = external constant [0 x i8]
@olang_loc_19d95224243c5dd3_a108b37826b1917 = external constant [0 x i8]
@olang_loc_9c4378154f5f7dac_a032de2992525ef0 = external constant [0 x i8]
@olang_loc_b263a57856eac862_46b7b1031f9001a6 = external constant [0 x i8]
@olang_loc_9166140a1ac8280_ddd22134593fa34 = external constant [0 x i8]
@olang_loc_69b21e264e8a714a_b3e97d9d77526506 = external constant [0 x i8]
@olang_loc_8585d6fe8f316a51_b60a12ce50df87ed = external constant [0 x i8]
@olang_loc_eabe3ddcfaef285c_106dba970e52f8d8 = external constant [0 x i8]
@olang_loc_14b8182deed7e34b_cfe8cf3ea4c448f7 = external constant [0 x i8]
@olang_loc_9034b6aed20fb51a_d179ca40c5e654ce = external constant [0 x i8]
@olang_loc_8cd05a7785ffddf0_abfc69165374635c = external constant [0 x i8]
@olang_loc_c53cd7dd70350acf_d5f64367475d1e4b = external constant [0 x i8]
@olang_loc_9e0e80da8565932d_348a542961ec57a9 = external constant [0 x i8]
@olang_loc_5bab8da58715fcd0_e7391da9b8dff344 = external constant [0 x i8]
@olang_loc_b36b34168d540f92_3d8b83b8d4d4846 = external constant [0 x i8]
@olang_loc_45ada3313b7506a3_5e369560cd76ab37 = external constant [0 x i8]
@olang_loc_89b7cc3957ccbb94_42e76e0711c83918 = external constant [0 x i8]
@olang_loc_234a8883e8ade8b2_a53ba9ebf2e3f7c6 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
