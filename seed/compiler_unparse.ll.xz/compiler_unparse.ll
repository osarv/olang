; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/unparse:writer" = type { ptr, { i64, ptr }, ptr, %"std/prelude/text:StringBuilder", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
@G_2ecompiler_2funparse_2eMaxIndent = constant <{ [8 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00" }>, align 8
define dso_local { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/unparse:writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca %"compiler/unparse:writer"
  %l20 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %a1, { i64, ptr } %a2, ptr %a3)
  store %"compiler/unparse:writer" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/unparse:writer", ptr %l12
  store %"compiler/unparse:writer" %t8, ptr %l4
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %s0, ptr %v0, ptr %l4, ptr %t29)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l6, !tbaa !24
  br label %bb2
bb8:
  %t38 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 5
  %t40 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %v4, ptr %t38)
  store { i64, ptr } %t40, ptr %l28
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l30, !tbaa !24
  %t45 = mul i64 %t44, 8
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l31, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l30, !tbaa !24
  %t54 = mul i64 %t53, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2funparse_2eMaxIndent_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 64, ptr @G_2ecompiler_2funparse_2eMaxIndent, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2funparse_2eUnparse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/unparse:writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca %"compiler/unparse:writer"
  %l20 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %a1, { i64, ptr } %a2, ptr %a3)
  store %"compiler/unparse:writer" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/unparse:writer", ptr %l12
  store %"compiler/unparse:writer" %t8, ptr %l4
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %s0, ptr %v0, ptr %l4, ptr %t29)
  br label %bb6
bb6:
  %t34 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t34, i8 10)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l6, !tbaa !24
  br label %bb2
bb9:
  %t40 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 3
  %t42 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %t40)
  store { i64, ptr } %t42, ptr %l29
  br label %bb10
bb10:
  %t43 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load i64, ptr %l31, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l11 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l29 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t7, { i64, ptr } { i64 3, ptr @.d0 })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 1, ptr @.d1 })
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l11, !tbaa !29
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = getelementptr %"compiler/unparse:writer", ptr %t12, i32 0, i32 4
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = add i64 %t14, 1
  %t18 = load ptr, ptr %l11, !tbaa !29
  %t19 = getelementptr %"compiler/unparse:writer", ptr %t18, i32 0, i32 4
  store i64 %t16, ptr %t19, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l21, !tbaa !27
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t35
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %t40, ptr %l5, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t42)
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb6
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l29, !tbaa !29
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = getelementptr %"compiler/unparse:writer", ptr %t53, i32 0, i32 4
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = sub i64 %t55, 1
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t60 = getelementptr %"compiler/unparse:writer", ptr %t59, i32 0, i32 4
  store i64 %t57, ptr %t60, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t61)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t63, { i64, ptr } { i64 1, ptr @.d2 })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t7 = extractvalue { i64, ptr } zeroinitializer, 0
  %t8 = icmp eq i64 %t6, %t7
  %t9 = extractvalue { i64, ptr } %t4, 1
  %t10 = extractvalue { i64, ptr } zeroinitializer, 1
  %t11 = icmp eq ptr %t9, %t10
  %t12 = and i1 %t8, %t11
  br i1 %t12, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/unparse:writer", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  %t24 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t17, i64 %t21)
  store i1 %t24, ptr %l10
  br label %bb3
bb3:
  %t25 = load i1, ptr %l10, !tbaa !21
  store i1 %t25, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t26 = load i1, ptr %l5, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Branch", ptr %t28, i32 0, i32 0
  %t31 = load %"compiler/source:Span", ptr %t30
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t27, %"compiler/source:Span" %t31)
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/unparse:writer", ptr %t34, i32 0, i32 5
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Branch", ptr %t37, i32 0, i32 0
  %t40 = load %"compiler/source:Span", ptr %t39
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t36, %"compiler/source:Span" %t40)
  br label %bb8
bb8:
  br label %ret
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Branch", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t43, { i64, ptr } %t47)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 5
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp ne ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t8, { i64, ptr } { i64 4, ptr @.d3 })
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Case", ptr %t11, i32 0, i32 5
  %t14 = load ptr, ptr %t13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t10, ptr %t14)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t17, { i64, ptr } { i64 1, ptr @.d4 })
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Case", ptr %t20, i32 0, i32 4
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t19, { i64, ptr } %t23)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t23, { i64, ptr } { i64 6, ptr @.d5 })
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Catch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l10, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l34, !tbaa !29
  %t55 = icmp sgt i64 %t42, 0
  br i1 %t55, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 2, ptr @.d6 }, ptr %l37, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 1, ptr @.d7 }, ptr %l37, !tbaa !27
  br label %bb12
bb12:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t57, { i64, ptr } %t58)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t59, ptr %t60)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l7, !tbaa !24
  br label %bb6
bb16:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Catch", ptr %t67, i32 0, i32 2
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } zeroinitializer, 0
  %t74 = icmp eq i64 %t72, %t73
  %t75 = extractvalue { i64, ptr } %t70, 1
  %t76 = extractvalue { i64, ptr } zeroinitializer, 1
  %t77 = icmp eq ptr %t75, %t76
  %t78 = and i1 %t74, %t77
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t81 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t81, { i64, ptr } { i64 1, ptr @.d8 })
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l5, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Catch", ptr %t84, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t83, { i64, ptr } %t87)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/ast:Catch", ptr %t90, i32 0, i32 3
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = icmp sgt i64 %t95, 0
  br i1 %t97, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t99 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t99, { i64, ptr } { i64 9, ptr @.d9 })
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Catch", ptr %t102, i32 0, i32 3
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t101, { i64, ptr } %t105)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t108 = load i64, ptr %l3, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l3, !tbaa !24
  br label %bb1
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l82 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb80
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t21 = load ptr, ptr %l25, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l25, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l26, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { ptr }, ptr %t31, i32 0, i32 0
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t35, { i64, ptr } { i64 10, ptr @.d10 })
  br label %bb13
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Func", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t37, i32 %t41)
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t44, ptr %t48, i1 false)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb80
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l38, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 2
  store i1 %t58, ptr %l39, !tbaa !21
  br label %bb18
bb18:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", ptr }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l4, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  br label %bb22
bb22:
  br label %bb80
bb23:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t71 = load ptr, ptr %l46, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t74 = load ptr, ptr %l46, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 3
  store i1 %t77, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  %t78 = load i1, ptr %l47, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  br label %bb29
bb29:
  br label %bb80
bb30:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t90 = load ptr, ptr %l54, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb31, label %bb32
bb31:
  %t93 = load ptr, ptr %l54, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 4
  store i1 %t96, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l55, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t100, i32 0, i32 1
  %t102 = load i32, ptr %t101
  store i32 %t102, ptr %l6, !tbaa !23
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t106, i32 0, i32 2
  %t108 = load %"compiler/source:Span", ptr %t107
  store %"compiler/source:Span" %t108, ptr %l7
  br label %bb35
bb34:
  br label %bb43
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t110, { i64, ptr } { i64 7, ptr @.d11 })
  br label %bb36
bb36:
  %t112 = load i32, ptr %l6, !tbaa !23
  %t114 = icmp ne i32 %t112, 0
  br i1 %t114, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t116, i32 %t117)
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t120, { i64, ptr } { i64 1, ptr @.d12 })
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t122, %"compiler/source:Span" %t123)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb80
bb43:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb44, label %bb45
bb44:
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = load i64, ptr %t130
  %t133 = icmp eq i64 %t131, 5
  store i1 %t133, ptr %l71, !tbaa !21
  br label %bb45
bb45:
  %t134 = load i1, ptr %l71, !tbaa !21
  br i1 %t134, label %bb46, label %bb47
bb46:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, { i64, ptr } }, ptr %t137, i32 0, i32 1
  %t139 = load i32, ptr %t138
  store i32 %t139, ptr %l8, !tbaa !23
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [4 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, { i64, ptr } }, ptr %t143, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %t144
  store { i64, ptr } %t145, ptr %l9, !tbaa !27
  br label %bb48
bb47:
  br label %bb62
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t147, { i64, ptr } { i64 6, ptr @.d13 })
  br label %bb49
bb49:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t149, i32 %t150)
  br label %bb50
bb50:
  %t153 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t153, { i64, ptr } { i64 2, ptr @.d14 })
  br label %bb51
bb51:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l82, !tbaa !29
  %t156 = load ptr, ptr %l82, !tbaa !29
  %t157 = getelementptr %"compiler/unparse:writer", ptr %t156, i32 0, i32 4
  %t158 = load i64, ptr %t157, !tbaa !24
  %t160 = add i64 %t158, 1
  %t162 = load ptr, ptr %l82, !tbaa !29
  %t163 = getelementptr %"compiler/unparse:writer", ptr %t162, i32 0, i32 4
  store i64 %t160, ptr %t163, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t164, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  store i64 %t168, ptr %l12, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t170 = load i64, ptr %l11, !tbaa !24
  %t171 = load i64, ptr %l12, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb54:
  br label %bb55
bb55:
  %t178 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t178, ptr %l92, !tbaa !27
  %t179 = load i64, ptr %l11, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr i32, ptr %t182, i64 %t179
  %t184 = load i32, ptr %t183, !tbaa !33
  store i32 %t184, ptr %l13, !tbaa !23
  %t186 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t186)
  br label %bb56
bb56:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t188, i32 %t189)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb58:
  %t192 = load i64, ptr %l11, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l11, !tbaa !24
  br label %bb52
bb59:
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l100, !tbaa !29
  %t197 = load ptr, ptr %l100, !tbaa !29
  %t198 = getelementptr %"compiler/unparse:writer", ptr %t197, i32 0, i32 4
  %t199 = load i64, ptr %t198, !tbaa !24
  %t201 = sub i64 %t199, 1
  %t203 = load ptr, ptr %l100, !tbaa !29
  %t204 = getelementptr %"compiler/unparse:writer", ptr %t203, i32 0, i32 4
  store i64 %t201, ptr %t204, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t205)
  br label %bb60
bb60:
  %t207 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t207, { i64, ptr } { i64 1, ptr @.d15 })
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  br label %bb80
bb62:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t210 = load ptr, ptr %l105, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb63, label %bb64
bb63:
  %t213 = load ptr, ptr %l105, !tbaa !29
  %t214 = load i64, ptr %t213
  %t216 = icmp eq i64 %t214, 6
  store i1 %t216, ptr %l106, !tbaa !21
  br label %bb64
bb64:
  %t217 = load i1, ptr %l106, !tbaa !21
  br i1 %t217, label %bb65, label %bb66
bb65:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t220, i32 0, i32 1
  %t222 = load %"compiler/source:Span", ptr %t221
  store %"compiler/source:Span" %t222, ptr %l14
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t226, i32 0, i32 2
  %t228 = load { i64, ptr }, ptr %t227
  store { i64, ptr } %t228, ptr %l15, !tbaa !27
  br label %bb67
bb66:
  br label %bb72
bb67:
  store %olang.scope zeroinitializer, ptr %s11
  %t230 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t230, { i64, ptr } { i64 5, ptr @.d16 })
  br label %bb68
bb68:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l14
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t232, %"compiler/source:Span" %t233)
  br label %bb69
bb69:
  %t236 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t236, { i64, ptr } { i64 1, ptr @.d17 })
  br label %bb70
bb70:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t238, { i64, ptr } %t239)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb72:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t243 = load ptr, ptr %l119, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb73, label %bb74
bb73:
  %t246 = load ptr, ptr %l119, !tbaa !29
  %t247 = load i64, ptr %t246
  %t249 = icmp eq i64 %t247, 7
  store i1 %t249, ptr %l120, !tbaa !21
  br label %bb74
bb74:
  %t250 = load i1, ptr %l120, !tbaa !21
  br i1 %t250, label %bb75, label %bb76
bb75:
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l16, !tbaa !29
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  br label %bb78
bb78:
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb80:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l18 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t8, { i64, ptr } { i64 2, ptr @.d19 })
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Sig", ptr %t10, i32 0, i32 3
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = icmp eq i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  br i1 %a2, label %bb8, label %bb9
bb8:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Sig", ptr %t21, i32 0, i32 3
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = icmp sgt i64 %t26, 1
  store i1 %t28, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t30 = load i1, ptr %l18, !tbaa !21
  store i1 %t30, ptr %l3, !tbaa !21
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l23, !tbaa !29
  %t32 = load i1, ptr %l3, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 2, ptr @.d20 }, ptr %l25, !tbaa !27
  br label %bb13
bb12:
  store { i64, ptr } { i64 1, ptr @.d21 }, ptr %l25, !tbaa !27
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t34, { i64, ptr } %t35)
  br label %bb14
bb14:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Sig", ptr %t36, i32 0, i32 3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb17:
  br label %bb18
bb18:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l8, !tbaa !29
  %t65 = icmp sgt i64 %t53, 0
  br i1 %t65, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t67 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t67, { i64, ptr } { i64 2, ptr @.d22 })
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l5, !tbaa !24
  br label %bb15
bb25:
  %t77 = load i1, ptr %l3, !tbaa !21
  br i1 %t77, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s7
  %t79 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t79, { i64, ptr } { i64 1, ptr @.d23 })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l95 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l98 = alloca i32
  %l100 = alloca i32
  %l102 = alloca i1
  %l104 = alloca i32
  %l106 = alloca i32
  %l108 = alloca i1
  %l109 = alloca i1
  %l110 = alloca i32
  %l112 = alloca i32
  %l114 = alloca i1
  %l115 = alloca i1
  %l117 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l131 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l135 = alloca i1
  %l147 = alloca ptr
  %l149 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l154 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i1
  %l181 = alloca { i64, ptr }
  %l187 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l199 = alloca ptr
  %l200 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca i1
  %l229 = alloca ptr
  %l231 = alloca { i64, ptr }
  %l234 = alloca ptr
  %l235 = alloca i1
  %l246 = alloca ptr
  %l248 = alloca { i64, ptr }
  %l251 = alloca ptr
  %l252 = alloca i1
  %l264 = alloca ptr
  %l265 = alloca i1
  %l278 = alloca ptr
  %l279 = alloca i1
  %l297 = alloca ptr
  %l298 = alloca i1
  %l311 = alloca ptr
  %l312 = alloca i1
  %l324 = alloca ptr
  %l325 = alloca i1
  %l338 = alloca ptr
  %l339 = alloca i1
  %l361 = alloca ptr
  %l362 = alloca i1
  %l375 = alloca ptr
  %l376 = alloca i1
  %l385 = alloca ptr
  %l386 = alloca i1
  %l421 = alloca ptr
  %l422 = alloca i1
  %l435 = alloca { i64, ptr }
  %l445 = alloca ptr
  %l446 = alloca i1
  %l455 = alloca ptr
  %l457 = alloca { i64, ptr }
  %l462 = alloca ptr
  %l463 = alloca i1
  %l476 = alloca ptr
  %l477 = alloca i1
  %l484 = alloca ptr
  %l485 = alloca i1
  %l493 = alloca ptr
  %l494 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t2 = load ptr, ptr %l61, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l61, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l62, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l62, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t16, i32 %t17)
  br label %bb6
bb6:
  br label %bb318
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t21 = load ptr, ptr %l69, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l69, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l70, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l70, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32 }, ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/source:Span", ptr %t32
  store %"compiler/source:Span" %t33, ptr %l3
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t35, %"compiler/source:Span" %t36)
  br label %bb13
bb13:
  br label %bb318
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t40 = load ptr, ptr %l77, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l77, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l78, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l78, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb23
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t54, { i64, ptr } { i64 1, ptr @.d24 })
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t56, ptr %t57)
  br label %bb21
bb21:
  %t60 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t60, { i64, ptr } { i64 1, ptr @.d25 })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb318
bb23:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t63 = load ptr, ptr %l87, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb24, label %bb25
bb24:
  %t66 = load ptr, ptr %l87, !tbaa !29
  %t67 = load i64, ptr %t66
  %t69 = icmp eq i64 %t67, 3
  store i1 %t69, ptr %l88, !tbaa !21
  br label %bb25
bb25:
  %t70 = load i1, ptr %l88, !tbaa !21
  br i1 %t70, label %bb26, label %bb27
bb26:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 1
  %t75 = load i32, ptr %t74
  store i32 %t75, ptr %l5
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 2
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l6, !tbaa !29
  br label %bb28
bb27:
  br label %bb50
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l95, !tbaa !29
  %t84 = load i32, ptr %l5
  %t86 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t84)
  store { i64, ptr } %t86, ptr %l97
  br label %bb29
bb29:
  %t87 = load ptr, ptr %l95, !tbaa !29
  %t88 = load { i64, ptr }, ptr %l97, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t87, { i64, ptr } %t88)
  br label %bb30
bb30:
  %t89 = load i32, ptr %l5
  store i32 %t89, ptr %l98
  store i32 48, ptr %l100
  %t92 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l98, ptr %l100)
  store i1 %t92, ptr %l102
  br label %bb31
bb31:
  %t93 = load i1, ptr %l102, !tbaa !21
  br i1 %t93, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t94 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t94, { i64, ptr } { i64 1, ptr @.d26 })
  br label %bb34
bb33:
  %t96 = load i32, ptr %l5
  store i32 %t96, ptr %l104
  store i32 50, ptr %l106
  %t99 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l104, ptr %l106)
  store i1 %t99, ptr %l108
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb35:
  %t100 = load i1, ptr %l108, !tbaa !21
  br i1 %t100, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb39
bb37:
  %t101 = load i32, ptr %l5
  store i32 %t101, ptr %l110
  store i32 72, ptr %l112
  %t104 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l110, ptr %l112)
  store i1 %t104, ptr %l114
  br label %bb38
bb38:
  %t105 = load i1, ptr %l114, !tbaa !21
  store i1 %t105, ptr %l109, !tbaa !21
  br label %bb39
bb39:
  %t106 = load i1, ptr %l109, !tbaa !21
  br i1 %t106, label %bb40, label %bb41
bb40:
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t109 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v1, ptr %t107)
  store i1 %t109, ptr %l117
  br label %bb42
bb41:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb43
bb42:
  %t110 = load i1, ptr %l117, !tbaa !21
  store i1 %t110, ptr %l115, !tbaa !21
  br label %bb43
bb43:
  %t111 = load i1, ptr %l115, !tbaa !21
  br i1 %t111, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t112 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t112, { i64, ptr } { i64 1, ptr @.d27 })
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t114, ptr %t115)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s4)
  br label %bb318
bb50:
  %t118 = load ptr, ptr %l1, !tbaa !29
  store ptr %t118, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t119 = load ptr, ptr %l121, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb51, label %bb52
bb51:
  %t122 = load ptr, ptr %l121, !tbaa !29
  %t123 = load i64, ptr %t122
  %t125 = icmp eq i64 %t123, 4
  store i1 %t125, ptr %l122, !tbaa !21
  br label %bb52
bb52:
  %t126 = load i1, ptr %l122, !tbaa !21
  br i1 %t126, label %bb53, label %bb54
bb53:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t129, i32 0, i32 1
  %t131 = load i32, ptr %t130
  store i32 %t131, ptr %l7
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t135, i32 0, i32 2
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l8, !tbaa !29
  br label %bb55
bb54:
  br label %bb59
bb55:
  store %olang.scope zeroinitializer, ptr %s8
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t139, ptr %t140)
  br label %bb56
bb56:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l131, !tbaa !29
  %t144 = load i32, ptr %l7
  %t146 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t144)
  store { i64, ptr } %t146, ptr %l133
  br label %bb57
bb57:
  %t147 = load ptr, ptr %l131, !tbaa !29
  %t148 = load { i64, ptr }, ptr %l133, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t147, { i64, ptr } %t148)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s8)
  br label %bb318
bb59:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t150 = load ptr, ptr %l134, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb60, label %bb61
bb60:
  %t153 = load ptr, ptr %l134, !tbaa !29
  %t154 = load i64, ptr %t153
  %t156 = icmp eq i64 %t154, 5
  store i1 %t156, ptr %l135, !tbaa !21
  br label %bb61
bb61:
  %t157 = load i1, ptr %l135, !tbaa !21
  br i1 %t157, label %bb62, label %bb63
bb62:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t160, i32 0, i32 1
  %t162 = load i32, ptr %t161
  store i32 %t162, ptr %l9
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t166, i32 0, i32 2
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l10, !tbaa !29
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t172, i32 0, i32 3
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l11, !tbaa !29
  br label %bb64
bb63:
  br label %bb71
bb64:
  store %olang.scope zeroinitializer, ptr %s9
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t176, ptr %t177)
  br label %bb65
bb65:
  %t180 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t180, { i64, ptr } { i64 1, ptr @.d28 })
  br label %bb66
bb66:
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l147, !tbaa !29
  %t183 = load i32, ptr %l9
  %t185 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t183)
  store { i64, ptr } %t185, ptr %l149
  br label %bb67
bb67:
  %t186 = load ptr, ptr %l147, !tbaa !29
  %t187 = load { i64, ptr }, ptr %l149, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t186, { i64, ptr } %t187)
  br label %bb68
bb68:
  %t188 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t188, { i64, ptr } { i64 1, ptr @.d29 })
  br label %bb69
bb69:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t190, ptr %t191)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s9)
  br label %bb318
bb71:
  %t194 = load ptr, ptr %l1, !tbaa !29
  store ptr %t194, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t195 = load ptr, ptr %l153, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb72, label %bb73
bb72:
  %t198 = load ptr, ptr %l153, !tbaa !29
  %t199 = load i64, ptr %t198
  %t201 = icmp eq i64 %t199, 6
  store i1 %t201, ptr %l154, !tbaa !21
  br label %bb73
bb73:
  %t202 = load i1, ptr %l154, !tbaa !21
  br i1 %t202, label %bb74, label %bb75
bb74:
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr { i64, [5 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t205, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l12, !tbaa !29
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l13, !tbaa !29
  br label %bb76
bb75:
  br label %bb80
bb76:
  store %olang.scope zeroinitializer, ptr %s10
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t215, ptr %t216)
  br label %bb77
bb77:
  %t219 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t219, { i64, ptr } { i64 8, ptr @.d30 })
  br label %bb78
bb78:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t221, ptr %t222)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s10)
  br label %bb318
bb80:
  %t225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t225, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t226 = load ptr, ptr %l166, !tbaa !29
  %t227 = icmp ne ptr %t226, null
  br i1 %t227, label %bb81, label %bb82
bb81:
  %t229 = load ptr, ptr %l166, !tbaa !29
  %t230 = load i64, ptr %t229
  %t232 = icmp eq i64 %t230, 7
  store i1 %t232, ptr %l167, !tbaa !21
  br label %bb82
bb82:
  %t233 = load i1, ptr %l167, !tbaa !21
  br i1 %t233, label %bb83, label %bb84
bb83:
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t236 = getelementptr { i64, [5 x i64] }, ptr %t234, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", ptr }, ptr %t236, i32 0, i32 1
  %t238 = load ptr, ptr %t237
  store ptr %t238, ptr %l14, !tbaa !29
  br label %bb85
bb84:
  br label %bb100
bb85:
  %t240 = load ptr, ptr %l14, !tbaa !29
  %t242 = getelementptr %"compiler/ast:Chain", ptr %t240, i32 0, i32 1
  %t243 = load { i64, ptr }, ptr %t242, !tbaa !27
  store { i64, ptr } %t243, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t245 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t245, 0
  store i64 %t247, ptr %l17, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s13
  %t249 = load i64, ptr %l16, !tbaa !24
  %t250 = load i64, ptr %l17, !tbaa !24
  %t253 = icmp slt i64 %t249, %t250
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s13)
  br label %bb99
bb88:
  br label %bb89
bb89:
  %t257 = load i64, ptr %l16, !tbaa !24
  store i64 %t257, ptr %l18, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t259, ptr %l181, !tbaa !27
  %t260 = load i64, ptr %l16, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr ptr, ptr %t263, i64 %t260
  %t265 = load ptr, ptr %t264, !tbaa !39
  store ptr %t265, ptr %l19, !tbaa !29
  %t267 = load i64, ptr %l18, !tbaa !24
  %t269 = icmp sgt i64 %t267, 0
  br i1 %t269, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s14
  %t271 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t271, { i64, ptr } { i64 1, ptr @.d31 })
  br label %bb92
bb91:
  br label %bb96
bb92:
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l187, !tbaa !29
  %t274 = load ptr, ptr %l14, !tbaa !29
  %t276 = getelementptr %"compiler/ast:Chain", ptr %t274, i32 0, i32 0
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  store { i64, ptr } %t277, ptr %l189, !tbaa !27
  %t278 = load i64, ptr %l18, !tbaa !24
  %t280 = sub i64 %t278, 1
  %t282 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr i32, ptr %t283, i64 %t280
  %t285 = load i32, ptr %t284
  %t287 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s14, i32 %t285)
  store { i64, ptr } %t287, ptr %l193
  br label %bb93
bb93:
  %t288 = load ptr, ptr %l187, !tbaa !29
  %t289 = load { i64, ptr }, ptr %l193, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t288, { i64, ptr } %t289)
  br label %bb94
bb94:
  %t290 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t290, { i64, ptr } { i64 1, ptr @.d32 })
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s14)
  br label %bb96
bb96:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t292, ptr %t293)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s13)
  br label %bb98
bb98:
  %t296 = load i64, ptr %l16, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l16, !tbaa !24
  br label %bb86
bb99:
  br label %bb318
bb100:
  %t300 = load ptr, ptr %l1, !tbaa !29
  store ptr %t300, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t301 = load ptr, ptr %l199, !tbaa !29
  %t302 = icmp ne ptr %t301, null
  br i1 %t302, label %bb101, label %bb102
bb101:
  %t304 = load ptr, ptr %l199, !tbaa !29
  %t305 = load i64, ptr %t304
  %t307 = icmp eq i64 %t305, 8
  store i1 %t307, ptr %l200, !tbaa !21
  br label %bb102
bb102:
  %t308 = load i1, ptr %l200, !tbaa !21
  br i1 %t308, label %bb103, label %bb104
bb103:
  %t309 = load ptr, ptr %l1, !tbaa !29
  %t311 = getelementptr { i64, [5 x i64] }, ptr %t309, i32 0, i32 1
  %t312 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t311, i32 0, i32 1
  %t313 = load ptr, ptr %t312
  store ptr %t313, ptr %l20, !tbaa !29
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t317 = getelementptr { i64, [5 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t317, i32 0, i32 2
  %t319 = load ptr, ptr %t318
  store ptr %t319, ptr %l21, !tbaa !29
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr { i64, [5 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t323, i32 0, i32 3
  %t325 = load ptr, ptr %t324
  store ptr %t325, ptr %l22, !tbaa !29
  br label %bb105
bb104:
  br label %bb111
bb105:
  store %olang.scope zeroinitializer, ptr %s16
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t327, ptr %t328)
  br label %bb106
bb106:
  %t331 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t331, { i64, ptr } { i64 4, ptr @.d33 })
  br label %bb107
bb107:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t333, ptr %t334)
  br label %bb108
bb108:
  %t337 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t337, { i64, ptr } { i64 6, ptr @.d34 })
  br label %bb109
bb109:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t339, ptr %t340)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s16)
  br label %bb318
bb111:
  %t343 = load ptr, ptr %l1, !tbaa !29
  store ptr %t343, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t344 = load ptr, ptr %l217, !tbaa !29
  %t345 = icmp ne ptr %t344, null
  br i1 %t345, label %bb112, label %bb113
bb112:
  %t347 = load ptr, ptr %l217, !tbaa !29
  %t348 = load i64, ptr %t347
  %t350 = icmp eq i64 %t348, 9
  store i1 %t350, ptr %l218, !tbaa !21
  br label %bb113
bb113:
  %t351 = load i1, ptr %l218, !tbaa !21
  br i1 %t351, label %bb114, label %bb115
bb114:
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t354 = getelementptr { i64, [5 x i64] }, ptr %t352, i32 0, i32 1
  %t355 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t354, i32 0, i32 1
  %t356 = load ptr, ptr %t355
  store ptr %t356, ptr %l23, !tbaa !29
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr { i64, [5 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t360, i32 0, i32 2
  %t362 = load ptr, ptr %t361
  store ptr %t362, ptr %l24, !tbaa !29
  %t364 = load ptr, ptr %l1, !tbaa !29
  %t366 = getelementptr { i64, [5 x i64] }, ptr %t364, i32 0, i32 1
  %t367 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t366, i32 0, i32 3
  %t368 = load i1, ptr %t367
  store i1 %t368, ptr %l25, !tbaa !21
  br label %bb116
bb115:
  br label %bb123
bb116:
  store %olang.scope zeroinitializer, ptr %s17
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t370, ptr %t371)
  br label %bb117
bb117:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l229, !tbaa !29
  %t375 = load i1, ptr %l25, !tbaa !21
  br i1 %t375, label %bb118, label %bb119
bb118:
  store { i64, ptr } { i64 8, ptr @.d35 }, ptr %l231, !tbaa !27
  br label %bb120
bb119:
  store { i64, ptr } { i64 4, ptr @.d36 }, ptr %l231, !tbaa !27
  br label %bb120
bb120:
  %t377 = load ptr, ptr %l229, !tbaa !29
  %t378 = load { i64, ptr }, ptr %l231, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t377, { i64, ptr } %t378)
  br label %bb121
bb121:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t379, ptr %t380)
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s17)
  br label %bb318
bb123:
  %t383 = load ptr, ptr %l1, !tbaa !29
  store ptr %t383, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t384 = load ptr, ptr %l234, !tbaa !29
  %t385 = icmp ne ptr %t384, null
  br i1 %t385, label %bb124, label %bb125
bb124:
  %t387 = load ptr, ptr %l234, !tbaa !29
  %t388 = load i64, ptr %t387
  %t390 = icmp eq i64 %t388, 10
  store i1 %t390, ptr %l235, !tbaa !21
  br label %bb125
bb125:
  %t391 = load i1, ptr %l235, !tbaa !21
  br i1 %t391, label %bb126, label %bb127
bb126:
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t394 = getelementptr { i64, [5 x i64] }, ptr %t392, i32 0, i32 1
  %t395 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t394, i32 0, i32 1
  %t396 = load ptr, ptr %t395
  store ptr %t396, ptr %l26, !tbaa !29
  %t398 = load ptr, ptr %l1, !tbaa !29
  %t400 = getelementptr { i64, [5 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t400, i32 0, i32 2
  %t402 = load ptr, ptr %t401
  store ptr %t402, ptr %l27, !tbaa !29
  %t404 = load ptr, ptr %l1, !tbaa !29
  %t406 = getelementptr { i64, [5 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t406, i32 0, i32 3
  %t408 = load i1, ptr %t407
  store i1 %t408, ptr %l28, !tbaa !21
  br label %bb128
bb127:
  br label %bb135
bb128:
  store %olang.scope zeroinitializer, ptr %s18
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t410, ptr %t411)
  br label %bb129
bb129:
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l246, !tbaa !29
  %t415 = load i1, ptr %l28, !tbaa !21
  br i1 %t415, label %bb130, label %bb131
bb130:
  store { i64, ptr } { i64 8, ptr @.d37 }, ptr %l248, !tbaa !27
  br label %bb132
bb131:
  store { i64, ptr } { i64 4, ptr @.d38 }, ptr %l248, !tbaa !27
  br label %bb132
bb132:
  %t417 = load ptr, ptr %l246, !tbaa !29
  %t418 = load { i64, ptr }, ptr %l248, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t417, { i64, ptr } %t418)
  br label %bb133
bb133:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t419, ptr %t420)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s18)
  br label %bb318
bb135:
  %t423 = load ptr, ptr %l1, !tbaa !29
  store ptr %t423, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t424 = load ptr, ptr %l251, !tbaa !29
  %t425 = icmp ne ptr %t424, null
  br i1 %t425, label %bb136, label %bb137
bb136:
  %t427 = load ptr, ptr %l251, !tbaa !29
  %t428 = load i64, ptr %t427
  %t430 = icmp eq i64 %t428, 11
  store i1 %t430, ptr %l252, !tbaa !21
  br label %bb137
bb137:
  %t431 = load i1, ptr %l252, !tbaa !21
  br i1 %t431, label %bb138, label %bb139
bb138:
  %t432 = load ptr, ptr %l1, !tbaa !29
  %t434 = getelementptr { i64, [5 x i64] }, ptr %t432, i32 0, i32 1
  %t435 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t434, i32 0, i32 1
  %t436 = load ptr, ptr %t435
  store ptr %t436, ptr %l29, !tbaa !29
  %t438 = load ptr, ptr %l1, !tbaa !29
  %t440 = getelementptr { i64, [5 x i64] }, ptr %t438, i32 0, i32 1
  %t441 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t440, i32 0, i32 2
  %t442 = load ptr, ptr %t441
  store ptr %t442, ptr %l30, !tbaa !29
  br label %bb140
bb139:
  br label %bb144
bb140:
  store %olang.scope zeroinitializer, ptr %s19
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t444, ptr %t445)
  br label %bb141
bb141:
  %t448 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t448, { i64, ptr } { i64 4, ptr @.d39 })
  br label %bb142
bb142:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t450, ptr %t451)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s19)
  br label %bb318
bb144:
  %t454 = load ptr, ptr %l1, !tbaa !29
  store ptr %t454, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t455 = load ptr, ptr %l264, !tbaa !29
  %t456 = icmp ne ptr %t455, null
  br i1 %t456, label %bb145, label %bb146
bb145:
  %t458 = load ptr, ptr %l264, !tbaa !29
  %t459 = load i64, ptr %t458
  %t461 = icmp eq i64 %t459, 12
  store i1 %t461, ptr %l265, !tbaa !21
  br label %bb146
bb146:
  %t462 = load i1, ptr %l265, !tbaa !21
  br i1 %t462, label %bb147, label %bb148
bb147:
  %t463 = load ptr, ptr %l1, !tbaa !29
  %t465 = getelementptr { i64, [5 x i64] }, ptr %t463, i32 0, i32 1
  %t466 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t465, i32 0, i32 1
  %t467 = load ptr, ptr %t466
  store ptr %t467, ptr %l31, !tbaa !29
  %t469 = load ptr, ptr %l1, !tbaa !29
  %t471 = getelementptr { i64, [5 x i64] }, ptr %t469, i32 0, i32 1
  %t472 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t471, i32 0, i32 2
  %t473 = load { i64, ptr }, ptr %t472
  store { i64, ptr } %t473, ptr %l32, !tbaa !27
  br label %bb149
bb148:
  br label %bb154
bb149:
  store %olang.scope zeroinitializer, ptr %s20
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t475, ptr %t476)
  br label %bb150
bb150:
  %t479 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t479, { i64, ptr } { i64 1, ptr @.d40 })
  br label %bb151
bb151:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load { i64, ptr }, ptr %l32, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t481, { i64, ptr } %t482)
  br label %bb152
bb152:
  %t485 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t485, { i64, ptr } { i64 1, ptr @.d41 })
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s20)
  br label %bb318
bb154:
  %t487 = load ptr, ptr %l1, !tbaa !29
  store ptr %t487, ptr %l278, !tbaa !29
  store i1 false, ptr %l279, !tbaa !21
  %t488 = load ptr, ptr %l278, !tbaa !29
  %t489 = icmp ne ptr %t488, null
  br i1 %t489, label %bb155, label %bb156
bb155:
  %t491 = load ptr, ptr %l278, !tbaa !29
  %t492 = load i64, ptr %t491
  %t494 = icmp eq i64 %t492, 13
  store i1 %t494, ptr %l279, !tbaa !21
  br label %bb156
bb156:
  %t495 = load i1, ptr %l279, !tbaa !21
  br i1 %t495, label %bb157, label %bb158
bb157:
  %t496 = load ptr, ptr %l1, !tbaa !29
  %t498 = getelementptr { i64, [5 x i64] }, ptr %t496, i32 0, i32 1
  %t499 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t498, i32 0, i32 1
  %t500 = load ptr, ptr %t499
  store ptr %t500, ptr %l33, !tbaa !29
  %t502 = load ptr, ptr %l1, !tbaa !29
  %t504 = getelementptr { i64, [5 x i64] }, ptr %t502, i32 0, i32 1
  %t505 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t504, i32 0, i32 2
  %t506 = load i32, ptr %t505
  store i32 %t506, ptr %l34, !tbaa !23
  %t508 = load ptr, ptr %l1, !tbaa !29
  %t510 = getelementptr { i64, [5 x i64] }, ptr %t508, i32 0, i32 1
  %t511 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t510, i32 0, i32 3
  %t512 = load { i64, ptr }, ptr %t511
  store { i64, ptr } %t512, ptr %l35, !tbaa !27
  br label %bb159
bb158:
  br label %bb166
bb159:
  store %olang.scope zeroinitializer, ptr %s21
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t514, ptr %t515)
  br label %bb160
bb160:
  %t518 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t518, { i64, ptr } { i64 1, ptr @.d42 })
  br label %bb161
bb161:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t521 = load i32, ptr %l34, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t520, i32 %t521)
  br label %bb162
bb162:
  %t524 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t524, { i64, ptr } { i64 1, ptr @.d43 })
  br label %bb163
bb163:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load { i64, ptr }, ptr %l35, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t526, { i64, ptr } %t527)
  br label %bb164
bb164:
  %t530 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t530, { i64, ptr } { i64 1, ptr @.d44 })
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s21)
  br label %bb318
bb166:
  %t532 = load ptr, ptr %l1, !tbaa !29
  store ptr %t532, ptr %l297, !tbaa !29
  store i1 false, ptr %l298, !tbaa !21
  %t533 = load ptr, ptr %l297, !tbaa !29
  %t534 = icmp ne ptr %t533, null
  br i1 %t534, label %bb167, label %bb168
bb167:
  %t536 = load ptr, ptr %l297, !tbaa !29
  %t537 = load i64, ptr %t536
  %t539 = icmp eq i64 %t537, 14
  store i1 %t539, ptr %l298, !tbaa !21
  br label %bb168
bb168:
  %t540 = load i1, ptr %l298, !tbaa !21
  br i1 %t540, label %bb169, label %bb170
bb169:
  %t541 = load ptr, ptr %l1, !tbaa !29
  %t543 = getelementptr { i64, [5 x i64] }, ptr %t541, i32 0, i32 1
  %t544 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t543, i32 0, i32 1
  %t545 = load ptr, ptr %t544
  store ptr %t545, ptr %l36, !tbaa !29
  %t547 = load ptr, ptr %l1, !tbaa !29
  %t549 = getelementptr { i64, [5 x i64] }, ptr %t547, i32 0, i32 1
  %t550 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t549, i32 0, i32 2
  %t551 = load { i64, ptr }, ptr %t550
  store { i64, ptr } %t551, ptr %l37, !tbaa !27
  br label %bb171
bb170:
  br label %bb176
bb171:
  store %olang.scope zeroinitializer, ptr %s22
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t553, ptr %t554)
  br label %bb172
bb172:
  %t557 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t557, { i64, ptr } { i64 1, ptr @.d45 })
  br label %bb173
bb173:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t560 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t559, { i64, ptr } %t560)
  br label %bb174
bb174:
  %t563 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t563, { i64, ptr } { i64 1, ptr @.d46 })
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s22)
  br label %bb318
bb176:
  %t565 = load ptr, ptr %l1, !tbaa !29
  store ptr %t565, ptr %l311, !tbaa !29
  store i1 false, ptr %l312, !tbaa !21
  %t566 = load ptr, ptr %l311, !tbaa !29
  %t567 = icmp ne ptr %t566, null
  br i1 %t567, label %bb177, label %bb178
bb177:
  %t569 = load ptr, ptr %l311, !tbaa !29
  %t570 = load i64, ptr %t569
  %t572 = icmp eq i64 %t570, 15
  store i1 %t572, ptr %l312, !tbaa !21
  br label %bb178
bb178:
  %t573 = load i1, ptr %l312, !tbaa !21
  br i1 %t573, label %bb179, label %bb180
bb179:
  %t574 = load ptr, ptr %l1, !tbaa !29
  %t576 = getelementptr { i64, [5 x i64] }, ptr %t574, i32 0, i32 1
  %t577 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t576, i32 0, i32 1
  %t578 = load ptr, ptr %t577
  store ptr %t578, ptr %l38, !tbaa !29
  %t580 = load ptr, ptr %l1, !tbaa !29
  %t582 = getelementptr { i64, [5 x i64] }, ptr %t580, i32 0, i32 1
  %t583 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t582, i32 0, i32 2
  %t584 = load i32, ptr %t583
  store i32 %t584, ptr %l39, !tbaa !23
  br label %bb181
bb180:
  br label %bb185
bb181:
  store %olang.scope zeroinitializer, ptr %s23
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t586, ptr %t587)
  br label %bb182
bb182:
  %t590 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t590, { i64, ptr } { i64 1, ptr @.d47 })
  br label %bb183
bb183:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t592, i32 %t593)
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s23)
  br label %bb318
bb185:
  %t596 = load ptr, ptr %l1, !tbaa !29
  store ptr %t596, ptr %l324, !tbaa !29
  store i1 false, ptr %l325, !tbaa !21
  %t597 = load ptr, ptr %l324, !tbaa !29
  %t598 = icmp ne ptr %t597, null
  br i1 %t598, label %bb186, label %bb187
bb186:
  %t600 = load ptr, ptr %l324, !tbaa !29
  %t601 = load i64, ptr %t600
  %t603 = icmp eq i64 %t601, 16
  store i1 %t603, ptr %l325, !tbaa !21
  br label %bb187
bb187:
  %t604 = load i1, ptr %l325, !tbaa !21
  br i1 %t604, label %bb188, label %bb189
bb188:
  %t605 = load ptr, ptr %l1, !tbaa !29
  %t607 = getelementptr { i64, [5 x i64] }, ptr %t605, i32 0, i32 1
  %t608 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t607, i32 0, i32 1
  %t609 = load ptr, ptr %t608
  store ptr %t609, ptr %l40, !tbaa !29
  %t611 = load ptr, ptr %l1, !tbaa !29
  %t613 = getelementptr { i64, [5 x i64] }, ptr %t611, i32 0, i32 1
  %t614 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t613, i32 0, i32 2
  %t615 = load { i64, ptr }, ptr %t614
  store { i64, ptr } %t615, ptr %l41, !tbaa !27
  br label %bb190
bb189:
  br label %bb195
bb190:
  store %olang.scope zeroinitializer, ptr %s24
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t618 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t617, ptr %t618)
  br label %bb191
bb191:
  %t621 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t621, { i64, ptr } { i64 1, ptr @.d48 })
  br label %bb192
bb192:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load { i64, ptr }, ptr %l41, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t623, { i64, ptr } %t624)
  br label %bb193
bb193:
  %t627 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t627, { i64, ptr } { i64 1, ptr @.d49 })
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s24)
  br label %bb318
bb195:
  %t629 = load ptr, ptr %l1, !tbaa !29
  store ptr %t629, ptr %l338, !tbaa !29
  store i1 false, ptr %l339, !tbaa !21
  %t630 = load ptr, ptr %l338, !tbaa !29
  %t631 = icmp ne ptr %t630, null
  br i1 %t631, label %bb196, label %bb197
bb196:
  %t633 = load ptr, ptr %l338, !tbaa !29
  %t634 = load i64, ptr %t633
  %t636 = icmp eq i64 %t634, 17
  store i1 %t636, ptr %l339, !tbaa !21
  br label %bb197
bb197:
  %t637 = load i1, ptr %l339, !tbaa !21
  br i1 %t637, label %bb198, label %bb199
bb198:
  %t638 = load ptr, ptr %l1, !tbaa !29
  %t640 = getelementptr { i64, [5 x i64] }, ptr %t638, i32 0, i32 1
  %t641 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t640, i32 0, i32 1
  %t642 = load ptr, ptr %t641
  store ptr %t642, ptr %l42, !tbaa !29
  %t644 = load ptr, ptr %l1, !tbaa !29
  %t646 = getelementptr { i64, [5 x i64] }, ptr %t644, i32 0, i32 1
  %t647 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t646, i32 0, i32 2
  %t648 = load ptr, ptr %t647
  store ptr %t648, ptr %l43, !tbaa !29
  %t650 = load ptr, ptr %l1, !tbaa !29
  %t652 = getelementptr { i64, [5 x i64] }, ptr %t650, i32 0, i32 1
  %t653 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t652, i32 0, i32 3
  %t654 = load ptr, ptr %t653
  store ptr %t654, ptr %l44, !tbaa !29
  br label %bb200
bb199:
  br label %bb213
bb200:
  store %olang.scope zeroinitializer, ptr %s25
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t656, ptr %t657)
  br label %bb201
bb201:
  %t660 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t660, { i64, ptr } { i64 1, ptr @.d50 })
  br label %bb202
bb202:
  %t662 = load ptr, ptr %l43, !tbaa !29
  %t664 = icmp ne ptr %t662, null
  br i1 %t664, label %bb203, label %bb204
bb203:
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t667 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t666, ptr %t667)
  br label %bb205
bb204:
  br label %bb206
bb205:
  br label %bb206
bb206:
  %t670 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t670, { i64, ptr } { i64 1, ptr @.d51 })
  br label %bb207
bb207:
  %t672 = load ptr, ptr %l44, !tbaa !29
  %t674 = icmp ne ptr %t672, null
  br i1 %t674, label %bb208, label %bb209
bb208:
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t677 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t676, ptr %t677)
  br label %bb210
bb209:
  br label %bb211
bb210:
  br label %bb211
bb211:
  %t680 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t680, { i64, ptr } { i64 1, ptr @.d52 })
  br label %bb212
bb212:
  call void @__olang_scope_close(ptr %s25)
  br label %bb318
bb213:
  %t682 = load ptr, ptr %l1, !tbaa !29
  store ptr %t682, ptr %l361, !tbaa !29
  store i1 false, ptr %l362, !tbaa !21
  %t683 = load ptr, ptr %l361, !tbaa !29
  %t684 = icmp ne ptr %t683, null
  br i1 %t684, label %bb214, label %bb215
bb214:
  %t686 = load ptr, ptr %l361, !tbaa !29
  %t687 = load i64, ptr %t686
  %t689 = icmp eq i64 %t687, 18
  store i1 %t689, ptr %l362, !tbaa !21
  br label %bb215
bb215:
  %t690 = load i1, ptr %l362, !tbaa !21
  br i1 %t690, label %bb216, label %bb217
bb216:
  %t691 = load ptr, ptr %l1, !tbaa !29
  %t693 = getelementptr { i64, [5 x i64] }, ptr %t691, i32 0, i32 1
  %t694 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t693, i32 0, i32 1
  %t695 = load ptr, ptr %t694
  store ptr %t695, ptr %l45, !tbaa !29
  %t697 = load ptr, ptr %l1, !tbaa !29
  %t699 = getelementptr { i64, [5 x i64] }, ptr %t697, i32 0, i32 1
  %t700 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t699, i32 0, i32 2
  %t701 = load { i64, ptr }, ptr %t700
  store { i64, ptr } %t701, ptr %l46, !tbaa !27
  br label %bb218
bb217:
  br label %bb223
bb218:
  store %olang.scope zeroinitializer, ptr %s28
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t703, ptr %t704)
  br label %bb219
bb219:
  %t707 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t707, { i64, ptr } { i64 1, ptr @.d53 })
  br label %bb220
bb220:
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t710 = load { i64, ptr }, ptr %l46, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t709, { i64, ptr } %t710)
  br label %bb221
bb221:
  %t713 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t713, { i64, ptr } { i64 1, ptr @.d54 })
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s28)
  br label %bb318
bb223:
  %t715 = load ptr, ptr %l1, !tbaa !29
  store ptr %t715, ptr %l375, !tbaa !29
  store i1 false, ptr %l376, !tbaa !21
  %t716 = load ptr, ptr %l375, !tbaa !29
  %t717 = icmp ne ptr %t716, null
  br i1 %t717, label %bb224, label %bb225
bb224:
  %t719 = load ptr, ptr %l375, !tbaa !29
  %t720 = load i64, ptr %t719
  %t722 = icmp eq i64 %t720, 19
  store i1 %t722, ptr %l376, !tbaa !21
  br label %bb225
bb225:
  %t723 = load i1, ptr %l376, !tbaa !21
  br i1 %t723, label %bb226, label %bb227
bb226:
  %t724 = load ptr, ptr %l1, !tbaa !29
  %t726 = getelementptr { i64, [5 x i64] }, ptr %t724, i32 0, i32 1
  %t727 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t726, i32 0, i32 1
  %t728 = load { i64, ptr }, ptr %t727
  store { i64, ptr } %t728, ptr %l47, !tbaa !27
  br label %bb228
bb227:
  br label %bb232
bb228:
  store %olang.scope zeroinitializer, ptr %s29
  %t730 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t730, { i64, ptr } { i64 1, ptr @.d55 })
  br label %bb229
bb229:
  %t732 = load ptr, ptr %l0, !tbaa !29
  %t733 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t732, { i64, ptr } %t733)
  br label %bb230
bb230:
  %t736 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t736, { i64, ptr } { i64 1, ptr @.d56 })
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s29)
  br label %bb318
bb232:
  %t738 = load ptr, ptr %l1, !tbaa !29
  store ptr %t738, ptr %l385, !tbaa !29
  store i1 false, ptr %l386, !tbaa !21
  %t739 = load ptr, ptr %l385, !tbaa !29
  %t740 = icmp ne ptr %t739, null
  br i1 %t740, label %bb233, label %bb234
bb233:
  %t742 = load ptr, ptr %l385, !tbaa !29
  %t743 = load i64, ptr %t742
  %t745 = icmp eq i64 %t743, 20
  store i1 %t745, ptr %l386, !tbaa !21
  br label %bb234
bb234:
  %t746 = load i1, ptr %l386, !tbaa !21
  br i1 %t746, label %bb235, label %bb236
bb235:
  %t747 = load ptr, ptr %l1, !tbaa !29
  %t749 = getelementptr { i64, [5 x i64] }, ptr %t747, i32 0, i32 1
  %t750 = getelementptr { %"compiler/source:Span", ptr }, ptr %t749, i32 0, i32 1
  %t751 = load ptr, ptr %t750
  store ptr %t751, ptr %l48, !tbaa !29
  br label %bb237
bb236:
  br label %bb256
bb237:
  store %olang.scope zeroinitializer, ptr %s30
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t754 = load ptr, ptr %l48, !tbaa !29
  %t756 = getelementptr %"compiler/ast:Compr", ptr %t754, i32 0, i32 0
  %t757 = load ptr, ptr %t756, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t753, ptr %t757)
  br label %bb238
bb238:
  %t760 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t760, { i64, ptr } { i64 1, ptr @.d57 })
  br label %bb239
bb239:
  %t762 = load ptr, ptr %l0, !tbaa !29
  %t763 = load ptr, ptr %l48, !tbaa !29
  %t765 = getelementptr %"compiler/ast:Compr", ptr %t763, i32 0, i32 1
  %t766 = load ptr, ptr %t765, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t762, ptr %t766)
  br label %bb240
bb240:
  %t769 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t769, { i64, ptr } { i64 5, ptr @.d58 })
  br label %bb241
bb241:
  %t771 = load ptr, ptr %l48, !tbaa !29
  %t773 = getelementptr %"compiler/ast:Compr", ptr %t771, i32 0, i32 2
  %t774 = load i32, ptr %t773, !tbaa !23
  %t776 = icmp ne i32 %t774, 0
  br i1 %t776, label %bb242, label %bb243
bb242:
  store %olang.scope zeroinitializer, ptr %s31
  %t778 = load ptr, ptr %l0, !tbaa !29
  %t779 = load ptr, ptr %l48, !tbaa !29
  %t781 = getelementptr %"compiler/ast:Compr", ptr %t779, i32 0, i32 2
  %t782 = load i32, ptr %t781, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t778, i32 %t782)
  br label %bb244
bb243:
  br label %bb246
bb244:
  %t785 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t785, { i64, ptr } { i64 2, ptr @.d59 })
  br label %bb245
bb245:
  call void @__olang_scope_close(ptr %s31)
  br label %bb246
bb246:
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t788 = load ptr, ptr %l48, !tbaa !29
  %t790 = getelementptr %"compiler/ast:Compr", ptr %t788, i32 0, i32 3
  %t791 = load i32, ptr %t790, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t787, i32 %t791)
  br label %bb247
bb247:
  %t794 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t794, { i64, ptr } { i64 4, ptr @.d60 })
  br label %bb248
bb248:
  %t796 = load ptr, ptr %l0, !tbaa !29
  %t797 = load ptr, ptr %l48, !tbaa !29
  %t799 = getelementptr %"compiler/ast:Compr", ptr %t797, i32 0, i32 4
  %t800 = load ptr, ptr %t799, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t796, ptr %t800)
  br label %bb249
bb249:
  %t803 = load ptr, ptr %l48, !tbaa !29
  %t805 = getelementptr %"compiler/ast:Compr", ptr %t803, i32 0, i32 5
  %t806 = load ptr, ptr %t805, !tbaa !29
  %t808 = icmp ne ptr %t806, null
  br i1 %t808, label %bb250, label %bb251
bb250:
  store %olang.scope zeroinitializer, ptr %s32
  %t810 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s32, ptr %t810, { i64, ptr } { i64 4, ptr @.d61 })
  br label %bb252
bb251:
  br label %bb254
bb252:
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t813 = load ptr, ptr %l48, !tbaa !29
  %t815 = getelementptr %"compiler/ast:Compr", ptr %t813, i32 0, i32 5
  %t816 = load ptr, ptr %t815, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t812, ptr %t816)
  br label %bb253
bb253:
  call void @__olang_scope_close(ptr %s32)
  br label %bb254
bb254:
  %t819 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t819, { i64, ptr } { i64 1, ptr @.d62 })
  br label %bb255
bb255:
  call void @__olang_scope_close(ptr %s30)
  br label %bb318
bb256:
  %t821 = load ptr, ptr %l1, !tbaa !29
  store ptr %t821, ptr %l421, !tbaa !29
  store i1 false, ptr %l422, !tbaa !21
  %t822 = load ptr, ptr %l421, !tbaa !29
  %t823 = icmp ne ptr %t822, null
  br i1 %t823, label %bb257, label %bb258
bb257:
  %t825 = load ptr, ptr %l421, !tbaa !29
  %t826 = load i64, ptr %t825
  %t828 = icmp eq i64 %t826, 21
  store i1 %t828, ptr %l422, !tbaa !21
  br label %bb258
bb258:
  %t829 = load i1, ptr %l422, !tbaa !21
  br i1 %t829, label %bb259, label %bb260
bb259:
  %t830 = load ptr, ptr %l1, !tbaa !29
  %t832 = getelementptr { i64, [5 x i64] }, ptr %t830, i32 0, i32 1
  %t833 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t832, i32 0, i32 1
  %t834 = load { i64, ptr }, ptr %t833
  store { i64, ptr } %t834, ptr %l49, !tbaa !27
  br label %bb261
bb260:
  br label %bb273
bb261:
  %t836 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t836, ptr %l50, !tbaa !27
  store i64 0, ptr %l51, !tbaa !24
  %t838 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t840 = extractvalue { i64, ptr } %t838, 0
  store i64 %t840, ptr %l52, !tbaa !24
  br label %bb262
bb262:
  store %olang.scope zeroinitializer, ptr %s35
  %t842 = load i64, ptr %l51, !tbaa !24
  %t843 = load i64, ptr %l52, !tbaa !24
  %t846 = icmp slt i64 %t842, %t843
  %t848 = xor i1 %t846, true
  br i1 %t848, label %bb263, label %bb264
bb263:
  call void @__olang_scope_close(ptr %s35)
  br label %bb272
bb264:
  br label %bb265
bb265:
  %t850 = load i64, ptr %l51, !tbaa !24
  %t852 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t852, ptr %l435, !tbaa !27
  %t853 = load i64, ptr %l51, !tbaa !24
  %t855 = getelementptr { i64, ptr }, ptr %l435, i32 0, i32 1
  %t856 = load ptr, ptr %t855, !tbaa !27
  %t857 = getelementptr ptr, ptr %t856, i64 %t853
  %t858 = load ptr, ptr %t857, !tbaa !39
  store ptr %t858, ptr %l54, !tbaa !29
  %t862 = icmp sgt i64 %t850, 0
  br i1 %t862, label %bb266, label %bb267
bb266:
  store %olang.scope zeroinitializer, ptr %s36
  %t864 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s36, ptr %t864, { i64, ptr } { i64 1, ptr @.d63 })
  br label %bb268
bb267:
  br label %bb269
bb268:
  call void @__olang_scope_close(ptr %s36)
  br label %bb269
bb269:
  %t866 = load ptr, ptr %l0, !tbaa !29
  %t867 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t866, ptr %t867)
  br label %bb270
bb270:
  call void @__olang_scope_close(ptr %s35)
  br label %bb271
bb271:
  %t870 = load i64, ptr %l51, !tbaa !24
  %t872 = add i64 %t870, 1
  store i64 %t872, ptr %l51, !tbaa !24
  br label %bb262
bb272:
  br label %bb318
bb273:
  %t874 = load ptr, ptr %l1, !tbaa !29
  store ptr %t874, ptr %l445, !tbaa !29
  store i1 false, ptr %l446, !tbaa !21
  %t875 = load ptr, ptr %l445, !tbaa !29
  %t876 = icmp ne ptr %t875, null
  br i1 %t876, label %bb274, label %bb275
bb274:
  %t878 = load ptr, ptr %l445, !tbaa !29
  %t879 = load i64, ptr %t878
  %t881 = icmp eq i64 %t879, 22
  store i1 %t881, ptr %l446, !tbaa !21
  br label %bb275
bb275:
  %t882 = load i1, ptr %l446, !tbaa !21
  br i1 %t882, label %bb276, label %bb277
bb276:
  %t883 = load ptr, ptr %l1, !tbaa !29
  %t885 = getelementptr { i64, [5 x i64] }, ptr %t883, i32 0, i32 1
  %t886 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t885, i32 0, i32 1
  %t887 = load ptr, ptr %t886
  store ptr %t887, ptr %l55, !tbaa !29
  %t889 = load ptr, ptr %l1, !tbaa !29
  %t891 = getelementptr { i64, [5 x i64] }, ptr %t889, i32 0, i32 1
  %t892 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t891, i32 0, i32 2
  %t893 = load { i64, ptr }, ptr %t892
  store { i64, ptr } %t893, ptr %l56, !tbaa !27
  %t895 = load ptr, ptr %l1, !tbaa !29
  %t897 = getelementptr { i64, [5 x i64] }, ptr %t895, i32 0, i32 1
  %t898 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t897, i32 0, i32 3
  %t899 = load i1, ptr %t898
  store i1 %t899, ptr %l57, !tbaa !21
  br label %bb278
bb277:
  br label %bb285
bb278:
  store %olang.scope zeroinitializer, ptr %s38
  %t901 = load ptr, ptr %l0, !tbaa !29
  store ptr %t901, ptr %l455, !tbaa !29
  %t902 = load i1, ptr %l57, !tbaa !21
  br i1 %t902, label %bb279, label %bb280
bb279:
  store { i64, ptr } { i64 8, ptr @.d64 }, ptr %l457, !tbaa !27
  br label %bb281
bb280:
  store { i64, ptr } { i64 4, ptr @.d65 }, ptr %l457, !tbaa !27
  br label %bb281
bb281:
  %t904 = load ptr, ptr %l455, !tbaa !29
  %t905 = load { i64, ptr }, ptr %l457, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s38, ptr %t904, { i64, ptr } %t905)
  br label %bb282
bb282:
  %t906 = load ptr, ptr %l0, !tbaa !29
  %t907 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t906, ptr %t907)
  br label %bb283
bb283:
  %t910 = load ptr, ptr %l0, !tbaa !29
  %t911 = load { i64, ptr }, ptr %l56, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t910, { i64, ptr } %t911)
  br label %bb284
bb284:
  call void @__olang_scope_close(ptr %s38)
  br label %bb318
bb285:
  %t914 = load ptr, ptr %l1, !tbaa !29
  store ptr %t914, ptr %l462, !tbaa !29
  store i1 false, ptr %l463, !tbaa !21
  %t915 = load ptr, ptr %l462, !tbaa !29
  %t916 = icmp ne ptr %t915, null
  br i1 %t916, label %bb286, label %bb287
bb286:
  %t918 = load ptr, ptr %l462, !tbaa !29
  %t919 = load i64, ptr %t918
  %t921 = icmp eq i64 %t919, 23
  store i1 %t921, ptr %l463, !tbaa !21
  br label %bb287
bb287:
  %t922 = load i1, ptr %l463, !tbaa !21
  br i1 %t922, label %bb288, label %bb289
bb288:
  %t923 = load ptr, ptr %l1, !tbaa !29
  %t925 = getelementptr { i64, [5 x i64] }, ptr %t923, i32 0, i32 1
  %t926 = getelementptr { %"compiler/source:Span", ptr }, ptr %t925, i32 0, i32 1
  %t927 = load ptr, ptr %t926
  store ptr %t927, ptr %l58, !tbaa !29
  br label %bb290
bb289:
  br label %bb295
bb290:
  store %olang.scope zeroinitializer, ptr %s39
  %t929 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s39, ptr %t929, { i64, ptr } { i64 2, ptr @.d66 })
  br label %bb291
bb291:
  %t931 = load ptr, ptr %l0, !tbaa !29
  %t932 = load ptr, ptr %l58, !tbaa !29
  %t934 = getelementptr %"compiler/ast:Func", ptr %t932, i32 0, i32 3
  %t935 = load ptr, ptr %t934, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t931, ptr %t935, i1 true)
  br label %bb292
bb292:
  %t938 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s39, ptr %t938, { i64, ptr } { i64 1, ptr @.d67 })
  br label %bb293
bb293:
  %t940 = load ptr, ptr %l0, !tbaa !29
  %t941 = load ptr, ptr %l58, !tbaa !29
  %t943 = getelementptr %"compiler/ast:Func", ptr %t941, i32 0, i32 4
  %t944 = load { i64, ptr }, ptr %t943, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t940, { i64, ptr } %t944)
  br label %bb294
bb294:
  call void @__olang_scope_close(ptr %s39)
  br label %bb318
bb295:
  %t947 = load ptr, ptr %l1, !tbaa !29
  store ptr %t947, ptr %l476, !tbaa !29
  store i1 false, ptr %l477, !tbaa !21
  %t948 = load ptr, ptr %l476, !tbaa !29
  %t949 = icmp ne ptr %t948, null
  br i1 %t949, label %bb296, label %bb297
bb296:
  %t951 = load ptr, ptr %l476, !tbaa !29
  %t952 = load i64, ptr %t951
  %t954 = icmp eq i64 %t952, 24
  store i1 %t954, ptr %l477, !tbaa !21
  br label %bb297
bb297:
  %t955 = load i1, ptr %l477, !tbaa !21
  br i1 %t955, label %bb298, label %bb299
bb298:
  %t956 = load ptr, ptr %l1, !tbaa !29
  %t958 = getelementptr { i64, [5 x i64] }, ptr %t956, i32 0, i32 1
  %t959 = getelementptr { %"compiler/source:Span", ptr }, ptr %t958, i32 0, i32 1
  %t960 = load ptr, ptr %t959
  store ptr %t960, ptr %l59, !tbaa !29
  br label %bb300
bb299:
  br label %bb302
bb300:
  %t962 = load ptr, ptr %l0, !tbaa !29
  %t963 = load ptr, ptr %l59, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t962, ptr %t963)
  br label %bb301
bb301:
  br label %bb318
bb302:
  %t966 = load ptr, ptr %l1, !tbaa !29
  store ptr %t966, ptr %l484, !tbaa !29
  store i1 false, ptr %l485, !tbaa !21
  %t967 = load ptr, ptr %l484, !tbaa !29
  %t968 = icmp ne ptr %t967, null
  br i1 %t968, label %bb303, label %bb304
bb303:
  %t970 = load ptr, ptr %l484, !tbaa !29
  %t971 = load i64, ptr %t970
  %t973 = icmp eq i64 %t971, 25
  store i1 %t973, ptr %l485, !tbaa !21
  br label %bb304
bb304:
  %t974 = load i1, ptr %l485, !tbaa !21
  br i1 %t974, label %bb305, label %bb306
bb305:
  %t975 = load ptr, ptr %l1, !tbaa !29
  %t977 = getelementptr { i64, [5 x i64] }, ptr %t975, i32 0, i32 1
  %t978 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t977, i32 0, i32 1
  %t979 = load { i64, ptr }, ptr %t978
  store { i64, ptr } %t979, ptr %l60, !tbaa !27
  br label %bb307
bb306:
  br label %bb310
bb307:
  store %olang.scope zeroinitializer, ptr %s41
  %t981 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s41, ptr %t981, { i64, ptr } { i64 6, ptr @.d68 })
  br label %bb308
bb308:
  %t983 = load ptr, ptr %l0, !tbaa !29
  %t984 = load { i64, ptr }, ptr %l60, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t983, { i64, ptr } %t984)
  br label %bb309
bb309:
  call void @__olang_scope_close(ptr %s41)
  br label %bb318
bb310:
  %t987 = load ptr, ptr %l1, !tbaa !29
  store ptr %t987, ptr %l493, !tbaa !29
  store i1 false, ptr %l494, !tbaa !21
  %t988 = load ptr, ptr %l493, !tbaa !29
  %t989 = icmp ne ptr %t988, null
  br i1 %t989, label %bb311, label %bb312
bb311:
  %t991 = load ptr, ptr %l493, !tbaa !29
  %t992 = load i64, ptr %t991
  %t994 = icmp eq i64 %t992, 26
  store i1 %t994, ptr %l494, !tbaa !21
  br label %bb312
bb312:
  %t995 = load i1, ptr %l494, !tbaa !21
  br i1 %t995, label %bb313, label %bb314
bb313:
  br label %bb315
bb314:
  br label %bb317
bb315:
  store %olang.scope zeroinitializer, ptr %s42
  %t996 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s42, ptr %t996, { i64, ptr } { i64 7, ptr @.d69 })
  br label %bb316
bb316:
  call void @__olang_scope_close(ptr %s42)
  br label %bb318
bb317:
  call void @__olang_check_failed(ptr @.c70)
  unreachable
bb318:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t27 = icmp sgt i64 %t15, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t29, { i64, ptr } { i64 2, ptr @.d71 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr @.d72 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/ast:Func", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = icmp ne ptr %t6, null
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 1, ptr @.d73 })
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Func", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t12, ptr %t16)
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t19, { i64, ptr } { i64 2, ptr @.d74 })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %t24, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t21, i32 %t25)
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 5
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %t32)
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Func", ptr %t36, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t35, ptr %t39, i1 false)
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t42, { i64, ptr } { i64 1, ptr @.d75 })
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t45, i32 0, i32 4
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t44, { i64, ptr } %t48)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:If", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t8, ptr %t12)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } { i64 3, ptr @.d76 })
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:If", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t17, ptr %t21)
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t24, { i64, ptr } { i64 1, ptr @.d77 })
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:If", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/ast:If", ptr %t33, i32 0, i32 2
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp ne ptr %t36, null
  br i1 %t38, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t40, { i64, ptr } { i64 6, ptr @.d78 })
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/ast:If", ptr %t43, i32 0, i32 2
  %t46 = load ptr, ptr %t45, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t42, ptr %t46)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l21 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l94 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 6, ptr @.d79 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Match", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t3, ptr %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 2, ptr @.d80 })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l21, !tbaa !29
  %t13 = load ptr, ptr %l21, !tbaa !29
  %t14 = getelementptr %"compiler/unparse:writer", ptr %t13, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = add i64 %t15, 1
  %t19 = load ptr, ptr %l21, !tbaa !29
  %t20 = getelementptr %"compiler/unparse:writer", ptr %t19, i32 0, i32 4
  store i64 %t17, ptr %t20, !tbaa !24
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Match", ptr %t21, i32 0, i32 3
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb6:
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l32, !tbaa !27
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  store ptr %t44, ptr %l5, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t46)
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t48, { i64, ptr } { i64 5, ptr @.d81 })
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Case", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l46, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l10, !tbaa !29
  %t79 = icmp sgt i64 %t67, 0
  br i1 %t79, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t81, { i64, ptr } { i64 2, ptr @.d82 })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb10
bb20:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Case", ptr %t91, i32 0, i32 2
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t110, ptr %l65, !tbaa !27
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr ptr, ptr %t114, i64 %t111
  %t116 = load ptr, ptr %t115, !tbaa !39
  store ptr %t116, ptr %l15, !tbaa !29
  %t120 = icmp sgt i64 %t108, 0
  br i1 %t120, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t122 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t122, { i64, ptr } { i64 2, ptr @.d83 })
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb28:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb30
bb30:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l12, !tbaa !24
  br label %bb21
bb31:
  %t132 = load ptr, ptr %l5, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Case", ptr %t132, i32 0, i32 3
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = icmp ne ptr %t135, null
  br i1 %t137, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s11
  %t139 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t139, { i64, ptr } { i64 4, ptr @.d84 })
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Case", ptr %t142, i32 0, i32 3
  %t145 = load ptr, ptr %t144, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t141, ptr %t145)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s11)
  br label %bb36
bb36:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %t148, ptr %t149)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb38:
  %t152 = load i64, ptr %l3, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l3, !tbaa !24
  br label %bb4
bb39:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr %"compiler/ast:Match", ptr %t156, i32 0, i32 4
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = icmp ne ptr %t159, null
  br i1 %t161, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s13
  %t163 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t163)
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t165 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t165, { i64, ptr } { i64 7, ptr @.d85 })
  br label %bb43
bb43:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/ast:Match", ptr %t168, i32 0, i32 4
  %t171 = load ptr, ptr %t170, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %t167, ptr %t171)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s13)
  br label %bb45
bb45:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l94, !tbaa !29
  %t175 = load ptr, ptr %l94, !tbaa !29
  %t176 = getelementptr %"compiler/unparse:writer", ptr %t175, i32 0, i32 4
  %t177 = load i64, ptr %t176, !tbaa !24
  %t179 = sub i64 %t177, 1
  %t181 = load ptr, ptr %l94, !tbaa !29
  %t182 = getelementptr %"compiler/unparse:writer", ptr %t181, i32 0, i32 4
  store i64 %t179, ptr %t182, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t183)
  br label %bb46
bb46:
  %t185 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t185, { i64, ptr } { i64 1, ptr @.d86 })
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t7, i32 %a1)
  store { i64, ptr } %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t12, { i64, ptr } %t13)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t3, i8 10)
  br label %bb1
bb1:
  store i64 0, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/unparse:writer", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2funparse_2eMaxIndent, !tbaa !24
  %t12 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t8, i64 %t9)
  store i64 %t12, ptr %l12
  br label %bb2
bb2:
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb8
bb5:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l19, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l19, !tbaa !24
  store i64 %t40, ptr %l16, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l16, !tbaa !24
  store i64 %t41, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l1, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l6, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/unparse:writer", ptr %t60, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t62, { i64, ptr } { i64 4, ptr @.d87 })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l5, !tbaa !24
  br label %bb9
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Param", ptr %t1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t8, i32 %t12)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Param", ptr %t15, i32 0, i32 2
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp ne ptr %t18, null
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Param", ptr %t22, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = icmp ne i32 %t25, 0
  br i1 %t27, label %bb7, label %bb8
bb6:
  br label %bb12
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t29, { i64, ptr } { i64 1, ptr @.d88 })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Param", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %t34, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t31, ptr %t35)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Param", ptr %t38, i32 0, i32 3
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = icmp ne ptr %t41, null
  br i1 %t43, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t45, { i64, ptr } { i64 3, ptr @.d89 })
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Param", ptr %t48, i32 0, i32 3
  %t51 = load ptr, ptr %t50, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t47, ptr %t51)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t27 = icmp sgt i64 %t15, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t29, { i64, ptr } { i64 2, ptr @.d90 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:Path", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t30 = icmp sgt i64 %t18, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t32, { i64, ptr } { i64 1, ptr @.d91 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t34, i32 %t35)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l44 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 1, ptr @.d92 })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb49
bb7:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb8, label %bb9
bb8:
  %t16 = load ptr, ptr %l17, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 1
  store i1 %t19, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb10, label %bb11
bb10:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", ptr }, ptr %t23, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  br label %bb13
bb13:
  br label %bb49
bb14:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t35 = load ptr, ptr %l25, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l26, !tbaa !21
  br i1 %t39, label %bb17, label %bb18
bb17:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t48, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49
  store { i64, ptr } %t50, ptr %l4, !tbaa !27
  br label %bb19
bb18:
  br label %bb34
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t56, { i64, ptr } { i64 1, ptr @.d93 })
  br label %bb21
bb21:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l44, !tbaa !27
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l9, !tbaa !29
  %t84 = icmp sgt i64 %t72, 0
  br i1 %t84, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t86, { i64, ptr } { i64 2, ptr @.d94 })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t88, ptr %t89)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l6, !tbaa !24
  br label %bb22
bb32:
  %t96 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t96, { i64, ptr } { i64 1, ptr @.d95 })
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t99 = load ptr, ptr %l55, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb35, label %bb36
bb35:
  %t102 = load ptr, ptr %l55, !tbaa !29
  %t103 = load i64, ptr %t102
  %t105 = icmp eq i64 %t103, 3
  store i1 %t105, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb37, label %bb38
bb37:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32 }, ptr %t109, i32 0, i32 1
  %t111 = load i32, ptr %t110
  store i32 %t111, ptr %l10, !tbaa !23
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t113, i32 %t114)
  br label %bb40
bb40:
  br label %bb49
bb41:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb42, label %bb43
bb42:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load i64, ptr %t121
  %t124 = icmp eq i64 %t122, 4
  store i1 %t124, ptr %l64, !tbaa !21
  br label %bb43
bb43:
  %t125 = load i1, ptr %l64, !tbaa !21
  br i1 %t125, label %bb44, label %bb45
bb44:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", ptr }, ptr %t128, i32 0, i32 1
  %t130 = load ptr, ptr %t129
  store ptr %t130, ptr %l11, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t132, ptr %t133)
  br label %bb47
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @.c96)
  unreachable
bb49:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/unparse:writer", ptr %a0, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l18 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 1, ptr @.d97 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 1, ptr @.d98 })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Sig", ptr %t12, i32 0, i32 4
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t17, { i64, ptr } { i64 9, ptr @.d99 })
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:Sig", ptr %t19, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp eq i64 %t24, 1
  br i1 %t26, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t28, { i64, ptr } { i64 1, ptr @.d100 })
  br label %bb10
bb9:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Sig", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp sgt i64 %t35, 1
  br i1 %t37, label %bb12, label %bb13
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Sig", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l18, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr ptr, ptr %t45, i64 0
  %t47 = load ptr, ptr %t46, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t39, ptr %t47)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t50, { i64, ptr } { i64 2, ptr @.d101 })
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Sig", ptr %t53, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t52, { i64, ptr } %t56)
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t59, { i64, ptr } { i64 1, ptr @.d102 })
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t61, ptr %t62, i1 %a2)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l10, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c103)
  unreachable
bb3:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c103)
  unreachable
bb5:
  %t29 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l9, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t37, { i64, ptr } %t36)
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c103)
  unreachable
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l75 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l82 = alloca i1
  %l91 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca i1
  %l223 = alloca ptr
  %l225 = alloca { i64, ptr }
  %l226 = alloca ptr
  %l227 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i1
  %l254 = alloca ptr
  %l255 = alloca i1
  %l271 = alloca ptr
  %l272 = alloca i1
  %l287 = alloca ptr
  %l288 = alloca i1
  %l296 = alloca ptr
  %l297 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t2 = load ptr, ptr %l30, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l30, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l31, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l31, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb215
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t21 = load ptr, ptr %l38, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l38, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l39, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l39, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb215
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t40 = load ptr, ptr %l46, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l46, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l47, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l47, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb26
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Multi", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t54, { i64, ptr } %t58)
  br label %bb20
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l55, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Multi", ptr %t62, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr @.d104 }, ptr %l58, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 3, ptr @.d105 }, ptr %l58, !tbaa !27
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l55, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l58, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t67, { i64, ptr } %t68)
  br label %bb24
bb24:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Multi", ptr %t70, i32 0, i32 2
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t69, { i64, ptr } %t73)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb215
bb26:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t77 = load ptr, ptr %l62, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l62, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l63, !tbaa !21
  br label %bb28
bb28:
  %t84 = load i1, ptr %l63, !tbaa !21
  br i1 %t84, label %bb29, label %bb30
bb29:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l5
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l6, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t99, i32 0, i32 3
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l7, !tbaa !29
  br label %bb31
bb30:
  br label %bb38
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t103, ptr %t104)
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t107, { i64, ptr } { i64 1, ptr @.d106 })
  br label %bb33
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l75, !tbaa !29
  %t110 = load i32, ptr %l5
  %t112 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t110)
  store { i64, ptr } %t112, ptr %l77
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l75, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l77, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t113, { i64, ptr } %t114)
  br label %bb35
bb35:
  %t115 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t115, { i64, ptr } { i64 1, ptr @.d107 })
  br label %bb36
bb36:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb215
bb38:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t122 = load ptr, ptr %l81, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %l81, !tbaa !29
  %t126 = load i64, ptr %t125
  %t128 = icmp eq i64 %t126, 4
  store i1 %t128, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t129 = load i1, ptr %l82, !tbaa !21
  br i1 %t129, label %bb41, label %bb42
bb41:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l8, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [5 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t138, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139
  store { i64, ptr } %t140, ptr %l9, !tbaa !27
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [5 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t144, i32 0, i32 3
  %t146 = load i1, ptr %t145
  store i1 %t146, ptr %l10, !tbaa !21
  br label %bb43
bb42:
  br label %bb50
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l91, !tbaa !29
  %t149 = load i1, ptr %l10, !tbaa !21
  br i1 %t149, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 8, ptr @.d108 }, ptr %l93, !tbaa !27
  br label %bb46
bb45:
  store { i64, ptr } { i64 4, ptr @.d109 }, ptr %l93, !tbaa !27
  br label %bb46
bb46:
  %t151 = load ptr, ptr %l91, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l93, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t151, { i64, ptr } %t152)
  br label %bb47
bb47:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t153, ptr %t154)
  br label %bb48
bb48:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t157, { i64, ptr } %t158)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb215
bb50:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t162 = load ptr, ptr %l98, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb51, label %bb52
bb51:
  %t165 = load ptr, ptr %l98, !tbaa !29
  %t166 = load i64, ptr %t165
  %t168 = icmp eq i64 %t166, 5
  store i1 %t168, ptr %l99, !tbaa !21
  br label %bb52
bb52:
  %t169 = load i1, ptr %l99, !tbaa !21
  br i1 %t169, label %bb53, label %bb54
bb53:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", ptr }, ptr %t172, i32 0, i32 1
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l11, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %t176, ptr %t177)
  br label %bb56
bb56:
  br label %bb215
bb57:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t181 = load ptr, ptr %l106, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb58, label %bb59
bb58:
  %t184 = load ptr, ptr %l106, !tbaa !29
  %t185 = load i64, ptr %t184
  %t187 = icmp eq i64 %t185, 6
  store i1 %t187, ptr %l107, !tbaa !21
  br label %bb59
bb59:
  %t188 = load i1, ptr %l107, !tbaa !21
  br i1 %t188, label %bb60, label %bb61
bb60:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t191, i32 0, i32 1
  %t193 = load { i64, ptr }, ptr %t192
  store { i64, ptr } %t193, ptr %l12, !tbaa !27
  br label %bb62
bb61:
  br label %bb65
bb62:
  store %olang.scope zeroinitializer, ptr %s7
  %t195 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t195, { i64, ptr } { i64 4, ptr @.d110 })
  br label %bb63
bb63:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t197, { i64, ptr } %t198)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb215
bb65:
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t202 = load ptr, ptr %l115, !tbaa !29
  %t203 = icmp ne ptr %t202, null
  br i1 %t203, label %bb66, label %bb67
bb66:
  %t205 = load ptr, ptr %l115, !tbaa !29
  %t206 = load i64, ptr %t205
  %t208 = icmp eq i64 %t206, 7
  store i1 %t208, ptr %l116, !tbaa !21
  br label %bb67
bb67:
  %t209 = load i1, ptr %l116, !tbaa !21
  br i1 %t209, label %bb68, label %bb69
bb68:
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t212, i32 0, i32 1
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l13, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t218, i32 0, i32 2
  %t220 = load { i64, ptr }, ptr %t219
  store { i64, ptr } %t220, ptr %l14, !tbaa !27
  br label %bb70
bb69:
  br label %bb75
bb70:
  store %olang.scope zeroinitializer, ptr %s8
  %t222 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t222, { i64, ptr } { i64 4, ptr @.d111 })
  br label %bb71
bb71:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t224, ptr %t225)
  br label %bb72
bb72:
  %t228 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t228, { i64, ptr } { i64 1, ptr @.d112 })
  br label %bb73
bb73:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t230, { i64, ptr } %t231)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s8)
  br label %bb215
bb75:
  %t234 = load ptr, ptr %l1, !tbaa !29
  store ptr %t234, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t235 = load ptr, ptr %l129, !tbaa !29
  %t236 = icmp ne ptr %t235, null
  br i1 %t236, label %bb76, label %bb77
bb76:
  %t238 = load ptr, ptr %l129, !tbaa !29
  %t239 = load i64, ptr %t238
  %t241 = icmp eq i64 %t239, 8
  store i1 %t241, ptr %l130, !tbaa !21
  br label %bb77
bb77:
  %t242 = load i1, ptr %l130, !tbaa !21
  br i1 %t242, label %bb78, label %bb79
bb78:
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t245 = getelementptr { i64, [5 x i64] }, ptr %t243, i32 0, i32 1
  %t246 = getelementptr { %"compiler/source:Span", ptr }, ptr %t245, i32 0, i32 1
  %t247 = load ptr, ptr %t246
  store ptr %t247, ptr %l15, !tbaa !29
  br label %bb80
bb79:
  br label %bb89
bb80:
  store %olang.scope zeroinitializer, ptr %s9
  %t249 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t249, { i64, ptr } { i64 4, ptr @.d113 })
  br label %bb81
bb81:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l15, !tbaa !29
  %t254 = getelementptr %"compiler/ast:For3", ptr %t252, i32 0, i32 0
  %t255 = load ptr, ptr %t254, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t251, ptr %t255)
  br label %bb82
bb82:
  %t258 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t258, { i64, ptr } { i64 2, ptr @.d114 })
  br label %bb83
bb83:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l15, !tbaa !29
  %t263 = getelementptr %"compiler/ast:For3", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t260, ptr %t264)
  br label %bb84
bb84:
  %t267 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t267, { i64, ptr } { i64 2, ptr @.d115 })
  br label %bb85
bb85:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load ptr, ptr %l15, !tbaa !29
  %t272 = getelementptr %"compiler/ast:For3", ptr %t270, i32 0, i32 2
  %t273 = load ptr, ptr %t272, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t269, ptr %t273)
  br label %bb86
bb86:
  %t276 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t276, { i64, ptr } { i64 1, ptr @.d116 })
  br label %bb87
bb87:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l15, !tbaa !29
  %t281 = getelementptr %"compiler/ast:For3", ptr %t279, i32 0, i32 3
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t278, { i64, ptr } %t282)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s9)
  br label %bb215
bb89:
  %t285 = load ptr, ptr %l1, !tbaa !29
  store ptr %t285, ptr %l151, !tbaa !29
  store i1 false, ptr %l152, !tbaa !21
  %t286 = load ptr, ptr %l151, !tbaa !29
  %t287 = icmp ne ptr %t286, null
  br i1 %t287, label %bb90, label %bb91
bb90:
  %t289 = load ptr, ptr %l151, !tbaa !29
  %t290 = load i64, ptr %t289
  %t292 = icmp eq i64 %t290, 9
  store i1 %t292, ptr %l152, !tbaa !21
  br label %bb91
bb91:
  %t293 = load i1, ptr %l152, !tbaa !21
  br i1 %t293, label %bb92, label %bb93
bb92:
  %t294 = load ptr, ptr %l1, !tbaa !29
  %t296 = getelementptr { i64, [5 x i64] }, ptr %t294, i32 0, i32 1
  %t297 = getelementptr { %"compiler/source:Span", ptr }, ptr %t296, i32 0, i32 1
  %t298 = load ptr, ptr %t297
  store ptr %t298, ptr %l16, !tbaa !29
  br label %bb94
bb93:
  br label %bb111
bb94:
  store %olang.scope zeroinitializer, ptr %s10
  %t300 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t300, { i64, ptr } { i64 4, ptr @.d117 })
  br label %bb95
bb95:
  %t302 = load ptr, ptr %l16, !tbaa !29
  %t304 = getelementptr %"compiler/ast:ForIn", ptr %t302, i32 0, i32 0
  %t305 = load i32, ptr %t304, !tbaa !23
  %t307 = icmp ne i32 %t305, 0
  br i1 %t307, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s11
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l16, !tbaa !29
  %t312 = getelementptr %"compiler/ast:ForIn", ptr %t310, i32 0, i32 0
  %t313 = load i32, ptr %t312, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t309, i32 %t313)
  br label %bb98
bb97:
  br label %bb100
bb98:
  %t316 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t316, { i64, ptr } { i64 2, ptr @.d118 })
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s11)
  br label %bb100
bb100:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load ptr, ptr %l16, !tbaa !29
  %t321 = getelementptr %"compiler/ast:ForIn", ptr %t319, i32 0, i32 1
  %t322 = load i32, ptr %t321, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t318, i32 %t322)
  br label %bb101
bb101:
  %t325 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t325, { i64, ptr } { i64 4, ptr @.d119 })
  br label %bb102
bb102:
  %t327 = load ptr, ptr %l16, !tbaa !29
  %t329 = getelementptr %"compiler/ast:ForIn", ptr %t327, i32 0, i32 3
  %t330 = load i1, ptr %t329, !tbaa !21
  br i1 %t330, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s12
  %t332 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t332, { i64, ptr } { i64 4, ptr @.d120 })
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_scope_close(ptr %s12)
  br label %bb106
bb106:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %l16, !tbaa !29
  %t337 = getelementptr %"compiler/ast:ForIn", ptr %t335, i32 0, i32 2
  %t338 = load ptr, ptr %t337, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t334, ptr %t338)
  br label %bb107
bb107:
  %t341 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t341, { i64, ptr } { i64 1, ptr @.d121 })
  br label %bb108
bb108:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l16, !tbaa !29
  %t346 = getelementptr %"compiler/ast:ForIn", ptr %t344, i32 0, i32 4
  %t347 = load { i64, ptr }, ptr %t346, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t343, { i64, ptr } %t347)
  br label %bb109
bb109:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load ptr, ptr %l16, !tbaa !29
  %t353 = getelementptr %"compiler/ast:ForIn", ptr %t351, i32 0, i32 5
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t350, { i64, ptr } %t354)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s10)
  br label %bb215
bb111:
  %t357 = load ptr, ptr %l1, !tbaa !29
  store ptr %t357, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t358 = load ptr, ptr %l182, !tbaa !29
  %t359 = icmp ne ptr %t358, null
  br i1 %t359, label %bb112, label %bb113
bb112:
  %t361 = load ptr, ptr %l182, !tbaa !29
  %t362 = load i64, ptr %t361
  %t364 = icmp eq i64 %t362, 10
  store i1 %t364, ptr %l183, !tbaa !21
  br label %bb113
bb113:
  %t365 = load i1, ptr %l183, !tbaa !21
  br i1 %t365, label %bb114, label %bb115
bb114:
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t368 = getelementptr { i64, [5 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t368, i32 0, i32 1
  %t370 = load { i64, ptr }, ptr %t369
  store { i64, ptr } %t370, ptr %l17, !tbaa !27
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t374 = getelementptr { i64, [5 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t374, i32 0, i32 2
  %t376 = load ptr, ptr %t375
  store ptr %t376, ptr %l18, !tbaa !29
  br label %bb116
bb115:
  br label %bb121
bb116:
  store %olang.scope zeroinitializer, ptr %s13
  %t378 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t378, { i64, ptr } { i64 3, ptr @.d122 })
  br label %bb117
bb117:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t380, { i64, ptr } %t381)
  br label %bb118
bb118:
  %t384 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t384, { i64, ptr } { i64 5, ptr @.d123 })
  br label %bb119
bb119:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t386, ptr %t387)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s13)
  br label %bb215
bb121:
  %t390 = load ptr, ptr %l1, !tbaa !29
  store ptr %t390, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t391 = load ptr, ptr %l196, !tbaa !29
  %t392 = icmp ne ptr %t391, null
  br i1 %t392, label %bb122, label %bb123
bb122:
  %t394 = load ptr, ptr %l196, !tbaa !29
  %t395 = load i64, ptr %t394
  %t397 = icmp eq i64 %t395, 11
  store i1 %t397, ptr %l197, !tbaa !21
  br label %bb123
bb123:
  %t398 = load i1, ptr %l197, !tbaa !21
  br i1 %t398, label %bb124, label %bb125
bb124:
  %t399 = load ptr, ptr %l1, !tbaa !29
  %t401 = getelementptr { i64, [5 x i64] }, ptr %t399, i32 0, i32 1
  %t402 = getelementptr { %"compiler/source:Span", ptr }, ptr %t401, i32 0, i32 1
  %t403 = load ptr, ptr %t402
  store ptr %t403, ptr %l19, !tbaa !29
  br label %bb126
bb125:
  br label %bb128
bb126:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t405, ptr %t406)
  br label %bb127
bb127:
  br label %bb215
bb128:
  %t409 = load ptr, ptr %l1, !tbaa !29
  store ptr %t409, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t410 = load ptr, ptr %l204, !tbaa !29
  %t411 = icmp ne ptr %t410, null
  br i1 %t411, label %bb129, label %bb130
bb129:
  %t413 = load ptr, ptr %l204, !tbaa !29
  %t414 = load i64, ptr %t413
  %t416 = icmp eq i64 %t414, 12
  store i1 %t416, ptr %l205, !tbaa !21
  br label %bb130
bb130:
  %t417 = load i1, ptr %l205, !tbaa !21
  br i1 %t417, label %bb131, label %bb132
bb131:
  %t418 = load ptr, ptr %l1, !tbaa !29
  %t420 = getelementptr { i64, [5 x i64] }, ptr %t418, i32 0, i32 1
  %t421 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t420, i32 0, i32 1
  %t422 = load { i64, ptr }, ptr %t421
  store { i64, ptr } %t422, ptr %l20, !tbaa !27
  br label %bb133
bb132:
  br label %bb140
bb133:
  store %olang.scope zeroinitializer, ptr %s15
  %t424 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t424, { i64, ptr } { i64 6, ptr @.d124 })
  br label %bb134
bb134:
  %t426 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t426, 0
  %t430 = icmp sgt i64 %t428, 0
  br i1 %t430, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s16
  %t432 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t432, { i64, ptr } { i64 1, ptr @.d125 })
  br label %bb137
bb136:
  br label %bb139
bb137:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t434, { i64, ptr } %t435)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s16)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s15)
  br label %bb215
bb140:
  %t438 = load ptr, ptr %l1, !tbaa !29
  store ptr %t438, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t439 = load ptr, ptr %l217, !tbaa !29
  %t440 = icmp ne ptr %t439, null
  br i1 %t440, label %bb141, label %bb142
bb141:
  %t442 = load ptr, ptr %l217, !tbaa !29
  %t443 = load i64, ptr %t442
  %t445 = icmp eq i64 %t443, 13
  store i1 %t445, ptr %l218, !tbaa !21
  br label %bb142
bb142:
  %t446 = load i1, ptr %l218, !tbaa !21
  br i1 %t446, label %bb143, label %bb144
bb143:
  %t447 = load ptr, ptr %l1, !tbaa !29
  %t449 = getelementptr { i64, [5 x i64] }, ptr %t447, i32 0, i32 1
  %t450 = getelementptr { %"compiler/source:Span", i32 }, ptr %t449, i32 0, i32 1
  %t451 = load i32, ptr %t450
  store i32 %t451, ptr %l21
  br label %bb145
bb144:
  br label %bb148
bb145:
  store %olang.scope zeroinitializer, ptr %s17
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l223, !tbaa !29
  %t454 = load i32, ptr %l21
  %t456 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s17, i32 %t454)
  store { i64, ptr } %t456, ptr %l225
  br label %bb146
bb146:
  %t457 = load ptr, ptr %l223, !tbaa !29
  %t458 = load { i64, ptr }, ptr %l225, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t457, { i64, ptr } %t458)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s17)
  br label %bb215
bb148:
  %t459 = load ptr, ptr %l1, !tbaa !29
  store ptr %t459, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t460 = load ptr, ptr %l226, !tbaa !29
  %t461 = icmp ne ptr %t460, null
  br i1 %t461, label %bb149, label %bb150
bb149:
  %t463 = load ptr, ptr %l226, !tbaa !29
  %t464 = load i64, ptr %t463
  %t466 = icmp eq i64 %t464, 14
  store i1 %t466, ptr %l227, !tbaa !21
  br label %bb150
bb150:
  %t467 = load i1, ptr %l227, !tbaa !21
  br i1 %t467, label %bb151, label %bb152
bb151:
  %t468 = load ptr, ptr %l1, !tbaa !29
  %t470 = getelementptr { i64, [5 x i64] }, ptr %t468, i32 0, i32 1
  %t471 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t470, i32 0, i32 1
  %t472 = load ptr, ptr %t471
  store ptr %t472, ptr %l22, !tbaa !29
  %t474 = load ptr, ptr %l1, !tbaa !29
  %t476 = getelementptr { i64, [5 x i64] }, ptr %t474, i32 0, i32 1
  %t477 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t476, i32 0, i32 2
  %t478 = load ptr, ptr %t477
  store ptr %t478, ptr %l23, !tbaa !29
  br label %bb153
bb152:
  br label %bb161
bb153:
  store %olang.scope zeroinitializer, ptr %s18
  %t480 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t480, { i64, ptr } { i64 7, ptr @.d126 })
  br label %bb154
bb154:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t482, ptr %t483)
  br label %bb155
bb155:
  %t486 = load ptr, ptr %l23, !tbaa !29
  %t488 = icmp ne ptr %t486, null
  br i1 %t488, label %bb156, label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s19
  %t490 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t490, { i64, ptr } { i64 2, ptr @.d127 })
  br label %bb158
bb157:
  br label %bb160
bb158:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t492, ptr %t493)
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s19)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s18)
  br label %bb215
bb161:
  %t496 = load ptr, ptr %l1, !tbaa !29
  store ptr %t496, ptr %l242, !tbaa !29
  store i1 false, ptr %l243, !tbaa !21
  %t497 = load ptr, ptr %l242, !tbaa !29
  %t498 = icmp ne ptr %t497, null
  br i1 %t498, label %bb162, label %bb163
bb162:
  %t500 = load ptr, ptr %l242, !tbaa !29
  %t501 = load i64, ptr %t500
  %t503 = icmp eq i64 %t501, 15
  store i1 %t503, ptr %l243, !tbaa !21
  br label %bb163
bb163:
  %t504 = load i1, ptr %l243, !tbaa !21
  br i1 %t504, label %bb164, label %bb165
bb164:
  %t505 = load ptr, ptr %l1, !tbaa !29
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", ptr }, ptr %t507, i32 0, i32 1
  %t509 = load ptr, ptr %t508
  store ptr %t509, ptr %l24, !tbaa !29
  br label %bb166
bb165:
  br label %bb173
bb166:
  store %olang.scope zeroinitializer, ptr %s20
  %t511 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t511, { i64, ptr } { i64 5, ptr @.d128 })
  br label %bb167
bb167:
  %t513 = load ptr, ptr %l24, !tbaa !29
  %t515 = icmp ne ptr %t513, null
  br i1 %t515, label %bb168, label %bb169
bb168:
  store %olang.scope zeroinitializer, ptr %s21
  %t517 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t517, { i64, ptr } { i64 1, ptr @.d129 })
  br label %bb170
bb169:
  br label %bb172
bb170:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t519, ptr %t520)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s21)
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s20)
  br label %bb215
bb173:
  %t523 = load ptr, ptr %l1, !tbaa !29
  store ptr %t523, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t524 = load ptr, ptr %l254, !tbaa !29
  %t525 = icmp ne ptr %t524, null
  br i1 %t525, label %bb174, label %bb175
bb174:
  %t527 = load ptr, ptr %l254, !tbaa !29
  %t528 = load i64, ptr %t527
  %t530 = icmp eq i64 %t528, 16
  store i1 %t530, ptr %l255, !tbaa !21
  br label %bb175
bb175:
  %t531 = load i1, ptr %l255, !tbaa !21
  br i1 %t531, label %bb176, label %bb177
bb176:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr { i64, [5 x i64] }, ptr %t532, i32 0, i32 1
  %t535 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t534, i32 0, i32 1
  %t536 = load { i64, ptr }, ptr %t535
  store { i64, ptr } %t536, ptr %l25, !tbaa !27
  %t538 = load ptr, ptr %l1, !tbaa !29
  %t540 = getelementptr { i64, [5 x i64] }, ptr %t538, i32 0, i32 1
  %t541 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t540, i32 0, i32 2
  %t542 = load ptr, ptr %t541
  store ptr %t542, ptr %l26, !tbaa !29
  br label %bb178
bb177:
  br label %bb186
bb178:
  store %olang.scope zeroinitializer, ptr %s22
  %t544 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t544, { i64, ptr } { i64 6, ptr @.d130 })
  br label %bb179
bb179:
  %t546 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t546, 0
  %t550 = icmp sgt i64 %t548, 0
  br i1 %t550, label %bb180, label %bb181
bb180:
  store %olang.scope zeroinitializer, ptr %s23
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t552, { i64, ptr } %t553)
  br label %bb182
bb181:
  br label %bb184
bb182:
  %t556 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t556, { i64, ptr } { i64 3, ptr @.d131 })
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s23)
  br label %bb184
bb184:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t558, ptr %t559)
  br label %bb185
bb185:
  call void @__olang_scope_close(ptr %s22)
  br label %bb215
bb186:
  %t562 = load ptr, ptr %l1, !tbaa !29
  store ptr %t562, ptr %l271, !tbaa !29
  store i1 false, ptr %l272, !tbaa !21
  %t563 = load ptr, ptr %l271, !tbaa !29
  %t564 = icmp ne ptr %t563, null
  br i1 %t564, label %bb187, label %bb188
bb187:
  %t566 = load ptr, ptr %l271, !tbaa !29
  %t567 = load i64, ptr %t566
  %t569 = icmp eq i64 %t567, 17
  store i1 %t569, ptr %l272, !tbaa !21
  br label %bb188
bb188:
  %t570 = load i1, ptr %l272, !tbaa !21
  br i1 %t570, label %bb189, label %bb190
bb189:
  %t571 = load ptr, ptr %l1, !tbaa !29
  %t573 = getelementptr { i64, [5 x i64] }, ptr %t571, i32 0, i32 1
  %t574 = getelementptr { %"compiler/source:Span", ptr }, ptr %t573, i32 0, i32 1
  %t575 = load ptr, ptr %t574
  store ptr %t575, ptr %l27, !tbaa !29
  br label %bb191
bb190:
  br label %bb199
bb191:
  store %olang.scope zeroinitializer, ptr %s24
  %t577 = load ptr, ptr %l27, !tbaa !29
  %t579 = getelementptr %"compiler/ast:JoinS", ptr %t577, i32 0, i32 0
  %t580 = load i1, ptr %t579, !tbaa !21
  br i1 %t580, label %bb192, label %bb193
bb192:
  store %olang.scope zeroinitializer, ptr %s25
  %t582 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t582, { i64, ptr } { i64 4, ptr @.d132 })
  br label %bb194
bb193:
  br label %bb195
bb194:
  call void @__olang_scope_close(ptr %s25)
  br label %bb195
bb195:
  %t584 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t584, { i64, ptr } { i64 5, ptr @.d133 })
  br label %bb196
bb196:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load ptr, ptr %l27, !tbaa !29
  %t589 = getelementptr %"compiler/ast:JoinS", ptr %t587, i32 0, i32 1
  %t590 = load { i64, ptr }, ptr %t589, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t586, { i64, ptr } %t590)
  br label %bb197
bb197:
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t594 = load ptr, ptr %l27, !tbaa !29
  %t596 = getelementptr %"compiler/ast:JoinS", ptr %t594, i32 0, i32 2
  %t597 = load { i64, ptr }, ptr %t596, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t593, { i64, ptr } %t597)
  br label %bb198
bb198:
  call void @__olang_scope_close(ptr %s24)
  br label %bb215
bb199:
  %t600 = load ptr, ptr %l1, !tbaa !29
  store ptr %t600, ptr %l287, !tbaa !29
  store i1 false, ptr %l288, !tbaa !21
  %t601 = load ptr, ptr %l287, !tbaa !29
  %t602 = icmp ne ptr %t601, null
  br i1 %t602, label %bb200, label %bb201
bb200:
  %t604 = load ptr, ptr %l287, !tbaa !29
  %t605 = load i64, ptr %t604
  %t607 = icmp eq i64 %t605, 18
  store i1 %t607, ptr %l288, !tbaa !21
  br label %bb201
bb201:
  %t608 = load i1, ptr %l288, !tbaa !21
  br i1 %t608, label %bb202, label %bb203
bb202:
  %t609 = load ptr, ptr %l1, !tbaa !29
  %t611 = getelementptr { i64, [5 x i64] }, ptr %t609, i32 0, i32 1
  %t612 = getelementptr { %"compiler/source:Span", ptr }, ptr %t611, i32 0, i32 1
  %t613 = load ptr, ptr %t612
  store ptr %t613, ptr %l28, !tbaa !29
  br label %bb204
bb203:
  br label %bb207
bb204:
  store %olang.scope zeroinitializer, ptr %s26
  %t615 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t615, { i64, ptr } { i64 6, ptr @.d134 })
  br label %bb205
bb205:
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t618 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t617, ptr %t618)
  br label %bb206
bb206:
  call void @__olang_scope_close(ptr %s26)
  br label %bb215
bb207:
  %t621 = load ptr, ptr %l1, !tbaa !29
  store ptr %t621, ptr %l296, !tbaa !29
  store i1 false, ptr %l297, !tbaa !21
  %t622 = load ptr, ptr %l296, !tbaa !29
  %t623 = icmp ne ptr %t622, null
  br i1 %t623, label %bb208, label %bb209
bb208:
  %t625 = load ptr, ptr %l296, !tbaa !29
  %t626 = load i64, ptr %t625
  %t628 = icmp eq i64 %t626, 19
  store i1 %t628, ptr %l297, !tbaa !21
  br label %bb209
bb209:
  %t629 = load i1, ptr %l297, !tbaa !21
  br i1 %t629, label %bb210, label %bb211
bb210:
  %t630 = load ptr, ptr %l1, !tbaa !29
  %t632 = getelementptr { i64, [5 x i64] }, ptr %t630, i32 0, i32 1
  %t633 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t632, i32 0, i32 1
  %t634 = load { i64, ptr }, ptr %t633
  store { i64, ptr } %t634, ptr %l29, !tbaa !27
  br label %bb212
bb211:
  br label %bb214
bb212:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t637 = load { i64, ptr }, ptr %l29, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t636, { i64, ptr } %t637)
  br label %bb213
bb213:
  br label %bb215
bb214:
  call void @__olang_check_failed(ptr @.c135)
  unreachable
bb215:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l38 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopBranch", ptr %t5, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t4, i64 %t8)
  store i1 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopBranch", ptr %t14, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t13, %"compiler/source:Span" %t17)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TopBranch", ptr %t23, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t22, %"compiler/source:Span" %t26)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t29, { i64, ptr } { i64 1, ptr @.d136 })
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = getelementptr %"compiler/unparse:writer", ptr %t32, i32 0, i32 4
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = add i64 %t34, 1
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = getelementptr %"compiler/unparse:writer", ptr %t38, i32 0, i32 4
  store i64 %t36, ptr %t39, !tbaa !24
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  store ptr %t63, ptr %l5, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t65)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l3, !tbaa !24
  br label %bb8
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l38, !tbaa !29
  %t76 = load ptr, ptr %l38, !tbaa !29
  %t77 = getelementptr %"compiler/unparse:writer", ptr %t76, i32 0, i32 4
  %t78 = load i64, ptr %t77, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"compiler/unparse:writer", ptr %t82, i32 0, i32 4
  store i64 %t80, ptr %t83, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t84)
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t86, { i64, ptr } { i64 1, ptr @.d137 })
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr @.d138 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:TopIf", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t3, ptr %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 1, ptr @.d139 })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TopIf", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t12, ptr %t16)
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:TopIf", ptr %t19, i32 0, i32 2
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp ne ptr %t22, null
  br i1 %t24, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t26, { i64, ptr } { i64 6, ptr @.d140 })
  br label %bb7
bb6:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TopIf", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp ne ptr %t31, null
  br i1 %t33, label %bb9, label %bb10
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/ast:TopIf", ptr %t36, i32 0, i32 2
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t35, ptr %t39)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t42, { i64, ptr } { i64 6, ptr @.d141 })
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:TopIf", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t44, ptr %t48)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l33 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l51 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l103 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb23
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t38, ptr %l33, !tbaa !27
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i32, ptr %t42, i64 %t39
  %t44 = load i32, ptr %t43, !tbaa !33
  store i32 %t44, ptr %l8, !tbaa !23
  %t48 = icmp sgt i64 %t36, 0
  br i1 %t48, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t50, { i64, ptr } { i64 1, ptr @.d142 })
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t52, i32 %t53)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb6
bb16:
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t66 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t66, { i64, ptr } { i64 1, ptr @.d143 })
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t68, { i64, ptr } %t69)
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t72, { i64, ptr } { i64 1, ptr @.d144 })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  br label %bb84
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t75 = load ptr, ptr %l50, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l50, !tbaa !29
  %t79 = load i64, ptr %t78
  %t81 = icmp eq i64 %t79, 1
  store i1 %t81, ptr %l51, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l51, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l9, !tbaa !29
  br label %bb28
bb27:
  br label %bb31
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t89 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t89, { i64, ptr } { i64 2, ptr @.d145 })
  br label %bb29
bb29:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t91, ptr %t92, i1 true)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb84
bb31:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t96 = load ptr, ptr %l59, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb32, label %bb33
bb32:
  %t99 = load ptr, ptr %l59, !tbaa !29
  %t100 = load i64, ptr %t99
  %t102 = icmp eq i64 %t100, 2
  store i1 %t102, ptr %l60, !tbaa !21
  br label %bb33
bb33:
  %t103 = load i1, ptr %l60, !tbaa !21
  br i1 %t103, label %bb34, label %bb35
bb34:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", ptr }, ptr %t106, i32 0, i32 1
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l10, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  br label %bb37
bb37:
  br label %bb84
bb38:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t115 = load ptr, ptr %l67, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb39, label %bb40
bb39:
  %t118 = load ptr, ptr %l67, !tbaa !29
  %t119 = load i64, ptr %t118
  %t121 = icmp eq i64 %t119, 3
  store i1 %t121, ptr %l68, !tbaa !21
  br label %bb40
bb40:
  %t122 = load i1, ptr %l68, !tbaa !21
  br i1 %t122, label %bb41, label %bb42
bb41:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr }, ptr %t125, i32 0, i32 1
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t129, ptr %t130)
  br label %bb44
bb44:
  br label %bb84
bb45:
  %t133 = load ptr, ptr %l1, !tbaa !29
  store ptr %t133, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t134 = load ptr, ptr %l75, !tbaa !29
  %t135 = icmp ne ptr %t134, null
  br i1 %t135, label %bb46, label %bb47
bb46:
  %t137 = load ptr, ptr %l75, !tbaa !29
  %t138 = load i64, ptr %t137
  %t140 = icmp eq i64 %t138, 4
  store i1 %t140, ptr %l76, !tbaa !21
  br label %bb47
bb47:
  %t141 = load i1, ptr %l76, !tbaa !21
  br i1 %t141, label %bb48, label %bb49
bb48:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [5 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t144, i32 0, i32 1
  %t146 = load ptr, ptr %t145
  store ptr %t146, ptr %l12, !tbaa !29
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t150, i32 0, i32 2
  %t152 = load i32, ptr %t151
  store i32 %t152, ptr %l13, !tbaa !23
  br label %bb50
bb49:
  br label %bb57
bb50:
  store %olang.scope zeroinitializer, ptr %s10
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t154, ptr %t155)
  br label %bb51
bb51:
  %t158 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t158, { i64, ptr } { i64 1, ptr @.d146 })
  br label %bb52
bb52:
  %t160 = load i32, ptr %l13, !tbaa !23
  %t162 = icmp ne i32 %t160, 0
  br i1 %t162, label %bb53, label %bb54
bb53:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t164, i32 %t165)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb57:
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t169 = load ptr, ptr %l90, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb58, label %bb59
bb58:
  %t172 = load ptr, ptr %l90, !tbaa !29
  %t173 = load i64, ptr %t172
  %t175 = icmp eq i64 %t173, 5
  store i1 %t175, ptr %l91, !tbaa !21
  br label %bb59
bb59:
  %t176 = load i1, ptr %l91, !tbaa !21
  br i1 %t176, label %bb60, label %bb61
bb60:
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t179, i32 0, i32 1
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l14, !tbaa !29
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t185, i32 0, i32 2
  %t187 = load i1, ptr %t186
  store i1 %t187, ptr %l15, !tbaa !21
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t191, i32 0, i32 3
  %t193 = load i1, ptr %t192
  store i1 %t193, ptr %l16, !tbaa !21
  br label %bb62
bb61:
  br label %bb83
bb62:
  %t195 = load i1, ptr %l16, !tbaa !21
  br i1 %t195, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s13
  %t197 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t197, { i64, ptr } { i64 3, ptr @.d147 })
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s13)
  br label %bb66
bb66:
  %t199 = load i1, ptr %l16, !tbaa !21
  br i1 %t199, label %bb67, label %bb68
bb67:
  %t201 = load i1, ptr %l15, !tbaa !21
  store i1 %t201, ptr %l103, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb69
bb69:
  %t203 = load i1, ptr %l103, !tbaa !21
  br i1 %t203, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s14
  %t204 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t204, { i64, ptr } { i64 1, ptr @.d148 })
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s14)
  br label %bb73
bb73:
  %t206 = load i1, ptr %l15, !tbaa !21
  br i1 %t206, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s15
  %t208 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t208, { i64, ptr } { i64 3, ptr @.d149 })
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_scope_close(ptr %s15)
  br label %bb77
bb77:
  %t210 = load ptr, ptr %l14, !tbaa !29
  %t212 = icmp ne ptr %t210, null
  br i1 %t212, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s16
  %t214 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t214, { i64, ptr } { i64 1, ptr @.d150 })
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t216, ptr %t217)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s16)
  br label %bb82
bb82:
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @.c151)
  unreachable
bb84:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l51 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca i1
  %l91 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb19
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t16, { i64, ptr } { i64 6, ptr @.d152 })
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:StructBody", ptr %t19, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t18, { i64, ptr } %t22)
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t25, { i64, ptr } { i64 1, ptr @.d153 })
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/ast:StructBody", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t27, { i64, ptr } %t31)
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t34, { i64, ptr } { i64 1, ptr @.d154 })
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:StructBody", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t36, ptr %t40, i1 false)
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t43, { i64, ptr } { i64 1, ptr @.d155 })
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/ast:StructBody", ptr %t46, i32 0, i32 2
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t45, { i64, ptr } %t49)
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/ast:StructBody", ptr %t52, i32 0, i32 4
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } zeroinitializer, 0
  %t59 = icmp eq i64 %t57, %t58
  %t60 = extractvalue { i64, ptr } %t55, 1
  %t61 = extractvalue { i64, ptr } zeroinitializer, 1
  %t62 = icmp eq ptr %t60, %t61
  %t63 = and i1 %t59, %t62
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t66 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t66, { i64, ptr } { i64 10, ptr @.d156 })
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/ast:StructBody", ptr %t69, i32 0, i32 4
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t68, { i64, ptr } %t72)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  br label %bb81
bb19:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l44, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 1
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb21
bb21:
  %t83 = load i1, ptr %l45, !tbaa !21
  br i1 %t83, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [2 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { { i64, ptr } }, ptr %t86, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87
  store { i64, ptr } %t88, ptr %l3, !tbaa !27
  br label %bb24
bb23:
  br label %bb42
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t90, { i64, ptr } { i64 6, ptr @.d157 })
  br label %bb25
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l51, !tbaa !29
  %t93 = load ptr, ptr %l51, !tbaa !29
  %t94 = getelementptr %"compiler/unparse:writer", ptr %t93, i32 0, i32 4
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = add i64 %t95, 1
  %t99 = load ptr, ptr %l51, !tbaa !29
  %t100 = getelementptr %"compiler/unparse:writer", ptr %t99, i32 0, i32 4
  store i64 %t97, ptr %t100, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t101, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l6, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load i64, ptr %l5, !tbaa !24
  %t108 = load i64, ptr %l6, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb28:
  br label %bb29
bb29:
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t115, ptr %l61, !tbaa !27
  %t116 = load i64, ptr %l5, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr ptr, ptr %t119, i64 %t116
  %t121 = load ptr, ptr %t120, !tbaa !39
  store ptr %t121, ptr %l7, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t123)
  br label %bb30
bb30:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t128 = getelementptr %"compiler/ast:CaseDecl", ptr %t126, i32 0, i32 1
  %t129 = load i32, ptr %t128, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t125, i32 %t129)
  br label %bb31
bb31:
  %t132 = load ptr, ptr %l7, !tbaa !29
  %t134 = getelementptr %"compiler/ast:CaseDecl", ptr %t132, i32 0, i32 2
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t139 = icmp sgt i64 %t137, 0
  br i1 %t139, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t141, { i64, ptr } { i64 1, ptr @.d158 })
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l7, !tbaa !29
  %t146 = getelementptr %"compiler/ast:CaseDecl", ptr %t144, i32 0, i32 2
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t143, { i64, ptr } %t147)
  br label %bb35
bb35:
  %t150 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t150, { i64, ptr } { i64 1, ptr @.d159 })
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  %t152 = load i64, ptr %l5, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l5, !tbaa !24
  br label %bb26
bb39:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l79, !tbaa !29
  %t157 = load ptr, ptr %l79, !tbaa !29
  %t158 = getelementptr %"compiler/unparse:writer", ptr %t157, i32 0, i32 4
  %t159 = load i64, ptr %t158, !tbaa !24
  %t161 = sub i64 %t159, 1
  %t163 = load ptr, ptr %l79, !tbaa !29
  %t164 = getelementptr %"compiler/unparse:writer", ptr %t163, i32 0, i32 4
  store i64 %t161, ptr %t164, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t165)
  br label %bb40
bb40:
  %t167 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t167, { i64, ptr } { i64 1, ptr @.d160 })
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb81
bb42:
  %t169 = load ptr, ptr %l1, !tbaa !29
  store ptr %t169, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t170 = load ptr, ptr %l84, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb43, label %bb44
bb43:
  %t173 = load ptr, ptr %l84, !tbaa !29
  %t174 = load i64, ptr %t173
  %t176 = icmp eq i64 %t174, 2
  store i1 %t176, ptr %l85, !tbaa !21
  br label %bb44
bb44:
  %t177 = load i1, ptr %l85, !tbaa !21
  br i1 %t177, label %bb45, label %bb46
bb45:
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { { i64, ptr } }, ptr %t180, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181
  store { i64, ptr } %t182, ptr %l8, !tbaa !27
  br label %bb47
bb46:
  br label %bb64
bb47:
  store %olang.scope zeroinitializer, ptr %s8
  %t184 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t184, { i64, ptr } { i64 7, ptr @.d161 })
  br label %bb48
bb48:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l91, !tbaa !29
  %t187 = load ptr, ptr %l91, !tbaa !29
  %t188 = getelementptr %"compiler/unparse:writer", ptr %t187, i32 0, i32 4
  %t189 = load i64, ptr %t188, !tbaa !24
  %t191 = add i64 %t189, 1
  %t193 = load ptr, ptr %l91, !tbaa !29
  %t194 = getelementptr %"compiler/unparse:writer", ptr %t193, i32 0, i32 4
  store i64 %t191, ptr %t194, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t195, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  store i64 %t199, ptr %l11, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t201 = load i64, ptr %l10, !tbaa !24
  %t202 = load i64, ptr %l11, !tbaa !24
  %t205 = icmp slt i64 %t201, %t202
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb51:
  br label %bb52
bb52:
  %t209 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t209, ptr %l101, !tbaa !27
  %t210 = load i64, ptr %l10, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr ptr, ptr %t213, i64 %t210
  %t215 = load ptr, ptr %t214, !tbaa !39
  store ptr %t215, ptr %l12, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t217)
  br label %bb53
bb53:
  %t219 = load ptr, ptr %l12, !tbaa !29
  %t221 = getelementptr %"compiler/ast:Func", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = icmp ne ptr %t222, null
  br i1 %t224, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s11
  %t226 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t226, { i64, ptr } { i64 4, ptr @.d162 })
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb57:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l12, !tbaa !29
  %t231 = getelementptr %"compiler/ast:Func", ptr %t229, i32 0, i32 2
  %t232 = load i32, ptr %t231, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t228, i32 %t232)
  br label %bb58
bb58:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l12, !tbaa !29
  %t238 = getelementptr %"compiler/ast:Func", ptr %t236, i32 0, i32 3
  %t239 = load ptr, ptr %t238, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t235, ptr %t239, i1 false)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  %t242 = load i64, ptr %l10, !tbaa !24
  %t244 = add i64 %t242, 1
  store i64 %t244, ptr %l10, !tbaa !24
  br label %bb49
bb61:
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l117, !tbaa !29
  %t247 = load ptr, ptr %l117, !tbaa !29
  %t248 = getelementptr %"compiler/unparse:writer", ptr %t247, i32 0, i32 4
  %t249 = load i64, ptr %t248, !tbaa !24
  %t251 = sub i64 %t249, 1
  %t253 = load ptr, ptr %l117, !tbaa !29
  %t254 = getelementptr %"compiler/unparse:writer", ptr %t253, i32 0, i32 4
  store i64 %t251, ptr %t254, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t255)
  br label %bb62
bb62:
  %t257 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t257, { i64, ptr } { i64 1, ptr @.d163 })
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  br label %bb81
bb64:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t260 = load ptr, ptr %l122, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb65, label %bb66
bb65:
  %t263 = load ptr, ptr %l122, !tbaa !29
  %t264 = load i64, ptr %t263
  %t266 = icmp eq i64 %t264, 3
  store i1 %t266, ptr %l123, !tbaa !21
  br label %bb66
bb66:
  %t267 = load i1, ptr %l123, !tbaa !21
  br i1 %t267, label %bb67, label %bb68
bb67:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [2 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { ptr, ptr }, ptr %t270, i32 0, i32 0
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l13, !tbaa !29
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t276 = getelementptr { i64, [2 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { ptr, ptr }, ptr %t276, i32 0, i32 1
  %t278 = load ptr, ptr %t277
  store ptr %t278, ptr %l14, !tbaa !29
  br label %bb69
bb68:
  br label %bb80
bb69:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t280, ptr %t281)
  br label %bb70
bb70:
  %t284 = load ptr, ptr %l14, !tbaa !29
  %t286 = icmp ne ptr %t284, null
  br i1 %t286, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s14
  %t288 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t288, { i64, ptr } { i64 1, ptr @.d164 })
  br label %bb73
bb72:
  br label %bb79
bb73:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load ptr, ptr %l14, !tbaa !29
  %t293 = getelementptr %"compiler/ast:Func", ptr %t291, i32 0, i32 3
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/ast:Sig", ptr %t294, i32 0, i32 0
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t290, { i64, ptr } %t297)
  br label %bb74
bb74:
  %t300 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t300, { i64, ptr } { i64 1, ptr @.d165 })
  br label %bb75
bb75:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load ptr, ptr %l14, !tbaa !29
  %t305 = getelementptr %"compiler/ast:Func", ptr %t303, i32 0, i32 3
  %t306 = load ptr, ptr %t305, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t302, ptr %t306, i1 false)
  br label %bb76
bb76:
  %t309 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t309, { i64, ptr } { i64 1, ptr @.d166 })
  br label %bb77
bb77:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load ptr, ptr %l14, !tbaa !29
  %t314 = getelementptr %"compiler/ast:Func", ptr %t312, i32 0, i32 4
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t311, { i64, ptr } %t315)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s14)
  br label %bb79
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @.c167)
  unreachable
bb81:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 5, ptr @.d168 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:TypeDecl", ptr %t4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t3, i32 %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:TypeDecl", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t14)
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TypeDecl", ptr %t17, i32 0, i32 2
  %t20 = load i1, ptr %t19, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t22, { i64, ptr } { i64 8, ptr @.d169 })
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t24, { i64, ptr } { i64 1, ptr @.d170 })
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TypeDecl", ptr %t27, i32 0, i32 3
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i1
  %l22 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = extractvalue { i64, ptr } zeroinitializer, 0
  %t5 = icmp eq i64 %t3, %t4
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } zeroinitializer, 1
  %t8 = icmp eq ptr %t6, %t7
  %t9 = and i1 %t5, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp eq i64 %t13, 0
  store i1 %t15, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t18, { i64, ptr } { i64 1, ptr @.d171 })
  br label %bb7
bb7:
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb10:
  br label %bb11
bb11:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 %t37
  %t42 = load ptr, ptr %t41, !tbaa !39
  store ptr %t42, ptr %l6, !tbaa !29
  %t46 = icmp sgt i64 %t34, 0
  br i1 %t46, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t48, { i64, ptr } { i64 2, ptr @.d172 })
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l6, !tbaa !29
  %t53 = getelementptr %"compiler/ast:TypeParam", ptr %t51, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t50, i32 %t54)
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l6, !tbaa !29
  %t59 = getelementptr %"compiler/ast:TypeParam", ptr %t57, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = icmp ne ptr %t60, null
  br i1 %t62, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t64, { i64, ptr } { i64 1, ptr @.d173 })
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l6, !tbaa !29
  %t69 = getelementptr %"compiler/ast:TypeParam", ptr %t67, i32 0, i32 2
  %t70 = load ptr, ptr %t69, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t66, ptr %t70)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l3, !tbaa !24
  br label %bb8
bb23:
  %t77 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t77, { i64, ptr } { i64 1, ptr @.d174 })
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t27 = icmp sgt i64 %t15, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t29, { i64, ptr } { i64 2, ptr @.d175 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t30 = icmp sgt i64 %t18, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t32, { i64, ptr } { i64 2, ptr @.d176 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t34, i32 %t35)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/ast:VarDecl", ptr %t42, i32 0, i32 4
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t47, i32 0, i32 2
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp ne ptr %t50, null
  br i1 %t52, label %bb14, label %bb15
bb13:
  br label %bb21
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t54, { i64, ptr } { i64 1, ptr @.d177 })
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/ast:VarDecl", ptr %t57, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t63, { i64, ptr } { i64 4, ptr @.d178 })
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:VarDecl", ptr %t66, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t65, { i64, ptr } %t69)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/ast:VarDecl", ptr %t72, i32 0, i32 2
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  br i1 %t77, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t79 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t79, { i64, ptr } { i64 1, ptr @.d179 })
  br label %bb25
bb25:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/ast:VarDecl", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t81, ptr %t85)
  br label %bb26
bb26:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/ast:VarDecl", ptr %t88, i32 0, i32 3
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  %t97 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t97, { i64, ptr } { i64 3, ptr @.d180 })
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/ast:VarDecl", ptr %t100, i32 0, i32 3
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t99, { i64, ptr } %t103)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i32
  %l16 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l68 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load i32, ptr %l1
  store i32 %t16, ptr %l14
  store i32 50, ptr %l16
  %t19 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l14, ptr %l16)
  store i1 %t19, ptr %l18
  br label %bb6
bb6:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb10
bb8:
  %t21 = load i32, ptr %l1
  store i32 %t21, ptr %l20
  store i32 72, ptr %l22
  %t24 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l20, ptr %l22)
  store i1 %t24, ptr %l24
  br label %bb9
bb9:
  %t25 = load i1, ptr %l24, !tbaa !21
  store i1 %t25, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l19, !tbaa !21
  store i1 %t26, ptr %l7, !tbaa !21
  br label %bb53
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t28 = load ptr, ptr %l25, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb12, label %bb13
bb12:
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 1
  store i1 %t34, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb53
bb17:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t37 = load ptr, ptr %l29, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l29, !tbaa !29
  %t41 = load i64, ptr %t40
  %t43 = icmp eq i64 %t41, 5
  store i1 %t43, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l30, !tbaa !21
  br i1 %t44, label %bb20, label %bb21
bb20:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t51)
  store i1 %t53, ptr %l36
  br label %bb23
bb23:
  %t54 = load i1, ptr %l36, !tbaa !21
  store i1 %t54, ptr %l7, !tbaa !21
  br label %bb53
bb24:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t56 = load ptr, ptr %l37, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb25, label %bb26
bb25:
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l38, !tbaa !21
  br label %bb26
bb26:
  %t63 = load i1, ptr %l38, !tbaa !21
  br i1 %t63, label %bb27, label %bb28
bb27:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l3, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t70)
  store i1 %t72, ptr %l44
  br label %bb30
bb30:
  %t73 = load i1, ptr %l44, !tbaa !21
  store i1 %t73, ptr %l7, !tbaa !21
  br label %bb53
bb31:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t75 = load ptr, ptr %l45, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb32, label %bb33
bb32:
  %t78 = load ptr, ptr %l45, !tbaa !29
  %t79 = load i64, ptr %t78
  %t81 = icmp eq i64 %t79, 12
  store i1 %t81, ptr %l46, !tbaa !21
  br label %bb33
bb33:
  %t82 = load i1, ptr %l46, !tbaa !21
  br i1 %t82, label %bb34, label %bb35
bb34:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t89)
  store i1 %t91, ptr %l52
  br label %bb37
bb37:
  %t92 = load i1, ptr %l52, !tbaa !21
  store i1 %t92, ptr %l7, !tbaa !21
  br label %bb53
bb38:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t94 = load ptr, ptr %l53, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb39, label %bb40
bb39:
  %t97 = load ptr, ptr %l53, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 15
  store i1 %t100, ptr %l54, !tbaa !21
  br label %bb40
bb40:
  %t101 = load i1, ptr %l54, !tbaa !21
  br i1 %t101, label %bb41, label %bb42
bb41:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t108)
  store i1 %t110, ptr %l60
  br label %bb44
bb44:
  %t111 = load i1, ptr %l60, !tbaa !21
  store i1 %t111, ptr %l7, !tbaa !21
  br label %bb53
bb45:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t113 = load ptr, ptr %l61, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb46, label %bb47
bb46:
  %t116 = load ptr, ptr %l61, !tbaa !29
  %t117 = load i64, ptr %t116
  %t119 = icmp eq i64 %t117, 16
  store i1 %t119, ptr %l62, !tbaa !21
  br label %bb47
bb47:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb48, label %bb49
bb48:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l6, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t129 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t127)
  store i1 %t129, ptr %l68
  br label %bb51
bb51:
  %t130 = load i1, ptr %l68, !tbaa !21
  store i1 %t130, ptr %l7, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb53
bb53:
  %t131 = load i1, ptr %l7, !tbaa !21
  store i1 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/unparse:writer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store ptr %a2, ptr %l5, !tbaa !29
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v3)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l12
  store %"std/prelude/text:StringBuilder" %t8, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l13
  br label %bb2
bb2:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = insertvalue %"compiler/unparse:writer" undef, ptr %t12, 0
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = insertvalue %"compiler/unparse:writer" %t13, { i64, ptr } %t14, 1
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t17 = insertvalue %"compiler/unparse:writer" %t15, ptr %t16, 2
  %t18 = load %"std/prelude/text:StringBuilder", ptr %l6
  %t19 = insertvalue %"compiler/unparse:writer" %t17, %"std/prelude/text:StringBuilder" %t18, 3
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = insertvalue %"compiler/unparse:writer" %t19, i64 %t20, 4
  %t23 = insertvalue %"compiler/unparse:writer" %t21, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 5
  store %"compiler/unparse:writer" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/unparse:writer", ptr %rv
  ret %"compiler/unparse:writer" %rr
}

define dso_local void @olang_2einit_2ecompiler_2funparse() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2funparse_2eMaxIndent_2einit()
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant [3 x i8] c"{ }"
@.d1 = private constant [1 x i8] c"{"
@.d2 = private constant [1 x i8] c"}"
@.d3 = private constant [4 x i8] c" => "
@.d4 = private constant [1 x i8] c" "
@.d5 = private constant [6 x i8] c" catch"
@.d6 = private constant [2 x i8] c", "
@.d7 = private constant [1 x i8] c" "
@.d8 = private constant [1 x i8] c" "
@.d9 = private constant [9 x i8] c" default "
@.d10 = private constant [10 x i8] c"extern fn "
@.d11 = private constant [7 x i8] c"import "
@.d12 = private constant [1 x i8] c" "
@.d13 = private constant [6 x i8] c"error "
@.d14 = private constant [2 x i8] c" {"
@.d15 = private constant [1 x i8] c"}"
@.d16 = private constant [5 x i8] c"test "
@.d17 = private constant [1 x i8] c" "
declare void @__olang_check_failed(ptr)
@.c18 = private unnamed_addr constant [53 x i8] c"compiler/unparse.olang:56: reached unreachable code\0A\00"
@.d19 = private constant [2 x i8] c" ?"
@.d20 = private constant [2 x i8] c" ("
@.d21 = private constant [1 x i8] c" "
@.d22 = private constant [2 x i8] c", "
@.d23 = private constant [1 x i8] c")"
@.d24 = private constant [1 x i8] c"("
@.d25 = private constant [1 x i8] c")"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d26 = private constant [1 x i8] c" "
@.d27 = private constant [1 x i8] c" "
@.d28 = private constant [1 x i8] c" "
@.d29 = private constant [1 x i8] c" "
@.d30 = private constant [8 x i8] c" not in "
@.d31 = private constant [1 x i8] c" "
@.d32 = private constant [1 x i8] c" "
@.d33 = private constant [4 x i8] c" if "
@.d34 = private constant [6 x i8] c" else "
@.d35 = private constant [8 x i8] c" is not "
@.d36 = private constant [4 x i8] c" is "
@.d37 = private constant [8 x i8] c" is not "
@.d38 = private constant [4 x i8] c" is "
@.d39 = private constant [4 x i8] c" as "
@.d40 = private constant [1 x i8] c"("
@.d41 = private constant [1 x i8] c")"
@.d42 = private constant [1 x i8] c"&"
@.d43 = private constant [1 x i8] c"("
@.d44 = private constant [1 x i8] c")"
@.d45 = private constant [1 x i8] c"<"
@.d46 = private constant [1 x i8] c">"
@.d47 = private constant [1 x i8] c"."
@.d48 = private constant [1 x i8] c"["
@.d49 = private constant [1 x i8] c"]"
@.d50 = private constant [1 x i8] c"["
@.d51 = private constant [1 x i8] c":"
@.d52 = private constant [1 x i8] c"]"
@.d53 = private constant [1 x i8] c"["
@.d54 = private constant [1 x i8] c"]"
@.d55 = private constant [1 x i8] c"["
@.d56 = private constant [1 x i8] c"]"
@.d57 = private constant [1 x i8] c"["
@.d58 = private constant [5 x i8] c" for "
@.d59 = private constant [2 x i8] c", "
@.d60 = private constant [4 x i8] c" in "
@.d61 = private constant [4 x i8] c" if "
@.d62 = private constant [1 x i8] c"]"
@.d63 = private constant [1 x i8] c" "
@.d64 = private constant [8 x i8] c"checked "
@.d65 = private constant [4 x i8] c"try "
@.d66 = private constant [2 x i8] c"fn"
@.d67 = private constant [1 x i8] c" "
@.d68 = private constant [6 x i8] c"range "
@.d69 = private constant [7 x i8] c"default"
@.c70 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:589: reached unreachable code\0A\00"
@.d71 = private constant [2 x i8] c", "
@.d72 = private constant [3 x i8] c"fn "
@.d73 = private constant [1 x i8] c"("
@.d74 = private constant [2 x i8] c") "
@.d75 = private constant [1 x i8] c" "
@.d76 = private constant [3 x i8] c"if "
@.d77 = private constant [1 x i8] c" "
@.d78 = private constant [6 x i8] c" else "
@.d79 = private constant [6 x i8] c"match "
@.d80 = private constant [2 x i8] c" {"
@.d81 = private constant [5 x i8] c"case "
@.d82 = private constant [2 x i8] c", "
@.d83 = private constant [2 x i8] c", "
@.d84 = private constant [4 x i8] c" if "
@.d85 = private constant [7 x i8] c"nomatch"
@.d86 = private constant [1 x i8] c"}"
@.d87 = private constant [4 x i8] c"    "
@.d88 = private constant [1 x i8] c" "
@.d89 = private constant [3 x i8] c" = "
@.d90 = private constant [2 x i8] c", "
@.d91 = private constant [1 x i8] c"."
@.d92 = private constant [1 x i8] c"_"
@.d93 = private constant [1 x i8] c"("
@.d94 = private constant [2 x i8] c", "
@.d95 = private constant [1 x i8] c")"
@.c96 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:562: reached unreachable code\0A\00"
@.d97 = private constant [1 x i8] c"("
@.d98 = private constant [1 x i8] c")"
@.d99 = private constant [9 x i8] c" noreturn"
@.d100 = private constant [1 x i8] c" "
@.d101 = private constant [2 x i8] c" ("
@.d102 = private constant [1 x i8] c")"
@.c103 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:41: slice bounds out of range\0A\00"
@.d104 = private constant [4 x i8] c" := "
@.d105 = private constant [3 x i8] c" = "
@.d106 = private constant [1 x i8] c" "
@.d107 = private constant [1 x i8] c" "
@.d108 = private constant [8 x i8] c"checked "
@.d109 = private constant [4 x i8] c"try "
@.d110 = private constant [4 x i8] c"for "
@.d111 = private constant [4 x i8] c"for "
@.d112 = private constant [1 x i8] c" "
@.d113 = private constant [4 x i8] c"for "
@.d114 = private constant [2 x i8] c", "
@.d115 = private constant [2 x i8] c", "
@.d116 = private constant [1 x i8] c" "
@.d117 = private constant [4 x i8] c"for "
@.d118 = private constant [2 x i8] c", "
@.d119 = private constant [4 x i8] c" in "
@.d120 = private constant [4 x i8] c"try "
@.d121 = private constant [1 x i8] c" "
@.d122 = private constant [3 x i8] c"do "
@.d123 = private constant [5 x i8] c" for "
@.d124 = private constant [6 x i8] c"return"
@.d125 = private constant [1 x i8] c" "
@.d126 = private constant [7 x i8] c"assert "
@.d127 = private constant [2 x i8] c", "
@.d128 = private constant [5 x i8] c"error"
@.d129 = private constant [1 x i8] c" "
@.d130 = private constant [6 x i8] c"spawn "
@.d131 = private constant [3 x i8] c" = "
@.d132 = private constant [4 x i8] c"try "
@.d133 = private constant [5 x i8] c"join "
@.d134 = private constant [6 x i8] c"defer "
@.c135 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:386: reached unreachable code\0A\00"
@.d136 = private constant [1 x i8] c"{"
@.d137 = private constant [1 x i8] c"}"
@.d138 = private constant [3 x i8] c"if "
@.d139 = private constant [1 x i8] c" "
@.d140 = private constant [6 x i8] c" else "
@.d141 = private constant [6 x i8] c" else "
@.d142 = private constant [1 x i8] c"."
@.d143 = private constant [1 x i8] c"<"
@.d144 = private constant [1 x i8] c">"
@.d145 = private constant [2 x i8] c"fn"
@.d146 = private constant [1 x i8] c"&"
@.d147 = private constant [3 x i8] c"own"
@.d148 = private constant [1 x i8] c" "
@.d149 = private constant [3 x i8] c"mut"
@.d150 = private constant [1 x i8] c" "
@.c151 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:290: reached unreachable code\0A\00"
@.d152 = private constant [6 x i8] c"struct"
@.d153 = private constant [1 x i8] c"("
@.d154 = private constant [1 x i8] c")"
@.d155 = private constant [1 x i8] c" "
@.d156 = private constant [10 x i8] c" destruct "
@.d157 = private constant [6 x i8] c"enum {"
@.d158 = private constant [1 x i8] c"("
@.d159 = private constant [1 x i8] c")"
@.d160 = private constant [1 x i8] c"}"
@.d161 = private constant [7 x i8] c"trait {"
@.d162 = private constant [4 x i8] c"mut "
@.d163 = private constant [1 x i8] c"}"
@.d164 = private constant [1 x i8] c"("
@.d165 = private constant [1 x i8] c")"
@.d166 = private constant [1 x i8] c" "
@.c167 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:222: reached unreachable code\0A\00"
@.d168 = private constant [5 x i8] c"type "
@.d169 = private constant [8 x i8] c" extends"
@.d170 = private constant [1 x i8] c" "
@.d171 = private constant [1 x i8] c"<"
@.d172 = private constant [2 x i8] c", "
@.d173 = private constant [1 x i8] c" "
@.d174 = private constant [1 x i8] c">"
@.d175 = private constant [2 x i8] c", "
@.d176 = private constant [2 x i8] c", "
@.d177 = private constant [1 x i8] c" "
@.d178 = private constant [4 x i8] c" := "
@.d179 = private constant [1 x i8] c" "
@.d180 = private constant [3 x i8] c" = "
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
