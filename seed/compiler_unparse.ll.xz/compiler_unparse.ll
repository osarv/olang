; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/unparse:writer" = type { ptr, { i64, ptr }, ptr, %"std/prelude/text:StringBuilder", i64, %"std/prelude/list:List<compiler/source:Span>" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"std/prelude/list:List<compiler/source:Span>" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
@G_2ecompiler_2funparse_2eMaxIndent = global i64 zeroinitializer
define dso_local { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"compiler/unparse:writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca %"compiler/unparse:writer"
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t2, ptr %l10, !tbaa !27
  %t3 = load ptr, ptr %l3, !tbaa !29
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = call %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %t4, { i64, ptr } %t5, ptr %t6)
  store %"compiler/unparse:writer" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/unparse:writer", ptr %l12
  store %"compiler/unparse:writer" %t8, ptr %l4
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l13, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t11, ptr %l14, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l15, !tbaa !24
  %t14 = load i64, ptr %l15, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l6, !tbaa !24
  store i64 %t15, ptr %l16, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  store i64 %t16, ptr %l17, !tbaa !24
  %t17 = load i64, ptr %l16, !tbaa !24
  %t18 = load i64, ptr %l17, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l18, !tbaa !21
  %t20 = load i1, ptr %l18, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l19, !tbaa !21
  %t22 = load i1, ptr %l19, !tbaa !21
  br i1 %t22, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  store i64 %t24, ptr %l21, !tbaa !24
  %t25 = load i64, ptr %l21, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t25
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l22, !tbaa !29
  store ptr %t30, ptr %l8, !tbaa !29
  store ptr %l4, ptr %l23, !tbaa !29
  %t31 = load ptr, ptr %l8, !tbaa !29
  store ptr %t31, ptr %l24, !tbaa !29
  %t32 = load ptr, ptr %l23, !tbaa !29
  %t33 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %s0, ptr %v0, ptr %t32, ptr %t33)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = load i64, ptr %l6, !tbaa !24
  store i64 %t34, ptr %l25, !tbaa !24
  %t35 = load i64, ptr %l25, !tbaa !24
  %t36 = add i64 %t35, 1
  store i64 %t36, ptr %l26, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb2
bb8:
  call void @__olang_scope_close(ptr %s1)
  %t38 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 5
  store ptr %t38, ptr %l27, !tbaa !29
  %t39 = load ptr, ptr %l27, !tbaa !29
  %t40 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %v4, ptr %t39)
  store { i64, ptr } %t40, ptr %l28
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l30, !tbaa !24
  %t45 = mul i64 %t44, 8
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l31, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l30, !tbaa !24
  %t54 = mul i64 %t53, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2funparse_2eMaxIndent_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 64, ptr @G_2ecompiler_2funparse_2eMaxIndent, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load i64, ptr %l7, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l8, !tbaa !21
  %t6 = load i1, ptr %l8, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l9, !tbaa !29
  %t8 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t8, { i64, ptr } { i64 3, ptr @.d0 })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 1, ptr @.d1 })
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l11, !tbaa !29
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = getelementptr %"compiler/unparse:writer", ptr %t12, i32 0, i32 4
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l12, !tbaa !24
  %t16 = add i64 %t15, 1
  store i64 %t16, ptr %l13, !tbaa !24
  %t17 = load i64, ptr %l13, !tbaa !24
  %t18 = load ptr, ptr %l11, !tbaa !29
  %t19 = getelementptr %"compiler/unparse:writer", ptr %t18, i32 0, i32 4
  store i64 %t17, ptr %t19, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l14, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l16, !tbaa !24
  %t25 = load i64, ptr %l16, !tbaa !24
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  store i64 %t27, ptr %l18, !tbaa !24
  %t28 = load i64, ptr %l17, !tbaa !24
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = icmp slt i64 %t28, %t29
  store i1 %t30, ptr %l19, !tbaa !21
  %t31 = load i1, ptr %l19, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l20, !tbaa !21
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t34, ptr %l21, !tbaa !27
  %t35 = load i64, ptr %l3, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 %t36
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %t40, ptr %l23, !tbaa !29
  %t41 = load ptr, ptr %l23, !tbaa !29
  store ptr %t41, ptr %l5, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l24, !tbaa !29
  %t43 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t43)
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l25, !tbaa !29
  %t45 = load ptr, ptr %l5, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l25, !tbaa !29
  %t47 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l3, !tbaa !24
  store i64 %t48, ptr %l27, !tbaa !24
  %t49 = load i64, ptr %l27, !tbaa !24
  %t50 = add i64 %t49, 1
  store i64 %t50, ptr %l28, !tbaa !24
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb6
bb13:
  call void @__olang_scope_close(ptr %s2)
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l29, !tbaa !29
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = getelementptr %"compiler/unparse:writer", ptr %t53, i32 0, i32 4
  %t55 = load i64, ptr %t54, !tbaa !24
  store i64 %t55, ptr %l30, !tbaa !24
  %t56 = load i64, ptr %l30, !tbaa !24
  %t57 = sub i64 %t56, 1
  store i64 %t57, ptr %l31, !tbaa !24
  %t58 = load i64, ptr %l31, !tbaa !24
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t60 = getelementptr %"compiler/unparse:writer", ptr %t59, i32 0, i32 4
  store i64 %t58, ptr %t60, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l32, !tbaa !29
  %t62 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t62)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  %t64 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t64, { i64, ptr } { i64 1, ptr @.d2 })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t2, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  %t7 = extractvalue { i64, ptr } zeroinitializer, 0
  %t8 = icmp eq i64 %t6, %t7
  %t9 = extractvalue { i64, ptr } %t5, 1
  %t10 = extractvalue { i64, ptr } zeroinitializer, 1
  %t11 = icmp eq ptr %t9, %t10
  %t12 = and i1 %t8, %t11
  store i1 %t12, ptr %l4, !tbaa !21
  %t13 = load i1, ptr %l4, !tbaa !21
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l6, !tbaa !29
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t16 = getelementptr %"compiler/unparse:writer", ptr %t15, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l7, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  store ptr %t18, ptr %l8, !tbaa !29
  %t19 = load ptr, ptr %l8, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t19, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l9, !tbaa !24
  %t22 = load ptr, ptr %l7, !tbaa !29
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t24, ptr %l10
  br label %bb3
bb3:
  %t25 = load i1, ptr %l10, !tbaa !21
  store i1 %t25, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t26 = load i1, ptr %l5, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l11, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l12, !tbaa !29
  %t29 = load ptr, ptr %l12, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Branch", ptr %t29, i32 0, i32 0
  %t31 = load %"compiler/source:Span", ptr %t30
  store %"compiler/source:Span" %t31, ptr %l13
  %t32 = load ptr, ptr %l11, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l13
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t32, %"compiler/source:Span" %t33)
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l14, !tbaa !29
  %t35 = load ptr, ptr %l14, !tbaa !29
  %t36 = getelementptr %"compiler/unparse:writer", ptr %t35, i32 0, i32 5
  store ptr %t36, ptr %l15, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l16, !tbaa !29
  %t38 = load ptr, ptr %l16, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Branch", ptr %t38, i32 0, i32 0
  %t40 = load %"compiler/source:Span", ptr %t39
  store %"compiler/source:Span" %t40, ptr %l17
  %t41 = load ptr, ptr %l15, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l17
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t41, %"compiler/source:Span" %t42)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l18, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l19, !tbaa !29
  %t45 = load ptr, ptr %l19, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Branch", ptr %t45, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l20, !tbaa !27
  %t48 = load ptr, ptr %l18, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t48, { i64, ptr } %t49)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t2, i32 0, i32 5
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = icmp ne ptr %t5, null
  store i1 %t6, ptr %l4, !tbaa !21
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t9, { i64, ptr } { i64 4, ptr @.d3 })
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l7, !tbaa !29
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Case", ptr %t12, i32 0, i32 5
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l8, !tbaa !29
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t15, ptr %t16)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l9, !tbaa !29
  %t18 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t18, { i64, ptr } { i64 1, ptr @.d4 })
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l11, !tbaa !29
  %t21 = load ptr, ptr %l11, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Case", ptr %t21, i32 0, i32 4
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l12, !tbaa !27
  %t24 = load ptr, ptr %l10, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %t25)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l11, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t3, ptr %l12, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l13, !tbaa !24
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l14, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l15, !tbaa !24
  %t9 = load i64, ptr %l14, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l16, !tbaa !21
  %t12 = load i1, ptr %l16, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l17, !tbaa !21
  %t14 = load i1, ptr %l17, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l19, !tbaa !24
  %t17 = load i64, ptr %l19, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t17
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l20, !tbaa !29
  %t22 = load ptr, ptr %l20, !tbaa !29
  store ptr %t22, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  %t24 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t24, { i64, ptr } { i64 6, ptr @.d5 })
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load ptr, ptr %l5, !tbaa !29
  store ptr %t25, ptr %l22, !tbaa !29
  %t26 = load ptr, ptr %l22, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Catch", ptr %t26, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l23, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t30, ptr %l24, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l25, !tbaa !24
  store i64 %t33, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load i64, ptr %l7, !tbaa !24
  store i64 %t34, ptr %l26, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  store i64 %t35, ptr %l27, !tbaa !24
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = icmp slt i64 %t36, %t37
  store i1 %t38, ptr %l28, !tbaa !21
  %t39 = load i1, ptr %l28, !tbaa !21
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l29, !tbaa !21
  %t41 = load i1, ptr %l29, !tbaa !21
  br i1 %t41, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  store i64 %t42, ptr %l30, !tbaa !24
  %t43 = load i64, ptr %l30, !tbaa !24
  store i64 %t43, ptr %l9, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  store i64 %t45, ptr %l32, !tbaa !24
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t46
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l33, !tbaa !29
  %t51 = load ptr, ptr %l33, !tbaa !29
  store ptr %t51, ptr %l10, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l34, !tbaa !29
  %t53 = load i64, ptr %l9, !tbaa !24
  store i64 %t53, ptr %l35, !tbaa !24
  %t54 = load i64, ptr %l35, !tbaa !24
  %t55 = icmp sgt i64 %t54, 0
  store i1 %t55, ptr %l36, !tbaa !21
  %t56 = load i1, ptr %l36, !tbaa !21
  br i1 %t56, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 2, ptr @.d6 }, ptr %l37, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 1, ptr @.d7 }, ptr %l37, !tbaa !27
  br label %bb12
bb12:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t57, { i64, ptr } %t58)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l38, !tbaa !29
  %t60 = load ptr, ptr %l10, !tbaa !29
  store ptr %t60, ptr %l39, !tbaa !29
  %t61 = load ptr, ptr %l38, !tbaa !29
  %t62 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t61, ptr %t62)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t63 = load i64, ptr %l7, !tbaa !24
  store i64 %t63, ptr %l40, !tbaa !24
  %t64 = load i64, ptr %l40, !tbaa !24
  %t65 = add i64 %t64, 1
  store i64 %t65, ptr %l41, !tbaa !24
  %t66 = load i64, ptr %l41, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb6
bb16:
  call void @__olang_scope_close(ptr %s3)
  %t67 = load ptr, ptr %l5, !tbaa !29
  store ptr %t67, ptr %l42, !tbaa !29
  %t68 = load ptr, ptr %l42, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Catch", ptr %t68, i32 0, i32 2
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l43, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = extractvalue { i64, ptr } zeroinitializer, 0
  %t74 = icmp eq i64 %t72, %t73
  %t75 = extractvalue { i64, ptr } %t71, 1
  %t76 = extractvalue { i64, ptr } zeroinitializer, 1
  %t77 = icmp eq ptr %t75, %t76
  %t78 = and i1 %t74, %t77
  %t79 = xor i1 %t78, true
  store i1 %t79, ptr %l44, !tbaa !21
  %t80 = load i1, ptr %l44, !tbaa !21
  br i1 %t80, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l45, !tbaa !29
  %t82 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t82, { i64, ptr } { i64 1, ptr @.d8 })
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l46, !tbaa !29
  %t84 = load ptr, ptr %l5, !tbaa !29
  store ptr %t84, ptr %l47, !tbaa !29
  %t85 = load ptr, ptr %l47, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Catch", ptr %t85, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l48, !tbaa !27
  %t88 = load ptr, ptr %l46, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l48, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t88, { i64, ptr } %t89)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l5, !tbaa !29
  store ptr %t90, ptr %l49, !tbaa !29
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = getelementptr %"compiler/ast:Catch", ptr %t91, i32 0, i32 3
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l50, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l51, !tbaa !24
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = icmp sgt i64 %t96, 0
  store i1 %t97, ptr %l52, !tbaa !21
  %t98 = load i1, ptr %l52, !tbaa !21
  br i1 %t98, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l53, !tbaa !29
  %t100 = load ptr, ptr %l53, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t100, { i64, ptr } { i64 9, ptr @.d9 })
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l54, !tbaa !29
  %t102 = load ptr, ptr %l5, !tbaa !29
  store ptr %t102, ptr %l55, !tbaa !29
  %t103 = load ptr, ptr %l55, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Catch", ptr %t103, i32 0, i32 3
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l56, !tbaa !27
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l56, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t106, { i64, ptr } %t107)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  %t108 = load i64, ptr %l3, !tbaa !24
  store i64 %t108, ptr %l57, !tbaa !24
  %t109 = load i64, ptr %l57, !tbaa !24
  %t110 = add i64 %t109, 1
  store i64 %t110, ptr %l58, !tbaa !24
  %t111 = load i64, ptr %l58, !tbaa !24
  store i64 %t111, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb1
bb28:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca ptr
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca i32
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l120 = alloca i1
  %l121 = alloca i1
  %l122 = alloca i64
  %l123 = alloca ptr
  %l124 = alloca ptr
  %l125 = alloca ptr
  %l126 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l19, !tbaa !21
  %t4 = load i1, ptr %l19, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l20, !tbaa !24
  %t7 = load i64, ptr %l20, !tbaa !24
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l21, !tbaa !29
  %t11 = load ptr, ptr %l21, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l22, !tbaa !29
  %t15 = load ptr, ptr %l22, !tbaa !29
  store ptr %t15, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l23, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l24, !tbaa !29
  %t18 = load ptr, ptr %l23, !tbaa !29
  %t19 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %t18, ptr %t19)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb80
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t21 = load ptr, ptr %l25, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  store i1 %t22, ptr %l27, !tbaa !21
  %t23 = load i1, ptr %l27, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l25, !tbaa !29
  %t25 = load i64, ptr %t24
  store i64 %t25, ptr %l28, !tbaa !24
  %t26 = load i64, ptr %l28, !tbaa !24
  %t27 = icmp eq i64 %t26, 1
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l26, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l29, !tbaa !29
  %t30 = load ptr, ptr %l29, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 1
  %t32 = getelementptr { ptr }, ptr %t31, i32 0, i32 0
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l30, !tbaa !29
  %t34 = load ptr, ptr %l30, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l31, !tbaa !29
  %t36 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t36, { i64, ptr } { i64 10, ptr @.d10 })
  br label %bb13
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l32, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  store ptr %t38, ptr %l33, !tbaa !29
  %t39 = load ptr, ptr %l33, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Func", ptr %t39, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  store i32 %t41, ptr %l34, !tbaa !23
  %t42 = load ptr, ptr %l32, !tbaa !29
  %t43 = load i32, ptr %l34, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t42, i32 %t43)
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l35, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  store ptr %t45, ptr %l36, !tbaa !29
  %t46 = load ptr, ptr %l36, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t46, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l37, !tbaa !29
  %t49 = load ptr, ptr %l35, !tbaa !29
  %t50 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t49, ptr %t50, i1 false)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb80
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  store i1 %t53, ptr %l40, !tbaa !21
  %t54 = load i1, ptr %l40, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l38, !tbaa !29
  %t56 = load i64, ptr %t55
  store i64 %t56, ptr %l41, !tbaa !24
  %t57 = load i64, ptr %l41, !tbaa !24
  %t58 = icmp eq i64 %t57, 2
  store i1 %t58, ptr %l39, !tbaa !21
  br label %bb18
bb18:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l42, !tbaa !29
  %t61 = load ptr, ptr %l42, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", ptr }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l43, !tbaa !29
  %t65 = load ptr, ptr %l43, !tbaa !29
  store ptr %t65, ptr %l4, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l44, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  store ptr %t67, ptr %l45, !tbaa !29
  %t68 = load ptr, ptr %l44, !tbaa !29
  %t69 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb80
bb23:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t71 = load ptr, ptr %l46, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  store i1 %t72, ptr %l48, !tbaa !21
  %t73 = load i1, ptr %l48, !tbaa !21
  br i1 %t73, label %bb24, label %bb25
bb24:
  %t74 = load ptr, ptr %l46, !tbaa !29
  %t75 = load i64, ptr %t74
  store i64 %t75, ptr %l49, !tbaa !24
  %t76 = load i64, ptr %l49, !tbaa !24
  %t77 = icmp eq i64 %t76, 3
  store i1 %t77, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  %t78 = load i1, ptr %l47, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l50, !tbaa !29
  %t80 = load ptr, ptr %l50, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l51, !tbaa !29
  %t84 = load ptr, ptr %l51, !tbaa !29
  store ptr %t84, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l52, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  store ptr %t86, ptr %l53, !tbaa !29
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = load ptr, ptr %l53, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb80
bb30:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t90 = load ptr, ptr %l54, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  store i1 %t91, ptr %l56, !tbaa !21
  %t92 = load i1, ptr %l56, !tbaa !21
  br i1 %t92, label %bb31, label %bb32
bb31:
  %t93 = load ptr, ptr %l54, !tbaa !29
  %t94 = load i64, ptr %t93
  store i64 %t94, ptr %l57, !tbaa !24
  %t95 = load i64, ptr %l57, !tbaa !24
  %t96 = icmp eq i64 %t95, 4
  store i1 %t96, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l55, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l58, !tbaa !29
  %t99 = load ptr, ptr %l58, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t99, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t100, i32 0, i32 1
  %t102 = load i32, ptr %t101
  store i32 %t102, ptr %l59, !tbaa !23
  %t103 = load i32, ptr %l59, !tbaa !23
  store i32 %t103, ptr %l6, !tbaa !23
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l60, !tbaa !29
  %t105 = load ptr, ptr %l60, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t105, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t106, i32 0, i32 2
  %t108 = load %"compiler/source:Span", ptr %t107
  store %"compiler/source:Span" %t108, ptr %l61
  %t109 = load %"compiler/source:Span", ptr %l61
  store %"compiler/source:Span" %t109, ptr %l7
  br label %bb35
bb34:
  br label %bb43
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l62, !tbaa !29
  %t111 = load ptr, ptr %l62, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t111, { i64, ptr } { i64 7, ptr @.d11 })
  br label %bb36
bb36:
  %t112 = load i32, ptr %l6, !tbaa !23
  store i32 %t112, ptr %l63, !tbaa !23
  %t113 = load i32, ptr %l63, !tbaa !23
  %t114 = icmp ne i32 %t113, 0
  store i1 %t114, ptr %l64, !tbaa !21
  %t115 = load i1, ptr %l64, !tbaa !21
  br i1 %t115, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l65, !tbaa !29
  %t117 = load i32, ptr %l6, !tbaa !23
  store i32 %t117, ptr %l66, !tbaa !23
  %t118 = load ptr, ptr %l65, !tbaa !29
  %t119 = load i32, ptr %l66, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t118, i32 %t119)
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l67, !tbaa !29
  %t121 = load ptr, ptr %l67, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t121, { i64, ptr } { i64 1, ptr @.d12 })
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l68, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t123, ptr %l69
  %t124 = load ptr, ptr %l68, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l69
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t124, %"compiler/source:Span" %t125)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb80
bb43:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  store i1 %t128, ptr %l72, !tbaa !21
  %t129 = load i1, ptr %l72, !tbaa !21
  br i1 %t129, label %bb44, label %bb45
bb44:
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = load i64, ptr %t130
  store i64 %t131, ptr %l73, !tbaa !24
  %t132 = load i64, ptr %l73, !tbaa !24
  %t133 = icmp eq i64 %t132, 5
  store i1 %t133, ptr %l71, !tbaa !21
  br label %bb45
bb45:
  %t134 = load i1, ptr %l71, !tbaa !21
  br i1 %t134, label %bb46, label %bb47
bb46:
  %t135 = load ptr, ptr %l1, !tbaa !29
  store ptr %t135, ptr %l74, !tbaa !29
  %t136 = load ptr, ptr %l74, !tbaa !29
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, { i64, ptr } }, ptr %t137, i32 0, i32 1
  %t139 = load i32, ptr %t138
  store i32 %t139, ptr %l75, !tbaa !23
  %t140 = load i32, ptr %l75, !tbaa !23
  store i32 %t140, ptr %l8, !tbaa !23
  %t141 = load ptr, ptr %l1, !tbaa !29
  store ptr %t141, ptr %l76, !tbaa !29
  %t142 = load ptr, ptr %l76, !tbaa !29
  %t143 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, { i64, ptr } }, ptr %t143, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %t144
  store { i64, ptr } %t145, ptr %l77, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t146, ptr %l9, !tbaa !27
  br label %bb48
bb47:
  br label %bb62
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l78, !tbaa !29
  %t148 = load ptr, ptr %l78, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t148, { i64, ptr } { i64 6, ptr @.d13 })
  br label %bb49
bb49:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l79, !tbaa !29
  %t150 = load i32, ptr %l8, !tbaa !23
  store i32 %t150, ptr %l80, !tbaa !23
  %t151 = load ptr, ptr %l79, !tbaa !29
  %t152 = load i32, ptr %l80, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t151, i32 %t152)
  br label %bb50
bb50:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l81, !tbaa !29
  %t154 = load ptr, ptr %l81, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t154, { i64, ptr } { i64 2, ptr @.d14 })
  br label %bb51
bb51:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l82, !tbaa !29
  %t156 = load ptr, ptr %l82, !tbaa !29
  %t157 = getelementptr %"compiler/unparse:writer", ptr %t156, i32 0, i32 4
  %t158 = load i64, ptr %t157, !tbaa !24
  store i64 %t158, ptr %l83, !tbaa !24
  %t159 = load i64, ptr %l83, !tbaa !24
  %t160 = add i64 %t159, 1
  store i64 %t160, ptr %l84, !tbaa !24
  %t161 = load i64, ptr %l84, !tbaa !24
  %t162 = load ptr, ptr %l82, !tbaa !29
  %t163 = getelementptr %"compiler/unparse:writer", ptr %t162, i32 0, i32 4
  store i64 %t161, ptr %t163, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s8
  %t164 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t164, ptr %l85, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t165, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t166, ptr %l86, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  store i64 %t168, ptr %l87, !tbaa !24
  %t169 = load i64, ptr %l87, !tbaa !24
  store i64 %t169, ptr %l12, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t170 = load i64, ptr %l11, !tbaa !24
  store i64 %t170, ptr %l88, !tbaa !24
  %t171 = load i64, ptr %l12, !tbaa !24
  store i64 %t171, ptr %l89, !tbaa !24
  %t172 = load i64, ptr %l88, !tbaa !24
  %t173 = load i64, ptr %l89, !tbaa !24
  %t174 = icmp slt i64 %t172, %t173
  store i1 %t174, ptr %l90, !tbaa !21
  %t175 = load i1, ptr %l90, !tbaa !21
  %t176 = xor i1 %t175, true
  store i1 %t176, ptr %l91, !tbaa !21
  %t177 = load i1, ptr %l91, !tbaa !21
  br i1 %t177, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb54:
  br label %bb55
bb55:
  %t178 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t178, ptr %l92, !tbaa !27
  %t179 = load i64, ptr %l11, !tbaa !24
  store i64 %t179, ptr %l93, !tbaa !24
  %t180 = load i64, ptr %l93, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr i32, ptr %t182, i64 %t180
  %t184 = load i32, ptr %t183, !tbaa !33
  store i32 %t184, ptr %l94, !tbaa !23
  %t185 = load i32, ptr %l94, !tbaa !23
  store i32 %t185, ptr %l13, !tbaa !23
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l95, !tbaa !29
  %t187 = load ptr, ptr %l95, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t187)
  br label %bb56
bb56:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l96, !tbaa !29
  %t189 = load i32, ptr %l13, !tbaa !23
  store i32 %t189, ptr %l97, !tbaa !23
  %t190 = load ptr, ptr %l96, !tbaa !29
  %t191 = load i32, ptr %l97, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t190, i32 %t191)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s10
  %t192 = load i64, ptr %l11, !tbaa !24
  store i64 %t192, ptr %l98, !tbaa !24
  %t193 = load i64, ptr %l98, !tbaa !24
  %t194 = add i64 %t193, 1
  store i64 %t194, ptr %l99, !tbaa !24
  %t195 = load i64, ptr %l99, !tbaa !24
  store i64 %t195, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb52
bb59:
  call void @__olang_scope_close(ptr %s8)
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l100, !tbaa !29
  %t197 = load ptr, ptr %l100, !tbaa !29
  %t198 = getelementptr %"compiler/unparse:writer", ptr %t197, i32 0, i32 4
  %t199 = load i64, ptr %t198, !tbaa !24
  store i64 %t199, ptr %l101, !tbaa !24
  %t200 = load i64, ptr %l101, !tbaa !24
  %t201 = sub i64 %t200, 1
  store i64 %t201, ptr %l102, !tbaa !24
  %t202 = load i64, ptr %l102, !tbaa !24
  %t203 = load ptr, ptr %l100, !tbaa !29
  %t204 = getelementptr %"compiler/unparse:writer", ptr %t203, i32 0, i32 4
  store i64 %t202, ptr %t204, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l103, !tbaa !29
  %t206 = load ptr, ptr %l103, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t206)
  br label %bb60
bb60:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l104, !tbaa !29
  %t208 = load ptr, ptr %l104, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t208, { i64, ptr } { i64 1, ptr @.d15 })
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  br label %bb80
bb62:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t210 = load ptr, ptr %l105, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  store i1 %t211, ptr %l107, !tbaa !21
  %t212 = load i1, ptr %l107, !tbaa !21
  br i1 %t212, label %bb63, label %bb64
bb63:
  %t213 = load ptr, ptr %l105, !tbaa !29
  %t214 = load i64, ptr %t213
  store i64 %t214, ptr %l108, !tbaa !24
  %t215 = load i64, ptr %l108, !tbaa !24
  %t216 = icmp eq i64 %t215, 6
  store i1 %t216, ptr %l106, !tbaa !21
  br label %bb64
bb64:
  %t217 = load i1, ptr %l106, !tbaa !21
  br i1 %t217, label %bb65, label %bb66
bb65:
  %t218 = load ptr, ptr %l1, !tbaa !29
  store ptr %t218, ptr %l109, !tbaa !29
  %t219 = load ptr, ptr %l109, !tbaa !29
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t220, i32 0, i32 1
  %t222 = load %"compiler/source:Span", ptr %t221
  store %"compiler/source:Span" %t222, ptr %l110
  %t223 = load %"compiler/source:Span", ptr %l110
  store %"compiler/source:Span" %t223, ptr %l14
  %t224 = load ptr, ptr %l1, !tbaa !29
  store ptr %t224, ptr %l111, !tbaa !29
  %t225 = load ptr, ptr %l111, !tbaa !29
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t225, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t226, i32 0, i32 2
  %t228 = load { i64, ptr }, ptr %t227
  store { i64, ptr } %t228, ptr %l112, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t229, ptr %l15, !tbaa !27
  br label %bb67
bb66:
  br label %bb72
bb67:
  store %olang.scope zeroinitializer, ptr %s11
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l113, !tbaa !29
  %t231 = load ptr, ptr %l113, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t231, { i64, ptr } { i64 5, ptr @.d16 })
  br label %bb68
bb68:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l114, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t233, ptr %l115
  %t234 = load ptr, ptr %l114, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l115
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t234, %"compiler/source:Span" %t235)
  br label %bb69
bb69:
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l116, !tbaa !29
  %t237 = load ptr, ptr %l116, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t237, { i64, ptr } { i64 1, ptr @.d17 })
  br label %bb70
bb70:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l117, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t239, ptr %l118, !tbaa !27
  %t240 = load ptr, ptr %l117, !tbaa !29
  %t241 = load { i64, ptr }, ptr %l118, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t240, { i64, ptr } %t241)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb72:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t243 = load ptr, ptr %l119, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  store i1 %t244, ptr %l121, !tbaa !21
  %t245 = load i1, ptr %l121, !tbaa !21
  br i1 %t245, label %bb73, label %bb74
bb73:
  %t246 = load ptr, ptr %l119, !tbaa !29
  %t247 = load i64, ptr %t246
  store i64 %t247, ptr %l122, !tbaa !24
  %t248 = load i64, ptr %l122, !tbaa !24
  %t249 = icmp eq i64 %t248, 7
  store i1 %t249, ptr %l120, !tbaa !21
  br label %bb74
bb74:
  %t250 = load i1, ptr %l120, !tbaa !21
  br i1 %t250, label %bb75, label %bb76
bb75:
  %t251 = load ptr, ptr %l1, !tbaa !29
  store ptr %t251, ptr %l123, !tbaa !29
  %t252 = load ptr, ptr %l123, !tbaa !29
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l124, !tbaa !29
  %t256 = load ptr, ptr %l124, !tbaa !29
  store ptr %t256, ptr %l16, !tbaa !29
  br label %bb77
bb76:
  br label %bb79
bb77:
  store %olang.scope zeroinitializer, ptr %s12
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l125, !tbaa !29
  %t258 = load ptr, ptr %l16, !tbaa !29
  store ptr %t258, ptr %l126, !tbaa !29
  %t259 = load ptr, ptr %l125, !tbaa !29
  %t260 = load ptr, ptr %l126, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t259, ptr %t260)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s12)
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb80:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t2, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l10, !tbaa !21
  %t5 = load i1, ptr %l10, !tbaa !21
  %t6 = xor i1 %t5, true
  store i1 %t6, ptr %l11, !tbaa !21
  %t7 = load i1, ptr %l11, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 2, ptr @.d19 })
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l13, !tbaa !29
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Sig", ptr %t11, i32 0, i32 3
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l14, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l15, !tbaa !24
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = icmp eq i64 %t16, 0
  store i1 %t17, ptr %l16, !tbaa !21
  %t18 = load i1, ptr %l16, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load i1, ptr %l2, !tbaa !21
  store i1 %t19, ptr %l17, !tbaa !21
  %t20 = load i1, ptr %l17, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l19, !tbaa !29
  %t22 = load ptr, ptr %l19, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Sig", ptr %t22, i32 0, i32 3
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l20, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l21, !tbaa !24
  %t27 = load i64, ptr %l21, !tbaa !24
  %t28 = icmp sgt i64 %t27, 1
  store i1 %t28, ptr %l22, !tbaa !21
  %t29 = load i1, ptr %l22, !tbaa !21
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t30 = load i1, ptr %l18, !tbaa !21
  store i1 %t30, ptr %l3, !tbaa !21
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l23, !tbaa !29
  %t32 = load i1, ptr %l3, !tbaa !21
  store i1 %t32, ptr %l24, !tbaa !21
  %t33 = load i1, ptr %l24, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 2, ptr @.d20 }, ptr %l25, !tbaa !27
  br label %bb13
bb12:
  store { i64, ptr } { i64 1, ptr @.d21 }, ptr %l25, !tbaa !27
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t34, { i64, ptr } %t35)
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l26, !tbaa !29
  %t37 = load ptr, ptr %l26, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Sig", ptr %t37, i32 0, i32 3
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l27, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t40, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t41, ptr %l28, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l29, !tbaa !24
  %t44 = load i64, ptr %l29, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load i64, ptr %l5, !tbaa !24
  store i64 %t45, ptr %l30, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  store i64 %t46, ptr %l31, !tbaa !24
  %t47 = load i64, ptr %l30, !tbaa !24
  %t48 = load i64, ptr %l31, !tbaa !24
  %t49 = icmp slt i64 %t47, %t48
  store i1 %t49, ptr %l32, !tbaa !21
  %t50 = load i1, ptr %l32, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l33, !tbaa !21
  %t52 = load i1, ptr %l33, !tbaa !21
  br i1 %t52, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb17:
  br label %bb18
bb18:
  %t53 = load i64, ptr %l5, !tbaa !24
  store i64 %t53, ptr %l34, !tbaa !24
  %t54 = load i64, ptr %l34, !tbaa !24
  store i64 %t54, ptr %l7, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t57
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l37, !tbaa !29
  %t62 = load ptr, ptr %l37, !tbaa !29
  store ptr %t62, ptr %l8, !tbaa !29
  %t63 = load i64, ptr %l7, !tbaa !24
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = load i64, ptr %l38, !tbaa !24
  %t65 = icmp sgt i64 %t64, 0
  store i1 %t65, ptr %l39, !tbaa !21
  %t66 = load i1, ptr %l39, !tbaa !21
  br i1 %t66, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l40, !tbaa !29
  %t68 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t68, { i64, ptr } { i64 2, ptr @.d22 })
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l41, !tbaa !29
  %t70 = load ptr, ptr %l8, !tbaa !29
  store ptr %t70, ptr %l42, !tbaa !29
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t72 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t71, ptr %t72)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t73 = load i64, ptr %l5, !tbaa !24
  store i64 %t73, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l43, !tbaa !24
  %t75 = add i64 %t74, 1
  store i64 %t75, ptr %l44, !tbaa !24
  %t76 = load i64, ptr %l44, !tbaa !24
  store i64 %t76, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb15
bb25:
  call void @__olang_scope_close(ptr %s3)
  %t77 = load i1, ptr %l3, !tbaa !21
  store i1 %t77, ptr %l45, !tbaa !21
  %t78 = load i1, ptr %l45, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s7
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l46, !tbaa !29
  %t80 = load ptr, ptr %l46, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t80, { i64, ptr } { i64 1, ptr @.d23 })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l98 = alloca i32
  %l99 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca ptr
  %l102 = alloca i1
  %l103 = alloca i1
  %l104 = alloca i32
  %l105 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca ptr
  %l108 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca ptr
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca i32
  %l117 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca ptr
  %l120 = alloca i1
  %l121 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i1
  %l129 = alloca i1
  %l130 = alloca i64
  %l131 = alloca ptr
  %l132 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l141 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca i32
  %l146 = alloca ptr
  %l147 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l150 = alloca ptr
  %l151 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca ptr
  %l154 = alloca i32
  %l155 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l157 = alloca ptr
  %l158 = alloca ptr
  %l159 = alloca ptr
  %l160 = alloca i1
  %l161 = alloca i1
  %l162 = alloca i64
  %l163 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca ptr
  %l168 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca ptr
  %l171 = alloca ptr
  %l172 = alloca ptr
  %l173 = alloca i1
  %l174 = alloca i1
  %l175 = alloca i64
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca ptr
  %l179 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l181 = alloca i64
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i1
  %l185 = alloca i1
  %l186 = alloca i64
  %l187 = alloca { i64, ptr }
  %l188 = alloca i64
  %l189 = alloca ptr
  %l190 = alloca i64
  %l191 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca ptr
  %l194 = alloca ptr
  %l195 = alloca { i64, ptr }
  %l196 = alloca i64
  %l197 = alloca i64
  %l198 = alloca i32
  %l199 = alloca { i64, ptr }
  %l200 = alloca ptr
  %l201 = alloca ptr
  %l202 = alloca ptr
  %l203 = alloca i64
  %l204 = alloca i64
  %l205 = alloca ptr
  %l206 = alloca i1
  %l207 = alloca i1
  %l208 = alloca i64
  %l209 = alloca ptr
  %l210 = alloca ptr
  %l211 = alloca ptr
  %l212 = alloca ptr
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l216 = alloca ptr
  %l217 = alloca ptr
  %l218 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca ptr
  %l221 = alloca ptr
  %l222 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca i1
  %l225 = alloca i1
  %l226 = alloca i64
  %l227 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca ptr
  %l230 = alloca ptr
  %l231 = alloca ptr
  %l232 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca ptr
  %l235 = alloca ptr
  %l236 = alloca i1
  %l237 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l241 = alloca i1
  %l242 = alloca i1
  %l243 = alloca i64
  %l244 = alloca ptr
  %l245 = alloca ptr
  %l246 = alloca ptr
  %l247 = alloca ptr
  %l248 = alloca ptr
  %l249 = alloca i1
  %l250 = alloca ptr
  %l251 = alloca ptr
  %l252 = alloca ptr
  %l253 = alloca i1
  %l254 = alloca { i64, ptr }
  %l255 = alloca ptr
  %l256 = alloca ptr
  %l257 = alloca ptr
  %l258 = alloca i1
  %l259 = alloca i1
  %l260 = alloca i64
  %l261 = alloca ptr
  %l262 = alloca ptr
  %l263 = alloca ptr
  %l264 = alloca ptr
  %l265 = alloca ptr
  %l266 = alloca ptr
  %l267 = alloca ptr
  %l268 = alloca ptr
  %l269 = alloca ptr
  %l270 = alloca ptr
  %l271 = alloca i1
  %l272 = alloca i1
  %l273 = alloca i64
  %l274 = alloca ptr
  %l275 = alloca ptr
  %l276 = alloca ptr
  %l277 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l279 = alloca ptr
  %l280 = alloca ptr
  %l281 = alloca ptr
  %l282 = alloca { i64, ptr }
  %l283 = alloca ptr
  %l284 = alloca ptr
  %l285 = alloca i1
  %l286 = alloca i1
  %l287 = alloca i64
  %l288 = alloca ptr
  %l289 = alloca ptr
  %l290 = alloca ptr
  %l291 = alloca i32
  %l292 = alloca ptr
  %l293 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l295 = alloca ptr
  %l296 = alloca ptr
  %l297 = alloca ptr
  %l298 = alloca i32
  %l299 = alloca ptr
  %l300 = alloca ptr
  %l301 = alloca { i64, ptr }
  %l302 = alloca ptr
  %l303 = alloca ptr
  %l304 = alloca i1
  %l305 = alloca i1
  %l306 = alloca i64
  %l307 = alloca ptr
  %l308 = alloca ptr
  %l309 = alloca ptr
  %l310 = alloca { i64, ptr }
  %l311 = alloca ptr
  %l312 = alloca ptr
  %l313 = alloca ptr
  %l314 = alloca ptr
  %l315 = alloca { i64, ptr }
  %l316 = alloca ptr
  %l317 = alloca ptr
  %l318 = alloca i1
  %l319 = alloca i1
  %l320 = alloca i64
  %l321 = alloca ptr
  %l322 = alloca ptr
  %l323 = alloca ptr
  %l324 = alloca i32
  %l325 = alloca ptr
  %l326 = alloca ptr
  %l327 = alloca ptr
  %l328 = alloca ptr
  %l329 = alloca i32
  %l330 = alloca ptr
  %l331 = alloca i1
  %l332 = alloca i1
  %l333 = alloca i64
  %l334 = alloca ptr
  %l335 = alloca ptr
  %l336 = alloca ptr
  %l337 = alloca { i64, ptr }
  %l338 = alloca ptr
  %l339 = alloca ptr
  %l340 = alloca ptr
  %l341 = alloca ptr
  %l342 = alloca { i64, ptr }
  %l343 = alloca ptr
  %l344 = alloca ptr
  %l345 = alloca i1
  %l346 = alloca i1
  %l347 = alloca i64
  %l348 = alloca ptr
  %l349 = alloca ptr
  %l350 = alloca ptr
  %l351 = alloca ptr
  %l352 = alloca ptr
  %l353 = alloca ptr
  %l354 = alloca ptr
  %l355 = alloca ptr
  %l356 = alloca ptr
  %l357 = alloca ptr
  %l358 = alloca i1
  %l359 = alloca ptr
  %l360 = alloca ptr
  %l361 = alloca ptr
  %l362 = alloca ptr
  %l363 = alloca i1
  %l364 = alloca ptr
  %l365 = alloca ptr
  %l366 = alloca ptr
  %l367 = alloca ptr
  %l368 = alloca i1
  %l369 = alloca i1
  %l370 = alloca i64
  %l371 = alloca ptr
  %l372 = alloca ptr
  %l373 = alloca ptr
  %l374 = alloca { i64, ptr }
  %l375 = alloca ptr
  %l376 = alloca ptr
  %l377 = alloca ptr
  %l378 = alloca ptr
  %l379 = alloca { i64, ptr }
  %l380 = alloca ptr
  %l381 = alloca ptr
  %l382 = alloca i1
  %l383 = alloca i1
  %l384 = alloca i64
  %l385 = alloca ptr
  %l386 = alloca { i64, ptr }
  %l387 = alloca ptr
  %l388 = alloca ptr
  %l389 = alloca { i64, ptr }
  %l390 = alloca ptr
  %l391 = alloca ptr
  %l392 = alloca i1
  %l393 = alloca i1
  %l394 = alloca i64
  %l395 = alloca ptr
  %l396 = alloca ptr
  %l397 = alloca ptr
  %l398 = alloca ptr
  %l399 = alloca ptr
  %l400 = alloca ptr
  %l401 = alloca ptr
  %l402 = alloca ptr
  %l403 = alloca ptr
  %l404 = alloca ptr
  %l405 = alloca ptr
  %l406 = alloca i32
  %l407 = alloca i1
  %l408 = alloca ptr
  %l409 = alloca ptr
  %l410 = alloca i32
  %l411 = alloca ptr
  %l412 = alloca ptr
  %l413 = alloca ptr
  %l414 = alloca i32
  %l415 = alloca ptr
  %l416 = alloca ptr
  %l417 = alloca ptr
  %l418 = alloca ptr
  %l419 = alloca ptr
  %l420 = alloca ptr
  %l421 = alloca i1
  %l422 = alloca ptr
  %l423 = alloca ptr
  %l424 = alloca ptr
  %l425 = alloca ptr
  %l426 = alloca ptr
  %l427 = alloca ptr
  %l428 = alloca i1
  %l429 = alloca i1
  %l430 = alloca i64
  %l431 = alloca ptr
  %l432 = alloca { i64, ptr }
  %l433 = alloca { i64, ptr }
  %l434 = alloca { i64, ptr }
  %l435 = alloca i64
  %l436 = alloca i64
  %l437 = alloca i64
  %l438 = alloca i1
  %l439 = alloca i1
  %l440 = alloca i64
  %l441 = alloca { i64, ptr }
  %l442 = alloca i64
  %l443 = alloca ptr
  %l444 = alloca i64
  %l445 = alloca i1
  %l446 = alloca ptr
  %l447 = alloca ptr
  %l448 = alloca ptr
  %l449 = alloca i64
  %l450 = alloca i64
  %l451 = alloca ptr
  %l452 = alloca i1
  %l453 = alloca i1
  %l454 = alloca i64
  %l455 = alloca ptr
  %l456 = alloca ptr
  %l457 = alloca ptr
  %l458 = alloca { i64, ptr }
  %l459 = alloca ptr
  %l460 = alloca i1
  %l461 = alloca ptr
  %l462 = alloca i1
  %l463 = alloca { i64, ptr }
  %l464 = alloca ptr
  %l465 = alloca ptr
  %l466 = alloca ptr
  %l467 = alloca { i64, ptr }
  %l468 = alloca ptr
  %l469 = alloca i1
  %l470 = alloca i1
  %l471 = alloca i64
  %l472 = alloca ptr
  %l473 = alloca ptr
  %l474 = alloca ptr
  %l475 = alloca ptr
  %l476 = alloca ptr
  %l477 = alloca ptr
  %l478 = alloca ptr
  %l479 = alloca ptr
  %l480 = alloca ptr
  %l481 = alloca { i64, ptr }
  %l482 = alloca ptr
  %l483 = alloca i1
  %l484 = alloca i1
  %l485 = alloca i64
  %l486 = alloca ptr
  %l487 = alloca ptr
  %l488 = alloca ptr
  %l489 = alloca ptr
  %l490 = alloca ptr
  %l491 = alloca i1
  %l492 = alloca i1
  %l493 = alloca i64
  %l494 = alloca ptr
  %l495 = alloca { i64, ptr }
  %l496 = alloca ptr
  %l497 = alloca ptr
  %l498 = alloca { i64, ptr }
  %l499 = alloca ptr
  %l500 = alloca i1
  %l501 = alloca i1
  %l502 = alloca i64
  %l503 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t2 = load ptr, ptr %l61, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l63, !tbaa !21
  %t4 = load i1, ptr %l63, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l61, !tbaa !29
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l64, !tbaa !24
  %t7 = load i64, ptr %l64, !tbaa !24
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l62, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l62, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l65, !tbaa !29
  %t11 = load ptr, ptr %l65, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l66, !tbaa !23
  %t15 = load i32, ptr %l66, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l67, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  store i32 %t17, ptr %l68, !tbaa !23
  %t18 = load ptr, ptr %l67, !tbaa !29
  %t19 = load i32, ptr %l68, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t18, i32 %t19)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb322
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t21 = load ptr, ptr %l69, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  store i1 %t22, ptr %l71, !tbaa !21
  %t23 = load i1, ptr %l71, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l69, !tbaa !29
  %t25 = load i64, ptr %t24
  store i64 %t25, ptr %l72, !tbaa !24
  %t26 = load i64, ptr %l72, !tbaa !24
  %t27 = icmp eq i64 %t26, 1
  store i1 %t27, ptr %l70, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l70, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l73, !tbaa !29
  %t30 = load ptr, ptr %l73, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32 }, ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/source:Span", ptr %t32
  store %"compiler/source:Span" %t33, ptr %l74
  %t34 = load %"compiler/source:Span", ptr %l74
  store %"compiler/source:Span" %t34, ptr %l3
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l75, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t36, ptr %l76
  %t37 = load ptr, ptr %l75, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l76
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t37, %"compiler/source:Span" %t38)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb322
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t40 = load ptr, ptr %l77, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  store i1 %t41, ptr %l79, !tbaa !21
  %t42 = load i1, ptr %l79, !tbaa !21
  br i1 %t42, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l77, !tbaa !29
  %t44 = load i64, ptr %t43
  store i64 %t44, ptr %l80, !tbaa !24
  %t45 = load i64, ptr %l80, !tbaa !24
  %t46 = icmp eq i64 %t45, 2
  store i1 %t46, ptr %l78, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l78, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l81, !tbaa !29
  %t49 = load ptr, ptr %l81, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l82, !tbaa !29
  %t53 = load ptr, ptr %l82, !tbaa !29
  store ptr %t53, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb23
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l83, !tbaa !29
  %t55 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t55, { i64, ptr } { i64 1, ptr @.d24 })
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l84, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  store ptr %t57, ptr %l85, !tbaa !29
  %t58 = load ptr, ptr %l84, !tbaa !29
  %t59 = load ptr, ptr %l85, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  br label %bb21
bb21:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l86, !tbaa !29
  %t61 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t61, { i64, ptr } { i64 1, ptr @.d25 })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb322
bb23:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t63 = load ptr, ptr %l87, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  store i1 %t64, ptr %l89, !tbaa !21
  %t65 = load i1, ptr %l89, !tbaa !21
  br i1 %t65, label %bb24, label %bb25
bb24:
  %t66 = load ptr, ptr %l87, !tbaa !29
  %t67 = load i64, ptr %t66
  store i64 %t67, ptr %l90, !tbaa !24
  %t68 = load i64, ptr %l90, !tbaa !24
  %t69 = icmp eq i64 %t68, 3
  store i1 %t69, ptr %l88, !tbaa !21
  br label %bb25
bb25:
  %t70 = load i1, ptr %l88, !tbaa !21
  br i1 %t70, label %bb26, label %bb27
bb26:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l91, !tbaa !29
  %t72 = load ptr, ptr %l91, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 1
  %t75 = load i32, ptr %t74
  store i32 %t75, ptr %l92
  %t76 = load i32, ptr %l92
  store i32 %t76, ptr %l5
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l93, !tbaa !29
  %t78 = load ptr, ptr %l93, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t78, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 2
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l94, !tbaa !29
  %t82 = load ptr, ptr %l94, !tbaa !29
  store ptr %t82, ptr %l6, !tbaa !29
  br label %bb28
bb27:
  br label %bb54
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l95, !tbaa !29
  %t84 = load i32, ptr %l5
  store i32 %t84, ptr %l96
  %t85 = load i32, ptr %l96
  %t86 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t85)
  store { i64, ptr } %t86, ptr %l97
  br label %bb29
bb29:
  %t87 = load ptr, ptr %l95, !tbaa !29
  %t88 = load { i64, ptr }, ptr %l97, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t87, { i64, ptr } %t88)
  br label %bb30
bb30:
  %t89 = load i32, ptr %l5
  store i32 %t89, ptr %l98
  store ptr %l98, ptr %l99, !tbaa !29
  store i32 50, ptr %l100
  store ptr %l100, ptr %l101, !tbaa !29
  %t90 = load ptr, ptr %l99, !tbaa !29
  %t91 = load ptr, ptr %l101, !tbaa !29
  %t92 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t90, ptr %t91)
  store i1 %t92, ptr %l102
  br label %bb31
bb31:
  %t93 = load i1, ptr %l102, !tbaa !21
  br i1 %t93, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb35
bb33:
  %t94 = load i32, ptr %l5
  store i32 %t94, ptr %l104
  store ptr %l104, ptr %l105, !tbaa !29
  store i32 41, ptr %l106
  store ptr %l106, ptr %l107, !tbaa !29
  %t95 = load ptr, ptr %l105, !tbaa !29
  %t96 = load ptr, ptr %l107, !tbaa !29
  %t97 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t95, ptr %t96)
  store i1 %t97, ptr %l108
  br label %bb34
bb34:
  %t98 = load i1, ptr %l108, !tbaa !21
  store i1 %t98, ptr %l103, !tbaa !21
  br label %bb35
bb35:
  %t99 = load i1, ptr %l103, !tbaa !21
  br i1 %t99, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s5
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l109, !tbaa !29
  %t101 = load ptr, ptr %l109, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t101, { i64, ptr } { i64 1, ptr @.d26 })
  br label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t102 = load i32, ptr %l5
  store i32 %t102, ptr %l110
  store ptr %l110, ptr %l111, !tbaa !29
  store i32 52, ptr %l112
  store ptr %l112, ptr %l113, !tbaa !29
  %t103 = load ptr, ptr %l111, !tbaa !29
  %t104 = load ptr, ptr %l113, !tbaa !29
  %t105 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t103, ptr %t104)
  store i1 %t105, ptr %l114
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb39:
  %t106 = load i1, ptr %l114, !tbaa !21
  br i1 %t106, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb43
bb41:
  %t107 = load i32, ptr %l5
  store i32 %t107, ptr %l116
  store ptr %l116, ptr %l117, !tbaa !29
  store i32 74, ptr %l118
  store ptr %l118, ptr %l119, !tbaa !29
  %t108 = load ptr, ptr %l117, !tbaa !29
  %t109 = load ptr, ptr %l119, !tbaa !29
  %t110 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t108, ptr %t109)
  store i1 %t110, ptr %l120
  br label %bb42
bb42:
  %t111 = load i1, ptr %l120, !tbaa !21
  store i1 %t111, ptr %l115, !tbaa !21
  br label %bb43
bb43:
  %t112 = load i1, ptr %l115, !tbaa !21
  br i1 %t112, label %bb44, label %bb45
bb44:
  %t113 = load ptr, ptr %l6, !tbaa !29
  store ptr %t113, ptr %l122, !tbaa !29
  %t114 = load ptr, ptr %l122, !tbaa !29
  %t115 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v1, ptr %t114)
  store i1 %t115, ptr %l123
  br label %bb46
bb45:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb47
bb46:
  %t116 = load i1, ptr %l123, !tbaa !21
  store i1 %t116, ptr %l121, !tbaa !21
  br label %bb47
bb47:
  %t117 = load i1, ptr %l121, !tbaa !21
  br i1 %t117, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l124, !tbaa !29
  %t119 = load ptr, ptr %l124, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t119, { i64, ptr } { i64 1, ptr @.d27 })
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s6)
  br label %bb52
bb52:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l125, !tbaa !29
  %t121 = load ptr, ptr %l6, !tbaa !29
  store ptr %t121, ptr %l126, !tbaa !29
  %t122 = load ptr, ptr %l125, !tbaa !29
  %t123 = load ptr, ptr %l126, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t122, ptr %t123)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb322
bb54:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t125 = load ptr, ptr %l127, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  store i1 %t126, ptr %l129, !tbaa !21
  %t127 = load i1, ptr %l129, !tbaa !21
  br i1 %t127, label %bb55, label %bb56
bb55:
  %t128 = load ptr, ptr %l127, !tbaa !29
  %t129 = load i64, ptr %t128
  store i64 %t129, ptr %l130, !tbaa !24
  %t130 = load i64, ptr %l130, !tbaa !24
  %t131 = icmp eq i64 %t130, 4
  store i1 %t131, ptr %l128, !tbaa !21
  br label %bb56
bb56:
  %t132 = load i1, ptr %l128, !tbaa !21
  br i1 %t132, label %bb57, label %bb58
bb57:
  %t133 = load ptr, ptr %l1, !tbaa !29
  store ptr %t133, ptr %l131, !tbaa !29
  %t134 = load ptr, ptr %l131, !tbaa !29
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t135, i32 0, i32 1
  %t137 = load i32, ptr %t136
  store i32 %t137, ptr %l132
  %t138 = load i32, ptr %l132
  store i32 %t138, ptr %l7
  %t139 = load ptr, ptr %l1, !tbaa !29
  store ptr %t139, ptr %l133, !tbaa !29
  %t140 = load ptr, ptr %l133, !tbaa !29
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l134, !tbaa !29
  %t144 = load ptr, ptr %l134, !tbaa !29
  store ptr %t144, ptr %l8, !tbaa !29
  br label %bb59
bb58:
  br label %bb63
bb59:
  store %olang.scope zeroinitializer, ptr %s8
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l135, !tbaa !29
  %t146 = load ptr, ptr %l8, !tbaa !29
  store ptr %t146, ptr %l136, !tbaa !29
  %t147 = load ptr, ptr %l135, !tbaa !29
  %t148 = load ptr, ptr %l136, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t147, ptr %t148)
  br label %bb60
bb60:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l137, !tbaa !29
  %t150 = load i32, ptr %l7
  store i32 %t150, ptr %l138
  %t151 = load i32, ptr %l138
  %t152 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t151)
  store { i64, ptr } %t152, ptr %l139
  br label %bb61
bb61:
  %t153 = load ptr, ptr %l137, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l139, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t153, { i64, ptr } %t154)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s8)
  br label %bb322
bb63:
  %t155 = load ptr, ptr %l1, !tbaa !29
  store ptr %t155, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t156 = load ptr, ptr %l140, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  store i1 %t157, ptr %l142, !tbaa !21
  %t158 = load i1, ptr %l142, !tbaa !21
  br i1 %t158, label %bb64, label %bb65
bb64:
  %t159 = load ptr, ptr %l140, !tbaa !29
  %t160 = load i64, ptr %t159
  store i64 %t160, ptr %l143, !tbaa !24
  %t161 = load i64, ptr %l143, !tbaa !24
  %t162 = icmp eq i64 %t161, 5
  store i1 %t162, ptr %l141, !tbaa !21
  br label %bb65
bb65:
  %t163 = load i1, ptr %l141, !tbaa !21
  br i1 %t163, label %bb66, label %bb67
bb66:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l144, !tbaa !29
  %t165 = load ptr, ptr %l144, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t166, i32 0, i32 1
  %t168 = load i32, ptr %t167
  store i32 %t168, ptr %l145
  %t169 = load i32, ptr %l145
  store i32 %t169, ptr %l9
  %t170 = load ptr, ptr %l1, !tbaa !29
  store ptr %t170, ptr %l146, !tbaa !29
  %t171 = load ptr, ptr %l146, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t172, i32 0, i32 2
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l147, !tbaa !29
  %t175 = load ptr, ptr %l147, !tbaa !29
  store ptr %t175, ptr %l10, !tbaa !29
  %t176 = load ptr, ptr %l1, !tbaa !29
  store ptr %t176, ptr %l148, !tbaa !29
  %t177 = load ptr, ptr %l148, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t178, i32 0, i32 3
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l149, !tbaa !29
  %t181 = load ptr, ptr %l149, !tbaa !29
  store ptr %t181, ptr %l11, !tbaa !29
  br label %bb68
bb67:
  br label %bb75
bb68:
  store %olang.scope zeroinitializer, ptr %s9
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l150, !tbaa !29
  %t183 = load ptr, ptr %l10, !tbaa !29
  store ptr %t183, ptr %l151, !tbaa !29
  %t184 = load ptr, ptr %l150, !tbaa !29
  %t185 = load ptr, ptr %l151, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t184, ptr %t185)
  br label %bb69
bb69:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l152, !tbaa !29
  %t187 = load ptr, ptr %l152, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t187, { i64, ptr } { i64 1, ptr @.d28 })
  br label %bb70
bb70:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l153, !tbaa !29
  %t189 = load i32, ptr %l9
  store i32 %t189, ptr %l154
  %t190 = load i32, ptr %l154
  %t191 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t190)
  store { i64, ptr } %t191, ptr %l155
  br label %bb71
bb71:
  %t192 = load ptr, ptr %l153, !tbaa !29
  %t193 = load { i64, ptr }, ptr %l155, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t192, { i64, ptr } %t193)
  br label %bb72
bb72:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l156, !tbaa !29
  %t195 = load ptr, ptr %l156, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t195, { i64, ptr } { i64 1, ptr @.d29 })
  br label %bb73
bb73:
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l157, !tbaa !29
  %t197 = load ptr, ptr %l11, !tbaa !29
  store ptr %t197, ptr %l158, !tbaa !29
  %t198 = load ptr, ptr %l157, !tbaa !29
  %t199 = load ptr, ptr %l158, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t198, ptr %t199)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s9)
  br label %bb322
bb75:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l159, !tbaa !29
  store i1 false, ptr %l160, !tbaa !21
  %t201 = load ptr, ptr %l159, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  store i1 %t202, ptr %l161, !tbaa !21
  %t203 = load i1, ptr %l161, !tbaa !21
  br i1 %t203, label %bb76, label %bb77
bb76:
  %t204 = load ptr, ptr %l159, !tbaa !29
  %t205 = load i64, ptr %t204
  store i64 %t205, ptr %l162, !tbaa !24
  %t206 = load i64, ptr %l162, !tbaa !24
  %t207 = icmp eq i64 %t206, 6
  store i1 %t207, ptr %l160, !tbaa !21
  br label %bb77
bb77:
  %t208 = load i1, ptr %l160, !tbaa !21
  br i1 %t208, label %bb78, label %bb79
bb78:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l163, !tbaa !29
  %t210 = load ptr, ptr %l163, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t211, i32 0, i32 1
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l164, !tbaa !29
  %t214 = load ptr, ptr %l164, !tbaa !29
  store ptr %t214, ptr %l12, !tbaa !29
  %t215 = load ptr, ptr %l1, !tbaa !29
  store ptr %t215, ptr %l165, !tbaa !29
  %t216 = load ptr, ptr %l165, !tbaa !29
  %t217 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t217, i32 0, i32 2
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l166, !tbaa !29
  %t220 = load ptr, ptr %l166, !tbaa !29
  store ptr %t220, ptr %l13, !tbaa !29
  br label %bb80
bb79:
  br label %bb84
bb80:
  store %olang.scope zeroinitializer, ptr %s10
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l167, !tbaa !29
  %t222 = load ptr, ptr %l12, !tbaa !29
  store ptr %t222, ptr %l168, !tbaa !29
  %t223 = load ptr, ptr %l167, !tbaa !29
  %t224 = load ptr, ptr %l168, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t223, ptr %t224)
  br label %bb81
bb81:
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l169, !tbaa !29
  %t226 = load ptr, ptr %l169, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t226, { i64, ptr } { i64 8, ptr @.d30 })
  br label %bb82
bb82:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l170, !tbaa !29
  %t228 = load ptr, ptr %l13, !tbaa !29
  store ptr %t228, ptr %l171, !tbaa !29
  %t229 = load ptr, ptr %l170, !tbaa !29
  %t230 = load ptr, ptr %l171, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t229, ptr %t230)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s10)
  br label %bb322
bb84:
  %t231 = load ptr, ptr %l1, !tbaa !29
  store ptr %t231, ptr %l172, !tbaa !29
  store i1 false, ptr %l173, !tbaa !21
  %t232 = load ptr, ptr %l172, !tbaa !29
  %t233 = icmp ne ptr %t232, null
  store i1 %t233, ptr %l174, !tbaa !21
  %t234 = load i1, ptr %l174, !tbaa !21
  br i1 %t234, label %bb85, label %bb86
bb85:
  %t235 = load ptr, ptr %l172, !tbaa !29
  %t236 = load i64, ptr %t235
  store i64 %t236, ptr %l175, !tbaa !24
  %t237 = load i64, ptr %l175, !tbaa !24
  %t238 = icmp eq i64 %t237, 7
  store i1 %t238, ptr %l173, !tbaa !21
  br label %bb86
bb86:
  %t239 = load i1, ptr %l173, !tbaa !21
  br i1 %t239, label %bb87, label %bb88
bb87:
  %t240 = load ptr, ptr %l1, !tbaa !29
  store ptr %t240, ptr %l176, !tbaa !29
  %t241 = load ptr, ptr %l176, !tbaa !29
  %t242 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t243 = getelementptr { %"compiler/source:Span", ptr }, ptr %t242, i32 0, i32 1
  %t244 = load ptr, ptr %t243
  store ptr %t244, ptr %l177, !tbaa !29
  %t245 = load ptr, ptr %l177, !tbaa !29
  store ptr %t245, ptr %l14, !tbaa !29
  br label %bb89
bb88:
  br label %bb104
bb89:
  store %olang.scope zeroinitializer, ptr %s11
  store %olang.scope zeroinitializer, ptr %s12
  %t246 = load ptr, ptr %l14, !tbaa !29
  store ptr %t246, ptr %l178, !tbaa !29
  %t247 = load ptr, ptr %l178, !tbaa !29
  %t248 = getelementptr %"compiler/ast:Chain", ptr %t247, i32 0, i32 1
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  store { i64, ptr } %t249, ptr %l179, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l179, !tbaa !27
  store { i64, ptr } %t250, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t251 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t251, ptr %l180, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 0
  store i64 %t253, ptr %l181, !tbaa !24
  %t254 = load i64, ptr %l181, !tbaa !24
  store i64 %t254, ptr %l17, !tbaa !24
  br label %bb90
bb90:
  store %olang.scope zeroinitializer, ptr %s13
  %t255 = load i64, ptr %l16, !tbaa !24
  store i64 %t255, ptr %l182, !tbaa !24
  %t256 = load i64, ptr %l17, !tbaa !24
  store i64 %t256, ptr %l183, !tbaa !24
  %t257 = load i64, ptr %l182, !tbaa !24
  %t258 = load i64, ptr %l183, !tbaa !24
  %t259 = icmp slt i64 %t257, %t258
  store i1 %t259, ptr %l184, !tbaa !21
  %t260 = load i1, ptr %l184, !tbaa !21
  %t261 = xor i1 %t260, true
  store i1 %t261, ptr %l185, !tbaa !21
  %t262 = load i1, ptr %l185, !tbaa !21
  br i1 %t262, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s13)
  br label %bb103
bb92:
  br label %bb93
bb93:
  %t263 = load i64, ptr %l16, !tbaa !24
  store i64 %t263, ptr %l186, !tbaa !24
  %t264 = load i64, ptr %l186, !tbaa !24
  store i64 %t264, ptr %l18, !tbaa !24
  %t265 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t265, ptr %l187, !tbaa !27
  %t266 = load i64, ptr %l16, !tbaa !24
  store i64 %t266, ptr %l188, !tbaa !24
  %t267 = load i64, ptr %l188, !tbaa !24
  %t268 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr ptr, ptr %t269, i64 %t267
  %t271 = load ptr, ptr %t270, !tbaa !39
  store ptr %t271, ptr %l189, !tbaa !29
  %t272 = load ptr, ptr %l189, !tbaa !29
  store ptr %t272, ptr %l19, !tbaa !29
  %t273 = load i64, ptr %l18, !tbaa !24
  store i64 %t273, ptr %l190, !tbaa !24
  %t274 = load i64, ptr %l190, !tbaa !24
  %t275 = icmp sgt i64 %t274, 0
  store i1 %t275, ptr %l191, !tbaa !21
  %t276 = load i1, ptr %l191, !tbaa !21
  br i1 %t276, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s14
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l192, !tbaa !29
  %t278 = load ptr, ptr %l192, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t278, { i64, ptr } { i64 1, ptr @.d31 })
  br label %bb96
bb95:
  br label %bb100
bb96:
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l193, !tbaa !29
  %t280 = load ptr, ptr %l14, !tbaa !29
  store ptr %t280, ptr %l194, !tbaa !29
  %t281 = load ptr, ptr %l194, !tbaa !29
  %t282 = getelementptr %"compiler/ast:Chain", ptr %t281, i32 0, i32 0
  %t283 = load { i64, ptr }, ptr %t282, !tbaa !27
  store { i64, ptr } %t283, ptr %l195, !tbaa !27
  %t284 = load i64, ptr %l18, !tbaa !24
  store i64 %t284, ptr %l196, !tbaa !24
  %t285 = load i64, ptr %l196, !tbaa !24
  %t286 = sub i64 %t285, 1
  store i64 %t286, ptr %l197, !tbaa !24
  %t287 = load i64, ptr %l197, !tbaa !24
  %t288 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr i32, ptr %t289, i64 %t287
  %t291 = load i32, ptr %t290
  store i32 %t291, ptr %l198
  %t292 = load i32, ptr %l198
  %t293 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s14, i32 %t292)
  store { i64, ptr } %t293, ptr %l199
  br label %bb97
bb97:
  %t294 = load ptr, ptr %l193, !tbaa !29
  %t295 = load { i64, ptr }, ptr %l199, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t294, { i64, ptr } %t295)
  br label %bb98
bb98:
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l200, !tbaa !29
  %t297 = load ptr, ptr %l200, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t297, { i64, ptr } { i64 1, ptr @.d32 })
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s14)
  br label %bb100
bb100:
  %t298 = load ptr, ptr %l0, !tbaa !29
  store ptr %t298, ptr %l201, !tbaa !29
  %t299 = load ptr, ptr %l19, !tbaa !29
  store ptr %t299, ptr %l202, !tbaa !29
  %t300 = load ptr, ptr %l201, !tbaa !29
  %t301 = load ptr, ptr %l202, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t300, ptr %t301)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s13)
  br label %bb102
bb102:
  store %olang.scope zeroinitializer, ptr %s15
  %t302 = load i64, ptr %l16, !tbaa !24
  store i64 %t302, ptr %l203, !tbaa !24
  %t303 = load i64, ptr %l203, !tbaa !24
  %t304 = add i64 %t303, 1
  store i64 %t304, ptr %l204, !tbaa !24
  %t305 = load i64, ptr %l204, !tbaa !24
  store i64 %t305, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb90
bb103:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  br label %bb322
bb104:
  %t306 = load ptr, ptr %l1, !tbaa !29
  store ptr %t306, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t307 = load ptr, ptr %l205, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  store i1 %t308, ptr %l207, !tbaa !21
  %t309 = load i1, ptr %l207, !tbaa !21
  br i1 %t309, label %bb105, label %bb106
bb105:
  %t310 = load ptr, ptr %l205, !tbaa !29
  %t311 = load i64, ptr %t310
  store i64 %t311, ptr %l208, !tbaa !24
  %t312 = load i64, ptr %l208, !tbaa !24
  %t313 = icmp eq i64 %t312, 8
  store i1 %t313, ptr %l206, !tbaa !21
  br label %bb106
bb106:
  %t314 = load i1, ptr %l206, !tbaa !21
  br i1 %t314, label %bb107, label %bb108
bb107:
  %t315 = load ptr, ptr %l1, !tbaa !29
  store ptr %t315, ptr %l209, !tbaa !29
  %t316 = load ptr, ptr %l209, !tbaa !29
  %t317 = getelementptr { i64, [5 x i64] }, ptr %t316, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t317, i32 0, i32 1
  %t319 = load ptr, ptr %t318
  store ptr %t319, ptr %l210, !tbaa !29
  %t320 = load ptr, ptr %l210, !tbaa !29
  store ptr %t320, ptr %l20, !tbaa !29
  %t321 = load ptr, ptr %l1, !tbaa !29
  store ptr %t321, ptr %l211, !tbaa !29
  %t322 = load ptr, ptr %l211, !tbaa !29
  %t323 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t323, i32 0, i32 2
  %t325 = load ptr, ptr %t324
  store ptr %t325, ptr %l212, !tbaa !29
  %t326 = load ptr, ptr %l212, !tbaa !29
  store ptr %t326, ptr %l21, !tbaa !29
  %t327 = load ptr, ptr %l1, !tbaa !29
  store ptr %t327, ptr %l213, !tbaa !29
  %t328 = load ptr, ptr %l213, !tbaa !29
  %t329 = getelementptr { i64, [5 x i64] }, ptr %t328, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t329, i32 0, i32 3
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l214, !tbaa !29
  %t332 = load ptr, ptr %l214, !tbaa !29
  store ptr %t332, ptr %l22, !tbaa !29
  br label %bb109
bb108:
  br label %bb115
bb109:
  store %olang.scope zeroinitializer, ptr %s16
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l215, !tbaa !29
  %t334 = load ptr, ptr %l20, !tbaa !29
  store ptr %t334, ptr %l216, !tbaa !29
  %t335 = load ptr, ptr %l215, !tbaa !29
  %t336 = load ptr, ptr %l216, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t335, ptr %t336)
  br label %bb110
bb110:
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l217, !tbaa !29
  %t338 = load ptr, ptr %l217, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t338, { i64, ptr } { i64 4, ptr @.d33 })
  br label %bb111
bb111:
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l218, !tbaa !29
  %t340 = load ptr, ptr %l21, !tbaa !29
  store ptr %t340, ptr %l219, !tbaa !29
  %t341 = load ptr, ptr %l218, !tbaa !29
  %t342 = load ptr, ptr %l219, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t341, ptr %t342)
  br label %bb112
bb112:
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l220, !tbaa !29
  %t344 = load ptr, ptr %l220, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t344, { i64, ptr } { i64 6, ptr @.d34 })
  br label %bb113
bb113:
  %t345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t345, ptr %l221, !tbaa !29
  %t346 = load ptr, ptr %l22, !tbaa !29
  store ptr %t346, ptr %l222, !tbaa !29
  %t347 = load ptr, ptr %l221, !tbaa !29
  %t348 = load ptr, ptr %l222, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t347, ptr %t348)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s16)
  br label %bb322
bb115:
  %t349 = load ptr, ptr %l1, !tbaa !29
  store ptr %t349, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t350 = load ptr, ptr %l223, !tbaa !29
  %t351 = icmp ne ptr %t350, null
  store i1 %t351, ptr %l225, !tbaa !21
  %t352 = load i1, ptr %l225, !tbaa !21
  br i1 %t352, label %bb116, label %bb117
bb116:
  %t353 = load ptr, ptr %l223, !tbaa !29
  %t354 = load i64, ptr %t353
  store i64 %t354, ptr %l226, !tbaa !24
  %t355 = load i64, ptr %l226, !tbaa !24
  %t356 = icmp eq i64 %t355, 9
  store i1 %t356, ptr %l224, !tbaa !21
  br label %bb117
bb117:
  %t357 = load i1, ptr %l224, !tbaa !21
  br i1 %t357, label %bb118, label %bb119
bb118:
  %t358 = load ptr, ptr %l1, !tbaa !29
  store ptr %t358, ptr %l227, !tbaa !29
  %t359 = load ptr, ptr %l227, !tbaa !29
  %t360 = getelementptr { i64, [5 x i64] }, ptr %t359, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t360, i32 0, i32 1
  %t362 = load ptr, ptr %t361
  store ptr %t362, ptr %l228, !tbaa !29
  %t363 = load ptr, ptr %l228, !tbaa !29
  store ptr %t363, ptr %l23, !tbaa !29
  %t364 = load ptr, ptr %l1, !tbaa !29
  store ptr %t364, ptr %l229, !tbaa !29
  %t365 = load ptr, ptr %l229, !tbaa !29
  %t366 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 1
  %t367 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t366, i32 0, i32 2
  %t368 = load ptr, ptr %t367
  store ptr %t368, ptr %l230, !tbaa !29
  %t369 = load ptr, ptr %l230, !tbaa !29
  store ptr %t369, ptr %l24, !tbaa !29
  %t370 = load ptr, ptr %l1, !tbaa !29
  store ptr %t370, ptr %l231, !tbaa !29
  %t371 = load ptr, ptr %l231, !tbaa !29
  %t372 = getelementptr { i64, [5 x i64] }, ptr %t371, i32 0, i32 1
  %t373 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t372, i32 0, i32 3
  %t374 = load i1, ptr %t373
  store i1 %t374, ptr %l232, !tbaa !21
  %t375 = load i1, ptr %l232, !tbaa !21
  store i1 %t375, ptr %l25, !tbaa !21
  br label %bb120
bb119:
  br label %bb127
bb120:
  store %olang.scope zeroinitializer, ptr %s17
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l233, !tbaa !29
  %t377 = load ptr, ptr %l23, !tbaa !29
  store ptr %t377, ptr %l234, !tbaa !29
  %t378 = load ptr, ptr %l233, !tbaa !29
  %t379 = load ptr, ptr %l234, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t378, ptr %t379)
  br label %bb121
bb121:
  %t380 = load ptr, ptr %l0, !tbaa !29
  store ptr %t380, ptr %l235, !tbaa !29
  %t381 = load i1, ptr %l25, !tbaa !21
  store i1 %t381, ptr %l236, !tbaa !21
  %t382 = load i1, ptr %l236, !tbaa !21
  br i1 %t382, label %bb122, label %bb123
bb122:
  store { i64, ptr } { i64 8, ptr @.d35 }, ptr %l237, !tbaa !27
  br label %bb124
bb123:
  store { i64, ptr } { i64 4, ptr @.d36 }, ptr %l237, !tbaa !27
  br label %bb124
bb124:
  %t383 = load ptr, ptr %l235, !tbaa !29
  %t384 = load { i64, ptr }, ptr %l237, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t383, { i64, ptr } %t384)
  br label %bb125
bb125:
  %t385 = load ptr, ptr %l0, !tbaa !29
  store ptr %t385, ptr %l238, !tbaa !29
  %t386 = load ptr, ptr %l24, !tbaa !29
  store ptr %t386, ptr %l239, !tbaa !29
  %t387 = load ptr, ptr %l238, !tbaa !29
  %t388 = load ptr, ptr %l239, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t387, ptr %t388)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s17)
  br label %bb322
bb127:
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t390 = load ptr, ptr %l240, !tbaa !29
  %t391 = icmp ne ptr %t390, null
  store i1 %t391, ptr %l242, !tbaa !21
  %t392 = load i1, ptr %l242, !tbaa !21
  br i1 %t392, label %bb128, label %bb129
bb128:
  %t393 = load ptr, ptr %l240, !tbaa !29
  %t394 = load i64, ptr %t393
  store i64 %t394, ptr %l243, !tbaa !24
  %t395 = load i64, ptr %l243, !tbaa !24
  %t396 = icmp eq i64 %t395, 10
  store i1 %t396, ptr %l241, !tbaa !21
  br label %bb129
bb129:
  %t397 = load i1, ptr %l241, !tbaa !21
  br i1 %t397, label %bb130, label %bb131
bb130:
  %t398 = load ptr, ptr %l1, !tbaa !29
  store ptr %t398, ptr %l244, !tbaa !29
  %t399 = load ptr, ptr %l244, !tbaa !29
  %t400 = getelementptr { i64, [5 x i64] }, ptr %t399, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t400, i32 0, i32 1
  %t402 = load ptr, ptr %t401
  store ptr %t402, ptr %l245, !tbaa !29
  %t403 = load ptr, ptr %l245, !tbaa !29
  store ptr %t403, ptr %l26, !tbaa !29
  %t404 = load ptr, ptr %l1, !tbaa !29
  store ptr %t404, ptr %l246, !tbaa !29
  %t405 = load ptr, ptr %l246, !tbaa !29
  %t406 = getelementptr { i64, [5 x i64] }, ptr %t405, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t406, i32 0, i32 2
  %t408 = load ptr, ptr %t407
  store ptr %t408, ptr %l247, !tbaa !29
  %t409 = load ptr, ptr %l247, !tbaa !29
  store ptr %t409, ptr %l27, !tbaa !29
  %t410 = load ptr, ptr %l1, !tbaa !29
  store ptr %t410, ptr %l248, !tbaa !29
  %t411 = load ptr, ptr %l248, !tbaa !29
  %t412 = getelementptr { i64, [5 x i64] }, ptr %t411, i32 0, i32 1
  %t413 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t412, i32 0, i32 3
  %t414 = load i1, ptr %t413
  store i1 %t414, ptr %l249, !tbaa !21
  %t415 = load i1, ptr %l249, !tbaa !21
  store i1 %t415, ptr %l28, !tbaa !21
  br label %bb132
bb131:
  br label %bb139
bb132:
  store %olang.scope zeroinitializer, ptr %s18
  %t416 = load ptr, ptr %l0, !tbaa !29
  store ptr %t416, ptr %l250, !tbaa !29
  %t417 = load ptr, ptr %l26, !tbaa !29
  store ptr %t417, ptr %l251, !tbaa !29
  %t418 = load ptr, ptr %l250, !tbaa !29
  %t419 = load ptr, ptr %l251, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t418, ptr %t419)
  br label %bb133
bb133:
  %t420 = load ptr, ptr %l0, !tbaa !29
  store ptr %t420, ptr %l252, !tbaa !29
  %t421 = load i1, ptr %l28, !tbaa !21
  store i1 %t421, ptr %l253, !tbaa !21
  %t422 = load i1, ptr %l253, !tbaa !21
  br i1 %t422, label %bb134, label %bb135
bb134:
  store { i64, ptr } { i64 8, ptr @.d37 }, ptr %l254, !tbaa !27
  br label %bb136
bb135:
  store { i64, ptr } { i64 4, ptr @.d38 }, ptr %l254, !tbaa !27
  br label %bb136
bb136:
  %t423 = load ptr, ptr %l252, !tbaa !29
  %t424 = load { i64, ptr }, ptr %l254, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t423, { i64, ptr } %t424)
  br label %bb137
bb137:
  %t425 = load ptr, ptr %l0, !tbaa !29
  store ptr %t425, ptr %l255, !tbaa !29
  %t426 = load ptr, ptr %l27, !tbaa !29
  store ptr %t426, ptr %l256, !tbaa !29
  %t427 = load ptr, ptr %l255, !tbaa !29
  %t428 = load ptr, ptr %l256, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t427, ptr %t428)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s18)
  br label %bb322
bb139:
  %t429 = load ptr, ptr %l1, !tbaa !29
  store ptr %t429, ptr %l257, !tbaa !29
  store i1 false, ptr %l258, !tbaa !21
  %t430 = load ptr, ptr %l257, !tbaa !29
  %t431 = icmp ne ptr %t430, null
  store i1 %t431, ptr %l259, !tbaa !21
  %t432 = load i1, ptr %l259, !tbaa !21
  br i1 %t432, label %bb140, label %bb141
bb140:
  %t433 = load ptr, ptr %l257, !tbaa !29
  %t434 = load i64, ptr %t433
  store i64 %t434, ptr %l260, !tbaa !24
  %t435 = load i64, ptr %l260, !tbaa !24
  %t436 = icmp eq i64 %t435, 11
  store i1 %t436, ptr %l258, !tbaa !21
  br label %bb141
bb141:
  %t437 = load i1, ptr %l258, !tbaa !21
  br i1 %t437, label %bb142, label %bb143
bb142:
  %t438 = load ptr, ptr %l1, !tbaa !29
  store ptr %t438, ptr %l261, !tbaa !29
  %t439 = load ptr, ptr %l261, !tbaa !29
  %t440 = getelementptr { i64, [5 x i64] }, ptr %t439, i32 0, i32 1
  %t441 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t440, i32 0, i32 1
  %t442 = load ptr, ptr %t441
  store ptr %t442, ptr %l262, !tbaa !29
  %t443 = load ptr, ptr %l262, !tbaa !29
  store ptr %t443, ptr %l29, !tbaa !29
  %t444 = load ptr, ptr %l1, !tbaa !29
  store ptr %t444, ptr %l263, !tbaa !29
  %t445 = load ptr, ptr %l263, !tbaa !29
  %t446 = getelementptr { i64, [5 x i64] }, ptr %t445, i32 0, i32 1
  %t447 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t446, i32 0, i32 2
  %t448 = load ptr, ptr %t447
  store ptr %t448, ptr %l264, !tbaa !29
  %t449 = load ptr, ptr %l264, !tbaa !29
  store ptr %t449, ptr %l30, !tbaa !29
  br label %bb144
bb143:
  br label %bb148
bb144:
  store %olang.scope zeroinitializer, ptr %s19
  %t450 = load ptr, ptr %l0, !tbaa !29
  store ptr %t450, ptr %l265, !tbaa !29
  %t451 = load ptr, ptr %l29, !tbaa !29
  store ptr %t451, ptr %l266, !tbaa !29
  %t452 = load ptr, ptr %l265, !tbaa !29
  %t453 = load ptr, ptr %l266, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t452, ptr %t453)
  br label %bb145
bb145:
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l267, !tbaa !29
  %t455 = load ptr, ptr %l267, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t455, { i64, ptr } { i64 4, ptr @.d39 })
  br label %bb146
bb146:
  %t456 = load ptr, ptr %l0, !tbaa !29
  store ptr %t456, ptr %l268, !tbaa !29
  %t457 = load ptr, ptr %l30, !tbaa !29
  store ptr %t457, ptr %l269, !tbaa !29
  %t458 = load ptr, ptr %l268, !tbaa !29
  %t459 = load ptr, ptr %l269, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t458, ptr %t459)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s19)
  br label %bb322
bb148:
  %t460 = load ptr, ptr %l1, !tbaa !29
  store ptr %t460, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t461 = load ptr, ptr %l270, !tbaa !29
  %t462 = icmp ne ptr %t461, null
  store i1 %t462, ptr %l272, !tbaa !21
  %t463 = load i1, ptr %l272, !tbaa !21
  br i1 %t463, label %bb149, label %bb150
bb149:
  %t464 = load ptr, ptr %l270, !tbaa !29
  %t465 = load i64, ptr %t464
  store i64 %t465, ptr %l273, !tbaa !24
  %t466 = load i64, ptr %l273, !tbaa !24
  %t467 = icmp eq i64 %t466, 12
  store i1 %t467, ptr %l271, !tbaa !21
  br label %bb150
bb150:
  %t468 = load i1, ptr %l271, !tbaa !21
  br i1 %t468, label %bb151, label %bb152
bb151:
  %t469 = load ptr, ptr %l1, !tbaa !29
  store ptr %t469, ptr %l274, !tbaa !29
  %t470 = load ptr, ptr %l274, !tbaa !29
  %t471 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 1
  %t472 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t471, i32 0, i32 1
  %t473 = load ptr, ptr %t472
  store ptr %t473, ptr %l275, !tbaa !29
  %t474 = load ptr, ptr %l275, !tbaa !29
  store ptr %t474, ptr %l31, !tbaa !29
  %t475 = load ptr, ptr %l1, !tbaa !29
  store ptr %t475, ptr %l276, !tbaa !29
  %t476 = load ptr, ptr %l276, !tbaa !29
  %t477 = getelementptr { i64, [5 x i64] }, ptr %t476, i32 0, i32 1
  %t478 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t477, i32 0, i32 2
  %t479 = load { i64, ptr }, ptr %t478
  store { i64, ptr } %t479, ptr %l277, !tbaa !27
  %t480 = load { i64, ptr }, ptr %l277, !tbaa !27
  store { i64, ptr } %t480, ptr %l32, !tbaa !27
  br label %bb153
bb152:
  br label %bb158
bb153:
  store %olang.scope zeroinitializer, ptr %s20
  %t481 = load ptr, ptr %l0, !tbaa !29
  store ptr %t481, ptr %l278, !tbaa !29
  %t482 = load ptr, ptr %l31, !tbaa !29
  store ptr %t482, ptr %l279, !tbaa !29
  %t483 = load ptr, ptr %l278, !tbaa !29
  %t484 = load ptr, ptr %l279, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t483, ptr %t484)
  br label %bb154
bb154:
  %t485 = load ptr, ptr %l0, !tbaa !29
  store ptr %t485, ptr %l280, !tbaa !29
  %t486 = load ptr, ptr %l280, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t486, { i64, ptr } { i64 1, ptr @.d40 })
  br label %bb155
bb155:
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l281, !tbaa !29
  %t488 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t488, ptr %l282, !tbaa !27
  %t489 = load ptr, ptr %l281, !tbaa !29
  %t490 = load { i64, ptr }, ptr %l282, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t489, { i64, ptr } %t490)
  br label %bb156
bb156:
  %t491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t491, ptr %l283, !tbaa !29
  %t492 = load ptr, ptr %l283, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t492, { i64, ptr } { i64 1, ptr @.d41 })
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s20)
  br label %bb322
bb158:
  %t493 = load ptr, ptr %l1, !tbaa !29
  store ptr %t493, ptr %l284, !tbaa !29
  store i1 false, ptr %l285, !tbaa !21
  %t494 = load ptr, ptr %l284, !tbaa !29
  %t495 = icmp ne ptr %t494, null
  store i1 %t495, ptr %l286, !tbaa !21
  %t496 = load i1, ptr %l286, !tbaa !21
  br i1 %t496, label %bb159, label %bb160
bb159:
  %t497 = load ptr, ptr %l284, !tbaa !29
  %t498 = load i64, ptr %t497
  store i64 %t498, ptr %l287, !tbaa !24
  %t499 = load i64, ptr %l287, !tbaa !24
  %t500 = icmp eq i64 %t499, 13
  store i1 %t500, ptr %l285, !tbaa !21
  br label %bb160
bb160:
  %t501 = load i1, ptr %l285, !tbaa !21
  br i1 %t501, label %bb161, label %bb162
bb161:
  %t502 = load ptr, ptr %l1, !tbaa !29
  store ptr %t502, ptr %l288, !tbaa !29
  %t503 = load ptr, ptr %l288, !tbaa !29
  %t504 = getelementptr { i64, [5 x i64] }, ptr %t503, i32 0, i32 1
  %t505 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t504, i32 0, i32 1
  %t506 = load ptr, ptr %t505
  store ptr %t506, ptr %l289, !tbaa !29
  %t507 = load ptr, ptr %l289, !tbaa !29
  store ptr %t507, ptr %l33, !tbaa !29
  %t508 = load ptr, ptr %l1, !tbaa !29
  store ptr %t508, ptr %l290, !tbaa !29
  %t509 = load ptr, ptr %l290, !tbaa !29
  %t510 = getelementptr { i64, [5 x i64] }, ptr %t509, i32 0, i32 1
  %t511 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t510, i32 0, i32 2
  %t512 = load i32, ptr %t511
  store i32 %t512, ptr %l291, !tbaa !23
  %t513 = load i32, ptr %l291, !tbaa !23
  store i32 %t513, ptr %l34, !tbaa !23
  %t514 = load ptr, ptr %l1, !tbaa !29
  store ptr %t514, ptr %l292, !tbaa !29
  %t515 = load ptr, ptr %l292, !tbaa !29
  %t516 = getelementptr { i64, [5 x i64] }, ptr %t515, i32 0, i32 1
  %t517 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t516, i32 0, i32 3
  %t518 = load { i64, ptr }, ptr %t517
  store { i64, ptr } %t518, ptr %l293, !tbaa !27
  %t519 = load { i64, ptr }, ptr %l293, !tbaa !27
  store { i64, ptr } %t519, ptr %l35, !tbaa !27
  br label %bb163
bb162:
  br label %bb170
bb163:
  store %olang.scope zeroinitializer, ptr %s21
  %t520 = load ptr, ptr %l0, !tbaa !29
  store ptr %t520, ptr %l294, !tbaa !29
  %t521 = load ptr, ptr %l33, !tbaa !29
  store ptr %t521, ptr %l295, !tbaa !29
  %t522 = load ptr, ptr %l294, !tbaa !29
  %t523 = load ptr, ptr %l295, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t522, ptr %t523)
  br label %bb164
bb164:
  %t524 = load ptr, ptr %l0, !tbaa !29
  store ptr %t524, ptr %l296, !tbaa !29
  %t525 = load ptr, ptr %l296, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t525, { i64, ptr } { i64 1, ptr @.d42 })
  br label %bb165
bb165:
  %t526 = load ptr, ptr %l0, !tbaa !29
  store ptr %t526, ptr %l297, !tbaa !29
  %t527 = load i32, ptr %l34, !tbaa !23
  store i32 %t527, ptr %l298, !tbaa !23
  %t528 = load ptr, ptr %l297, !tbaa !29
  %t529 = load i32, ptr %l298, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t528, i32 %t529)
  br label %bb166
bb166:
  %t530 = load ptr, ptr %l0, !tbaa !29
  store ptr %t530, ptr %l299, !tbaa !29
  %t531 = load ptr, ptr %l299, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t531, { i64, ptr } { i64 1, ptr @.d43 })
  br label %bb167
bb167:
  %t532 = load ptr, ptr %l0, !tbaa !29
  store ptr %t532, ptr %l300, !tbaa !29
  %t533 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t533, ptr %l301, !tbaa !27
  %t534 = load ptr, ptr %l300, !tbaa !29
  %t535 = load { i64, ptr }, ptr %l301, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t534, { i64, ptr } %t535)
  br label %bb168
bb168:
  %t536 = load ptr, ptr %l0, !tbaa !29
  store ptr %t536, ptr %l302, !tbaa !29
  %t537 = load ptr, ptr %l302, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t537, { i64, ptr } { i64 1, ptr @.d44 })
  br label %bb169
bb169:
  call void @__olang_scope_close(ptr %s21)
  br label %bb322
bb170:
  %t538 = load ptr, ptr %l1, !tbaa !29
  store ptr %t538, ptr %l303, !tbaa !29
  store i1 false, ptr %l304, !tbaa !21
  %t539 = load ptr, ptr %l303, !tbaa !29
  %t540 = icmp ne ptr %t539, null
  store i1 %t540, ptr %l305, !tbaa !21
  %t541 = load i1, ptr %l305, !tbaa !21
  br i1 %t541, label %bb171, label %bb172
bb171:
  %t542 = load ptr, ptr %l303, !tbaa !29
  %t543 = load i64, ptr %t542
  store i64 %t543, ptr %l306, !tbaa !24
  %t544 = load i64, ptr %l306, !tbaa !24
  %t545 = icmp eq i64 %t544, 14
  store i1 %t545, ptr %l304, !tbaa !21
  br label %bb172
bb172:
  %t546 = load i1, ptr %l304, !tbaa !21
  br i1 %t546, label %bb173, label %bb174
bb173:
  %t547 = load ptr, ptr %l1, !tbaa !29
  store ptr %t547, ptr %l307, !tbaa !29
  %t548 = load ptr, ptr %l307, !tbaa !29
  %t549 = getelementptr { i64, [5 x i64] }, ptr %t548, i32 0, i32 1
  %t550 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t549, i32 0, i32 1
  %t551 = load ptr, ptr %t550
  store ptr %t551, ptr %l308, !tbaa !29
  %t552 = load ptr, ptr %l308, !tbaa !29
  store ptr %t552, ptr %l36, !tbaa !29
  %t553 = load ptr, ptr %l1, !tbaa !29
  store ptr %t553, ptr %l309, !tbaa !29
  %t554 = load ptr, ptr %l309, !tbaa !29
  %t555 = getelementptr { i64, [5 x i64] }, ptr %t554, i32 0, i32 1
  %t556 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t555, i32 0, i32 2
  %t557 = load { i64, ptr }, ptr %t556
  store { i64, ptr } %t557, ptr %l310, !tbaa !27
  %t558 = load { i64, ptr }, ptr %l310, !tbaa !27
  store { i64, ptr } %t558, ptr %l37, !tbaa !27
  br label %bb175
bb174:
  br label %bb180
bb175:
  store %olang.scope zeroinitializer, ptr %s22
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l311, !tbaa !29
  %t560 = load ptr, ptr %l36, !tbaa !29
  store ptr %t560, ptr %l312, !tbaa !29
  %t561 = load ptr, ptr %l311, !tbaa !29
  %t562 = load ptr, ptr %l312, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t561, ptr %t562)
  br label %bb176
bb176:
  %t563 = load ptr, ptr %l0, !tbaa !29
  store ptr %t563, ptr %l313, !tbaa !29
  %t564 = load ptr, ptr %l313, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t564, { i64, ptr } { i64 1, ptr @.d45 })
  br label %bb177
bb177:
  %t565 = load ptr, ptr %l0, !tbaa !29
  store ptr %t565, ptr %l314, !tbaa !29
  %t566 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t566, ptr %l315, !tbaa !27
  %t567 = load ptr, ptr %l314, !tbaa !29
  %t568 = load { i64, ptr }, ptr %l315, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t567, { i64, ptr } %t568)
  br label %bb178
bb178:
  %t569 = load ptr, ptr %l0, !tbaa !29
  store ptr %t569, ptr %l316, !tbaa !29
  %t570 = load ptr, ptr %l316, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t570, { i64, ptr } { i64 1, ptr @.d46 })
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s22)
  br label %bb322
bb180:
  %t571 = load ptr, ptr %l1, !tbaa !29
  store ptr %t571, ptr %l317, !tbaa !29
  store i1 false, ptr %l318, !tbaa !21
  %t572 = load ptr, ptr %l317, !tbaa !29
  %t573 = icmp ne ptr %t572, null
  store i1 %t573, ptr %l319, !tbaa !21
  %t574 = load i1, ptr %l319, !tbaa !21
  br i1 %t574, label %bb181, label %bb182
bb181:
  %t575 = load ptr, ptr %l317, !tbaa !29
  %t576 = load i64, ptr %t575
  store i64 %t576, ptr %l320, !tbaa !24
  %t577 = load i64, ptr %l320, !tbaa !24
  %t578 = icmp eq i64 %t577, 15
  store i1 %t578, ptr %l318, !tbaa !21
  br label %bb182
bb182:
  %t579 = load i1, ptr %l318, !tbaa !21
  br i1 %t579, label %bb183, label %bb184
bb183:
  %t580 = load ptr, ptr %l1, !tbaa !29
  store ptr %t580, ptr %l321, !tbaa !29
  %t581 = load ptr, ptr %l321, !tbaa !29
  %t582 = getelementptr { i64, [5 x i64] }, ptr %t581, i32 0, i32 1
  %t583 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t582, i32 0, i32 1
  %t584 = load ptr, ptr %t583
  store ptr %t584, ptr %l322, !tbaa !29
  %t585 = load ptr, ptr %l322, !tbaa !29
  store ptr %t585, ptr %l38, !tbaa !29
  %t586 = load ptr, ptr %l1, !tbaa !29
  store ptr %t586, ptr %l323, !tbaa !29
  %t587 = load ptr, ptr %l323, !tbaa !29
  %t588 = getelementptr { i64, [5 x i64] }, ptr %t587, i32 0, i32 1
  %t589 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t588, i32 0, i32 2
  %t590 = load i32, ptr %t589
  store i32 %t590, ptr %l324, !tbaa !23
  %t591 = load i32, ptr %l324, !tbaa !23
  store i32 %t591, ptr %l39, !tbaa !23
  br label %bb185
bb184:
  br label %bb189
bb185:
  store %olang.scope zeroinitializer, ptr %s23
  %t592 = load ptr, ptr %l0, !tbaa !29
  store ptr %t592, ptr %l325, !tbaa !29
  %t593 = load ptr, ptr %l38, !tbaa !29
  store ptr %t593, ptr %l326, !tbaa !29
  %t594 = load ptr, ptr %l325, !tbaa !29
  %t595 = load ptr, ptr %l326, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t594, ptr %t595)
  br label %bb186
bb186:
  %t596 = load ptr, ptr %l0, !tbaa !29
  store ptr %t596, ptr %l327, !tbaa !29
  %t597 = load ptr, ptr %l327, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t597, { i64, ptr } { i64 1, ptr @.d47 })
  br label %bb187
bb187:
  %t598 = load ptr, ptr %l0, !tbaa !29
  store ptr %t598, ptr %l328, !tbaa !29
  %t599 = load i32, ptr %l39, !tbaa !23
  store i32 %t599, ptr %l329, !tbaa !23
  %t600 = load ptr, ptr %l328, !tbaa !29
  %t601 = load i32, ptr %l329, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t600, i32 %t601)
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s23)
  br label %bb322
bb189:
  %t602 = load ptr, ptr %l1, !tbaa !29
  store ptr %t602, ptr %l330, !tbaa !29
  store i1 false, ptr %l331, !tbaa !21
  %t603 = load ptr, ptr %l330, !tbaa !29
  %t604 = icmp ne ptr %t603, null
  store i1 %t604, ptr %l332, !tbaa !21
  %t605 = load i1, ptr %l332, !tbaa !21
  br i1 %t605, label %bb190, label %bb191
bb190:
  %t606 = load ptr, ptr %l330, !tbaa !29
  %t607 = load i64, ptr %t606
  store i64 %t607, ptr %l333, !tbaa !24
  %t608 = load i64, ptr %l333, !tbaa !24
  %t609 = icmp eq i64 %t608, 16
  store i1 %t609, ptr %l331, !tbaa !21
  br label %bb191
bb191:
  %t610 = load i1, ptr %l331, !tbaa !21
  br i1 %t610, label %bb192, label %bb193
bb192:
  %t611 = load ptr, ptr %l1, !tbaa !29
  store ptr %t611, ptr %l334, !tbaa !29
  %t612 = load ptr, ptr %l334, !tbaa !29
  %t613 = getelementptr { i64, [5 x i64] }, ptr %t612, i32 0, i32 1
  %t614 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t613, i32 0, i32 1
  %t615 = load ptr, ptr %t614
  store ptr %t615, ptr %l335, !tbaa !29
  %t616 = load ptr, ptr %l335, !tbaa !29
  store ptr %t616, ptr %l40, !tbaa !29
  %t617 = load ptr, ptr %l1, !tbaa !29
  store ptr %t617, ptr %l336, !tbaa !29
  %t618 = load ptr, ptr %l336, !tbaa !29
  %t619 = getelementptr { i64, [5 x i64] }, ptr %t618, i32 0, i32 1
  %t620 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t619, i32 0, i32 2
  %t621 = load { i64, ptr }, ptr %t620
  store { i64, ptr } %t621, ptr %l337, !tbaa !27
  %t622 = load { i64, ptr }, ptr %l337, !tbaa !27
  store { i64, ptr } %t622, ptr %l41, !tbaa !27
  br label %bb194
bb193:
  br label %bb199
bb194:
  store %olang.scope zeroinitializer, ptr %s24
  %t623 = load ptr, ptr %l0, !tbaa !29
  store ptr %t623, ptr %l338, !tbaa !29
  %t624 = load ptr, ptr %l40, !tbaa !29
  store ptr %t624, ptr %l339, !tbaa !29
  %t625 = load ptr, ptr %l338, !tbaa !29
  %t626 = load ptr, ptr %l339, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t625, ptr %t626)
  br label %bb195
bb195:
  %t627 = load ptr, ptr %l0, !tbaa !29
  store ptr %t627, ptr %l340, !tbaa !29
  %t628 = load ptr, ptr %l340, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t628, { i64, ptr } { i64 1, ptr @.d48 })
  br label %bb196
bb196:
  %t629 = load ptr, ptr %l0, !tbaa !29
  store ptr %t629, ptr %l341, !tbaa !29
  %t630 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t630, ptr %l342, !tbaa !27
  %t631 = load ptr, ptr %l341, !tbaa !29
  %t632 = load { i64, ptr }, ptr %l342, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t631, { i64, ptr } %t632)
  br label %bb197
bb197:
  %t633 = load ptr, ptr %l0, !tbaa !29
  store ptr %t633, ptr %l343, !tbaa !29
  %t634 = load ptr, ptr %l343, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t634, { i64, ptr } { i64 1, ptr @.d49 })
  br label %bb198
bb198:
  call void @__olang_scope_close(ptr %s24)
  br label %bb322
bb199:
  %t635 = load ptr, ptr %l1, !tbaa !29
  store ptr %t635, ptr %l344, !tbaa !29
  store i1 false, ptr %l345, !tbaa !21
  %t636 = load ptr, ptr %l344, !tbaa !29
  %t637 = icmp ne ptr %t636, null
  store i1 %t637, ptr %l346, !tbaa !21
  %t638 = load i1, ptr %l346, !tbaa !21
  br i1 %t638, label %bb200, label %bb201
bb200:
  %t639 = load ptr, ptr %l344, !tbaa !29
  %t640 = load i64, ptr %t639
  store i64 %t640, ptr %l347, !tbaa !24
  %t641 = load i64, ptr %l347, !tbaa !24
  %t642 = icmp eq i64 %t641, 17
  store i1 %t642, ptr %l345, !tbaa !21
  br label %bb201
bb201:
  %t643 = load i1, ptr %l345, !tbaa !21
  br i1 %t643, label %bb202, label %bb203
bb202:
  %t644 = load ptr, ptr %l1, !tbaa !29
  store ptr %t644, ptr %l348, !tbaa !29
  %t645 = load ptr, ptr %l348, !tbaa !29
  %t646 = getelementptr { i64, [5 x i64] }, ptr %t645, i32 0, i32 1
  %t647 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t646, i32 0, i32 1
  %t648 = load ptr, ptr %t647
  store ptr %t648, ptr %l349, !tbaa !29
  %t649 = load ptr, ptr %l349, !tbaa !29
  store ptr %t649, ptr %l42, !tbaa !29
  %t650 = load ptr, ptr %l1, !tbaa !29
  store ptr %t650, ptr %l350, !tbaa !29
  %t651 = load ptr, ptr %l350, !tbaa !29
  %t652 = getelementptr { i64, [5 x i64] }, ptr %t651, i32 0, i32 1
  %t653 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t652, i32 0, i32 2
  %t654 = load ptr, ptr %t653
  store ptr %t654, ptr %l351, !tbaa !29
  %t655 = load ptr, ptr %l351, !tbaa !29
  store ptr %t655, ptr %l43, !tbaa !29
  %t656 = load ptr, ptr %l1, !tbaa !29
  store ptr %t656, ptr %l352, !tbaa !29
  %t657 = load ptr, ptr %l352, !tbaa !29
  %t658 = getelementptr { i64, [5 x i64] }, ptr %t657, i32 0, i32 1
  %t659 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t658, i32 0, i32 3
  %t660 = load ptr, ptr %t659
  store ptr %t660, ptr %l353, !tbaa !29
  %t661 = load ptr, ptr %l353, !tbaa !29
  store ptr %t661, ptr %l44, !tbaa !29
  br label %bb204
bb203:
  br label %bb217
bb204:
  store %olang.scope zeroinitializer, ptr %s25
  %t662 = load ptr, ptr %l0, !tbaa !29
  store ptr %t662, ptr %l354, !tbaa !29
  %t663 = load ptr, ptr %l42, !tbaa !29
  store ptr %t663, ptr %l355, !tbaa !29
  %t664 = load ptr, ptr %l354, !tbaa !29
  %t665 = load ptr, ptr %l355, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t664, ptr %t665)
  br label %bb205
bb205:
  %t666 = load ptr, ptr %l0, !tbaa !29
  store ptr %t666, ptr %l356, !tbaa !29
  %t667 = load ptr, ptr %l356, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t667, { i64, ptr } { i64 1, ptr @.d50 })
  br label %bb206
bb206:
  %t668 = load ptr, ptr %l43, !tbaa !29
  store ptr %t668, ptr %l357, !tbaa !29
  %t669 = load ptr, ptr %l357, !tbaa !29
  %t670 = icmp ne ptr %t669, null
  store i1 %t670, ptr %l358, !tbaa !21
  %t671 = load i1, ptr %l358, !tbaa !21
  br i1 %t671, label %bb207, label %bb208
bb207:
  store %olang.scope zeroinitializer, ptr %s26
  %t672 = load ptr, ptr %l0, !tbaa !29
  store ptr %t672, ptr %l359, !tbaa !29
  %t673 = load ptr, ptr %l43, !tbaa !29
  store ptr %t673, ptr %l360, !tbaa !29
  %t674 = load ptr, ptr %l359, !tbaa !29
  %t675 = load ptr, ptr %l360, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t674, ptr %t675)
  br label %bb209
bb208:
  br label %bb210
bb209:
  call void @__olang_scope_close(ptr %s26)
  br label %bb210
bb210:
  %t676 = load ptr, ptr %l0, !tbaa !29
  store ptr %t676, ptr %l361, !tbaa !29
  %t677 = load ptr, ptr %l361, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t677, { i64, ptr } { i64 1, ptr @.d51 })
  br label %bb211
bb211:
  %t678 = load ptr, ptr %l44, !tbaa !29
  store ptr %t678, ptr %l362, !tbaa !29
  %t679 = load ptr, ptr %l362, !tbaa !29
  %t680 = icmp ne ptr %t679, null
  store i1 %t680, ptr %l363, !tbaa !21
  %t681 = load i1, ptr %l363, !tbaa !21
  br i1 %t681, label %bb212, label %bb213
bb212:
  store %olang.scope zeroinitializer, ptr %s27
  %t682 = load ptr, ptr %l0, !tbaa !29
  store ptr %t682, ptr %l364, !tbaa !29
  %t683 = load ptr, ptr %l44, !tbaa !29
  store ptr %t683, ptr %l365, !tbaa !29
  %t684 = load ptr, ptr %l364, !tbaa !29
  %t685 = load ptr, ptr %l365, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t684, ptr %t685)
  br label %bb214
bb213:
  br label %bb215
bb214:
  call void @__olang_scope_close(ptr %s27)
  br label %bb215
bb215:
  %t686 = load ptr, ptr %l0, !tbaa !29
  store ptr %t686, ptr %l366, !tbaa !29
  %t687 = load ptr, ptr %l366, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t687, { i64, ptr } { i64 1, ptr @.d52 })
  br label %bb216
bb216:
  call void @__olang_scope_close(ptr %s25)
  br label %bb322
bb217:
  %t688 = load ptr, ptr %l1, !tbaa !29
  store ptr %t688, ptr %l367, !tbaa !29
  store i1 false, ptr %l368, !tbaa !21
  %t689 = load ptr, ptr %l367, !tbaa !29
  %t690 = icmp ne ptr %t689, null
  store i1 %t690, ptr %l369, !tbaa !21
  %t691 = load i1, ptr %l369, !tbaa !21
  br i1 %t691, label %bb218, label %bb219
bb218:
  %t692 = load ptr, ptr %l367, !tbaa !29
  %t693 = load i64, ptr %t692
  store i64 %t693, ptr %l370, !tbaa !24
  %t694 = load i64, ptr %l370, !tbaa !24
  %t695 = icmp eq i64 %t694, 18
  store i1 %t695, ptr %l368, !tbaa !21
  br label %bb219
bb219:
  %t696 = load i1, ptr %l368, !tbaa !21
  br i1 %t696, label %bb220, label %bb221
bb220:
  %t697 = load ptr, ptr %l1, !tbaa !29
  store ptr %t697, ptr %l371, !tbaa !29
  %t698 = load ptr, ptr %l371, !tbaa !29
  %t699 = getelementptr { i64, [5 x i64] }, ptr %t698, i32 0, i32 1
  %t700 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t699, i32 0, i32 1
  %t701 = load ptr, ptr %t700
  store ptr %t701, ptr %l372, !tbaa !29
  %t702 = load ptr, ptr %l372, !tbaa !29
  store ptr %t702, ptr %l45, !tbaa !29
  %t703 = load ptr, ptr %l1, !tbaa !29
  store ptr %t703, ptr %l373, !tbaa !29
  %t704 = load ptr, ptr %l373, !tbaa !29
  %t705 = getelementptr { i64, [5 x i64] }, ptr %t704, i32 0, i32 1
  %t706 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t705, i32 0, i32 2
  %t707 = load { i64, ptr }, ptr %t706
  store { i64, ptr } %t707, ptr %l374, !tbaa !27
  %t708 = load { i64, ptr }, ptr %l374, !tbaa !27
  store { i64, ptr } %t708, ptr %l46, !tbaa !27
  br label %bb222
bb221:
  br label %bb227
bb222:
  store %olang.scope zeroinitializer, ptr %s28
  %t709 = load ptr, ptr %l0, !tbaa !29
  store ptr %t709, ptr %l375, !tbaa !29
  %t710 = load ptr, ptr %l45, !tbaa !29
  store ptr %t710, ptr %l376, !tbaa !29
  %t711 = load ptr, ptr %l375, !tbaa !29
  %t712 = load ptr, ptr %l376, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t711, ptr %t712)
  br label %bb223
bb223:
  %t713 = load ptr, ptr %l0, !tbaa !29
  store ptr %t713, ptr %l377, !tbaa !29
  %t714 = load ptr, ptr %l377, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t714, { i64, ptr } { i64 1, ptr @.d53 })
  br label %bb224
bb224:
  %t715 = load ptr, ptr %l0, !tbaa !29
  store ptr %t715, ptr %l378, !tbaa !29
  %t716 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t716, ptr %l379, !tbaa !27
  %t717 = load ptr, ptr %l378, !tbaa !29
  %t718 = load { i64, ptr }, ptr %l379, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t717, { i64, ptr } %t718)
  br label %bb225
bb225:
  %t719 = load ptr, ptr %l0, !tbaa !29
  store ptr %t719, ptr %l380, !tbaa !29
  %t720 = load ptr, ptr %l380, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t720, { i64, ptr } { i64 1, ptr @.d54 })
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s28)
  br label %bb322
bb227:
  %t721 = load ptr, ptr %l1, !tbaa !29
  store ptr %t721, ptr %l381, !tbaa !29
  store i1 false, ptr %l382, !tbaa !21
  %t722 = load ptr, ptr %l381, !tbaa !29
  %t723 = icmp ne ptr %t722, null
  store i1 %t723, ptr %l383, !tbaa !21
  %t724 = load i1, ptr %l383, !tbaa !21
  br i1 %t724, label %bb228, label %bb229
bb228:
  %t725 = load ptr, ptr %l381, !tbaa !29
  %t726 = load i64, ptr %t725
  store i64 %t726, ptr %l384, !tbaa !24
  %t727 = load i64, ptr %l384, !tbaa !24
  %t728 = icmp eq i64 %t727, 19
  store i1 %t728, ptr %l382, !tbaa !21
  br label %bb229
bb229:
  %t729 = load i1, ptr %l382, !tbaa !21
  br i1 %t729, label %bb230, label %bb231
bb230:
  %t730 = load ptr, ptr %l1, !tbaa !29
  store ptr %t730, ptr %l385, !tbaa !29
  %t731 = load ptr, ptr %l385, !tbaa !29
  %t732 = getelementptr { i64, [5 x i64] }, ptr %t731, i32 0, i32 1
  %t733 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t732, i32 0, i32 1
  %t734 = load { i64, ptr }, ptr %t733
  store { i64, ptr } %t734, ptr %l386, !tbaa !27
  %t735 = load { i64, ptr }, ptr %l386, !tbaa !27
  store { i64, ptr } %t735, ptr %l47, !tbaa !27
  br label %bb232
bb231:
  br label %bb236
bb232:
  store %olang.scope zeroinitializer, ptr %s29
  %t736 = load ptr, ptr %l0, !tbaa !29
  store ptr %t736, ptr %l387, !tbaa !29
  %t737 = load ptr, ptr %l387, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t737, { i64, ptr } { i64 1, ptr @.d55 })
  br label %bb233
bb233:
  %t738 = load ptr, ptr %l0, !tbaa !29
  store ptr %t738, ptr %l388, !tbaa !29
  %t739 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t739, ptr %l389, !tbaa !27
  %t740 = load ptr, ptr %l388, !tbaa !29
  %t741 = load { i64, ptr }, ptr %l389, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t740, { i64, ptr } %t741)
  br label %bb234
bb234:
  %t742 = load ptr, ptr %l0, !tbaa !29
  store ptr %t742, ptr %l390, !tbaa !29
  %t743 = load ptr, ptr %l390, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t743, { i64, ptr } { i64 1, ptr @.d56 })
  br label %bb235
bb235:
  call void @__olang_scope_close(ptr %s29)
  br label %bb322
bb236:
  %t744 = load ptr, ptr %l1, !tbaa !29
  store ptr %t744, ptr %l391, !tbaa !29
  store i1 false, ptr %l392, !tbaa !21
  %t745 = load ptr, ptr %l391, !tbaa !29
  %t746 = icmp ne ptr %t745, null
  store i1 %t746, ptr %l393, !tbaa !21
  %t747 = load i1, ptr %l393, !tbaa !21
  br i1 %t747, label %bb237, label %bb238
bb237:
  %t748 = load ptr, ptr %l391, !tbaa !29
  %t749 = load i64, ptr %t748
  store i64 %t749, ptr %l394, !tbaa !24
  %t750 = load i64, ptr %l394, !tbaa !24
  %t751 = icmp eq i64 %t750, 20
  store i1 %t751, ptr %l392, !tbaa !21
  br label %bb238
bb238:
  %t752 = load i1, ptr %l392, !tbaa !21
  br i1 %t752, label %bb239, label %bb240
bb239:
  %t753 = load ptr, ptr %l1, !tbaa !29
  store ptr %t753, ptr %l395, !tbaa !29
  %t754 = load ptr, ptr %l395, !tbaa !29
  %t755 = getelementptr { i64, [5 x i64] }, ptr %t754, i32 0, i32 1
  %t756 = getelementptr { %"compiler/source:Span", ptr }, ptr %t755, i32 0, i32 1
  %t757 = load ptr, ptr %t756
  store ptr %t757, ptr %l396, !tbaa !29
  %t758 = load ptr, ptr %l396, !tbaa !29
  store ptr %t758, ptr %l48, !tbaa !29
  br label %bb241
bb240:
  br label %bb260
bb241:
  store %olang.scope zeroinitializer, ptr %s30
  %t759 = load ptr, ptr %l0, !tbaa !29
  store ptr %t759, ptr %l397, !tbaa !29
  %t760 = load ptr, ptr %l48, !tbaa !29
  store ptr %t760, ptr %l398, !tbaa !29
  %t761 = load ptr, ptr %l398, !tbaa !29
  %t762 = getelementptr %"compiler/ast:Compr", ptr %t761, i32 0, i32 0
  %t763 = load ptr, ptr %t762, !tbaa !29
  store ptr %t763, ptr %l399, !tbaa !29
  %t764 = load ptr, ptr %l397, !tbaa !29
  %t765 = load ptr, ptr %l399, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t764, ptr %t765)
  br label %bb242
bb242:
  %t766 = load ptr, ptr %l0, !tbaa !29
  store ptr %t766, ptr %l400, !tbaa !29
  %t767 = load ptr, ptr %l400, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t767, { i64, ptr } { i64 1, ptr @.d57 })
  br label %bb243
bb243:
  %t768 = load ptr, ptr %l0, !tbaa !29
  store ptr %t768, ptr %l401, !tbaa !29
  %t769 = load ptr, ptr %l48, !tbaa !29
  store ptr %t769, ptr %l402, !tbaa !29
  %t770 = load ptr, ptr %l402, !tbaa !29
  %t771 = getelementptr %"compiler/ast:Compr", ptr %t770, i32 0, i32 1
  %t772 = load ptr, ptr %t771, !tbaa !29
  store ptr %t772, ptr %l403, !tbaa !29
  %t773 = load ptr, ptr %l401, !tbaa !29
  %t774 = load ptr, ptr %l403, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t773, ptr %t774)
  br label %bb244
bb244:
  %t775 = load ptr, ptr %l0, !tbaa !29
  store ptr %t775, ptr %l404, !tbaa !29
  %t776 = load ptr, ptr %l404, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t776, { i64, ptr } { i64 5, ptr @.d58 })
  br label %bb245
bb245:
  %t777 = load ptr, ptr %l48, !tbaa !29
  store ptr %t777, ptr %l405, !tbaa !29
  %t778 = load ptr, ptr %l405, !tbaa !29
  %t779 = getelementptr %"compiler/ast:Compr", ptr %t778, i32 0, i32 2
  %t780 = load i32, ptr %t779, !tbaa !23
  store i32 %t780, ptr %l406, !tbaa !23
  %t781 = load i32, ptr %l406, !tbaa !23
  %t782 = icmp ne i32 %t781, 0
  store i1 %t782, ptr %l407, !tbaa !21
  %t783 = load i1, ptr %l407, !tbaa !21
  br i1 %t783, label %bb246, label %bb247
bb246:
  store %olang.scope zeroinitializer, ptr %s31
  %t784 = load ptr, ptr %l0, !tbaa !29
  store ptr %t784, ptr %l408, !tbaa !29
  %t785 = load ptr, ptr %l48, !tbaa !29
  store ptr %t785, ptr %l409, !tbaa !29
  %t786 = load ptr, ptr %l409, !tbaa !29
  %t787 = getelementptr %"compiler/ast:Compr", ptr %t786, i32 0, i32 2
  %t788 = load i32, ptr %t787, !tbaa !23
  store i32 %t788, ptr %l410, !tbaa !23
  %t789 = load ptr, ptr %l408, !tbaa !29
  %t790 = load i32, ptr %l410, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t789, i32 %t790)
  br label %bb248
bb247:
  br label %bb250
bb248:
  %t791 = load ptr, ptr %l0, !tbaa !29
  store ptr %t791, ptr %l411, !tbaa !29
  %t792 = load ptr, ptr %l411, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t792, { i64, ptr } { i64 2, ptr @.d59 })
  br label %bb249
bb249:
  call void @__olang_scope_close(ptr %s31)
  br label %bb250
bb250:
  %t793 = load ptr, ptr %l0, !tbaa !29
  store ptr %t793, ptr %l412, !tbaa !29
  %t794 = load ptr, ptr %l48, !tbaa !29
  store ptr %t794, ptr %l413, !tbaa !29
  %t795 = load ptr, ptr %l413, !tbaa !29
  %t796 = getelementptr %"compiler/ast:Compr", ptr %t795, i32 0, i32 3
  %t797 = load i32, ptr %t796, !tbaa !23
  store i32 %t797, ptr %l414, !tbaa !23
  %t798 = load ptr, ptr %l412, !tbaa !29
  %t799 = load i32, ptr %l414, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t798, i32 %t799)
  br label %bb251
bb251:
  %t800 = load ptr, ptr %l0, !tbaa !29
  store ptr %t800, ptr %l415, !tbaa !29
  %t801 = load ptr, ptr %l415, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t801, { i64, ptr } { i64 4, ptr @.d60 })
  br label %bb252
bb252:
  %t802 = load ptr, ptr %l0, !tbaa !29
  store ptr %t802, ptr %l416, !tbaa !29
  %t803 = load ptr, ptr %l48, !tbaa !29
  store ptr %t803, ptr %l417, !tbaa !29
  %t804 = load ptr, ptr %l417, !tbaa !29
  %t805 = getelementptr %"compiler/ast:Compr", ptr %t804, i32 0, i32 4
  %t806 = load ptr, ptr %t805, !tbaa !29
  store ptr %t806, ptr %l418, !tbaa !29
  %t807 = load ptr, ptr %l416, !tbaa !29
  %t808 = load ptr, ptr %l418, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t807, ptr %t808)
  br label %bb253
bb253:
  %t809 = load ptr, ptr %l48, !tbaa !29
  store ptr %t809, ptr %l419, !tbaa !29
  %t810 = load ptr, ptr %l419, !tbaa !29
  %t811 = getelementptr %"compiler/ast:Compr", ptr %t810, i32 0, i32 5
  %t812 = load ptr, ptr %t811, !tbaa !29
  store ptr %t812, ptr %l420, !tbaa !29
  %t813 = load ptr, ptr %l420, !tbaa !29
  %t814 = icmp ne ptr %t813, null
  store i1 %t814, ptr %l421, !tbaa !21
  %t815 = load i1, ptr %l421, !tbaa !21
  br i1 %t815, label %bb254, label %bb255
bb254:
  store %olang.scope zeroinitializer, ptr %s32
  %t816 = load ptr, ptr %l0, !tbaa !29
  store ptr %t816, ptr %l422, !tbaa !29
  %t817 = load ptr, ptr %l422, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s32, ptr %t817, { i64, ptr } { i64 4, ptr @.d61 })
  br label %bb256
bb255:
  br label %bb258
bb256:
  %t818 = load ptr, ptr %l0, !tbaa !29
  store ptr %t818, ptr %l423, !tbaa !29
  %t819 = load ptr, ptr %l48, !tbaa !29
  store ptr %t819, ptr %l424, !tbaa !29
  %t820 = load ptr, ptr %l424, !tbaa !29
  %t821 = getelementptr %"compiler/ast:Compr", ptr %t820, i32 0, i32 5
  %t822 = load ptr, ptr %t821, !tbaa !29
  store ptr %t822, ptr %l425, !tbaa !29
  %t823 = load ptr, ptr %l423, !tbaa !29
  %t824 = load ptr, ptr %l425, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t823, ptr %t824)
  br label %bb257
bb257:
  call void @__olang_scope_close(ptr %s32)
  br label %bb258
bb258:
  %t825 = load ptr, ptr %l0, !tbaa !29
  store ptr %t825, ptr %l426, !tbaa !29
  %t826 = load ptr, ptr %l426, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t826, { i64, ptr } { i64 1, ptr @.d62 })
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s30)
  br label %bb322
bb260:
  %t827 = load ptr, ptr %l1, !tbaa !29
  store ptr %t827, ptr %l427, !tbaa !29
  store i1 false, ptr %l428, !tbaa !21
  %t828 = load ptr, ptr %l427, !tbaa !29
  %t829 = icmp ne ptr %t828, null
  store i1 %t829, ptr %l429, !tbaa !21
  %t830 = load i1, ptr %l429, !tbaa !21
  br i1 %t830, label %bb261, label %bb262
bb261:
  %t831 = load ptr, ptr %l427, !tbaa !29
  %t832 = load i64, ptr %t831
  store i64 %t832, ptr %l430, !tbaa !24
  %t833 = load i64, ptr %l430, !tbaa !24
  %t834 = icmp eq i64 %t833, 21
  store i1 %t834, ptr %l428, !tbaa !21
  br label %bb262
bb262:
  %t835 = load i1, ptr %l428, !tbaa !21
  br i1 %t835, label %bb263, label %bb264
bb263:
  %t836 = load ptr, ptr %l1, !tbaa !29
  store ptr %t836, ptr %l431, !tbaa !29
  %t837 = load ptr, ptr %l431, !tbaa !29
  %t838 = getelementptr { i64, [5 x i64] }, ptr %t837, i32 0, i32 1
  %t839 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t838, i32 0, i32 1
  %t840 = load { i64, ptr }, ptr %t839
  store { i64, ptr } %t840, ptr %l432, !tbaa !27
  %t841 = load { i64, ptr }, ptr %l432, !tbaa !27
  store { i64, ptr } %t841, ptr %l49, !tbaa !27
  br label %bb265
bb264:
  br label %bb277
bb265:
  store %olang.scope zeroinitializer, ptr %s33
  store %olang.scope zeroinitializer, ptr %s34
  %t842 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t842, ptr %l433, !tbaa !27
  %t843 = load { i64, ptr }, ptr %l433, !tbaa !27
  store { i64, ptr } %t843, ptr %l50, !tbaa !27
  store i64 0, ptr %l51, !tbaa !24
  %t844 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t844, ptr %l434, !tbaa !27
  %t845 = load { i64, ptr }, ptr %l434, !tbaa !27
  %t846 = extractvalue { i64, ptr } %t845, 0
  store i64 %t846, ptr %l435, !tbaa !24
  %t847 = load i64, ptr %l435, !tbaa !24
  store i64 %t847, ptr %l52, !tbaa !24
  br label %bb266
bb266:
  store %olang.scope zeroinitializer, ptr %s35
  %t848 = load i64, ptr %l51, !tbaa !24
  store i64 %t848, ptr %l436, !tbaa !24
  %t849 = load i64, ptr %l52, !tbaa !24
  store i64 %t849, ptr %l437, !tbaa !24
  %t850 = load i64, ptr %l436, !tbaa !24
  %t851 = load i64, ptr %l437, !tbaa !24
  %t852 = icmp slt i64 %t850, %t851
  store i1 %t852, ptr %l438, !tbaa !21
  %t853 = load i1, ptr %l438, !tbaa !21
  %t854 = xor i1 %t853, true
  store i1 %t854, ptr %l439, !tbaa !21
  %t855 = load i1, ptr %l439, !tbaa !21
  br i1 %t855, label %bb267, label %bb268
bb267:
  call void @__olang_scope_close(ptr %s35)
  br label %bb276
bb268:
  br label %bb269
bb269:
  %t856 = load i64, ptr %l51, !tbaa !24
  store i64 %t856, ptr %l440, !tbaa !24
  %t857 = load i64, ptr %l440, !tbaa !24
  store i64 %t857, ptr %l53, !tbaa !24
  %t858 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t858, ptr %l441, !tbaa !27
  %t859 = load i64, ptr %l51, !tbaa !24
  store i64 %t859, ptr %l442, !tbaa !24
  %t860 = load i64, ptr %l442, !tbaa !24
  %t861 = getelementptr { i64, ptr }, ptr %l441, i32 0, i32 1
  %t862 = load ptr, ptr %t861, !tbaa !27
  %t863 = getelementptr ptr, ptr %t862, i64 %t860
  %t864 = load ptr, ptr %t863, !tbaa !39
  store ptr %t864, ptr %l443, !tbaa !29
  %t865 = load ptr, ptr %l443, !tbaa !29
  store ptr %t865, ptr %l54, !tbaa !29
  %t866 = load i64, ptr %l53, !tbaa !24
  store i64 %t866, ptr %l444, !tbaa !24
  %t867 = load i64, ptr %l444, !tbaa !24
  %t868 = icmp sgt i64 %t867, 0
  store i1 %t868, ptr %l445, !tbaa !21
  %t869 = load i1, ptr %l445, !tbaa !21
  br i1 %t869, label %bb270, label %bb271
bb270:
  store %olang.scope zeroinitializer, ptr %s36
  %t870 = load ptr, ptr %l0, !tbaa !29
  store ptr %t870, ptr %l446, !tbaa !29
  %t871 = load ptr, ptr %l446, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s36, ptr %t871, { i64, ptr } { i64 1, ptr @.d63 })
  br label %bb272
bb271:
  br label %bb273
bb272:
  call void @__olang_scope_close(ptr %s36)
  br label %bb273
bb273:
  %t872 = load ptr, ptr %l0, !tbaa !29
  store ptr %t872, ptr %l447, !tbaa !29
  %t873 = load ptr, ptr %l54, !tbaa !29
  store ptr %t873, ptr %l448, !tbaa !29
  %t874 = load ptr, ptr %l447, !tbaa !29
  %t875 = load ptr, ptr %l448, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t874, ptr %t875)
  br label %bb274
bb274:
  call void @__olang_scope_close(ptr %s35)
  br label %bb275
bb275:
  store %olang.scope zeroinitializer, ptr %s37
  %t876 = load i64, ptr %l51, !tbaa !24
  store i64 %t876, ptr %l449, !tbaa !24
  %t877 = load i64, ptr %l449, !tbaa !24
  %t878 = add i64 %t877, 1
  store i64 %t878, ptr %l450, !tbaa !24
  %t879 = load i64, ptr %l450, !tbaa !24
  store i64 %t879, ptr %l51, !tbaa !24
  call void @__olang_scope_close(ptr %s37)
  br label %bb266
bb276:
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s33)
  br label %bb322
bb277:
  %t880 = load ptr, ptr %l1, !tbaa !29
  store ptr %t880, ptr %l451, !tbaa !29
  store i1 false, ptr %l452, !tbaa !21
  %t881 = load ptr, ptr %l451, !tbaa !29
  %t882 = icmp ne ptr %t881, null
  store i1 %t882, ptr %l453, !tbaa !21
  %t883 = load i1, ptr %l453, !tbaa !21
  br i1 %t883, label %bb278, label %bb279
bb278:
  %t884 = load ptr, ptr %l451, !tbaa !29
  %t885 = load i64, ptr %t884
  store i64 %t885, ptr %l454, !tbaa !24
  %t886 = load i64, ptr %l454, !tbaa !24
  %t887 = icmp eq i64 %t886, 22
  store i1 %t887, ptr %l452, !tbaa !21
  br label %bb279
bb279:
  %t888 = load i1, ptr %l452, !tbaa !21
  br i1 %t888, label %bb280, label %bb281
bb280:
  %t889 = load ptr, ptr %l1, !tbaa !29
  store ptr %t889, ptr %l455, !tbaa !29
  %t890 = load ptr, ptr %l455, !tbaa !29
  %t891 = getelementptr { i64, [5 x i64] }, ptr %t890, i32 0, i32 1
  %t892 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t891, i32 0, i32 1
  %t893 = load ptr, ptr %t892
  store ptr %t893, ptr %l456, !tbaa !29
  %t894 = load ptr, ptr %l456, !tbaa !29
  store ptr %t894, ptr %l55, !tbaa !29
  %t895 = load ptr, ptr %l1, !tbaa !29
  store ptr %t895, ptr %l457, !tbaa !29
  %t896 = load ptr, ptr %l457, !tbaa !29
  %t897 = getelementptr { i64, [5 x i64] }, ptr %t896, i32 0, i32 1
  %t898 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t897, i32 0, i32 2
  %t899 = load { i64, ptr }, ptr %t898
  store { i64, ptr } %t899, ptr %l458, !tbaa !27
  %t900 = load { i64, ptr }, ptr %l458, !tbaa !27
  store { i64, ptr } %t900, ptr %l56, !tbaa !27
  %t901 = load ptr, ptr %l1, !tbaa !29
  store ptr %t901, ptr %l459, !tbaa !29
  %t902 = load ptr, ptr %l459, !tbaa !29
  %t903 = getelementptr { i64, [5 x i64] }, ptr %t902, i32 0, i32 1
  %t904 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t903, i32 0, i32 3
  %t905 = load i1, ptr %t904
  store i1 %t905, ptr %l460, !tbaa !21
  %t906 = load i1, ptr %l460, !tbaa !21
  store i1 %t906, ptr %l57, !tbaa !21
  br label %bb282
bb281:
  br label %bb289
bb282:
  store %olang.scope zeroinitializer, ptr %s38
  %t907 = load ptr, ptr %l0, !tbaa !29
  store ptr %t907, ptr %l461, !tbaa !29
  %t908 = load i1, ptr %l57, !tbaa !21
  store i1 %t908, ptr %l462, !tbaa !21
  %t909 = load i1, ptr %l462, !tbaa !21
  br i1 %t909, label %bb283, label %bb284
bb283:
  store { i64, ptr } { i64 8, ptr @.d64 }, ptr %l463, !tbaa !27
  br label %bb285
bb284:
  store { i64, ptr } { i64 4, ptr @.d65 }, ptr %l463, !tbaa !27
  br label %bb285
bb285:
  %t910 = load ptr, ptr %l461, !tbaa !29
  %t911 = load { i64, ptr }, ptr %l463, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s38, ptr %t910, { i64, ptr } %t911)
  br label %bb286
bb286:
  %t912 = load ptr, ptr %l0, !tbaa !29
  store ptr %t912, ptr %l464, !tbaa !29
  %t913 = load ptr, ptr %l55, !tbaa !29
  store ptr %t913, ptr %l465, !tbaa !29
  %t914 = load ptr, ptr %l464, !tbaa !29
  %t915 = load ptr, ptr %l465, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t914, ptr %t915)
  br label %bb287
bb287:
  %t916 = load ptr, ptr %l0, !tbaa !29
  store ptr %t916, ptr %l466, !tbaa !29
  %t917 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t917, ptr %l467, !tbaa !27
  %t918 = load ptr, ptr %l466, !tbaa !29
  %t919 = load { i64, ptr }, ptr %l467, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t918, { i64, ptr } %t919)
  br label %bb288
bb288:
  call void @__olang_scope_close(ptr %s38)
  br label %bb322
bb289:
  %t920 = load ptr, ptr %l1, !tbaa !29
  store ptr %t920, ptr %l468, !tbaa !29
  store i1 false, ptr %l469, !tbaa !21
  %t921 = load ptr, ptr %l468, !tbaa !29
  %t922 = icmp ne ptr %t921, null
  store i1 %t922, ptr %l470, !tbaa !21
  %t923 = load i1, ptr %l470, !tbaa !21
  br i1 %t923, label %bb290, label %bb291
bb290:
  %t924 = load ptr, ptr %l468, !tbaa !29
  %t925 = load i64, ptr %t924
  store i64 %t925, ptr %l471, !tbaa !24
  %t926 = load i64, ptr %l471, !tbaa !24
  %t927 = icmp eq i64 %t926, 23
  store i1 %t927, ptr %l469, !tbaa !21
  br label %bb291
bb291:
  %t928 = load i1, ptr %l469, !tbaa !21
  br i1 %t928, label %bb292, label %bb293
bb292:
  %t929 = load ptr, ptr %l1, !tbaa !29
  store ptr %t929, ptr %l472, !tbaa !29
  %t930 = load ptr, ptr %l472, !tbaa !29
  %t931 = getelementptr { i64, [5 x i64] }, ptr %t930, i32 0, i32 1
  %t932 = getelementptr { %"compiler/source:Span", ptr }, ptr %t931, i32 0, i32 1
  %t933 = load ptr, ptr %t932
  store ptr %t933, ptr %l473, !tbaa !29
  %t934 = load ptr, ptr %l473, !tbaa !29
  store ptr %t934, ptr %l58, !tbaa !29
  br label %bb294
bb293:
  br label %bb299
bb294:
  store %olang.scope zeroinitializer, ptr %s39
  %t935 = load ptr, ptr %l0, !tbaa !29
  store ptr %t935, ptr %l474, !tbaa !29
  %t936 = load ptr, ptr %l474, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s39, ptr %t936, { i64, ptr } { i64 2, ptr @.d66 })
  br label %bb295
bb295:
  %t937 = load ptr, ptr %l0, !tbaa !29
  store ptr %t937, ptr %l475, !tbaa !29
  %t938 = load ptr, ptr %l58, !tbaa !29
  store ptr %t938, ptr %l476, !tbaa !29
  %t939 = load ptr, ptr %l476, !tbaa !29
  %t940 = getelementptr %"compiler/ast:Func", ptr %t939, i32 0, i32 3
  %t941 = load ptr, ptr %t940, !tbaa !29
  store ptr %t941, ptr %l477, !tbaa !29
  %t942 = load ptr, ptr %l475, !tbaa !29
  %t943 = load ptr, ptr %l477, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t942, ptr %t943, i1 true)
  br label %bb296
bb296:
  %t944 = load ptr, ptr %l0, !tbaa !29
  store ptr %t944, ptr %l478, !tbaa !29
  %t945 = load ptr, ptr %l478, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s39, ptr %t945, { i64, ptr } { i64 1, ptr @.d67 })
  br label %bb297
bb297:
  %t946 = load ptr, ptr %l0, !tbaa !29
  store ptr %t946, ptr %l479, !tbaa !29
  %t947 = load ptr, ptr %l58, !tbaa !29
  store ptr %t947, ptr %l480, !tbaa !29
  %t948 = load ptr, ptr %l480, !tbaa !29
  %t949 = getelementptr %"compiler/ast:Func", ptr %t948, i32 0, i32 4
  %t950 = load { i64, ptr }, ptr %t949, !tbaa !27
  store { i64, ptr } %t950, ptr %l481, !tbaa !27
  %t951 = load ptr, ptr %l479, !tbaa !29
  %t952 = load { i64, ptr }, ptr %l481, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t951, { i64, ptr } %t952)
  br label %bb298
bb298:
  call void @__olang_scope_close(ptr %s39)
  br label %bb322
bb299:
  %t953 = load ptr, ptr %l1, !tbaa !29
  store ptr %t953, ptr %l482, !tbaa !29
  store i1 false, ptr %l483, !tbaa !21
  %t954 = load ptr, ptr %l482, !tbaa !29
  %t955 = icmp ne ptr %t954, null
  store i1 %t955, ptr %l484, !tbaa !21
  %t956 = load i1, ptr %l484, !tbaa !21
  br i1 %t956, label %bb300, label %bb301
bb300:
  %t957 = load ptr, ptr %l482, !tbaa !29
  %t958 = load i64, ptr %t957
  store i64 %t958, ptr %l485, !tbaa !24
  %t959 = load i64, ptr %l485, !tbaa !24
  %t960 = icmp eq i64 %t959, 24
  store i1 %t960, ptr %l483, !tbaa !21
  br label %bb301
bb301:
  %t961 = load i1, ptr %l483, !tbaa !21
  br i1 %t961, label %bb302, label %bb303
bb302:
  %t962 = load ptr, ptr %l1, !tbaa !29
  store ptr %t962, ptr %l486, !tbaa !29
  %t963 = load ptr, ptr %l486, !tbaa !29
  %t964 = getelementptr { i64, [5 x i64] }, ptr %t963, i32 0, i32 1
  %t965 = getelementptr { %"compiler/source:Span", ptr }, ptr %t964, i32 0, i32 1
  %t966 = load ptr, ptr %t965
  store ptr %t966, ptr %l487, !tbaa !29
  %t967 = load ptr, ptr %l487, !tbaa !29
  store ptr %t967, ptr %l59, !tbaa !29
  br label %bb304
bb303:
  br label %bb306
bb304:
  store %olang.scope zeroinitializer, ptr %s40
  %t968 = load ptr, ptr %l0, !tbaa !29
  store ptr %t968, ptr %l488, !tbaa !29
  %t969 = load ptr, ptr %l59, !tbaa !29
  store ptr %t969, ptr %l489, !tbaa !29
  %t970 = load ptr, ptr %l488, !tbaa !29
  %t971 = load ptr, ptr %l489, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t970, ptr %t971)
  br label %bb305
bb305:
  call void @__olang_scope_close(ptr %s40)
  br label %bb322
bb306:
  %t972 = load ptr, ptr %l1, !tbaa !29
  store ptr %t972, ptr %l490, !tbaa !29
  store i1 false, ptr %l491, !tbaa !21
  %t973 = load ptr, ptr %l490, !tbaa !29
  %t974 = icmp ne ptr %t973, null
  store i1 %t974, ptr %l492, !tbaa !21
  %t975 = load i1, ptr %l492, !tbaa !21
  br i1 %t975, label %bb307, label %bb308
bb307:
  %t976 = load ptr, ptr %l490, !tbaa !29
  %t977 = load i64, ptr %t976
  store i64 %t977, ptr %l493, !tbaa !24
  %t978 = load i64, ptr %l493, !tbaa !24
  %t979 = icmp eq i64 %t978, 25
  store i1 %t979, ptr %l491, !tbaa !21
  br label %bb308
bb308:
  %t980 = load i1, ptr %l491, !tbaa !21
  br i1 %t980, label %bb309, label %bb310
bb309:
  %t981 = load ptr, ptr %l1, !tbaa !29
  store ptr %t981, ptr %l494, !tbaa !29
  %t982 = load ptr, ptr %l494, !tbaa !29
  %t983 = getelementptr { i64, [5 x i64] }, ptr %t982, i32 0, i32 1
  %t984 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t983, i32 0, i32 1
  %t985 = load { i64, ptr }, ptr %t984
  store { i64, ptr } %t985, ptr %l495, !tbaa !27
  %t986 = load { i64, ptr }, ptr %l495, !tbaa !27
  store { i64, ptr } %t986, ptr %l60, !tbaa !27
  br label %bb311
bb310:
  br label %bb314
bb311:
  store %olang.scope zeroinitializer, ptr %s41
  %t987 = load ptr, ptr %l0, !tbaa !29
  store ptr %t987, ptr %l496, !tbaa !29
  %t988 = load ptr, ptr %l496, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s41, ptr %t988, { i64, ptr } { i64 6, ptr @.d68 })
  br label %bb312
bb312:
  %t989 = load ptr, ptr %l0, !tbaa !29
  store ptr %t989, ptr %l497, !tbaa !29
  %t990 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t990, ptr %l498, !tbaa !27
  %t991 = load ptr, ptr %l497, !tbaa !29
  %t992 = load { i64, ptr }, ptr %l498, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t991, { i64, ptr } %t992)
  br label %bb313
bb313:
  call void @__olang_scope_close(ptr %s41)
  br label %bb322
bb314:
  %t993 = load ptr, ptr %l1, !tbaa !29
  store ptr %t993, ptr %l499, !tbaa !29
  store i1 false, ptr %l500, !tbaa !21
  %t994 = load ptr, ptr %l499, !tbaa !29
  %t995 = icmp ne ptr %t994, null
  store i1 %t995, ptr %l501, !tbaa !21
  %t996 = load i1, ptr %l501, !tbaa !21
  br i1 %t996, label %bb315, label %bb316
bb315:
  %t997 = load ptr, ptr %l499, !tbaa !29
  %t998 = load i64, ptr %t997
  store i64 %t998, ptr %l502, !tbaa !24
  %t999 = load i64, ptr %l502, !tbaa !24
  %t1000 = icmp eq i64 %t999, 26
  store i1 %t1000, ptr %l500, !tbaa !21
  br label %bb316
bb316:
  %t1001 = load i1, ptr %l500, !tbaa !21
  br i1 %t1001, label %bb317, label %bb318
bb317:
  br label %bb319
bb318:
  br label %bb321
bb319:
  store %olang.scope zeroinitializer, ptr %s42
  %t1002 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1002, ptr %l503, !tbaa !29
  %t1003 = load ptr, ptr %l503, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s42, ptr %t1003, { i64, ptr } { i64 7, ptr @.d69 })
  br label %bb320
bb320:
  call void @__olang_scope_close(ptr %s42)
  br label %bb322
bb321:
  call void @__olang_check_failed(ptr @.c70)
  unreachable
bb322:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t3, ptr %l8, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l11, !tbaa !24
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l11, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l12, !tbaa !21
  %t12 = load i1, ptr %l12, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l13, !tbaa !21
  %t14 = load i1, ptr %l13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l14, !tbaa !24
  %t16 = load i64, ptr %l14, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l16, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t19
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load ptr, ptr %l17, !tbaa !29
  store ptr %t24, ptr %l6, !tbaa !29
  %t25 = load i64, ptr %l5, !tbaa !24
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = icmp sgt i64 %t26, 0
  store i1 %t27, ptr %l19, !tbaa !21
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  %t30 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t30, { i64, ptr } { i64 2, ptr @.d71 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t35 = load i64, ptr %l3, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  %t36 = load i64, ptr %l23, !tbaa !24
  %t37 = add i64 %t36, 1
  store i64 %t37, ptr %l24, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb1
bb11:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t2, { i64, ptr } { i64 3, ptr @.d72 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l1, !tbaa !29
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t5 = getelementptr %"compiler/ast:Func", ptr %t4, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  store i1 %t8, ptr %l5, !tbaa !21
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t11, { i64, ptr } { i64 1, ptr @.d73 })
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Func", ptr %t14, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t18 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  %t20 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t20, { i64, ptr } { i64 2, ptr @.d74 })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l11, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Func", ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24, !tbaa !23
  store i32 %t25, ptr %l13, !tbaa !23
  %t26 = load ptr, ptr %l11, !tbaa !29
  %t27 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t26, i32 %t27)
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l14, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l15, !tbaa !29
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t30, i32 0, i32 5
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load ptr, ptr %l14, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t33, { i64, ptr } %t34)
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l17, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l18, !tbaa !29
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Func", ptr %t37, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l19, !tbaa !29
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t40, ptr %t41, i1 false)
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l20, !tbaa !29
  %t43 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t43, { i64, ptr } { i64 1, ptr @.d75 })
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l21, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l22, !tbaa !29
  %t46 = load ptr, ptr %l22, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t46, i32 0, i32 4
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l23, !tbaa !27
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t49, { i64, ptr } %t50)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t2, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = icmp eq ptr %t5, null
  store i1 %t6, ptr %l4, !tbaa !21
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = getelementptr %"compiler/ast:If", ptr %t10, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t14 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t16, { i64, ptr } { i64 3, ptr @.d76 })
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l9, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load ptr, ptr %l10, !tbaa !29
  %t20 = getelementptr %"compiler/ast:If", ptr %t19, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l11, !tbaa !29
  %t22 = load ptr, ptr %l9, !tbaa !29
  %t23 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l12, !tbaa !29
  %t25 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t25, { i64, ptr } { i64 1, ptr @.d77 })
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l13, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l14, !tbaa !29
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = getelementptr %"compiler/ast:If", ptr %t28, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l15, !tbaa !29
  %t31 = load ptr, ptr %l13, !tbaa !29
  %t32 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l16, !tbaa !29
  %t34 = load ptr, ptr %l16, !tbaa !29
  %t35 = getelementptr %"compiler/ast:If", ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  store i1 %t38, ptr %l18, !tbaa !21
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l19, !tbaa !29
  %t41 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t41, { i64, ptr } { i64 6, ptr @.d78 })
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l20, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l21, !tbaa !29
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = getelementptr %"compiler/ast:If", ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  %t47 = load ptr, ptr %l20, !tbaa !29
  %t48 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  %t2 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t2, { i64, ptr } { i64 6, ptr @.d79 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l17, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  store ptr %t4, ptr %l18, !tbaa !29
  %t5 = load ptr, ptr %l18, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Match", ptr %t5, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l19, !tbaa !29
  %t8 = load ptr, ptr %l17, !tbaa !29
  %t9 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l20, !tbaa !29
  %t11 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t11, { i64, ptr } { i64 2, ptr @.d80 })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l21, !tbaa !29
  %t13 = load ptr, ptr %l21, !tbaa !29
  %t14 = getelementptr %"compiler/unparse:writer", ptr %t13, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l22, !tbaa !24
  %t16 = load i64, ptr %l22, !tbaa !24
  %t17 = add i64 %t16, 1
  store i64 %t17, ptr %l23, !tbaa !24
  %t18 = load i64, ptr %l23, !tbaa !24
  %t19 = load ptr, ptr %l21, !tbaa !29
  %t20 = getelementptr %"compiler/unparse:writer", ptr %t19, i32 0, i32 4
  store i64 %t18, ptr %t20, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l24, !tbaa !29
  %t22 = load ptr, ptr %l24, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Match", ptr %t22, i32 0, i32 3
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l25, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t25, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l26, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l27, !tbaa !24
  %t29 = load i64, ptr %l27, !tbaa !24
  store i64 %t29, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l28, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l29, !tbaa !24
  %t32 = load i64, ptr %l28, !tbaa !24
  %t33 = load i64, ptr %l29, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  store i1 %t34, ptr %l30, !tbaa !21
  %t35 = load i1, ptr %l30, !tbaa !21
  %t36 = xor i1 %t35, true
  store i1 %t36, ptr %l31, !tbaa !21
  %t37 = load i1, ptr %l31, !tbaa !21
  br i1 %t37, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb6:
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l32, !tbaa !27
  %t39 = load i64, ptr %l3, !tbaa !24
  store i64 %t39, ptr %l33, !tbaa !24
  %t40 = load i64, ptr %l33, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t40
  %t44 = load ptr, ptr %t43, !tbaa !39
  store ptr %t44, ptr %l34, !tbaa !29
  %t45 = load ptr, ptr %l34, !tbaa !29
  store ptr %t45, ptr %l5, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l35, !tbaa !29
  %t47 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t47)
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l36, !tbaa !29
  %t49 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t49, { i64, ptr } { i64 5, ptr @.d81 })
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l5, !tbaa !29
  store ptr %t50, ptr %l37, !tbaa !29
  %t51 = load ptr, ptr %l37, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Case", ptr %t51, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l38, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t54, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l39, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l40, !tbaa !24
  %t58 = load i64, ptr %l40, !tbaa !24
  store i64 %t58, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load i64, ptr %l7, !tbaa !24
  store i64 %t59, ptr %l41, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  store i64 %t60, ptr %l42, !tbaa !24
  %t61 = load i64, ptr %l41, !tbaa !24
  %t62 = load i64, ptr %l42, !tbaa !24
  %t63 = icmp slt i64 %t61, %t62
  store i1 %t63, ptr %l43, !tbaa !21
  %t64 = load i1, ptr %l43, !tbaa !21
  %t65 = xor i1 %t64, true
  store i1 %t65, ptr %l44, !tbaa !21
  %t66 = load i1, ptr %l44, !tbaa !21
  br i1 %t66, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  store i64 %t67, ptr %l45, !tbaa !24
  %t68 = load i64, ptr %l45, !tbaa !24
  store i64 %t68, ptr %l9, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l46, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  store i64 %t70, ptr %l47, !tbaa !24
  %t71 = load i64, ptr %l47, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t71
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l48, !tbaa !29
  %t76 = load ptr, ptr %l48, !tbaa !29
  store ptr %t76, ptr %l10, !tbaa !29
  %t77 = load i64, ptr %l9, !tbaa !24
  store i64 %t77, ptr %l49, !tbaa !24
  %t78 = load i64, ptr %l49, !tbaa !24
  %t79 = icmp sgt i64 %t78, 0
  store i1 %t79, ptr %l50, !tbaa !21
  %t80 = load i1, ptr %l50, !tbaa !21
  br i1 %t80, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l51, !tbaa !29
  %t82 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t82, { i64, ptr } { i64 2, ptr @.d82 })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l52, !tbaa !29
  %t84 = load ptr, ptr %l10, !tbaa !29
  store ptr %t84, ptr %l53, !tbaa !29
  %t85 = load ptr, ptr %l52, !tbaa !29
  %t86 = load ptr, ptr %l53, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t87 = load i64, ptr %l7, !tbaa !24
  store i64 %t87, ptr %l54, !tbaa !24
  %t88 = load i64, ptr %l54, !tbaa !24
  %t89 = add i64 %t88, 1
  store i64 %t89, ptr %l55, !tbaa !24
  %t90 = load i64, ptr %l55, !tbaa !24
  store i64 %t90, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb10
bb20:
  call void @__olang_scope_close(ptr %s3)
  store %olang.scope zeroinitializer, ptr %s7
  %t91 = load ptr, ptr %l5, !tbaa !29
  store ptr %t91, ptr %l56, !tbaa !29
  %t92 = load ptr, ptr %l56, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Case", ptr %t92, i32 0, i32 2
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l57, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t95, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t96, ptr %l58, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l59, !tbaa !24
  %t99 = load i64, ptr %l59, !tbaa !24
  store i64 %t99, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t100 = load i64, ptr %l12, !tbaa !24
  store i64 %t100, ptr %l60, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  store i64 %t101, ptr %l61, !tbaa !24
  %t102 = load i64, ptr %l60, !tbaa !24
  %t103 = load i64, ptr %l61, !tbaa !24
  %t104 = icmp slt i64 %t102, %t103
  store i1 %t104, ptr %l62, !tbaa !21
  %t105 = load i1, ptr %l62, !tbaa !21
  %t106 = xor i1 %t105, true
  store i1 %t106, ptr %l63, !tbaa !21
  %t107 = load i1, ptr %l63, !tbaa !21
  br i1 %t107, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l12, !tbaa !24
  store i64 %t108, ptr %l64, !tbaa !24
  %t109 = load i64, ptr %l64, !tbaa !24
  store i64 %t109, ptr %l14, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t110, ptr %l65, !tbaa !27
  %t111 = load i64, ptr %l12, !tbaa !24
  store i64 %t111, ptr %l66, !tbaa !24
  %t112 = load i64, ptr %l66, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr ptr, ptr %t114, i64 %t112
  %t116 = load ptr, ptr %t115, !tbaa !39
  store ptr %t116, ptr %l67, !tbaa !29
  %t117 = load ptr, ptr %l67, !tbaa !29
  store ptr %t117, ptr %l15, !tbaa !29
  %t118 = load i64, ptr %l14, !tbaa !24
  store i64 %t118, ptr %l68, !tbaa !24
  %t119 = load i64, ptr %l68, !tbaa !24
  %t120 = icmp sgt i64 %t119, 0
  store i1 %t120, ptr %l69, !tbaa !21
  %t121 = load i1, ptr %l69, !tbaa !21
  br i1 %t121, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l70, !tbaa !29
  %t123 = load ptr, ptr %l70, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t123, { i64, ptr } { i64 2, ptr @.d83 })
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb28:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l71, !tbaa !29
  %t125 = load ptr, ptr %l15, !tbaa !29
  store ptr %t125, ptr %l72, !tbaa !29
  %t126 = load ptr, ptr %l71, !tbaa !29
  %t127 = load ptr, ptr %l72, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t126, ptr %t127)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s10
  %t128 = load i64, ptr %l12, !tbaa !24
  store i64 %t128, ptr %l73, !tbaa !24
  %t129 = load i64, ptr %l73, !tbaa !24
  %t130 = add i64 %t129, 1
  store i64 %t130, ptr %l74, !tbaa !24
  %t131 = load i64, ptr %l74, !tbaa !24
  store i64 %t131, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb21
bb31:
  call void @__olang_scope_close(ptr %s7)
  %t132 = load ptr, ptr %l5, !tbaa !29
  store ptr %t132, ptr %l75, !tbaa !29
  %t133 = load ptr, ptr %l75, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Case", ptr %t133, i32 0, i32 3
  %t135 = load ptr, ptr %t134, !tbaa !29
  store ptr %t135, ptr %l76, !tbaa !29
  %t136 = load ptr, ptr %l76, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  store i1 %t137, ptr %l77, !tbaa !21
  %t138 = load i1, ptr %l77, !tbaa !21
  br i1 %t138, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s11
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l78, !tbaa !29
  %t140 = load ptr, ptr %l78, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t140, { i64, ptr } { i64 4, ptr @.d84 })
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l79, !tbaa !29
  %t142 = load ptr, ptr %l5, !tbaa !29
  store ptr %t142, ptr %l80, !tbaa !29
  %t143 = load ptr, ptr %l80, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Case", ptr %t143, i32 0, i32 3
  %t145 = load ptr, ptr %t144, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l79, !tbaa !29
  %t147 = load ptr, ptr %l81, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t146, ptr %t147)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s11)
  br label %bb36
bb36:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l82, !tbaa !29
  %t149 = load ptr, ptr %l5, !tbaa !29
  store ptr %t149, ptr %l83, !tbaa !29
  %t150 = load ptr, ptr %l82, !tbaa !29
  %t151 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %t150, ptr %t151)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s12
  %t152 = load i64, ptr %l3, !tbaa !24
  store i64 %t152, ptr %l84, !tbaa !24
  %t153 = load i64, ptr %l84, !tbaa !24
  %t154 = add i64 %t153, 1
  store i64 %t154, ptr %l85, !tbaa !24
  %t155 = load i64, ptr %l85, !tbaa !24
  store i64 %t155, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb4
bb39:
  call void @__olang_scope_close(ptr %s1)
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l86, !tbaa !29
  %t157 = load ptr, ptr %l86, !tbaa !29
  %t158 = getelementptr %"compiler/ast:Match", ptr %t157, i32 0, i32 4
  %t159 = load ptr, ptr %t158, !tbaa !29
  store ptr %t159, ptr %l87, !tbaa !29
  %t160 = load ptr, ptr %l87, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  store i1 %t161, ptr %l88, !tbaa !21
  %t162 = load i1, ptr %l88, !tbaa !21
  br i1 %t162, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s13
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l89, !tbaa !29
  %t164 = load ptr, ptr %l89, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t164)
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l90, !tbaa !29
  %t166 = load ptr, ptr %l90, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t166, { i64, ptr } { i64 7, ptr @.d85 })
  br label %bb43
bb43:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l91, !tbaa !29
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l92, !tbaa !29
  %t169 = load ptr, ptr %l92, !tbaa !29
  %t170 = getelementptr %"compiler/ast:Match", ptr %t169, i32 0, i32 4
  %t171 = load ptr, ptr %t170, !tbaa !29
  store ptr %t171, ptr %l93, !tbaa !29
  %t172 = load ptr, ptr %l91, !tbaa !29
  %t173 = load ptr, ptr %l93, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %t172, ptr %t173)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s13)
  br label %bb45
bb45:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l94, !tbaa !29
  %t175 = load ptr, ptr %l94, !tbaa !29
  %t176 = getelementptr %"compiler/unparse:writer", ptr %t175, i32 0, i32 4
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l95, !tbaa !24
  %t178 = load i64, ptr %l95, !tbaa !24
  %t179 = sub i64 %t178, 1
  store i64 %t179, ptr %l96, !tbaa !24
  %t180 = load i64, ptr %l96, !tbaa !24
  %t181 = load ptr, ptr %l94, !tbaa !29
  %t182 = getelementptr %"compiler/unparse:writer", ptr %t181, i32 0, i32 4
  store i64 %t180, ptr %t182, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l97, !tbaa !29
  %t184 = load ptr, ptr %l97, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t184)
  br label %bb46
bb46:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l98, !tbaa !29
  %t186 = load ptr, ptr %l98, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t186, { i64, ptr } { i64 1, ptr @.d86 })
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t2, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t5, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  store i32 %t8, ptr %l6, !tbaa !23
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i32, ptr %l6, !tbaa !23
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t9, i32 %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t12, { i64, ptr } %t13)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t2, i32 0, i32 3
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l8, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t4, i8 10)
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l10, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2funparse_2eMaxIndent, !tbaa !24
  store i64 %t9, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = load i64, ptr %l11, !tbaa !24
  %t12 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t10, i64 %t11)
  store i64 %t12, ptr %l12
  br label %bb2
bb2:
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l13, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l14, !tbaa !24
  %t16 = load i64, ptr %l13, !tbaa !24
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = icmp sgt i64 %t16, %t17
  store i1 %t18, ptr %l15, !tbaa !21
  %t19 = load i1, ptr %l15, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = icmp sgt i64 %t21, 0
  store i1 %t22, ptr %l18, !tbaa !21
  %t23 = load i1, ptr %l18, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb8
bb5:
  %t24 = load i64, ptr %l2, !tbaa !24
  store i64 %t24, ptr %l20, !tbaa !24
  %t25 = load i64, ptr %l1, !tbaa !24
  store i64 %t25, ptr %l21, !tbaa !24
  %t26 = load i64, ptr %l20, !tbaa !24
  %t27 = load i64, ptr %l21, !tbaa !24
  %t28 = sub i64 %t26, %t27
  store i64 %t28, ptr %l22, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  store i64 %t29, ptr %l23, !tbaa !24
  %t30 = load i64, ptr %l22, !tbaa !24
  %t31 = load i64, ptr %l23, !tbaa !24
  %t32 = add i64 %t30, %t31
  store i64 %t32, ptr %l24, !tbaa !24
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = sub i64 %t33, 1
  store i64 %t34, ptr %l25, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  store i64 %t35, ptr %l26, !tbaa !24
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = sdiv i64 %t36, %t37
  store i64 %t38, ptr %l27, !tbaa !24
  %t39 = load i64, ptr %l27, !tbaa !24
  store i64 %t39, ptr %l19, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l19, !tbaa !24
  store i64 %t40, ptr %l16, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l16, !tbaa !24
  store i64 %t41, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l5, !tbaa !24
  store i64 %t42, ptr %l28, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  store i64 %t43, ptr %l29, !tbaa !24
  %t44 = load i64, ptr %l28, !tbaa !24
  %t45 = load i64, ptr %l29, !tbaa !24
  %t46 = icmp slt i64 %t44, %t45
  store i1 %t46, ptr %l30, !tbaa !21
  %t47 = load i1, ptr %l30, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l31, !tbaa !21
  %t49 = load i1, ptr %l31, !tbaa !21
  br i1 %t49, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  store i64 %t51, ptr %l33, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  store i64 %t52, ptr %l34, !tbaa !24
  %t53 = load i64, ptr %l33, !tbaa !24
  %t54 = load i64, ptr %l34, !tbaa !24
  %t55 = mul i64 %t53, %t54
  store i64 %t55, ptr %l35, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = load i64, ptr %l35, !tbaa !24
  %t58 = add i64 %t56, %t57
  store i64 %t58, ptr %l36, !tbaa !24
  %t59 = load i64, ptr %l36, !tbaa !24
  store i64 %t59, ptr %l6, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l37, !tbaa !29
  %t61 = load ptr, ptr %l37, !tbaa !29
  %t62 = getelementptr %"compiler/unparse:writer", ptr %t61, i32 0, i32 3
  store ptr %t62, ptr %l38, !tbaa !29
  %t63 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t63, { i64, ptr } { i64 4, ptr @.d87 })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load i64, ptr %l5, !tbaa !24
  store i64 %t64, ptr %l39, !tbaa !24
  %t65 = load i64, ptr %l39, !tbaa !24
  %t66 = add i64 %t65, 1
  store i64 %t66, ptr %l40, !tbaa !24
  %t67 = load i64, ptr %l40, !tbaa !24
  store i64 %t67, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb15:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Param", ptr %t2, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load i32, ptr %l3, !tbaa !23
  %t6 = icmp ne i32 %t5, 0
  store i1 %t6, ptr %l4, !tbaa !21
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t10, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l7, !tbaa !23
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t14 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t13, i32 %t14)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Param", ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l9, !tbaa !29
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  store i1 %t20, ptr %l10, !tbaa !21
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l11, !tbaa !29
  %t23 = load ptr, ptr %l11, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Param", ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  store i32 %t25, ptr %l12, !tbaa !23
  %t26 = load i32, ptr %l12, !tbaa !23
  %t27 = icmp ne i32 %t26, 0
  store i1 %t27, ptr %l13, !tbaa !21
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb6:
  br label %bb12
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l14, !tbaa !29
  %t30 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t30, { i64, ptr } { i64 1, ptr @.d88 })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l15, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l16, !tbaa !29
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Param", ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l17, !tbaa !29
  %t36 = load ptr, ptr %l15, !tbaa !29
  %t37 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t36, ptr %t37)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l18, !tbaa !29
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Param", ptr %t39, i32 0, i32 3
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l19, !tbaa !29
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  store i1 %t43, ptr %l20, !tbaa !21
  %t44 = load i1, ptr %l20, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t46, { i64, ptr } { i64 3, ptr @.d89 })
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l22, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l23, !tbaa !29
  %t49 = load ptr, ptr %l23, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Param", ptr %t49, i32 0, i32 3
  %t51 = load ptr, ptr %t50, !tbaa !29
  store ptr %t51, ptr %l24, !tbaa !29
  %t52 = load ptr, ptr %l22, !tbaa !29
  %t53 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t3, ptr %l8, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l11, !tbaa !24
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l11, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l12, !tbaa !21
  %t12 = load i1, ptr %l12, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l13, !tbaa !21
  %t14 = load i1, ptr %l13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l14, !tbaa !24
  %t16 = load i64, ptr %l14, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l16, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t19
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load ptr, ptr %l17, !tbaa !29
  store ptr %t24, ptr %l6, !tbaa !29
  %t25 = load i64, ptr %l5, !tbaa !24
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = icmp sgt i64 %t26, 0
  store i1 %t27, ptr %l19, !tbaa !21
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  %t30 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t30, { i64, ptr } { i64 2, ptr @.d90 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t35 = load i64, ptr %l3, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  %t36 = load i64, ptr %l23, !tbaa !24
  %t37 = add i64 %t36, 1
  store i64 %t37, ptr %l24, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb1
bb11:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Path", ptr %t2, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t5, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l9, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l10, !tbaa !24
  %t9 = load i64, ptr %l10, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  store i64 %t10, ptr %l11, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  store i64 %t11, ptr %l12, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  store i1 %t14, ptr %l13, !tbaa !21
  %t15 = load i1, ptr %l13, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l14, !tbaa !21
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l15, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  store i64 %t21, ptr %l17, !tbaa !24
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t22
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l18, !tbaa !23
  %t27 = load i32, ptr %l18, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  %t28 = load i64, ptr %l5, !tbaa !24
  store i64 %t28, ptr %l19, !tbaa !24
  %t29 = load i64, ptr %l19, !tbaa !24
  %t30 = icmp sgt i64 %t29, 0
  store i1 %t30, ptr %l20, !tbaa !21
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l21, !tbaa !29
  %t33 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t33, { i64, ptr } { i64 1, ptr @.d91 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  store i32 %t35, ptr %l23, !tbaa !23
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t36, i32 %t37)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l24, !tbaa !24
  %t40 = add i64 %t39, 1
  store i64 %t40, ptr %l25, !tbaa !24
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb1
bb11:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l14, !tbaa !21
  %t4 = load i1, ptr %l14, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l15, !tbaa !24
  %t7 = load i64, ptr %l15, !tbaa !24
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l16, !tbaa !29
  %t11 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t11, { i64, ptr } { i64 1, ptr @.d92 })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb49
bb7:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  store i1 %t14, ptr %l19, !tbaa !21
  %t15 = load i1, ptr %l19, !tbaa !21
  br i1 %t15, label %bb8, label %bb9
bb8:
  %t16 = load ptr, ptr %l17, !tbaa !29
  %t17 = load i64, ptr %t16
  store i64 %t17, ptr %l20, !tbaa !24
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = icmp eq i64 %t18, 1
  store i1 %t19, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb10, label %bb11
bb10:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  %t22 = load ptr, ptr %l21, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", ptr }, ptr %t23, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l22, !tbaa !29
  %t26 = load ptr, ptr %l22, !tbaa !29
  store ptr %t26, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l23, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l24, !tbaa !29
  %t29 = load ptr, ptr %l23, !tbaa !29
  %t30 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t29, ptr %t30)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb14:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  store i1 %t33, ptr %l27, !tbaa !21
  %t34 = load i1, ptr %l27, !tbaa !21
  br i1 %t34, label %bb15, label %bb16
bb15:
  %t35 = load ptr, ptr %l25, !tbaa !29
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l28, !tbaa !24
  %t37 = load i64, ptr %l28, !tbaa !24
  %t38 = icmp eq i64 %t37, 2
  store i1 %t38, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l26, !tbaa !21
  br i1 %t39, label %bb17, label %bb18
bb17:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l29, !tbaa !29
  %t41 = load ptr, ptr %l29, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l30, !tbaa !29
  %t45 = load ptr, ptr %l30, !tbaa !29
  store ptr %t45, ptr %l3, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l31, !tbaa !29
  %t47 = load ptr, ptr %l31, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t48, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t51, ptr %l4, !tbaa !27
  br label %bb19
bb18:
  br label %bb34
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l33, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  store ptr %t53, ptr %l34, !tbaa !29
  %t54 = load ptr, ptr %l33, !tbaa !29
  %t55 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t54, ptr %t55)
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l35, !tbaa !29
  %t57 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t57, { i64, ptr } { i64 1, ptr @.d93 })
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l36, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t59, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t60, ptr %l37, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l38, !tbaa !24
  %t63 = load i64, ptr %l38, !tbaa !24
  store i64 %t63, ptr %l7, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load i64, ptr %l6, !tbaa !24
  store i64 %t64, ptr %l39, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = load i64, ptr %l40, !tbaa !24
  %t68 = icmp slt i64 %t66, %t67
  store i1 %t68, ptr %l41, !tbaa !21
  %t69 = load i1, ptr %l41, !tbaa !21
  %t70 = xor i1 %t69, true
  store i1 %t70, ptr %l42, !tbaa !21
  %t71 = load i1, ptr %l42, !tbaa !21
  br i1 %t71, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t72 = load i64, ptr %l6, !tbaa !24
  store i64 %t72, ptr %l43, !tbaa !24
  %t73 = load i64, ptr %l43, !tbaa !24
  store i64 %t73, ptr %l8, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l44, !tbaa !27
  %t75 = load i64, ptr %l6, !tbaa !24
  store i64 %t75, ptr %l45, !tbaa !24
  %t76 = load i64, ptr %l45, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t76
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l46, !tbaa !29
  %t81 = load ptr, ptr %l46, !tbaa !29
  store ptr %t81, ptr %l9, !tbaa !29
  %t82 = load i64, ptr %l8, !tbaa !24
  store i64 %t82, ptr %l47, !tbaa !24
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = icmp sgt i64 %t83, 0
  store i1 %t84, ptr %l48, !tbaa !21
  %t85 = load i1, ptr %l48, !tbaa !21
  br i1 %t85, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l49, !tbaa !29
  %t87 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t87, { i64, ptr } { i64 2, ptr @.d94 })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l50, !tbaa !29
  %t89 = load ptr, ptr %l9, !tbaa !29
  store ptr %t89, ptr %l51, !tbaa !29
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t90, ptr %t91)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t92 = load i64, ptr %l6, !tbaa !24
  store i64 %t92, ptr %l52, !tbaa !24
  %t93 = load i64, ptr %l52, !tbaa !24
  %t94 = add i64 %t93, 1
  store i64 %t94, ptr %l53, !tbaa !24
  %t95 = load i64, ptr %l53, !tbaa !24
  store i64 %t95, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb22
bb32:
  call void @__olang_scope_close(ptr %s4)
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l54, !tbaa !29
  %t97 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t97, { i64, ptr } { i64 1, ptr @.d95 })
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t99 = load ptr, ptr %l55, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  store i1 %t100, ptr %l57, !tbaa !21
  %t101 = load i1, ptr %l57, !tbaa !21
  br i1 %t101, label %bb35, label %bb36
bb35:
  %t102 = load ptr, ptr %l55, !tbaa !29
  %t103 = load i64, ptr %t102
  store i64 %t103, ptr %l58, !tbaa !24
  %t104 = load i64, ptr %l58, !tbaa !24
  %t105 = icmp eq i64 %t104, 3
  store i1 %t105, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb37, label %bb38
bb37:
  %t107 = load ptr, ptr %l1, !tbaa !29
  store ptr %t107, ptr %l59, !tbaa !29
  %t108 = load ptr, ptr %l59, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32 }, ptr %t109, i32 0, i32 1
  %t111 = load i32, ptr %t110
  store i32 %t111, ptr %l60, !tbaa !23
  %t112 = load i32, ptr %l60, !tbaa !23
  store i32 %t112, ptr %l10, !tbaa !23
  br label %bb39
bb38:
  br label %bb41
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l61, !tbaa !29
  %t114 = load i32, ptr %l10, !tbaa !23
  store i32 %t114, ptr %l62, !tbaa !23
  %t115 = load ptr, ptr %l61, !tbaa !29
  %t116 = load i32, ptr %l62, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t115, i32 %t116)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb41:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  store i1 %t119, ptr %l65, !tbaa !21
  %t120 = load i1, ptr %l65, !tbaa !21
  br i1 %t120, label %bb42, label %bb43
bb42:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load i64, ptr %t121
  store i64 %t122, ptr %l66, !tbaa !24
  %t123 = load i64, ptr %l66, !tbaa !24
  %t124 = icmp eq i64 %t123, 4
  store i1 %t124, ptr %l64, !tbaa !21
  br label %bb43
bb43:
  %t125 = load i1, ptr %l64, !tbaa !21
  br i1 %t125, label %bb44, label %bb45
bb44:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l67, !tbaa !29
  %t127 = load ptr, ptr %l67, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t127, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", ptr }, ptr %t128, i32 0, i32 1
  %t130 = load ptr, ptr %t129
  store ptr %t130, ptr %l68, !tbaa !29
  %t131 = load ptr, ptr %l68, !tbaa !29
  store ptr %t131, ptr %l11, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l69, !tbaa !29
  %t133 = load ptr, ptr %l11, !tbaa !29
  store ptr %t133, ptr %l70, !tbaa !29
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = load ptr, ptr %l70, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t134, ptr %t135)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s9)
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @.c96)
  unreachable
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t2, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t5, { i64, ptr } %t6)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t2, { i64, ptr } { i64 1, ptr @.d97 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t5, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t8, { i64, ptr } %t9)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t11, { i64, ptr } { i64 1, ptr @.d98 })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Sig", ptr %t13, i32 0, i32 4
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l9, !tbaa !21
  %t16 = load i1, ptr %l9, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l10, !tbaa !29
  %t18 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t18, { i64, ptr } { i64 9, ptr @.d99 })
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l11, !tbaa !29
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = getelementptr %"compiler/ast:Sig", ptr %t20, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l13, !tbaa !24
  %t25 = load i64, ptr %l13, !tbaa !24
  %t26 = icmp eq i64 %t25, 1
  store i1 %t26, ptr %l14, !tbaa !21
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l15, !tbaa !29
  %t29 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t29, { i64, ptr } { i64 1, ptr @.d100 })
  br label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l20, !tbaa !29
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Sig", ptr %t31, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l21, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l22, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = icmp sgt i64 %t36, 1
  store i1 %t37, ptr %l23, !tbaa !21
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l16, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l17, !tbaa !29
  %t41 = load ptr, ptr %l17, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Sig", ptr %t41, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l18, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr ptr, ptr %t45, i64 0
  %t47 = load ptr, ptr %t46, !tbaa !39
  store ptr %t47, ptr %l19, !tbaa !29
  %t48 = load ptr, ptr %l16, !tbaa !29
  %t49 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l24, !tbaa !29
  %t51 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t51, { i64, ptr } { i64 2, ptr @.d101 })
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l25, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l26, !tbaa !29
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Sig", ptr %t54, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l27, !tbaa !27
  %t57 = load ptr, ptr %l25, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t57, { i64, ptr } %t58)
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l28, !tbaa !29
  %t60 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t60, { i64, ptr } { i64 1, ptr @.d102 })
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l29, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l30, !tbaa !29
  %t63 = load i1, ptr %l2, !tbaa !21
  store i1 %t63, ptr %l31, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = load ptr, ptr %l30, !tbaa !29
  %t66 = load i1, ptr %l31, !tbaa !21
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t64, ptr %t65, i1 %t66)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t2, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t5, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  store i32 %t9, ptr %l6, !tbaa !23
  %t10 = load i32, ptr %l6, !tbaa !23
  %t11 = sext i32 %t10 to i64
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l8, !tbaa !23
  %t14 = load i32, ptr %l8, !tbaa !23
  %t15 = sext i32 %t14 to i64
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l10, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  store i1 %t19, ptr %l11, !tbaa !21
  %t20 = load i1, ptr %l11, !tbaa !21
  br i1 %t20, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  store i1 %t23, ptr %l12, !tbaa !21
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c103)
  unreachable
bb3:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  store i1 %t27, ptr %l13, !tbaa !21
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c103)
  unreachable
bb5:
  %t29 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l9, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l14, !tbaa !27
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t37, { i64, ptr } %t38)
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c103)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i64
  %l66 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i64
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l116 = alloca i1
  %l117 = alloca i1
  %l118 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l123 = alloca ptr
  %l124 = alloca ptr
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l130 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i64
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca ptr
  %l141 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca ptr
  %l150 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca i1
  %l153 = alloca i1
  %l154 = alloca i64
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l157 = alloca ptr
  %l158 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca i32
  %l168 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca i1
  %l171 = alloca ptr
  %l172 = alloca ptr
  %l173 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca { i64, ptr }
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l183 = alloca i1
  %l184 = alloca i1
  %l185 = alloca i64
  %l186 = alloca ptr
  %l187 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l189 = alloca ptr
  %l190 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca ptr
  %l195 = alloca ptr
  %l196 = alloca ptr
  %l197 = alloca i1
  %l198 = alloca i1
  %l199 = alloca i64
  %l200 = alloca ptr
  %l201 = alloca ptr
  %l202 = alloca ptr
  %l203 = alloca ptr
  %l204 = alloca ptr
  %l205 = alloca i1
  %l206 = alloca i1
  %l207 = alloca i64
  %l208 = alloca ptr
  %l209 = alloca { i64, ptr }
  %l210 = alloca ptr
  %l211 = alloca { i64, ptr }
  %l212 = alloca i64
  %l213 = alloca i1
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l216 = alloca { i64, ptr }
  %l217 = alloca ptr
  %l218 = alloca i1
  %l219 = alloca i1
  %l220 = alloca i64
  %l221 = alloca ptr
  %l222 = alloca i32
  %l223 = alloca ptr
  %l224 = alloca i32
  %l225 = alloca { i64, ptr }
  %l226 = alloca ptr
  %l227 = alloca i1
  %l228 = alloca i1
  %l229 = alloca i64
  %l230 = alloca ptr
  %l231 = alloca ptr
  %l232 = alloca ptr
  %l233 = alloca ptr
  %l234 = alloca ptr
  %l235 = alloca ptr
  %l236 = alloca ptr
  %l237 = alloca ptr
  %l238 = alloca i1
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l241 = alloca ptr
  %l242 = alloca ptr
  %l243 = alloca i1
  %l244 = alloca i1
  %l245 = alloca i64
  %l246 = alloca ptr
  %l247 = alloca ptr
  %l248 = alloca ptr
  %l249 = alloca ptr
  %l250 = alloca i1
  %l251 = alloca ptr
  %l252 = alloca ptr
  %l253 = alloca ptr
  %l254 = alloca ptr
  %l255 = alloca i1
  %l256 = alloca i1
  %l257 = alloca i64
  %l258 = alloca ptr
  %l259 = alloca { i64, ptr }
  %l260 = alloca ptr
  %l261 = alloca ptr
  %l262 = alloca ptr
  %l263 = alloca { i64, ptr }
  %l264 = alloca i64
  %l265 = alloca i1
  %l266 = alloca ptr
  %l267 = alloca { i64, ptr }
  %l268 = alloca ptr
  %l269 = alloca ptr
  %l270 = alloca ptr
  %l271 = alloca ptr
  %l272 = alloca i1
  %l273 = alloca i1
  %l274 = alloca i64
  %l275 = alloca ptr
  %l276 = alloca ptr
  %l277 = alloca ptr
  %l278 = alloca i1
  %l279 = alloca ptr
  %l280 = alloca ptr
  %l281 = alloca ptr
  %l282 = alloca ptr
  %l283 = alloca { i64, ptr }
  %l284 = alloca ptr
  %l285 = alloca ptr
  %l286 = alloca { i64, ptr }
  %l287 = alloca ptr
  %l288 = alloca i1
  %l289 = alloca i1
  %l290 = alloca i64
  %l291 = alloca ptr
  %l292 = alloca ptr
  %l293 = alloca ptr
  %l294 = alloca ptr
  %l295 = alloca ptr
  %l296 = alloca ptr
  %l297 = alloca i1
  %l298 = alloca i1
  %l299 = alloca i64
  %l300 = alloca ptr
  %l301 = alloca { i64, ptr }
  %l302 = alloca ptr
  %l303 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t2 = load ptr, ptr %l30, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l32, !tbaa !21
  %t4 = load i1, ptr %l32, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l30, !tbaa !29
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l33, !tbaa !24
  %t7 = load i64, ptr %l33, !tbaa !24
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l31, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l31, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l34, !tbaa !29
  %t11 = load ptr, ptr %l34, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l35, !tbaa !29
  %t15 = load ptr, ptr %l35, !tbaa !29
  store ptr %t15, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l36, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l37, !tbaa !29
  %t18 = load ptr, ptr %l36, !tbaa !29
  %t19 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t18, ptr %t19)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb215
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t21 = load ptr, ptr %l38, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  store i1 %t22, ptr %l40, !tbaa !21
  %t23 = load i1, ptr %l40, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l38, !tbaa !29
  %t25 = load i64, ptr %t24
  store i64 %t25, ptr %l41, !tbaa !24
  %t26 = load i64, ptr %l41, !tbaa !24
  %t27 = icmp eq i64 %t26, 1
  store i1 %t27, ptr %l39, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l39, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l42, !tbaa !29
  %t30 = load ptr, ptr %l42, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l43, !tbaa !29
  %t34 = load ptr, ptr %l43, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l44, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  store ptr %t36, ptr %l45, !tbaa !29
  %t37 = load ptr, ptr %l44, !tbaa !29
  %t38 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb215
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t40 = load ptr, ptr %l46, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  store i1 %t41, ptr %l48, !tbaa !21
  %t42 = load i1, ptr %l48, !tbaa !21
  br i1 %t42, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l46, !tbaa !29
  %t44 = load i64, ptr %t43
  store i64 %t44, ptr %l49, !tbaa !24
  %t45 = load i64, ptr %l49, !tbaa !24
  %t46 = icmp eq i64 %t45, 2
  store i1 %t46, ptr %l47, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l47, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l50, !tbaa !29
  %t49 = load ptr, ptr %l50, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l51, !tbaa !29
  %t53 = load ptr, ptr %l51, !tbaa !29
  store ptr %t53, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb26
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l52, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  store ptr %t55, ptr %l53, !tbaa !29
  %t56 = load ptr, ptr %l53, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Multi", ptr %t56, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l54, !tbaa !27
  %t59 = load ptr, ptr %l52, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l54, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t59, { i64, ptr } %t60)
  br label %bb20
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l55, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  store ptr %t62, ptr %l56, !tbaa !29
  %t63 = load ptr, ptr %l56, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Multi", ptr %t63, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  store i1 %t65, ptr %l57, !tbaa !21
  %t66 = load i1, ptr %l57, !tbaa !21
  br i1 %t66, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr @.d104 }, ptr %l58, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 3, ptr @.d105 }, ptr %l58, !tbaa !27
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l55, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l58, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t67, { i64, ptr } %t68)
  br label %bb24
bb24:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l59, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  store ptr %t70, ptr %l60, !tbaa !29
  %t71 = load ptr, ptr %l60, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Multi", ptr %t71, i32 0, i32 2
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l61, !tbaa !27
  %t74 = load ptr, ptr %l59, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l61, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t74, { i64, ptr } %t75)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb215
bb26:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t77 = load ptr, ptr %l62, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  store i1 %t78, ptr %l64, !tbaa !21
  %t79 = load i1, ptr %l64, !tbaa !21
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l62, !tbaa !29
  %t81 = load i64, ptr %t80
  store i64 %t81, ptr %l65, !tbaa !24
  %t82 = load i64, ptr %l65, !tbaa !24
  %t83 = icmp eq i64 %t82, 3
  store i1 %t83, ptr %l63, !tbaa !21
  br label %bb28
bb28:
  %t84 = load i1, ptr %l63, !tbaa !21
  br i1 %t84, label %bb29, label %bb30
bb29:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l66, !tbaa !29
  %t86 = load ptr, ptr %l66, !tbaa !29
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l67
  %t90 = load i32, ptr %l67
  store i32 %t90, ptr %l5
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l68, !tbaa !29
  %t92 = load ptr, ptr %l68, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l69, !tbaa !29
  %t96 = load ptr, ptr %l69, !tbaa !29
  store ptr %t96, ptr %l6, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l70, !tbaa !29
  %t98 = load ptr, ptr %l70, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t98, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t99, i32 0, i32 3
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l71, !tbaa !29
  %t102 = load ptr, ptr %l71, !tbaa !29
  store ptr %t102, ptr %l7, !tbaa !29
  br label %bb31
bb30:
  br label %bb38
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l72, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  store ptr %t104, ptr %l73, !tbaa !29
  %t105 = load ptr, ptr %l72, !tbaa !29
  %t106 = load ptr, ptr %l73, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t105, ptr %t106)
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l74, !tbaa !29
  %t108 = load ptr, ptr %l74, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t108, { i64, ptr } { i64 1, ptr @.d106 })
  br label %bb33
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l75, !tbaa !29
  %t110 = load i32, ptr %l5
  store i32 %t110, ptr %l76
  %t111 = load i32, ptr %l76
  %t112 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t111)
  store { i64, ptr } %t112, ptr %l77
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l75, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l77, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t113, { i64, ptr } %t114)
  br label %bb35
bb35:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l78, !tbaa !29
  %t116 = load ptr, ptr %l78, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t116, { i64, ptr } { i64 1, ptr @.d107 })
  br label %bb36
bb36:
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l79, !tbaa !29
  %t118 = load ptr, ptr %l7, !tbaa !29
  store ptr %t118, ptr %l80, !tbaa !29
  %t119 = load ptr, ptr %l79, !tbaa !29
  %t120 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t119, ptr %t120)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb215
bb38:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t122 = load ptr, ptr %l81, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  store i1 %t123, ptr %l83, !tbaa !21
  %t124 = load i1, ptr %l83, !tbaa !21
  br i1 %t124, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %l81, !tbaa !29
  %t126 = load i64, ptr %t125
  store i64 %t126, ptr %l84, !tbaa !24
  %t127 = load i64, ptr %l84, !tbaa !24
  %t128 = icmp eq i64 %t127, 4
  store i1 %t128, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t129 = load i1, ptr %l82, !tbaa !21
  br i1 %t129, label %bb41, label %bb42
bb41:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l85, !tbaa !29
  %t131 = load ptr, ptr %l85, !tbaa !29
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t131, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l86, !tbaa !29
  %t135 = load ptr, ptr %l86, !tbaa !29
  store ptr %t135, ptr %l8, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  store ptr %t136, ptr %l87, !tbaa !29
  %t137 = load ptr, ptr %l87, !tbaa !29
  %t138 = getelementptr { i64, [5 x i64] }, ptr %t137, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t138, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139
  store { i64, ptr } %t140, ptr %l88, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t141, ptr %l9, !tbaa !27
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l89, !tbaa !29
  %t143 = load ptr, ptr %l89, !tbaa !29
  %t144 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t144, i32 0, i32 3
  %t146 = load i1, ptr %t145
  store i1 %t146, ptr %l90, !tbaa !21
  %t147 = load i1, ptr %l90, !tbaa !21
  store i1 %t147, ptr %l10, !tbaa !21
  br label %bb43
bb42:
  br label %bb50
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l91, !tbaa !29
  %t149 = load i1, ptr %l10, !tbaa !21
  store i1 %t149, ptr %l92, !tbaa !21
  %t150 = load i1, ptr %l92, !tbaa !21
  br i1 %t150, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 8, ptr @.d108 }, ptr %l93, !tbaa !27
  br label %bb46
bb45:
  store { i64, ptr } { i64 4, ptr @.d109 }, ptr %l93, !tbaa !27
  br label %bb46
bb46:
  %t151 = load ptr, ptr %l91, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l93, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t151, { i64, ptr } %t152)
  br label %bb47
bb47:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l94, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  store ptr %t154, ptr %l95, !tbaa !29
  %t155 = load ptr, ptr %l94, !tbaa !29
  %t156 = load ptr, ptr %l95, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t155, ptr %t156)
  br label %bb48
bb48:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l96, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t158, ptr %l97, !tbaa !27
  %t159 = load ptr, ptr %l96, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l97, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t159, { i64, ptr } %t160)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb215
bb50:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t162 = load ptr, ptr %l98, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  store i1 %t163, ptr %l100, !tbaa !21
  %t164 = load i1, ptr %l100, !tbaa !21
  br i1 %t164, label %bb51, label %bb52
bb51:
  %t165 = load ptr, ptr %l98, !tbaa !29
  %t166 = load i64, ptr %t165
  store i64 %t166, ptr %l101, !tbaa !24
  %t167 = load i64, ptr %l101, !tbaa !24
  %t168 = icmp eq i64 %t167, 5
  store i1 %t168, ptr %l99, !tbaa !21
  br label %bb52
bb52:
  %t169 = load i1, ptr %l99, !tbaa !21
  br i1 %t169, label %bb53, label %bb54
bb53:
  %t170 = load ptr, ptr %l1, !tbaa !29
  store ptr %t170, ptr %l102, !tbaa !29
  %t171 = load ptr, ptr %l102, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", ptr }, ptr %t172, i32 0, i32 1
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l103, !tbaa !29
  %t175 = load ptr, ptr %l103, !tbaa !29
  store ptr %t175, ptr %l11, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  store %olang.scope zeroinitializer, ptr %s6
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l104, !tbaa !29
  %t177 = load ptr, ptr %l11, !tbaa !29
  store ptr %t177, ptr %l105, !tbaa !29
  %t178 = load ptr, ptr %l104, !tbaa !29
  %t179 = load ptr, ptr %l105, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %t178, ptr %t179)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s6)
  br label %bb215
bb57:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t181 = load ptr, ptr %l106, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  store i1 %t182, ptr %l108, !tbaa !21
  %t183 = load i1, ptr %l108, !tbaa !21
  br i1 %t183, label %bb58, label %bb59
bb58:
  %t184 = load ptr, ptr %l106, !tbaa !29
  %t185 = load i64, ptr %t184
  store i64 %t185, ptr %l109, !tbaa !24
  %t186 = load i64, ptr %l109, !tbaa !24
  %t187 = icmp eq i64 %t186, 6
  store i1 %t187, ptr %l107, !tbaa !21
  br label %bb59
bb59:
  %t188 = load i1, ptr %l107, !tbaa !21
  br i1 %t188, label %bb60, label %bb61
bb60:
  %t189 = load ptr, ptr %l1, !tbaa !29
  store ptr %t189, ptr %l110, !tbaa !29
  %t190 = load ptr, ptr %l110, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t191, i32 0, i32 1
  %t193 = load { i64, ptr }, ptr %t192
  store { i64, ptr } %t193, ptr %l111, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t194, ptr %l12, !tbaa !27
  br label %bb62
bb61:
  br label %bb65
bb62:
  store %olang.scope zeroinitializer, ptr %s7
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l112, !tbaa !29
  %t196 = load ptr, ptr %l112, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t196, { i64, ptr } { i64 4, ptr @.d110 })
  br label %bb63
bb63:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l113, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t198, ptr %l114, !tbaa !27
  %t199 = load ptr, ptr %l113, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l114, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t199, { i64, ptr } %t200)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb215
bb65:
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t202 = load ptr, ptr %l115, !tbaa !29
  %t203 = icmp ne ptr %t202, null
  store i1 %t203, ptr %l117, !tbaa !21
  %t204 = load i1, ptr %l117, !tbaa !21
  br i1 %t204, label %bb66, label %bb67
bb66:
  %t205 = load ptr, ptr %l115, !tbaa !29
  %t206 = load i64, ptr %t205
  store i64 %t206, ptr %l118, !tbaa !24
  %t207 = load i64, ptr %l118, !tbaa !24
  %t208 = icmp eq i64 %t207, 7
  store i1 %t208, ptr %l116, !tbaa !21
  br label %bb67
bb67:
  %t209 = load i1, ptr %l116, !tbaa !21
  br i1 %t209, label %bb68, label %bb69
bb68:
  %t210 = load ptr, ptr %l1, !tbaa !29
  store ptr %t210, ptr %l119, !tbaa !29
  %t211 = load ptr, ptr %l119, !tbaa !29
  %t212 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t212, i32 0, i32 1
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l120, !tbaa !29
  %t215 = load ptr, ptr %l120, !tbaa !29
  store ptr %t215, ptr %l13, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  store ptr %t216, ptr %l121, !tbaa !29
  %t217 = load ptr, ptr %l121, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t217, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t218, i32 0, i32 2
  %t220 = load { i64, ptr }, ptr %t219
  store { i64, ptr } %t220, ptr %l122, !tbaa !27
  %t221 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t221, ptr %l14, !tbaa !27
  br label %bb70
bb69:
  br label %bb75
bb70:
  store %olang.scope zeroinitializer, ptr %s8
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l123, !tbaa !29
  %t223 = load ptr, ptr %l123, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t223, { i64, ptr } { i64 4, ptr @.d111 })
  br label %bb71
bb71:
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l124, !tbaa !29
  %t225 = load ptr, ptr %l13, !tbaa !29
  store ptr %t225, ptr %l125, !tbaa !29
  %t226 = load ptr, ptr %l124, !tbaa !29
  %t227 = load ptr, ptr %l125, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t226, ptr %t227)
  br label %bb72
bb72:
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l126, !tbaa !29
  %t229 = load ptr, ptr %l126, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t229, { i64, ptr } { i64 1, ptr @.d112 })
  br label %bb73
bb73:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l127, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t231, ptr %l128, !tbaa !27
  %t232 = load ptr, ptr %l127, !tbaa !29
  %t233 = load { i64, ptr }, ptr %l128, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t232, { i64, ptr } %t233)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s8)
  br label %bb215
bb75:
  %t234 = load ptr, ptr %l1, !tbaa !29
  store ptr %t234, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t235 = load ptr, ptr %l129, !tbaa !29
  %t236 = icmp ne ptr %t235, null
  store i1 %t236, ptr %l131, !tbaa !21
  %t237 = load i1, ptr %l131, !tbaa !21
  br i1 %t237, label %bb76, label %bb77
bb76:
  %t238 = load ptr, ptr %l129, !tbaa !29
  %t239 = load i64, ptr %t238
  store i64 %t239, ptr %l132, !tbaa !24
  %t240 = load i64, ptr %l132, !tbaa !24
  %t241 = icmp eq i64 %t240, 8
  store i1 %t241, ptr %l130, !tbaa !21
  br label %bb77
bb77:
  %t242 = load i1, ptr %l130, !tbaa !21
  br i1 %t242, label %bb78, label %bb79
bb78:
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l133, !tbaa !29
  %t244 = load ptr, ptr %l133, !tbaa !29
  %t245 = getelementptr { i64, [5 x i64] }, ptr %t244, i32 0, i32 1
  %t246 = getelementptr { %"compiler/source:Span", ptr }, ptr %t245, i32 0, i32 1
  %t247 = load ptr, ptr %t246
  store ptr %t247, ptr %l134, !tbaa !29
  %t248 = load ptr, ptr %l134, !tbaa !29
  store ptr %t248, ptr %l15, !tbaa !29
  br label %bb80
bb79:
  br label %bb89
bb80:
  store %olang.scope zeroinitializer, ptr %s9
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l135, !tbaa !29
  %t250 = load ptr, ptr %l135, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t250, { i64, ptr } { i64 4, ptr @.d113 })
  br label %bb81
bb81:
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l136, !tbaa !29
  %t252 = load ptr, ptr %l15, !tbaa !29
  store ptr %t252, ptr %l137, !tbaa !29
  %t253 = load ptr, ptr %l137, !tbaa !29
  %t254 = getelementptr %"compiler/ast:For3", ptr %t253, i32 0, i32 0
  %t255 = load ptr, ptr %t254, !tbaa !29
  store ptr %t255, ptr %l138, !tbaa !29
  %t256 = load ptr, ptr %l136, !tbaa !29
  %t257 = load ptr, ptr %l138, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t256, ptr %t257)
  br label %bb82
bb82:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l139, !tbaa !29
  %t259 = load ptr, ptr %l139, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t259, { i64, ptr } { i64 2, ptr @.d114 })
  br label %bb83
bb83:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l140, !tbaa !29
  %t261 = load ptr, ptr %l15, !tbaa !29
  store ptr %t261, ptr %l141, !tbaa !29
  %t262 = load ptr, ptr %l141, !tbaa !29
  %t263 = getelementptr %"compiler/ast:For3", ptr %t262, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  store ptr %t264, ptr %l142, !tbaa !29
  %t265 = load ptr, ptr %l140, !tbaa !29
  %t266 = load ptr, ptr %l142, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t265, ptr %t266)
  br label %bb84
bb84:
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l143, !tbaa !29
  %t268 = load ptr, ptr %l143, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t268, { i64, ptr } { i64 2, ptr @.d115 })
  br label %bb85
bb85:
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l144, !tbaa !29
  %t270 = load ptr, ptr %l15, !tbaa !29
  store ptr %t270, ptr %l145, !tbaa !29
  %t271 = load ptr, ptr %l145, !tbaa !29
  %t272 = getelementptr %"compiler/ast:For3", ptr %t271, i32 0, i32 2
  %t273 = load ptr, ptr %t272, !tbaa !29
  store ptr %t273, ptr %l146, !tbaa !29
  %t274 = load ptr, ptr %l144, !tbaa !29
  %t275 = load ptr, ptr %l146, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t274, ptr %t275)
  br label %bb86
bb86:
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l147, !tbaa !29
  %t277 = load ptr, ptr %l147, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t277, { i64, ptr } { i64 1, ptr @.d116 })
  br label %bb87
bb87:
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l148, !tbaa !29
  %t279 = load ptr, ptr %l15, !tbaa !29
  store ptr %t279, ptr %l149, !tbaa !29
  %t280 = load ptr, ptr %l149, !tbaa !29
  %t281 = getelementptr %"compiler/ast:For3", ptr %t280, i32 0, i32 3
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !27
  store { i64, ptr } %t282, ptr %l150, !tbaa !27
  %t283 = load ptr, ptr %l148, !tbaa !29
  %t284 = load { i64, ptr }, ptr %l150, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t283, { i64, ptr } %t284)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s9)
  br label %bb215
bb89:
  %t285 = load ptr, ptr %l1, !tbaa !29
  store ptr %t285, ptr %l151, !tbaa !29
  store i1 false, ptr %l152, !tbaa !21
  %t286 = load ptr, ptr %l151, !tbaa !29
  %t287 = icmp ne ptr %t286, null
  store i1 %t287, ptr %l153, !tbaa !21
  %t288 = load i1, ptr %l153, !tbaa !21
  br i1 %t288, label %bb90, label %bb91
bb90:
  %t289 = load ptr, ptr %l151, !tbaa !29
  %t290 = load i64, ptr %t289
  store i64 %t290, ptr %l154, !tbaa !24
  %t291 = load i64, ptr %l154, !tbaa !24
  %t292 = icmp eq i64 %t291, 9
  store i1 %t292, ptr %l152, !tbaa !21
  br label %bb91
bb91:
  %t293 = load i1, ptr %l152, !tbaa !21
  br i1 %t293, label %bb92, label %bb93
bb92:
  %t294 = load ptr, ptr %l1, !tbaa !29
  store ptr %t294, ptr %l155, !tbaa !29
  %t295 = load ptr, ptr %l155, !tbaa !29
  %t296 = getelementptr { i64, [5 x i64] }, ptr %t295, i32 0, i32 1
  %t297 = getelementptr { %"compiler/source:Span", ptr }, ptr %t296, i32 0, i32 1
  %t298 = load ptr, ptr %t297
  store ptr %t298, ptr %l156, !tbaa !29
  %t299 = load ptr, ptr %l156, !tbaa !29
  store ptr %t299, ptr %l16, !tbaa !29
  br label %bb94
bb93:
  br label %bb111
bb94:
  store %olang.scope zeroinitializer, ptr %s10
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l157, !tbaa !29
  %t301 = load ptr, ptr %l157, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t301, { i64, ptr } { i64 4, ptr @.d117 })
  br label %bb95
bb95:
  %t302 = load ptr, ptr %l16, !tbaa !29
  store ptr %t302, ptr %l158, !tbaa !29
  %t303 = load ptr, ptr %l158, !tbaa !29
  %t304 = getelementptr %"compiler/ast:ForIn", ptr %t303, i32 0, i32 0
  %t305 = load i32, ptr %t304, !tbaa !23
  store i32 %t305, ptr %l159, !tbaa !23
  %t306 = load i32, ptr %l159, !tbaa !23
  %t307 = icmp ne i32 %t306, 0
  store i1 %t307, ptr %l160, !tbaa !21
  %t308 = load i1, ptr %l160, !tbaa !21
  br i1 %t308, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s11
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l161, !tbaa !29
  %t310 = load ptr, ptr %l16, !tbaa !29
  store ptr %t310, ptr %l162, !tbaa !29
  %t311 = load ptr, ptr %l162, !tbaa !29
  %t312 = getelementptr %"compiler/ast:ForIn", ptr %t311, i32 0, i32 0
  %t313 = load i32, ptr %t312, !tbaa !23
  store i32 %t313, ptr %l163, !tbaa !23
  %t314 = load ptr, ptr %l161, !tbaa !29
  %t315 = load i32, ptr %l163, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t314, i32 %t315)
  br label %bb98
bb97:
  br label %bb100
bb98:
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l164, !tbaa !29
  %t317 = load ptr, ptr %l164, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t317, { i64, ptr } { i64 2, ptr @.d118 })
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s11)
  br label %bb100
bb100:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l165, !tbaa !29
  %t319 = load ptr, ptr %l16, !tbaa !29
  store ptr %t319, ptr %l166, !tbaa !29
  %t320 = load ptr, ptr %l166, !tbaa !29
  %t321 = getelementptr %"compiler/ast:ForIn", ptr %t320, i32 0, i32 1
  %t322 = load i32, ptr %t321, !tbaa !23
  store i32 %t322, ptr %l167, !tbaa !23
  %t323 = load ptr, ptr %l165, !tbaa !29
  %t324 = load i32, ptr %l167, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t323, i32 %t324)
  br label %bb101
bb101:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l168, !tbaa !29
  %t326 = load ptr, ptr %l168, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t326, { i64, ptr } { i64 4, ptr @.d119 })
  br label %bb102
bb102:
  %t327 = load ptr, ptr %l16, !tbaa !29
  store ptr %t327, ptr %l169, !tbaa !29
  %t328 = load ptr, ptr %l169, !tbaa !29
  %t329 = getelementptr %"compiler/ast:ForIn", ptr %t328, i32 0, i32 3
  %t330 = load i1, ptr %t329, !tbaa !21
  store i1 %t330, ptr %l170, !tbaa !21
  %t331 = load i1, ptr %l170, !tbaa !21
  br i1 %t331, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s12
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l171, !tbaa !29
  %t333 = load ptr, ptr %l171, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t333, { i64, ptr } { i64 4, ptr @.d120 })
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_scope_close(ptr %s12)
  br label %bb106
bb106:
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l172, !tbaa !29
  %t335 = load ptr, ptr %l16, !tbaa !29
  store ptr %t335, ptr %l173, !tbaa !29
  %t336 = load ptr, ptr %l173, !tbaa !29
  %t337 = getelementptr %"compiler/ast:ForIn", ptr %t336, i32 0, i32 2
  %t338 = load ptr, ptr %t337, !tbaa !29
  store ptr %t338, ptr %l174, !tbaa !29
  %t339 = load ptr, ptr %l172, !tbaa !29
  %t340 = load ptr, ptr %l174, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t339, ptr %t340)
  br label %bb107
bb107:
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l175, !tbaa !29
  %t342 = load ptr, ptr %l175, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t342, { i64, ptr } { i64 1, ptr @.d121 })
  br label %bb108
bb108:
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l176, !tbaa !29
  %t344 = load ptr, ptr %l16, !tbaa !29
  store ptr %t344, ptr %l177, !tbaa !29
  %t345 = load ptr, ptr %l177, !tbaa !29
  %t346 = getelementptr %"compiler/ast:ForIn", ptr %t345, i32 0, i32 4
  %t347 = load { i64, ptr }, ptr %t346, !tbaa !27
  store { i64, ptr } %t347, ptr %l178, !tbaa !27
  %t348 = load ptr, ptr %l176, !tbaa !29
  %t349 = load { i64, ptr }, ptr %l178, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t348, { i64, ptr } %t349)
  br label %bb109
bb109:
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l179, !tbaa !29
  %t351 = load ptr, ptr %l16, !tbaa !29
  store ptr %t351, ptr %l180, !tbaa !29
  %t352 = load ptr, ptr %l180, !tbaa !29
  %t353 = getelementptr %"compiler/ast:ForIn", ptr %t352, i32 0, i32 5
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  store { i64, ptr } %t354, ptr %l181, !tbaa !27
  %t355 = load ptr, ptr %l179, !tbaa !29
  %t356 = load { i64, ptr }, ptr %l181, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t355, { i64, ptr } %t356)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s10)
  br label %bb215
bb111:
  %t357 = load ptr, ptr %l1, !tbaa !29
  store ptr %t357, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t358 = load ptr, ptr %l182, !tbaa !29
  %t359 = icmp ne ptr %t358, null
  store i1 %t359, ptr %l184, !tbaa !21
  %t360 = load i1, ptr %l184, !tbaa !21
  br i1 %t360, label %bb112, label %bb113
bb112:
  %t361 = load ptr, ptr %l182, !tbaa !29
  %t362 = load i64, ptr %t361
  store i64 %t362, ptr %l185, !tbaa !24
  %t363 = load i64, ptr %l185, !tbaa !24
  %t364 = icmp eq i64 %t363, 10
  store i1 %t364, ptr %l183, !tbaa !21
  br label %bb113
bb113:
  %t365 = load i1, ptr %l183, !tbaa !21
  br i1 %t365, label %bb114, label %bb115
bb114:
  %t366 = load ptr, ptr %l1, !tbaa !29
  store ptr %t366, ptr %l186, !tbaa !29
  %t367 = load ptr, ptr %l186, !tbaa !29
  %t368 = getelementptr { i64, [5 x i64] }, ptr %t367, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t368, i32 0, i32 1
  %t370 = load { i64, ptr }, ptr %t369
  store { i64, ptr } %t370, ptr %l187, !tbaa !27
  %t371 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t371, ptr %l17, !tbaa !27
  %t372 = load ptr, ptr %l1, !tbaa !29
  store ptr %t372, ptr %l188, !tbaa !29
  %t373 = load ptr, ptr %l188, !tbaa !29
  %t374 = getelementptr { i64, [5 x i64] }, ptr %t373, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t374, i32 0, i32 2
  %t376 = load ptr, ptr %t375
  store ptr %t376, ptr %l189, !tbaa !29
  %t377 = load ptr, ptr %l189, !tbaa !29
  store ptr %t377, ptr %l18, !tbaa !29
  br label %bb116
bb115:
  br label %bb121
bb116:
  store %olang.scope zeroinitializer, ptr %s13
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l190, !tbaa !29
  %t379 = load ptr, ptr %l190, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t379, { i64, ptr } { i64 3, ptr @.d122 })
  br label %bb117
bb117:
  %t380 = load ptr, ptr %l0, !tbaa !29
  store ptr %t380, ptr %l191, !tbaa !29
  %t381 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t381, ptr %l192, !tbaa !27
  %t382 = load ptr, ptr %l191, !tbaa !29
  %t383 = load { i64, ptr }, ptr %l192, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t382, { i64, ptr } %t383)
  br label %bb118
bb118:
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l193, !tbaa !29
  %t385 = load ptr, ptr %l193, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t385, { i64, ptr } { i64 5, ptr @.d123 })
  br label %bb119
bb119:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l194, !tbaa !29
  %t387 = load ptr, ptr %l18, !tbaa !29
  store ptr %t387, ptr %l195, !tbaa !29
  %t388 = load ptr, ptr %l194, !tbaa !29
  %t389 = load ptr, ptr %l195, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t388, ptr %t389)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s13)
  br label %bb215
bb121:
  %t390 = load ptr, ptr %l1, !tbaa !29
  store ptr %t390, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t391 = load ptr, ptr %l196, !tbaa !29
  %t392 = icmp ne ptr %t391, null
  store i1 %t392, ptr %l198, !tbaa !21
  %t393 = load i1, ptr %l198, !tbaa !21
  br i1 %t393, label %bb122, label %bb123
bb122:
  %t394 = load ptr, ptr %l196, !tbaa !29
  %t395 = load i64, ptr %t394
  store i64 %t395, ptr %l199, !tbaa !24
  %t396 = load i64, ptr %l199, !tbaa !24
  %t397 = icmp eq i64 %t396, 11
  store i1 %t397, ptr %l197, !tbaa !21
  br label %bb123
bb123:
  %t398 = load i1, ptr %l197, !tbaa !21
  br i1 %t398, label %bb124, label %bb125
bb124:
  %t399 = load ptr, ptr %l1, !tbaa !29
  store ptr %t399, ptr %l200, !tbaa !29
  %t400 = load ptr, ptr %l200, !tbaa !29
  %t401 = getelementptr { i64, [5 x i64] }, ptr %t400, i32 0, i32 1
  %t402 = getelementptr { %"compiler/source:Span", ptr }, ptr %t401, i32 0, i32 1
  %t403 = load ptr, ptr %t402
  store ptr %t403, ptr %l201, !tbaa !29
  %t404 = load ptr, ptr %l201, !tbaa !29
  store ptr %t404, ptr %l19, !tbaa !29
  br label %bb126
bb125:
  br label %bb128
bb126:
  store %olang.scope zeroinitializer, ptr %s14
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l202, !tbaa !29
  %t406 = load ptr, ptr %l19, !tbaa !29
  store ptr %t406, ptr %l203, !tbaa !29
  %t407 = load ptr, ptr %l202, !tbaa !29
  %t408 = load ptr, ptr %l203, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t407, ptr %t408)
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s14)
  br label %bb215
bb128:
  %t409 = load ptr, ptr %l1, !tbaa !29
  store ptr %t409, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t410 = load ptr, ptr %l204, !tbaa !29
  %t411 = icmp ne ptr %t410, null
  store i1 %t411, ptr %l206, !tbaa !21
  %t412 = load i1, ptr %l206, !tbaa !21
  br i1 %t412, label %bb129, label %bb130
bb129:
  %t413 = load ptr, ptr %l204, !tbaa !29
  %t414 = load i64, ptr %t413
  store i64 %t414, ptr %l207, !tbaa !24
  %t415 = load i64, ptr %l207, !tbaa !24
  %t416 = icmp eq i64 %t415, 12
  store i1 %t416, ptr %l205, !tbaa !21
  br label %bb130
bb130:
  %t417 = load i1, ptr %l205, !tbaa !21
  br i1 %t417, label %bb131, label %bb132
bb131:
  %t418 = load ptr, ptr %l1, !tbaa !29
  store ptr %t418, ptr %l208, !tbaa !29
  %t419 = load ptr, ptr %l208, !tbaa !29
  %t420 = getelementptr { i64, [5 x i64] }, ptr %t419, i32 0, i32 1
  %t421 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t420, i32 0, i32 1
  %t422 = load { i64, ptr }, ptr %t421
  store { i64, ptr } %t422, ptr %l209, !tbaa !27
  %t423 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t423, ptr %l20, !tbaa !27
  br label %bb133
bb132:
  br label %bb140
bb133:
  store %olang.scope zeroinitializer, ptr %s15
  %t424 = load ptr, ptr %l0, !tbaa !29
  store ptr %t424, ptr %l210, !tbaa !29
  %t425 = load ptr, ptr %l210, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t425, { i64, ptr } { i64 6, ptr @.d124 })
  br label %bb134
bb134:
  %t426 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t426, ptr %l211, !tbaa !27
  %t427 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t427, 0
  store i64 %t428, ptr %l212, !tbaa !24
  %t429 = load i64, ptr %l212, !tbaa !24
  %t430 = icmp sgt i64 %t429, 0
  store i1 %t430, ptr %l213, !tbaa !21
  %t431 = load i1, ptr %l213, !tbaa !21
  br i1 %t431, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s16
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l214, !tbaa !29
  %t433 = load ptr, ptr %l214, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t433, { i64, ptr } { i64 1, ptr @.d125 })
  br label %bb137
bb136:
  br label %bb139
bb137:
  %t434 = load ptr, ptr %l0, !tbaa !29
  store ptr %t434, ptr %l215, !tbaa !29
  %t435 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t435, ptr %l216, !tbaa !27
  %t436 = load ptr, ptr %l215, !tbaa !29
  %t437 = load { i64, ptr }, ptr %l216, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t436, { i64, ptr } %t437)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s16)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s15)
  br label %bb215
bb140:
  %t438 = load ptr, ptr %l1, !tbaa !29
  store ptr %t438, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t439 = load ptr, ptr %l217, !tbaa !29
  %t440 = icmp ne ptr %t439, null
  store i1 %t440, ptr %l219, !tbaa !21
  %t441 = load i1, ptr %l219, !tbaa !21
  br i1 %t441, label %bb141, label %bb142
bb141:
  %t442 = load ptr, ptr %l217, !tbaa !29
  %t443 = load i64, ptr %t442
  store i64 %t443, ptr %l220, !tbaa !24
  %t444 = load i64, ptr %l220, !tbaa !24
  %t445 = icmp eq i64 %t444, 13
  store i1 %t445, ptr %l218, !tbaa !21
  br label %bb142
bb142:
  %t446 = load i1, ptr %l218, !tbaa !21
  br i1 %t446, label %bb143, label %bb144
bb143:
  %t447 = load ptr, ptr %l1, !tbaa !29
  store ptr %t447, ptr %l221, !tbaa !29
  %t448 = load ptr, ptr %l221, !tbaa !29
  %t449 = getelementptr { i64, [5 x i64] }, ptr %t448, i32 0, i32 1
  %t450 = getelementptr { %"compiler/source:Span", i32 }, ptr %t449, i32 0, i32 1
  %t451 = load i32, ptr %t450
  store i32 %t451, ptr %l222
  %t452 = load i32, ptr %l222
  store i32 %t452, ptr %l21
  br label %bb145
bb144:
  br label %bb148
bb145:
  store %olang.scope zeroinitializer, ptr %s17
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l223, !tbaa !29
  %t454 = load i32, ptr %l21
  store i32 %t454, ptr %l224
  %t455 = load i32, ptr %l224
  %t456 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s17, i32 %t455)
  store { i64, ptr } %t456, ptr %l225
  br label %bb146
bb146:
  %t457 = load ptr, ptr %l223, !tbaa !29
  %t458 = load { i64, ptr }, ptr %l225, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t457, { i64, ptr } %t458)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s17)
  br label %bb215
bb148:
  %t459 = load ptr, ptr %l1, !tbaa !29
  store ptr %t459, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t460 = load ptr, ptr %l226, !tbaa !29
  %t461 = icmp ne ptr %t460, null
  store i1 %t461, ptr %l228, !tbaa !21
  %t462 = load i1, ptr %l228, !tbaa !21
  br i1 %t462, label %bb149, label %bb150
bb149:
  %t463 = load ptr, ptr %l226, !tbaa !29
  %t464 = load i64, ptr %t463
  store i64 %t464, ptr %l229, !tbaa !24
  %t465 = load i64, ptr %l229, !tbaa !24
  %t466 = icmp eq i64 %t465, 14
  store i1 %t466, ptr %l227, !tbaa !21
  br label %bb150
bb150:
  %t467 = load i1, ptr %l227, !tbaa !21
  br i1 %t467, label %bb151, label %bb152
bb151:
  %t468 = load ptr, ptr %l1, !tbaa !29
  store ptr %t468, ptr %l230, !tbaa !29
  %t469 = load ptr, ptr %l230, !tbaa !29
  %t470 = getelementptr { i64, [5 x i64] }, ptr %t469, i32 0, i32 1
  %t471 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t470, i32 0, i32 1
  %t472 = load ptr, ptr %t471
  store ptr %t472, ptr %l231, !tbaa !29
  %t473 = load ptr, ptr %l231, !tbaa !29
  store ptr %t473, ptr %l22, !tbaa !29
  %t474 = load ptr, ptr %l1, !tbaa !29
  store ptr %t474, ptr %l232, !tbaa !29
  %t475 = load ptr, ptr %l232, !tbaa !29
  %t476 = getelementptr { i64, [5 x i64] }, ptr %t475, i32 0, i32 1
  %t477 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t476, i32 0, i32 2
  %t478 = load ptr, ptr %t477
  store ptr %t478, ptr %l233, !tbaa !29
  %t479 = load ptr, ptr %l233, !tbaa !29
  store ptr %t479, ptr %l23, !tbaa !29
  br label %bb153
bb152:
  br label %bb161
bb153:
  store %olang.scope zeroinitializer, ptr %s18
  %t480 = load ptr, ptr %l0, !tbaa !29
  store ptr %t480, ptr %l234, !tbaa !29
  %t481 = load ptr, ptr %l234, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t481, { i64, ptr } { i64 7, ptr @.d126 })
  br label %bb154
bb154:
  %t482 = load ptr, ptr %l0, !tbaa !29
  store ptr %t482, ptr %l235, !tbaa !29
  %t483 = load ptr, ptr %l22, !tbaa !29
  store ptr %t483, ptr %l236, !tbaa !29
  %t484 = load ptr, ptr %l235, !tbaa !29
  %t485 = load ptr, ptr %l236, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t484, ptr %t485)
  br label %bb155
bb155:
  %t486 = load ptr, ptr %l23, !tbaa !29
  store ptr %t486, ptr %l237, !tbaa !29
  %t487 = load ptr, ptr %l237, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  store i1 %t488, ptr %l238, !tbaa !21
  %t489 = load i1, ptr %l238, !tbaa !21
  br i1 %t489, label %bb156, label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s19
  %t490 = load ptr, ptr %l0, !tbaa !29
  store ptr %t490, ptr %l239, !tbaa !29
  %t491 = load ptr, ptr %l239, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t491, { i64, ptr } { i64 2, ptr @.d127 })
  br label %bb158
bb157:
  br label %bb160
bb158:
  %t492 = load ptr, ptr %l0, !tbaa !29
  store ptr %t492, ptr %l240, !tbaa !29
  %t493 = load ptr, ptr %l23, !tbaa !29
  store ptr %t493, ptr %l241, !tbaa !29
  %t494 = load ptr, ptr %l240, !tbaa !29
  %t495 = load ptr, ptr %l241, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t494, ptr %t495)
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s19)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s18)
  br label %bb215
bb161:
  %t496 = load ptr, ptr %l1, !tbaa !29
  store ptr %t496, ptr %l242, !tbaa !29
  store i1 false, ptr %l243, !tbaa !21
  %t497 = load ptr, ptr %l242, !tbaa !29
  %t498 = icmp ne ptr %t497, null
  store i1 %t498, ptr %l244, !tbaa !21
  %t499 = load i1, ptr %l244, !tbaa !21
  br i1 %t499, label %bb162, label %bb163
bb162:
  %t500 = load ptr, ptr %l242, !tbaa !29
  %t501 = load i64, ptr %t500
  store i64 %t501, ptr %l245, !tbaa !24
  %t502 = load i64, ptr %l245, !tbaa !24
  %t503 = icmp eq i64 %t502, 15
  store i1 %t503, ptr %l243, !tbaa !21
  br label %bb163
bb163:
  %t504 = load i1, ptr %l243, !tbaa !21
  br i1 %t504, label %bb164, label %bb165
bb164:
  %t505 = load ptr, ptr %l1, !tbaa !29
  store ptr %t505, ptr %l246, !tbaa !29
  %t506 = load ptr, ptr %l246, !tbaa !29
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t506, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", ptr }, ptr %t507, i32 0, i32 1
  %t509 = load ptr, ptr %t508
  store ptr %t509, ptr %l247, !tbaa !29
  %t510 = load ptr, ptr %l247, !tbaa !29
  store ptr %t510, ptr %l24, !tbaa !29
  br label %bb166
bb165:
  br label %bb173
bb166:
  store %olang.scope zeroinitializer, ptr %s20
  %t511 = load ptr, ptr %l0, !tbaa !29
  store ptr %t511, ptr %l248, !tbaa !29
  %t512 = load ptr, ptr %l248, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t512, { i64, ptr } { i64 5, ptr @.d128 })
  br label %bb167
bb167:
  %t513 = load ptr, ptr %l24, !tbaa !29
  store ptr %t513, ptr %l249, !tbaa !29
  %t514 = load ptr, ptr %l249, !tbaa !29
  %t515 = icmp ne ptr %t514, null
  store i1 %t515, ptr %l250, !tbaa !21
  %t516 = load i1, ptr %l250, !tbaa !21
  br i1 %t516, label %bb168, label %bb169
bb168:
  store %olang.scope zeroinitializer, ptr %s21
  %t517 = load ptr, ptr %l0, !tbaa !29
  store ptr %t517, ptr %l251, !tbaa !29
  %t518 = load ptr, ptr %l251, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t518, { i64, ptr } { i64 1, ptr @.d129 })
  br label %bb170
bb169:
  br label %bb172
bb170:
  %t519 = load ptr, ptr %l0, !tbaa !29
  store ptr %t519, ptr %l252, !tbaa !29
  %t520 = load ptr, ptr %l24, !tbaa !29
  store ptr %t520, ptr %l253, !tbaa !29
  %t521 = load ptr, ptr %l252, !tbaa !29
  %t522 = load ptr, ptr %l253, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t521, ptr %t522)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s21)
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s20)
  br label %bb215
bb173:
  %t523 = load ptr, ptr %l1, !tbaa !29
  store ptr %t523, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t524 = load ptr, ptr %l254, !tbaa !29
  %t525 = icmp ne ptr %t524, null
  store i1 %t525, ptr %l256, !tbaa !21
  %t526 = load i1, ptr %l256, !tbaa !21
  br i1 %t526, label %bb174, label %bb175
bb174:
  %t527 = load ptr, ptr %l254, !tbaa !29
  %t528 = load i64, ptr %t527
  store i64 %t528, ptr %l257, !tbaa !24
  %t529 = load i64, ptr %l257, !tbaa !24
  %t530 = icmp eq i64 %t529, 16
  store i1 %t530, ptr %l255, !tbaa !21
  br label %bb175
bb175:
  %t531 = load i1, ptr %l255, !tbaa !21
  br i1 %t531, label %bb176, label %bb177
bb176:
  %t532 = load ptr, ptr %l1, !tbaa !29
  store ptr %t532, ptr %l258, !tbaa !29
  %t533 = load ptr, ptr %l258, !tbaa !29
  %t534 = getelementptr { i64, [5 x i64] }, ptr %t533, i32 0, i32 1
  %t535 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t534, i32 0, i32 1
  %t536 = load { i64, ptr }, ptr %t535
  store { i64, ptr } %t536, ptr %l259, !tbaa !27
  %t537 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t537, ptr %l25, !tbaa !27
  %t538 = load ptr, ptr %l1, !tbaa !29
  store ptr %t538, ptr %l260, !tbaa !29
  %t539 = load ptr, ptr %l260, !tbaa !29
  %t540 = getelementptr { i64, [5 x i64] }, ptr %t539, i32 0, i32 1
  %t541 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t540, i32 0, i32 2
  %t542 = load ptr, ptr %t541
  store ptr %t542, ptr %l261, !tbaa !29
  %t543 = load ptr, ptr %l261, !tbaa !29
  store ptr %t543, ptr %l26, !tbaa !29
  br label %bb178
bb177:
  br label %bb186
bb178:
  store %olang.scope zeroinitializer, ptr %s22
  %t544 = load ptr, ptr %l0, !tbaa !29
  store ptr %t544, ptr %l262, !tbaa !29
  %t545 = load ptr, ptr %l262, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t545, { i64, ptr } { i64 6, ptr @.d130 })
  br label %bb179
bb179:
  %t546 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t546, ptr %l263, !tbaa !27
  %t547 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t547, 0
  store i64 %t548, ptr %l264, !tbaa !24
  %t549 = load i64, ptr %l264, !tbaa !24
  %t550 = icmp sgt i64 %t549, 0
  store i1 %t550, ptr %l265, !tbaa !21
  %t551 = load i1, ptr %l265, !tbaa !21
  br i1 %t551, label %bb180, label %bb181
bb180:
  store %olang.scope zeroinitializer, ptr %s23
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l266, !tbaa !29
  %t553 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t553, ptr %l267, !tbaa !27
  %t554 = load ptr, ptr %l266, !tbaa !29
  %t555 = load { i64, ptr }, ptr %l267, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t554, { i64, ptr } %t555)
  br label %bb182
bb181:
  br label %bb184
bb182:
  %t556 = load ptr, ptr %l0, !tbaa !29
  store ptr %t556, ptr %l268, !tbaa !29
  %t557 = load ptr, ptr %l268, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t557, { i64, ptr } { i64 3, ptr @.d131 })
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s23)
  br label %bb184
bb184:
  %t558 = load ptr, ptr %l0, !tbaa !29
  store ptr %t558, ptr %l269, !tbaa !29
  %t559 = load ptr, ptr %l26, !tbaa !29
  store ptr %t559, ptr %l270, !tbaa !29
  %t560 = load ptr, ptr %l269, !tbaa !29
  %t561 = load ptr, ptr %l270, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t560, ptr %t561)
  br label %bb185
bb185:
  call void @__olang_scope_close(ptr %s22)
  br label %bb215
bb186:
  %t562 = load ptr, ptr %l1, !tbaa !29
  store ptr %t562, ptr %l271, !tbaa !29
  store i1 false, ptr %l272, !tbaa !21
  %t563 = load ptr, ptr %l271, !tbaa !29
  %t564 = icmp ne ptr %t563, null
  store i1 %t564, ptr %l273, !tbaa !21
  %t565 = load i1, ptr %l273, !tbaa !21
  br i1 %t565, label %bb187, label %bb188
bb187:
  %t566 = load ptr, ptr %l271, !tbaa !29
  %t567 = load i64, ptr %t566
  store i64 %t567, ptr %l274, !tbaa !24
  %t568 = load i64, ptr %l274, !tbaa !24
  %t569 = icmp eq i64 %t568, 17
  store i1 %t569, ptr %l272, !tbaa !21
  br label %bb188
bb188:
  %t570 = load i1, ptr %l272, !tbaa !21
  br i1 %t570, label %bb189, label %bb190
bb189:
  %t571 = load ptr, ptr %l1, !tbaa !29
  store ptr %t571, ptr %l275, !tbaa !29
  %t572 = load ptr, ptr %l275, !tbaa !29
  %t573 = getelementptr { i64, [5 x i64] }, ptr %t572, i32 0, i32 1
  %t574 = getelementptr { %"compiler/source:Span", ptr }, ptr %t573, i32 0, i32 1
  %t575 = load ptr, ptr %t574
  store ptr %t575, ptr %l276, !tbaa !29
  %t576 = load ptr, ptr %l276, !tbaa !29
  store ptr %t576, ptr %l27, !tbaa !29
  br label %bb191
bb190:
  br label %bb199
bb191:
  store %olang.scope zeroinitializer, ptr %s24
  %t577 = load ptr, ptr %l27, !tbaa !29
  store ptr %t577, ptr %l277, !tbaa !29
  %t578 = load ptr, ptr %l277, !tbaa !29
  %t579 = getelementptr %"compiler/ast:JoinS", ptr %t578, i32 0, i32 0
  %t580 = load i1, ptr %t579, !tbaa !21
  store i1 %t580, ptr %l278, !tbaa !21
  %t581 = load i1, ptr %l278, !tbaa !21
  br i1 %t581, label %bb192, label %bb193
bb192:
  store %olang.scope zeroinitializer, ptr %s25
  %t582 = load ptr, ptr %l0, !tbaa !29
  store ptr %t582, ptr %l279, !tbaa !29
  %t583 = load ptr, ptr %l279, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t583, { i64, ptr } { i64 4, ptr @.d132 })
  br label %bb194
bb193:
  br label %bb195
bb194:
  call void @__olang_scope_close(ptr %s25)
  br label %bb195
bb195:
  %t584 = load ptr, ptr %l0, !tbaa !29
  store ptr %t584, ptr %l280, !tbaa !29
  %t585 = load ptr, ptr %l280, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t585, { i64, ptr } { i64 5, ptr @.d133 })
  br label %bb196
bb196:
  %t586 = load ptr, ptr %l0, !tbaa !29
  store ptr %t586, ptr %l281, !tbaa !29
  %t587 = load ptr, ptr %l27, !tbaa !29
  store ptr %t587, ptr %l282, !tbaa !29
  %t588 = load ptr, ptr %l282, !tbaa !29
  %t589 = getelementptr %"compiler/ast:JoinS", ptr %t588, i32 0, i32 1
  %t590 = load { i64, ptr }, ptr %t589, !tbaa !27
  store { i64, ptr } %t590, ptr %l283, !tbaa !27
  %t591 = load ptr, ptr %l281, !tbaa !29
  %t592 = load { i64, ptr }, ptr %l283, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t591, { i64, ptr } %t592)
  br label %bb197
bb197:
  %t593 = load ptr, ptr %l0, !tbaa !29
  store ptr %t593, ptr %l284, !tbaa !29
  %t594 = load ptr, ptr %l27, !tbaa !29
  store ptr %t594, ptr %l285, !tbaa !29
  %t595 = load ptr, ptr %l285, !tbaa !29
  %t596 = getelementptr %"compiler/ast:JoinS", ptr %t595, i32 0, i32 2
  %t597 = load { i64, ptr }, ptr %t596, !tbaa !27
  store { i64, ptr } %t597, ptr %l286, !tbaa !27
  %t598 = load ptr, ptr %l284, !tbaa !29
  %t599 = load { i64, ptr }, ptr %l286, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t598, { i64, ptr } %t599)
  br label %bb198
bb198:
  call void @__olang_scope_close(ptr %s24)
  br label %bb215
bb199:
  %t600 = load ptr, ptr %l1, !tbaa !29
  store ptr %t600, ptr %l287, !tbaa !29
  store i1 false, ptr %l288, !tbaa !21
  %t601 = load ptr, ptr %l287, !tbaa !29
  %t602 = icmp ne ptr %t601, null
  store i1 %t602, ptr %l289, !tbaa !21
  %t603 = load i1, ptr %l289, !tbaa !21
  br i1 %t603, label %bb200, label %bb201
bb200:
  %t604 = load ptr, ptr %l287, !tbaa !29
  %t605 = load i64, ptr %t604
  store i64 %t605, ptr %l290, !tbaa !24
  %t606 = load i64, ptr %l290, !tbaa !24
  %t607 = icmp eq i64 %t606, 18
  store i1 %t607, ptr %l288, !tbaa !21
  br label %bb201
bb201:
  %t608 = load i1, ptr %l288, !tbaa !21
  br i1 %t608, label %bb202, label %bb203
bb202:
  %t609 = load ptr, ptr %l1, !tbaa !29
  store ptr %t609, ptr %l291, !tbaa !29
  %t610 = load ptr, ptr %l291, !tbaa !29
  %t611 = getelementptr { i64, [5 x i64] }, ptr %t610, i32 0, i32 1
  %t612 = getelementptr { %"compiler/source:Span", ptr }, ptr %t611, i32 0, i32 1
  %t613 = load ptr, ptr %t612
  store ptr %t613, ptr %l292, !tbaa !29
  %t614 = load ptr, ptr %l292, !tbaa !29
  store ptr %t614, ptr %l28, !tbaa !29
  br label %bb204
bb203:
  br label %bb207
bb204:
  store %olang.scope zeroinitializer, ptr %s26
  %t615 = load ptr, ptr %l0, !tbaa !29
  store ptr %t615, ptr %l293, !tbaa !29
  %t616 = load ptr, ptr %l293, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t616, { i64, ptr } { i64 6, ptr @.d134 })
  br label %bb205
bb205:
  %t617 = load ptr, ptr %l0, !tbaa !29
  store ptr %t617, ptr %l294, !tbaa !29
  %t618 = load ptr, ptr %l28, !tbaa !29
  store ptr %t618, ptr %l295, !tbaa !29
  %t619 = load ptr, ptr %l294, !tbaa !29
  %t620 = load ptr, ptr %l295, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t619, ptr %t620)
  br label %bb206
bb206:
  call void @__olang_scope_close(ptr %s26)
  br label %bb215
bb207:
  %t621 = load ptr, ptr %l1, !tbaa !29
  store ptr %t621, ptr %l296, !tbaa !29
  store i1 false, ptr %l297, !tbaa !21
  %t622 = load ptr, ptr %l296, !tbaa !29
  %t623 = icmp ne ptr %t622, null
  store i1 %t623, ptr %l298, !tbaa !21
  %t624 = load i1, ptr %l298, !tbaa !21
  br i1 %t624, label %bb208, label %bb209
bb208:
  %t625 = load ptr, ptr %l296, !tbaa !29
  %t626 = load i64, ptr %t625
  store i64 %t626, ptr %l299, !tbaa !24
  %t627 = load i64, ptr %l299, !tbaa !24
  %t628 = icmp eq i64 %t627, 19
  store i1 %t628, ptr %l297, !tbaa !21
  br label %bb209
bb209:
  %t629 = load i1, ptr %l297, !tbaa !21
  br i1 %t629, label %bb210, label %bb211
bb210:
  %t630 = load ptr, ptr %l1, !tbaa !29
  store ptr %t630, ptr %l300, !tbaa !29
  %t631 = load ptr, ptr %l300, !tbaa !29
  %t632 = getelementptr { i64, [5 x i64] }, ptr %t631, i32 0, i32 1
  %t633 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t632, i32 0, i32 1
  %t634 = load { i64, ptr }, ptr %t633
  store { i64, ptr } %t634, ptr %l301, !tbaa !27
  %t635 = load { i64, ptr }, ptr %l301, !tbaa !27
  store { i64, ptr } %t635, ptr %l29, !tbaa !27
  br label %bb212
bb211:
  br label %bb214
bb212:
  store %olang.scope zeroinitializer, ptr %s27
  %t636 = load ptr, ptr %l0, !tbaa !29
  store ptr %t636, ptr %l302, !tbaa !29
  %t637 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t637, ptr %l303, !tbaa !27
  %t638 = load ptr, ptr %l302, !tbaa !29
  %t639 = load { i64, ptr }, ptr %l303, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t638, { i64, ptr } %t639)
  br label %bb213
bb213:
  call void @__olang_scope_close(ptr %s27)
  br label %bb215
bb214:
  call void @__olang_check_failed(ptr @.c135)
  unreachable
bb215:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t2, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopBranch", ptr %t6, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l9, !tbaa !24
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l11, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l12, !tbaa !29
  %t15 = load ptr, ptr %l12, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopBranch", ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  store %"compiler/source:Span" %t17, ptr %l13
  %t18 = load ptr, ptr %l11, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l13
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t18, %"compiler/source:Span" %t19)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l14, !tbaa !29
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t21, i32 0, i32 5
  store ptr %t22, ptr %l15, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l16, !tbaa !29
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TopBranch", ptr %t24, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  store %"compiler/source:Span" %t26, ptr %l17
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l17
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t27, %"compiler/source:Span" %t28)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t30, { i64, ptr } { i64 1, ptr @.d136 })
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = getelementptr %"compiler/unparse:writer", ptr %t32, i32 0, i32 4
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = add i64 %t35, 1
  store i64 %t36, ptr %l21, !tbaa !24
  %t37 = load i64, ptr %l21, !tbaa !24
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = getelementptr %"compiler/unparse:writer", ptr %t38, i32 0, i32 4
  store i64 %t37, ptr %t39, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TopBranch", ptr %t41, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t44, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l24, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l25, !tbaa !24
  %t48 = load i64, ptr %l25, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l3, !tbaa !24
  store i64 %t49, ptr %l26, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  store i64 %t50, ptr %l27, !tbaa !24
  %t51 = load i64, ptr %l26, !tbaa !24
  %t52 = load i64, ptr %l27, !tbaa !24
  %t53 = icmp slt i64 %t51, %t52
  store i1 %t53, ptr %l28, !tbaa !21
  %t54 = load i1, ptr %l28, !tbaa !21
  %t55 = xor i1 %t54, true
  store i1 %t55, ptr %l29, !tbaa !21
  %t56 = load i1, ptr %l29, !tbaa !21
  br i1 %t56, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  %t58 = load i64, ptr %l3, !tbaa !24
  store i64 %t58, ptr %l31, !tbaa !24
  %t59 = load i64, ptr %l31, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t59
  %t63 = load ptr, ptr %t62, !tbaa !39
  store ptr %t63, ptr %l32, !tbaa !29
  %t64 = load ptr, ptr %l32, !tbaa !29
  store ptr %t64, ptr %l5, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l33, !tbaa !29
  %t66 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t66)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l34, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  store ptr %t68, ptr %l35, !tbaa !29
  %t69 = load ptr, ptr %l34, !tbaa !29
  %t70 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load i64, ptr %l3, !tbaa !24
  store i64 %t71, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l36, !tbaa !24
  %t73 = add i64 %t72, 1
  store i64 %t73, ptr %l37, !tbaa !24
  %t74 = load i64, ptr %l37, !tbaa !24
  store i64 %t74, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb8
bb15:
  call void @__olang_scope_close(ptr %s2)
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l38, !tbaa !29
  %t76 = load ptr, ptr %l38, !tbaa !29
  %t77 = getelementptr %"compiler/unparse:writer", ptr %t76, i32 0, i32 4
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l39, !tbaa !24
  %t79 = load i64, ptr %l39, !tbaa !24
  %t80 = sub i64 %t79, 1
  store i64 %t80, ptr %l40, !tbaa !24
  %t81 = load i64, ptr %l40, !tbaa !24
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"compiler/unparse:writer", ptr %t82, i32 0, i32 4
  store i64 %t81, ptr %t83, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l41, !tbaa !29
  %t85 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t85)
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l42, !tbaa !29
  %t87 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t87, { i64, ptr } { i64 1, ptr @.d137 })
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t2, { i64, ptr } { i64 3, ptr @.d138 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/ast:TopIf", ptr %t5, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t11, { i64, ptr } { i64 1, ptr @.d139 })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t18 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = getelementptr %"compiler/ast:TopIf", ptr %t20, i32 0, i32 2
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l11, !tbaa !29
  %t23 = load ptr, ptr %l11, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  store i1 %t24, ptr %l12, !tbaa !21
  %t25 = load i1, ptr %l12, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l13, !tbaa !29
  %t27 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t27, { i64, ptr } { i64 6, ptr @.d140 })
  br label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l17, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TopIf", ptr %t29, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l18, !tbaa !29
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  store i1 %t33, ptr %l19, !tbaa !21
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l14, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l15, !tbaa !29
  %t37 = load ptr, ptr %l15, !tbaa !29
  %t38 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l16, !tbaa !29
  %t40 = load ptr, ptr %l14, !tbaa !29
  %t41 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t40, ptr %t41)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l20, !tbaa !29
  %t43 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t43, { i64, ptr } { i64 6, ptr @.d141 })
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l21, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l22, !tbaa !29
  %t46 = load ptr, ptr %l22, !tbaa !29
  %t47 = getelementptr %"compiler/ast:TopIf", ptr %t46, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l23, !tbaa !29
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t50 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i32
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca i32
  %l87 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca ptr
  %l91 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i64
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l103 = alloca i1
  %l104 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l19, !tbaa !21
  %t4 = load i1, ptr %l19, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l20, !tbaa !24
  %t7 = load i64, ptr %l20, !tbaa !24
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l21, !tbaa !29
  %t11 = load ptr, ptr %l21, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l22, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l23, !tbaa !29
  %t17 = load ptr, ptr %l23, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l24, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t21, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb23
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l25, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l26, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l27, !tbaa !24
  %t27 = load i64, ptr %l27, !tbaa !24
  store i64 %t27, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l5, !tbaa !24
  store i64 %t28, ptr %l28, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  store i64 %t29, ptr %l29, !tbaa !24
  %t30 = load i64, ptr %l28, !tbaa !24
  %t31 = load i64, ptr %l29, !tbaa !24
  %t32 = icmp slt i64 %t30, %t31
  store i1 %t32, ptr %l30, !tbaa !21
  %t33 = load i1, ptr %l30, !tbaa !21
  %t34 = xor i1 %t33, true
  store i1 %t34, ptr %l31, !tbaa !21
  %t35 = load i1, ptr %l31, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t36 = load i64, ptr %l5, !tbaa !24
  store i64 %t36, ptr %l32, !tbaa !24
  %t37 = load i64, ptr %l32, !tbaa !24
  store i64 %t37, ptr %l7, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t38, ptr %l33, !tbaa !27
  %t39 = load i64, ptr %l5, !tbaa !24
  store i64 %t39, ptr %l34, !tbaa !24
  %t40 = load i64, ptr %l34, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i32, ptr %t42, i64 %t40
  %t44 = load i32, ptr %t43, !tbaa !33
  store i32 %t44, ptr %l35, !tbaa !23
  %t45 = load i32, ptr %l35, !tbaa !23
  store i32 %t45, ptr %l8, !tbaa !23
  %t46 = load i64, ptr %l7, !tbaa !24
  store i64 %t46, ptr %l36, !tbaa !24
  %t47 = load i64, ptr %l36, !tbaa !24
  %t48 = icmp sgt i64 %t47, 0
  store i1 %t48, ptr %l37, !tbaa !21
  %t49 = load i1, ptr %l37, !tbaa !21
  br i1 %t49, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l38, !tbaa !29
  %t51 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t51, { i64, ptr } { i64 1, ptr @.d142 })
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l39, !tbaa !29
  %t53 = load i32, ptr %l8, !tbaa !23
  store i32 %t53, ptr %l40, !tbaa !23
  %t54 = load ptr, ptr %l39, !tbaa !29
  %t55 = load i32, ptr %l40, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t54, i32 %t55)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t56 = load i64, ptr %l5, !tbaa !24
  store i64 %t56, ptr %l41, !tbaa !24
  %t57 = load i64, ptr %l41, !tbaa !24
  %t58 = add i64 %t57, 1
  store i64 %t58, ptr %l42, !tbaa !24
  %t59 = load i64, ptr %l42, !tbaa !24
  store i64 %t59, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb6
bb16:
  call void @__olang_scope_close(ptr %s2)
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t60, ptr %l43, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l44, !tbaa !24
  %t63 = load i64, ptr %l44, !tbaa !24
  %t64 = icmp sgt i64 %t63, 0
  store i1 %t64, ptr %l45, !tbaa !21
  %t65 = load i1, ptr %l45, !tbaa !21
  br i1 %t65, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l46, !tbaa !29
  %t67 = load ptr, ptr %l46, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t67, { i64, ptr } { i64 1, ptr @.d143 })
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l47, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t69, ptr %l48, !tbaa !27
  %t70 = load ptr, ptr %l47, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l48, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t70, { i64, ptr } %t71)
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l49, !tbaa !29
  %t73 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t73, { i64, ptr } { i64 1, ptr @.d144 })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s1)
  br label %bb84
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t75 = load ptr, ptr %l50, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  store i1 %t76, ptr %l52, !tbaa !21
  %t77 = load i1, ptr %l52, !tbaa !21
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l50, !tbaa !29
  %t79 = load i64, ptr %t78
  store i64 %t79, ptr %l53, !tbaa !24
  %t80 = load i64, ptr %l53, !tbaa !24
  %t81 = icmp eq i64 %t80, 1
  store i1 %t81, ptr %l51, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l51, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l1, !tbaa !29
  store ptr %t83, ptr %l54, !tbaa !29
  %t84 = load ptr, ptr %l54, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l55, !tbaa !29
  %t88 = load ptr, ptr %l55, !tbaa !29
  store ptr %t88, ptr %l9, !tbaa !29
  br label %bb28
bb27:
  br label %bb31
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l56, !tbaa !29
  %t90 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t90, { i64, ptr } { i64 2, ptr @.d145 })
  br label %bb29
bb29:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l57, !tbaa !29
  %t92 = load ptr, ptr %l9, !tbaa !29
  store ptr %t92, ptr %l58, !tbaa !29
  %t93 = load ptr, ptr %l57, !tbaa !29
  %t94 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t93, ptr %t94, i1 true)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb84
bb31:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t96 = load ptr, ptr %l59, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  store i1 %t97, ptr %l61, !tbaa !21
  %t98 = load i1, ptr %l61, !tbaa !21
  br i1 %t98, label %bb32, label %bb33
bb32:
  %t99 = load ptr, ptr %l59, !tbaa !29
  %t100 = load i64, ptr %t99
  store i64 %t100, ptr %l62, !tbaa !24
  %t101 = load i64, ptr %l62, !tbaa !24
  %t102 = icmp eq i64 %t101, 2
  store i1 %t102, ptr %l60, !tbaa !21
  br label %bb33
bb33:
  %t103 = load i1, ptr %l60, !tbaa !21
  br i1 %t103, label %bb34, label %bb35
bb34:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l63, !tbaa !29
  %t105 = load ptr, ptr %l63, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", ptr }, ptr %t106, i32 0, i32 1
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l64, !tbaa !29
  %t109 = load ptr, ptr %l64, !tbaa !29
  store ptr %t109, ptr %l10, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  store %olang.scope zeroinitializer, ptr %s8
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l65, !tbaa !29
  %t111 = load ptr, ptr %l10, !tbaa !29
  store ptr %t111, ptr %l66, !tbaa !29
  %t112 = load ptr, ptr %l65, !tbaa !29
  %t113 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t112, ptr %t113)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb84
bb38:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t115 = load ptr, ptr %l67, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  store i1 %t116, ptr %l69, !tbaa !21
  %t117 = load i1, ptr %l69, !tbaa !21
  br i1 %t117, label %bb39, label %bb40
bb39:
  %t118 = load ptr, ptr %l67, !tbaa !29
  %t119 = load i64, ptr %t118
  store i64 %t119, ptr %l70, !tbaa !24
  %t120 = load i64, ptr %l70, !tbaa !24
  %t121 = icmp eq i64 %t120, 3
  store i1 %t121, ptr %l68, !tbaa !21
  br label %bb40
bb40:
  %t122 = load i1, ptr %l68, !tbaa !21
  br i1 %t122, label %bb41, label %bb42
bb41:
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l71, !tbaa !29
  %t124 = load ptr, ptr %l71, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr }, ptr %t125, i32 0, i32 1
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l72, !tbaa !29
  %t128 = load ptr, ptr %l72, !tbaa !29
  store ptr %t128, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l73, !tbaa !29
  %t130 = load ptr, ptr %l11, !tbaa !29
  store ptr %t130, ptr %l74, !tbaa !29
  %t131 = load ptr, ptr %l73, !tbaa !29
  %t132 = load ptr, ptr %l74, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t131, ptr %t132)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s9)
  br label %bb84
bb45:
  %t133 = load ptr, ptr %l1, !tbaa !29
  store ptr %t133, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t134 = load ptr, ptr %l75, !tbaa !29
  %t135 = icmp ne ptr %t134, null
  store i1 %t135, ptr %l77, !tbaa !21
  %t136 = load i1, ptr %l77, !tbaa !21
  br i1 %t136, label %bb46, label %bb47
bb46:
  %t137 = load ptr, ptr %l75, !tbaa !29
  %t138 = load i64, ptr %t137
  store i64 %t138, ptr %l78, !tbaa !24
  %t139 = load i64, ptr %l78, !tbaa !24
  %t140 = icmp eq i64 %t139, 4
  store i1 %t140, ptr %l76, !tbaa !21
  br label %bb47
bb47:
  %t141 = load i1, ptr %l76, !tbaa !21
  br i1 %t141, label %bb48, label %bb49
bb48:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l79, !tbaa !29
  %t143 = load ptr, ptr %l79, !tbaa !29
  %t144 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t144, i32 0, i32 1
  %t146 = load ptr, ptr %t145
  store ptr %t146, ptr %l80, !tbaa !29
  %t147 = load ptr, ptr %l80, !tbaa !29
  store ptr %t147, ptr %l12, !tbaa !29
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l81, !tbaa !29
  %t149 = load ptr, ptr %l81, !tbaa !29
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t150, i32 0, i32 2
  %t152 = load i32, ptr %t151
  store i32 %t152, ptr %l82, !tbaa !23
  %t153 = load i32, ptr %l82, !tbaa !23
  store i32 %t153, ptr %l13, !tbaa !23
  br label %bb50
bb49:
  br label %bb57
bb50:
  store %olang.scope zeroinitializer, ptr %s10
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l83, !tbaa !29
  %t155 = load ptr, ptr %l12, !tbaa !29
  store ptr %t155, ptr %l84, !tbaa !29
  %t156 = load ptr, ptr %l83, !tbaa !29
  %t157 = load ptr, ptr %l84, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t156, ptr %t157)
  br label %bb51
bb51:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l85, !tbaa !29
  %t159 = load ptr, ptr %l85, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t159, { i64, ptr } { i64 1, ptr @.d146 })
  br label %bb52
bb52:
  %t160 = load i32, ptr %l13, !tbaa !23
  store i32 %t160, ptr %l86, !tbaa !23
  %t161 = load i32, ptr %l86, !tbaa !23
  %t162 = icmp ne i32 %t161, 0
  store i1 %t162, ptr %l87, !tbaa !21
  %t163 = load i1, ptr %l87, !tbaa !21
  br i1 %t163, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s11
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l88, !tbaa !29
  %t165 = load i32, ptr %l13, !tbaa !23
  store i32 %t165, ptr %l89, !tbaa !23
  %t166 = load ptr, ptr %l88, !tbaa !29
  %t167 = load i32, ptr %l89, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t166, i32 %t167)
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_scope_close(ptr %s11)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb57:
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t169 = load ptr, ptr %l90, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  store i1 %t170, ptr %l92, !tbaa !21
  %t171 = load i1, ptr %l92, !tbaa !21
  br i1 %t171, label %bb58, label %bb59
bb58:
  %t172 = load ptr, ptr %l90, !tbaa !29
  %t173 = load i64, ptr %t172
  store i64 %t173, ptr %l93, !tbaa !24
  %t174 = load i64, ptr %l93, !tbaa !24
  %t175 = icmp eq i64 %t174, 5
  store i1 %t175, ptr %l91, !tbaa !21
  br label %bb59
bb59:
  %t176 = load i1, ptr %l91, !tbaa !21
  br i1 %t176, label %bb60, label %bb61
bb60:
  %t177 = load ptr, ptr %l1, !tbaa !29
  store ptr %t177, ptr %l94, !tbaa !29
  %t178 = load ptr, ptr %l94, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t179, i32 0, i32 1
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l95, !tbaa !29
  %t182 = load ptr, ptr %l95, !tbaa !29
  store ptr %t182, ptr %l14, !tbaa !29
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l96, !tbaa !29
  %t184 = load ptr, ptr %l96, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t184, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t185, i32 0, i32 2
  %t187 = load i1, ptr %t186
  store i1 %t187, ptr %l97, !tbaa !21
  %t188 = load i1, ptr %l97, !tbaa !21
  store i1 %t188, ptr %l15, !tbaa !21
  %t189 = load ptr, ptr %l1, !tbaa !29
  store ptr %t189, ptr %l98, !tbaa !29
  %t190 = load ptr, ptr %l98, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t191, i32 0, i32 3
  %t193 = load i1, ptr %t192
  store i1 %t193, ptr %l99, !tbaa !21
  %t194 = load i1, ptr %l99, !tbaa !21
  store i1 %t194, ptr %l16, !tbaa !21
  br label %bb62
bb61:
  br label %bb83
bb62:
  store %olang.scope zeroinitializer, ptr %s12
  %t195 = load i1, ptr %l16, !tbaa !21
  store i1 %t195, ptr %l100, !tbaa !21
  %t196 = load i1, ptr %l100, !tbaa !21
  br i1 %t196, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s13
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l101, !tbaa !29
  %t198 = load ptr, ptr %l101, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t198, { i64, ptr } { i64 3, ptr @.d147 })
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s13)
  br label %bb66
bb66:
  %t199 = load i1, ptr %l16, !tbaa !21
  store i1 %t199, ptr %l102, !tbaa !21
  %t200 = load i1, ptr %l102, !tbaa !21
  br i1 %t200, label %bb67, label %bb68
bb67:
  %t201 = load i1, ptr %l15, !tbaa !21
  store i1 %t201, ptr %l104, !tbaa !21
  %t202 = load i1, ptr %l104, !tbaa !21
  store i1 %t202, ptr %l103, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb69
bb69:
  %t203 = load i1, ptr %l103, !tbaa !21
  br i1 %t203, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s14
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l105, !tbaa !29
  %t205 = load ptr, ptr %l105, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t205, { i64, ptr } { i64 1, ptr @.d148 })
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_scope_close(ptr %s14)
  br label %bb73
bb73:
  %t206 = load i1, ptr %l15, !tbaa !21
  store i1 %t206, ptr %l106, !tbaa !21
  %t207 = load i1, ptr %l106, !tbaa !21
  br i1 %t207, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s15
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l107, !tbaa !29
  %t209 = load ptr, ptr %l107, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t209, { i64, ptr } { i64 3, ptr @.d149 })
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_scope_close(ptr %s15)
  br label %bb77
bb77:
  %t210 = load ptr, ptr %l14, !tbaa !29
  store ptr %t210, ptr %l108, !tbaa !29
  %t211 = load ptr, ptr %l108, !tbaa !29
  %t212 = icmp ne ptr %t211, null
  store i1 %t212, ptr %l109, !tbaa !21
  %t213 = load i1, ptr %l109, !tbaa !21
  br i1 %t213, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s16
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l110, !tbaa !29
  %t215 = load ptr, ptr %l110, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t215, { i64, ptr } { i64 1, ptr @.d150 })
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t216, ptr %l111, !tbaa !29
  %t217 = load ptr, ptr %l14, !tbaa !29
  store ptr %t217, ptr %l112, !tbaa !29
  %t218 = load ptr, ptr %l111, !tbaa !29
  %t219 = load ptr, ptr %l112, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t218, ptr %t219)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s16)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s12)
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @.c151)
  unreachable
bb84:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i64
  %l88 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca i32
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca ptr
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca i1
  %l124 = alloca i1
  %l125 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l140 = alloca ptr
  %l141 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l17, !tbaa !21
  %t4 = load i1, ptr %l17, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l18, !tbaa !24
  %t7 = load i64, ptr %l18, !tbaa !24
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l19, !tbaa !29
  %t11 = load ptr, ptr %l19, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l20, !tbaa !29
  %t15 = load ptr, ptr %l20, !tbaa !29
  store ptr %t15, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb19
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l21, !tbaa !29
  %t17 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t17, { i64, ptr } { i64 6, ptr @.d152 })
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l22, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l23, !tbaa !29
  %t20 = load ptr, ptr %l23, !tbaa !29
  %t21 = getelementptr %"compiler/ast:StructBody", ptr %t20, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l24, !tbaa !27
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t23, { i64, ptr } %t24)
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l25, !tbaa !29
  %t26 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t26, { i64, ptr } { i64 1, ptr @.d153 })
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l26, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l27, !tbaa !29
  %t29 = load ptr, ptr %l27, !tbaa !29
  %t30 = getelementptr %"compiler/ast:StructBody", ptr %t29, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l28, !tbaa !27
  %t32 = load ptr, ptr %l26, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t32, { i64, ptr } %t33)
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l29, !tbaa !29
  %t35 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t35, { i64, ptr } { i64 1, ptr @.d154 })
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l30, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  store ptr %t37, ptr %l31, !tbaa !29
  %t38 = load ptr, ptr %l31, !tbaa !29
  %t39 = getelementptr %"compiler/ast:StructBody", ptr %t38, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l32, !tbaa !29
  %t41 = load ptr, ptr %l30, !tbaa !29
  %t42 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t41, ptr %t42, i1 false)
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l33, !tbaa !29
  %t44 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t44, { i64, ptr } { i64 1, ptr @.d155 })
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l34, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  store ptr %t46, ptr %l35, !tbaa !29
  %t47 = load ptr, ptr %l35, !tbaa !29
  %t48 = getelementptr %"compiler/ast:StructBody", ptr %t47, i32 0, i32 2
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l36, !tbaa !27
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t50, { i64, ptr } %t51)
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l2, !tbaa !29
  store ptr %t52, ptr %l37, !tbaa !29
  %t53 = load ptr, ptr %l37, !tbaa !29
  %t54 = getelementptr %"compiler/ast:StructBody", ptr %t53, i32 0, i32 4
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  %t58 = extractvalue { i64, ptr } zeroinitializer, 0
  %t59 = icmp eq i64 %t57, %t58
  %t60 = extractvalue { i64, ptr } %t56, 1
  %t61 = extractvalue { i64, ptr } zeroinitializer, 1
  %t62 = icmp eq ptr %t60, %t61
  %t63 = and i1 %t59, %t62
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %l39, !tbaa !21
  %t65 = load i1, ptr %l39, !tbaa !21
  br i1 %t65, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l40, !tbaa !29
  %t67 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t67, { i64, ptr } { i64 10, ptr @.d156 })
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l41, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  store ptr %t69, ptr %l42, !tbaa !29
  %t70 = load ptr, ptr %l42, !tbaa !29
  %t71 = getelementptr %"compiler/ast:StructBody", ptr %t70, i32 0, i32 4
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l43, !tbaa !27
  %t73 = load ptr, ptr %l41, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l43, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t73, { i64, ptr } %t74)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  br label %bb81
bb19:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  store i1 %t77, ptr %l46, !tbaa !21
  %t78 = load i1, ptr %l46, !tbaa !21
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l44, !tbaa !29
  %t80 = load i64, ptr %t79
  store i64 %t80, ptr %l47, !tbaa !24
  %t81 = load i64, ptr %l47, !tbaa !24
  %t82 = icmp eq i64 %t81, 1
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb21
bb21:
  %t83 = load i1, ptr %l45, !tbaa !21
  br i1 %t83, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l48, !tbaa !29
  %t85 = load ptr, ptr %l48, !tbaa !29
  %t86 = getelementptr { i64, [2 x i64] }, ptr %t85, i32 0, i32 1
  %t87 = getelementptr { { i64, ptr } }, ptr %t86, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87
  store { i64, ptr } %t88, ptr %l49, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t89, ptr %l3, !tbaa !27
  br label %bb24
bb23:
  br label %bb42
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l50, !tbaa !29
  %t91 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t91, { i64, ptr } { i64 6, ptr @.d157 })
  br label %bb25
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l51, !tbaa !29
  %t93 = load ptr, ptr %l51, !tbaa !29
  %t94 = getelementptr %"compiler/unparse:writer", ptr %t93, i32 0, i32 4
  %t95 = load i64, ptr %t94, !tbaa !24
  store i64 %t95, ptr %l52, !tbaa !24
  %t96 = load i64, ptr %l52, !tbaa !24
  %t97 = add i64 %t96, 1
  store i64 %t97, ptr %l53, !tbaa !24
  %t98 = load i64, ptr %l53, !tbaa !24
  %t99 = load ptr, ptr %l51, !tbaa !29
  %t100 = getelementptr %"compiler/unparse:writer", ptr %t99, i32 0, i32 4
  store i64 %t98, ptr %t100, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t101, ptr %l54, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t102, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t103, ptr %l55, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l56, !tbaa !24
  %t106 = load i64, ptr %l56, !tbaa !24
  store i64 %t106, ptr %l6, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load i64, ptr %l5, !tbaa !24
  store i64 %t107, ptr %l57, !tbaa !24
  %t108 = load i64, ptr %l6, !tbaa !24
  store i64 %t108, ptr %l58, !tbaa !24
  %t109 = load i64, ptr %l57, !tbaa !24
  %t110 = load i64, ptr %l58, !tbaa !24
  %t111 = icmp slt i64 %t109, %t110
  store i1 %t111, ptr %l59, !tbaa !21
  %t112 = load i1, ptr %l59, !tbaa !21
  %t113 = xor i1 %t112, true
  store i1 %t113, ptr %l60, !tbaa !21
  %t114 = load i1, ptr %l60, !tbaa !21
  br i1 %t114, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb28:
  br label %bb29
bb29:
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t115, ptr %l61, !tbaa !27
  %t116 = load i64, ptr %l5, !tbaa !24
  store i64 %t116, ptr %l62, !tbaa !24
  %t117 = load i64, ptr %l62, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr ptr, ptr %t119, i64 %t117
  %t121 = load ptr, ptr %t120, !tbaa !39
  store ptr %t121, ptr %l63, !tbaa !29
  %t122 = load ptr, ptr %l63, !tbaa !29
  store ptr %t122, ptr %l7, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l64, !tbaa !29
  %t124 = load ptr, ptr %l64, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t124)
  br label %bb30
bb30:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l65, !tbaa !29
  %t126 = load ptr, ptr %l7, !tbaa !29
  store ptr %t126, ptr %l66, !tbaa !29
  %t127 = load ptr, ptr %l66, !tbaa !29
  %t128 = getelementptr %"compiler/ast:CaseDecl", ptr %t127, i32 0, i32 1
  %t129 = load i32, ptr %t128, !tbaa !23
  store i32 %t129, ptr %l67, !tbaa !23
  %t130 = load ptr, ptr %l65, !tbaa !29
  %t131 = load i32, ptr %l67, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t130, i32 %t131)
  br label %bb31
bb31:
  %t132 = load ptr, ptr %l7, !tbaa !29
  store ptr %t132, ptr %l68, !tbaa !29
  %t133 = load ptr, ptr %l68, !tbaa !29
  %t134 = getelementptr %"compiler/ast:CaseDecl", ptr %t133, i32 0, i32 2
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  store { i64, ptr } %t135, ptr %l69, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l70, !tbaa !24
  %t138 = load i64, ptr %l70, !tbaa !24
  %t139 = icmp sgt i64 %t138, 0
  store i1 %t139, ptr %l71, !tbaa !21
  %t140 = load i1, ptr %l71, !tbaa !21
  br i1 %t140, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l72, !tbaa !29
  %t142 = load ptr, ptr %l72, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t142, { i64, ptr } { i64 1, ptr @.d158 })
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l73, !tbaa !29
  %t144 = load ptr, ptr %l7, !tbaa !29
  store ptr %t144, ptr %l74, !tbaa !29
  %t145 = load ptr, ptr %l74, !tbaa !29
  %t146 = getelementptr %"compiler/ast:CaseDecl", ptr %t145, i32 0, i32 2
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  store { i64, ptr } %t147, ptr %l75, !tbaa !27
  %t148 = load ptr, ptr %l73, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l75, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t148, { i64, ptr } %t149)
  br label %bb35
bb35:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l76, !tbaa !29
  %t151 = load ptr, ptr %l76, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t151, { i64, ptr } { i64 1, ptr @.d159 })
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t152 = load i64, ptr %l5, !tbaa !24
  store i64 %t152, ptr %l77, !tbaa !24
  %t153 = load i64, ptr %l77, !tbaa !24
  %t154 = add i64 %t153, 1
  store i64 %t154, ptr %l78, !tbaa !24
  %t155 = load i64, ptr %l78, !tbaa !24
  store i64 %t155, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb26
bb39:
  call void @__olang_scope_close(ptr %s4)
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l79, !tbaa !29
  %t157 = load ptr, ptr %l79, !tbaa !29
  %t158 = getelementptr %"compiler/unparse:writer", ptr %t157, i32 0, i32 4
  %t159 = load i64, ptr %t158, !tbaa !24
  store i64 %t159, ptr %l80, !tbaa !24
  %t160 = load i64, ptr %l80, !tbaa !24
  %t161 = sub i64 %t160, 1
  store i64 %t161, ptr %l81, !tbaa !24
  %t162 = load i64, ptr %l81, !tbaa !24
  %t163 = load ptr, ptr %l79, !tbaa !29
  %t164 = getelementptr %"compiler/unparse:writer", ptr %t163, i32 0, i32 4
  store i64 %t162, ptr %t164, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l82, !tbaa !29
  %t166 = load ptr, ptr %l82, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t166)
  br label %bb40
bb40:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l83, !tbaa !29
  %t168 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t168, { i64, ptr } { i64 1, ptr @.d160 })
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb81
bb42:
  %t169 = load ptr, ptr %l1, !tbaa !29
  store ptr %t169, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t170 = load ptr, ptr %l84, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  store i1 %t171, ptr %l86, !tbaa !21
  %t172 = load i1, ptr %l86, !tbaa !21
  br i1 %t172, label %bb43, label %bb44
bb43:
  %t173 = load ptr, ptr %l84, !tbaa !29
  %t174 = load i64, ptr %t173
  store i64 %t174, ptr %l87, !tbaa !24
  %t175 = load i64, ptr %l87, !tbaa !24
  %t176 = icmp eq i64 %t175, 2
  store i1 %t176, ptr %l85, !tbaa !21
  br label %bb44
bb44:
  %t177 = load i1, ptr %l85, !tbaa !21
  br i1 %t177, label %bb45, label %bb46
bb45:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l88, !tbaa !29
  %t179 = load ptr, ptr %l88, !tbaa !29
  %t180 = getelementptr { i64, [2 x i64] }, ptr %t179, i32 0, i32 1
  %t181 = getelementptr { { i64, ptr } }, ptr %t180, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181
  store { i64, ptr } %t182, ptr %l89, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t183, ptr %l8, !tbaa !27
  br label %bb47
bb46:
  br label %bb64
bb47:
  store %olang.scope zeroinitializer, ptr %s8
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l90, !tbaa !29
  %t185 = load ptr, ptr %l90, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t185, { i64, ptr } { i64 7, ptr @.d161 })
  br label %bb48
bb48:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l91, !tbaa !29
  %t187 = load ptr, ptr %l91, !tbaa !29
  %t188 = getelementptr %"compiler/unparse:writer", ptr %t187, i32 0, i32 4
  %t189 = load i64, ptr %t188, !tbaa !24
  store i64 %t189, ptr %l92, !tbaa !24
  %t190 = load i64, ptr %l92, !tbaa !24
  %t191 = add i64 %t190, 1
  store i64 %t191, ptr %l93, !tbaa !24
  %t192 = load i64, ptr %l93, !tbaa !24
  %t193 = load ptr, ptr %l91, !tbaa !29
  %t194 = getelementptr %"compiler/unparse:writer", ptr %t193, i32 0, i32 4
  store i64 %t192, ptr %t194, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s9
  %t195 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t195, ptr %l94, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t196, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t197, ptr %l95, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  store i64 %t199, ptr %l96, !tbaa !24
  %t200 = load i64, ptr %l96, !tbaa !24
  store i64 %t200, ptr %l11, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t201 = load i64, ptr %l10, !tbaa !24
  store i64 %t201, ptr %l97, !tbaa !24
  %t202 = load i64, ptr %l11, !tbaa !24
  store i64 %t202, ptr %l98, !tbaa !24
  %t203 = load i64, ptr %l97, !tbaa !24
  %t204 = load i64, ptr %l98, !tbaa !24
  %t205 = icmp slt i64 %t203, %t204
  store i1 %t205, ptr %l99, !tbaa !21
  %t206 = load i1, ptr %l99, !tbaa !21
  %t207 = xor i1 %t206, true
  store i1 %t207, ptr %l100, !tbaa !21
  %t208 = load i1, ptr %l100, !tbaa !21
  br i1 %t208, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb51:
  br label %bb52
bb52:
  %t209 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t209, ptr %l101, !tbaa !27
  %t210 = load i64, ptr %l10, !tbaa !24
  store i64 %t210, ptr %l102, !tbaa !24
  %t211 = load i64, ptr %l102, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr ptr, ptr %t213, i64 %t211
  %t215 = load ptr, ptr %t214, !tbaa !39
  store ptr %t215, ptr %l103, !tbaa !29
  %t216 = load ptr, ptr %l103, !tbaa !29
  store ptr %t216, ptr %l12, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l104, !tbaa !29
  %t218 = load ptr, ptr %l104, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t218)
  br label %bb53
bb53:
  %t219 = load ptr, ptr %l12, !tbaa !29
  store ptr %t219, ptr %l105, !tbaa !29
  %t220 = load ptr, ptr %l105, !tbaa !29
  %t221 = getelementptr %"compiler/ast:Func", ptr %t220, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  store ptr %t222, ptr %l106, !tbaa !29
  %t223 = load ptr, ptr %l106, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  store i1 %t224, ptr %l107, !tbaa !21
  %t225 = load i1, ptr %l107, !tbaa !21
  br i1 %t225, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s11
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l108, !tbaa !29
  %t227 = load ptr, ptr %l108, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t227, { i64, ptr } { i64 4, ptr @.d162 })
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb57:
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l109, !tbaa !29
  %t229 = load ptr, ptr %l12, !tbaa !29
  store ptr %t229, ptr %l110, !tbaa !29
  %t230 = load ptr, ptr %l110, !tbaa !29
  %t231 = getelementptr %"compiler/ast:Func", ptr %t230, i32 0, i32 2
  %t232 = load i32, ptr %t231, !tbaa !23
  store i32 %t232, ptr %l111, !tbaa !23
  %t233 = load ptr, ptr %l109, !tbaa !29
  %t234 = load i32, ptr %l111, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t233, i32 %t234)
  br label %bb58
bb58:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l112, !tbaa !29
  %t236 = load ptr, ptr %l12, !tbaa !29
  store ptr %t236, ptr %l113, !tbaa !29
  %t237 = load ptr, ptr %l113, !tbaa !29
  %t238 = getelementptr %"compiler/ast:Func", ptr %t237, i32 0, i32 3
  %t239 = load ptr, ptr %t238, !tbaa !29
  store ptr %t239, ptr %l114, !tbaa !29
  %t240 = load ptr, ptr %l112, !tbaa !29
  %t241 = load ptr, ptr %l114, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t240, ptr %t241, i1 false)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s12
  %t242 = load i64, ptr %l10, !tbaa !24
  store i64 %t242, ptr %l115, !tbaa !24
  %t243 = load i64, ptr %l115, !tbaa !24
  %t244 = add i64 %t243, 1
  store i64 %t244, ptr %l116, !tbaa !24
  %t245 = load i64, ptr %l116, !tbaa !24
  store i64 %t245, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb49
bb61:
  call void @__olang_scope_close(ptr %s9)
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l117, !tbaa !29
  %t247 = load ptr, ptr %l117, !tbaa !29
  %t248 = getelementptr %"compiler/unparse:writer", ptr %t247, i32 0, i32 4
  %t249 = load i64, ptr %t248, !tbaa !24
  store i64 %t249, ptr %l118, !tbaa !24
  %t250 = load i64, ptr %l118, !tbaa !24
  %t251 = sub i64 %t250, 1
  store i64 %t251, ptr %l119, !tbaa !24
  %t252 = load i64, ptr %l119, !tbaa !24
  %t253 = load ptr, ptr %l117, !tbaa !29
  %t254 = getelementptr %"compiler/unparse:writer", ptr %t253, i32 0, i32 4
  store i64 %t252, ptr %t254, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l120, !tbaa !29
  %t256 = load ptr, ptr %l120, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t256)
  br label %bb62
bb62:
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l121, !tbaa !29
  %t258 = load ptr, ptr %l121, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t258, { i64, ptr } { i64 1, ptr @.d163 })
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  br label %bb81
bb64:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t260 = load ptr, ptr %l122, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  store i1 %t261, ptr %l124, !tbaa !21
  %t262 = load i1, ptr %l124, !tbaa !21
  br i1 %t262, label %bb65, label %bb66
bb65:
  %t263 = load ptr, ptr %l122, !tbaa !29
  %t264 = load i64, ptr %t263
  store i64 %t264, ptr %l125, !tbaa !24
  %t265 = load i64, ptr %l125, !tbaa !24
  %t266 = icmp eq i64 %t265, 3
  store i1 %t266, ptr %l123, !tbaa !21
  br label %bb66
bb66:
  %t267 = load i1, ptr %l123, !tbaa !21
  br i1 %t267, label %bb67, label %bb68
bb67:
  %t268 = load ptr, ptr %l1, !tbaa !29
  store ptr %t268, ptr %l126, !tbaa !29
  %t269 = load ptr, ptr %l126, !tbaa !29
  %t270 = getelementptr { i64, [2 x i64] }, ptr %t269, i32 0, i32 1
  %t271 = getelementptr { ptr, ptr }, ptr %t270, i32 0, i32 0
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l127, !tbaa !29
  %t273 = load ptr, ptr %l127, !tbaa !29
  store ptr %t273, ptr %l13, !tbaa !29
  %t274 = load ptr, ptr %l1, !tbaa !29
  store ptr %t274, ptr %l128, !tbaa !29
  %t275 = load ptr, ptr %l128, !tbaa !29
  %t276 = getelementptr { i64, [2 x i64] }, ptr %t275, i32 0, i32 1
  %t277 = getelementptr { ptr, ptr }, ptr %t276, i32 0, i32 1
  %t278 = load ptr, ptr %t277
  store ptr %t278, ptr %l129, !tbaa !29
  %t279 = load ptr, ptr %l129, !tbaa !29
  store ptr %t279, ptr %l14, !tbaa !29
  br label %bb69
bb68:
  br label %bb80
bb69:
  store %olang.scope zeroinitializer, ptr %s13
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l130, !tbaa !29
  %t281 = load ptr, ptr %l13, !tbaa !29
  store ptr %t281, ptr %l131, !tbaa !29
  %t282 = load ptr, ptr %l130, !tbaa !29
  %t283 = load ptr, ptr %l131, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t282, ptr %t283)
  br label %bb70
bb70:
  %t284 = load ptr, ptr %l14, !tbaa !29
  store ptr %t284, ptr %l132, !tbaa !29
  %t285 = load ptr, ptr %l132, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  store i1 %t286, ptr %l133, !tbaa !21
  %t287 = load i1, ptr %l133, !tbaa !21
  br i1 %t287, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s14
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l134, !tbaa !29
  %t289 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t289, { i64, ptr } { i64 1, ptr @.d164 })
  br label %bb73
bb72:
  br label %bb79
bb73:
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l135, !tbaa !29
  %t291 = load ptr, ptr %l14, !tbaa !29
  store ptr %t291, ptr %l136, !tbaa !29
  %t292 = load ptr, ptr %l136, !tbaa !29
  %t293 = getelementptr %"compiler/ast:Func", ptr %t292, i32 0, i32 3
  %t294 = load ptr, ptr %t293, !tbaa !29
  store ptr %t294, ptr %l137, !tbaa !29
  %t295 = load ptr, ptr %l137, !tbaa !29
  %t296 = getelementptr %"compiler/ast:Sig", ptr %t295, i32 0, i32 0
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  store { i64, ptr } %t297, ptr %l138, !tbaa !27
  %t298 = load ptr, ptr %l135, !tbaa !29
  %t299 = load { i64, ptr }, ptr %l138, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t298, { i64, ptr } %t299)
  br label %bb74
bb74:
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l139, !tbaa !29
  %t301 = load ptr, ptr %l139, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t301, { i64, ptr } { i64 1, ptr @.d165 })
  br label %bb75
bb75:
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l140, !tbaa !29
  %t303 = load ptr, ptr %l14, !tbaa !29
  store ptr %t303, ptr %l141, !tbaa !29
  %t304 = load ptr, ptr %l141, !tbaa !29
  %t305 = getelementptr %"compiler/ast:Func", ptr %t304, i32 0, i32 3
  %t306 = load ptr, ptr %t305, !tbaa !29
  store ptr %t306, ptr %l142, !tbaa !29
  %t307 = load ptr, ptr %l140, !tbaa !29
  %t308 = load ptr, ptr %l142, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t307, ptr %t308, i1 false)
  br label %bb76
bb76:
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l143, !tbaa !29
  %t310 = load ptr, ptr %l143, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t310, { i64, ptr } { i64 1, ptr @.d166 })
  br label %bb77
bb77:
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l144, !tbaa !29
  %t312 = load ptr, ptr %l14, !tbaa !29
  store ptr %t312, ptr %l145, !tbaa !29
  %t313 = load ptr, ptr %l145, !tbaa !29
  %t314 = getelementptr %"compiler/ast:Func", ptr %t313, i32 0, i32 4
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  store { i64, ptr } %t315, ptr %l146, !tbaa !27
  %t316 = load ptr, ptr %l144, !tbaa !29
  %t317 = load { i64, ptr }, ptr %l146, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t316, { i64, ptr } %t317)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s14)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s13)
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @.c167)
  unreachable
bb81:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t2, { i64, ptr } { i64 5, ptr @.d168 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t8, i32 %t9)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l7, !tbaa !29
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/ast:TypeDecl", ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %t16)
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l9, !tbaa !29
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TypeDecl", ptr %t18, i32 0, i32 2
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l10, !tbaa !21
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l11, !tbaa !29
  %t23 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t23, { i64, ptr } { i64 8, ptr @.d169 })
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l12, !tbaa !29
  %t25 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t25, { i64, ptr } { i64 1, ptr @.d170 })
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l13, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l14, !tbaa !29
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TypeDecl", ptr %t28, i32 0, i32 3
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l15, !tbaa !29
  %t31 = load ptr, ptr %l13, !tbaa !29
  %t32 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  %t4 = extractvalue { i64, ptr } zeroinitializer, 0
  %t5 = icmp eq i64 %t3, %t4
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } zeroinitializer, 1
  %t8 = icmp eq ptr %t6, %t7
  %t9 = and i1 %t5, %t8
  store i1 %t9, ptr %l8, !tbaa !21
  %t10 = load i1, ptr %l8, !tbaa !21
  br i1 %t10, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = icmp eq i64 %t14, 0
  store i1 %t15, ptr %l12, !tbaa !21
  %t16 = load i1, ptr %l12, !tbaa !21
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l13, !tbaa !29
  %t19 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t19, { i64, ptr } { i64 1, ptr @.d171 })
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l14, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  store i64 %t24, ptr %l16, !tbaa !24
  %t25 = load i64, ptr %l16, !tbaa !24
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  store i64 %t27, ptr %l18, !tbaa !24
  %t28 = load i64, ptr %l17, !tbaa !24
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = icmp slt i64 %t28, %t29
  store i1 %t30, ptr %l19, !tbaa !21
  %t31 = load i1, ptr %l19, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l20, !tbaa !21
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb10:
  br label %bb11
bb11:
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %l21, !tbaa !24
  %t35 = load i64, ptr %l21, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load i64, ptr %l3, !tbaa !24
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load i64, ptr %l23, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 %t38
  %t42 = load ptr, ptr %t41, !tbaa !39
  store ptr %t42, ptr %l24, !tbaa !29
  %t43 = load ptr, ptr %l24, !tbaa !29
  store ptr %t43, ptr %l6, !tbaa !29
  %t44 = load i64, ptr %l5, !tbaa !24
  store i64 %t44, ptr %l25, !tbaa !24
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = icmp sgt i64 %t45, 0
  store i1 %t46, ptr %l26, !tbaa !21
  %t47 = load i1, ptr %l26, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l27, !tbaa !29
  %t49 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t49, { i64, ptr } { i64 2, ptr @.d172 })
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l28, !tbaa !29
  %t51 = load ptr, ptr %l6, !tbaa !29
  store ptr %t51, ptr %l29, !tbaa !29
  %t52 = load ptr, ptr %l29, !tbaa !29
  %t53 = getelementptr %"compiler/ast:TypeParam", ptr %t52, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  store i32 %t54, ptr %l30, !tbaa !23
  %t55 = load ptr, ptr %l28, !tbaa !29
  %t56 = load i32, ptr %l30, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t55, i32 %t56)
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l6, !tbaa !29
  store ptr %t57, ptr %l31, !tbaa !29
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = getelementptr %"compiler/ast:TypeParam", ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l32, !tbaa !29
  %t61 = load ptr, ptr %l32, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  store i1 %t62, ptr %l33, !tbaa !21
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l34, !tbaa !29
  %t65 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t65, { i64, ptr } { i64 1, ptr @.d173 })
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l35, !tbaa !29
  %t67 = load ptr, ptr %l6, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = getelementptr %"compiler/ast:TypeParam", ptr %t68, i32 0, i32 2
  %t70 = load ptr, ptr %t69, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  %t71 = load ptr, ptr %l35, !tbaa !29
  %t72 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t71, ptr %t72)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t73 = load i64, ptr %l3, !tbaa !24
  store i64 %t73, ptr %l38, !tbaa !24
  %t74 = load i64, ptr %l38, !tbaa !24
  %t75 = add i64 %t74, 1
  store i64 %t75, ptr %l39, !tbaa !24
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb8
bb23:
  call void @__olang_scope_close(ptr %s2)
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l40, !tbaa !29
  %t78 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t78, { i64, ptr } { i64 1, ptr @.d174 })
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t3, ptr %l8, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l11, !tbaa !24
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l11, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l12, !tbaa !21
  %t12 = load i1, ptr %l12, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l13, !tbaa !21
  %t14 = load i1, ptr %l13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l14, !tbaa !24
  %t16 = load i64, ptr %l14, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l16, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t19
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load ptr, ptr %l17, !tbaa !29
  store ptr %t24, ptr %l6, !tbaa !29
  %t25 = load i64, ptr %l5, !tbaa !24
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = icmp sgt i64 %t26, 0
  store i1 %t27, ptr %l19, !tbaa !21
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  %t30 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t30, { i64, ptr } { i64 2, ptr @.d175 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l21, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t35 = load i64, ptr %l3, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  %t36 = load i64, ptr %l23, !tbaa !24
  %t37 = add i64 %t36, 1
  store i64 %t37, ptr %l24, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb1
bb11:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l8, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t5, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l9, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l10, !tbaa !24
  %t9 = load i64, ptr %l10, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  store i64 %t10, ptr %l11, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  store i64 %t11, ptr %l12, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  store i1 %t14, ptr %l13, !tbaa !21
  %t15 = load i1, ptr %l13, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l14, !tbaa !21
  %t17 = load i1, ptr %l14, !tbaa !21
  br i1 %t17, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l15, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  store i64 %t21, ptr %l17, !tbaa !24
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t22
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l18, !tbaa !23
  %t27 = load i32, ptr %l18, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  %t28 = load i64, ptr %l5, !tbaa !24
  store i64 %t28, ptr %l19, !tbaa !24
  %t29 = load i64, ptr %l19, !tbaa !24
  %t30 = icmp sgt i64 %t29, 0
  store i1 %t30, ptr %l20, !tbaa !21
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l21, !tbaa !29
  %t33 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t33, { i64, ptr } { i64 2, ptr @.d176 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  store i32 %t35, ptr %l23, !tbaa !23
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t36, i32 %t37)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l24, !tbaa !24
  %t40 = add i64 %t39, 1
  store i64 %t40, ptr %l25, !tbaa !24
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb1
bb11:
  call void @__olang_scope_close(ptr %s1)
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t44 = getelementptr %"compiler/ast:VarDecl", ptr %t43, i32 0, i32 4
  %t45 = load i1, ptr %t44, !tbaa !21
  store i1 %t45, ptr %l27, !tbaa !21
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load ptr, ptr %l1, !tbaa !29
  store ptr %t47, ptr %l28, !tbaa !29
  %t48 = load ptr, ptr %l28, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  store i1 %t52, ptr %l30, !tbaa !21
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb13:
  br label %bb21
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  %t55 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t55, { i64, ptr } { i64 1, ptr @.d177 })
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l32, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l33, !tbaa !29
  %t58 = load ptr, ptr %l33, !tbaa !29
  %t59 = getelementptr %"compiler/ast:VarDecl", ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l34, !tbaa !29
  %t61 = load ptr, ptr %l32, !tbaa !29
  %t62 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t61, ptr %t62)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l35, !tbaa !29
  %t64 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t64, { i64, ptr } { i64 4, ptr @.d178 })
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l36, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l37, !tbaa !29
  %t67 = load ptr, ptr %l37, !tbaa !29
  %t68 = getelementptr %"compiler/ast:VarDecl", ptr %t67, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l38, !tbaa !27
  %t70 = load ptr, ptr %l36, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t70, { i64, ptr } %t71)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l39, !tbaa !29
  %t73 = load ptr, ptr %l39, !tbaa !29
  %t74 = getelementptr %"compiler/ast:VarDecl", ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74, !tbaa !29
  store ptr %t75, ptr %l40, !tbaa !29
  %t76 = load ptr, ptr %l40, !tbaa !29
  %t77 = icmp eq ptr %t76, null
  store i1 %t77, ptr %l41, !tbaa !21
  %t78 = load i1, ptr %l41, !tbaa !21
  br i1 %t78, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l42, !tbaa !29
  %t80 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t80, { i64, ptr } { i64 1, ptr @.d179 })
  br label %bb25
bb25:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l43, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l44, !tbaa !29
  %t83 = load ptr, ptr %l44, !tbaa !29
  %t84 = getelementptr %"compiler/ast:VarDecl", ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l45, !tbaa !29
  %t86 = load ptr, ptr %l43, !tbaa !29
  %t87 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  br label %bb26
bb26:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l46, !tbaa !29
  %t89 = load ptr, ptr %l46, !tbaa !29
  %t90 = getelementptr %"compiler/ast:VarDecl", ptr %t89, i32 0, i32 3
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l48, !tbaa !24
  %t94 = load i64, ptr %l48, !tbaa !24
  %t95 = icmp sgt i64 %t94, 0
  store i1 %t95, ptr %l49, !tbaa !21
  %t96 = load i1, ptr %l49, !tbaa !21
  br i1 %t96, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l50, !tbaa !29
  %t98 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t98, { i64, ptr } { i64 3, ptr @.d180 })
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  store ptr %t100, ptr %l52, !tbaa !29
  %t101 = load ptr, ptr %l52, !tbaa !29
  %t102 = getelementptr %"compiler/ast:VarDecl", ptr %t101, i32 0, i32 3
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l53, !tbaa !27
  %t104 = load ptr, ptr %l51, !tbaa !29
  %t105 = load { i64, ptr }, ptr %l53, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t104, { i64, ptr } %t105)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  store i1 %t3, ptr %l10, !tbaa !21
  %t4 = load i1, ptr %l10, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  store i64 %t6, ptr %l11, !tbaa !24
  %t7 = load i64, ptr %l11, !tbaa !24
  %t8 = icmp eq i64 %t7, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l13
  %t15 = load i32, ptr %l13
  store i32 %t15, ptr %l1
  br label %bb5
bb4:
  br label %bb11
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load i32, ptr %l1
  store i32 %t16, ptr %l14
  store ptr %l14, ptr %l15, !tbaa !29
  store i32 52, ptr %l16
  store ptr %l16, ptr %l17, !tbaa !29
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = load ptr, ptr %l17, !tbaa !29
  %t19 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t17, ptr %t18)
  store i1 %t19, ptr %l18
  br label %bb6
bb6:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb10
bb8:
  %t21 = load i32, ptr %l1
  store i32 %t21, ptr %l20
  store ptr %l20, ptr %l21, !tbaa !29
  store i32 74, ptr %l22
  store ptr %l22, ptr %l23, !tbaa !29
  %t22 = load ptr, ptr %l21, !tbaa !29
  %t23 = load ptr, ptr %l23, !tbaa !29
  %t24 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %t22, ptr %t23)
  store i1 %t24, ptr %l24
  br label %bb9
bb9:
  %t25 = load i1, ptr %l24, !tbaa !21
  store i1 %t25, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l19, !tbaa !21
  store i1 %t26, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb53
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t28 = load ptr, ptr %l25, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  store i1 %t29, ptr %l27, !tbaa !21
  %t30 = load i1, ptr %l27, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = load i64, ptr %t31
  store i64 %t32, ptr %l28, !tbaa !24
  %t33 = load i64, ptr %l28, !tbaa !24
  %t34 = icmp eq i64 %t33, 1
  store i1 %t34, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb17:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t37 = load ptr, ptr %l29, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  store i1 %t38, ptr %l31, !tbaa !21
  %t39 = load i1, ptr %l31, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l29, !tbaa !29
  %t41 = load i64, ptr %t40
  store i64 %t41, ptr %l32, !tbaa !24
  %t42 = load i64, ptr %l32, !tbaa !24
  %t43 = icmp eq i64 %t42, 5
  store i1 %t43, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l30, !tbaa !21
  br i1 %t44, label %bb20, label %bb21
bb20:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l33, !tbaa !29
  %t46 = load ptr, ptr %l33, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l34, !tbaa !29
  %t50 = load ptr, ptr %l34, !tbaa !29
  store ptr %t50, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load ptr, ptr %l2, !tbaa !29
  store ptr %t51, ptr %l35, !tbaa !29
  %t52 = load ptr, ptr %l35, !tbaa !29
  %t53 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t52)
  store i1 %t53, ptr %l36
  br label %bb23
bb23:
  %t54 = load i1, ptr %l36, !tbaa !21
  store i1 %t54, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb53
bb24:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t56 = load ptr, ptr %l37, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  store i1 %t57, ptr %l39, !tbaa !21
  %t58 = load i1, ptr %l39, !tbaa !21
  br i1 %t58, label %bb25, label %bb26
bb25:
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t60 = load i64, ptr %t59
  store i64 %t60, ptr %l40, !tbaa !24
  %t61 = load i64, ptr %l40, !tbaa !24
  %t62 = icmp eq i64 %t61, 4
  store i1 %t62, ptr %l38, !tbaa !21
  br label %bb26
bb26:
  %t63 = load i1, ptr %l38, !tbaa !21
  br i1 %t63, label %bb27, label %bb28
bb27:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l41, !tbaa !29
  %t65 = load ptr, ptr %l41, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l42, !tbaa !29
  %t69 = load ptr, ptr %l42, !tbaa !29
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load ptr, ptr %l3, !tbaa !29
  store ptr %t70, ptr %l43, !tbaa !29
  %t71 = load ptr, ptr %l43, !tbaa !29
  %t72 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t71)
  store i1 %t72, ptr %l44
  br label %bb30
bb30:
  %t73 = load i1, ptr %l44, !tbaa !21
  store i1 %t73, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb53
bb31:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t75 = load ptr, ptr %l45, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  store i1 %t76, ptr %l47, !tbaa !21
  %t77 = load i1, ptr %l47, !tbaa !21
  br i1 %t77, label %bb32, label %bb33
bb32:
  %t78 = load ptr, ptr %l45, !tbaa !29
  %t79 = load i64, ptr %t78
  store i64 %t79, ptr %l48, !tbaa !24
  %t80 = load i64, ptr %l48, !tbaa !24
  %t81 = icmp eq i64 %t80, 12
  store i1 %t81, ptr %l46, !tbaa !21
  br label %bb33
bb33:
  %t82 = load i1, ptr %l46, !tbaa !21
  br i1 %t82, label %bb34, label %bb35
bb34:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l49, !tbaa !29
  %t84 = load ptr, ptr %l49, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l50, !tbaa !29
  %t88 = load ptr, ptr %l50, !tbaa !29
  store ptr %t88, ptr %l4, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  store %olang.scope zeroinitializer, ptr %s5
  %t89 = load ptr, ptr %l4, !tbaa !29
  store ptr %t89, ptr %l51, !tbaa !29
  %t90 = load ptr, ptr %l51, !tbaa !29
  %t91 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t90)
  store i1 %t91, ptr %l52
  br label %bb37
bb37:
  %t92 = load i1, ptr %l52, !tbaa !21
  store i1 %t92, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb38:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t94 = load ptr, ptr %l53, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  store i1 %t95, ptr %l55, !tbaa !21
  %t96 = load i1, ptr %l55, !tbaa !21
  br i1 %t96, label %bb39, label %bb40
bb39:
  %t97 = load ptr, ptr %l53, !tbaa !29
  %t98 = load i64, ptr %t97
  store i64 %t98, ptr %l56, !tbaa !24
  %t99 = load i64, ptr %l56, !tbaa !24
  %t100 = icmp eq i64 %t99, 15
  store i1 %t100, ptr %l54, !tbaa !21
  br label %bb40
bb40:
  %t101 = load i1, ptr %l54, !tbaa !21
  br i1 %t101, label %bb41, label %bb42
bb41:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l57, !tbaa !29
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l58, !tbaa !29
  %t107 = load ptr, ptr %l58, !tbaa !29
  store ptr %t107, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t108 = load ptr, ptr %l5, !tbaa !29
  store ptr %t108, ptr %l59, !tbaa !29
  %t109 = load ptr, ptr %l59, !tbaa !29
  %t110 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t109)
  store i1 %t110, ptr %l60
  br label %bb44
bb44:
  %t111 = load i1, ptr %l60, !tbaa !21
  store i1 %t111, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb53
bb45:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t113 = load ptr, ptr %l61, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  store i1 %t114, ptr %l63, !tbaa !21
  %t115 = load i1, ptr %l63, !tbaa !21
  br i1 %t115, label %bb46, label %bb47
bb46:
  %t116 = load ptr, ptr %l61, !tbaa !29
  %t117 = load i64, ptr %t116
  store i64 %t117, ptr %l64, !tbaa !24
  %t118 = load i64, ptr %l64, !tbaa !24
  %t119 = icmp eq i64 %t118, 16
  store i1 %t119, ptr %l62, !tbaa !21
  br label %bb47
bb47:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb48, label %bb49
bb48:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l65, !tbaa !29
  %t122 = load ptr, ptr %l65, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l66, !tbaa !29
  %t126 = load ptr, ptr %l66, !tbaa !29
  store ptr %t126, ptr %l6, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  store %olang.scope zeroinitializer, ptr %s7
  %t127 = load ptr, ptr %l6, !tbaa !29
  store ptr %t127, ptr %l67, !tbaa !29
  %t128 = load ptr, ptr %l67, !tbaa !29
  %t129 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t128)
  store i1 %t129, ptr %l68
  br label %bb51
bb51:
  %t130 = load i1, ptr %l68, !tbaa !21
  store i1 %t130, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s8
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t131 = load i1, ptr %l7, !tbaa !21
  store i1 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/list:List<compiler/source:Span>"
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca %"std/prelude/list:List<compiler/source:Span>"
  %l14 = alloca %"compiler/unparse:writer"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/unparse:writer"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l9, !tbaa !29
  store ptr %t2, ptr %l3, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l10, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  %t6 = load ptr, ptr %l11, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v3)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l12
  store %"std/prelude/text:StringBuilder" %t8, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List<compiler/source:Span>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %t9)
  store %"std/prelude/list:List<compiler/source:Span>" %t10, ptr %l13
  br label %bb2
bb2:
  %t11 = load %"std/prelude/list:List<compiler/source:Span>", ptr %l13
  store %"std/prelude/list:List<compiler/source:Span>" %t11, ptr %l8
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = insertvalue %"compiler/unparse:writer" undef, ptr %t12, 0
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = insertvalue %"compiler/unparse:writer" %t13, { i64, ptr } %t14, 1
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t17 = insertvalue %"compiler/unparse:writer" %t15, ptr %t16, 2
  %t18 = load %"std/prelude/text:StringBuilder", ptr %l6
  %t19 = insertvalue %"compiler/unparse:writer" %t17, %"std/prelude/text:StringBuilder" %t18, 3
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = insertvalue %"compiler/unparse:writer" %t19, i64 %t20, 4
  %t22 = load %"std/prelude/list:List<compiler/source:Span>", ptr %l8
  %t23 = insertvalue %"compiler/unparse:writer" %t21, %"std/prelude/list:List<compiler/source:Span>" %t22, 5
  store %"compiler/unparse:writer" %t23, ptr %l14
  call void @__olang_scope_close(ptr %s0)
  %t24 = load %"compiler/unparse:writer", ptr %l14
  store %"compiler/unparse:writer" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/unparse:writer", ptr %rv
  ret %"compiler/unparse:writer" %rr
}

define dso_local void @olang_2einit_2ecompiler_2funparse() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2funparse_2eMaxIndent_2einit()
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant [3 x i8] c"{ }"
@.d1 = private constant [1 x i8] c"{"
@.d2 = private constant [1 x i8] c"}"
@.d3 = private constant [4 x i8] c" => "
@.d4 = private constant [1 x i8] c" "
@.d5 = private constant [6 x i8] c" catch"
@.d6 = private constant [2 x i8] c", "
@.d7 = private constant [1 x i8] c" "
@.d8 = private constant [1 x i8] c" "
@.d9 = private constant [9 x i8] c" default "
@.d10 = private constant [10 x i8] c"extern fn "
@.d11 = private constant [7 x i8] c"import "
@.d12 = private constant [1 x i8] c" "
@.d13 = private constant [6 x i8] c"error "
@.d14 = private constant [2 x i8] c" {"
@.d15 = private constant [1 x i8] c"}"
@.d16 = private constant [5 x i8] c"test "
@.d17 = private constant [1 x i8] c" "
declare void @__olang_check_failed(ptr)
@.c18 = private unnamed_addr constant [53 x i8] c"compiler/unparse.olang:56: reached unreachable code\0A\00"
@.d19 = private constant [2 x i8] c" ?"
@.d20 = private constant [2 x i8] c" ("
@.d21 = private constant [1 x i8] c" "
@.d22 = private constant [2 x i8] c", "
@.d23 = private constant [1 x i8] c")"
@.d24 = private constant [1 x i8] c"("
@.d25 = private constant [1 x i8] c")"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d26 = private constant [1 x i8] c" "
@.d27 = private constant [1 x i8] c" "
@.d28 = private constant [1 x i8] c" "
@.d29 = private constant [1 x i8] c" "
@.d30 = private constant [8 x i8] c" not in "
@.d31 = private constant [1 x i8] c" "
@.d32 = private constant [1 x i8] c" "
@.d33 = private constant [4 x i8] c" if "
@.d34 = private constant [6 x i8] c" else "
@.d35 = private constant [8 x i8] c" is not "
@.d36 = private constant [4 x i8] c" is "
@.d37 = private constant [8 x i8] c" is not "
@.d38 = private constant [4 x i8] c" is "
@.d39 = private constant [4 x i8] c" as "
@.d40 = private constant [1 x i8] c"("
@.d41 = private constant [1 x i8] c")"
@.d42 = private constant [1 x i8] c"&"
@.d43 = private constant [1 x i8] c"("
@.d44 = private constant [1 x i8] c")"
@.d45 = private constant [1 x i8] c"<"
@.d46 = private constant [1 x i8] c">"
@.d47 = private constant [1 x i8] c"."
@.d48 = private constant [1 x i8] c"["
@.d49 = private constant [1 x i8] c"]"
@.d50 = private constant [1 x i8] c"["
@.d51 = private constant [1 x i8] c":"
@.d52 = private constant [1 x i8] c"]"
@.d53 = private constant [1 x i8] c"["
@.d54 = private constant [1 x i8] c"]"
@.d55 = private constant [1 x i8] c"["
@.d56 = private constant [1 x i8] c"]"
@.d57 = private constant [1 x i8] c"["
@.d58 = private constant [5 x i8] c" for "
@.d59 = private constant [2 x i8] c", "
@.d60 = private constant [4 x i8] c" in "
@.d61 = private constant [4 x i8] c" if "
@.d62 = private constant [1 x i8] c"]"
@.d63 = private constant [1 x i8] c" "
@.d64 = private constant [8 x i8] c"checked "
@.d65 = private constant [4 x i8] c"try "
@.d66 = private constant [2 x i8] c"fn"
@.d67 = private constant [1 x i8] c" "
@.d68 = private constant [6 x i8] c"range "
@.d69 = private constant [7 x i8] c"default"
@.c70 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:589: reached unreachable code\0A\00"
@.d71 = private constant [2 x i8] c", "
@.d72 = private constant [3 x i8] c"fn "
@.d73 = private constant [1 x i8] c"("
@.d74 = private constant [2 x i8] c") "
@.d75 = private constant [1 x i8] c" "
@.d76 = private constant [3 x i8] c"if "
@.d77 = private constant [1 x i8] c" "
@.d78 = private constant [6 x i8] c" else "
@.d79 = private constant [6 x i8] c"match "
@.d80 = private constant [2 x i8] c" {"
@.d81 = private constant [5 x i8] c"case "
@.d82 = private constant [2 x i8] c", "
@.d83 = private constant [2 x i8] c", "
@.d84 = private constant [4 x i8] c" if "
@.d85 = private constant [7 x i8] c"nomatch"
@.d86 = private constant [1 x i8] c"}"
@.d87 = private constant [4 x i8] c"    "
@.d88 = private constant [1 x i8] c" "
@.d89 = private constant [3 x i8] c" = "
@.d90 = private constant [2 x i8] c", "
@.d91 = private constant [1 x i8] c"."
@.d92 = private constant [1 x i8] c"_"
@.d93 = private constant [1 x i8] c"("
@.d94 = private constant [2 x i8] c", "
@.d95 = private constant [1 x i8] c")"
@.c96 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:562: reached unreachable code\0A\00"
@.d97 = private constant [1 x i8] c"("
@.d98 = private constant [1 x i8] c")"
@.d99 = private constant [9 x i8] c" noreturn"
@.d100 = private constant [1 x i8] c" "
@.d101 = private constant [2 x i8] c" ("
@.d102 = private constant [1 x i8] c")"
@.c103 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:41: slice bounds out of range\0A\00"
@.d104 = private constant [4 x i8] c" := "
@.d105 = private constant [3 x i8] c" = "
@.d106 = private constant [1 x i8] c" "
@.d107 = private constant [1 x i8] c" "
@.d108 = private constant [8 x i8] c"checked "
@.d109 = private constant [4 x i8] c"try "
@.d110 = private constant [4 x i8] c"for "
@.d111 = private constant [4 x i8] c"for "
@.d112 = private constant [1 x i8] c" "
@.d113 = private constant [4 x i8] c"for "
@.d114 = private constant [2 x i8] c", "
@.d115 = private constant [2 x i8] c", "
@.d116 = private constant [1 x i8] c" "
@.d117 = private constant [4 x i8] c"for "
@.d118 = private constant [2 x i8] c", "
@.d119 = private constant [4 x i8] c" in "
@.d120 = private constant [4 x i8] c"try "
@.d121 = private constant [1 x i8] c" "
@.d122 = private constant [3 x i8] c"do "
@.d123 = private constant [5 x i8] c" for "
@.d124 = private constant [6 x i8] c"return"
@.d125 = private constant [1 x i8] c" "
@.d126 = private constant [7 x i8] c"assert "
@.d127 = private constant [2 x i8] c", "
@.d128 = private constant [5 x i8] c"error"
@.d129 = private constant [1 x i8] c" "
@.d130 = private constant [6 x i8] c"spawn "
@.d131 = private constant [3 x i8] c" = "
@.d132 = private constant [4 x i8] c"try "
@.d133 = private constant [5 x i8] c"join "
@.d134 = private constant [6 x i8] c"defer "
@.c135 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:386: reached unreachable code\0A\00"
@.d136 = private constant [1 x i8] c"{"
@.d137 = private constant [1 x i8] c"}"
@.d138 = private constant [3 x i8] c"if "
@.d139 = private constant [1 x i8] c" "
@.d140 = private constant [6 x i8] c" else "
@.d141 = private constant [6 x i8] c" else "
@.d142 = private constant [1 x i8] c"."
@.d143 = private constant [1 x i8] c"<"
@.d144 = private constant [1 x i8] c">"
@.d145 = private constant [2 x i8] c"fn"
@.d146 = private constant [1 x i8] c"&"
@.d147 = private constant [3 x i8] c"own"
@.d148 = private constant [1 x i8] c" "
@.d149 = private constant [3 x i8] c"mut"
@.d150 = private constant [1 x i8] c" "
@.c151 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:290: reached unreachable code\0A\00"
@.d152 = private constant [6 x i8] c"struct"
@.d153 = private constant [1 x i8] c"("
@.d154 = private constant [1 x i8] c")"
@.d155 = private constant [1 x i8] c" "
@.d156 = private constant [10 x i8] c" destruct "
@.d157 = private constant [6 x i8] c"enum {"
@.d158 = private constant [1 x i8] c"("
@.d159 = private constant [1 x i8] c")"
@.d160 = private constant [1 x i8] c"}"
@.d161 = private constant [7 x i8] c"trait {"
@.d162 = private constant [4 x i8] c"mut "
@.d163 = private constant [1 x i8] c"}"
@.d164 = private constant [1 x i8] c"("
@.d165 = private constant [1 x i8] c")"
@.d166 = private constant [1 x i8] c" "
@.c167 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:222: reached unreachable code\0A\00"
@.d168 = private constant [5 x i8] c"type "
@.d169 = private constant [8 x i8] c" extends"
@.d170 = private constant [1 x i8] c" "
@.d171 = private constant [1 x i8] c"<"
@.d172 = private constant [2 x i8] c", "
@.d173 = private constant [1 x i8] c" "
@.d174 = private constant [1 x i8] c">"
@.d175 = private constant [2 x i8] c", "
@.d176 = private constant [2 x i8] c", "
@.d177 = private constant [1 x i8] c" "
@.d178 = private constant [4 x i8] c" := "
@.d179 = private constant [1 x i8] c" "
@.d180 = private constant [3 x i8] c" = "
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List<compiler/source:Span>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/source:Span>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/source:Span>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/source:Span>" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/source:Span>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/source:Span>", ptr %l0
  store %"std/prelude/list:List<compiler/source:Span>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/source:Span>", ptr %rv
  ret %"std/prelude/list:List<compiler/source:Span>" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/source:Span>" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
