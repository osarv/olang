; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/unparse:writer" = type { ptr, { i64, ptr }, ptr, %"std/prelude/text:StringBuilder", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1 }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Outlives" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
@G_2ecompiler_2funparse_2eMaxIndent = constant <{ [8 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00" }>, align 8
define dso_local { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/unparse:writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca %"compiler/unparse:writer"
  %l20 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %a1, { i64, ptr } %a2, ptr %a3)
  store %"compiler/unparse:writer" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/unparse:writer", ptr %l12
  store %"compiler/unparse:writer" %t8, ptr %l4
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %s0, ptr %v0, ptr %l4, ptr %t29)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l6, !tbaa !24
  br label %bb2
bb8:
  %t38 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 5
  %t40 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %v4, ptr %t38)
  store { i64, ptr } %t40, ptr %l28
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l30, !tbaa !24
  %t45 = mul i64 %t44, 8
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l31, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l30, !tbaa !24
  %t54 = mul i64 %t53, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2funparse_2eMaxIndent_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 64, ptr @G_2ecompiler_2funparse_2eMaxIndent, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2funparse_2eUnparse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/unparse:writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca %"compiler/unparse:writer"
  %l20 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %a1, { i64, ptr } %a2, ptr %a3)
  store %"compiler/unparse:writer" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/unparse:writer", ptr %l12
  store %"compiler/unparse:writer" %t8, ptr %l4
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %s0, ptr %v0, ptr %l4, ptr %t29)
  br label %bb6
bb6:
  %t34 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t34, i8 10)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l6, !tbaa !24
  br label %bb2
bb9:
  %t40 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 3
  %t42 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %t40)
  store { i64, ptr } %t42, ptr %l29
  br label %bb10
bb10:
  %t43 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load i64, ptr %l31, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l12 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l35 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t7, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l12, !tbaa !29
  %t12 = load ptr, ptr %l12, !tbaa !29
  %t13 = getelementptr %"compiler/unparse:writer", ptr %t12, i32 0, i32 4
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = add i64 %t14, 1
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = getelementptr %"compiler/unparse:writer", ptr %t18, i32 0, i32 4
  store i64 %t16, ptr %t19, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t20, i32 0, i32 6
  %t23 = load i1, ptr %t22, !tbaa !21
  store i1 %t23, ptr %l2, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/unparse:writer", ptr %t25, i32 0, i32 6
  store i1 false, ptr %t27, !tbaa !21
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t28, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l25, !tbaa !27
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l6, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t50)
  br label %bb10
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l4, !tbaa !24
  br label %bb6
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i1, ptr %l2, !tbaa !21
  %t64 = getelementptr %"compiler/unparse:writer", ptr %t60, i32 0, i32 6
  store i1 %t61, ptr %t64, !tbaa !21
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l35, !tbaa !29
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = getelementptr %"compiler/unparse:writer", ptr %t66, i32 0, i32 4
  %t68 = load i64, ptr %t67, !tbaa !24
  %t70 = sub i64 %t68, 1
  %t72 = load ptr, ptr %l35, !tbaa !29
  %t73 = getelementptr %"compiler/unparse:writer", ptr %t72, i32 0, i32 4
  store i64 %t70, ptr %t73, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t74)
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t76, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l31 = alloca i1
  %l33 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr ptr, ptr %t9, i64 0
  %t11 = load ptr, ptr %t10, !tbaa !39
  %t13 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t11)
  store %"compiler/source:Span" %t13, ptr %l8
  br label %bb3
bb2:
  br label %bb24
bb3:
  %t14 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t19 = sub i64 %t17, 1
  store i64 %t19, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/unparse:writer", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l16, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i8, ptr %t32, i64 %t29
  %t34 = load i8, ptr %t33, !tbaa !32
  %t36 = icmp eq i8 %t34, 32
  br i1 %t36, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/unparse:writer", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp eq i8 %t47, 9
  store i1 %t49, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t51 = load i1, ptr %l20, !tbaa !21
  store i1 %t51, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t52 = load i1, ptr %l14, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = sub i64 %t55, 1
  store i64 %t57, ptr %l2, !tbaa !24
  br label %bb14
bb14:
  br label %bb4
bb15:
  %t59 = load i64, ptr %l2, !tbaa !24
  %t61 = icmp sge i64 %t59, 0
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/unparse:writer", ptr %t63, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l33, !tbaa !27
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 58
  store i1 %t74, ptr %l31, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t76 = load i1, ptr %l31, !tbaa !21
  br i1 %t76, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t77, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t80, ptr %l39, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr ptr, ptr %t82, i64 0
  %t84 = load ptr, ptr %t83, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t79, ptr %t84)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t87, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t89, { i64, ptr } %t90)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/unparse:writer", ptr %t10, i32 0, i32 2
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Branch", ptr %t14, i32 0, i32 2
  %t17 = load i64, ptr %t16, !tbaa !24
  %t20 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t13, i64 %t17)
  store i1 %t20, ptr %l11
  br label %bb3
bb3:
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l6, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/unparse:writer", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l13, !tbaa !27
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Branch", ptr %t27, i32 0, i32 0
  %t30 = getelementptr %"compiler/source:Span", ptr %t29, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t35 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t33
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = icmp ne i8 %t38, 58
  br i1 %t40, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t42, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Branch", ptr %t45, i32 0, i32 0
  %t48 = load %"compiler/source:Span", ptr %t47
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t44, %"compiler/source:Span" %t48)
  br label %bb11
bb11:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/unparse:writer", ptr %t51, i32 0, i32 5
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Branch", ptr %t54, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t53, %"compiler/source:Span" %t57)
  br label %bb12
bb12:
  br label %ret
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Branch", ptr %t61, i32 0, i32 1
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t60, { i64, ptr } %t64)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l7 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 5
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Case", ptr %t13, i32 0, i32 5
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6d411809e3c45284_6ddb613e25dacce8)
  unreachable
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Case", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t24, ptr %t23)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t26, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) })
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Case", ptr %t29, i32 0, i32 4
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %t32)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t23, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Catch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l10, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l34, !tbaa !29
  %t55 = icmp sgt i64 %t42, 0
  br i1 %t55, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb12
bb12:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t57, { i64, ptr } %t58)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t59, ptr %t60)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l7, !tbaa !24
  br label %bb6
bb16:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Catch", ptr %t67, i32 0, i32 5
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = icmp ne i32 %t70, 0
  br i1 %t72, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t74 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t74, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Catch", ptr %t77, i32 0, i32 5
  %t80 = load i32, ptr %t79, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t76, i32 %t80)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Catch", ptr %t83, i32 0, i32 4
  %t86 = load i1, ptr %t85, !tbaa !21
  br i1 %t86, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t88 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t88, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Catch", ptr %t91, i32 0, i32 2
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t90, { i64, ptr } %t94)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Catch", ptr %t97, i32 0, i32 3
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  %t106 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t106, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l5, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Catch", ptr %t109, i32 0, i32 3
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t108, { i64, ptr } %t112)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t115 = load i64, ptr %l3, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l3, !tbaa !24
  br label %bb1
bb33:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtract(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l65 = alloca i64
  %l68 = alloca i64
  %l90 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 5
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Sig", ptr %t8, i32 0, i32 5
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_3b272a795e4745a2_9a90297686d0fdde)
  unreachable
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Sig", ptr %t15, i32 0, i32 5
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l2, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t20, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb7
bb7:
  store i1 true, ptr %l3, !tbaa !21
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/ast:ContractBlock", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t39, ptr %l35, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l7, !tbaa !29
  %t47 = load i1, ptr %l3, !tbaa !21
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t51 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t51, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  store i1 false, ptr %l3, !tbaa !21
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtractItem(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb8
bb18:
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/ast:ContractBlock", ptr %t61, i32 0, i32 2
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t70 = load i64, ptr %l9, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb20, label %bb21
bb20:
  br label %bb49
bb21:
  br label %bb22
bb22:
  %t78 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t78, ptr %l53, !tbaa !27
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr ptr, ptr %t82, i64 %t79
  %t84 = load ptr, ptr %t83, !tbaa !39
  store ptr %t84, ptr %l11, !tbaa !29
  %t86 = load i1, ptr %l3, !tbaa !21
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s8
  %t90 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t90, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s8)
  br label %bb26
bb26:
  store i1 false, ptr %l3, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  %t92 = load ptr, ptr %l11, !tbaa !29
  %t94 = getelementptr %"compiler/ast:Outlives", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = icmp sgt i64 %t99, %t100
  br i1 %t103, label %bb27, label %bb28
bb27:
  %t105 = load i64, ptr %l14, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb32
bb29:
  %t109 = load i64, ptr %l13, !tbaa !24
  %t110 = load i64, ptr %l12, !tbaa !24
  %t113 = sub i64 %t109, %t110
  %t114 = load i64, ptr %l14, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = sub i64 %t117, 1
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = sdiv i64 %t119, %t120
  store i64 %t123, ptr %l68, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t125 = load i64, ptr %l68, !tbaa !24
  store i64 %t125, ptr %l65, !tbaa !24
  br label %bb32
bb32:
  %t126 = load i64, ptr %l65, !tbaa !24
  store i64 %t126, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb33
bb33:
  %t127 = load i64, ptr %l16, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb34, label %bb35
bb34:
  br label %bb47
bb35:
  br label %bb36
bb36:
  %t135 = load i64, ptr %l12, !tbaa !24
  %t136 = load i64, ptr %l16, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t140 = mul i64 %t136, %t137
  %t143 = add i64 %t135, %t140
  store i64 %t143, ptr %l17, !tbaa !24
  %t145 = load i64, ptr %l17, !tbaa !24
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s11
  %t149 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t149, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s11)
  br label %bb40
bb40:
  %t151 = load ptr, ptr %l11, !tbaa !29
  %t153 = getelementptr %"compiler/ast:Outlives", ptr %t151, i32 0, i32 1
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  store { i64, ptr } %t154, ptr %l90, !tbaa !27
  %t155 = load i64, ptr %l17, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i32, ptr %t158, i64 %t155
  %t160 = load i32, ptr %t159, !tbaa !33
  %t162 = icmp eq i32 %t160, 0
  br i1 %t162, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s12
  %t164 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t164, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb43
bb42:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l11, !tbaa !29
  %t169 = getelementptr %"compiler/ast:Outlives", ptr %t167, i32 0, i32 1
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l97, !tbaa !27
  %t171 = load i64, ptr %l17, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr i32, ptr %t174, i64 %t171
  %t176 = load i32, ptr %t175, !tbaa !33
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t166, i32 %t176)
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s12)
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t179 = load i64, ptr %l16, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l16, !tbaa !24
  br label %bb33
bb47:
  br label %bb48
bb48:
  %t183 = load i64, ptr %l9, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l9, !tbaa !24
  br label %bb19
bb49:
  %t187 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t187, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtractItem(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t17)
  br label %bb6
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca ptr
  %l25 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l99 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca i1
  %l159 = alloca ptr
  %l160 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t2 = load ptr, ptr %l24, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l24, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l25, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l25, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [6 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb103
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t21 = load ptr, ptr %l32, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l32, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l33, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l33, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [6 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { ptr }, ptr %t31, i32 0, i32 0
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t35, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb13
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Func", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t37, i32 %t41)
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t44, ptr %t48)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb103
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t52 = load ptr, ptr %l45, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l45, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 2
  store i1 %t58, ptr %l46, !tbaa !21
  br label %bb18
bb18:
  %t59 = load i1, ptr %l46, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [6 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", ptr }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l4, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  br label %bb22
bb22:
  br label %bb103
bb23:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t71 = load ptr, ptr %l53, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t74 = load ptr, ptr %l53, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 3
  store i1 %t77, ptr %l54, !tbaa !21
  br label %bb25
bb25:
  %t78 = load i1, ptr %l54, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [6 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  br label %bb29
bb29:
  br label %bb103
bb30:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t90 = load ptr, ptr %l61, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb31, label %bb32
bb31:
  %t93 = load ptr, ptr %l61, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 4
  store i1 %t96, ptr %l62, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l62, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [6 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t100, i32 0, i32 1
  %t102 = load i32, ptr %t101
  store i32 %t102, ptr %l6, !tbaa !23
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [6 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t106, i32 0, i32 2
  %t108 = load %"compiler/source:Span", ptr %t107
  store %"compiler/source:Span" %t108, ptr %l7
  br label %bb35
bb34:
  br label %bb43
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t110, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb36
bb36:
  %t112 = load i32, ptr %l6, !tbaa !23
  %t114 = icmp ne i32 %t112, 0
  br i1 %t114, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t116, i32 %t117)
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t120, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t122, %"compiler/source:Span" %t123)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb103
bb43:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t127 = load ptr, ptr %l77, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb44, label %bb45
bb44:
  %t130 = load ptr, ptr %l77, !tbaa !29
  %t131 = load i64, ptr %t130
  %t133 = icmp eq i64 %t131, 5
  store i1 %t133, ptr %l78, !tbaa !21
  br label %bb45
bb45:
  %t134 = load i1, ptr %l78, !tbaa !21
  br i1 %t134, label %bb46, label %bb47
bb46:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [6 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t137, i32 0, i32 1
  %t139 = load i32, ptr %t138
  store i32 %t139, ptr %l8, !tbaa !23
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [6 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t143, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %t144
  store { i64, ptr } %t145, ptr %l9, !tbaa !27
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [6 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t149, i32 0, i32 3
  %t151 = load { i64, ptr }, ptr %t150
  store { i64, ptr } %t151, ptr %l10, !tbaa !27
  br label %bb48
bb47:
  br label %bb77
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t153 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t153, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) })
  br label %bb49
bb49:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t155, i32 %t156)
  br label %bb50
bb50:
  %t159 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t159, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) })
  br label %bb51
bb51:
  %t161 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t161, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  store i64 %t165, ptr %l13, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t167 = load i64, ptr %l12, !tbaa !24
  %t168 = load i64, ptr %l13, !tbaa !24
  %t171 = icmp slt i64 %t167, %t168
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb62
bb54:
  br label %bb55
bb55:
  %t175 = load i64, ptr %l12, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t177, ptr %l99, !tbaa !27
  %t178 = load i64, ptr %l12, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr ptr, ptr %t181, i64 %t178
  %t183 = load ptr, ptr %t182, !tbaa !39
  store ptr %t183, ptr %l15, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l102, !tbaa !29
  %t188 = icmp sgt i64 %t175, 0
  br i1 %t188, label %bb56, label %bb57
bb56:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l105, !tbaa !27
  br label %bb58
bb57:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l105, !tbaa !27
  br label %bb58
bb58:
  %t190 = load ptr, ptr %l102, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l105, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t190, { i64, ptr } %t191)
  br label %bb59
bb59:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t192, ptr %t193)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s9)
  br label %bb61
bb61:
  %t196 = load i64, ptr %l12, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l12, !tbaa !24
  br label %bb52
bb62:
  %t200 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t204 = icmp sgt i64 %t202, 0
  br i1 %t204, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s11
  %t206 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t206, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb65
bb64:
  br label %bb76
bb65:
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l114, !tbaa !29
  %t209 = load ptr, ptr %l114, !tbaa !29
  %t210 = getelementptr %"compiler/unparse:writer", ptr %t209, i32 0, i32 4
  %t211 = load i64, ptr %t210, !tbaa !24
  %t213 = add i64 %t211, 1
  %t215 = load ptr, ptr %l114, !tbaa !29
  %t216 = getelementptr %"compiler/unparse:writer", ptr %t215, i32 0, i32 4
  store i64 %t213, ptr %t216, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t217, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t219 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t219, 0
  store i64 %t221, ptr %l18, !tbaa !24
  br label %bb66
bb66:
  %t223 = load i64, ptr %l17, !tbaa !24
  %t224 = load i64, ptr %l18, !tbaa !24
  %t227 = icmp slt i64 %t223, %t224
  %t229 = xor i1 %t227, true
  br i1 %t229, label %bb67, label %bb68
bb67:
  br label %bb73
bb68:
  br label %bb69
bb69:
  %t231 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t231, ptr %l124, !tbaa !27
  %t232 = load i64, ptr %l17, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  store i32 %t237, ptr %l19, !tbaa !23
  %t239 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t239)
  br label %bb70
bb70:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l19, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t241, i32 %t242)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t245 = load i64, ptr %l17, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l17, !tbaa !24
  br label %bb66
bb73:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l132, !tbaa !29
  %t250 = load ptr, ptr %l132, !tbaa !29
  %t251 = getelementptr %"compiler/unparse:writer", ptr %t250, i32 0, i32 4
  %t252 = load i64, ptr %t251, !tbaa !24
  %t254 = sub i64 %t252, 1
  %t256 = load ptr, ptr %l132, !tbaa !29
  %t257 = getelementptr %"compiler/unparse:writer", ptr %t256, i32 0, i32 4
  store i64 %t254, ptr %t257, !tbaa !24
  %t258 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t258)
  br label %bb74
bb74:
  %t260 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t260, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s11)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s7)
  br label %bb103
bb77:
  %t262 = load ptr, ptr %l1, !tbaa !29
  store ptr %t262, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t263 = load ptr, ptr %l137, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb78, label %bb79
bb78:
  %t266 = load ptr, ptr %l137, !tbaa !29
  %t267 = load i64, ptr %t266
  %t269 = icmp eq i64 %t267, 6
  store i1 %t269, ptr %l138, !tbaa !21
  br label %bb79
bb79:
  %t270 = load i1, ptr %l138, !tbaa !21
  br i1 %t270, label %bb80, label %bb81
bb80:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr { i64, [6 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t273, i32 0, i32 1
  %t275 = load %"compiler/source:Span", ptr %t274
  store %"compiler/source:Span" %t275, ptr %l20
  %t277 = load ptr, ptr %l1, !tbaa !29
  %t279 = getelementptr { i64, [6 x i64] }, ptr %t277, i32 0, i32 1
  %t280 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t279, i32 0, i32 2
  %t281 = load { i64, ptr }, ptr %t280
  store { i64, ptr } %t281, ptr %l21, !tbaa !27
  br label %bb82
bb81:
  br label %bb87
bb82:
  store %olang.scope zeroinitializer, ptr %s15
  %t283 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t283, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb83
bb83:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load %"compiler/source:Span", ptr %l20
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t285, %"compiler/source:Span" %t286)
  br label %bb84
bb84:
  %t289 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t289, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb85
bb85:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t291, { i64, ptr } %t292)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s15)
  br label %bb103
bb87:
  %t295 = load ptr, ptr %l1, !tbaa !29
  store ptr %t295, ptr %l151, !tbaa !29
  store i1 false, ptr %l152, !tbaa !21
  %t296 = load ptr, ptr %l151, !tbaa !29
  %t297 = icmp ne ptr %t296, null
  br i1 %t297, label %bb88, label %bb89
bb88:
  %t299 = load ptr, ptr %l151, !tbaa !29
  %t300 = load i64, ptr %t299
  %t302 = icmp eq i64 %t300, 7
  store i1 %t302, ptr %l152, !tbaa !21
  br label %bb89
bb89:
  %t303 = load i1, ptr %l152, !tbaa !21
  br i1 %t303, label %bb90, label %bb91
bb90:
  %t304 = load ptr, ptr %l1, !tbaa !29
  %t306 = getelementptr { i64, [6 x i64] }, ptr %t304, i32 0, i32 1
  %t307 = getelementptr { %"compiler/source:Span", ptr }, ptr %t306, i32 0, i32 1
  %t308 = load ptr, ptr %t307
  store ptr %t308, ptr %l22, !tbaa !29
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t310, ptr %t311)
  br label %bb93
bb93:
  br label %bb103
bb94:
  %t314 = load ptr, ptr %l1, !tbaa !29
  store ptr %t314, ptr %l159, !tbaa !29
  store i1 false, ptr %l160, !tbaa !21
  %t315 = load ptr, ptr %l159, !tbaa !29
  %t316 = icmp ne ptr %t315, null
  br i1 %t316, label %bb95, label %bb96
bb95:
  %t318 = load ptr, ptr %l159, !tbaa !29
  %t319 = load i64, ptr %t318
  %t321 = icmp eq i64 %t319, 8
  store i1 %t321, ptr %l160, !tbaa !21
  br label %bb96
bb96:
  %t322 = load i1, ptr %l160, !tbaa !21
  br i1 %t322, label %bb97, label %bb98
bb97:
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr { i64, [6 x i64] }, ptr %t323, i32 0, i32 1
  %t326 = getelementptr { %"compiler/source:Span", %"compiler/source:Span" }, ptr %t325, i32 0, i32 1
  %t327 = load %"compiler/source:Span", ptr %t326
  store %"compiler/source:Span" %t327, ptr %l23
  br label %bb99
bb98:
  br label %bb102
bb99:
  store %olang.scope zeroinitializer, ptr %s17
  %t329 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t329, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb100
bb100:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t331, %"compiler/source:Span" %t332)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s17)
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_7f8607ca82c86e8f_41d7f7ff4057cd03)
  unreachable
bb103:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Sig", ptr %t10, i32 0, i32 3
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb7:
  br label %bb8
bb8:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr ptr, ptr %t33, i64 %t30
  %t35 = load ptr, ptr %t34, !tbaa !39
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l23, !tbaa !29
  %t40 = icmp sgt i64 %t27, 0
  br i1 %t40, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb11
bb10:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l23, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t42, { i64, ptr } %t43)
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb5
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l101 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l106 = alloca i1
  %l109 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l120 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l134 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l138 = alloca i1
  %l150 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l157 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l184 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l192 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l202 = alloca ptr
  %l203 = alloca i1
  %l220 = alloca ptr
  %l221 = alloca i1
  %l232 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l238 = alloca i1
  %l249 = alloca ptr
  %l251 = alloca { i64, ptr }
  %l254 = alloca ptr
  %l255 = alloca i1
  %l267 = alloca ptr
  %l268 = alloca i1
  %l281 = alloca ptr
  %l282 = alloca i1
  %l300 = alloca ptr
  %l301 = alloca i1
  %l314 = alloca ptr
  %l315 = alloca i1
  %l327 = alloca ptr
  %l328 = alloca i1
  %l341 = alloca ptr
  %l342 = alloca i1
  %l366 = alloca ptr
  %l367 = alloca i1
  %l374 = alloca ptr
  %l382 = alloca ptr
  %l383 = alloca i1
  %l392 = alloca ptr
  %l393 = alloca i1
  %l401 = alloca ptr
  %l431 = alloca ptr
  %l441 = alloca ptr
  %l442 = alloca i1
  %l455 = alloca { i64, ptr }
  %l465 = alloca ptr
  %l466 = alloca i1
  %l478 = alloca ptr
  %l479 = alloca i1
  %l496 = alloca ptr
  %l497 = alloca i1
  %l504 = alloca ptr
  %l505 = alloca i1
  %l513 = alloca ptr
  %l514 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t2 = load ptr, ptr %l62, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l62, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l63, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l63, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t16, i32 %t17)
  br label %bb6
bb6:
  br label %bb332
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t21 = load ptr, ptr %l70, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l70, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l71, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l71, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32 }, ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/source:Span", ptr %t32
  store %"compiler/source:Span" %t33, ptr %l3
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t35, %"compiler/source:Span" %t36)
  br label %bb13
bb13:
  br label %bb332
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t40 = load ptr, ptr %l78, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l78, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l79, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l79, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb23
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t54, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/unparse:writer", ptr %t56, i32 0, i32 6
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l5, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/unparse:writer", ptr %t61, i32 0, i32 6
  store i1 false, ptr %t63, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  br label %bb21
bb21:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i1, ptr %l5, !tbaa !21
  %t72 = getelementptr %"compiler/unparse:writer", ptr %t68, i32 0, i32 6
  store i1 %t69, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t73, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb332
bb23:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t76 = load ptr, ptr %l93, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l93, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 3
  store i1 %t82, ptr %l94, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l94, !tbaa !21
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l6
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb53
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l101, !tbaa !29
  %t97 = load i32, ptr %l6
  %t99 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t97)
  store { i64, ptr } %t99, ptr %l103
  br label %bb29
bb29:
  %t100 = load ptr, ptr %l101, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l103, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t100, { i64, ptr } %t101)
  br label %bb30
bb30:
  %t102 = load i32, ptr %l6
  %t104 = trunc i64 49 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb33
bb32:
  %t107 = load i32, ptr %l6
  %t109 = trunc i64 13 to i32
  %t110 = icmp eq i32 %t107, %t109
  store i1 %t110, ptr %l106, !tbaa !21
  br label %bb33
bb33:
  %t112 = load i1, ptr %l106, !tbaa !21
  br i1 %t112, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb36
bb35:
  %t113 = load i32, ptr %l6
  %t115 = trunc i64 18 to i32
  %t116 = icmp eq i32 %t113, %t115
  store i1 %t116, ptr %l109, !tbaa !21
  br label %bb36
bb36:
  %t118 = load i1, ptr %l109, !tbaa !21
  br i1 %t118, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s5
  %t119 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t119, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb39
bb38:
  %t121 = load i32, ptr %l6
  %t123 = trunc i64 52 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb40, label %bb41
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb40:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb42
bb41:
  %t126 = load i32, ptr %l6
  %t128 = trunc i64 74 to i32
  %t129 = icmp eq i32 %t126, %t128
  store i1 %t129, ptr %l115, !tbaa !21
  br label %bb42
bb42:
  %t131 = load i1, ptr %l115, !tbaa !21
  br i1 %t131, label %bb43, label %bb44
bb43:
  %t132 = load ptr, ptr %l7, !tbaa !29
  %t134 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v1, ptr %t132)
  store i1 %t134, ptr %l120
  br label %bb45
bb44:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb46
bb45:
  %t135 = load i1, ptr %l120, !tbaa !21
  store i1 %t135, ptr %l118, !tbaa !21
  br label %bb46
bb46:
  %t136 = load i1, ptr %l118, !tbaa !21
  br i1 %t136, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t137 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t137, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t139, ptr %t140)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s4)
  br label %bb332
bb53:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t144 = load ptr, ptr %l124, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb54, label %bb55
bb54:
  %t147 = load ptr, ptr %l124, !tbaa !29
  %t148 = load i64, ptr %t147
  %t150 = icmp eq i64 %t148, 4
  store i1 %t150, ptr %l125, !tbaa !21
  br label %bb55
bb55:
  %t151 = load i1, ptr %l125, !tbaa !21
  br i1 %t151, label %bb56, label %bb57
bb56:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t154, i32 0, i32 1
  %t156 = load i32, ptr %t155
  store i32 %t156, ptr %l8
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t160, i32 0, i32 2
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l9, !tbaa !29
  br label %bb58
bb57:
  br label %bb62
bb58:
  store %olang.scope zeroinitializer, ptr %s8
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t164, ptr %t165)
  br label %bb59
bb59:
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l134, !tbaa !29
  %t169 = load i32, ptr %l8
  %t171 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t169)
  store { i64, ptr } %t171, ptr %l136
  br label %bb60
bb60:
  %t172 = load ptr, ptr %l134, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l136, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t172, { i64, ptr } %t173)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s8)
  br label %bb332
bb62:
  %t174 = load ptr, ptr %l1, !tbaa !29
  store ptr %t174, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t175 = load ptr, ptr %l137, !tbaa !29
  %t176 = icmp ne ptr %t175, null
  br i1 %t176, label %bb63, label %bb64
bb63:
  %t178 = load ptr, ptr %l137, !tbaa !29
  %t179 = load i64, ptr %t178
  %t181 = icmp eq i64 %t179, 5
  store i1 %t181, ptr %l138, !tbaa !21
  br label %bb64
bb64:
  %t182 = load i1, ptr %l138, !tbaa !21
  br i1 %t182, label %bb65, label %bb66
bb65:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t185, i32 0, i32 1
  %t187 = load i32, ptr %t186
  store i32 %t187, ptr %l10
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t191, i32 0, i32 2
  %t193 = load ptr, ptr %t192
  store ptr %t193, ptr %l11, !tbaa !29
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t197, i32 0, i32 3
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l12, !tbaa !29
  br label %bb67
bb66:
  br label %bb74
bb67:
  store %olang.scope zeroinitializer, ptr %s9
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t201, ptr %t202)
  br label %bb68
bb68:
  %t205 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t205, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb69
bb69:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l150, !tbaa !29
  %t208 = load i32, ptr %l10
  %t210 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t208)
  store { i64, ptr } %t210, ptr %l152
  br label %bb70
bb70:
  %t211 = load ptr, ptr %l150, !tbaa !29
  %t212 = load { i64, ptr }, ptr %l152, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t211, { i64, ptr } %t212)
  br label %bb71
bb71:
  %t213 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t213, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb72
bb72:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t215, ptr %t216)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s9)
  br label %bb332
bb74:
  %t219 = load ptr, ptr %l1, !tbaa !29
  store ptr %t219, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t220 = load ptr, ptr %l156, !tbaa !29
  %t221 = icmp ne ptr %t220, null
  br i1 %t221, label %bb75, label %bb76
bb75:
  %t223 = load ptr, ptr %l156, !tbaa !29
  %t224 = load i64, ptr %t223
  %t226 = icmp eq i64 %t224, 6
  store i1 %t226, ptr %l157, !tbaa !21
  br label %bb76
bb76:
  %t227 = load i1, ptr %l157, !tbaa !21
  br i1 %t227, label %bb77, label %bb78
bb77:
  %t228 = load ptr, ptr %l1, !tbaa !29
  %t230 = getelementptr { i64, [5 x i64] }, ptr %t228, i32 0, i32 1
  %t231 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t230, i32 0, i32 1
  %t232 = load ptr, ptr %t231
  store ptr %t232, ptr %l13, !tbaa !29
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t236 = getelementptr { i64, [5 x i64] }, ptr %t234, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t236, i32 0, i32 2
  %t238 = load ptr, ptr %t237
  store ptr %t238, ptr %l14, !tbaa !29
  br label %bb79
bb78:
  br label %bb83
bb79:
  store %olang.scope zeroinitializer, ptr %s10
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t240, ptr %t241)
  br label %bb80
bb80:
  %t244 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t244, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb81
bb81:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t246, ptr %t247)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s10)
  br label %bb332
bb83:
  %t250 = load ptr, ptr %l1, !tbaa !29
  store ptr %t250, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t251 = load ptr, ptr %l169, !tbaa !29
  %t252 = icmp ne ptr %t251, null
  br i1 %t252, label %bb84, label %bb85
bb84:
  %t254 = load ptr, ptr %l169, !tbaa !29
  %t255 = load i64, ptr %t254
  %t257 = icmp eq i64 %t255, 7
  store i1 %t257, ptr %l170, !tbaa !21
  br label %bb85
bb85:
  %t258 = load i1, ptr %l170, !tbaa !21
  br i1 %t258, label %bb86, label %bb87
bb86:
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr { i64, [5 x i64] }, ptr %t259, i32 0, i32 1
  %t262 = getelementptr { %"compiler/source:Span", ptr }, ptr %t261, i32 0, i32 1
  %t263 = load ptr, ptr %t262
  store ptr %t263, ptr %l15, !tbaa !29
  br label %bb88
bb87:
  br label %bb103
bb88:
  %t265 = load ptr, ptr %l15, !tbaa !29
  %t267 = getelementptr %"compiler/ast:Chain", ptr %t265, i32 0, i32 1
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !27
  store { i64, ptr } %t268, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t270 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t270, 0
  store i64 %t272, ptr %l18, !tbaa !24
  br label %bb89
bb89:
  %t274 = load i64, ptr %l17, !tbaa !24
  %t275 = load i64, ptr %l18, !tbaa !24
  %t278 = icmp slt i64 %t274, %t275
  %t280 = xor i1 %t278, true
  br i1 %t280, label %bb90, label %bb91
bb90:
  br label %bb102
bb91:
  br label %bb92
bb92:
  %t282 = load i64, ptr %l17, !tbaa !24
  store i64 %t282, ptr %l19, !tbaa !24
  %t284 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t284, ptr %l184, !tbaa !27
  %t285 = load i64, ptr %l17, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr ptr, ptr %t288, i64 %t285
  %t290 = load ptr, ptr %t289, !tbaa !39
  store ptr %t290, ptr %l20, !tbaa !29
  %t292 = load i64, ptr %l19, !tbaa !24
  %t294 = icmp sgt i64 %t292, 0
  br i1 %t294, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s14
  %t296 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t296, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t298 = load ptr, ptr %l0, !tbaa !29
  store ptr %t298, ptr %l190, !tbaa !29
  %t299 = load ptr, ptr %l15, !tbaa !29
  %t301 = getelementptr %"compiler/ast:Chain", ptr %t299, i32 0, i32 0
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  store { i64, ptr } %t302, ptr %l192, !tbaa !27
  %t303 = load i64, ptr %l19, !tbaa !24
  %t305 = sub i64 %t303, 1
  %t307 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i32, ptr %t308, i64 %t305
  %t310 = load i32, ptr %t309
  %t312 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s14, i32 %t310)
  store { i64, ptr } %t312, ptr %l196
  br label %bb96
bb96:
  %t313 = load ptr, ptr %l190, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l196, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t313, { i64, ptr } %t314)
  br label %bb97
bb97:
  %t315 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t315, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s14)
  br label %bb99
bb99:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t317, ptr %t318)
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t321 = load i64, ptr %l17, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l17, !tbaa !24
  br label %bb89
bb102:
  br label %bb332
bb103:
  %t325 = load ptr, ptr %l1, !tbaa !29
  store ptr %t325, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t326 = load ptr, ptr %l202, !tbaa !29
  %t327 = icmp ne ptr %t326, null
  br i1 %t327, label %bb104, label %bb105
bb104:
  %t329 = load ptr, ptr %l202, !tbaa !29
  %t330 = load i64, ptr %t329
  %t332 = icmp eq i64 %t330, 8
  store i1 %t332, ptr %l203, !tbaa !21
  br label %bb105
bb105:
  %t333 = load i1, ptr %l203, !tbaa !21
  br i1 %t333, label %bb106, label %bb107
bb106:
  %t334 = load ptr, ptr %l1, !tbaa !29
  %t336 = getelementptr { i64, [5 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t336, i32 0, i32 1
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l21, !tbaa !29
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr { i64, [5 x i64] }, ptr %t340, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t342, i32 0, i32 2
  %t344 = load ptr, ptr %t343
  store ptr %t344, ptr %l22, !tbaa !29
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t348 = getelementptr { i64, [5 x i64] }, ptr %t346, i32 0, i32 1
  %t349 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t348, i32 0, i32 3
  %t350 = load ptr, ptr %t349
  store ptr %t350, ptr %l23, !tbaa !29
  br label %bb108
bb107:
  br label %bb114
bb108:
  store %olang.scope zeroinitializer, ptr %s16
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t352, ptr %t353)
  br label %bb109
bb109:
  %t356 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t356, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb110
bb110:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t358, ptr %t359)
  br label %bb111
bb111:
  %t362 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t362, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) })
  br label %bb112
bb112:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t364, ptr %t365)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s16)
  br label %bb332
bb114:
  %t368 = load ptr, ptr %l1, !tbaa !29
  store ptr %t368, ptr %l220, !tbaa !29
  store i1 false, ptr %l221, !tbaa !21
  %t369 = load ptr, ptr %l220, !tbaa !29
  %t370 = icmp ne ptr %t369, null
  br i1 %t370, label %bb115, label %bb116
bb115:
  %t372 = load ptr, ptr %l220, !tbaa !29
  %t373 = load i64, ptr %t372
  %t375 = icmp eq i64 %t373, 9
  store i1 %t375, ptr %l221, !tbaa !21
  br label %bb116
bb116:
  %t376 = load i1, ptr %l221, !tbaa !21
  br i1 %t376, label %bb117, label %bb118
bb117:
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr { i64, [5 x i64] }, ptr %t377, i32 0, i32 1
  %t380 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t379, i32 0, i32 1
  %t381 = load ptr, ptr %t380
  store ptr %t381, ptr %l24, !tbaa !29
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = getelementptr { i64, [5 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t385, i32 0, i32 2
  %t387 = load ptr, ptr %t386
  store ptr %t387, ptr %l25, !tbaa !29
  %t389 = load ptr, ptr %l1, !tbaa !29
  %t391 = getelementptr { i64, [5 x i64] }, ptr %t389, i32 0, i32 1
  %t392 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t391, i32 0, i32 3
  %t393 = load i1, ptr %t392
  store i1 %t393, ptr %l26, !tbaa !21
  br label %bb119
bb118:
  br label %bb126
bb119:
  store %olang.scope zeroinitializer, ptr %s17
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t395, ptr %t396)
  br label %bb120
bb120:
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l232, !tbaa !29
  %t400 = load i1, ptr %l26, !tbaa !21
  br i1 %t400, label %bb121, label %bb122
bb121:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l234, !tbaa !27
  br label %bb123
bb122:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l234, !tbaa !27
  br label %bb123
bb123:
  %t402 = load ptr, ptr %l232, !tbaa !29
  %t403 = load { i64, ptr }, ptr %l234, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t402, { i64, ptr } %t403)
  br label %bb124
bb124:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t404, ptr %t405)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s17)
  br label %bb332
bb126:
  %t408 = load ptr, ptr %l1, !tbaa !29
  store ptr %t408, ptr %l237, !tbaa !29
  store i1 false, ptr %l238, !tbaa !21
  %t409 = load ptr, ptr %l237, !tbaa !29
  %t410 = icmp ne ptr %t409, null
  br i1 %t410, label %bb127, label %bb128
bb127:
  %t412 = load ptr, ptr %l237, !tbaa !29
  %t413 = load i64, ptr %t412
  %t415 = icmp eq i64 %t413, 10
  store i1 %t415, ptr %l238, !tbaa !21
  br label %bb128
bb128:
  %t416 = load i1, ptr %l238, !tbaa !21
  br i1 %t416, label %bb129, label %bb130
bb129:
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr { i64, [5 x i64] }, ptr %t417, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t419, i32 0, i32 1
  %t421 = load ptr, ptr %t420
  store ptr %t421, ptr %l27, !tbaa !29
  %t423 = load ptr, ptr %l1, !tbaa !29
  %t425 = getelementptr { i64, [5 x i64] }, ptr %t423, i32 0, i32 1
  %t426 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t425, i32 0, i32 2
  %t427 = load ptr, ptr %t426
  store ptr %t427, ptr %l28, !tbaa !29
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t431, i32 0, i32 3
  %t433 = load i1, ptr %t432
  store i1 %t433, ptr %l29, !tbaa !21
  br label %bb131
bb130:
  br label %bb138
bb131:
  store %olang.scope zeroinitializer, ptr %s18
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t435, ptr %t436)
  br label %bb132
bb132:
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l249, !tbaa !29
  %t440 = load i1, ptr %l29, !tbaa !21
  br i1 %t440, label %bb133, label %bb134
bb133:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l251, !tbaa !27
  br label %bb135
bb134:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l251, !tbaa !27
  br label %bb135
bb135:
  %t442 = load ptr, ptr %l249, !tbaa !29
  %t443 = load { i64, ptr }, ptr %l251, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t442, { i64, ptr } %t443)
  br label %bb136
bb136:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t444, ptr %t445)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s18)
  br label %bb332
bb138:
  %t448 = load ptr, ptr %l1, !tbaa !29
  store ptr %t448, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t449 = load ptr, ptr %l254, !tbaa !29
  %t450 = icmp ne ptr %t449, null
  br i1 %t450, label %bb139, label %bb140
bb139:
  %t452 = load ptr, ptr %l254, !tbaa !29
  %t453 = load i64, ptr %t452
  %t455 = icmp eq i64 %t453, 11
  store i1 %t455, ptr %l255, !tbaa !21
  br label %bb140
bb140:
  %t456 = load i1, ptr %l255, !tbaa !21
  br i1 %t456, label %bb141, label %bb142
bb141:
  %t457 = load ptr, ptr %l1, !tbaa !29
  %t459 = getelementptr { i64, [5 x i64] }, ptr %t457, i32 0, i32 1
  %t460 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t459, i32 0, i32 1
  %t461 = load ptr, ptr %t460
  store ptr %t461, ptr %l30, !tbaa !29
  %t463 = load ptr, ptr %l1, !tbaa !29
  %t465 = getelementptr { i64, [5 x i64] }, ptr %t463, i32 0, i32 1
  %t466 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t465, i32 0, i32 2
  %t467 = load ptr, ptr %t466
  store ptr %t467, ptr %l31, !tbaa !29
  br label %bb143
bb142:
  br label %bb147
bb143:
  store %olang.scope zeroinitializer, ptr %s19
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t469, ptr %t470)
  br label %bb144
bb144:
  %t473 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t473, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb145
bb145:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t475, ptr %t476)
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s19)
  br label %bb332
bb147:
  %t479 = load ptr, ptr %l1, !tbaa !29
  store ptr %t479, ptr %l267, !tbaa !29
  store i1 false, ptr %l268, !tbaa !21
  %t480 = load ptr, ptr %l267, !tbaa !29
  %t481 = icmp ne ptr %t480, null
  br i1 %t481, label %bb148, label %bb149
bb148:
  %t483 = load ptr, ptr %l267, !tbaa !29
  %t484 = load i64, ptr %t483
  %t486 = icmp eq i64 %t484, 12
  store i1 %t486, ptr %l268, !tbaa !21
  br label %bb149
bb149:
  %t487 = load i1, ptr %l268, !tbaa !21
  br i1 %t487, label %bb150, label %bb151
bb150:
  %t488 = load ptr, ptr %l1, !tbaa !29
  %t490 = getelementptr { i64, [5 x i64] }, ptr %t488, i32 0, i32 1
  %t491 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t490, i32 0, i32 1
  %t492 = load ptr, ptr %t491
  store ptr %t492, ptr %l32, !tbaa !29
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t496 = getelementptr { i64, [5 x i64] }, ptr %t494, i32 0, i32 1
  %t497 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t496, i32 0, i32 2
  %t498 = load { i64, ptr }, ptr %t497
  store { i64, ptr } %t498, ptr %l33, !tbaa !27
  br label %bb152
bb151:
  br label %bb157
bb152:
  store %olang.scope zeroinitializer, ptr %s20
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t500, ptr %t501)
  br label %bb153
bb153:
  %t504 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t504, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb154
bb154:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t506, { i64, ptr } %t507)
  br label %bb155
bb155:
  %t510 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t510, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s20)
  br label %bb332
bb157:
  %t512 = load ptr, ptr %l1, !tbaa !29
  store ptr %t512, ptr %l281, !tbaa !29
  store i1 false, ptr %l282, !tbaa !21
  %t513 = load ptr, ptr %l281, !tbaa !29
  %t514 = icmp ne ptr %t513, null
  br i1 %t514, label %bb158, label %bb159
bb158:
  %t516 = load ptr, ptr %l281, !tbaa !29
  %t517 = load i64, ptr %t516
  %t519 = icmp eq i64 %t517, 13
  store i1 %t519, ptr %l282, !tbaa !21
  br label %bb159
bb159:
  %t520 = load i1, ptr %l282, !tbaa !21
  br i1 %t520, label %bb160, label %bb161
bb160:
  %t521 = load ptr, ptr %l1, !tbaa !29
  %t523 = getelementptr { i64, [5 x i64] }, ptr %t521, i32 0, i32 1
  %t524 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t523, i32 0, i32 1
  %t525 = load ptr, ptr %t524
  store ptr %t525, ptr %l34, !tbaa !29
  %t527 = load ptr, ptr %l1, !tbaa !29
  %t529 = getelementptr { i64, [5 x i64] }, ptr %t527, i32 0, i32 1
  %t530 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t529, i32 0, i32 2
  %t531 = load i32, ptr %t530
  store i32 %t531, ptr %l35, !tbaa !23
  %t533 = load ptr, ptr %l1, !tbaa !29
  %t535 = getelementptr { i64, [5 x i64] }, ptr %t533, i32 0, i32 1
  %t536 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t535, i32 0, i32 3
  %t537 = load { i64, ptr }, ptr %t536
  store { i64, ptr } %t537, ptr %l36, !tbaa !27
  br label %bb162
bb161:
  br label %bb169
bb162:
  store %olang.scope zeroinitializer, ptr %s21
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t539, ptr %t540)
  br label %bb163
bb163:
  %t543 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t543, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) })
  br label %bb164
bb164:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load i32, ptr %l35, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t545, i32 %t546)
  br label %bb165
bb165:
  %t549 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t549, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) })
  br label %bb166
bb166:
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t552 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t551, { i64, ptr } %t552)
  br label %bb167
bb167:
  %t555 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t555, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) })
  br label %bb168
bb168:
  call void @__olang_scope_close(ptr %s21)
  br label %bb332
bb169:
  %t557 = load ptr, ptr %l1, !tbaa !29
  store ptr %t557, ptr %l300, !tbaa !29
  store i1 false, ptr %l301, !tbaa !21
  %t558 = load ptr, ptr %l300, !tbaa !29
  %t559 = icmp ne ptr %t558, null
  br i1 %t559, label %bb170, label %bb171
bb170:
  %t561 = load ptr, ptr %l300, !tbaa !29
  %t562 = load i64, ptr %t561
  %t564 = icmp eq i64 %t562, 14
  store i1 %t564, ptr %l301, !tbaa !21
  br label %bb171
bb171:
  %t565 = load i1, ptr %l301, !tbaa !21
  br i1 %t565, label %bb172, label %bb173
bb172:
  %t566 = load ptr, ptr %l1, !tbaa !29
  %t568 = getelementptr { i64, [5 x i64] }, ptr %t566, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t568, i32 0, i32 1
  %t570 = load ptr, ptr %t569
  store ptr %t570, ptr %l37, !tbaa !29
  %t572 = load ptr, ptr %l1, !tbaa !29
  %t574 = getelementptr { i64, [5 x i64] }, ptr %t572, i32 0, i32 1
  %t575 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t574, i32 0, i32 2
  %t576 = load { i64, ptr }, ptr %t575
  store { i64, ptr } %t576, ptr %l38, !tbaa !27
  br label %bb174
bb173:
  br label %bb179
bb174:
  store %olang.scope zeroinitializer, ptr %s22
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t578, ptr %t579)
  br label %bb175
bb175:
  %t582 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t582, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) })
  br label %bb176
bb176:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t584, { i64, ptr } %t585)
  br label %bb177
bb177:
  %t588 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t588, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s22)
  br label %bb332
bb179:
  %t590 = load ptr, ptr %l1, !tbaa !29
  store ptr %t590, ptr %l314, !tbaa !29
  store i1 false, ptr %l315, !tbaa !21
  %t591 = load ptr, ptr %l314, !tbaa !29
  %t592 = icmp ne ptr %t591, null
  br i1 %t592, label %bb180, label %bb181
bb180:
  %t594 = load ptr, ptr %l314, !tbaa !29
  %t595 = load i64, ptr %t594
  %t597 = icmp eq i64 %t595, 15
  store i1 %t597, ptr %l315, !tbaa !21
  br label %bb181
bb181:
  %t598 = load i1, ptr %l315, !tbaa !21
  br i1 %t598, label %bb182, label %bb183
bb182:
  %t599 = load ptr, ptr %l1, !tbaa !29
  %t601 = getelementptr { i64, [5 x i64] }, ptr %t599, i32 0, i32 1
  %t602 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t601, i32 0, i32 1
  %t603 = load ptr, ptr %t602
  store ptr %t603, ptr %l39, !tbaa !29
  %t605 = load ptr, ptr %l1, !tbaa !29
  %t607 = getelementptr { i64, [5 x i64] }, ptr %t605, i32 0, i32 1
  %t608 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t607, i32 0, i32 2
  %t609 = load i32, ptr %t608
  store i32 %t609, ptr %l40, !tbaa !23
  br label %bb184
bb183:
  br label %bb188
bb184:
  store %olang.scope zeroinitializer, ptr %s23
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t611, ptr %t612)
  br label %bb185
bb185:
  %t615 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t615, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) })
  br label %bb186
bb186:
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t618 = load i32, ptr %l40, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t617, i32 %t618)
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s23)
  br label %bb332
bb188:
  %t621 = load ptr, ptr %l1, !tbaa !29
  store ptr %t621, ptr %l327, !tbaa !29
  store i1 false, ptr %l328, !tbaa !21
  %t622 = load ptr, ptr %l327, !tbaa !29
  %t623 = icmp ne ptr %t622, null
  br i1 %t623, label %bb189, label %bb190
bb189:
  %t625 = load ptr, ptr %l327, !tbaa !29
  %t626 = load i64, ptr %t625
  %t628 = icmp eq i64 %t626, 16
  store i1 %t628, ptr %l328, !tbaa !21
  br label %bb190
bb190:
  %t629 = load i1, ptr %l328, !tbaa !21
  br i1 %t629, label %bb191, label %bb192
bb191:
  %t630 = load ptr, ptr %l1, !tbaa !29
  %t632 = getelementptr { i64, [5 x i64] }, ptr %t630, i32 0, i32 1
  %t633 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t632, i32 0, i32 1
  %t634 = load ptr, ptr %t633
  store ptr %t634, ptr %l41, !tbaa !29
  %t636 = load ptr, ptr %l1, !tbaa !29
  %t638 = getelementptr { i64, [5 x i64] }, ptr %t636, i32 0, i32 1
  %t639 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t638, i32 0, i32 2
  %t640 = load { i64, ptr }, ptr %t639
  store { i64, ptr } %t640, ptr %l42, !tbaa !27
  br label %bb193
bb192:
  br label %bb198
bb193:
  store %olang.scope zeroinitializer, ptr %s24
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t642, ptr %t643)
  br label %bb194
bb194:
  %t646 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t646, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) })
  br label %bb195
bb195:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load { i64, ptr }, ptr %l42, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t648, { i64, ptr } %t649)
  br label %bb196
bb196:
  %t652 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t652, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) })
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s24)
  br label %bb332
bb198:
  %t654 = load ptr, ptr %l1, !tbaa !29
  store ptr %t654, ptr %l341, !tbaa !29
  store i1 false, ptr %l342, !tbaa !21
  %t655 = load ptr, ptr %l341, !tbaa !29
  %t656 = icmp ne ptr %t655, null
  br i1 %t656, label %bb199, label %bb200
bb199:
  %t658 = load ptr, ptr %l341, !tbaa !29
  %t659 = load i64, ptr %t658
  %t661 = icmp eq i64 %t659, 17
  store i1 %t661, ptr %l342, !tbaa !21
  br label %bb200
bb200:
  %t662 = load i1, ptr %l342, !tbaa !21
  br i1 %t662, label %bb201, label %bb202
bb201:
  %t663 = load ptr, ptr %l1, !tbaa !29
  %t665 = getelementptr { i64, [5 x i64] }, ptr %t663, i32 0, i32 1
  %t666 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t665, i32 0, i32 1
  %t667 = load ptr, ptr %t666
  store ptr %t667, ptr %l43, !tbaa !29
  %t669 = load ptr, ptr %l1, !tbaa !29
  %t671 = getelementptr { i64, [5 x i64] }, ptr %t669, i32 0, i32 1
  %t672 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t671, i32 0, i32 2
  %t673 = load ptr, ptr %t672
  store ptr %t673, ptr %l44, !tbaa !29
  %t675 = load ptr, ptr %l1, !tbaa !29
  %t677 = getelementptr { i64, [5 x i64] }, ptr %t675, i32 0, i32 1
  %t678 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t677, i32 0, i32 3
  %t679 = load ptr, ptr %t678
  store ptr %t679, ptr %l45, !tbaa !29
  br label %bb203
bb202:
  br label %bb216
bb203:
  store %olang.scope zeroinitializer, ptr %s25
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t682 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t681, ptr %t682)
  br label %bb204
bb204:
  %t685 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t685, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) })
  br label %bb205
bb205:
  %t687 = load ptr, ptr %l44, !tbaa !29
  %t689 = icmp eq ptr %t687, null
  %t691 = xor i1 %t689, true
  br i1 %t691, label %bb206, label %bb207
bb206:
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t694 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t693, ptr %t694)
  br label %bb208
bb207:
  br label %bb209
bb208:
  br label %bb209
bb209:
  %t697 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t697, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb210
bb210:
  %t699 = load ptr, ptr %l45, !tbaa !29
  %t701 = icmp eq ptr %t699, null
  %t703 = xor i1 %t701, true
  br i1 %t703, label %bb211, label %bb212
bb211:
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t705, ptr %t706)
  br label %bb213
bb212:
  br label %bb214
bb213:
  br label %bb214
bb214:
  %t709 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t709, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) })
  br label %bb215
bb215:
  call void @__olang_scope_close(ptr %s25)
  br label %bb332
bb216:
  %t711 = load ptr, ptr %l1, !tbaa !29
  store ptr %t711, ptr %l366, !tbaa !29
  store i1 false, ptr %l367, !tbaa !21
  %t712 = load ptr, ptr %l366, !tbaa !29
  %t713 = icmp ne ptr %t712, null
  br i1 %t713, label %bb217, label %bb218
bb217:
  %t715 = load ptr, ptr %l366, !tbaa !29
  %t716 = load i64, ptr %t715
  %t718 = icmp eq i64 %t716, 18
  store i1 %t718, ptr %l367, !tbaa !21
  br label %bb218
bb218:
  %t719 = load i1, ptr %l367, !tbaa !21
  br i1 %t719, label %bb219, label %bb220
bb219:
  %t720 = load ptr, ptr %l1, !tbaa !29
  %t722 = getelementptr { i64, [5 x i64] }, ptr %t720, i32 0, i32 1
  %t723 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t722, i32 0, i32 1
  %t724 = load ptr, ptr %t723
  store ptr %t724, ptr %l46, !tbaa !29
  %t726 = load ptr, ptr %l1, !tbaa !29
  %t728 = getelementptr { i64, [5 x i64] }, ptr %t726, i32 0, i32 1
  %t729 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t728, i32 0, i32 2
  %t730 = load { i64, ptr }, ptr %t729
  store { i64, ptr } %t730, ptr %l47, !tbaa !27
  br label %bb221
bb220:
  br label %bb229
bb221:
  store %olang.scope zeroinitializer, ptr %s28
  %t732 = load ptr, ptr %l0, !tbaa !29
  store ptr %t732, ptr %l374, !tbaa !29
  %t733 = load ptr, ptr %l46, !tbaa !29
  %t735 = icmp eq ptr %t733, null
  br i1 %t735, label %bb222, label %bb223
bb222:
  call void @__olang_check_failed(ptr @olang_loc_577bb2401887ee03_bd83bee27b444ed7)
  unreachable
bb223:
  br label %bb224
bb224:
  %t737 = load ptr, ptr %l46, !tbaa !29
  %t738 = load ptr, ptr %l374, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t738, ptr %t737)
  br label %bb225
bb225:
  %t740 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t740, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb226
bb226:
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t743 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t742, { i64, ptr } %t743)
  br label %bb227
bb227:
  %t746 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t746, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) })
  br label %bb228
bb228:
  call void @__olang_scope_close(ptr %s28)
  br label %bb332
bb229:
  %t748 = load ptr, ptr %l1, !tbaa !29
  store ptr %t748, ptr %l382, !tbaa !29
  store i1 false, ptr %l383, !tbaa !21
  %t749 = load ptr, ptr %l382, !tbaa !29
  %t750 = icmp ne ptr %t749, null
  br i1 %t750, label %bb230, label %bb231
bb230:
  %t752 = load ptr, ptr %l382, !tbaa !29
  %t753 = load i64, ptr %t752
  %t755 = icmp eq i64 %t753, 19
  store i1 %t755, ptr %l383, !tbaa !21
  br label %bb231
bb231:
  %t756 = load i1, ptr %l383, !tbaa !21
  br i1 %t756, label %bb232, label %bb233
bb232:
  %t757 = load ptr, ptr %l1, !tbaa !29
  %t759 = getelementptr { i64, [5 x i64] }, ptr %t757, i32 0, i32 1
  %t760 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t759, i32 0, i32 1
  %t761 = load { i64, ptr }, ptr %t760
  store { i64, ptr } %t761, ptr %l48, !tbaa !27
  br label %bb234
bb233:
  br label %bb238
bb234:
  store %olang.scope zeroinitializer, ptr %s29
  %t763 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t763, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb235
bb235:
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t766 = load { i64, ptr }, ptr %l48, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t765, { i64, ptr } %t766)
  br label %bb236
bb236:
  %t769 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t769, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) })
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s29)
  br label %bb332
bb238:
  %t771 = load ptr, ptr %l1, !tbaa !29
  store ptr %t771, ptr %l392, !tbaa !29
  store i1 false, ptr %l393, !tbaa !21
  %t772 = load ptr, ptr %l392, !tbaa !29
  %t773 = icmp ne ptr %t772, null
  br i1 %t773, label %bb239, label %bb240
bb239:
  %t775 = load ptr, ptr %l392, !tbaa !29
  %t776 = load i64, ptr %t775
  %t778 = icmp eq i64 %t776, 20
  store i1 %t778, ptr %l393, !tbaa !21
  br label %bb240
bb240:
  %t779 = load i1, ptr %l393, !tbaa !21
  br i1 %t779, label %bb241, label %bb242
bb241:
  %t780 = load ptr, ptr %l1, !tbaa !29
  %t782 = getelementptr { i64, [5 x i64] }, ptr %t780, i32 0, i32 1
  %t783 = getelementptr { %"compiler/source:Span", ptr }, ptr %t782, i32 0, i32 1
  %t784 = load ptr, ptr %t783
  store ptr %t784, ptr %l49, !tbaa !29
  br label %bb243
bb242:
  br label %bb274
bb243:
  store %olang.scope zeroinitializer, ptr %s30
  %t786 = load ptr, ptr %l49, !tbaa !29
  %t788 = getelementptr %"compiler/ast:Compr", ptr %t786, i32 0, i32 6
  %t789 = load i1, ptr %t788, !tbaa !21
  %t791 = xor i1 %t789, true
  br i1 %t791, label %bb244, label %bb245
bb244:
  store %olang.scope zeroinitializer, ptr %s31
  %t793 = load ptr, ptr %l0, !tbaa !29
  store ptr %t793, ptr %l401, !tbaa !29
  %t794 = load ptr, ptr %l49, !tbaa !29
  %t796 = getelementptr %"compiler/ast:Compr", ptr %t794, i32 0, i32 0
  %t797 = load ptr, ptr %t796, !tbaa !29
  %t799 = icmp eq ptr %t797, null
  br i1 %t799, label %bb246, label %bb247
bb245:
  br label %bb251
bb246:
  call void @__olang_check_failed(ptr @olang_loc_47b511f5ef6d9e74_baf04e552c3da2b8)
  unreachable
bb247:
  br label %bb248
bb248:
  %t801 = load ptr, ptr %l49, !tbaa !29
  %t803 = getelementptr %"compiler/ast:Compr", ptr %t801, i32 0, i32 0
  %t804 = load ptr, ptr %t803, !tbaa !29
  %t805 = load ptr, ptr %l401, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t805, ptr %t804)
  br label %bb249
bb249:
  %t807 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t807, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) })
  br label %bb250
bb250:
  call void @__olang_scope_close(ptr %s31)
  br label %bb251
bb251:
  %t809 = load ptr, ptr %l0, !tbaa !29
  %t810 = load ptr, ptr %l49, !tbaa !29
  %t812 = getelementptr %"compiler/ast:Compr", ptr %t810, i32 0, i32 1
  %t813 = load ptr, ptr %t812, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t809, ptr %t813)
  br label %bb252
bb252:
  %t816 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t816, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) })
  br label %bb253
bb253:
  %t818 = load ptr, ptr %l49, !tbaa !29
  %t820 = getelementptr %"compiler/ast:Compr", ptr %t818, i32 0, i32 2
  %t821 = load i32, ptr %t820, !tbaa !23
  %t823 = icmp ne i32 %t821, 0
  br i1 %t823, label %bb254, label %bb255
bb254:
  store %olang.scope zeroinitializer, ptr %s32
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t826 = load ptr, ptr %l49, !tbaa !29
  %t828 = getelementptr %"compiler/ast:Compr", ptr %t826, i32 0, i32 2
  %t829 = load i32, ptr %t828, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t825, i32 %t829)
  br label %bb256
bb255:
  br label %bb258
bb256:
  %t832 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s32, ptr %t832, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) })
  br label %bb257
bb257:
  call void @__olang_scope_close(ptr %s32)
  br label %bb258
bb258:
  %t834 = load ptr, ptr %l0, !tbaa !29
  %t835 = load ptr, ptr %l49, !tbaa !29
  %t837 = getelementptr %"compiler/ast:Compr", ptr %t835, i32 0, i32 3
  %t838 = load i32, ptr %t837, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t834, i32 %t838)
  br label %bb259
bb259:
  %t841 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t841, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) })
  br label %bb260
bb260:
  %t843 = load ptr, ptr %l0, !tbaa !29
  %t844 = load ptr, ptr %l49, !tbaa !29
  %t846 = getelementptr %"compiler/ast:Compr", ptr %t844, i32 0, i32 4
  %t847 = load ptr, ptr %t846, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t843, ptr %t847)
  br label %bb261
bb261:
  %t850 = load ptr, ptr %l49, !tbaa !29
  %t852 = getelementptr %"compiler/ast:Compr", ptr %t850, i32 0, i32 5
  %t853 = load ptr, ptr %t852, !tbaa !29
  %t855 = icmp eq ptr %t853, null
  %t857 = xor i1 %t855, true
  br i1 %t857, label %bb262, label %bb263
bb262:
  store %olang.scope zeroinitializer, ptr %s33
  %t859 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s33, ptr %t859, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) })
  br label %bb264
bb263:
  br label %bb269
bb264:
  %t861 = load ptr, ptr %l0, !tbaa !29
  store ptr %t861, ptr %l431, !tbaa !29
  %t862 = load ptr, ptr %l49, !tbaa !29
  %t864 = getelementptr %"compiler/ast:Compr", ptr %t862, i32 0, i32 5
  %t865 = load ptr, ptr %t864, !tbaa !29
  %t867 = icmp eq ptr %t865, null
  br i1 %t867, label %bb265, label %bb266
bb265:
  call void @__olang_check_failed(ptr @olang_loc_e6dde321a76d1169_ef8c066898e78ecd)
  unreachable
bb266:
  br label %bb267
bb267:
  %t869 = load ptr, ptr %l49, !tbaa !29
  %t871 = getelementptr %"compiler/ast:Compr", ptr %t869, i32 0, i32 5
  %t872 = load ptr, ptr %t871, !tbaa !29
  %t873 = load ptr, ptr %l431, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t873, ptr %t872)
  br label %bb268
bb268:
  call void @__olang_scope_close(ptr %s33)
  br label %bb269
bb269:
  %t875 = load ptr, ptr %l49, !tbaa !29
  %t877 = getelementptr %"compiler/ast:Compr", ptr %t875, i32 0, i32 6
  %t878 = load i1, ptr %t877, !tbaa !21
  %t880 = xor i1 %t878, true
  br i1 %t880, label %bb270, label %bb271
bb270:
  store %olang.scope zeroinitializer, ptr %s34
  %t882 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s34, ptr %t882, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) })
  br label %bb272
bb271:
  br label %bb273
bb272:
  call void @__olang_scope_close(ptr %s34)
  br label %bb273
bb273:
  call void @__olang_scope_close(ptr %s30)
  br label %bb332
bb274:
  %t884 = load ptr, ptr %l1, !tbaa !29
  store ptr %t884, ptr %l441, !tbaa !29
  store i1 false, ptr %l442, !tbaa !21
  %t885 = load ptr, ptr %l441, !tbaa !29
  %t886 = icmp ne ptr %t885, null
  br i1 %t886, label %bb275, label %bb276
bb275:
  %t888 = load ptr, ptr %l441, !tbaa !29
  %t889 = load i64, ptr %t888
  %t891 = icmp eq i64 %t889, 21
  store i1 %t891, ptr %l442, !tbaa !21
  br label %bb276
bb276:
  %t892 = load i1, ptr %l442, !tbaa !21
  br i1 %t892, label %bb277, label %bb278
bb277:
  %t893 = load ptr, ptr %l1, !tbaa !29
  %t895 = getelementptr { i64, [5 x i64] }, ptr %t893, i32 0, i32 1
  %t896 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t895, i32 0, i32 1
  %t897 = load { i64, ptr }, ptr %t896
  store { i64, ptr } %t897, ptr %l50, !tbaa !27
  br label %bb279
bb278:
  br label %bb291
bb279:
  %t899 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t899, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t901 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t903 = extractvalue { i64, ptr } %t901, 0
  store i64 %t903, ptr %l53, !tbaa !24
  br label %bb280
bb280:
  %t905 = load i64, ptr %l52, !tbaa !24
  %t906 = load i64, ptr %l53, !tbaa !24
  %t909 = icmp slt i64 %t905, %t906
  %t911 = xor i1 %t909, true
  br i1 %t911, label %bb281, label %bb282
bb281:
  br label %bb290
bb282:
  br label %bb283
bb283:
  %t913 = load i64, ptr %l52, !tbaa !24
  %t915 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t915, ptr %l455, !tbaa !27
  %t916 = load i64, ptr %l52, !tbaa !24
  %t918 = getelementptr { i64, ptr }, ptr %l455, i32 0, i32 1
  %t919 = load ptr, ptr %t918, !tbaa !27
  %t920 = getelementptr ptr, ptr %t919, i64 %t916
  %t921 = load ptr, ptr %t920, !tbaa !39
  store ptr %t921, ptr %l55, !tbaa !29
  %t925 = icmp sgt i64 %t913, 0
  br i1 %t925, label %bb284, label %bb285
bb284:
  store %olang.scope zeroinitializer, ptr %s38
  %t927 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s38, ptr %t927, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) })
  br label %bb286
bb285:
  br label %bb287
bb286:
  call void @__olang_scope_close(ptr %s38)
  br label %bb287
bb287:
  %t929 = load ptr, ptr %l0, !tbaa !29
  %t930 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t929, ptr %t930)
  br label %bb288
bb288:
  br label %bb289
bb289:
  %t933 = load i64, ptr %l52, !tbaa !24
  %t935 = add i64 %t933, 1
  store i64 %t935, ptr %l52, !tbaa !24
  br label %bb280
bb290:
  br label %bb332
bb291:
  %t937 = load ptr, ptr %l1, !tbaa !29
  store ptr %t937, ptr %l465, !tbaa !29
  store i1 false, ptr %l466, !tbaa !21
  %t938 = load ptr, ptr %l465, !tbaa !29
  %t939 = icmp ne ptr %t938, null
  br i1 %t939, label %bb292, label %bb293
bb292:
  %t941 = load ptr, ptr %l465, !tbaa !29
  %t942 = load i64, ptr %t941
  %t944 = icmp eq i64 %t942, 22
  store i1 %t944, ptr %l466, !tbaa !21
  br label %bb293
bb293:
  %t945 = load i1, ptr %l466, !tbaa !21
  br i1 %t945, label %bb294, label %bb295
bb294:
  %t946 = load ptr, ptr %l1, !tbaa !29
  %t948 = getelementptr { i64, [5 x i64] }, ptr %t946, i32 0, i32 1
  %t949 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t948, i32 0, i32 1
  %t950 = load ptr, ptr %t949
  store ptr %t950, ptr %l56, !tbaa !29
  %t952 = load ptr, ptr %l1, !tbaa !29
  %t954 = getelementptr { i64, [5 x i64] }, ptr %t952, i32 0, i32 1
  %t955 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t954, i32 0, i32 2
  %t956 = load { i64, ptr }, ptr %t955
  store { i64, ptr } %t956, ptr %l57, !tbaa !27
  br label %bb296
bb295:
  br label %bb300
bb296:
  store %olang.scope zeroinitializer, ptr %s40
  %t958 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s40, ptr %t958, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d75, i32 0, i32 1) })
  br label %bb297
bb297:
  %t960 = load ptr, ptr %l0, !tbaa !29
  %t961 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t960, ptr %t961)
  br label %bb298
bb298:
  %t964 = load ptr, ptr %l0, !tbaa !29
  %t965 = load { i64, ptr }, ptr %l57, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t964, { i64, ptr } %t965)
  br label %bb299
bb299:
  call void @__olang_scope_close(ptr %s40)
  br label %bb332
bb300:
  %t968 = load ptr, ptr %l1, !tbaa !29
  store ptr %t968, ptr %l478, !tbaa !29
  store i1 false, ptr %l479, !tbaa !21
  %t969 = load ptr, ptr %l478, !tbaa !29
  %t970 = icmp ne ptr %t969, null
  br i1 %t970, label %bb301, label %bb302
bb301:
  %t972 = load ptr, ptr %l478, !tbaa !29
  %t973 = load i64, ptr %t972
  %t975 = icmp eq i64 %t973, 23
  store i1 %t975, ptr %l479, !tbaa !21
  br label %bb302
bb302:
  %t976 = load i1, ptr %l479, !tbaa !21
  br i1 %t976, label %bb303, label %bb304
bb303:
  %t977 = load ptr, ptr %l1, !tbaa !29
  %t979 = getelementptr { i64, [5 x i64] }, ptr %t977, i32 0, i32 1
  %t980 = getelementptr { %"compiler/source:Span", ptr }, ptr %t979, i32 0, i32 1
  %t981 = load ptr, ptr %t980
  store ptr %t981, ptr %l58, !tbaa !29
  br label %bb305
bb304:
  br label %bb309
bb305:
  store %olang.scope zeroinitializer, ptr %s41
  %t983 = load ptr, ptr %l0, !tbaa !29
  %t985 = getelementptr %"compiler/unparse:writer", ptr %t983, i32 0, i32 6
  %t986 = load i1, ptr %t985, !tbaa !21
  store i1 %t986, ptr %l59, !tbaa !21
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t990 = getelementptr %"compiler/unparse:writer", ptr %t988, i32 0, i32 6
  store i1 false, ptr %t990, !tbaa !21
  %t991 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s41, ptr %t991, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) })
  br label %bb306
bb306:
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t994 = load ptr, ptr %l58, !tbaa !29
  %t996 = getelementptr %"compiler/ast:Func", ptr %t994, i32 0, i32 3
  %t997 = load ptr, ptr %t996, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t993, ptr %t997)
  br label %bb307
bb307:
  %t1000 = load ptr, ptr %l0, !tbaa !29
  %t1001 = load i1, ptr %l59, !tbaa !21
  %t1004 = getelementptr %"compiler/unparse:writer", ptr %t1000, i32 0, i32 6
  store i1 %t1001, ptr %t1004, !tbaa !21
  %t1005 = load ptr, ptr %l0, !tbaa !29
  %t1006 = load ptr, ptr %l58, !tbaa !29
  %t1008 = getelementptr %"compiler/ast:Func", ptr %t1006, i32 0, i32 4
  %t1009 = load { i64, ptr }, ptr %t1008, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t1005, { i64, ptr } %t1009)
  br label %bb308
bb308:
  call void @__olang_scope_close(ptr %s41)
  br label %bb332
bb309:
  %t1012 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1012, ptr %l496, !tbaa !29
  store i1 false, ptr %l497, !tbaa !21
  %t1013 = load ptr, ptr %l496, !tbaa !29
  %t1014 = icmp ne ptr %t1013, null
  br i1 %t1014, label %bb310, label %bb311
bb310:
  %t1016 = load ptr, ptr %l496, !tbaa !29
  %t1017 = load i64, ptr %t1016
  %t1019 = icmp eq i64 %t1017, 24
  store i1 %t1019, ptr %l497, !tbaa !21
  br label %bb311
bb311:
  %t1020 = load i1, ptr %l497, !tbaa !21
  br i1 %t1020, label %bb312, label %bb313
bb312:
  %t1021 = load ptr, ptr %l1, !tbaa !29
  %t1023 = getelementptr { i64, [5 x i64] }, ptr %t1021, i32 0, i32 1
  %t1024 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1023, i32 0, i32 1
  %t1025 = load ptr, ptr %t1024
  store ptr %t1025, ptr %l60, !tbaa !29
  br label %bb314
bb313:
  br label %bb316
bb314:
  %t1027 = load ptr, ptr %l0, !tbaa !29
  %t1028 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t1027, ptr %t1028)
  br label %bb315
bb315:
  br label %bb332
bb316:
  %t1031 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1031, ptr %l504, !tbaa !29
  store i1 false, ptr %l505, !tbaa !21
  %t1032 = load ptr, ptr %l504, !tbaa !29
  %t1033 = icmp ne ptr %t1032, null
  br i1 %t1033, label %bb317, label %bb318
bb317:
  %t1035 = load ptr, ptr %l504, !tbaa !29
  %t1036 = load i64, ptr %t1035
  %t1038 = icmp eq i64 %t1036, 25
  store i1 %t1038, ptr %l505, !tbaa !21
  br label %bb318
bb318:
  %t1039 = load i1, ptr %l505, !tbaa !21
  br i1 %t1039, label %bb319, label %bb320
bb319:
  %t1040 = load ptr, ptr %l1, !tbaa !29
  %t1042 = getelementptr { i64, [5 x i64] }, ptr %t1040, i32 0, i32 1
  %t1043 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t1042, i32 0, i32 1
  %t1044 = load { i64, ptr }, ptr %t1043
  store { i64, ptr } %t1044, ptr %l61, !tbaa !27
  br label %bb321
bb320:
  br label %bb324
bb321:
  store %olang.scope zeroinitializer, ptr %s43
  %t1046 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s43, ptr %t1046, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d77, i32 0, i32 1) })
  br label %bb322
bb322:
  %t1048 = load ptr, ptr %l0, !tbaa !29
  %t1049 = load { i64, ptr }, ptr %l61, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t1048, { i64, ptr } %t1049)
  br label %bb323
bb323:
  call void @__olang_scope_close(ptr %s43)
  br label %bb332
bb324:
  %t1052 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1052, ptr %l513, !tbaa !29
  store i1 false, ptr %l514, !tbaa !21
  %t1053 = load ptr, ptr %l513, !tbaa !29
  %t1054 = icmp ne ptr %t1053, null
  br i1 %t1054, label %bb325, label %bb326
bb325:
  %t1056 = load ptr, ptr %l513, !tbaa !29
  %t1057 = load i64, ptr %t1056
  %t1059 = icmp eq i64 %t1057, 26
  store i1 %t1059, ptr %l514, !tbaa !21
  br label %bb326
bb326:
  %t1060 = load i1, ptr %l514, !tbaa !21
  br i1 %t1060, label %bb327, label %bb328
bb327:
  br label %bb329
bb328:
  br label %bb331
bb329:
  store %olang.scope zeroinitializer, ptr %s44
  %t1061 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s44, ptr %t1061, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d78, i32 0, i32 1) })
  br label %bb330
bb330:
  call void @__olang_scope_close(ptr %s44)
  br label %bb332
bb331:
  call void @__olang_check_failed(ptr @olang_loc_af8532b2afdd02b1_ed9973e7a2ad66a5)
  unreachable
bb332:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t27 = icmp sgt i64 %t15, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t29, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d79, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l11 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t6, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d80, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d81, i32 0, i32 1) })
  br label %bb5
bb5:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Func", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t19, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) })
  br label %bb8
bb7:
  br label %bb14
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l11, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_240300a98391f326_30555605a48ff2da)
  unreachable
bb10:
  br label %bb11
bb11:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t33, ptr %t32)
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t35, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Func", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t37, i32 %t41)
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t45, i32 0, i32 5
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t44, { i64, ptr } %t48)
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/ast:Func", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %t54, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t51, ptr %t55)
  br label %bb17
bb17:
  %t58 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t58, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) })
  br label %bb18
bb18:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Func", ptr %t61, i32 0, i32 4
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t60, { i64, ptr } %t64)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l14 = alloca ptr
  %l20 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l42 = alloca ptr
  %l49 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:If", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_450b6e4c0e54f911_1dcad8b8a27ff01d)
  unreachable
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:If", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t20, ptr %t19)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t22, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d85, i32 0, i32 1) })
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:If", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_375b6e3c7dc4e00a_588d095da59240b6)
  unreachable
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/ast:If", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t36, ptr %t35)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l20, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:If", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_e1b6c554c381b10b_f727e5cc4e37ef67)
  unreachable
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/ast:If", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t50, ptr %t49)
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/ast:If", ptr %t52, i32 0, i32 2
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t61, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb43
bb19:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/ast:If", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l2, !tbaa !29
  %t68 = load ptr, ptr %l2, !tbaa !29
  store ptr %t68, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t69 = load ptr, ptr %l33, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load ptr, ptr %l33, !tbaa !29
  %t73 = load i64, ptr %t72
  %t75 = icmp eq i64 %t73, 5
  store i1 %t75, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t76 = load i1, ptr %l34, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", ptr }, ptr %t79, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t83 = load ptr, ptr %l3, !tbaa !29
  %t85 = getelementptr %"compiler/ast:If", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = icmp eq ptr %t86, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l42, !tbaa !29
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/ast:If", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb27, label %bb28
bb26:
  br label %bb31
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ba8e182b2fbe7a1c_99d493faf8d7cb48)
  unreachable
bb28:
  br label %bb29
bb29:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/ast:If", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t102, ptr %t101)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_a676b6f90e9ab794_adfa384105d75b88)
  unreachable
bb37:
  %t104 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t104, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) })
  br label %bb38
bb38:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l49, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/ast:If", ptr %t107, i32 0, i32 2
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_8218e8270bec8206_ca247080b262927a)
  unreachable
bb40:
  br label %bb41
bb41:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/ast:If", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t118, ptr %t117)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t9, { i64, ptr } %a1)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i1, ptr %l2, !tbaa !21
  %t17 = getelementptr %"compiler/unparse:writer", ptr %t13, i32 0, i32 6
  store i1 %t14, ptr %t17, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l21 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l96 = alloca ptr
  %l102 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d88, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Match", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t3, ptr %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l21, !tbaa !29
  %t13 = load ptr, ptr %l21, !tbaa !29
  %t14 = getelementptr %"compiler/unparse:writer", ptr %t13, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = add i64 %t15, 1
  %t19 = load ptr, ptr %l21, !tbaa !29
  %t20 = getelementptr %"compiler/unparse:writer", ptr %t19, i32 0, i32 4
  store i64 %t17, ptr %t20, !tbaa !24
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Match", ptr %t21, i32 0, i32 3
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb6:
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l32, !tbaa !27
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  store ptr %t44, ptr %l5, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t46)
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t48, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Case", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb11, label %bb12
bb11:
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l46, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l10, !tbaa !29
  %t79 = icmp sgt i64 %t67, 0
  br i1 %t79, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t81, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb10
bb20:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Case", ptr %t91, i32 0, i32 2
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t110, ptr %l65, !tbaa !27
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr ptr, ptr %t114, i64 %t111
  %t116 = load ptr, ptr %t115, !tbaa !39
  store ptr %t116, ptr %l15, !tbaa !29
  %t120 = icmp sgt i64 %t108, 0
  br i1 %t120, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t122 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t122, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d92, i32 0, i32 1) })
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb28:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l12, !tbaa !24
  br label %bb21
bb31:
  %t132 = load ptr, ptr %l5, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Case", ptr %t132, i32 0, i32 3
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = icmp eq ptr %t135, null
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s11
  %t141 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t141, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d93, i32 0, i32 1) })
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l80, !tbaa !29
  %t144 = load ptr, ptr %l5, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_212921701ccd28fb_40c266614e32415f)
  unreachable
bb36:
  br label %bb37
bb37:
  %t151 = load ptr, ptr %l5, !tbaa !29
  %t153 = getelementptr %"compiler/ast:Case", ptr %t151, i32 0, i32 3
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t155, ptr %t154)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s11)
  br label %bb39
bb39:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %t157, ptr %t158)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t161 = load i64, ptr %l3, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l3, !tbaa !24
  br label %bb4
bb42:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/ast:Match", ptr %t165, i32 0, i32 4
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = icmp eq ptr %t168, null
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s13
  %t174 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t174)
  br label %bb45
bb44:
  br label %bb51
bb45:
  %t176 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t176, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d94, i32 0, i32 1) })
  br label %bb46
bb46:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l96, !tbaa !29
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr %"compiler/ast:Match", ptr %t179, i32 0, i32 4
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = icmp eq ptr %t182, null
  br i1 %t184, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_a89566c82002a68c_50a6017df30325c0)
  unreachable
bb48:
  br label %bb49
bb49:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr %"compiler/ast:Match", ptr %t186, i32 0, i32 4
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t190 = load ptr, ptr %l96, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %t190, ptr %t189)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s13)
  br label %bb51
bb51:
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l102, !tbaa !29
  %t193 = load ptr, ptr %l102, !tbaa !29
  %t194 = getelementptr %"compiler/unparse:writer", ptr %t193, i32 0, i32 4
  %t195 = load i64, ptr %t194, !tbaa !24
  %t197 = sub i64 %t195, 1
  %t199 = load ptr, ptr %l102, !tbaa !29
  %t200 = getelementptr %"compiler/unparse:writer", ptr %t199, i32 0, i32 4
  store i64 %t197, ptr %t200, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t201)
  br label %bb52
bb52:
  %t203 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t203, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) })
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t7, i32 %a1)
  store { i64, ptr } %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t12, { i64, ptr } %t13)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t3, i8 10)
  br label %bb1
bb1:
  store i64 0, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/unparse:writer", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2funparse_2eMaxIndent, !tbaa !24
  %t12 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t8, i64 %t9)
  store i64 %t12, ptr %l12
  br label %bb2
bb2:
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb8
bb5:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l19, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l19, !tbaa !24
  store i64 %t40, ptr %l16, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l16, !tbaa !24
  store i64 %t41, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l1, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l6, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/unparse:writer", ptr %t60, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t62, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d96, i32 0, i32 1) })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l5, !tbaa !24
  br label %bb9
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l16 = alloca ptr
  %l27 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Param", ptr %t1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t8, i32 %t12)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Param", ptr %t15, i32 0, i32 2
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Param", ptr %t24, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = icmp ne i32 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb6:
  br label %bb15
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t31, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l16, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/ast:Param", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_2301005a90ba30f7_2e0b8cd6b5bb3c83)
  unreachable
bb12:
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/ast:Param", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t45, ptr %t44)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Param", ptr %t47, i32 0, i32 3
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t56, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d98, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l27, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Param", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_6385ebb2fa48e0d8_1e44ec8c8ca0ecf4)
  unreachable
bb20:
  br label %bb21
bb21:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Param", ptr %t66, i32 0, i32 3
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t70, ptr %t69)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l19 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l7, !tbaa !29
  %t35 = icmp sgt i64 %t23, 0
  br i1 %t35, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t37, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i1, ptr %l2, !tbaa !21
  %t51 = getelementptr %"compiler/unparse:writer", ptr %t47, i32 0, i32 6
  store i1 %t48, ptr %t51, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:Path", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t30 = icmp sgt i64 %t18, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t32, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t34, i32 %t35)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l46 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t2 = load ptr, ptr %l14, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l14, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l15, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d101, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb58
bb7:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t13 = load ptr, ptr %l19, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb8, label %bb9
bb8:
  %t16 = load ptr, ptr %l19, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 1
  store i1 %t19, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t20 = load i1, ptr %l20, !tbaa !21
  br i1 %t20, label %bb10, label %bb11
bb10:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", ptr }, ptr %t23, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  br label %bb13
bb13:
  br label %bb58
bb14:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t32 = load ptr, ptr %l27, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t35 = load ptr, ptr %l27, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l28, !tbaa !21
  br i1 %t39, label %bb17, label %bb18
bb17:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t48, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49
  store { i64, ptr } %t50, ptr %l4, !tbaa !27
  br label %bb19
bb18:
  br label %bb34
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t56, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d102, i32 0, i32 1) })
  br label %bb21
bb21:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb22
bb22:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb23, label %bb24
bb23:
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l46, !tbaa !27
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l9, !tbaa !29
  %t84 = icmp sgt i64 %t72, 0
  br i1 %t84, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t86, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t88, ptr %t89)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l6, !tbaa !24
  br label %bb22
bb32:
  %t96 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t96, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb58
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t99 = load ptr, ptr %l57, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb35, label %bb36
bb35:
  %t102 = load ptr, ptr %l57, !tbaa !29
  %t103 = load i64, ptr %t102
  %t105 = icmp eq i64 %t103, 3
  store i1 %t105, ptr %l58, !tbaa !21
  br label %bb36
bb36:
  %t106 = load i1, ptr %l58, !tbaa !21
  br i1 %t106, label %bb37, label %bb38
bb37:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32 }, ptr %t109, i32 0, i32 1
  %t111 = load i32, ptr %t110
  store i32 %t111, ptr %l10, !tbaa !23
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t113, i32 %t114)
  br label %bb40
bb40:
  br label %bb58
bb41:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t118 = load ptr, ptr %l65, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb42, label %bb43
bb42:
  %t121 = load ptr, ptr %l65, !tbaa !29
  %t122 = load i64, ptr %t121
  %t124 = icmp eq i64 %t122, 4
  store i1 %t124, ptr %l66, !tbaa !21
  br label %bb43
bb43:
  %t125 = load i1, ptr %l66, !tbaa !21
  br i1 %t125, label %bb44, label %bb45
bb44:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", ptr }, ptr %t128, i32 0, i32 1
  %t130 = load ptr, ptr %t129
  store ptr %t130, ptr %l11, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t132, ptr %t133)
  br label %bb47
bb47:
  br label %bb58
bb48:
  %t136 = load ptr, ptr %l1, !tbaa !29
  store ptr %t136, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t137 = load ptr, ptr %l73, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb49, label %bb50
bb49:
  %t140 = load ptr, ptr %l73, !tbaa !29
  %t141 = load i64, ptr %t140
  %t143 = icmp eq i64 %t141, 5
  store i1 %t143, ptr %l74, !tbaa !21
  br label %bb50
bb50:
  %t144 = load i1, ptr %l74, !tbaa !21
  br i1 %t144, label %bb51, label %bb52
bb51:
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t147, i32 0, i32 1
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l12, !tbaa !29
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t153, i32 0, i32 2
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l13, !tbaa !23
  br label %bb53
bb52:
  br label %bb57
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t157, ptr %t158)
  br label %bb54
bb54:
  %t161 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t161, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb55
bb55:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t163, i32 %t164)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_19d95224243c5dd3_a108b37826b1917)
  unreachable
bb58:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/unparse:writer", ptr %a0, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l43 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtract(ptr %v0, ptr %v1, ptr %t12, ptr %t13)
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Sig", ptr %t16, i32 0, i32 4
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t21, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/unparse:writer", ptr %t23, i32 0, i32 6
  %t26 = load i1, ptr %t25, !tbaa !21
  store i1 %t26, ptr %l2, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/unparse:writer", ptr %t28, i32 0, i32 6
  store i1 true, ptr %t30, !tbaa !21
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Sig", ptr %t31, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb11:
  br label %bb12
bb12:
  %t48 = load i64, ptr %l4, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l30, !tbaa !27
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  store ptr %t56, ptr %l7, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d109, i32 0, i32 1) }, ptr %l36, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, ptr %l36, !tbaa !27
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t63, { i64, ptr } %t64)
  br label %bb16
bb16:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Sig", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t73 = sub i64 %t71, 1
  %t76 = icmp eq i64 %t65, %t73
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/ast:Sig", ptr %t78, i32 0, i32 2
  %t81 = load i1, ptr %t80, !tbaa !21
  store i1 %t81, ptr %l43, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb19
bb19:
  %t83 = load i1, ptr %l43, !tbaa !21
  br i1 %t83, label %bb20, label %bb21
bb20:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l46, !tbaa !29
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t87 = call i1 @compiler_2funparse_2enoErrorsOf(ptr %v1, ptr %t85)
  store i1 %t87, ptr %l48
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t88 = load i1, ptr %l48, !tbaa !21
  %t89 = load ptr, ptr %l46, !tbaa !29
  %t90 = getelementptr %"compiler/unparse:writer", ptr %t89, i32 0, i32 7
  store i1 %t88, ptr %t90, !tbaa !21
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  br label %bb24
bb24:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/unparse:writer", ptr %t95, i32 0, i32 7
  store i1 false, ptr %t97, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t98 = load i64, ptr %l4, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l4, !tbaa !24
  br label %bb9
bb26:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i1, ptr %l2, !tbaa !21
  %t106 = getelementptr %"compiler/unparse:writer", ptr %t102, i32 0, i32 6
  store i1 %t103, ptr %t106, !tbaa !21
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/ast:Sig", ptr %t107, i32 0, i32 6
  %t110 = load i1, ptr %t109, !tbaa !21
  br i1 %t110, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t112 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t112, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t114, ptr %t115)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l10, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9c4378154f5f7dac_a032de2992525ef0)
  unreachable
bb3:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9c4378154f5f7dac_a032de2992525ef0)
  unreachable
bb5:
  %t29 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l9, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t37, { i64, ptr } %t36)
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9c4378154f5f7dac_a032de2992525ef0)
  unreachable
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l57 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca i1
  %l77 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l137 = alloca ptr
  %l150 = alloca ptr
  %l151 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i1
  %l224 = alloca ptr
  %l225 = alloca i1
  %l232 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l241 = alloca ptr
  %l242 = alloca i1
  %l258 = alloca ptr
  %l259 = alloca i1
  %l271 = alloca ptr
  %l272 = alloca i1
  %l288 = alloca ptr
  %l289 = alloca i1
  %l304 = alloca ptr
  %l305 = alloca i1
  %l312 = alloca ptr
  %l314 = alloca { i64, ptr }
  %l317 = alloca ptr
  %l318 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t2 = load ptr, ptr %l32, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l32, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l33, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l33, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb228
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t21 = load ptr, ptr %l40, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l40, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l41, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l41, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb228
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t40 = load ptr, ptr %l48, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l48, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l49, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l49, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb26
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Multi", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t54, { i64, ptr } %t58)
  br label %bb20
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l57, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Multi", ptr %t62, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d112, i32 0, i32 1) }, ptr %l60, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d113, i32 0, i32 1) }, ptr %l60, !tbaa !27
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l57, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l60, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t67, { i64, ptr } %t68)
  br label %bb24
bb24:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Multi", ptr %t70, i32 0, i32 2
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t69, { i64, ptr } %t73)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb228
bb26:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t77 = load ptr, ptr %l64, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l64, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l65, !tbaa !21
  br label %bb28
bb28:
  %t84 = load i1, ptr %l65, !tbaa !21
  br i1 %t84, label %bb29, label %bb30
bb29:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l5
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l6, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t99, i32 0, i32 3
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l7, !tbaa !29
  br label %bb31
bb30:
  br label %bb38
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t103, ptr %t104)
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t107, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) })
  br label %bb33
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l77, !tbaa !29
  %t110 = load i32, ptr %l5
  %t112 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t110)
  store { i64, ptr } %t112, ptr %l79
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l77, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l79, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t113, { i64, ptr } %t114)
  br label %bb35
bb35:
  %t115 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t115, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) })
  br label %bb36
bb36:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb228
bb38:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t122 = load ptr, ptr %l83, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %l83, !tbaa !29
  %t126 = load i64, ptr %t125
  %t128 = icmp eq i64 %t126, 4
  store i1 %t128, ptr %l84, !tbaa !21
  br label %bb40
bb40:
  %t129 = load i1, ptr %l84, !tbaa !21
  br i1 %t129, label %bb41, label %bb42
bb41:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l8, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t138, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139
  store { i64, ptr } %t140, ptr %l9, !tbaa !27
  br label %bb43
bb42:
  br label %bb47
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t142 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t142, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d116, i32 0, i32 1) })
  br label %bb44
bb44:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t144, ptr %t145)
  br label %bb45
bb45:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t148, { i64, ptr } %t149)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s5)
  br label %bb228
bb47:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t153 = load ptr, ptr %l96, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb48, label %bb49
bb48:
  %t156 = load ptr, ptr %l96, !tbaa !29
  %t157 = load i64, ptr %t156
  %t159 = icmp eq i64 %t157, 5
  store i1 %t159, ptr %l97, !tbaa !21
  br label %bb49
bb49:
  %t160 = load i1, ptr %l97, !tbaa !21
  br i1 %t160, label %bb50, label %bb51
bb50:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", ptr }, ptr %t163, i32 0, i32 1
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l10, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %t167, ptr %t168)
  br label %bb53
bb53:
  br label %bb228
bb54:
  %t171 = load ptr, ptr %l1, !tbaa !29
  store ptr %t171, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t172 = load ptr, ptr %l104, !tbaa !29
  %t173 = icmp ne ptr %t172, null
  br i1 %t173, label %bb55, label %bb56
bb55:
  %t175 = load ptr, ptr %l104, !tbaa !29
  %t176 = load i64, ptr %t175
  %t178 = icmp eq i64 %t176, 6
  store i1 %t178, ptr %l105, !tbaa !21
  br label %bb56
bb56:
  %t179 = load i1, ptr %l105, !tbaa !21
  br i1 %t179, label %bb57, label %bb58
bb57:
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t182, i32 0, i32 1
  %t184 = load { i64, ptr }, ptr %t183
  store { i64, ptr } %t184, ptr %l11, !tbaa !27
  br label %bb59
bb58:
  br label %bb62
bb59:
  store %olang.scope zeroinitializer, ptr %s7
  %t186 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t186, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d117, i32 0, i32 1) })
  br label %bb60
bb60:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t188, { i64, ptr } %t189)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  br label %bb228
bb62:
  %t192 = load ptr, ptr %l1, !tbaa !29
  store ptr %t192, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t193 = load ptr, ptr %l113, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb63, label %bb64
bb63:
  %t196 = load ptr, ptr %l113, !tbaa !29
  %t197 = load i64, ptr %t196
  %t199 = icmp eq i64 %t197, 7
  store i1 %t199, ptr %l114, !tbaa !21
  br label %bb64
bb64:
  %t200 = load i1, ptr %l114, !tbaa !21
  br i1 %t200, label %bb65, label %bb66
bb65:
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t203, i32 0, i32 1
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l12, !tbaa !29
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t209, i32 0, i32 2
  %t211 = load { i64, ptr }, ptr %t210
  store { i64, ptr } %t211, ptr %l13, !tbaa !27
  br label %bb67
bb66:
  br label %bb71
bb67:
  store %olang.scope zeroinitializer, ptr %s8
  %t213 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t213, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb68
bb68:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t215, ptr %t216)
  br label %bb69
bb69:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t219, { i64, ptr } %t220)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s8)
  br label %bb228
bb71:
  %t223 = load ptr, ptr %l1, !tbaa !29
  store ptr %t223, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t224 = load ptr, ptr %l126, !tbaa !29
  %t225 = icmp ne ptr %t224, null
  br i1 %t225, label %bb72, label %bb73
bb72:
  %t227 = load ptr, ptr %l126, !tbaa !29
  %t228 = load i64, ptr %t227
  %t230 = icmp eq i64 %t228, 8
  store i1 %t230, ptr %l127, !tbaa !21
  br label %bb73
bb73:
  %t231 = load i1, ptr %l127, !tbaa !21
  br i1 %t231, label %bb74, label %bb75
bb74:
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", ptr }, ptr %t234, i32 0, i32 1
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l14, !tbaa !29
  br label %bb76
bb75:
  br label %bb87
bb76:
  store %olang.scope zeroinitializer, ptr %s9
  %t238 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t238, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d119, i32 0, i32 1) })
  br label %bb77
bb77:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l14, !tbaa !29
  %t243 = getelementptr %"compiler/ast:For3", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t240, ptr %t244)
  br label %bb78
bb78:
  %t247 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t247, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d120, i32 0, i32 1) })
  br label %bb79
bb79:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l137, !tbaa !29
  %t250 = load ptr, ptr %l14, !tbaa !29
  %t252 = getelementptr %"compiler/ast:For3", ptr %t250, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = icmp eq ptr %t253, null
  br i1 %t255, label %bb80, label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_b263a57856eac862_46b7b1031f9001a6)
  unreachable
bb81:
  br label %bb82
bb82:
  %t257 = load ptr, ptr %l14, !tbaa !29
  %t259 = getelementptr %"compiler/ast:For3", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t261 = load ptr, ptr %l137, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t261, ptr %t260)
  br label %bb83
bb83:
  %t263 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t263, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d121, i32 0, i32 1) })
  br label %bb84
bb84:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l14, !tbaa !29
  %t268 = getelementptr %"compiler/ast:For3", ptr %t266, i32 0, i32 2
  %t269 = load ptr, ptr %t268, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t265, ptr %t269)
  br label %bb85
bb85:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load ptr, ptr %l14, !tbaa !29
  %t275 = getelementptr %"compiler/ast:For3", ptr %t273, i32 0, i32 3
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t272, { i64, ptr } %t276)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s9)
  br label %bb228
bb87:
  %t279 = load ptr, ptr %l1, !tbaa !29
  store ptr %t279, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t280 = load ptr, ptr %l150, !tbaa !29
  %t281 = icmp ne ptr %t280, null
  br i1 %t281, label %bb88, label %bb89
bb88:
  %t283 = load ptr, ptr %l150, !tbaa !29
  %t284 = load i64, ptr %t283
  %t286 = icmp eq i64 %t284, 9
  store i1 %t286, ptr %l151, !tbaa !21
  br label %bb89
bb89:
  %t287 = load i1, ptr %l151, !tbaa !21
  br i1 %t287, label %bb90, label %bb91
bb90:
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr { i64, [4 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", ptr }, ptr %t290, i32 0, i32 1
  %t292 = load ptr, ptr %t291
  store ptr %t292, ptr %l15, !tbaa !29
  br label %bb92
bb91:
  br label %bb108
bb92:
  store %olang.scope zeroinitializer, ptr %s10
  %t294 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t294, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d122, i32 0, i32 1) })
  br label %bb93
bb93:
  %t296 = load ptr, ptr %l15, !tbaa !29
  %t298 = getelementptr %"compiler/ast:ForIn", ptr %t296, i32 0, i32 0
  %t299 = load i32, ptr %t298, !tbaa !23
  %t301 = icmp ne i32 %t299, 0
  br i1 %t301, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s11
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load ptr, ptr %l15, !tbaa !29
  %t306 = getelementptr %"compiler/ast:ForIn", ptr %t304, i32 0, i32 0
  %t307 = load i32, ptr %t306, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t303, i32 %t307)
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t310 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t310, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d123, i32 0, i32 1) })
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s11)
  br label %bb98
bb98:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load ptr, ptr %l15, !tbaa !29
  %t315 = getelementptr %"compiler/ast:ForIn", ptr %t313, i32 0, i32 1
  %t316 = load i32, ptr %t315, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t312, i32 %t316)
  br label %bb99
bb99:
  %t319 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t319, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d124, i32 0, i32 1) })
  br label %bb100
bb100:
  %t321 = load ptr, ptr %l15, !tbaa !29
  %t323 = getelementptr %"compiler/ast:ForIn", ptr %t321, i32 0, i32 3
  %t324 = load i1, ptr %t323, !tbaa !21
  br i1 %t324, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s12
  %t326 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t326, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d125, i32 0, i32 1) })
  br label %bb103
bb102:
  br label %bb104
bb103:
  call void @__olang_scope_close(ptr %s12)
  br label %bb104
bb104:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load ptr, ptr %l15, !tbaa !29
  %t331 = getelementptr %"compiler/ast:ForIn", ptr %t329, i32 0, i32 2
  %t332 = load ptr, ptr %t331, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t328, ptr %t332)
  br label %bb105
bb105:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l15, !tbaa !29
  %t338 = getelementptr %"compiler/ast:ForIn", ptr %t336, i32 0, i32 4
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t335, { i64, ptr } %t339)
  br label %bb106
bb106:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l15, !tbaa !29
  %t345 = getelementptr %"compiler/ast:ForIn", ptr %t343, i32 0, i32 5
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t342, { i64, ptr } %t346)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s10)
  br label %bb228
bb108:
  %t349 = load ptr, ptr %l1, !tbaa !29
  store ptr %t349, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t350 = load ptr, ptr %l180, !tbaa !29
  %t351 = icmp ne ptr %t350, null
  br i1 %t351, label %bb109, label %bb110
bb109:
  %t353 = load ptr, ptr %l180, !tbaa !29
  %t354 = load i64, ptr %t353
  %t356 = icmp eq i64 %t354, 10
  store i1 %t356, ptr %l181, !tbaa !21
  br label %bb110
bb110:
  %t357 = load i1, ptr %l181, !tbaa !21
  br i1 %t357, label %bb111, label %bb112
bb111:
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t360, i32 0, i32 1
  %t362 = load { i64, ptr }, ptr %t361
  store { i64, ptr } %t362, ptr %l16, !tbaa !27
  %t364 = load ptr, ptr %l1, !tbaa !29
  %t366 = getelementptr { i64, [4 x i64] }, ptr %t364, i32 0, i32 1
  %t367 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t366, i32 0, i32 2
  %t368 = load ptr, ptr %t367
  store ptr %t368, ptr %l17, !tbaa !29
  br label %bb113
bb112:
  br label %bb118
bb113:
  store %olang.scope zeroinitializer, ptr %s13
  %t370 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t370, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d126, i32 0, i32 1) })
  br label %bb114
bb114:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t372, { i64, ptr } %t373)
  br label %bb115
bb115:
  %t376 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t376, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d127, i32 0, i32 1) })
  br label %bb116
bb116:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t378, ptr %t379)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s13)
  br label %bb228
bb118:
  %t382 = load ptr, ptr %l1, !tbaa !29
  store ptr %t382, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t383 = load ptr, ptr %l194, !tbaa !29
  %t384 = icmp ne ptr %t383, null
  br i1 %t384, label %bb119, label %bb120
bb119:
  %t386 = load ptr, ptr %l194, !tbaa !29
  %t387 = load i64, ptr %t386
  %t389 = icmp eq i64 %t387, 11
  store i1 %t389, ptr %l195, !tbaa !21
  br label %bb120
bb120:
  %t390 = load i1, ptr %l195, !tbaa !21
  br i1 %t390, label %bb121, label %bb122
bb121:
  %t391 = load ptr, ptr %l1, !tbaa !29
  %t393 = getelementptr { i64, [4 x i64] }, ptr %t391, i32 0, i32 1
  %t394 = getelementptr { %"compiler/source:Span", ptr }, ptr %t393, i32 0, i32 1
  %t395 = load ptr, ptr %t394
  store ptr %t395, ptr %l18, !tbaa !29
  br label %bb123
bb122:
  br label %bb125
bb123:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t397, ptr %t398)
  br label %bb124
bb124:
  br label %bb228
bb125:
  %t401 = load ptr, ptr %l1, !tbaa !29
  store ptr %t401, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t402 = load ptr, ptr %l202, !tbaa !29
  %t403 = icmp ne ptr %t402, null
  br i1 %t403, label %bb126, label %bb127
bb126:
  %t405 = load ptr, ptr %l202, !tbaa !29
  %t406 = load i64, ptr %t405
  %t408 = icmp eq i64 %t406, 12
  store i1 %t408, ptr %l203, !tbaa !21
  br label %bb127
bb127:
  %t409 = load i1, ptr %l203, !tbaa !21
  br i1 %t409, label %bb128, label %bb129
bb128:
  %t410 = load ptr, ptr %l1, !tbaa !29
  %t412 = getelementptr { i64, [4 x i64] }, ptr %t410, i32 0, i32 1
  %t413 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t412, i32 0, i32 1
  %t414 = load { i64, ptr }, ptr %t413
  store { i64, ptr } %t414, ptr %l19, !tbaa !27
  br label %bb130
bb129:
  br label %bb137
bb130:
  store %olang.scope zeroinitializer, ptr %s15
  %t416 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t416, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d128, i32 0, i32 1) })
  br label %bb131
bb131:
  %t418 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t420 = extractvalue { i64, ptr } %t418, 0
  %t422 = icmp sgt i64 %t420, 0
  br i1 %t422, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s16
  %t424 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t424, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d129, i32 0, i32 1) })
  br label %bb134
bb133:
  br label %bb136
bb134:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t426, { i64, ptr } %t427)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s16)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s15)
  br label %bb228
bb137:
  %t430 = load ptr, ptr %l1, !tbaa !29
  store ptr %t430, ptr %l215, !tbaa !29
  store i1 false, ptr %l216, !tbaa !21
  %t431 = load ptr, ptr %l215, !tbaa !29
  %t432 = icmp ne ptr %t431, null
  br i1 %t432, label %bb138, label %bb139
bb138:
  %t434 = load ptr, ptr %l215, !tbaa !29
  %t435 = load i64, ptr %t434
  %t437 = icmp eq i64 %t435, 20
  store i1 %t437, ptr %l216, !tbaa !21
  br label %bb139
bb139:
  %t438 = load i1, ptr %l216, !tbaa !21
  br i1 %t438, label %bb140, label %bb141
bb140:
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr { i64, [4 x i64] }, ptr %t439, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", ptr }, ptr %t441, i32 0, i32 1
  %t443 = load ptr, ptr %t442
  store ptr %t443, ptr %l20, !tbaa !29
  br label %bb142
bb141:
  br label %bb145
bb142:
  store %olang.scope zeroinitializer, ptr %s17
  %t445 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t445, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d130, i32 0, i32 1) })
  br label %bb143
bb143:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t447, ptr %t448)
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s17)
  br label %bb228
bb145:
  %t451 = load ptr, ptr %l1, !tbaa !29
  store ptr %t451, ptr %l224, !tbaa !29
  store i1 false, ptr %l225, !tbaa !21
  %t452 = load ptr, ptr %l224, !tbaa !29
  %t453 = icmp ne ptr %t452, null
  br i1 %t453, label %bb146, label %bb147
bb146:
  %t455 = load ptr, ptr %l224, !tbaa !29
  %t456 = load i64, ptr %t455
  %t458 = icmp eq i64 %t456, 13
  store i1 %t458, ptr %l225, !tbaa !21
  br label %bb147
bb147:
  %t459 = load i1, ptr %l225, !tbaa !21
  br i1 %t459, label %bb148, label %bb149
bb148:
  %t460 = load ptr, ptr %l1, !tbaa !29
  %t462 = getelementptr { i64, [4 x i64] }, ptr %t460, i32 0, i32 1
  %t463 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t462, i32 0, i32 1
  %t464 = load i32, ptr %t463
  store i32 %t464, ptr %l21
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [4 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t468, i32 0, i32 2
  %t470 = load ptr, ptr %t469
  store ptr %t470, ptr %l22, !tbaa !29
  br label %bb150
bb149:
  br label %bb158
bb150:
  store %olang.scope zeroinitializer, ptr %s18
  %t472 = load ptr, ptr %l0, !tbaa !29
  store ptr %t472, ptr %l232, !tbaa !29
  %t473 = load i32, ptr %l21
  %t475 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s18, i32 %t473)
  store { i64, ptr } %t475, ptr %l234
  br label %bb151
bb151:
  %t476 = load ptr, ptr %l232, !tbaa !29
  %t477 = load { i64, ptr }, ptr %l234, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t476, { i64, ptr } %t477)
  br label %bb152
bb152:
  %t478 = load ptr, ptr %l22, !tbaa !29
  %t480 = icmp eq ptr %t478, null
  %t482 = xor i1 %t480, true
  br i1 %t482, label %bb153, label %bb154
bb153:
  store %olang.scope zeroinitializer, ptr %s19
  %t484 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t484, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d131, i32 0, i32 1) })
  br label %bb155
bb154:
  br label %bb157
bb155:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t486, ptr %t487)
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s19)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s18)
  br label %bb228
bb158:
  %t490 = load ptr, ptr %l1, !tbaa !29
  store ptr %t490, ptr %l241, !tbaa !29
  store i1 false, ptr %l242, !tbaa !21
  %t491 = load ptr, ptr %l241, !tbaa !29
  %t492 = icmp ne ptr %t491, null
  br i1 %t492, label %bb159, label %bb160
bb159:
  %t494 = load ptr, ptr %l241, !tbaa !29
  %t495 = load i64, ptr %t494
  %t497 = icmp eq i64 %t495, 14
  store i1 %t497, ptr %l242, !tbaa !21
  br label %bb160
bb160:
  %t498 = load i1, ptr %l242, !tbaa !21
  br i1 %t498, label %bb161, label %bb162
bb161:
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = getelementptr { i64, [4 x i64] }, ptr %t499, i32 0, i32 1
  %t502 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t501, i32 0, i32 1
  %t503 = load ptr, ptr %t502
  store ptr %t503, ptr %l23, !tbaa !29
  %t505 = load ptr, ptr %l1, !tbaa !29
  %t507 = getelementptr { i64, [4 x i64] }, ptr %t505, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t507, i32 0, i32 2
  %t509 = load ptr, ptr %t508
  store ptr %t509, ptr %l24, !tbaa !29
  br label %bb163
bb162:
  br label %bb171
bb163:
  store %olang.scope zeroinitializer, ptr %s20
  %t511 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t511, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d132, i32 0, i32 1) })
  br label %bb164
bb164:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t513, ptr %t514)
  br label %bb165
bb165:
  %t517 = load ptr, ptr %l24, !tbaa !29
  %t519 = icmp eq ptr %t517, null
  %t521 = xor i1 %t519, true
  br i1 %t521, label %bb166, label %bb167
bb166:
  store %olang.scope zeroinitializer, ptr %s21
  %t523 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t523, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) })
  br label %bb168
bb167:
  br label %bb170
bb168:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t525, ptr %t526)
  br label %bb169
bb169:
  call void @__olang_scope_close(ptr %s21)
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s20)
  br label %bb228
bb171:
  %t529 = load ptr, ptr %l1, !tbaa !29
  store ptr %t529, ptr %l258, !tbaa !29
  store i1 false, ptr %l259, !tbaa !21
  %t530 = load ptr, ptr %l258, !tbaa !29
  %t531 = icmp ne ptr %t530, null
  br i1 %t531, label %bb172, label %bb173
bb172:
  %t533 = load ptr, ptr %l258, !tbaa !29
  %t534 = load i64, ptr %t533
  %t536 = icmp eq i64 %t534, 15
  store i1 %t536, ptr %l259, !tbaa !21
  br label %bb173
bb173:
  %t537 = load i1, ptr %l259, !tbaa !21
  br i1 %t537, label %bb174, label %bb175
bb174:
  %t538 = load ptr, ptr %l1, !tbaa !29
  %t540 = getelementptr { i64, [4 x i64] }, ptr %t538, i32 0, i32 1
  %t541 = getelementptr { %"compiler/source:Span", ptr }, ptr %t540, i32 0, i32 1
  %t542 = load ptr, ptr %t541
  store ptr %t542, ptr %l25, !tbaa !29
  br label %bb176
bb175:
  br label %bb183
bb176:
  store %olang.scope zeroinitializer, ptr %s22
  %t544 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t544, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d134, i32 0, i32 1) })
  br label %bb177
bb177:
  %t546 = load ptr, ptr %l25, !tbaa !29
  %t548 = icmp eq ptr %t546, null
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb178, label %bb179
bb178:
  store %olang.scope zeroinitializer, ptr %s23
  %t552 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t552, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) })
  br label %bb180
bb179:
  br label %bb182
bb180:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t554, ptr %t555)
  br label %bb181
bb181:
  call void @__olang_scope_close(ptr %s23)
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s22)
  br label %bb228
bb183:
  %t558 = load ptr, ptr %l1, !tbaa !29
  store ptr %t558, ptr %l271, !tbaa !29
  store i1 false, ptr %l272, !tbaa !21
  %t559 = load ptr, ptr %l271, !tbaa !29
  %t560 = icmp ne ptr %t559, null
  br i1 %t560, label %bb184, label %bb185
bb184:
  %t562 = load ptr, ptr %l271, !tbaa !29
  %t563 = load i64, ptr %t562
  %t565 = icmp eq i64 %t563, 16
  store i1 %t565, ptr %l272, !tbaa !21
  br label %bb185
bb185:
  %t566 = load i1, ptr %l272, !tbaa !21
  br i1 %t566, label %bb186, label %bb187
bb186:
  %t567 = load ptr, ptr %l1, !tbaa !29
  %t569 = getelementptr { i64, [4 x i64] }, ptr %t567, i32 0, i32 1
  %t570 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t569, i32 0, i32 1
  %t571 = load { i64, ptr }, ptr %t570
  store { i64, ptr } %t571, ptr %l26, !tbaa !27
  %t573 = load ptr, ptr %l1, !tbaa !29
  %t575 = getelementptr { i64, [4 x i64] }, ptr %t573, i32 0, i32 1
  %t576 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t575, i32 0, i32 2
  %t577 = load ptr, ptr %t576
  store ptr %t577, ptr %l27, !tbaa !29
  br label %bb188
bb187:
  br label %bb196
bb188:
  store %olang.scope zeroinitializer, ptr %s24
  %t579 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t579, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d136, i32 0, i32 1) })
  br label %bb189
bb189:
  %t581 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t583 = extractvalue { i64, ptr } %t581, 0
  %t585 = icmp sgt i64 %t583, 0
  br i1 %t585, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s25
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t587, { i64, ptr } %t588)
  br label %bb192
bb191:
  br label %bb194
bb192:
  %t591 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t591, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d137, i32 0, i32 1) })
  br label %bb193
bb193:
  call void @__olang_scope_close(ptr %s25)
  br label %bb194
bb194:
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t594 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t593, ptr %t594)
  br label %bb195
bb195:
  call void @__olang_scope_close(ptr %s24)
  br label %bb228
bb196:
  %t597 = load ptr, ptr %l1, !tbaa !29
  store ptr %t597, ptr %l288, !tbaa !29
  store i1 false, ptr %l289, !tbaa !21
  %t598 = load ptr, ptr %l288, !tbaa !29
  %t599 = icmp ne ptr %t598, null
  br i1 %t599, label %bb197, label %bb198
bb197:
  %t601 = load ptr, ptr %l288, !tbaa !29
  %t602 = load i64, ptr %t601
  %t604 = icmp eq i64 %t602, 17
  store i1 %t604, ptr %l289, !tbaa !21
  br label %bb198
bb198:
  %t605 = load i1, ptr %l289, !tbaa !21
  br i1 %t605, label %bb199, label %bb200
bb199:
  %t606 = load ptr, ptr %l1, !tbaa !29
  %t608 = getelementptr { i64, [4 x i64] }, ptr %t606, i32 0, i32 1
  %t609 = getelementptr { %"compiler/source:Span", ptr }, ptr %t608, i32 0, i32 1
  %t610 = load ptr, ptr %t609
  store ptr %t610, ptr %l28, !tbaa !29
  br label %bb201
bb200:
  br label %bb209
bb201:
  store %olang.scope zeroinitializer, ptr %s26
  %t612 = load ptr, ptr %l28, !tbaa !29
  %t614 = getelementptr %"compiler/ast:JoinS", ptr %t612, i32 0, i32 0
  %t615 = load i1, ptr %t614, !tbaa !21
  br i1 %t615, label %bb202, label %bb203
bb202:
  store %olang.scope zeroinitializer, ptr %s27
  %t617 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s27, ptr %t617, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d138, i32 0, i32 1) })
  br label %bb204
bb203:
  br label %bb205
bb204:
  call void @__olang_scope_close(ptr %s27)
  br label %bb205
bb205:
  %t619 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t619, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d139, i32 0, i32 1) })
  br label %bb206
bb206:
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t622 = load ptr, ptr %l28, !tbaa !29
  %t624 = getelementptr %"compiler/ast:JoinS", ptr %t622, i32 0, i32 1
  %t625 = load { i64, ptr }, ptr %t624, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t621, { i64, ptr } %t625)
  br label %bb207
bb207:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load ptr, ptr %l28, !tbaa !29
  %t631 = getelementptr %"compiler/ast:JoinS", ptr %t629, i32 0, i32 2
  %t632 = load { i64, ptr }, ptr %t631, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t628, { i64, ptr } %t632)
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s26)
  br label %bb228
bb209:
  %t635 = load ptr, ptr %l1, !tbaa !29
  store ptr %t635, ptr %l304, !tbaa !29
  store i1 false, ptr %l305, !tbaa !21
  %t636 = load ptr, ptr %l304, !tbaa !29
  %t637 = icmp ne ptr %t636, null
  br i1 %t637, label %bb210, label %bb211
bb210:
  %t639 = load ptr, ptr %l304, !tbaa !29
  %t640 = load i64, ptr %t639
  %t642 = icmp eq i64 %t640, 18
  store i1 %t642, ptr %l305, !tbaa !21
  br label %bb211
bb211:
  %t643 = load i1, ptr %l305, !tbaa !21
  br i1 %t643, label %bb212, label %bb213
bb212:
  %t644 = load ptr, ptr %l1, !tbaa !29
  %t646 = getelementptr { i64, [4 x i64] }, ptr %t644, i32 0, i32 1
  %t647 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t646, i32 0, i32 1
  %t648 = load ptr, ptr %t647
  store ptr %t648, ptr %l29, !tbaa !29
  %t650 = load ptr, ptr %l1, !tbaa !29
  %t652 = getelementptr { i64, [4 x i64] }, ptr %t650, i32 0, i32 1
  %t653 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t652, i32 0, i32 2
  %t654 = load i1, ptr %t653
  store i1 %t654, ptr %l30, !tbaa !21
  br label %bb214
bb213:
  br label %bb220
bb214:
  store %olang.scope zeroinitializer, ptr %s28
  %t656 = load ptr, ptr %l0, !tbaa !29
  store ptr %t656, ptr %l312, !tbaa !29
  %t657 = load i1, ptr %l30, !tbaa !21
  br i1 %t657, label %bb215, label %bb216
bb215:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d140, i32 0, i32 1) }, ptr %l314, !tbaa !27
  br label %bb217
bb216:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d141, i32 0, i32 1) }, ptr %l314, !tbaa !27
  br label %bb217
bb217:
  %t659 = load ptr, ptr %l312, !tbaa !29
  %t660 = load { i64, ptr }, ptr %l314, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t659, { i64, ptr } %t660)
  br label %bb218
bb218:
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t662 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t661, ptr %t662)
  br label %bb219
bb219:
  call void @__olang_scope_close(ptr %s28)
  br label %bb228
bb220:
  %t665 = load ptr, ptr %l1, !tbaa !29
  store ptr %t665, ptr %l317, !tbaa !29
  store i1 false, ptr %l318, !tbaa !21
  %t666 = load ptr, ptr %l317, !tbaa !29
  %t667 = icmp ne ptr %t666, null
  br i1 %t667, label %bb221, label %bb222
bb221:
  %t669 = load ptr, ptr %l317, !tbaa !29
  %t670 = load i64, ptr %t669
  %t672 = icmp eq i64 %t670, 19
  store i1 %t672, ptr %l318, !tbaa !21
  br label %bb222
bb222:
  %t673 = load i1, ptr %l318, !tbaa !21
  br i1 %t673, label %bb223, label %bb224
bb223:
  %t674 = load ptr, ptr %l1, !tbaa !29
  %t676 = getelementptr { i64, [4 x i64] }, ptr %t674, i32 0, i32 1
  %t677 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t676, i32 0, i32 1
  %t678 = load { i64, ptr }, ptr %t677
  store { i64, ptr } %t678, ptr %l31, !tbaa !27
  br label %bb225
bb224:
  br label %bb227
bb225:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load { i64, ptr }, ptr %l31, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t680, { i64, ptr } %t681)
  br label %bb226
bb226:
  br label %bb228
bb227:
  call void @__olang_check_failed(ptr @olang_loc_9166140a1ac8280_ddd22134593fa34)
  unreachable
bb228:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l38 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopBranch", ptr %t5, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t4, i64 %t8)
  store i1 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopBranch", ptr %t14, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t13, %"compiler/source:Span" %t17)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TopBranch", ptr %t23, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t22, %"compiler/source:Span" %t26)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t29, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) })
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = getelementptr %"compiler/unparse:writer", ptr %t32, i32 0, i32 4
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = add i64 %t34, 1
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = getelementptr %"compiler/unparse:writer", ptr %t38, i32 0, i32 4
  store i64 %t36, ptr %t39, !tbaa !24
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  store ptr %t63, ptr %l5, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t65)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l3, !tbaa !24
  br label %bb8
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l38, !tbaa !29
  %t76 = load ptr, ptr %l38, !tbaa !29
  %t77 = getelementptr %"compiler/unparse:writer", ptr %t76, i32 0, i32 4
  %t78 = load i64, ptr %t77, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"compiler/unparse:writer", ptr %t82, i32 0, i32 4
  store i64 %t80, ptr %t83, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t84)
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t86, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) })
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l10 = alloca ptr
  %l21 = alloca ptr
  %l32 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d144, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:TopIf", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_69b21e264e8a714a_b3e97d9d77526506)
  unreachable
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:TopIf", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t15, ptr %t14)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t17, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) })
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:TopIf", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8585d6fe8f316a51_b60a12ce50df87ed)
  unreachable
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TopIf", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t31, ptr %t30)
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/ast:TopIf", ptr %t33, i32 0, i32 2
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t42, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d146, i32 0, i32 1) })
  br label %bb13
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TopIf", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = icmp eq ptr %t47, null
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb18, label %bb19
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l21, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:TopIf", ptr %t54, i32 0, i32 2
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_eabe3ddcfaef285c_106dba970e52f8d8)
  unreachable
bb15:
  br label %bb16
bb16:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:TopIf", ptr %t61, i32 0, i32 2
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t65, ptr %t64)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t67, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d147, i32 0, i32 1) })
  br label %bb20
bb19:
  br label %bb25
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l32, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/ast:TopIf", ptr %t70, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_14b8182deed7e34b_cfe8cf3ea4c448f7)
  unreachable
bb22:
  br label %bb23
bb23:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/ast:TopIf", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t81, ptr %t80)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l42 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca i1
  %l67 = alloca i1
  %l70 = alloca i1
  %l75 = alloca i1
  %l81 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l113 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l120 = alloca ptr
  %l121 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l144 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca i1
  %l167 = alloca i1
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t2 = load ptr, ptr %l26, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l26, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l27, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l27, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb23
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb7, label %bb8
bb7:
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t38, ptr %l42, !tbaa !27
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i32, ptr %t42, i64 %t39
  %t44 = load i32, ptr %t43, !tbaa !33
  store i32 %t44, ptr %l8, !tbaa !23
  %t48 = icmp sgt i64 %t36, 0
  br i1 %t48, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t50, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) })
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t52, i32 %t53)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb6
bb16:
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t66 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t66, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d149, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t68, { i64, ptr } %t69)
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t72, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  br label %bb122
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t75 = load ptr, ptr %l59, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l59, !tbaa !29
  %t79 = load i64, ptr %t78
  %t81 = icmp eq i64 %t79, 1
  store i1 %t81, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l60, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l9, !tbaa !29
  br label %bb28
bb27:
  br label %bb47
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/unparse:writer", ptr %t89, i32 0, i32 7
  %t92 = load i1, ptr %t91, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb37
bb30:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/unparse:writer", ptr %t94, i32 0, i32 6
  %t97 = load i1, ptr %t96, !tbaa !21
  br i1 %t97, label %bb31, label %bb32
bb31:
  %t99 = load ptr, ptr %l9, !tbaa !29
  %t101 = getelementptr %"compiler/ast:Sig", ptr %t99, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t106 = icmp sgt i64 %t104, 1
  br i1 %t106, label %bb33, label %bb34
bb32:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb36
bb33:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb35
bb34:
  %t108 = load ptr, ptr %l9, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Sig", ptr %t108, i32 0, i32 3
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t115 = icmp sgt i64 %t113, 1
  store i1 %t115, ptr %l75, !tbaa !21
  br label %bb35
bb35:
  %t117 = load i1, ptr %l75, !tbaa !21
  store i1 %t117, ptr %l70, !tbaa !21
  br label %bb36
bb36:
  %t118 = load i1, ptr %l70, !tbaa !21
  store i1 %t118, ptr %l67, !tbaa !21
  br label %bb37
bb37:
  %t119 = load i1, ptr %l67, !tbaa !21
  store i1 %t119, ptr %l10, !tbaa !21
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/unparse:writer", ptr %t120, i32 0, i32 7
  store i1 false, ptr %t122, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l81, !tbaa !29
  %t124 = load i1, ptr %l10, !tbaa !21
  br i1 %t124, label %bb38, label %bb39
bb38:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d151, i32 0, i32 1) }, ptr %l83, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d152, i32 0, i32 1) }, ptr %l83, !tbaa !27
  br label %bb40
bb40:
  %t126 = load ptr, ptr %l81, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l83, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t126, { i64, ptr } %t127)
  br label %bb41
bb41:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/unparse:writer", ptr %t128, i32 0, i32 6
  %t131 = load i1, ptr %t130, !tbaa !21
  store i1 %t131, ptr %l11, !tbaa !21
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/unparse:writer", ptr %t133, i32 0, i32 6
  store i1 false, ptr %t135, !tbaa !21
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t136, ptr %t137)
  br label %bb42
bb42:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i1, ptr %l11, !tbaa !21
  %t144 = getelementptr %"compiler/unparse:writer", ptr %t140, i32 0, i32 6
  store i1 %t141, ptr %t144, !tbaa !21
  %t145 = load i1, ptr %l10, !tbaa !21
  br i1 %t145, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t147, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d153, i32 0, i32 1) })
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb122
bb47:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t150 = load ptr, ptr %l93, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb48, label %bb49
bb48:
  %t153 = load ptr, ptr %l93, !tbaa !29
  %t154 = load i64, ptr %t153
  %t156 = icmp eq i64 %t154, 2
  store i1 %t156, ptr %l94, !tbaa !21
  br label %bb49
bb49:
  %t157 = load i1, ptr %l94, !tbaa !21
  br i1 %t157, label %bb50, label %bb51
bb50:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l12, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t164, ptr %t165)
  br label %bb53
bb53:
  br label %bb122
bb54:
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t169 = load ptr, ptr %l101, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb55, label %bb56
bb55:
  %t172 = load ptr, ptr %l101, !tbaa !29
  %t173 = load i64, ptr %t172
  %t175 = icmp eq i64 %t173, 3
  store i1 %t175, ptr %l102, !tbaa !21
  br label %bb56
bb56:
  %t176 = load i1, ptr %l102, !tbaa !21
  br i1 %t176, label %bb57, label %bb58
bb57:
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t179, i32 0, i32 1
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l13, !tbaa !29
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t185, i32 0, i32 2
  %t187 = load i32, ptr %t186
  store i32 %t187, ptr %l14, !tbaa !23
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t191, i32 0, i32 3
  %t193 = load i1, ptr %t192
  store i1 %t193, ptr %l15, !tbaa !21
  br label %bb59
bb58:
  br label %bb69
bb59:
  store %olang.scope zeroinitializer, ptr %s10
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t195, ptr %t196)
  br label %bb60
bb60:
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l113, !tbaa !29
  %t200 = load i1, ptr %l15, !tbaa !21
  br i1 %t200, label %bb61, label %bb62
bb61:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d154, i32 0, i32 1) }, ptr %l115, !tbaa !27
  br label %bb63
bb62:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d155, i32 0, i32 1) }, ptr %l115, !tbaa !27
  br label %bb63
bb63:
  %t202 = load ptr, ptr %l113, !tbaa !29
  %t203 = load { i64, ptr }, ptr %l115, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t202, { i64, ptr } %t203)
  br label %bb64
bb64:
  %t204 = load i32, ptr %l14, !tbaa !23
  %t206 = icmp ne i32 %t204, 0
  br i1 %t206, label %bb65, label %bb66
bb65:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t208, i32 %t209)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s10)
  br label %bb122
bb69:
  %t212 = load ptr, ptr %l1, !tbaa !29
  store ptr %t212, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t213 = load ptr, ptr %l120, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb70, label %bb71
bb70:
  %t216 = load ptr, ptr %l120, !tbaa !29
  %t217 = load i64, ptr %t216
  %t219 = icmp eq i64 %t217, 5
  store i1 %t219, ptr %l121, !tbaa !21
  br label %bb71
bb71:
  %t220 = load i1, ptr %l121, !tbaa !21
  br i1 %t220, label %bb72, label %bb73
bb72:
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", ptr }, ptr %t223, i32 0, i32 1
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l16, !tbaa !29
  br label %bb74
bb73:
  br label %bb77
bb74:
  store %olang.scope zeroinitializer, ptr %s12
  %t227 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t227, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d156, i32 0, i32 1) })
  br label %bb75
bb75:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t229, ptr %t230)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s12)
  br label %bb122
bb77:
  %t233 = load ptr, ptr %l1, !tbaa !29
  store ptr %t233, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t234 = load ptr, ptr %l129, !tbaa !29
  %t235 = icmp ne ptr %t234, null
  br i1 %t235, label %bb78, label %bb79
bb78:
  %t237 = load ptr, ptr %l129, !tbaa !29
  %t238 = load i64, ptr %t237
  %t240 = icmp eq i64 %t238, 6
  store i1 %t240, ptr %l130, !tbaa !21
  br label %bb79
bb79:
  %t241 = load i1, ptr %l130, !tbaa !21
  br i1 %t241, label %bb80, label %bb81
bb80:
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr { i64, [5 x i64] }, ptr %t242, i32 0, i32 1
  %t245 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t244, i32 0, i32 1
  %t246 = load { i64, ptr }, ptr %t245
  store { i64, ptr } %t246, ptr %l17, !tbaa !27
  br label %bb82
bb81:
  br label %bb95
bb82:
  store %olang.scope zeroinitializer, ptr %s13
  %t248 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t248, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d157, i32 0, i32 1) })
  br label %bb83
bb83:
  %t250 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t250, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t252 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t252, 0
  store i64 %t254, ptr %l20, !tbaa !24
  br label %bb84
bb84:
  %t256 = load i64, ptr %l19, !tbaa !24
  %t257 = load i64, ptr %l20, !tbaa !24
  %t260 = icmp slt i64 %t256, %t257
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb85, label %bb86
bb85:
  br label %bb94
bb86:
  br label %bb87
bb87:
  %t264 = load i64, ptr %l19, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t266, ptr %l144, !tbaa !27
  %t267 = load i64, ptr %l19, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr ptr, ptr %t270, i64 %t267
  %t272 = load ptr, ptr %t271, !tbaa !39
  store ptr %t272, ptr %l22, !tbaa !29
  %t276 = icmp sgt i64 %t264, 0
  br i1 %t276, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s16
  %t278 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t278, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d158, i32 0, i32 1) })
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_scope_close(ptr %s16)
  br label %bb91
bb91:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t280, ptr %t281)
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t284 = load i64, ptr %l19, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l19, !tbaa !24
  br label %bb84
bb94:
  call void @__olang_scope_close(ptr %s13)
  br label %bb122
bb95:
  %t288 = load ptr, ptr %l1, !tbaa !29
  store ptr %t288, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t289 = load ptr, ptr %l154, !tbaa !29
  %t290 = icmp ne ptr %t289, null
  br i1 %t290, label %bb96, label %bb97
bb96:
  %t292 = load ptr, ptr %l154, !tbaa !29
  %t293 = load i64, ptr %t292
  %t295 = icmp eq i64 %t293, 4
  store i1 %t295, ptr %l155, !tbaa !21
  br label %bb97
bb97:
  %t296 = load i1, ptr %l155, !tbaa !21
  br i1 %t296, label %bb98, label %bb99
bb98:
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr { i64, [5 x i64] }, ptr %t297, i32 0, i32 1
  %t300 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t299, i32 0, i32 1
  %t301 = load ptr, ptr %t300
  store ptr %t301, ptr %l23, !tbaa !29
  %t303 = load ptr, ptr %l1, !tbaa !29
  %t305 = getelementptr { i64, [5 x i64] }, ptr %t303, i32 0, i32 1
  %t306 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t305, i32 0, i32 2
  %t307 = load i1, ptr %t306
  store i1 %t307, ptr %l24, !tbaa !21
  %t309 = load ptr, ptr %l1, !tbaa !29
  %t311 = getelementptr { i64, [5 x i64] }, ptr %t309, i32 0, i32 1
  %t312 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t311, i32 0, i32 3
  %t313 = load i1, ptr %t312
  store i1 %t313, ptr %l25, !tbaa !21
  br label %bb100
bb99:
  br label %bb121
bb100:
  %t315 = load i1, ptr %l25, !tbaa !21
  br i1 %t315, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s19
  %t317 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t317, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d159, i32 0, i32 1) })
  br label %bb103
bb102:
  br label %bb104
bb103:
  call void @__olang_scope_close(ptr %s19)
  br label %bb104
bb104:
  %t319 = load i1, ptr %l25, !tbaa !21
  br i1 %t319, label %bb105, label %bb106
bb105:
  %t321 = load i1, ptr %l24, !tbaa !21
  store i1 %t321, ptr %l167, !tbaa !21
  br label %bb107
bb106:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb107
bb107:
  %t323 = load i1, ptr %l167, !tbaa !21
  br i1 %t323, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s20
  %t324 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t324, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) })
  br label %bb110
bb109:
  br label %bb111
bb110:
  call void @__olang_scope_close(ptr %s20)
  br label %bb111
bb111:
  %t326 = load i1, ptr %l24, !tbaa !21
  br i1 %t326, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s21
  %t328 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t328, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d161, i32 0, i32 1) })
  br label %bb114
bb113:
  br label %bb115
bb114:
  call void @__olang_scope_close(ptr %s21)
  br label %bb115
bb115:
  %t330 = load ptr, ptr %l23, !tbaa !29
  %t332 = icmp eq ptr %t330, null
  %t334 = xor i1 %t332, true
  br i1 %t334, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s22
  %t336 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t336, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) })
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t338, ptr %t339)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s22)
  br label %bb120
bb120:
  br label %bb122
bb121:
  call void @__olang_check_failed(ptr @olang_loc_9034b6aed20fb51a_d179ca40c5e654ce)
  unreachable
bb122:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l48 = alloca ptr
  %l54 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i1
  %l87 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l137 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca i1
  %l165 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l200 = alloca ptr
  %l210 = alloca { i64, ptr }
  %l227 = alloca ptr
  %l232 = alloca ptr
  %l233 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s29 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t2 = load ptr, ptr %l29, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l29, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l30, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l30, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb150
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t11 = load ptr, ptr %l33, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l33, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l34, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l34, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [6 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { ptr }, ptr %t21, i32 0, i32 0
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb32
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t25, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d163, i32 0, i32 1) })
  br label %bb12
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/ast:StructBody", ptr %t28, i32 0, i32 5
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t27, { i64, ptr } %t31)
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t34, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) })
  br label %bb14
bb14:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:StructBody", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t36, { i64, ptr } %t40)
  br label %bb15
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t43, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) })
  br label %bb16
bb16:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l48, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/ast:StructBody", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8cd05a7785ffddf0_abfc69165374635c)
  unreachable
bb18:
  br label %bb19
bb19:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:StructBody", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t57, ptr %t56)
  br label %bb20
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l54, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:StructBody", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_c53cd7dd70350acf_d5f64367475d1e4b)
  unreachable
bb22:
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = getelementptr %"compiler/ast:StructBody", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t71 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtract(ptr %v0, ptr %v1, ptr %t71, ptr %t70)
  br label %bb24
bb24:
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t73, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d166, i32 0, i32 1) })
  br label %bb25
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:StructBody", ptr %t76, i32 0, i32 2
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t75, { i64, ptr } %t79)
  br label %bb26
bb26:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = getelementptr %"compiler/ast:StructBody", ptr %t82, i32 0, i32 3
  %t85 = getelementptr %"compiler/source:Span", ptr %t84, i32 0, i32 1
  %t86 = load i32, ptr %t85, !tbaa !23
  %t88 = icmp sgt i32 %t86, 0
  br i1 %t88, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t90, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d167, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/ast:StructBody", ptr %t93, i32 0, i32 4
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t92, { i64, ptr } %t96)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb150
bb32:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t100 = load ptr, ptr %l71, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l71, !tbaa !29
  %t104 = load i64, ptr %t103
  %t106 = icmp eq i64 %t104, 1
  store i1 %t106, ptr %l72, !tbaa !21
  br label %bb34
bb34:
  %t107 = load i1, ptr %l72, !tbaa !21
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [6 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { { i64, ptr }, ptr }, ptr %t110, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111
  store { i64, ptr } %t112, ptr %l3, !tbaa !27
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [6 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { { i64, ptr }, ptr }, ptr %t116, i32 0, i32 1
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l4, !tbaa !29
  br label %bb37
bb36:
  br label %bb77
bb37:
  store %olang.scope zeroinitializer, ptr %s4
  %t120 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t120, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d168, i32 0, i32 1) })
  br label %bb38
bb38:
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t128, ptr %t129)
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t132 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t132, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) })
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  %t134 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t134, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d170, i32 0, i32 1) })
  br label %bb44
bb44:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l87, !tbaa !29
  %t137 = load ptr, ptr %l87, !tbaa !29
  %t138 = getelementptr %"compiler/unparse:writer", ptr %t137, i32 0, i32 4
  %t139 = load i64, ptr %t138, !tbaa !24
  %t141 = add i64 %t139, 1
  %t143 = load ptr, ptr %l87, !tbaa !29
  %t144 = getelementptr %"compiler/unparse:writer", ptr %t143, i32 0, i32 4
  store i64 %t141, ptr %t144, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t145, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  store i64 %t149, ptr %l7, !tbaa !24
  br label %bb45
bb45:
  %t151 = load i64, ptr %l6, !tbaa !24
  %t152 = load i64, ptr %l7, !tbaa !24
  %t155 = icmp slt i64 %t151, %t152
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb46, label %bb47
bb46:
  br label %bb74
bb47:
  br label %bb48
bb48:
  %t159 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t159, ptr %l97, !tbaa !27
  %t160 = load i64, ptr %l6, !tbaa !24
  %t162 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr ptr, ptr %t163, i64 %t160
  %t165 = load ptr, ptr %t164, !tbaa !39
  store ptr %t165, ptr %l8, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t167)
  br label %bb49
bb49:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l8, !tbaa !29
  %t172 = getelementptr %"compiler/ast:CaseDecl", ptr %t170, i32 0, i32 1
  %t173 = load i32, ptr %t172, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t169, i32 %t173)
  br label %bb50
bb50:
  %t176 = load ptr, ptr %l8, !tbaa !29
  %t178 = getelementptr %"compiler/ast:CaseDecl", ptr %t176, i32 0, i32 3
  %t179 = load i1, ptr %t178, !tbaa !21
  br i1 %t179, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t181 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t181, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) })
  br label %bb53
bb52:
  %t183 = load ptr, ptr %l8, !tbaa !29
  %t185 = getelementptr %"compiler/ast:CaseDecl", ptr %t183, i32 0, i32 2
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t190 = icmp sgt i64 %t188, 0
  br i1 %t190, label %bb58, label %bb59
bb53:
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l107, !tbaa !29
  %t193 = load ptr, ptr %l8, !tbaa !29
  %t195 = getelementptr %"compiler/ast:CaseDecl", ptr %t193, i32 0, i32 2
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  store { i64, ptr } %t196, ptr %l109, !tbaa !27
  %t197 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 0
  %t200 = load ptr, ptr %t199, !tbaa !39
  %t202 = getelementptr %"compiler/ast:Param", ptr %t200, i32 0, i32 2
  %t203 = load ptr, ptr %t202, !tbaa !29
  store ptr %t203, ptr %l9, !tbaa !29
  %t205 = load ptr, ptr %l9, !tbaa !29
  %t207 = icmp eq ptr %t205, null
  br i1 %t207, label %bb54, label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_565cf8a51c2b309e_2af0495fa70fac4a)
  unreachable
bb55:
  br label %bb56
bb56:
  %t209 = load ptr, ptr %l9, !tbaa !29
  %t210 = load ptr, ptr %l107, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t210, ptr %t209)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb64
bb58:
  store %olang.scope zeroinitializer, ptr %s10
  %t212 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t212, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) })
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l8, !tbaa !29
  %t217 = getelementptr %"compiler/ast:CaseDecl", ptr %t215, i32 0, i32 2
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t214, { i64, ptr } %t218)
  br label %bb61
bb61:
  %t221 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t221, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t223 = load ptr, ptr %l8, !tbaa !29
  %t225 = getelementptr %"compiler/ast:CaseDecl", ptr %t223, i32 0, i32 4
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s11
  %t232 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t232, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d174, i32 0, i32 1) })
  br label %bb67
bb66:
  br label %bb72
bb67:
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l129, !tbaa !29
  %t235 = load ptr, ptr %l8, !tbaa !29
  %t237 = getelementptr %"compiler/ast:CaseDecl", ptr %t235, i32 0, i32 4
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = icmp eq ptr %t238, null
  br i1 %t240, label %bb68, label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_a9c38de43eb77545_46c40237e7b6a551)
  unreachable
bb69:
  br label %bb70
bb70:
  %t242 = load ptr, ptr %l8, !tbaa !29
  %t244 = getelementptr %"compiler/ast:CaseDecl", ptr %t242, i32 0, i32 4
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t246 = load ptr, ptr %l129, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t246, ptr %t245)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb72:
  br label %bb73
bb73:
  %t248 = load i64, ptr %l6, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l6, !tbaa !24
  br label %bb45
bb74:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l137, !tbaa !29
  %t253 = load ptr, ptr %l137, !tbaa !29
  %t254 = getelementptr %"compiler/unparse:writer", ptr %t253, i32 0, i32 4
  %t255 = load i64, ptr %t254, !tbaa !24
  %t257 = sub i64 %t255, 1
  %t259 = load ptr, ptr %l137, !tbaa !29
  %t260 = getelementptr %"compiler/unparse:writer", ptr %t259, i32 0, i32 4
  store i64 %t257, ptr %t260, !tbaa !24
  %t261 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t261)
  br label %bb75
bb75:
  %t263 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t263, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) })
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s4)
  br label %bb150
bb77:
  %t265 = load ptr, ptr %l1, !tbaa !29
  store ptr %t265, ptr %l142, !tbaa !29
  store i1 false, ptr %l143, !tbaa !21
  %t266 = load ptr, ptr %l142, !tbaa !29
  %t267 = icmp ne ptr %t266, null
  br i1 %t267, label %bb78, label %bb79
bb78:
  %t269 = load ptr, ptr %l142, !tbaa !29
  %t270 = load i64, ptr %t269
  %t272 = icmp eq i64 %t270, 2
  store i1 %t272, ptr %l143, !tbaa !21
  br label %bb79
bb79:
  %t273 = load i1, ptr %l143, !tbaa !21
  br i1 %t273, label %bb80, label %bb81
bb80:
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t276 = getelementptr { i64, [6 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t276, i32 0, i32 0
  %t278 = load { i64, ptr }, ptr %t277
  store { i64, ptr } %t278, ptr %l10, !tbaa !27
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t282 = getelementptr { i64, [6 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t282, i32 0, i32 1
  %t284 = load { i64, ptr }, ptr %t283
  store { i64, ptr } %t284, ptr %l11, !tbaa !27
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr { i64, [6 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t288, i32 0, i32 2
  %t290 = load { i64, ptr }, ptr %t289
  store { i64, ptr } %t290, ptr %l12, !tbaa !27
  br label %bb82
bb81:
  br label %bb132
bb82:
  store %olang.scope zeroinitializer, ptr %s13
  %t292 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t292, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d176, i32 0, i32 1) })
  br label %bb83
bb83:
  %t294 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t298 = icmp sgt i64 %t296, 0
  br i1 %t298, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s14
  %t300 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t300, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d177, i32 0, i32 1) })
  br label %bb86
bb85:
  br label %bb99
bb86:
  %t302 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t302, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t304 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 0
  store i64 %t306, ptr %l15, !tbaa !24
  br label %bb87
bb87:
  %t308 = load i64, ptr %l14, !tbaa !24
  %t309 = load i64, ptr %l15, !tbaa !24
  %t312 = icmp slt i64 %t308, %t309
  %t314 = xor i1 %t312, true
  br i1 %t314, label %bb88, label %bb89
bb88:
  br label %bb97
bb89:
  br label %bb90
bb90:
  %t316 = load i64, ptr %l14, !tbaa !24
  %t318 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t318, ptr %l165, !tbaa !27
  %t319 = load i64, ptr %l14, !tbaa !24
  %t321 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr ptr, ptr %t322, i64 %t319
  %t324 = load ptr, ptr %t323, !tbaa !39
  store ptr %t324, ptr %l17, !tbaa !29
  %t328 = icmp sgt i64 %t316, 0
  br i1 %t328, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s17
  %t330 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t330, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d178, i32 0, i32 1) })
  br label %bb93
bb92:
  br label %bb94
bb93:
  call void @__olang_scope_close(ptr %s17)
  br label %bb94
bb94:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t332, ptr %t333)
  br label %bb95
bb95:
  br label %bb96
bb96:
  %t336 = load i64, ptr %l14, !tbaa !24
  %t338 = add i64 %t336, 1
  store i64 %t338, ptr %l14, !tbaa !24
  br label %bb87
bb97:
  %t340 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t340, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d179, i32 0, i32 1) })
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s14)
  br label %bb99
bb99:
  %t342 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t342, 0
  %t346 = icmp sgt i64 %t344, 0
  br i1 %t346, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s19
  %t348 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t348, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d180, i32 0, i32 1) })
  br label %bb102
bb101:
  br label %bb115
bb102:
  %t350 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t350, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t352 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t352, 0
  store i64 %t354, ptr %l20, !tbaa !24
  br label %bb103
bb103:
  %t356 = load i64, ptr %l19, !tbaa !24
  %t357 = load i64, ptr %l20, !tbaa !24
  %t360 = icmp slt i64 %t356, %t357
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb104, label %bb105
bb104:
  br label %bb113
bb105:
  br label %bb106
bb106:
  %t364 = load i64, ptr %l19, !tbaa !24
  %t366 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t366, ptr %l188, !tbaa !27
  %t367 = load i64, ptr %l19, !tbaa !24
  %t369 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = getelementptr ptr, ptr %t370, i64 %t367
  %t372 = load ptr, ptr %t371, !tbaa !39
  store ptr %t372, ptr %l22, !tbaa !29
  %t376 = icmp sgt i64 %t364, 0
  br i1 %t376, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s22
  %t378 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t378, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d181, i32 0, i32 1) })
  br label %bb109
bb108:
  br label %bb110
bb109:
  call void @__olang_scope_close(ptr %s22)
  br label %bb110
bb110:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t380, ptr %t381)
  br label %bb111
bb111:
  br label %bb112
bb112:
  %t384 = load i64, ptr %l19, !tbaa !24
  %t386 = add i64 %t384, 1
  store i64 %t386, ptr %l19, !tbaa !24
  br label %bb103
bb113:
  %t388 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t388, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d182, i32 0, i32 1) })
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s19)
  br label %bb115
bb115:
  %t390 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t390, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) })
  br label %bb116
bb116:
  %t392 = load ptr, ptr %l0, !tbaa !29
  store ptr %t392, ptr %l200, !tbaa !29
  %t393 = load ptr, ptr %l200, !tbaa !29
  %t394 = getelementptr %"compiler/unparse:writer", ptr %t393, i32 0, i32 4
  %t395 = load i64, ptr %t394, !tbaa !24
  %t397 = add i64 %t395, 1
  %t399 = load ptr, ptr %l200, !tbaa !29
  %t400 = getelementptr %"compiler/unparse:writer", ptr %t399, i32 0, i32 4
  store i64 %t397, ptr %t400, !tbaa !24
  %t401 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t401, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t403 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t403, 0
  store i64 %t405, ptr %l25, !tbaa !24
  br label %bb117
bb117:
  %t407 = load i64, ptr %l24, !tbaa !24
  %t408 = load i64, ptr %l25, !tbaa !24
  %t411 = icmp slt i64 %t407, %t408
  %t413 = xor i1 %t411, true
  br i1 %t413, label %bb118, label %bb119
bb118:
  br label %bb129
bb119:
  br label %bb120
bb120:
  %t415 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t415, ptr %l210, !tbaa !27
  %t416 = load i64, ptr %l24, !tbaa !24
  %t418 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !27
  %t420 = getelementptr ptr, ptr %t419, i64 %t416
  %t421 = load ptr, ptr %t420, !tbaa !39
  store ptr %t421, ptr %l26, !tbaa !29
  %t423 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t423)
  br label %bb121
bb121:
  %t425 = load ptr, ptr %l26, !tbaa !29
  %t427 = getelementptr %"compiler/ast:Func", ptr %t425, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t430 = icmp eq ptr %t428, null
  %t432 = xor i1 %t430, true
  br i1 %t432, label %bb122, label %bb123
bb122:
  store %olang.scope zeroinitializer, ptr %s26
  %t434 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t434, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d184, i32 0, i32 1) })
  br label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_scope_close(ptr %s26)
  br label %bb125
bb125:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load ptr, ptr %l26, !tbaa !29
  %t439 = getelementptr %"compiler/ast:Func", ptr %t437, i32 0, i32 2
  %t440 = load i32, ptr %t439, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t436, i32 %t440)
  br label %bb126
bb126:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load ptr, ptr %l26, !tbaa !29
  %t446 = getelementptr %"compiler/ast:Func", ptr %t444, i32 0, i32 3
  %t447 = load ptr, ptr %t446, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t443, ptr %t447)
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t450 = load i64, ptr %l24, !tbaa !24
  %t452 = add i64 %t450, 1
  store i64 %t452, ptr %l24, !tbaa !24
  br label %bb117
bb129:
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l227, !tbaa !29
  %t455 = load ptr, ptr %l227, !tbaa !29
  %t456 = getelementptr %"compiler/unparse:writer", ptr %t455, i32 0, i32 4
  %t457 = load i64, ptr %t456, !tbaa !24
  %t459 = sub i64 %t457, 1
  %t461 = load ptr, ptr %l227, !tbaa !29
  %t462 = getelementptr %"compiler/unparse:writer", ptr %t461, i32 0, i32 4
  store i64 %t459, ptr %t462, !tbaa !24
  %t463 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t463)
  br label %bb130
bb130:
  %t465 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t465, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d185, i32 0, i32 1) })
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s13)
  br label %bb150
bb132:
  %t467 = load ptr, ptr %l1, !tbaa !29
  store ptr %t467, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t468 = load ptr, ptr %l232, !tbaa !29
  %t469 = icmp ne ptr %t468, null
  br i1 %t469, label %bb133, label %bb134
bb133:
  %t471 = load ptr, ptr %l232, !tbaa !29
  %t472 = load i64, ptr %t471
  %t474 = icmp eq i64 %t472, 3
  store i1 %t474, ptr %l233, !tbaa !21
  br label %bb134
bb134:
  %t475 = load i1, ptr %l233, !tbaa !21
  br i1 %t475, label %bb135, label %bb136
bb135:
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr { i64, [6 x i64] }, ptr %t476, i32 0, i32 1
  %t479 = getelementptr { ptr, ptr }, ptr %t478, i32 0, i32 0
  %t480 = load ptr, ptr %t479
  store ptr %t480, ptr %l27, !tbaa !29
  %t482 = load ptr, ptr %l1, !tbaa !29
  %t484 = getelementptr { i64, [6 x i64] }, ptr %t482, i32 0, i32 1
  %t485 = getelementptr { ptr, ptr }, ptr %t484, i32 0, i32 1
  %t486 = load ptr, ptr %t485
  store ptr %t486, ptr %l28, !tbaa !29
  br label %bb137
bb136:
  br label %bb149
bb137:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t488, ptr %t489)
  br label %bb138
bb138:
  %t492 = load ptr, ptr %l28, !tbaa !29
  %t494 = icmp eq ptr %t492, null
  %t496 = xor i1 %t494, true
  br i1 %t496, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s29
  %t498 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t498, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d186, i32 0, i32 1) })
  br label %bb141
bb140:
  br label %bb148
bb141:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load ptr, ptr %l28, !tbaa !29
  %t503 = getelementptr %"compiler/ast:Func", ptr %t501, i32 0, i32 3
  %t504 = load ptr, ptr %t503, !tbaa !29
  %t506 = getelementptr %"compiler/ast:Sig", ptr %t504, i32 0, i32 0
  %t507 = load { i64, ptr }, ptr %t506, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t500, { i64, ptr } %t507)
  br label %bb142
bb142:
  %t510 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t510, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d187, i32 0, i32 1) })
  br label %bb143
bb143:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t513 = load ptr, ptr %l28, !tbaa !29
  %t515 = getelementptr %"compiler/ast:Func", ptr %t513, i32 0, i32 3
  %t516 = load ptr, ptr %t515, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t512, ptr %t516)
  br label %bb144
bb144:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load ptr, ptr %l28, !tbaa !29
  %t522 = getelementptr %"compiler/ast:Func", ptr %t520, i32 0, i32 3
  %t523 = load ptr, ptr %t522, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtract(ptr %v0, ptr %v1, ptr %t519, ptr %t523)
  br label %bb145
bb145:
  %t526 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t526, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) })
  br label %bb146
bb146:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load ptr, ptr %l28, !tbaa !29
  %t531 = getelementptr %"compiler/ast:Func", ptr %t529, i32 0, i32 4
  %t532 = load { i64, ptr }, ptr %t531, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t528, { i64, ptr } %t532)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s29)
  br label %bb148
bb148:
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_7b9eb6dfa833729b_791a1e6ae071d10f)
  unreachable
bb150:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l24 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t15, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d189, i32 0, i32 1) })
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:TypeDecl", ptr %t18, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t17, i32 %t21)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t24, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d190, i32 0, i32 1) })
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TypeDecl", ptr %t27, i32 0, i32 0
  %t30 = load i32, ptr %t29, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t26, i32 %t30)
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeDecl", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t33, { i64, ptr } %t37)
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TypeDecl", ptr %t40, i32 0, i32 2
  %t43 = load i1, ptr %t42, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t45, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d191, i32 0, i32 1) })
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t47, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d192, i32 0, i32 1) })
  br label %bb17
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l24, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/ast:TypeDecl", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_5bab8da58715fcd0_e7391da9b8dff344)
  unreachable
bb19:
  br label %bb20
bb20:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/ast:TypeDecl", ptr %t57, i32 0, i32 3
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t61, ptr %t60)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l64 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t7, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d193, i32 0, i32 1) })
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/unparse:writer", ptr %t9, i32 0, i32 6
  %t12 = load i1, ptr %t11, !tbaa !21
  store i1 %t12, ptr %l2, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/unparse:writer", ptr %t14, i32 0, i32 6
  store i1 true, ptr %t16, !tbaa !21
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %bb39
bb7:
  br label %bb8
bb8:
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l27, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  store ptr %t39, ptr %l7, !tbaa !29
  %t41 = load ptr, ptr %l7, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TypeParam", ptr %t41, i32 0, i32 4
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb10:
  br label %bb16
bb11:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d194, i32 0, i32 1) }, ptr %l35, !tbaa !27
  br label %bb13
bb12:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d195, i32 0, i32 1) }, ptr %l35, !tbaa !27
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l32, !tbaa !29
  %t52 = load { i64, ptr }, ptr %l35, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t51, { i64, ptr } %t52)
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t56 = getelementptr %"compiler/ast:TypeParam", ptr %t54, i32 0, i32 1
  %t57 = load i32, ptr %t56, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t53, i32 %t57)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb16:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t64, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d196, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = getelementptr %"compiler/ast:TypeParam", ptr %t67, i32 0, i32 1
  %t70 = load i32, ptr %t69, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t66, i32 %t70)
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l7, !tbaa !29
  %t75 = getelementptr %"compiler/ast:TypeParam", ptr %t73, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = icmp eq ptr %t76, null
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t82 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t82, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d197, i32 0, i32 1) })
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l50, !tbaa !29
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t87 = getelementptr %"compiler/ast:TypeParam", ptr %t85, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = icmp eq ptr %t88, null
  br i1 %t90, label %bb25, label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_b36b34168d540f92_3d8b83b8d4d4846)
  unreachable
bb26:
  br label %bb27
bb27:
  %t92 = load ptr, ptr %l7, !tbaa !29
  %t94 = getelementptr %"compiler/ast:TypeParam", ptr %t92, i32 0, i32 2
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t96, ptr %t95)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t98 = load ptr, ptr %l7, !tbaa !29
  %t100 = getelementptr %"compiler/ast:TypeParam", ptr %t98, i32 0, i32 3
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t107 = load i64, ptr %l9, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s8)
  br label %bb37
bb32:
  br label %bb33
bb33:
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t115, ptr %l64, !tbaa !27
  %t116 = load i64, ptr %l9, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr ptr, ptr %t119, i64 %t116
  %t121 = load ptr, ptr %t120, !tbaa !39
  store ptr %t121, ptr %l11, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t123, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d198, i32 0, i32 1) })
  br label %bb34
bb34:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t125, ptr %t126)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb36
bb36:
  %t129 = load i64, ptr %l9, !tbaa !24
  %t131 = add i64 %t129, 1
  store i64 %t131, ptr %l9, !tbaa !24
  br label %bb30
bb37:
  br label %bb38
bb38:
  %t133 = load i64, ptr %l4, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l4, !tbaa !24
  br label %bb5
bb39:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i1, ptr %l2, !tbaa !21
  %t141 = getelementptr %"compiler/unparse:writer", ptr %t137, i32 0, i32 6
  store i1 %t138, ptr %t141, !tbaa !21
  %t142 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t142, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d199, i32 0, i32 1) })
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  br label %bb33
bb3:
  br label %bb4
bb4:
  %t23 = load i64, ptr %l4, !tbaa !24
  store i64 %t23, ptr %l6, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l25, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l7, !tbaa !29
  %t33 = load ptr, ptr %l7, !tbaa !29
  store ptr %t33, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t37 = load ptr, ptr %l28, !tbaa !29
  %t38 = load i64, ptr %t37
  %t40 = icmp eq i64 %t38, 6
  store i1 %t40, ptr %l29, !tbaa !21
  br label %bb6
bb6:
  %t41 = load i1, ptr %l29, !tbaa !21
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t44, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l8, !tbaa !27
  br label %bb9
bb8:
  br label %bb25
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l34, !tbaa !29
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d200, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d201, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l34, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t53, { i64, ptr } %t54)
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t55, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  br label %bb24
bb16:
  br label %bb17
bb17:
  %t69 = load i64, ptr %l10, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t71, ptr %l46, !tbaa !27
  %t72 = load i64, ptr %l10, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr ptr, ptr %t75, i64 %t72
  %t77 = load ptr, ptr %t76, !tbaa !39
  store ptr %t77, ptr %l13, !tbaa !29
  %t81 = icmp sgt i64 %t69, 0
  br i1 %t81, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  %t83 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t83, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d202, i32 0, i32 1) })
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l10, !tbaa !24
  br label %bb14
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb25:
  br label %bb26
bb26:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s9
  %t97 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t97, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d203, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb30
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t99, ptr %t100)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t103 = load i64, ptr %l4, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l4, !tbaa !24
  br label %bb1
bb33:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i1, ptr %l2, !tbaa !21
  %t111 = getelementptr %"compiler/unparse:writer", ptr %t107, i32 0, i32 6
  store i1 %t108, ptr %t111, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l47 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t30 = icmp sgt i64 %t18, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t32, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d204, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t34, i32 %t35)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/ast:VarDecl", ptr %t42, i32 0, i32 4
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t47, i32 0, i32 2
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb14, label %bb15
bb13:
  br label %bb24
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t56, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d205, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/ast:VarDecl", ptr %t59, i32 0, i32 2
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_45ada3313b7506a3_5e369560cd76ab37)
  unreachable
bb18:
  br label %bb19
bb19:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:VarDecl", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t70, ptr %t69)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t72, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb22
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/ast:VarDecl", ptr %t75, i32 0, i32 3
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t74, { i64, ptr } %t78)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/ast:VarDecl", ptr %t81, i32 0, i32 2
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t88, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d207, i32 0, i32 1) })
  br label %bb28
bb28:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l47, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/ast:VarDecl", ptr %t91, i32 0, i32 2
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb29, label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_89b7cc3957ccbb94_42e76e0711c83918)
  unreachable
bb30:
  br label %bb31
bb31:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/ast:VarDecl", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t102, ptr %t101)
  br label %bb32
bb32:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/ast:VarDecl", ptr %t104, i32 0, i32 3
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t111 = icmp sgt i64 %t109, 0
  br i1 %t111, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t113 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t113, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d208, i32 0, i32 1) })
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/ast:VarDecl", ptr %t116, i32 0, i32 3
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t115, { i64, ptr } %t119)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2funparse_2enoErrorsOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Sig", ptr %t16, i32 0, i32 2
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  store i1 %t21, ptr %l2, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_234a8883e8ade8b2_a53ba9ebf2e3f7c6)
  unreachable
bb11:
  %t23 = load i1, ptr %l2, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 52 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb7:
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 74 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l7, !tbaa !21
  br label %bb51
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 1
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb51
bb15:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb16, label %bb17
bb16:
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t41 = load i64, ptr %t40
  %t43 = icmp eq i64 %t41, 5
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb18, label %bb19
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l2, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t51)
  store i1 %t53, ptr %l30
  br label %bb21
bb21:
  %t54 = load i1, ptr %l30, !tbaa !21
  store i1 %t54, ptr %l7, !tbaa !21
  br label %bb51
bb22:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb23, label %bb24
bb23:
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb24
bb24:
  %t63 = load i1, ptr %l32, !tbaa !21
  br i1 %t63, label %bb25, label %bb26
bb25:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l3, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t70)
  store i1 %t72, ptr %l38
  br label %bb28
bb28:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l7, !tbaa !21
  br label %bb51
bb29:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb30, label %bb31
bb30:
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load i64, ptr %t78
  %t81 = icmp eq i64 %t79, 12
  store i1 %t81, ptr %l40, !tbaa !21
  br label %bb31
bb31:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb32, label %bb33
bb32:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t89)
  store i1 %t91, ptr %l46
  br label %bb35
bb35:
  %t92 = load i1, ptr %l46, !tbaa !21
  store i1 %t92, ptr %l7, !tbaa !21
  br label %bb51
bb36:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t94 = load ptr, ptr %l47, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb37, label %bb38
bb37:
  %t97 = load ptr, ptr %l47, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 15
  store i1 %t100, ptr %l48, !tbaa !21
  br label %bb38
bb38:
  %t101 = load i1, ptr %l48, !tbaa !21
  br i1 %t101, label %bb39, label %bb40
bb39:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l5, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t108)
  store i1 %t110, ptr %l54
  br label %bb42
bb42:
  %t111 = load i1, ptr %l54, !tbaa !21
  store i1 %t111, ptr %l7, !tbaa !21
  br label %bb51
bb43:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t113 = load ptr, ptr %l55, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb44, label %bb45
bb44:
  %t116 = load ptr, ptr %l55, !tbaa !29
  %t117 = load i64, ptr %t116
  %t119 = icmp eq i64 %t117, 16
  store i1 %t119, ptr %l56, !tbaa !21
  br label %bb45
bb45:
  %t120 = load i1, ptr %l56, !tbaa !21
  br i1 %t120, label %bb46, label %bb47
bb46:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l6, !tbaa !29
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t129 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t127)
  store i1 %t129, ptr %l62
  br label %bb49
bb49:
  %t130 = load i1, ptr %l62, !tbaa !21
  store i1 %t130, ptr %l7, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb51
bb51:
  %t131 = load i1, ptr %l7, !tbaa !21
  store i1 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/unparse:writer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store ptr %a2, ptr %l5, !tbaa !29
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v3)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t8, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = insertvalue %"compiler/unparse:writer" undef, ptr %t11, 0
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = insertvalue %"compiler/unparse:writer" %t12, { i64, ptr } %t13, 1
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t16 = insertvalue %"compiler/unparse:writer" %t14, ptr %t15, 2
  %t17 = load %"std/prelude/text:StringBuilder", ptr %l6
  %t18 = insertvalue %"compiler/unparse:writer" %t16, %"std/prelude/text:StringBuilder" %t17, 3
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = insertvalue %"compiler/unparse:writer" %t18, i64 %t19, 4
  %t22 = insertvalue %"compiler/unparse:writer" %t20, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, 5
  %t24 = insertvalue %"compiler/unparse:writer" %t22, i1 false, 6
  %t26 = insertvalue %"compiler/unparse:writer" %t24, i1 false, 7
  store %"compiler/unparse:writer" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/unparse:writer", ptr %rv
  ret %"compiler/unparse:writer" %rr
}

define dso_local void @olang_2einit_2ecompiler_2funparse() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2funparse_2eMaxIndent_2einit()
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"{ }" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d3 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" => " }>, align 8
declare void @__olang_check_failed(ptr)
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" catch" }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d13 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" default " }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d15 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d17 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" outlives " }>, align 8
@.d18 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d20 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@.d21 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d23 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" error" }>, align 8
@.d25 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" {" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d29 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"test " }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d31 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"link " }>, align 8
@.d32 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ?" }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d41 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" not in " }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" else " }>, align 8
@.d46 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" is not " }>, align 8
@.d47 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" is " }>, align 8
@.d48 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" is not " }>, align 8
@.d49 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" is " }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" as " }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d69 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d70 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d71 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d72 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d75 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d76 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d77 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"range " }>, align 8
@.d78 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"default" }>, align 8
@.d79 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d80 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"export " }>, align 8
@.d81 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d83 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d84 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d85 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"if " }>, align 8
@.d86 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" else" }>, align 8
@.d87 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d88 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"match " }>, align 8
@.d89 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" {" }>, align 8
@.d90 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"case " }>, align 8
@.d91 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d92 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d93 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d94 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"nomatch" }>, align 8
@.d95 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d96 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d98 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d99 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d101 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d102 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d103 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d104 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d105 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d106 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d108 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" noreturn" }>, align 8
@.d109 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d110 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d111 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" commutes" }>, align 8
@.d112 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" := " }>, align 8
@.d113 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d114 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d116 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d117 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d118 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d119 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d120 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d121 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d122 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d123 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d124 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d125 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d126 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"do " }>, align 8
@.d127 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d128 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d129 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d130 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"yield " }>, align 8
@.d131 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d132 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assert " }>, align 8
@.d133 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d134 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"error" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d136 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"spawn " }>, align 8
@.d137 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d138 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d139 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"join " }>, align 8
@.d140 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"errdefer " }>, align 8
@.d141 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"defer " }>, align 8
@.d142 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d143 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d144 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"if " }>, align 8
@.d145 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d146 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" else " }>, align 8
@.d147 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" else " }>, align 8
@.d148 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d149 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d150 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d151 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"(fn" }>, align 8
@.d152 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d153 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d154 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d155 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d156 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"any " }>, align 8
@.d157 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d158 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d159 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"own" }>, align 8
@.d160 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d161 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"mut" }>, align 8
@.d162 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d163 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"struct" }>, align 8
@.d164 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d165 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d166 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d167 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" destruct " }>, align 8
@.d168 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"enum " }>, align 8
@.d169 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d170 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d171 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d172 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d173 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d174 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d175 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d176 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"trait " }>, align 8
@.d177 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"extends " }>, align 8
@.d178 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d179 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d180 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d181 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d182 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d183 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d184 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d185 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d186 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d187 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d188 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d189 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"extern type " }>, align 8
@.d190 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d191 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" extends" }>, align 8
@.d192 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d193 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d194 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d195 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d196 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d197 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d198 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d199 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d200 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d201 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d202 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d203 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d204 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d205 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d206 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" := " }>, align 8
@.d207 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d208 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_6d411809e3c45284_6ddb613e25dacce8 = external constant [0 x i8]
@olang_loc_3b272a795e4745a2_9a90297686d0fdde = external constant [0 x i8]
@olang_loc_7f8607ca82c86e8f_41d7f7ff4057cd03 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
@olang_loc_577bb2401887ee03_bd83bee27b444ed7 = external constant [0 x i8]
@olang_loc_47b511f5ef6d9e74_baf04e552c3da2b8 = external constant [0 x i8]
@olang_loc_e6dde321a76d1169_ef8c066898e78ecd = external constant [0 x i8]
@olang_loc_af8532b2afdd02b1_ed9973e7a2ad66a5 = external constant [0 x i8]
@olang_loc_240300a98391f326_30555605a48ff2da = external constant [0 x i8]
@olang_loc_450b6e4c0e54f911_1dcad8b8a27ff01d = external constant [0 x i8]
@olang_loc_375b6e3c7dc4e00a_588d095da59240b6 = external constant [0 x i8]
@olang_loc_e1b6c554c381b10b_f727e5cc4e37ef67 = external constant [0 x i8]
@olang_loc_ba8e182b2fbe7a1c_99d493faf8d7cb48 = external constant [0 x i8]
@olang_loc_a676b6f90e9ab794_adfa384105d75b88 = external constant [0 x i8]
@olang_loc_8218e8270bec8206_ca247080b262927a = external constant [0 x i8]
@olang_loc_212921701ccd28fb_40c266614e32415f = external constant [0 x i8]
@olang_loc_a89566c82002a68c_50a6017df30325c0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_2301005a90ba30f7_2e0b8cd6b5bb3c83 = external constant [0 x i8]
@olang_loc_6385ebb2fa48e0d8_1e44ec8c8ca0ecf4 = external constant [0 x i8]
@olang_loc_19d95224243c5dd3_a108b37826b1917 = external constant [0 x i8]
@olang_loc_9c4378154f5f7dac_a032de2992525ef0 = external constant [0 x i8]
@olang_loc_b263a57856eac862_46b7b1031f9001a6 = external constant [0 x i8]
@olang_loc_9166140a1ac8280_ddd22134593fa34 = external constant [0 x i8]
@olang_loc_69b21e264e8a714a_b3e97d9d77526506 = external constant [0 x i8]
@olang_loc_8585d6fe8f316a51_b60a12ce50df87ed = external constant [0 x i8]
@olang_loc_eabe3ddcfaef285c_106dba970e52f8d8 = external constant [0 x i8]
@olang_loc_14b8182deed7e34b_cfe8cf3ea4c448f7 = external constant [0 x i8]
@olang_loc_9034b6aed20fb51a_d179ca40c5e654ce = external constant [0 x i8]
@olang_loc_8cd05a7785ffddf0_abfc69165374635c = external constant [0 x i8]
@olang_loc_c53cd7dd70350acf_d5f64367475d1e4b = external constant [0 x i8]
@olang_loc_565cf8a51c2b309e_2af0495fa70fac4a = external constant [0 x i8]
@olang_loc_a9c38de43eb77545_46c40237e7b6a551 = external constant [0 x i8]
@olang_loc_7b9eb6dfa833729b_791a1e6ae071d10f = external constant [0 x i8]
@olang_loc_5bab8da58715fcd0_e7391da9b8dff344 = external constant [0 x i8]
@olang_loc_b36b34168d540f92_3d8b83b8d4d4846 = external constant [0 x i8]
@olang_loc_45ada3313b7506a3_5e369560cd76ab37 = external constant [0 x i8]
@olang_loc_89b7cc3957ccbb94_42e76e0711c83918 = external constant [0 x i8]
@olang_loc_234a8883e8ade8b2_a53ba9ebf2e3f7c6 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
