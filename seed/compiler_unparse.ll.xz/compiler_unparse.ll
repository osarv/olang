; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/unparse:writer" = type { ptr, { i64, ptr }, ptr, %"std/prelude/text:StringBuilder", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
@G_2ecompiler_2funparse_2eMaxIndent = constant <{ [8 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00" }>, align 8
define dso_local { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/unparse:writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca %"compiler/unparse:writer"
  %l20 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %a1, { i64, ptr } %a2, ptr %a3)
  store %"compiler/unparse:writer" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/unparse:writer", ptr %l12
  store %"compiler/unparse:writer" %t8, ptr %l4
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %s0, ptr %v0, ptr %l4, ptr %t29)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l6, !tbaa !24
  br label %bb2
bb8:
  %t38 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 5
  %t40 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %v4, ptr %t38)
  store { i64, ptr } %t40, ptr %l28
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l30, !tbaa !24
  %t45 = mul i64 %t44, 8
  %t46 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l31, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l30, !tbaa !24
  %t54 = mul i64 %t53, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2funparse_2eMaxIndent_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 64, ptr @G_2ecompiler_2funparse_2eMaxIndent, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2funparse_2eUnparse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/unparse:writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca %"compiler/unparse:writer"
  %l20 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %a1, { i64, ptr } %a2, ptr %a3)
  store %"compiler/unparse:writer" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/unparse:writer", ptr %l12
  store %"compiler/unparse:writer" %t8, ptr %l4
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %s0, ptr %v0, ptr %l4, ptr %t29)
  br label %bb6
bb6:
  %t34 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t34, i8 10)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l6, !tbaa !24
  br label %bb2
bb9:
  %t40 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 3
  %t42 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %t40)
  store { i64, ptr } %t42, ptr %l29
  br label %bb10
bb10:
  %t43 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load i64, ptr %l31, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l12 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l35 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t7, { i64, ptr } { i64 3, ptr @.d0 })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 1, ptr @.d1 })
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l12, !tbaa !29
  %t12 = load ptr, ptr %l12, !tbaa !29
  %t13 = getelementptr %"compiler/unparse:writer", ptr %t12, i32 0, i32 4
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = add i64 %t14, 1
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = getelementptr %"compiler/unparse:writer", ptr %t18, i32 0, i32 4
  store i64 %t16, ptr %t19, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t20, i32 0, i32 6
  %t23 = load i1, ptr %t22, !tbaa !21
  store i1 %t23, ptr %l2, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/unparse:writer", ptr %t25, i32 0, i32 6
  store i1 false, ptr %t27, !tbaa !21
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t28, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l25, !tbaa !27
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l6, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t50)
  br label %bb10
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l4, !tbaa !24
  br label %bb6
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i1, ptr %l2, !tbaa !21
  %t64 = getelementptr %"compiler/unparse:writer", ptr %t60, i32 0, i32 6
  store i1 %t61, ptr %t64, !tbaa !21
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l35, !tbaa !29
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = getelementptr %"compiler/unparse:writer", ptr %t66, i32 0, i32 4
  %t68 = load i64, ptr %t67, !tbaa !24
  %t70 = sub i64 %t68, 1
  %t72 = load ptr, ptr %l35, !tbaa !29
  %t73 = getelementptr %"compiler/unparse:writer", ptr %t72, i32 0, i32 4
  store i64 %t70, ptr %t73, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t74)
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t76, { i64, ptr } { i64 1, ptr @.d2 })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l31 = alloca i1
  %l33 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr ptr, ptr %t9, i64 0
  %t11 = load ptr, ptr %t10, !tbaa !39
  %t13 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t11)
  store %"compiler/source:Span" %t13, ptr %l8
  br label %bb3
bb2:
  br label %bb24
bb3:
  %t14 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t19 = sub i64 %t17, 1
  store i64 %t19, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/unparse:writer", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l16, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i8, ptr %t32, i64 %t29
  %t34 = load i8, ptr %t33, !tbaa !32
  %t36 = icmp eq i8 %t34, 32
  br i1 %t36, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/unparse:writer", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp eq i8 %t47, 9
  store i1 %t49, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t51 = load i1, ptr %l20, !tbaa !21
  store i1 %t51, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t52 = load i1, ptr %l14, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = sub i64 %t55, 1
  store i64 %t57, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %bb4
bb15:
  %t59 = load i64, ptr %l2, !tbaa !24
  %t61 = icmp sge i64 %t59, 0
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/unparse:writer", ptr %t63, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l33, !tbaa !27
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 58
  store i1 %t74, ptr %l31, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t76 = load i1, ptr %l31, !tbaa !21
  br i1 %t76, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t77, { i64, ptr } { i64 2, ptr @.d3 })
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t80, ptr %l39, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr ptr, ptr %t82, i64 0
  %t84 = load ptr, ptr %t83, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t79, ptr %t84)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t87, { i64, ptr } { i64 1, ptr @.d4 })
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t89, { i64, ptr } %t90)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t7 = extractvalue { i64, ptr } zeroinitializer, 0
  %t8 = icmp eq i64 %t6, %t7
  %t9 = extractvalue { i64, ptr } %t4, 1
  %t10 = extractvalue { i64, ptr } zeroinitializer, 1
  %t11 = icmp eq ptr %t9, %t10
  %t12 = and i1 %t8, %t11
  br i1 %t12, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/unparse:writer", ptr %t14, i32 0, i32 2
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  %t24 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t17, i64 %t21)
  store i1 %t24, ptr %l10
  br label %bb3
bb3:
  %t25 = load i1, ptr %l10, !tbaa !21
  store i1 %t25, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t26 = load i1, ptr %l5, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/unparse:writer", ptr %t27, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l12, !tbaa !27
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Branch", ptr %t31, i32 0, i32 0
  %t34 = getelementptr %"compiler/source:Span", ptr %t33, i32 0, i32 0
  %t35 = load i32, ptr %t34, !tbaa !23
  %t37 = sext i32 %t35 to i64
  %t39 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t37
  %t42 = load i8, ptr %t41, !tbaa !32
  %t44 = icmp ne i8 %t42, 58
  br i1 %t44, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t46, { i64, ptr } { i64 1, ptr @.d5 })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Branch", ptr %t49, i32 0, i32 0
  %t52 = load %"compiler/source:Span", ptr %t51
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t48, %"compiler/source:Span" %t52)
  br label %bb11
bb11:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/unparse:writer", ptr %t55, i32 0, i32 5
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Branch", ptr %t58, i32 0, i32 0
  %t61 = load %"compiler/source:Span", ptr %t60
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t57, %"compiler/source:Span" %t61)
  br label %bb12
bb12:
  br label %ret
bb13:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Branch", ptr %t65, i32 0, i32 1
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t64, { i64, ptr } %t68)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 5
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp ne ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t8, { i64, ptr } { i64 4, ptr @.d6 })
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Case", ptr %t11, i32 0, i32 5
  %t14 = load ptr, ptr %t13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t10, ptr %t14)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t17, { i64, ptr } { i64 1, ptr @.d7 })
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Case", ptr %t20, i32 0, i32 4
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t19, { i64, ptr } %t23)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t23, { i64, ptr } { i64 6, ptr @.d8 })
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Catch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l10, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l34, !tbaa !29
  %t55 = icmp sgt i64 %t42, 0
  br i1 %t55, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 2, ptr @.d9 }, ptr %l37, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 1, ptr @.d10 }, ptr %l37, !tbaa !27
  br label %bb12
bb12:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t57, { i64, ptr } %t58)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t59, ptr %t60)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l7, !tbaa !24
  br label %bb6
bb16:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Catch", ptr %t67, i32 0, i32 2
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } zeroinitializer, 0
  %t74 = icmp eq i64 %t72, %t73
  %t75 = extractvalue { i64, ptr } %t70, 1
  %t76 = extractvalue { i64, ptr } zeroinitializer, 1
  %t77 = icmp eq ptr %t75, %t76
  %t78 = and i1 %t74, %t77
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t81 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t81, { i64, ptr } { i64 1, ptr @.d11 })
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l5, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Catch", ptr %t84, i32 0, i32 2
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t83, { i64, ptr } %t87)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/ast:Catch", ptr %t90, i32 0, i32 3
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = icmp sgt i64 %t95, 0
  br i1 %t97, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t99 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t99, { i64, ptr } { i64 9, ptr @.d12 })
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Catch", ptr %t102, i32 0, i32 3
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t101, { i64, ptr } %t105)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t108 = load i64, ptr %l3, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l3, !tbaa !24
  br label %bb1
bb28:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l82 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t2 = load ptr, ptr %l17, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l17, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l18, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb80
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t21 = load ptr, ptr %l25, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l25, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l26, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { ptr }, ptr %t31, i32 0, i32 0
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t35, { i64, ptr } { i64 10, ptr @.d13 })
  br label %bb13
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Func", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t37, i32 %t41)
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t44, ptr %t48)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb80
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l38, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 2
  store i1 %t58, ptr %l39, !tbaa !21
  br label %bb18
bb18:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", ptr }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l4, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  br label %bb22
bb22:
  br label %bb80
bb23:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t71 = load ptr, ptr %l46, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t74 = load ptr, ptr %l46, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 3
  store i1 %t77, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  %t78 = load i1, ptr %l47, !tbaa !21
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  br label %bb29
bb29:
  br label %bb80
bb30:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t90 = load ptr, ptr %l54, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb31, label %bb32
bb31:
  %t93 = load ptr, ptr %l54, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 4
  store i1 %t96, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l55, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t100, i32 0, i32 1
  %t102 = load i32, ptr %t101
  store i32 %t102, ptr %l6, !tbaa !23
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span" }, ptr %t106, i32 0, i32 2
  %t108 = load %"compiler/source:Span", ptr %t107
  store %"compiler/source:Span" %t108, ptr %l7
  br label %bb35
bb34:
  br label %bb43
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t110, { i64, ptr } { i64 7, ptr @.d14 })
  br label %bb36
bb36:
  %t112 = load i32, ptr %l6, !tbaa !23
  %t114 = icmp ne i32 %t112, 0
  br i1 %t114, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t116, i32 %t117)
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t120, { i64, ptr } { i64 1, ptr @.d15 })
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t122, %"compiler/source:Span" %t123)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb80
bb43:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb44, label %bb45
bb44:
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = load i64, ptr %t130
  %t133 = icmp eq i64 %t131, 5
  store i1 %t133, ptr %l71, !tbaa !21
  br label %bb45
bb45:
  %t134 = load i1, ptr %l71, !tbaa !21
  br i1 %t134, label %bb46, label %bb47
bb46:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, { i64, ptr } }, ptr %t137, i32 0, i32 1
  %t139 = load i32, ptr %t138
  store i32 %t139, ptr %l8, !tbaa !23
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [4 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, { i64, ptr } }, ptr %t143, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %t144
  store { i64, ptr } %t145, ptr %l9, !tbaa !27
  br label %bb48
bb47:
  br label %bb62
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t147, { i64, ptr } { i64 6, ptr @.d16 })
  br label %bb49
bb49:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t149, i32 %t150)
  br label %bb50
bb50:
  %t153 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t153, { i64, ptr } { i64 2, ptr @.d17 })
  br label %bb51
bb51:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l82, !tbaa !29
  %t156 = load ptr, ptr %l82, !tbaa !29
  %t157 = getelementptr %"compiler/unparse:writer", ptr %t156, i32 0, i32 4
  %t158 = load i64, ptr %t157, !tbaa !24
  %t160 = add i64 %t158, 1
  %t162 = load ptr, ptr %l82, !tbaa !29
  %t163 = getelementptr %"compiler/unparse:writer", ptr %t162, i32 0, i32 4
  store i64 %t160, ptr %t163, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t164, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  store i64 %t168, ptr %l12, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t170 = load i64, ptr %l11, !tbaa !24
  %t171 = load i64, ptr %l12, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb54:
  br label %bb55
bb55:
  %t178 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t178, ptr %l92, !tbaa !27
  %t179 = load i64, ptr %l11, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr i32, ptr %t182, i64 %t179
  %t184 = load i32, ptr %t183, !tbaa !33
  store i32 %t184, ptr %l13, !tbaa !23
  %t186 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t186)
  br label %bb56
bb56:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t188, i32 %t189)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb58:
  %t192 = load i64, ptr %l11, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l11, !tbaa !24
  br label %bb52
bb59:
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l100, !tbaa !29
  %t197 = load ptr, ptr %l100, !tbaa !29
  %t198 = getelementptr %"compiler/unparse:writer", ptr %t197, i32 0, i32 4
  %t199 = load i64, ptr %t198, !tbaa !24
  %t201 = sub i64 %t199, 1
  %t203 = load ptr, ptr %l100, !tbaa !29
  %t204 = getelementptr %"compiler/unparse:writer", ptr %t203, i32 0, i32 4
  store i64 %t201, ptr %t204, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t205)
  br label %bb60
bb60:
  %t207 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t207, { i64, ptr } { i64 1, ptr @.d18 })
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  br label %bb80
bb62:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t210 = load ptr, ptr %l105, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb63, label %bb64
bb63:
  %t213 = load ptr, ptr %l105, !tbaa !29
  %t214 = load i64, ptr %t213
  %t216 = icmp eq i64 %t214, 6
  store i1 %t216, ptr %l106, !tbaa !21
  br label %bb64
bb64:
  %t217 = load i1, ptr %l106, !tbaa !21
  br i1 %t217, label %bb65, label %bb66
bb65:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t220, i32 0, i32 1
  %t222 = load %"compiler/source:Span", ptr %t221
  store %"compiler/source:Span" %t222, ptr %l14
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t226, i32 0, i32 2
  %t228 = load { i64, ptr }, ptr %t227
  store { i64, ptr } %t228, ptr %l15, !tbaa !27
  br label %bb67
bb66:
  br label %bb72
bb67:
  store %olang.scope zeroinitializer, ptr %s11
  %t230 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t230, { i64, ptr } { i64 5, ptr @.d19 })
  br label %bb68
bb68:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l14
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t232, %"compiler/source:Span" %t233)
  br label %bb69
bb69:
  %t236 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t236, { i64, ptr } { i64 1, ptr @.d20 })
  br label %bb70
bb70:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t238, { i64, ptr } %t239)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb72:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t243 = load ptr, ptr %l119, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb73, label %bb74
bb73:
  %t246 = load ptr, ptr %l119, !tbaa !29
  %t247 = load i64, ptr %t246
  %t249 = icmp eq i64 %t247, 7
  store i1 %t249, ptr %l120, !tbaa !21
  br label %bb74
bb74:
  %t250 = load i1, ptr %l120, !tbaa !21
  br i1 %t250, label %bb75, label %bb76
bb75:
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l16, !tbaa !29
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  br label %bb78
bb78:
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb80:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t8, { i64, ptr } { i64 2, ptr @.d22 })
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Sig", ptr %t10, i32 0, i32 3
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb7:
  br label %bb8
bb8:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr ptr, ptr %t33, i64 %t30
  %t35 = load ptr, ptr %t34, !tbaa !39
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l23, !tbaa !29
  %t40 = icmp sgt i64 %t27, 0
  br i1 %t40, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 2, ptr @.d23 }, ptr %l26, !tbaa !27
  br label %bb11
bb10:
  store { i64, ptr } { i64 1, ptr @.d24 }, ptr %l26, !tbaa !27
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l23, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t42, { i64, ptr } %t43)
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb5
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l102 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l107 = alloca i32
  %l109 = alloca i1
  %l111 = alloca i32
  %l113 = alloca i32
  %l115 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i32
  %l119 = alloca i32
  %l121 = alloca i1
  %l122 = alloca i1
  %l124 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l138 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l142 = alloca i1
  %l154 = alloca ptr
  %l156 = alloca { i64, ptr }
  %l160 = alloca ptr
  %l161 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca i1
  %l188 = alloca { i64, ptr }
  %l194 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l206 = alloca ptr
  %l207 = alloca i1
  %l224 = alloca ptr
  %l225 = alloca i1
  %l236 = alloca ptr
  %l238 = alloca { i64, ptr }
  %l241 = alloca ptr
  %l242 = alloca i1
  %l253 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l258 = alloca ptr
  %l259 = alloca i1
  %l271 = alloca ptr
  %l272 = alloca i1
  %l285 = alloca ptr
  %l286 = alloca i1
  %l304 = alloca ptr
  %l305 = alloca i1
  %l318 = alloca ptr
  %l319 = alloca i1
  %l331 = alloca ptr
  %l332 = alloca i1
  %l345 = alloca ptr
  %l346 = alloca i1
  %l368 = alloca ptr
  %l369 = alloca i1
  %l382 = alloca ptr
  %l383 = alloca i1
  %l392 = alloca ptr
  %l393 = alloca i1
  %l428 = alloca ptr
  %l429 = alloca i1
  %l442 = alloca { i64, ptr }
  %l452 = alloca ptr
  %l453 = alloca i1
  %l462 = alloca ptr
  %l464 = alloca { i64, ptr }
  %l469 = alloca ptr
  %l470 = alloca i1
  %l488 = alloca ptr
  %l489 = alloca i1
  %l496 = alloca ptr
  %l497 = alloca i1
  %l505 = alloca ptr
  %l506 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t2 = load ptr, ptr %l63, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l63, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l64, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l64, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t16, i32 %t17)
  br label %bb6
bb6:
  br label %bb318
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t21 = load ptr, ptr %l71, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l71, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l72, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l72, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32 }, ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/source:Span", ptr %t32
  store %"compiler/source:Span" %t33, ptr %l3
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t35, %"compiler/source:Span" %t36)
  br label %bb13
bb13:
  br label %bb318
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t40 = load ptr, ptr %l79, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l79, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l80, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l80, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb23
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t54, { i64, ptr } { i64 1, ptr @.d25 })
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/unparse:writer", ptr %t56, i32 0, i32 6
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l5, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/unparse:writer", ptr %t61, i32 0, i32 6
  store i1 false, ptr %t63, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  br label %bb21
bb21:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i1, ptr %l5, !tbaa !21
  %t72 = getelementptr %"compiler/unparse:writer", ptr %t68, i32 0, i32 6
  store i1 %t69, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t73, { i64, ptr } { i64 1, ptr @.d26 })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb318
bb23:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t76 = load ptr, ptr %l94, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l94, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 3
  store i1 %t82, ptr %l95, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l95, !tbaa !21
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l6
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [5 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb50
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l102, !tbaa !29
  %t97 = load i32, ptr %l6
  %t99 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t97)
  store { i64, ptr } %t99, ptr %l104
  br label %bb29
bb29:
  %t100 = load ptr, ptr %l102, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l104, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t100, { i64, ptr } %t101)
  br label %bb30
bb30:
  %t102 = load i32, ptr %l6
  store i32 %t102, ptr %l105
  store i32 48, ptr %l107
  %t105 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l105, ptr %l107)
  store i1 %t105, ptr %l109
  br label %bb31
bb31:
  %t106 = load i1, ptr %l109, !tbaa !21
  br i1 %t106, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t107, { i64, ptr } { i64 1, ptr @.d27 })
  br label %bb34
bb33:
  %t109 = load i32, ptr %l6
  store i32 %t109, ptr %l111
  store i32 50, ptr %l113
  %t112 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l111, ptr %l113)
  store i1 %t112, ptr %l115
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb35:
  %t113 = load i1, ptr %l115, !tbaa !21
  br i1 %t113, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb39
bb37:
  %t114 = load i32, ptr %l6
  store i32 %t114, ptr %l117
  store i32 72, ptr %l119
  %t117 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l117, ptr %l119)
  store i1 %t117, ptr %l121
  br label %bb38
bb38:
  %t118 = load i1, ptr %l121, !tbaa !21
  store i1 %t118, ptr %l116, !tbaa !21
  br label %bb39
bb39:
  %t119 = load i1, ptr %l116, !tbaa !21
  br i1 %t119, label %bb40, label %bb41
bb40:
  %t120 = load ptr, ptr %l7, !tbaa !29
  %t122 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v1, ptr %t120)
  store i1 %t122, ptr %l124
  br label %bb42
bb41:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb43
bb42:
  %t123 = load i1, ptr %l124, !tbaa !21
  store i1 %t123, ptr %l122, !tbaa !21
  br label %bb43
bb43:
  %t124 = load i1, ptr %l122, !tbaa !21
  br i1 %t124, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t125 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t125, { i64, ptr } { i64 1, ptr @.d28 })
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t127, ptr %t128)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s4)
  br label %bb318
bb50:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t132 = load ptr, ptr %l128, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb51, label %bb52
bb51:
  %t135 = load ptr, ptr %l128, !tbaa !29
  %t136 = load i64, ptr %t135
  %t138 = icmp eq i64 %t136, 4
  store i1 %t138, ptr %l129, !tbaa !21
  br label %bb52
bb52:
  %t139 = load i1, ptr %l129, !tbaa !21
  br i1 %t139, label %bb53, label %bb54
bb53:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [5 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l8
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l9, !tbaa !29
  br label %bb55
bb54:
  br label %bb59
bb55:
  store %olang.scope zeroinitializer, ptr %s8
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t152, ptr %t153)
  br label %bb56
bb56:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l138, !tbaa !29
  %t157 = load i32, ptr %l8
  %t159 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t157)
  store { i64, ptr } %t159, ptr %l140
  br label %bb57
bb57:
  %t160 = load ptr, ptr %l138, !tbaa !29
  %t161 = load { i64, ptr }, ptr %l140, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t160, { i64, ptr } %t161)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s8)
  br label %bb318
bb59:
  %t162 = load ptr, ptr %l1, !tbaa !29
  store ptr %t162, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t163 = load ptr, ptr %l141, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb60, label %bb61
bb60:
  %t166 = load ptr, ptr %l141, !tbaa !29
  %t167 = load i64, ptr %t166
  %t169 = icmp eq i64 %t167, 5
  store i1 %t169, ptr %l142, !tbaa !21
  br label %bb61
bb61:
  %t170 = load i1, ptr %l142, !tbaa !21
  br i1 %t170, label %bb62, label %bb63
bb62:
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t173, i32 0, i32 1
  %t175 = load i32, ptr %t174
  store i32 %t175, ptr %l10
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t179, i32 0, i32 2
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l11, !tbaa !29
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t185, i32 0, i32 3
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l12, !tbaa !29
  br label %bb64
bb63:
  br label %bb71
bb64:
  store %olang.scope zeroinitializer, ptr %s9
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t189, ptr %t190)
  br label %bb65
bb65:
  %t193 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t193, { i64, ptr } { i64 1, ptr @.d29 })
  br label %bb66
bb66:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l154, !tbaa !29
  %t196 = load i32, ptr %l10
  %t198 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t196)
  store { i64, ptr } %t198, ptr %l156
  br label %bb67
bb67:
  %t199 = load ptr, ptr %l154, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l156, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t199, { i64, ptr } %t200)
  br label %bb68
bb68:
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t201, { i64, ptr } { i64 1, ptr @.d30 })
  br label %bb69
bb69:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t203, ptr %t204)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s9)
  br label %bb318
bb71:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t208 = load ptr, ptr %l160, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb72, label %bb73
bb72:
  %t211 = load ptr, ptr %l160, !tbaa !29
  %t212 = load i64, ptr %t211
  %t214 = icmp eq i64 %t212, 6
  store i1 %t214, ptr %l161, !tbaa !21
  br label %bb73
bb73:
  %t215 = load i1, ptr %l161, !tbaa !21
  br i1 %t215, label %bb74, label %bb75
bb74:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t218, i32 0, i32 1
  %t220 = load ptr, ptr %t219
  store ptr %t220, ptr %l13, !tbaa !29
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t224, i32 0, i32 2
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l14, !tbaa !29
  br label %bb76
bb75:
  br label %bb80
bb76:
  store %olang.scope zeroinitializer, ptr %s10
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t228, ptr %t229)
  br label %bb77
bb77:
  %t232 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t232, { i64, ptr } { i64 8, ptr @.d31 })
  br label %bb78
bb78:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t234, ptr %t235)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s10)
  br label %bb318
bb80:
  %t238 = load ptr, ptr %l1, !tbaa !29
  store ptr %t238, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t239 = load ptr, ptr %l173, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb81, label %bb82
bb81:
  %t242 = load ptr, ptr %l173, !tbaa !29
  %t243 = load i64, ptr %t242
  %t245 = icmp eq i64 %t243, 7
  store i1 %t245, ptr %l174, !tbaa !21
  br label %bb82
bb82:
  %t246 = load i1, ptr %l174, !tbaa !21
  br i1 %t246, label %bb83, label %bb84
bb83:
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t249 = getelementptr { i64, [5 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", ptr }, ptr %t249, i32 0, i32 1
  %t251 = load ptr, ptr %t250
  store ptr %t251, ptr %l15, !tbaa !29
  br label %bb85
bb84:
  br label %bb100
bb85:
  %t253 = load ptr, ptr %l15, !tbaa !29
  %t255 = getelementptr %"compiler/ast:Chain", ptr %t253, i32 0, i32 1
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  store { i64, ptr } %t256, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t258 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 0
  store i64 %t260, ptr %l18, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s13
  %t262 = load i64, ptr %l17, !tbaa !24
  %t263 = load i64, ptr %l18, !tbaa !24
  %t266 = icmp slt i64 %t262, %t263
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s13)
  br label %bb99
bb88:
  br label %bb89
bb89:
  %t270 = load i64, ptr %l17, !tbaa !24
  store i64 %t270, ptr %l19, !tbaa !24
  %t272 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t272, ptr %l188, !tbaa !27
  %t273 = load i64, ptr %l17, !tbaa !24
  %t275 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr ptr, ptr %t276, i64 %t273
  %t278 = load ptr, ptr %t277, !tbaa !39
  store ptr %t278, ptr %l20, !tbaa !29
  %t280 = load i64, ptr %l19, !tbaa !24
  %t282 = icmp sgt i64 %t280, 0
  br i1 %t282, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s14
  %t284 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t284, { i64, ptr } { i64 1, ptr @.d32 })
  br label %bb92
bb91:
  br label %bb96
bb92:
  %t286 = load ptr, ptr %l0, !tbaa !29
  store ptr %t286, ptr %l194, !tbaa !29
  %t287 = load ptr, ptr %l15, !tbaa !29
  %t289 = getelementptr %"compiler/ast:Chain", ptr %t287, i32 0, i32 0
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  store { i64, ptr } %t290, ptr %l196, !tbaa !27
  %t291 = load i64, ptr %l19, !tbaa !24
  %t293 = sub i64 %t291, 1
  %t295 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr i32, ptr %t296, i64 %t293
  %t298 = load i32, ptr %t297
  %t300 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s14, i32 %t298)
  store { i64, ptr } %t300, ptr %l200
  br label %bb93
bb93:
  %t301 = load ptr, ptr %l194, !tbaa !29
  %t302 = load { i64, ptr }, ptr %l200, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t301, { i64, ptr } %t302)
  br label %bb94
bb94:
  %t303 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t303, { i64, ptr } { i64 1, ptr @.d33 })
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s14)
  br label %bb96
bb96:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t305, ptr %t306)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s13)
  br label %bb98
bb98:
  %t309 = load i64, ptr %l17, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l17, !tbaa !24
  br label %bb86
bb99:
  br label %bb318
bb100:
  %t313 = load ptr, ptr %l1, !tbaa !29
  store ptr %t313, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t314 = load ptr, ptr %l206, !tbaa !29
  %t315 = icmp ne ptr %t314, null
  br i1 %t315, label %bb101, label %bb102
bb101:
  %t317 = load ptr, ptr %l206, !tbaa !29
  %t318 = load i64, ptr %t317
  %t320 = icmp eq i64 %t318, 8
  store i1 %t320, ptr %l207, !tbaa !21
  br label %bb102
bb102:
  %t321 = load i1, ptr %l207, !tbaa !21
  br i1 %t321, label %bb103, label %bb104
bb103:
  %t322 = load ptr, ptr %l1, !tbaa !29
  %t324 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 1
  %t325 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t324, i32 0, i32 1
  %t326 = load ptr, ptr %t325
  store ptr %t326, ptr %l21, !tbaa !29
  %t328 = load ptr, ptr %l1, !tbaa !29
  %t330 = getelementptr { i64, [5 x i64] }, ptr %t328, i32 0, i32 1
  %t331 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t330, i32 0, i32 2
  %t332 = load ptr, ptr %t331
  store ptr %t332, ptr %l22, !tbaa !29
  %t334 = load ptr, ptr %l1, !tbaa !29
  %t336 = getelementptr { i64, [5 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t336, i32 0, i32 3
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l23, !tbaa !29
  br label %bb105
bb104:
  br label %bb111
bb105:
  store %olang.scope zeroinitializer, ptr %s16
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t340, ptr %t341)
  br label %bb106
bb106:
  %t344 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t344, { i64, ptr } { i64 4, ptr @.d34 })
  br label %bb107
bb107:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t346, ptr %t347)
  br label %bb108
bb108:
  %t350 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t350, { i64, ptr } { i64 6, ptr @.d35 })
  br label %bb109
bb109:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t352, ptr %t353)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s16)
  br label %bb318
bb111:
  %t356 = load ptr, ptr %l1, !tbaa !29
  store ptr %t356, ptr %l224, !tbaa !29
  store i1 false, ptr %l225, !tbaa !21
  %t357 = load ptr, ptr %l224, !tbaa !29
  %t358 = icmp ne ptr %t357, null
  br i1 %t358, label %bb112, label %bb113
bb112:
  %t360 = load ptr, ptr %l224, !tbaa !29
  %t361 = load i64, ptr %t360
  %t363 = icmp eq i64 %t361, 9
  store i1 %t363, ptr %l225, !tbaa !21
  br label %bb113
bb113:
  %t364 = load i1, ptr %l225, !tbaa !21
  br i1 %t364, label %bb114, label %bb115
bb114:
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t367, i32 0, i32 1
  %t369 = load ptr, ptr %t368
  store ptr %t369, ptr %l24, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [5 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t373, i32 0, i32 2
  %t375 = load ptr, ptr %t374
  store ptr %t375, ptr %l25, !tbaa !29
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr { i64, [5 x i64] }, ptr %t377, i32 0, i32 1
  %t380 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t379, i32 0, i32 3
  %t381 = load i1, ptr %t380
  store i1 %t381, ptr %l26, !tbaa !21
  br label %bb116
bb115:
  br label %bb123
bb116:
  store %olang.scope zeroinitializer, ptr %s17
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t383, ptr %t384)
  br label %bb117
bb117:
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l236, !tbaa !29
  %t388 = load i1, ptr %l26, !tbaa !21
  br i1 %t388, label %bb118, label %bb119
bb118:
  store { i64, ptr } { i64 8, ptr @.d36 }, ptr %l238, !tbaa !27
  br label %bb120
bb119:
  store { i64, ptr } { i64 4, ptr @.d37 }, ptr %l238, !tbaa !27
  br label %bb120
bb120:
  %t390 = load ptr, ptr %l236, !tbaa !29
  %t391 = load { i64, ptr }, ptr %l238, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t390, { i64, ptr } %t391)
  br label %bb121
bb121:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t392, ptr %t393)
  br label %bb122
bb122:
  call void @__olang_scope_close(ptr %s17)
  br label %bb318
bb123:
  %t396 = load ptr, ptr %l1, !tbaa !29
  store ptr %t396, ptr %l241, !tbaa !29
  store i1 false, ptr %l242, !tbaa !21
  %t397 = load ptr, ptr %l241, !tbaa !29
  %t398 = icmp ne ptr %t397, null
  br i1 %t398, label %bb124, label %bb125
bb124:
  %t400 = load ptr, ptr %l241, !tbaa !29
  %t401 = load i64, ptr %t400
  %t403 = icmp eq i64 %t401, 10
  store i1 %t403, ptr %l242, !tbaa !21
  br label %bb125
bb125:
  %t404 = load i1, ptr %l242, !tbaa !21
  br i1 %t404, label %bb126, label %bb127
bb126:
  %t405 = load ptr, ptr %l1, !tbaa !29
  %t407 = getelementptr { i64, [5 x i64] }, ptr %t405, i32 0, i32 1
  %t408 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t407, i32 0, i32 1
  %t409 = load ptr, ptr %t408
  store ptr %t409, ptr %l27, !tbaa !29
  %t411 = load ptr, ptr %l1, !tbaa !29
  %t413 = getelementptr { i64, [5 x i64] }, ptr %t411, i32 0, i32 1
  %t414 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t413, i32 0, i32 2
  %t415 = load ptr, ptr %t414
  store ptr %t415, ptr %l28, !tbaa !29
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr { i64, [5 x i64] }, ptr %t417, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t419, i32 0, i32 3
  %t421 = load i1, ptr %t420
  store i1 %t421, ptr %l29, !tbaa !21
  br label %bb128
bb127:
  br label %bb135
bb128:
  store %olang.scope zeroinitializer, ptr %s18
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t423, ptr %t424)
  br label %bb129
bb129:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l253, !tbaa !29
  %t428 = load i1, ptr %l29, !tbaa !21
  br i1 %t428, label %bb130, label %bb131
bb130:
  store { i64, ptr } { i64 8, ptr @.d38 }, ptr %l255, !tbaa !27
  br label %bb132
bb131:
  store { i64, ptr } { i64 4, ptr @.d39 }, ptr %l255, !tbaa !27
  br label %bb132
bb132:
  %t430 = load ptr, ptr %l253, !tbaa !29
  %t431 = load { i64, ptr }, ptr %l255, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t430, { i64, ptr } %t431)
  br label %bb133
bb133:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t432, ptr %t433)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s18)
  br label %bb318
bb135:
  %t436 = load ptr, ptr %l1, !tbaa !29
  store ptr %t436, ptr %l258, !tbaa !29
  store i1 false, ptr %l259, !tbaa !21
  %t437 = load ptr, ptr %l258, !tbaa !29
  %t438 = icmp ne ptr %t437, null
  br i1 %t438, label %bb136, label %bb137
bb136:
  %t440 = load ptr, ptr %l258, !tbaa !29
  %t441 = load i64, ptr %t440
  %t443 = icmp eq i64 %t441, 11
  store i1 %t443, ptr %l259, !tbaa !21
  br label %bb137
bb137:
  %t444 = load i1, ptr %l259, !tbaa !21
  br i1 %t444, label %bb138, label %bb139
bb138:
  %t445 = load ptr, ptr %l1, !tbaa !29
  %t447 = getelementptr { i64, [5 x i64] }, ptr %t445, i32 0, i32 1
  %t448 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t447, i32 0, i32 1
  %t449 = load ptr, ptr %t448
  store ptr %t449, ptr %l30, !tbaa !29
  %t451 = load ptr, ptr %l1, !tbaa !29
  %t453 = getelementptr { i64, [5 x i64] }, ptr %t451, i32 0, i32 1
  %t454 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t453, i32 0, i32 2
  %t455 = load ptr, ptr %t454
  store ptr %t455, ptr %l31, !tbaa !29
  br label %bb140
bb139:
  br label %bb144
bb140:
  store %olang.scope zeroinitializer, ptr %s19
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t457, ptr %t458)
  br label %bb141
bb141:
  %t461 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t461, { i64, ptr } { i64 4, ptr @.d40 })
  br label %bb142
bb142:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t463, ptr %t464)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s19)
  br label %bb318
bb144:
  %t467 = load ptr, ptr %l1, !tbaa !29
  store ptr %t467, ptr %l271, !tbaa !29
  store i1 false, ptr %l272, !tbaa !21
  %t468 = load ptr, ptr %l271, !tbaa !29
  %t469 = icmp ne ptr %t468, null
  br i1 %t469, label %bb145, label %bb146
bb145:
  %t471 = load ptr, ptr %l271, !tbaa !29
  %t472 = load i64, ptr %t471
  %t474 = icmp eq i64 %t472, 12
  store i1 %t474, ptr %l272, !tbaa !21
  br label %bb146
bb146:
  %t475 = load i1, ptr %l272, !tbaa !21
  br i1 %t475, label %bb147, label %bb148
bb147:
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr { i64, [5 x i64] }, ptr %t476, i32 0, i32 1
  %t479 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t478, i32 0, i32 1
  %t480 = load ptr, ptr %t479
  store ptr %t480, ptr %l32, !tbaa !29
  %t482 = load ptr, ptr %l1, !tbaa !29
  %t484 = getelementptr { i64, [5 x i64] }, ptr %t482, i32 0, i32 1
  %t485 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t484, i32 0, i32 2
  %t486 = load { i64, ptr }, ptr %t485
  store { i64, ptr } %t486, ptr %l33, !tbaa !27
  br label %bb149
bb148:
  br label %bb154
bb149:
  store %olang.scope zeroinitializer, ptr %s20
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t488, ptr %t489)
  br label %bb150
bb150:
  %t492 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t492, { i64, ptr } { i64 1, ptr @.d41 })
  br label %bb151
bb151:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t494, { i64, ptr } %t495)
  br label %bb152
bb152:
  %t498 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t498, { i64, ptr } { i64 1, ptr @.d42 })
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s20)
  br label %bb318
bb154:
  %t500 = load ptr, ptr %l1, !tbaa !29
  store ptr %t500, ptr %l285, !tbaa !29
  store i1 false, ptr %l286, !tbaa !21
  %t501 = load ptr, ptr %l285, !tbaa !29
  %t502 = icmp ne ptr %t501, null
  br i1 %t502, label %bb155, label %bb156
bb155:
  %t504 = load ptr, ptr %l285, !tbaa !29
  %t505 = load i64, ptr %t504
  %t507 = icmp eq i64 %t505, 13
  store i1 %t507, ptr %l286, !tbaa !21
  br label %bb156
bb156:
  %t508 = load i1, ptr %l286, !tbaa !21
  br i1 %t508, label %bb157, label %bb158
bb157:
  %t509 = load ptr, ptr %l1, !tbaa !29
  %t511 = getelementptr { i64, [5 x i64] }, ptr %t509, i32 0, i32 1
  %t512 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t511, i32 0, i32 1
  %t513 = load ptr, ptr %t512
  store ptr %t513, ptr %l34, !tbaa !29
  %t515 = load ptr, ptr %l1, !tbaa !29
  %t517 = getelementptr { i64, [5 x i64] }, ptr %t515, i32 0, i32 1
  %t518 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t517, i32 0, i32 2
  %t519 = load i32, ptr %t518
  store i32 %t519, ptr %l35, !tbaa !23
  %t521 = load ptr, ptr %l1, !tbaa !29
  %t523 = getelementptr { i64, [5 x i64] }, ptr %t521, i32 0, i32 1
  %t524 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t523, i32 0, i32 3
  %t525 = load { i64, ptr }, ptr %t524
  store { i64, ptr } %t525, ptr %l36, !tbaa !27
  br label %bb159
bb158:
  br label %bb166
bb159:
  store %olang.scope zeroinitializer, ptr %s21
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t527, ptr %t528)
  br label %bb160
bb160:
  %t531 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t531, { i64, ptr } { i64 1, ptr @.d43 })
  br label %bb161
bb161:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load i32, ptr %l35, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t533, i32 %t534)
  br label %bb162
bb162:
  %t537 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t537, { i64, ptr } { i64 1, ptr @.d44 })
  br label %bb163
bb163:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t539, { i64, ptr } %t540)
  br label %bb164
bb164:
  %t543 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t543, { i64, ptr } { i64 1, ptr @.d45 })
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s21)
  br label %bb318
bb166:
  %t545 = load ptr, ptr %l1, !tbaa !29
  store ptr %t545, ptr %l304, !tbaa !29
  store i1 false, ptr %l305, !tbaa !21
  %t546 = load ptr, ptr %l304, !tbaa !29
  %t547 = icmp ne ptr %t546, null
  br i1 %t547, label %bb167, label %bb168
bb167:
  %t549 = load ptr, ptr %l304, !tbaa !29
  %t550 = load i64, ptr %t549
  %t552 = icmp eq i64 %t550, 14
  store i1 %t552, ptr %l305, !tbaa !21
  br label %bb168
bb168:
  %t553 = load i1, ptr %l305, !tbaa !21
  br i1 %t553, label %bb169, label %bb170
bb169:
  %t554 = load ptr, ptr %l1, !tbaa !29
  %t556 = getelementptr { i64, [5 x i64] }, ptr %t554, i32 0, i32 1
  %t557 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t556, i32 0, i32 1
  %t558 = load ptr, ptr %t557
  store ptr %t558, ptr %l37, !tbaa !29
  %t560 = load ptr, ptr %l1, !tbaa !29
  %t562 = getelementptr { i64, [5 x i64] }, ptr %t560, i32 0, i32 1
  %t563 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t562, i32 0, i32 2
  %t564 = load { i64, ptr }, ptr %t563
  store { i64, ptr } %t564, ptr %l38, !tbaa !27
  br label %bb171
bb170:
  br label %bb176
bb171:
  store %olang.scope zeroinitializer, ptr %s22
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t566, ptr %t567)
  br label %bb172
bb172:
  %t570 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t570, { i64, ptr } { i64 1, ptr @.d46 })
  br label %bb173
bb173:
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t573 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t572, { i64, ptr } %t573)
  br label %bb174
bb174:
  %t576 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t576, { i64, ptr } { i64 1, ptr @.d47 })
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s22)
  br label %bb318
bb176:
  %t578 = load ptr, ptr %l1, !tbaa !29
  store ptr %t578, ptr %l318, !tbaa !29
  store i1 false, ptr %l319, !tbaa !21
  %t579 = load ptr, ptr %l318, !tbaa !29
  %t580 = icmp ne ptr %t579, null
  br i1 %t580, label %bb177, label %bb178
bb177:
  %t582 = load ptr, ptr %l318, !tbaa !29
  %t583 = load i64, ptr %t582
  %t585 = icmp eq i64 %t583, 15
  store i1 %t585, ptr %l319, !tbaa !21
  br label %bb178
bb178:
  %t586 = load i1, ptr %l319, !tbaa !21
  br i1 %t586, label %bb179, label %bb180
bb179:
  %t587 = load ptr, ptr %l1, !tbaa !29
  %t589 = getelementptr { i64, [5 x i64] }, ptr %t587, i32 0, i32 1
  %t590 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t589, i32 0, i32 1
  %t591 = load ptr, ptr %t590
  store ptr %t591, ptr %l39, !tbaa !29
  %t593 = load ptr, ptr %l1, !tbaa !29
  %t595 = getelementptr { i64, [5 x i64] }, ptr %t593, i32 0, i32 1
  %t596 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t595, i32 0, i32 2
  %t597 = load i32, ptr %t596
  store i32 %t597, ptr %l40, !tbaa !23
  br label %bb181
bb180:
  br label %bb185
bb181:
  store %olang.scope zeroinitializer, ptr %s23
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t600 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t599, ptr %t600)
  br label %bb182
bb182:
  %t603 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t603, { i64, ptr } { i64 1, ptr @.d48 })
  br label %bb183
bb183:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load i32, ptr %l40, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t605, i32 %t606)
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s23)
  br label %bb318
bb185:
  %t609 = load ptr, ptr %l1, !tbaa !29
  store ptr %t609, ptr %l331, !tbaa !29
  store i1 false, ptr %l332, !tbaa !21
  %t610 = load ptr, ptr %l331, !tbaa !29
  %t611 = icmp ne ptr %t610, null
  br i1 %t611, label %bb186, label %bb187
bb186:
  %t613 = load ptr, ptr %l331, !tbaa !29
  %t614 = load i64, ptr %t613
  %t616 = icmp eq i64 %t614, 16
  store i1 %t616, ptr %l332, !tbaa !21
  br label %bb187
bb187:
  %t617 = load i1, ptr %l332, !tbaa !21
  br i1 %t617, label %bb188, label %bb189
bb188:
  %t618 = load ptr, ptr %l1, !tbaa !29
  %t620 = getelementptr { i64, [5 x i64] }, ptr %t618, i32 0, i32 1
  %t621 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t620, i32 0, i32 1
  %t622 = load ptr, ptr %t621
  store ptr %t622, ptr %l41, !tbaa !29
  %t624 = load ptr, ptr %l1, !tbaa !29
  %t626 = getelementptr { i64, [5 x i64] }, ptr %t624, i32 0, i32 1
  %t627 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t626, i32 0, i32 2
  %t628 = load { i64, ptr }, ptr %t627
  store { i64, ptr } %t628, ptr %l42, !tbaa !27
  br label %bb190
bb189:
  br label %bb195
bb190:
  store %olang.scope zeroinitializer, ptr %s24
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t631 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t630, ptr %t631)
  br label %bb191
bb191:
  %t634 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t634, { i64, ptr } { i64 1, ptr @.d49 })
  br label %bb192
bb192:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t637 = load { i64, ptr }, ptr %l42, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t636, { i64, ptr } %t637)
  br label %bb193
bb193:
  %t640 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t640, { i64, ptr } { i64 1, ptr @.d50 })
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s24)
  br label %bb318
bb195:
  %t642 = load ptr, ptr %l1, !tbaa !29
  store ptr %t642, ptr %l345, !tbaa !29
  store i1 false, ptr %l346, !tbaa !21
  %t643 = load ptr, ptr %l345, !tbaa !29
  %t644 = icmp ne ptr %t643, null
  br i1 %t644, label %bb196, label %bb197
bb196:
  %t646 = load ptr, ptr %l345, !tbaa !29
  %t647 = load i64, ptr %t646
  %t649 = icmp eq i64 %t647, 17
  store i1 %t649, ptr %l346, !tbaa !21
  br label %bb197
bb197:
  %t650 = load i1, ptr %l346, !tbaa !21
  br i1 %t650, label %bb198, label %bb199
bb198:
  %t651 = load ptr, ptr %l1, !tbaa !29
  %t653 = getelementptr { i64, [5 x i64] }, ptr %t651, i32 0, i32 1
  %t654 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t653, i32 0, i32 1
  %t655 = load ptr, ptr %t654
  store ptr %t655, ptr %l43, !tbaa !29
  %t657 = load ptr, ptr %l1, !tbaa !29
  %t659 = getelementptr { i64, [5 x i64] }, ptr %t657, i32 0, i32 1
  %t660 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t659, i32 0, i32 2
  %t661 = load ptr, ptr %t660
  store ptr %t661, ptr %l44, !tbaa !29
  %t663 = load ptr, ptr %l1, !tbaa !29
  %t665 = getelementptr { i64, [5 x i64] }, ptr %t663, i32 0, i32 1
  %t666 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t665, i32 0, i32 3
  %t667 = load ptr, ptr %t666
  store ptr %t667, ptr %l45, !tbaa !29
  br label %bb200
bb199:
  br label %bb213
bb200:
  store %olang.scope zeroinitializer, ptr %s25
  %t669 = load ptr, ptr %l0, !tbaa !29
  %t670 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t669, ptr %t670)
  br label %bb201
bb201:
  %t673 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t673, { i64, ptr } { i64 1, ptr @.d51 })
  br label %bb202
bb202:
  %t675 = load ptr, ptr %l44, !tbaa !29
  %t677 = icmp ne ptr %t675, null
  br i1 %t677, label %bb203, label %bb204
bb203:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t679, ptr %t680)
  br label %bb205
bb204:
  br label %bb206
bb205:
  br label %bb206
bb206:
  %t683 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t683, { i64, ptr } { i64 1, ptr @.d52 })
  br label %bb207
bb207:
  %t685 = load ptr, ptr %l45, !tbaa !29
  %t687 = icmp ne ptr %t685, null
  br i1 %t687, label %bb208, label %bb209
bb208:
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t690 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t689, ptr %t690)
  br label %bb210
bb209:
  br label %bb211
bb210:
  br label %bb211
bb211:
  %t693 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t693, { i64, ptr } { i64 1, ptr @.d53 })
  br label %bb212
bb212:
  call void @__olang_scope_close(ptr %s25)
  br label %bb318
bb213:
  %t695 = load ptr, ptr %l1, !tbaa !29
  store ptr %t695, ptr %l368, !tbaa !29
  store i1 false, ptr %l369, !tbaa !21
  %t696 = load ptr, ptr %l368, !tbaa !29
  %t697 = icmp ne ptr %t696, null
  br i1 %t697, label %bb214, label %bb215
bb214:
  %t699 = load ptr, ptr %l368, !tbaa !29
  %t700 = load i64, ptr %t699
  %t702 = icmp eq i64 %t700, 18
  store i1 %t702, ptr %l369, !tbaa !21
  br label %bb215
bb215:
  %t703 = load i1, ptr %l369, !tbaa !21
  br i1 %t703, label %bb216, label %bb217
bb216:
  %t704 = load ptr, ptr %l1, !tbaa !29
  %t706 = getelementptr { i64, [5 x i64] }, ptr %t704, i32 0, i32 1
  %t707 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t706, i32 0, i32 1
  %t708 = load ptr, ptr %t707
  store ptr %t708, ptr %l46, !tbaa !29
  %t710 = load ptr, ptr %l1, !tbaa !29
  %t712 = getelementptr { i64, [5 x i64] }, ptr %t710, i32 0, i32 1
  %t713 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t712, i32 0, i32 2
  %t714 = load { i64, ptr }, ptr %t713
  store { i64, ptr } %t714, ptr %l47, !tbaa !27
  br label %bb218
bb217:
  br label %bb223
bb218:
  store %olang.scope zeroinitializer, ptr %s28
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = load ptr, ptr %l46, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t716, ptr %t717)
  br label %bb219
bb219:
  %t720 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t720, { i64, ptr } { i64 1, ptr @.d54 })
  br label %bb220
bb220:
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t723 = load { i64, ptr }, ptr %l47, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t722, { i64, ptr } %t723)
  br label %bb221
bb221:
  %t726 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t726, { i64, ptr } { i64 1, ptr @.d55 })
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s28)
  br label %bb318
bb223:
  %t728 = load ptr, ptr %l1, !tbaa !29
  store ptr %t728, ptr %l382, !tbaa !29
  store i1 false, ptr %l383, !tbaa !21
  %t729 = load ptr, ptr %l382, !tbaa !29
  %t730 = icmp ne ptr %t729, null
  br i1 %t730, label %bb224, label %bb225
bb224:
  %t732 = load ptr, ptr %l382, !tbaa !29
  %t733 = load i64, ptr %t732
  %t735 = icmp eq i64 %t733, 19
  store i1 %t735, ptr %l383, !tbaa !21
  br label %bb225
bb225:
  %t736 = load i1, ptr %l383, !tbaa !21
  br i1 %t736, label %bb226, label %bb227
bb226:
  %t737 = load ptr, ptr %l1, !tbaa !29
  %t739 = getelementptr { i64, [5 x i64] }, ptr %t737, i32 0, i32 1
  %t740 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t739, i32 0, i32 1
  %t741 = load { i64, ptr }, ptr %t740
  store { i64, ptr } %t741, ptr %l48, !tbaa !27
  br label %bb228
bb227:
  br label %bb232
bb228:
  store %olang.scope zeroinitializer, ptr %s29
  %t743 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t743, { i64, ptr } { i64 1, ptr @.d56 })
  br label %bb229
bb229:
  %t745 = load ptr, ptr %l0, !tbaa !29
  %t746 = load { i64, ptr }, ptr %l48, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t745, { i64, ptr } %t746)
  br label %bb230
bb230:
  %t749 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t749, { i64, ptr } { i64 1, ptr @.d57 })
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s29)
  br label %bb318
bb232:
  %t751 = load ptr, ptr %l1, !tbaa !29
  store ptr %t751, ptr %l392, !tbaa !29
  store i1 false, ptr %l393, !tbaa !21
  %t752 = load ptr, ptr %l392, !tbaa !29
  %t753 = icmp ne ptr %t752, null
  br i1 %t753, label %bb233, label %bb234
bb233:
  %t755 = load ptr, ptr %l392, !tbaa !29
  %t756 = load i64, ptr %t755
  %t758 = icmp eq i64 %t756, 20
  store i1 %t758, ptr %l393, !tbaa !21
  br label %bb234
bb234:
  %t759 = load i1, ptr %l393, !tbaa !21
  br i1 %t759, label %bb235, label %bb236
bb235:
  %t760 = load ptr, ptr %l1, !tbaa !29
  %t762 = getelementptr { i64, [5 x i64] }, ptr %t760, i32 0, i32 1
  %t763 = getelementptr { %"compiler/source:Span", ptr }, ptr %t762, i32 0, i32 1
  %t764 = load ptr, ptr %t763
  store ptr %t764, ptr %l49, !tbaa !29
  br label %bb237
bb236:
  br label %bb256
bb237:
  store %olang.scope zeroinitializer, ptr %s30
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load ptr, ptr %l49, !tbaa !29
  %t769 = getelementptr %"compiler/ast:Compr", ptr %t767, i32 0, i32 0
  %t770 = load ptr, ptr %t769, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t766, ptr %t770)
  br label %bb238
bb238:
  %t773 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t773, { i64, ptr } { i64 1, ptr @.d58 })
  br label %bb239
bb239:
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t776 = load ptr, ptr %l49, !tbaa !29
  %t778 = getelementptr %"compiler/ast:Compr", ptr %t776, i32 0, i32 1
  %t779 = load ptr, ptr %t778, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t775, ptr %t779)
  br label %bb240
bb240:
  %t782 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t782, { i64, ptr } { i64 5, ptr @.d59 })
  br label %bb241
bb241:
  %t784 = load ptr, ptr %l49, !tbaa !29
  %t786 = getelementptr %"compiler/ast:Compr", ptr %t784, i32 0, i32 2
  %t787 = load i32, ptr %t786, !tbaa !23
  %t789 = icmp ne i32 %t787, 0
  br i1 %t789, label %bb242, label %bb243
bb242:
  store %olang.scope zeroinitializer, ptr %s31
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t792 = load ptr, ptr %l49, !tbaa !29
  %t794 = getelementptr %"compiler/ast:Compr", ptr %t792, i32 0, i32 2
  %t795 = load i32, ptr %t794, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t791, i32 %t795)
  br label %bb244
bb243:
  br label %bb246
bb244:
  %t798 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t798, { i64, ptr } { i64 2, ptr @.d60 })
  br label %bb245
bb245:
  call void @__olang_scope_close(ptr %s31)
  br label %bb246
bb246:
  %t800 = load ptr, ptr %l0, !tbaa !29
  %t801 = load ptr, ptr %l49, !tbaa !29
  %t803 = getelementptr %"compiler/ast:Compr", ptr %t801, i32 0, i32 3
  %t804 = load i32, ptr %t803, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t800, i32 %t804)
  br label %bb247
bb247:
  %t807 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t807, { i64, ptr } { i64 4, ptr @.d61 })
  br label %bb248
bb248:
  %t809 = load ptr, ptr %l0, !tbaa !29
  %t810 = load ptr, ptr %l49, !tbaa !29
  %t812 = getelementptr %"compiler/ast:Compr", ptr %t810, i32 0, i32 4
  %t813 = load ptr, ptr %t812, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t809, ptr %t813)
  br label %bb249
bb249:
  %t816 = load ptr, ptr %l49, !tbaa !29
  %t818 = getelementptr %"compiler/ast:Compr", ptr %t816, i32 0, i32 5
  %t819 = load ptr, ptr %t818, !tbaa !29
  %t821 = icmp ne ptr %t819, null
  br i1 %t821, label %bb250, label %bb251
bb250:
  store %olang.scope zeroinitializer, ptr %s32
  %t823 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s32, ptr %t823, { i64, ptr } { i64 4, ptr @.d62 })
  br label %bb252
bb251:
  br label %bb254
bb252:
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t826 = load ptr, ptr %l49, !tbaa !29
  %t828 = getelementptr %"compiler/ast:Compr", ptr %t826, i32 0, i32 5
  %t829 = load ptr, ptr %t828, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t825, ptr %t829)
  br label %bb253
bb253:
  call void @__olang_scope_close(ptr %s32)
  br label %bb254
bb254:
  %t832 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t832, { i64, ptr } { i64 1, ptr @.d63 })
  br label %bb255
bb255:
  call void @__olang_scope_close(ptr %s30)
  br label %bb318
bb256:
  %t834 = load ptr, ptr %l1, !tbaa !29
  store ptr %t834, ptr %l428, !tbaa !29
  store i1 false, ptr %l429, !tbaa !21
  %t835 = load ptr, ptr %l428, !tbaa !29
  %t836 = icmp ne ptr %t835, null
  br i1 %t836, label %bb257, label %bb258
bb257:
  %t838 = load ptr, ptr %l428, !tbaa !29
  %t839 = load i64, ptr %t838
  %t841 = icmp eq i64 %t839, 21
  store i1 %t841, ptr %l429, !tbaa !21
  br label %bb258
bb258:
  %t842 = load i1, ptr %l429, !tbaa !21
  br i1 %t842, label %bb259, label %bb260
bb259:
  %t843 = load ptr, ptr %l1, !tbaa !29
  %t845 = getelementptr { i64, [5 x i64] }, ptr %t843, i32 0, i32 1
  %t846 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t845, i32 0, i32 1
  %t847 = load { i64, ptr }, ptr %t846
  store { i64, ptr } %t847, ptr %l50, !tbaa !27
  br label %bb261
bb260:
  br label %bb273
bb261:
  %t849 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t849, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t851 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t853 = extractvalue { i64, ptr } %t851, 0
  store i64 %t853, ptr %l53, !tbaa !24
  br label %bb262
bb262:
  store %olang.scope zeroinitializer, ptr %s35
  %t855 = load i64, ptr %l52, !tbaa !24
  %t856 = load i64, ptr %l53, !tbaa !24
  %t859 = icmp slt i64 %t855, %t856
  %t861 = xor i1 %t859, true
  br i1 %t861, label %bb263, label %bb264
bb263:
  call void @__olang_scope_close(ptr %s35)
  br label %bb272
bb264:
  br label %bb265
bb265:
  %t863 = load i64, ptr %l52, !tbaa !24
  %t865 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t865, ptr %l442, !tbaa !27
  %t866 = load i64, ptr %l52, !tbaa !24
  %t868 = getelementptr { i64, ptr }, ptr %l442, i32 0, i32 1
  %t869 = load ptr, ptr %t868, !tbaa !27
  %t870 = getelementptr ptr, ptr %t869, i64 %t866
  %t871 = load ptr, ptr %t870, !tbaa !39
  store ptr %t871, ptr %l55, !tbaa !29
  %t875 = icmp sgt i64 %t863, 0
  br i1 %t875, label %bb266, label %bb267
bb266:
  store %olang.scope zeroinitializer, ptr %s36
  %t877 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s36, ptr %t877, { i64, ptr } { i64 1, ptr @.d64 })
  br label %bb268
bb267:
  br label %bb269
bb268:
  call void @__olang_scope_close(ptr %s36)
  br label %bb269
bb269:
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t880 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t879, ptr %t880)
  br label %bb270
bb270:
  call void @__olang_scope_close(ptr %s35)
  br label %bb271
bb271:
  %t883 = load i64, ptr %l52, !tbaa !24
  %t885 = add i64 %t883, 1
  store i64 %t885, ptr %l52, !tbaa !24
  br label %bb262
bb272:
  br label %bb318
bb273:
  %t887 = load ptr, ptr %l1, !tbaa !29
  store ptr %t887, ptr %l452, !tbaa !29
  store i1 false, ptr %l453, !tbaa !21
  %t888 = load ptr, ptr %l452, !tbaa !29
  %t889 = icmp ne ptr %t888, null
  br i1 %t889, label %bb274, label %bb275
bb274:
  %t891 = load ptr, ptr %l452, !tbaa !29
  %t892 = load i64, ptr %t891
  %t894 = icmp eq i64 %t892, 22
  store i1 %t894, ptr %l453, !tbaa !21
  br label %bb275
bb275:
  %t895 = load i1, ptr %l453, !tbaa !21
  br i1 %t895, label %bb276, label %bb277
bb276:
  %t896 = load ptr, ptr %l1, !tbaa !29
  %t898 = getelementptr { i64, [5 x i64] }, ptr %t896, i32 0, i32 1
  %t899 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t898, i32 0, i32 1
  %t900 = load ptr, ptr %t899
  store ptr %t900, ptr %l56, !tbaa !29
  %t902 = load ptr, ptr %l1, !tbaa !29
  %t904 = getelementptr { i64, [5 x i64] }, ptr %t902, i32 0, i32 1
  %t905 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t904, i32 0, i32 2
  %t906 = load { i64, ptr }, ptr %t905
  store { i64, ptr } %t906, ptr %l57, !tbaa !27
  %t908 = load ptr, ptr %l1, !tbaa !29
  %t910 = getelementptr { i64, [5 x i64] }, ptr %t908, i32 0, i32 1
  %t911 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t910, i32 0, i32 3
  %t912 = load i1, ptr %t911
  store i1 %t912, ptr %l58, !tbaa !21
  br label %bb278
bb277:
  br label %bb285
bb278:
  store %olang.scope zeroinitializer, ptr %s38
  %t914 = load ptr, ptr %l0, !tbaa !29
  store ptr %t914, ptr %l462, !tbaa !29
  %t915 = load i1, ptr %l58, !tbaa !21
  br i1 %t915, label %bb279, label %bb280
bb279:
  store { i64, ptr } { i64 8, ptr @.d65 }, ptr %l464, !tbaa !27
  br label %bb281
bb280:
  store { i64, ptr } { i64 4, ptr @.d66 }, ptr %l464, !tbaa !27
  br label %bb281
bb281:
  %t917 = load ptr, ptr %l462, !tbaa !29
  %t918 = load { i64, ptr }, ptr %l464, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s38, ptr %t917, { i64, ptr } %t918)
  br label %bb282
bb282:
  %t919 = load ptr, ptr %l0, !tbaa !29
  %t920 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t919, ptr %t920)
  br label %bb283
bb283:
  %t923 = load ptr, ptr %l0, !tbaa !29
  %t924 = load { i64, ptr }, ptr %l57, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t923, { i64, ptr } %t924)
  br label %bb284
bb284:
  call void @__olang_scope_close(ptr %s38)
  br label %bb318
bb285:
  %t927 = load ptr, ptr %l1, !tbaa !29
  store ptr %t927, ptr %l469, !tbaa !29
  store i1 false, ptr %l470, !tbaa !21
  %t928 = load ptr, ptr %l469, !tbaa !29
  %t929 = icmp ne ptr %t928, null
  br i1 %t929, label %bb286, label %bb287
bb286:
  %t931 = load ptr, ptr %l469, !tbaa !29
  %t932 = load i64, ptr %t931
  %t934 = icmp eq i64 %t932, 23
  store i1 %t934, ptr %l470, !tbaa !21
  br label %bb287
bb287:
  %t935 = load i1, ptr %l470, !tbaa !21
  br i1 %t935, label %bb288, label %bb289
bb288:
  %t936 = load ptr, ptr %l1, !tbaa !29
  %t938 = getelementptr { i64, [5 x i64] }, ptr %t936, i32 0, i32 1
  %t939 = getelementptr { %"compiler/source:Span", ptr }, ptr %t938, i32 0, i32 1
  %t940 = load ptr, ptr %t939
  store ptr %t940, ptr %l59, !tbaa !29
  br label %bb290
bb289:
  br label %bb295
bb290:
  store %olang.scope zeroinitializer, ptr %s39
  %t942 = load ptr, ptr %l0, !tbaa !29
  %t944 = getelementptr %"compiler/unparse:writer", ptr %t942, i32 0, i32 6
  %t945 = load i1, ptr %t944, !tbaa !21
  store i1 %t945, ptr %l60, !tbaa !21
  %t947 = load ptr, ptr %l0, !tbaa !29
  %t949 = getelementptr %"compiler/unparse:writer", ptr %t947, i32 0, i32 6
  store i1 false, ptr %t949, !tbaa !21
  %t950 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s39, ptr %t950, { i64, ptr } { i64 2, ptr @.d67 })
  br label %bb291
bb291:
  %t952 = load ptr, ptr %l0, !tbaa !29
  %t953 = load ptr, ptr %l59, !tbaa !29
  %t955 = getelementptr %"compiler/ast:Func", ptr %t953, i32 0, i32 3
  %t956 = load ptr, ptr %t955, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t952, ptr %t956)
  br label %bb292
bb292:
  %t959 = load ptr, ptr %l0, !tbaa !29
  %t960 = load i1, ptr %l60, !tbaa !21
  %t963 = getelementptr %"compiler/unparse:writer", ptr %t959, i32 0, i32 6
  store i1 %t960, ptr %t963, !tbaa !21
  %t964 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s39, ptr %t964, { i64, ptr } { i64 1, ptr @.d68 })
  br label %bb293
bb293:
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t967 = load ptr, ptr %l59, !tbaa !29
  %t969 = getelementptr %"compiler/ast:Func", ptr %t967, i32 0, i32 4
  %t970 = load { i64, ptr }, ptr %t969, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t966, { i64, ptr } %t970)
  br label %bb294
bb294:
  call void @__olang_scope_close(ptr %s39)
  br label %bb318
bb295:
  %t973 = load ptr, ptr %l1, !tbaa !29
  store ptr %t973, ptr %l488, !tbaa !29
  store i1 false, ptr %l489, !tbaa !21
  %t974 = load ptr, ptr %l488, !tbaa !29
  %t975 = icmp ne ptr %t974, null
  br i1 %t975, label %bb296, label %bb297
bb296:
  %t977 = load ptr, ptr %l488, !tbaa !29
  %t978 = load i64, ptr %t977
  %t980 = icmp eq i64 %t978, 24
  store i1 %t980, ptr %l489, !tbaa !21
  br label %bb297
bb297:
  %t981 = load i1, ptr %l489, !tbaa !21
  br i1 %t981, label %bb298, label %bb299
bb298:
  %t982 = load ptr, ptr %l1, !tbaa !29
  %t984 = getelementptr { i64, [5 x i64] }, ptr %t982, i32 0, i32 1
  %t985 = getelementptr { %"compiler/source:Span", ptr }, ptr %t984, i32 0, i32 1
  %t986 = load ptr, ptr %t985
  store ptr %t986, ptr %l61, !tbaa !29
  br label %bb300
bb299:
  br label %bb302
bb300:
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t989 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t988, ptr %t989)
  br label %bb301
bb301:
  br label %bb318
bb302:
  %t992 = load ptr, ptr %l1, !tbaa !29
  store ptr %t992, ptr %l496, !tbaa !29
  store i1 false, ptr %l497, !tbaa !21
  %t993 = load ptr, ptr %l496, !tbaa !29
  %t994 = icmp ne ptr %t993, null
  br i1 %t994, label %bb303, label %bb304
bb303:
  %t996 = load ptr, ptr %l496, !tbaa !29
  %t997 = load i64, ptr %t996
  %t999 = icmp eq i64 %t997, 25
  store i1 %t999, ptr %l497, !tbaa !21
  br label %bb304
bb304:
  %t1000 = load i1, ptr %l497, !tbaa !21
  br i1 %t1000, label %bb305, label %bb306
bb305:
  %t1001 = load ptr, ptr %l1, !tbaa !29
  %t1003 = getelementptr { i64, [5 x i64] }, ptr %t1001, i32 0, i32 1
  %t1004 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t1003, i32 0, i32 1
  %t1005 = load { i64, ptr }, ptr %t1004
  store { i64, ptr } %t1005, ptr %l62, !tbaa !27
  br label %bb307
bb306:
  br label %bb310
bb307:
  store %olang.scope zeroinitializer, ptr %s41
  %t1007 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s41, ptr %t1007, { i64, ptr } { i64 6, ptr @.d69 })
  br label %bb308
bb308:
  %t1009 = load ptr, ptr %l0, !tbaa !29
  %t1010 = load { i64, ptr }, ptr %l62, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t1009, { i64, ptr } %t1010)
  br label %bb309
bb309:
  call void @__olang_scope_close(ptr %s41)
  br label %bb318
bb310:
  %t1013 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1013, ptr %l505, !tbaa !29
  store i1 false, ptr %l506, !tbaa !21
  %t1014 = load ptr, ptr %l505, !tbaa !29
  %t1015 = icmp ne ptr %t1014, null
  br i1 %t1015, label %bb311, label %bb312
bb311:
  %t1017 = load ptr, ptr %l505, !tbaa !29
  %t1018 = load i64, ptr %t1017
  %t1020 = icmp eq i64 %t1018, 26
  store i1 %t1020, ptr %l506, !tbaa !21
  br label %bb312
bb312:
  %t1021 = load i1, ptr %l506, !tbaa !21
  br i1 %t1021, label %bb313, label %bb314
bb313:
  br label %bb315
bb314:
  br label %bb317
bb315:
  store %olang.scope zeroinitializer, ptr %s42
  %t1022 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s42, ptr %t1022, { i64, ptr } { i64 7, ptr @.d70 })
  br label %bb316
bb316:
  call void @__olang_scope_close(ptr %s42)
  br label %bb318
bb317:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb318:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t27 = icmp sgt i64 %t15, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t29, { i64, ptr } { i64 2, ptr @.d72 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr @.d73 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/ast:Func", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = icmp ne ptr %t6, null
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 1, ptr @.d74 })
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Func", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t12, ptr %t16)
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t19, { i64, ptr } { i64 2, ptr @.d75 })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %t24, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t21, i32 %t25)
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 5
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %t32)
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Func", ptr %t36, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t35, ptr %t39)
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t42, { i64, ptr } { i64 1, ptr @.d76 })
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Func", ptr %t45, i32 0, i32 4
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t44, { i64, ptr } %t48)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:If", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t8, ptr %t12)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } { i64 3, ptr @.d77 })
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:If", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t17, ptr %t21)
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:If", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t24, ptr %t28)
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:If", ptr %t31, i32 0, i32 2
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp ne ptr %t34, null
  br i1 %t36, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t38, { i64, ptr } { i64 5, ptr @.d78 })
  br label %bb10
bb9:
  br label %bb28
bb10:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/ast:If", ptr %t40, i32 0, i32 2
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l2, !tbaa !29
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t46 = load ptr, ptr %l23, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l23, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 5
  store i1 %t52, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l24, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", ptr }, ptr %t56, i32 0, i32 1
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb20
bb15:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/ast:If", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb16, label %bb17
bb16:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = getelementptr %"compiler/ast:If", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t67, ptr %t71)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb25:
  %t74 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t74, { i64, ptr } { i64 1, ptr @.d80 })
  br label %bb26
bb26:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/ast:If", ptr %t77, i32 0, i32 2
  %t80 = load ptr, ptr %t79, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t76, ptr %t80)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t9, { i64, ptr } %a1)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i1, ptr %l2, !tbaa !21
  %t17 = getelementptr %"compiler/unparse:writer", ptr %t13, i32 0, i32 6
  store i1 %t14, ptr %t17, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l21 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l94 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 6, ptr @.d81 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Match", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t3, ptr %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 2, ptr @.d82 })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l21, !tbaa !29
  %t13 = load ptr, ptr %l21, !tbaa !29
  %t14 = getelementptr %"compiler/unparse:writer", ptr %t13, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = add i64 %t15, 1
  %t19 = load ptr, ptr %l21, !tbaa !29
  %t20 = getelementptr %"compiler/unparse:writer", ptr %t19, i32 0, i32 4
  store i64 %t17, ptr %t20, !tbaa !24
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Match", ptr %t21, i32 0, i32 3
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb6:
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l32, !tbaa !27
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  store ptr %t44, ptr %l5, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t46)
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t48, { i64, ptr } { i64 5, ptr @.d83 })
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Case", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l46, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l10, !tbaa !29
  %t79 = icmp sgt i64 %t67, 0
  br i1 %t79, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t81, { i64, ptr } { i64 2, ptr @.d84 })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb10
bb20:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Case", ptr %t91, i32 0, i32 2
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t110, ptr %l65, !tbaa !27
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr ptr, ptr %t114, i64 %t111
  %t116 = load ptr, ptr %t115, !tbaa !39
  store ptr %t116, ptr %l15, !tbaa !29
  %t120 = icmp sgt i64 %t108, 0
  br i1 %t120, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t122 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t122, { i64, ptr } { i64 2, ptr @.d85 })
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb28:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb30
bb30:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l12, !tbaa !24
  br label %bb21
bb31:
  %t132 = load ptr, ptr %l5, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Case", ptr %t132, i32 0, i32 3
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = icmp ne ptr %t135, null
  br i1 %t137, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s11
  %t139 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t139, { i64, ptr } { i64 4, ptr @.d86 })
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Case", ptr %t142, i32 0, i32 3
  %t145 = load ptr, ptr %t144, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t141, ptr %t145)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s11)
  br label %bb36
bb36:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %t148, ptr %t149)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb38:
  %t152 = load i64, ptr %l3, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l3, !tbaa !24
  br label %bb4
bb39:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr %"compiler/ast:Match", ptr %t156, i32 0, i32 4
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = icmp ne ptr %t159, null
  br i1 %t161, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s13
  %t163 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t163)
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t165 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t165, { i64, ptr } { i64 7, ptr @.d87 })
  br label %bb43
bb43:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/ast:Match", ptr %t168, i32 0, i32 4
  %t171 = load ptr, ptr %t170, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %t167, ptr %t171)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s13)
  br label %bb45
bb45:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l94, !tbaa !29
  %t175 = load ptr, ptr %l94, !tbaa !29
  %t176 = getelementptr %"compiler/unparse:writer", ptr %t175, i32 0, i32 4
  %t177 = load i64, ptr %t176, !tbaa !24
  %t179 = sub i64 %t177, 1
  %t181 = load ptr, ptr %l94, !tbaa !29
  %t182 = getelementptr %"compiler/unparse:writer", ptr %t181, i32 0, i32 4
  store i64 %t179, ptr %t182, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t183)
  br label %bb46
bb46:
  %t185 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t185, { i64, ptr } { i64 1, ptr @.d88 })
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t7, i32 %a1)
  store { i64, ptr } %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t12, { i64, ptr } %t13)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t3, i8 10)
  br label %bb1
bb1:
  store i64 0, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/unparse:writer", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2funparse_2eMaxIndent, !tbaa !24
  %t12 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t8, i64 %t9)
  store i64 %t12, ptr %l12
  br label %bb2
bb2:
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb8
bb5:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l19, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l19, !tbaa !24
  store i64 %t40, ptr %l16, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l16, !tbaa !24
  store i64 %t41, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l1, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l6, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/unparse:writer", ptr %t60, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t62, { i64, ptr } { i64 4, ptr @.d89 })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l5, !tbaa !24
  br label %bb9
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Param", ptr %t1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t8, i32 %t12)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Param", ptr %t15, i32 0, i32 2
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp ne ptr %t18, null
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Param", ptr %t22, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = icmp ne i32 %t25, 0
  br i1 %t27, label %bb7, label %bb8
bb6:
  br label %bb12
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t29, { i64, ptr } { i64 1, ptr @.d90 })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Param", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %t34, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t31, ptr %t35)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Param", ptr %t38, i32 0, i32 3
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = icmp ne ptr %t41, null
  br i1 %t43, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t45, { i64, ptr } { i64 3, ptr @.d91 })
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Param", ptr %t48, i32 0, i32 3
  %t51 = load ptr, ptr %t50, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t47, ptr %t51)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l19 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l7, !tbaa !29
  %t35 = icmp sgt i64 %t23, 0
  br i1 %t35, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t37, { i64, ptr } { i64 2, ptr @.d92 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i1, ptr %l2, !tbaa !21
  %t51 = getelementptr %"compiler/unparse:writer", ptr %t47, i32 0, i32 6
  store i1 %t48, ptr %t51, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:Path", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t30 = icmp sgt i64 %t18, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t32, { i64, ptr } { i64 1, ptr @.d93 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t34, i32 %t35)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l44 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 1, ptr @.d94 })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb49
bb7:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb8, label %bb9
bb8:
  %t16 = load ptr, ptr %l17, !tbaa !29
  %t17 = load i64, ptr %t16
  %t19 = icmp eq i64 %t17, 1
  store i1 %t19, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb10, label %bb11
bb10:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", ptr }, ptr %t23, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  br label %bb13
bb13:
  br label %bb49
bb14:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t32 = load ptr, ptr %l25, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t35 = load ptr, ptr %l25, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l26, !tbaa !21
  br i1 %t39, label %bb17, label %bb18
bb17:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t48, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49
  store { i64, ptr } %t50, ptr %l4, !tbaa !27
  br label %bb19
bb18:
  br label %bb34
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t56, { i64, ptr } { i64 1, ptr @.d95 })
  br label %bb21
bb21:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l44, !tbaa !27
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l9, !tbaa !29
  %t84 = icmp sgt i64 %t72, 0
  br i1 %t84, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t86, { i64, ptr } { i64 2, ptr @.d96 })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t88, ptr %t89)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l6, !tbaa !24
  br label %bb22
bb32:
  %t96 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t96, { i64, ptr } { i64 1, ptr @.d97 })
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t99 = load ptr, ptr %l55, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb35, label %bb36
bb35:
  %t102 = load ptr, ptr %l55, !tbaa !29
  %t103 = load i64, ptr %t102
  %t105 = icmp eq i64 %t103, 3
  store i1 %t105, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb37, label %bb38
bb37:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32 }, ptr %t109, i32 0, i32 1
  %t111 = load i32, ptr %t110
  store i32 %t111, ptr %l10, !tbaa !23
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t113, i32 %t114)
  br label %bb40
bb40:
  br label %bb49
bb41:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb42, label %bb43
bb42:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load i64, ptr %t121
  %t124 = icmp eq i64 %t122, 4
  store i1 %t124, ptr %l64, !tbaa !21
  br label %bb43
bb43:
  %t125 = load i1, ptr %l64, !tbaa !21
  br i1 %t125, label %bb44, label %bb45
bb44:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", ptr }, ptr %t128, i32 0, i32 1
  %t130 = load ptr, ptr %t129
  store ptr %t130, ptr %l11, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t132, ptr %t133)
  br label %bb47
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @.c98)
  unreachable
bb49:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/unparse:writer", ptr %a0, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l41 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 1, ptr @.d99 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 1, ptr @.d100 })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Sig", ptr %t12, i32 0, i32 4
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t17, { i64, ptr } { i64 9, ptr @.d101 })
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/unparse:writer", ptr %t19, i32 0, i32 6
  %t22 = load i1, ptr %t21, !tbaa !21
  store i1 %t22, ptr %l2, !tbaa !21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/unparse:writer", ptr %t24, i32 0, i32 6
  store i1 true, ptr %t26, !tbaa !21
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Sig", ptr %t27, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l4, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t46, ptr %l28, !tbaa !27
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr ptr, ptr %t50, i64 %t47
  %t52 = load ptr, ptr %t51, !tbaa !39
  store ptr %t52, ptr %l7, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 2, ptr @.d102 }, ptr %l34, !tbaa !27
  br label %bb14
bb13:
  store { i64, ptr } { i64 1, ptr @.d103 }, ptr %l34, !tbaa !27
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l34, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t59, { i64, ptr } %t60)
  br label %bb15
bb15:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Sig", ptr %t62, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t69 = sub i64 %t67, 1
  %t72 = icmp eq i64 %t61, %t69
  br i1 %t72, label %bb16, label %bb17
bb16:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Sig", ptr %t74, i32 0, i32 2
  %t77 = load i1, ptr %t76, !tbaa !21
  store i1 %t77, ptr %l41, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb18
bb18:
  %t79 = load i1, ptr %l41, !tbaa !21
  br i1 %t79, label %bb19, label %bb20
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l44, !tbaa !29
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t83 = call i1 @compiler_2funparse_2enoErrorsOf(ptr %v1, ptr %t81)
  store i1 %t83, ptr %l46
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t84 = load i1, ptr %l46, !tbaa !21
  %t85 = load ptr, ptr %l44, !tbaa !29
  %t86 = getelementptr %"compiler/unparse:writer", ptr %t85, i32 0, i32 7
  store i1 %t84, ptr %t86, !tbaa !21
  br label %bb22
bb22:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/unparse:writer", ptr %t91, i32 0, i32 7
  store i1 false, ptr %t93, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t94 = load i64, ptr %l4, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l4, !tbaa !24
  br label %bb8
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i1, ptr %l2, !tbaa !21
  %t102 = getelementptr %"compiler/unparse:writer", ptr %t98, i32 0, i32 6
  store i1 %t99, ptr %t102, !tbaa !21
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t103, ptr %t104)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l10, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c104)
  unreachable
bb3:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c104)
  unreachable
bb5:
  %t29 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l9, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t37, { i64, ptr } %t36)
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c104)
  unreachable
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l83 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i1
  %l223 = alloca ptr
  %l225 = alloca { i64, ptr }
  %l231 = alloca ptr
  %l232 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i1
  %l259 = alloca ptr
  %l260 = alloca i1
  %l276 = alloca ptr
  %l277 = alloca i1
  %l292 = alloca ptr
  %l293 = alloca i1
  %l301 = alloca ptr
  %l302 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t2 = load ptr, ptr %l31, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l31, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l32, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l32, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb217
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t21 = load ptr, ptr %l39, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l39, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l40, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l40, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb217
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t40 = load ptr, ptr %l47, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l47, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l48, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l48, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb26
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Multi", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t54, { i64, ptr } %t58)
  br label %bb20
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l56, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Multi", ptr %t62, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr @.d105 }, ptr %l59, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 3, ptr @.d106 }, ptr %l59, !tbaa !27
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l56, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l59, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t67, { i64, ptr } %t68)
  br label %bb24
bb24:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Multi", ptr %t70, i32 0, i32 2
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t69, { i64, ptr } %t73)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb217
bb26:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t77 = load ptr, ptr %l63, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l63, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l64, !tbaa !21
  br label %bb28
bb28:
  %t84 = load i1, ptr %l64, !tbaa !21
  br i1 %t84, label %bb29, label %bb30
bb29:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l5
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l6, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t99, i32 0, i32 3
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l7, !tbaa !29
  br label %bb31
bb30:
  br label %bb38
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t103, ptr %t104)
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t107, { i64, ptr } { i64 1, ptr @.d107 })
  br label %bb33
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l76, !tbaa !29
  %t110 = load i32, ptr %l5
  %t112 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t110)
  store { i64, ptr } %t112, ptr %l78
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l76, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l78, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t113, { i64, ptr } %t114)
  br label %bb35
bb35:
  %t115 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t115, { i64, ptr } { i64 1, ptr @.d108 })
  br label %bb36
bb36:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb217
bb38:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t122 = load ptr, ptr %l82, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %l82, !tbaa !29
  %t126 = load i64, ptr %t125
  %t128 = icmp eq i64 %t126, 4
  store i1 %t128, ptr %l83, !tbaa !21
  br label %bb40
bb40:
  %t129 = load i1, ptr %l83, !tbaa !21
  br i1 %t129, label %bb41, label %bb42
bb41:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l8, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [5 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t138, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139
  store { i64, ptr } %t140, ptr %l9, !tbaa !27
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [5 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t144, i32 0, i32 3
  %t146 = load i1, ptr %t145
  store i1 %t146, ptr %l10, !tbaa !21
  br label %bb43
bb42:
  br label %bb50
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l92, !tbaa !29
  %t149 = load i1, ptr %l10, !tbaa !21
  br i1 %t149, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 8, ptr @.d109 }, ptr %l94, !tbaa !27
  br label %bb46
bb45:
  store { i64, ptr } { i64 4, ptr @.d110 }, ptr %l94, !tbaa !27
  br label %bb46
bb46:
  %t151 = load ptr, ptr %l92, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l94, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t151, { i64, ptr } %t152)
  br label %bb47
bb47:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t153, ptr %t154)
  br label %bb48
bb48:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t157, { i64, ptr } %t158)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb217
bb50:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t162 = load ptr, ptr %l99, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb51, label %bb52
bb51:
  %t165 = load ptr, ptr %l99, !tbaa !29
  %t166 = load i64, ptr %t165
  %t168 = icmp eq i64 %t166, 5
  store i1 %t168, ptr %l100, !tbaa !21
  br label %bb52
bb52:
  %t169 = load i1, ptr %l100, !tbaa !21
  br i1 %t169, label %bb53, label %bb54
bb53:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", ptr }, ptr %t172, i32 0, i32 1
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l11, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %t176, ptr %t177)
  br label %bb56
bb56:
  br label %bb217
bb57:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t181 = load ptr, ptr %l107, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb58, label %bb59
bb58:
  %t184 = load ptr, ptr %l107, !tbaa !29
  %t185 = load i64, ptr %t184
  %t187 = icmp eq i64 %t185, 6
  store i1 %t187, ptr %l108, !tbaa !21
  br label %bb59
bb59:
  %t188 = load i1, ptr %l108, !tbaa !21
  br i1 %t188, label %bb60, label %bb61
bb60:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t191, i32 0, i32 1
  %t193 = load { i64, ptr }, ptr %t192
  store { i64, ptr } %t193, ptr %l12, !tbaa !27
  br label %bb62
bb61:
  br label %bb65
bb62:
  store %olang.scope zeroinitializer, ptr %s7
  %t195 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t195, { i64, ptr } { i64 4, ptr @.d111 })
  br label %bb63
bb63:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t197, { i64, ptr } %t198)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb217
bb65:
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t202 = load ptr, ptr %l116, !tbaa !29
  %t203 = icmp ne ptr %t202, null
  br i1 %t203, label %bb66, label %bb67
bb66:
  %t205 = load ptr, ptr %l116, !tbaa !29
  %t206 = load i64, ptr %t205
  %t208 = icmp eq i64 %t206, 7
  store i1 %t208, ptr %l117, !tbaa !21
  br label %bb67
bb67:
  %t209 = load i1, ptr %l117, !tbaa !21
  br i1 %t209, label %bb68, label %bb69
bb68:
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t212, i32 0, i32 1
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l13, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t218, i32 0, i32 2
  %t220 = load { i64, ptr }, ptr %t219
  store { i64, ptr } %t220, ptr %l14, !tbaa !27
  br label %bb70
bb69:
  br label %bb74
bb70:
  store %olang.scope zeroinitializer, ptr %s8
  %t222 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t222, { i64, ptr } { i64 4, ptr @.d112 })
  br label %bb71
bb71:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t224, ptr %t225)
  br label %bb72
bb72:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t228, { i64, ptr } %t229)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s8)
  br label %bb217
bb74:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t233 = load ptr, ptr %l129, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb75, label %bb76
bb75:
  %t236 = load ptr, ptr %l129, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 8
  store i1 %t239, ptr %l130, !tbaa !21
  br label %bb76
bb76:
  %t240 = load i1, ptr %l130, !tbaa !21
  br i1 %t240, label %bb77, label %bb78
bb77:
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 1
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l15, !tbaa !29
  br label %bb79
bb78:
  br label %bb87
bb79:
  store %olang.scope zeroinitializer, ptr %s9
  %t247 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t247, { i64, ptr } { i64 4, ptr @.d113 })
  br label %bb80
bb80:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load ptr, ptr %l15, !tbaa !29
  %t252 = getelementptr %"compiler/ast:For3", ptr %t250, i32 0, i32 0
  %t253 = load ptr, ptr %t252, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t249, ptr %t253)
  br label %bb81
bb81:
  %t256 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t256, { i64, ptr } { i64 2, ptr @.d114 })
  br label %bb82
bb82:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %l15, !tbaa !29
  %t261 = getelementptr %"compiler/ast:For3", ptr %t259, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t258, ptr %t262)
  br label %bb83
bb83:
  %t265 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t265, { i64, ptr } { i64 2, ptr @.d115 })
  br label %bb84
bb84:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load ptr, ptr %l15, !tbaa !29
  %t270 = getelementptr %"compiler/ast:For3", ptr %t268, i32 0, i32 2
  %t271 = load ptr, ptr %t270, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t267, ptr %t271)
  br label %bb85
bb85:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l15, !tbaa !29
  %t277 = getelementptr %"compiler/ast:For3", ptr %t275, i32 0, i32 3
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t274, { i64, ptr } %t278)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s9)
  br label %bb217
bb87:
  %t281 = load ptr, ptr %l1, !tbaa !29
  store ptr %t281, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t282 = load ptr, ptr %l150, !tbaa !29
  %t283 = icmp ne ptr %t282, null
  br i1 %t283, label %bb88, label %bb89
bb88:
  %t285 = load ptr, ptr %l150, !tbaa !29
  %t286 = load i64, ptr %t285
  %t288 = icmp eq i64 %t286, 9
  store i1 %t288, ptr %l151, !tbaa !21
  br label %bb89
bb89:
  %t289 = load i1, ptr %l151, !tbaa !21
  br i1 %t289, label %bb90, label %bb91
bb90:
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t292 = getelementptr { i64, [5 x i64] }, ptr %t290, i32 0, i32 1
  %t293 = getelementptr { %"compiler/source:Span", ptr }, ptr %t292, i32 0, i32 1
  %t294 = load ptr, ptr %t293
  store ptr %t294, ptr %l16, !tbaa !29
  br label %bb92
bb91:
  br label %bb108
bb92:
  store %olang.scope zeroinitializer, ptr %s10
  %t296 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t296, { i64, ptr } { i64 4, ptr @.d116 })
  br label %bb93
bb93:
  %t298 = load ptr, ptr %l16, !tbaa !29
  %t300 = getelementptr %"compiler/ast:ForIn", ptr %t298, i32 0, i32 0
  %t301 = load i32, ptr %t300, !tbaa !23
  %t303 = icmp ne i32 %t301, 0
  br i1 %t303, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s11
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load ptr, ptr %l16, !tbaa !29
  %t308 = getelementptr %"compiler/ast:ForIn", ptr %t306, i32 0, i32 0
  %t309 = load i32, ptr %t308, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t305, i32 %t309)
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t312 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t312, { i64, ptr } { i64 2, ptr @.d117 })
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s11)
  br label %bb98
bb98:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l16, !tbaa !29
  %t317 = getelementptr %"compiler/ast:ForIn", ptr %t315, i32 0, i32 1
  %t318 = load i32, ptr %t317, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t314, i32 %t318)
  br label %bb99
bb99:
  %t321 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t321, { i64, ptr } { i64 4, ptr @.d118 })
  br label %bb100
bb100:
  %t323 = load ptr, ptr %l16, !tbaa !29
  %t325 = getelementptr %"compiler/ast:ForIn", ptr %t323, i32 0, i32 3
  %t326 = load i1, ptr %t325, !tbaa !21
  br i1 %t326, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s12
  %t328 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t328, { i64, ptr } { i64 4, ptr @.d119 })
  br label %bb103
bb102:
  br label %bb104
bb103:
  call void @__olang_scope_close(ptr %s12)
  br label %bb104
bb104:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l16, !tbaa !29
  %t333 = getelementptr %"compiler/ast:ForIn", ptr %t331, i32 0, i32 2
  %t334 = load ptr, ptr %t333, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t330, ptr %t334)
  br label %bb105
bb105:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load ptr, ptr %l16, !tbaa !29
  %t340 = getelementptr %"compiler/ast:ForIn", ptr %t338, i32 0, i32 4
  %t341 = load { i64, ptr }, ptr %t340, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t337, { i64, ptr } %t341)
  br label %bb106
bb106:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l16, !tbaa !29
  %t347 = getelementptr %"compiler/ast:ForIn", ptr %t345, i32 0, i32 5
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t344, { i64, ptr } %t348)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s10)
  br label %bb217
bb108:
  %t351 = load ptr, ptr %l1, !tbaa !29
  store ptr %t351, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t352 = load ptr, ptr %l180, !tbaa !29
  %t353 = icmp ne ptr %t352, null
  br i1 %t353, label %bb109, label %bb110
bb109:
  %t355 = load ptr, ptr %l180, !tbaa !29
  %t356 = load i64, ptr %t355
  %t358 = icmp eq i64 %t356, 10
  store i1 %t358, ptr %l181, !tbaa !21
  br label %bb110
bb110:
  %t359 = load i1, ptr %l181, !tbaa !21
  br i1 %t359, label %bb111, label %bb112
bb111:
  %t360 = load ptr, ptr %l1, !tbaa !29
  %t362 = getelementptr { i64, [5 x i64] }, ptr %t360, i32 0, i32 1
  %t363 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t362, i32 0, i32 1
  %t364 = load { i64, ptr }, ptr %t363
  store { i64, ptr } %t364, ptr %l17, !tbaa !27
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t368 = getelementptr { i64, [5 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t368, i32 0, i32 2
  %t370 = load ptr, ptr %t369
  store ptr %t370, ptr %l18, !tbaa !29
  br label %bb113
bb112:
  br label %bb118
bb113:
  store %olang.scope zeroinitializer, ptr %s13
  %t372 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t372, { i64, ptr } { i64 3, ptr @.d120 })
  br label %bb114
bb114:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t374, { i64, ptr } %t375)
  br label %bb115
bb115:
  %t378 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t378, { i64, ptr } { i64 5, ptr @.d121 })
  br label %bb116
bb116:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t380, ptr %t381)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s13)
  br label %bb217
bb118:
  %t384 = load ptr, ptr %l1, !tbaa !29
  store ptr %t384, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t385 = load ptr, ptr %l194, !tbaa !29
  %t386 = icmp ne ptr %t385, null
  br i1 %t386, label %bb119, label %bb120
bb119:
  %t388 = load ptr, ptr %l194, !tbaa !29
  %t389 = load i64, ptr %t388
  %t391 = icmp eq i64 %t389, 11
  store i1 %t391, ptr %l195, !tbaa !21
  br label %bb120
bb120:
  %t392 = load i1, ptr %l195, !tbaa !21
  br i1 %t392, label %bb121, label %bb122
bb121:
  %t393 = load ptr, ptr %l1, !tbaa !29
  %t395 = getelementptr { i64, [5 x i64] }, ptr %t393, i32 0, i32 1
  %t396 = getelementptr { %"compiler/source:Span", ptr }, ptr %t395, i32 0, i32 1
  %t397 = load ptr, ptr %t396
  store ptr %t397, ptr %l19, !tbaa !29
  br label %bb123
bb122:
  br label %bb125
bb123:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t399, ptr %t400)
  br label %bb124
bb124:
  br label %bb217
bb125:
  %t403 = load ptr, ptr %l1, !tbaa !29
  store ptr %t403, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t404 = load ptr, ptr %l202, !tbaa !29
  %t405 = icmp ne ptr %t404, null
  br i1 %t405, label %bb126, label %bb127
bb126:
  %t407 = load ptr, ptr %l202, !tbaa !29
  %t408 = load i64, ptr %t407
  %t410 = icmp eq i64 %t408, 12
  store i1 %t410, ptr %l203, !tbaa !21
  br label %bb127
bb127:
  %t411 = load i1, ptr %l203, !tbaa !21
  br i1 %t411, label %bb128, label %bb129
bb128:
  %t412 = load ptr, ptr %l1, !tbaa !29
  %t414 = getelementptr { i64, [5 x i64] }, ptr %t412, i32 0, i32 1
  %t415 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t414, i32 0, i32 1
  %t416 = load { i64, ptr }, ptr %t415
  store { i64, ptr } %t416, ptr %l20, !tbaa !27
  br label %bb130
bb129:
  br label %bb137
bb130:
  store %olang.scope zeroinitializer, ptr %s15
  %t418 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t418, { i64, ptr } { i64 6, ptr @.d122 })
  br label %bb131
bb131:
  %t420 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t420, 0
  %t424 = icmp sgt i64 %t422, 0
  br i1 %t424, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s16
  %t426 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t426, { i64, ptr } { i64 1, ptr @.d123 })
  br label %bb134
bb133:
  br label %bb136
bb134:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t428, { i64, ptr } %t429)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s16)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s15)
  br label %bb217
bb137:
  %t432 = load ptr, ptr %l1, !tbaa !29
  store ptr %t432, ptr %l215, !tbaa !29
  store i1 false, ptr %l216, !tbaa !21
  %t433 = load ptr, ptr %l215, !tbaa !29
  %t434 = icmp ne ptr %t433, null
  br i1 %t434, label %bb138, label %bb139
bb138:
  %t436 = load ptr, ptr %l215, !tbaa !29
  %t437 = load i64, ptr %t436
  %t439 = icmp eq i64 %t437, 13
  store i1 %t439, ptr %l216, !tbaa !21
  br label %bb139
bb139:
  %t440 = load i1, ptr %l216, !tbaa !21
  br i1 %t440, label %bb140, label %bb141
bb140:
  %t441 = load ptr, ptr %l1, !tbaa !29
  %t443 = getelementptr { i64, [5 x i64] }, ptr %t441, i32 0, i32 1
  %t444 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t443, i32 0, i32 1
  %t445 = load i32, ptr %t444
  store i32 %t445, ptr %l21
  %t447 = load ptr, ptr %l1, !tbaa !29
  %t449 = getelementptr { i64, [5 x i64] }, ptr %t447, i32 0, i32 1
  %t450 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t449, i32 0, i32 2
  %t451 = load ptr, ptr %t450
  store ptr %t451, ptr %l22, !tbaa !29
  br label %bb142
bb141:
  br label %bb150
bb142:
  store %olang.scope zeroinitializer, ptr %s17
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l223, !tbaa !29
  %t454 = load i32, ptr %l21
  %t456 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s17, i32 %t454)
  store { i64, ptr } %t456, ptr %l225
  br label %bb143
bb143:
  %t457 = load ptr, ptr %l223, !tbaa !29
  %t458 = load { i64, ptr }, ptr %l225, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t457, { i64, ptr } %t458)
  br label %bb144
bb144:
  %t459 = load ptr, ptr %l22, !tbaa !29
  %t461 = icmp ne ptr %t459, null
  br i1 %t461, label %bb145, label %bb146
bb145:
  store %olang.scope zeroinitializer, ptr %s18
  %t463 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t463, { i64, ptr } { i64 1, ptr @.d124 })
  br label %bb147
bb146:
  br label %bb149
bb147:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t465, ptr %t466)
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s18)
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s17)
  br label %bb217
bb150:
  %t469 = load ptr, ptr %l1, !tbaa !29
  store ptr %t469, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t470 = load ptr, ptr %l231, !tbaa !29
  %t471 = icmp ne ptr %t470, null
  br i1 %t471, label %bb151, label %bb152
bb151:
  %t473 = load ptr, ptr %l231, !tbaa !29
  %t474 = load i64, ptr %t473
  %t476 = icmp eq i64 %t474, 14
  store i1 %t476, ptr %l232, !tbaa !21
  br label %bb152
bb152:
  %t477 = load i1, ptr %l232, !tbaa !21
  br i1 %t477, label %bb153, label %bb154
bb153:
  %t478 = load ptr, ptr %l1, !tbaa !29
  %t480 = getelementptr { i64, [5 x i64] }, ptr %t478, i32 0, i32 1
  %t481 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t480, i32 0, i32 1
  %t482 = load ptr, ptr %t481
  store ptr %t482, ptr %l23, !tbaa !29
  %t484 = load ptr, ptr %l1, !tbaa !29
  %t486 = getelementptr { i64, [5 x i64] }, ptr %t484, i32 0, i32 1
  %t487 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t486, i32 0, i32 2
  %t488 = load ptr, ptr %t487
  store ptr %t488, ptr %l24, !tbaa !29
  br label %bb155
bb154:
  br label %bb163
bb155:
  store %olang.scope zeroinitializer, ptr %s19
  %t490 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t490, { i64, ptr } { i64 7, ptr @.d125 })
  br label %bb156
bb156:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t492, ptr %t493)
  br label %bb157
bb157:
  %t496 = load ptr, ptr %l24, !tbaa !29
  %t498 = icmp ne ptr %t496, null
  br i1 %t498, label %bb158, label %bb159
bb158:
  store %olang.scope zeroinitializer, ptr %s20
  %t500 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t500, { i64, ptr } { i64 2, ptr @.d126 })
  br label %bb160
bb159:
  br label %bb162
bb160:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t502, ptr %t503)
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s20)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s19)
  br label %bb217
bb163:
  %t506 = load ptr, ptr %l1, !tbaa !29
  store ptr %t506, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t507 = load ptr, ptr %l247, !tbaa !29
  %t508 = icmp ne ptr %t507, null
  br i1 %t508, label %bb164, label %bb165
bb164:
  %t510 = load ptr, ptr %l247, !tbaa !29
  %t511 = load i64, ptr %t510
  %t513 = icmp eq i64 %t511, 15
  store i1 %t513, ptr %l248, !tbaa !21
  br label %bb165
bb165:
  %t514 = load i1, ptr %l248, !tbaa !21
  br i1 %t514, label %bb166, label %bb167
bb166:
  %t515 = load ptr, ptr %l1, !tbaa !29
  %t517 = getelementptr { i64, [5 x i64] }, ptr %t515, i32 0, i32 1
  %t518 = getelementptr { %"compiler/source:Span", ptr }, ptr %t517, i32 0, i32 1
  %t519 = load ptr, ptr %t518
  store ptr %t519, ptr %l25, !tbaa !29
  br label %bb168
bb167:
  br label %bb175
bb168:
  store %olang.scope zeroinitializer, ptr %s21
  %t521 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t521, { i64, ptr } { i64 5, ptr @.d127 })
  br label %bb169
bb169:
  %t523 = load ptr, ptr %l25, !tbaa !29
  %t525 = icmp ne ptr %t523, null
  br i1 %t525, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s22
  %t527 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t527, { i64, ptr } { i64 1, ptr @.d128 })
  br label %bb172
bb171:
  br label %bb174
bb172:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t529, ptr %t530)
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s22)
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s21)
  br label %bb217
bb175:
  %t533 = load ptr, ptr %l1, !tbaa !29
  store ptr %t533, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t534 = load ptr, ptr %l259, !tbaa !29
  %t535 = icmp ne ptr %t534, null
  br i1 %t535, label %bb176, label %bb177
bb176:
  %t537 = load ptr, ptr %l259, !tbaa !29
  %t538 = load i64, ptr %t537
  %t540 = icmp eq i64 %t538, 16
  store i1 %t540, ptr %l260, !tbaa !21
  br label %bb177
bb177:
  %t541 = load i1, ptr %l260, !tbaa !21
  br i1 %t541, label %bb178, label %bb179
bb178:
  %t542 = load ptr, ptr %l1, !tbaa !29
  %t544 = getelementptr { i64, [5 x i64] }, ptr %t542, i32 0, i32 1
  %t545 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t544, i32 0, i32 1
  %t546 = load { i64, ptr }, ptr %t545
  store { i64, ptr } %t546, ptr %l26, !tbaa !27
  %t548 = load ptr, ptr %l1, !tbaa !29
  %t550 = getelementptr { i64, [5 x i64] }, ptr %t548, i32 0, i32 1
  %t551 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t550, i32 0, i32 2
  %t552 = load ptr, ptr %t551
  store ptr %t552, ptr %l27, !tbaa !29
  br label %bb180
bb179:
  br label %bb188
bb180:
  store %olang.scope zeroinitializer, ptr %s23
  %t554 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t554, { i64, ptr } { i64 6, ptr @.d129 })
  br label %bb181
bb181:
  %t556 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t558 = extractvalue { i64, ptr } %t556, 0
  %t560 = icmp sgt i64 %t558, 0
  br i1 %t560, label %bb182, label %bb183
bb182:
  store %olang.scope zeroinitializer, ptr %s24
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t563 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t562, { i64, ptr } %t563)
  br label %bb184
bb183:
  br label %bb186
bb184:
  %t566 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t566, { i64, ptr } { i64 3, ptr @.d130 })
  br label %bb185
bb185:
  call void @__olang_scope_close(ptr %s24)
  br label %bb186
bb186:
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t569 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t568, ptr %t569)
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s23)
  br label %bb217
bb188:
  %t572 = load ptr, ptr %l1, !tbaa !29
  store ptr %t572, ptr %l276, !tbaa !29
  store i1 false, ptr %l277, !tbaa !21
  %t573 = load ptr, ptr %l276, !tbaa !29
  %t574 = icmp ne ptr %t573, null
  br i1 %t574, label %bb189, label %bb190
bb189:
  %t576 = load ptr, ptr %l276, !tbaa !29
  %t577 = load i64, ptr %t576
  %t579 = icmp eq i64 %t577, 17
  store i1 %t579, ptr %l277, !tbaa !21
  br label %bb190
bb190:
  %t580 = load i1, ptr %l277, !tbaa !21
  br i1 %t580, label %bb191, label %bb192
bb191:
  %t581 = load ptr, ptr %l1, !tbaa !29
  %t583 = getelementptr { i64, [5 x i64] }, ptr %t581, i32 0, i32 1
  %t584 = getelementptr { %"compiler/source:Span", ptr }, ptr %t583, i32 0, i32 1
  %t585 = load ptr, ptr %t584
  store ptr %t585, ptr %l28, !tbaa !29
  br label %bb193
bb192:
  br label %bb201
bb193:
  store %olang.scope zeroinitializer, ptr %s25
  %t587 = load ptr, ptr %l28, !tbaa !29
  %t589 = getelementptr %"compiler/ast:JoinS", ptr %t587, i32 0, i32 0
  %t590 = load i1, ptr %t589, !tbaa !21
  br i1 %t590, label %bb194, label %bb195
bb194:
  store %olang.scope zeroinitializer, ptr %s26
  %t592 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t592, { i64, ptr } { i64 4, ptr @.d131 })
  br label %bb196
bb195:
  br label %bb197
bb196:
  call void @__olang_scope_close(ptr %s26)
  br label %bb197
bb197:
  %t594 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t594, { i64, ptr } { i64 5, ptr @.d132 })
  br label %bb198
bb198:
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t597 = load ptr, ptr %l28, !tbaa !29
  %t599 = getelementptr %"compiler/ast:JoinS", ptr %t597, i32 0, i32 1
  %t600 = load { i64, ptr }, ptr %t599, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t596, { i64, ptr } %t600)
  br label %bb199
bb199:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load ptr, ptr %l28, !tbaa !29
  %t606 = getelementptr %"compiler/ast:JoinS", ptr %t604, i32 0, i32 2
  %t607 = load { i64, ptr }, ptr %t606, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t603, { i64, ptr } %t607)
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s25)
  br label %bb217
bb201:
  %t610 = load ptr, ptr %l1, !tbaa !29
  store ptr %t610, ptr %l292, !tbaa !29
  store i1 false, ptr %l293, !tbaa !21
  %t611 = load ptr, ptr %l292, !tbaa !29
  %t612 = icmp ne ptr %t611, null
  br i1 %t612, label %bb202, label %bb203
bb202:
  %t614 = load ptr, ptr %l292, !tbaa !29
  %t615 = load i64, ptr %t614
  %t617 = icmp eq i64 %t615, 18
  store i1 %t617, ptr %l293, !tbaa !21
  br label %bb203
bb203:
  %t618 = load i1, ptr %l293, !tbaa !21
  br i1 %t618, label %bb204, label %bb205
bb204:
  %t619 = load ptr, ptr %l1, !tbaa !29
  %t621 = getelementptr { i64, [5 x i64] }, ptr %t619, i32 0, i32 1
  %t622 = getelementptr { %"compiler/source:Span", ptr }, ptr %t621, i32 0, i32 1
  %t623 = load ptr, ptr %t622
  store ptr %t623, ptr %l29, !tbaa !29
  br label %bb206
bb205:
  br label %bb209
bb206:
  store %olang.scope zeroinitializer, ptr %s27
  %t625 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s27, ptr %t625, { i64, ptr } { i64 6, ptr @.d133 })
  br label %bb207
bb207:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t627, ptr %t628)
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s27)
  br label %bb217
bb209:
  %t631 = load ptr, ptr %l1, !tbaa !29
  store ptr %t631, ptr %l301, !tbaa !29
  store i1 false, ptr %l302, !tbaa !21
  %t632 = load ptr, ptr %l301, !tbaa !29
  %t633 = icmp ne ptr %t632, null
  br i1 %t633, label %bb210, label %bb211
bb210:
  %t635 = load ptr, ptr %l301, !tbaa !29
  %t636 = load i64, ptr %t635
  %t638 = icmp eq i64 %t636, 19
  store i1 %t638, ptr %l302, !tbaa !21
  br label %bb211
bb211:
  %t639 = load i1, ptr %l302, !tbaa !21
  br i1 %t639, label %bb212, label %bb213
bb212:
  %t640 = load ptr, ptr %l1, !tbaa !29
  %t642 = getelementptr { i64, [5 x i64] }, ptr %t640, i32 0, i32 1
  %t643 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t642, i32 0, i32 1
  %t644 = load { i64, ptr }, ptr %t643
  store { i64, ptr } %t644, ptr %l30, !tbaa !27
  br label %bb214
bb213:
  br label %bb216
bb214:
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t647 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t646, { i64, ptr } %t647)
  br label %bb215
bb215:
  br label %bb217
bb216:
  call void @__olang_check_failed(ptr @.c134)
  unreachable
bb217:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l38 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopBranch", ptr %t5, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t4, i64 %t8)
  store i1 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopBranch", ptr %t14, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t13, %"compiler/source:Span" %t17)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TopBranch", ptr %t23, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t22, %"compiler/source:Span" %t26)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t29, { i64, ptr } { i64 1, ptr @.d135 })
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = getelementptr %"compiler/unparse:writer", ptr %t32, i32 0, i32 4
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = add i64 %t34, 1
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = getelementptr %"compiler/unparse:writer", ptr %t38, i32 0, i32 4
  store i64 %t36, ptr %t39, !tbaa !24
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  store ptr %t63, ptr %l5, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t65)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l3, !tbaa !24
  br label %bb8
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l38, !tbaa !29
  %t76 = load ptr, ptr %l38, !tbaa !29
  %t77 = getelementptr %"compiler/unparse:writer", ptr %t76, i32 0, i32 4
  %t78 = load i64, ptr %t77, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"compiler/unparse:writer", ptr %t82, i32 0, i32 4
  store i64 %t80, ptr %t83, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t84)
  br label %bb16
bb16:
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t86, { i64, ptr } { i64 1, ptr @.d136 })
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr @.d137 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:TopIf", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t3, ptr %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 1, ptr @.d138 })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TopIf", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t12, ptr %t16)
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:TopIf", ptr %t19, i32 0, i32 2
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp ne ptr %t22, null
  br i1 %t24, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t26, { i64, ptr } { i64 6, ptr @.d139 })
  br label %bb7
bb6:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TopIf", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp ne ptr %t31, null
  br i1 %t33, label %bb9, label %bb10
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/ast:TopIf", ptr %t36, i32 0, i32 2
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t35, ptr %t39)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t42, { i64, ptr } { i64 6, ptr @.d140 })
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:TopIf", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t44, ptr %t48)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l34 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %l67 = alloca i1
  %l73 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l121 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t2 = load ptr, ptr %l18, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l18, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l19, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l19, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb23
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t38, ptr %l34, !tbaa !27
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i32, ptr %t42, i64 %t39
  %t44 = load i32, ptr %t43, !tbaa !33
  store i32 %t44, ptr %l8, !tbaa !23
  %t48 = icmp sgt i64 %t36, 0
  br i1 %t48, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t50, { i64, ptr } { i64 1, ptr @.d141 })
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t52, i32 %t53)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb6
bb16:
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t66 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t66, { i64, ptr } { i64 1, ptr @.d142 })
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t68, { i64, ptr } %t69)
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t72, { i64, ptr } { i64 1, ptr @.d143 })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  br label %bb93
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t75 = load ptr, ptr %l51, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l51, !tbaa !29
  %t79 = load i64, ptr %t78
  %t81 = icmp eq i64 %t79, 1
  store i1 %t81, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l52, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l9, !tbaa !29
  br label %bb28
bb27:
  br label %bb47
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/unparse:writer", ptr %t89, i32 0, i32 7
  %t92 = load i1, ptr %t91, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb37
bb30:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/unparse:writer", ptr %t94, i32 0, i32 6
  %t97 = load i1, ptr %t96, !tbaa !21
  br i1 %t97, label %bb31, label %bb32
bb31:
  %t99 = load ptr, ptr %l9, !tbaa !29
  %t101 = getelementptr %"compiler/ast:Sig", ptr %t99, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t106 = icmp sgt i64 %t104, 1
  br i1 %t106, label %bb33, label %bb34
bb32:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb36
bb33:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb35
bb34:
  %t108 = load ptr, ptr %l9, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Sig", ptr %t108, i32 0, i32 3
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t115 = icmp sgt i64 %t113, 1
  store i1 %t115, ptr %l67, !tbaa !21
  br label %bb35
bb35:
  %t117 = load i1, ptr %l67, !tbaa !21
  store i1 %t117, ptr %l62, !tbaa !21
  br label %bb36
bb36:
  %t118 = load i1, ptr %l62, !tbaa !21
  store i1 %t118, ptr %l59, !tbaa !21
  br label %bb37
bb37:
  %t119 = load i1, ptr %l59, !tbaa !21
  store i1 %t119, ptr %l10, !tbaa !21
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/unparse:writer", ptr %t120, i32 0, i32 7
  store i1 false, ptr %t122, !tbaa !21
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l73, !tbaa !29
  %t124 = load i1, ptr %l10, !tbaa !21
  br i1 %t124, label %bb38, label %bb39
bb38:
  store { i64, ptr } { i64 3, ptr @.d144 }, ptr %l75, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 2, ptr @.d145 }, ptr %l75, !tbaa !27
  br label %bb40
bb40:
  %t126 = load ptr, ptr %l73, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l75, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t126, { i64, ptr } %t127)
  br label %bb41
bb41:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/unparse:writer", ptr %t128, i32 0, i32 6
  %t131 = load i1, ptr %t130, !tbaa !21
  store i1 %t131, ptr %l11, !tbaa !21
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/unparse:writer", ptr %t133, i32 0, i32 6
  store i1 false, ptr %t135, !tbaa !21
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t136, ptr %t137)
  br label %bb42
bb42:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i1, ptr %l11, !tbaa !21
  %t144 = getelementptr %"compiler/unparse:writer", ptr %t140, i32 0, i32 6
  store i1 %t141, ptr %t144, !tbaa !21
  %t145 = load i1, ptr %l10, !tbaa !21
  br i1 %t145, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t147, { i64, ptr } { i64 1, ptr @.d146 })
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb93
bb47:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t150 = load ptr, ptr %l85, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb48, label %bb49
bb48:
  %t153 = load ptr, ptr %l85, !tbaa !29
  %t154 = load i64, ptr %t153
  %t156 = icmp eq i64 %t154, 2
  store i1 %t156, ptr %l86, !tbaa !21
  br label %bb49
bb49:
  %t157 = load i1, ptr %l86, !tbaa !21
  br i1 %t157, label %bb50, label %bb51
bb50:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l12, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t164, ptr %t165)
  br label %bb53
bb53:
  br label %bb93
bb54:
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t169 = load ptr, ptr %l93, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb55, label %bb56
bb55:
  %t172 = load ptr, ptr %l93, !tbaa !29
  %t173 = load i64, ptr %t172
  %t175 = icmp eq i64 %t173, 3
  store i1 %t175, ptr %l94, !tbaa !21
  br label %bb56
bb56:
  %t176 = load i1, ptr %l94, !tbaa !21
  br i1 %t176, label %bb57, label %bb58
bb57:
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t179, i32 0, i32 1
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l13, !tbaa !29
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t185, i32 0, i32 2
  %t187 = load i32, ptr %t186
  store i32 %t187, ptr %l14, !tbaa !23
  br label %bb59
bb58:
  br label %bb66
bb59:
  store %olang.scope zeroinitializer, ptr %s10
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t189, ptr %t190)
  br label %bb60
bb60:
  %t193 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t193, { i64, ptr } { i64 1, ptr @.d147 })
  br label %bb61
bb61:
  %t195 = load i32, ptr %l14, !tbaa !23
  %t197 = icmp ne i32 %t195, 0
  br i1 %t197, label %bb62, label %bb63
bb62:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t199, i32 %t200)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s10)
  br label %bb93
bb66:
  %t203 = load ptr, ptr %l1, !tbaa !29
  store ptr %t203, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t204 = load ptr, ptr %l108, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb67, label %bb68
bb67:
  %t207 = load ptr, ptr %l108, !tbaa !29
  %t208 = load i64, ptr %t207
  %t210 = icmp eq i64 %t208, 4
  store i1 %t210, ptr %l109, !tbaa !21
  br label %bb68
bb68:
  %t211 = load i1, ptr %l109, !tbaa !21
  br i1 %t211, label %bb69, label %bb70
bb69:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t214, i32 0, i32 1
  %t216 = load ptr, ptr %t215
  store ptr %t216, ptr %l15, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t220, i32 0, i32 2
  %t222 = load i1, ptr %t221
  store i1 %t222, ptr %l16, !tbaa !21
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [5 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t226, i32 0, i32 3
  %t228 = load i1, ptr %t227
  store i1 %t228, ptr %l17, !tbaa !21
  br label %bb71
bb70:
  br label %bb92
bb71:
  %t230 = load i1, ptr %l17, !tbaa !21
  br i1 %t230, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s13
  %t232 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t232, { i64, ptr } { i64 3, ptr @.d148 })
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_scope_close(ptr %s13)
  br label %bb75
bb75:
  %t234 = load i1, ptr %l17, !tbaa !21
  br i1 %t234, label %bb76, label %bb77
bb76:
  %t236 = load i1, ptr %l16, !tbaa !21
  store i1 %t236, ptr %l121, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb78
bb78:
  %t238 = load i1, ptr %l121, !tbaa !21
  br i1 %t238, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s14
  %t239 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t239, { i64, ptr } { i64 1, ptr @.d149 })
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_scope_close(ptr %s14)
  br label %bb82
bb82:
  %t241 = load i1, ptr %l16, !tbaa !21
  br i1 %t241, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s15
  %t243 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t243, { i64, ptr } { i64 3, ptr @.d150 })
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s15)
  br label %bb86
bb86:
  %t245 = load ptr, ptr %l15, !tbaa !29
  %t247 = icmp ne ptr %t245, null
  br i1 %t247, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s16
  %t249 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t249, { i64, ptr } { i64 1, ptr @.d151 })
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t251, ptr %t252)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s16)
  br label %bb91
bb91:
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @.c152)
  unreachable
bb93:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l51 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca i1
  %l91 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb19
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t16, { i64, ptr } { i64 6, ptr @.d153 })
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:StructBody", ptr %t19, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t18, { i64, ptr } %t22)
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t25, { i64, ptr } { i64 1, ptr @.d154 })
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/ast:StructBody", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t27, { i64, ptr } %t31)
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t34, { i64, ptr } { i64 1, ptr @.d155 })
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:StructBody", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t36, ptr %t40)
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t43, { i64, ptr } { i64 1, ptr @.d156 })
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/ast:StructBody", ptr %t46, i32 0, i32 2
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t45, { i64, ptr } %t49)
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/ast:StructBody", ptr %t52, i32 0, i32 4
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } zeroinitializer, 0
  %t59 = icmp eq i64 %t57, %t58
  %t60 = extractvalue { i64, ptr } %t55, 1
  %t61 = extractvalue { i64, ptr } zeroinitializer, 1
  %t62 = icmp eq ptr %t60, %t61
  %t63 = and i1 %t59, %t62
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t66 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t66, { i64, ptr } { i64 10, ptr @.d157 })
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/ast:StructBody", ptr %t69, i32 0, i32 4
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t68, { i64, ptr } %t72)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  br label %bb81
bb19:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l44, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 1
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb21
bb21:
  %t83 = load i1, ptr %l45, !tbaa !21
  br i1 %t83, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [2 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { { i64, ptr } }, ptr %t86, i32 0, i32 0
  %t88 = load { i64, ptr }, ptr %t87
  store { i64, ptr } %t88, ptr %l3, !tbaa !27
  br label %bb24
bb23:
  br label %bb42
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t90, { i64, ptr } { i64 6, ptr @.d158 })
  br label %bb25
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l51, !tbaa !29
  %t93 = load ptr, ptr %l51, !tbaa !29
  %t94 = getelementptr %"compiler/unparse:writer", ptr %t93, i32 0, i32 4
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = add i64 %t95, 1
  %t99 = load ptr, ptr %l51, !tbaa !29
  %t100 = getelementptr %"compiler/unparse:writer", ptr %t99, i32 0, i32 4
  store i64 %t97, ptr %t100, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t101, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l6, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load i64, ptr %l5, !tbaa !24
  %t108 = load i64, ptr %l6, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb28:
  br label %bb29
bb29:
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t115, ptr %l61, !tbaa !27
  %t116 = load i64, ptr %l5, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr ptr, ptr %t119, i64 %t116
  %t121 = load ptr, ptr %t120, !tbaa !39
  store ptr %t121, ptr %l7, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t123)
  br label %bb30
bb30:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t128 = getelementptr %"compiler/ast:CaseDecl", ptr %t126, i32 0, i32 1
  %t129 = load i32, ptr %t128, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t125, i32 %t129)
  br label %bb31
bb31:
  %t132 = load ptr, ptr %l7, !tbaa !29
  %t134 = getelementptr %"compiler/ast:CaseDecl", ptr %t132, i32 0, i32 2
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t139 = icmp sgt i64 %t137, 0
  br i1 %t139, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t141, { i64, ptr } { i64 1, ptr @.d159 })
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l7, !tbaa !29
  %t146 = getelementptr %"compiler/ast:CaseDecl", ptr %t144, i32 0, i32 2
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t143, { i64, ptr } %t147)
  br label %bb35
bb35:
  %t150 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t150, { i64, ptr } { i64 1, ptr @.d160 })
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  %t152 = load i64, ptr %l5, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l5, !tbaa !24
  br label %bb26
bb39:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l79, !tbaa !29
  %t157 = load ptr, ptr %l79, !tbaa !29
  %t158 = getelementptr %"compiler/unparse:writer", ptr %t157, i32 0, i32 4
  %t159 = load i64, ptr %t158, !tbaa !24
  %t161 = sub i64 %t159, 1
  %t163 = load ptr, ptr %l79, !tbaa !29
  %t164 = getelementptr %"compiler/unparse:writer", ptr %t163, i32 0, i32 4
  store i64 %t161, ptr %t164, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t165)
  br label %bb40
bb40:
  %t167 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t167, { i64, ptr } { i64 1, ptr @.d161 })
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb81
bb42:
  %t169 = load ptr, ptr %l1, !tbaa !29
  store ptr %t169, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t170 = load ptr, ptr %l84, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb43, label %bb44
bb43:
  %t173 = load ptr, ptr %l84, !tbaa !29
  %t174 = load i64, ptr %t173
  %t176 = icmp eq i64 %t174, 2
  store i1 %t176, ptr %l85, !tbaa !21
  br label %bb44
bb44:
  %t177 = load i1, ptr %l85, !tbaa !21
  br i1 %t177, label %bb45, label %bb46
bb45:
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr { i64, [2 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { { i64, ptr } }, ptr %t180, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181
  store { i64, ptr } %t182, ptr %l8, !tbaa !27
  br label %bb47
bb46:
  br label %bb64
bb47:
  store %olang.scope zeroinitializer, ptr %s8
  %t184 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t184, { i64, ptr } { i64 7, ptr @.d162 })
  br label %bb48
bb48:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l91, !tbaa !29
  %t187 = load ptr, ptr %l91, !tbaa !29
  %t188 = getelementptr %"compiler/unparse:writer", ptr %t187, i32 0, i32 4
  %t189 = load i64, ptr %t188, !tbaa !24
  %t191 = add i64 %t189, 1
  %t193 = load ptr, ptr %l91, !tbaa !29
  %t194 = getelementptr %"compiler/unparse:writer", ptr %t193, i32 0, i32 4
  store i64 %t191, ptr %t194, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t195, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  store i64 %t199, ptr %l11, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t201 = load i64, ptr %l10, !tbaa !24
  %t202 = load i64, ptr %l11, !tbaa !24
  %t205 = icmp slt i64 %t201, %t202
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb51:
  br label %bb52
bb52:
  %t209 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t209, ptr %l101, !tbaa !27
  %t210 = load i64, ptr %l10, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr ptr, ptr %t213, i64 %t210
  %t215 = load ptr, ptr %t214, !tbaa !39
  store ptr %t215, ptr %l12, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t217)
  br label %bb53
bb53:
  %t219 = load ptr, ptr %l12, !tbaa !29
  %t221 = getelementptr %"compiler/ast:Func", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = icmp ne ptr %t222, null
  br i1 %t224, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s11
  %t226 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t226, { i64, ptr } { i64 4, ptr @.d163 })
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb57:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l12, !tbaa !29
  %t231 = getelementptr %"compiler/ast:Func", ptr %t229, i32 0, i32 2
  %t232 = load i32, ptr %t231, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t228, i32 %t232)
  br label %bb58
bb58:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l12, !tbaa !29
  %t238 = getelementptr %"compiler/ast:Func", ptr %t236, i32 0, i32 3
  %t239 = load ptr, ptr %t238, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t235, ptr %t239)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  %t242 = load i64, ptr %l10, !tbaa !24
  %t244 = add i64 %t242, 1
  store i64 %t244, ptr %l10, !tbaa !24
  br label %bb49
bb61:
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l117, !tbaa !29
  %t247 = load ptr, ptr %l117, !tbaa !29
  %t248 = getelementptr %"compiler/unparse:writer", ptr %t247, i32 0, i32 4
  %t249 = load i64, ptr %t248, !tbaa !24
  %t251 = sub i64 %t249, 1
  %t253 = load ptr, ptr %l117, !tbaa !29
  %t254 = getelementptr %"compiler/unparse:writer", ptr %t253, i32 0, i32 4
  store i64 %t251, ptr %t254, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t255)
  br label %bb62
bb62:
  %t257 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t257, { i64, ptr } { i64 1, ptr @.d164 })
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  br label %bb81
bb64:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t260 = load ptr, ptr %l122, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb65, label %bb66
bb65:
  %t263 = load ptr, ptr %l122, !tbaa !29
  %t264 = load i64, ptr %t263
  %t266 = icmp eq i64 %t264, 3
  store i1 %t266, ptr %l123, !tbaa !21
  br label %bb66
bb66:
  %t267 = load i1, ptr %l123, !tbaa !21
  br i1 %t267, label %bb67, label %bb68
bb67:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [2 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { ptr, ptr }, ptr %t270, i32 0, i32 0
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l13, !tbaa !29
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t276 = getelementptr { i64, [2 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { ptr, ptr }, ptr %t276, i32 0, i32 1
  %t278 = load ptr, ptr %t277
  store ptr %t278, ptr %l14, !tbaa !29
  br label %bb69
bb68:
  br label %bb80
bb69:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t280, ptr %t281)
  br label %bb70
bb70:
  %t284 = load ptr, ptr %l14, !tbaa !29
  %t286 = icmp ne ptr %t284, null
  br i1 %t286, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s14
  %t288 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t288, { i64, ptr } { i64 1, ptr @.d165 })
  br label %bb73
bb72:
  br label %bb79
bb73:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load ptr, ptr %l14, !tbaa !29
  %t293 = getelementptr %"compiler/ast:Func", ptr %t291, i32 0, i32 3
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/ast:Sig", ptr %t294, i32 0, i32 0
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t290, { i64, ptr } %t297)
  br label %bb74
bb74:
  %t300 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t300, { i64, ptr } { i64 1, ptr @.d166 })
  br label %bb75
bb75:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load ptr, ptr %l14, !tbaa !29
  %t305 = getelementptr %"compiler/ast:Func", ptr %t303, i32 0, i32 3
  %t306 = load ptr, ptr %t305, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t302, ptr %t306)
  br label %bb76
bb76:
  %t309 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t309, { i64, ptr } { i64 1, ptr @.d167 })
  br label %bb77
bb77:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t312 = load ptr, ptr %l14, !tbaa !29
  %t314 = getelementptr %"compiler/ast:Func", ptr %t312, i32 0, i32 4
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t311, { i64, ptr } %t315)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s14)
  br label %bb79
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @.c168)
  unreachable
bb81:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 5, ptr @.d169 })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:TypeDecl", ptr %t4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t3, i32 %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:TypeDecl", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t10, { i64, ptr } %t14)
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TypeDecl", ptr %t17, i32 0, i32 2
  %t20 = load i1, ptr %t19, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t22, { i64, ptr } { i64 8, ptr @.d170 })
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t24, { i64, ptr } { i64 1, ptr @.d171 })
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TypeDecl", ptr %t27, i32 0, i32 3
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca i1
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = extractvalue { i64, ptr } zeroinitializer, 0
  %t5 = icmp eq i64 %t3, %t4
  %t6 = extractvalue { i64, ptr } %t1, 1
  %t7 = extractvalue { i64, ptr } zeroinitializer, 1
  %t8 = icmp eq ptr %t6, %t7
  %t9 = and i1 %t5, %t8
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp eq i64 %t13, 0
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t18, { i64, ptr } { i64 1, ptr @.d172 })
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t20, i32 0, i32 6
  %t23 = load i1, ptr %t22, !tbaa !21
  store i1 %t23, ptr %l2, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/unparse:writer", ptr %t25, i32 0, i32 6
  store i1 true, ptr %t27, !tbaa !21
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t28, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb10:
  br label %bb11
bb11:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t44, ptr %l26, !tbaa !27
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l7, !tbaa !29
  %t54 = icmp sgt i64 %t42, 0
  br i1 %t54, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t56, { i64, ptr } { i64 2, ptr @.d173 })
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l7, !tbaa !29
  %t61 = getelementptr %"compiler/ast:TypeParam", ptr %t59, i32 0, i32 1
  %t62 = load i32, ptr %t61, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t58, i32 %t62)
  br label %bb16
bb16:
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t67 = getelementptr %"compiler/ast:TypeParam", ptr %t65, i32 0, i32 2
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp ne ptr %t68, null
  br i1 %t70, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t72, { i64, ptr } { i64 1, ptr @.d174 })
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t77 = getelementptr %"compiler/ast:TypeParam", ptr %t75, i32 0, i32 2
  %t78 = load ptr, ptr %t77, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t74, ptr %t78)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t81 = load i64, ptr %l4, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l4, !tbaa !24
  br label %bb8
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i1, ptr %l2, !tbaa !21
  %t89 = getelementptr %"compiler/unparse:writer", ptr %t85, i32 0, i32 6
  store i1 %t86, ptr %t89, !tbaa !21
  %t90 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t90, { i64, ptr } { i64 1, ptr @.d175 })
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l19 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l7, !tbaa !29
  %t35 = icmp sgt i64 %t23, 0
  br i1 %t35, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t37, { i64, ptr } { i64 2, ptr @.d176 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i1, ptr %l2, !tbaa !21
  %t51 = getelementptr %"compiler/unparse:writer", ptr %t47, i32 0, i32 6
  store i1 %t48, ptr %t51, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t30 = icmp sgt i64 %t18, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t32, { i64, ptr } { i64 2, ptr @.d177 })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t34, i32 %t35)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr %"compiler/ast:VarDecl", ptr %t42, i32 0, i32 4
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t47, i32 0, i32 2
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp ne ptr %t50, null
  br i1 %t52, label %bb14, label %bb15
bb13:
  br label %bb21
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t54, { i64, ptr } { i64 1, ptr @.d178 })
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/ast:VarDecl", ptr %t57, i32 0, i32 2
  %t60 = load ptr, ptr %t59, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t63, { i64, ptr } { i64 4, ptr @.d179 })
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:VarDecl", ptr %t66, i32 0, i32 3
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t65, { i64, ptr } %t69)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/ast:VarDecl", ptr %t72, i32 0, i32 2
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  br i1 %t77, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t79 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t79, { i64, ptr } { i64 1, ptr @.d180 })
  br label %bb25
bb25:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/ast:VarDecl", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t81, ptr %t85)
  br label %bb26
bb26:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/ast:VarDecl", ptr %t88, i32 0, i32 3
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  %t97 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t97, { i64, ptr } { i64 3, ptr @.d181 })
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/ast:VarDecl", ptr %t100, i32 0, i32 3
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t99, { i64, ptr } %t103)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2funparse_2enoErrorsOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Sig", ptr %t16, i32 0, i32 2
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  store i1 %t21, ptr %l2, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c182)
  unreachable
bb11:
  %t23 = load i1, ptr %l2, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i32
  %l16 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i32
  %l22 = alloca i32
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l68 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load i32, ptr %l1
  store i32 %t16, ptr %l14
  store i32 50, ptr %l16
  %t19 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l14, ptr %l16)
  store i1 %t19, ptr %l18
  br label %bb6
bb6:
  %t20 = load i1, ptr %l18, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb10
bb8:
  %t21 = load i32, ptr %l1
  store i32 %t21, ptr %l20
  store i32 72, ptr %l22
  %t24 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %l20, ptr %l22)
  store i1 %t24, ptr %l24
  br label %bb9
bb9:
  %t25 = load i1, ptr %l24, !tbaa !21
  store i1 %t25, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l19, !tbaa !21
  store i1 %t26, ptr %l7, !tbaa !21
  br label %bb53
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t28 = load ptr, ptr %l25, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb12, label %bb13
bb12:
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 1
  store i1 %t34, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb53
bb17:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t37 = load ptr, ptr %l29, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l29, !tbaa !29
  %t41 = load i64, ptr %t40
  %t43 = icmp eq i64 %t41, 5
  store i1 %t43, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l30, !tbaa !21
  br i1 %t44, label %bb20, label %bb21
bb20:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t51)
  store i1 %t53, ptr %l36
  br label %bb23
bb23:
  %t54 = load i1, ptr %l36, !tbaa !21
  store i1 %t54, ptr %l7, !tbaa !21
  br label %bb53
bb24:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t56 = load ptr, ptr %l37, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb25, label %bb26
bb25:
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l38, !tbaa !21
  br label %bb26
bb26:
  %t63 = load i1, ptr %l38, !tbaa !21
  br i1 %t63, label %bb27, label %bb28
bb27:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l3, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t70)
  store i1 %t72, ptr %l44
  br label %bb30
bb30:
  %t73 = load i1, ptr %l44, !tbaa !21
  store i1 %t73, ptr %l7, !tbaa !21
  br label %bb53
bb31:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t75 = load ptr, ptr %l45, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb32, label %bb33
bb32:
  %t78 = load ptr, ptr %l45, !tbaa !29
  %t79 = load i64, ptr %t78
  %t81 = icmp eq i64 %t79, 12
  store i1 %t81, ptr %l46, !tbaa !21
  br label %bb33
bb33:
  %t82 = load i1, ptr %l46, !tbaa !21
  br i1 %t82, label %bb34, label %bb35
bb34:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t89)
  store i1 %t91, ptr %l52
  br label %bb37
bb37:
  %t92 = load i1, ptr %l52, !tbaa !21
  store i1 %t92, ptr %l7, !tbaa !21
  br label %bb53
bb38:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t94 = load ptr, ptr %l53, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb39, label %bb40
bb39:
  %t97 = load ptr, ptr %l53, !tbaa !29
  %t98 = load i64, ptr %t97
  %t100 = icmp eq i64 %t98, 15
  store i1 %t100, ptr %l54, !tbaa !21
  br label %bb40
bb40:
  %t101 = load i1, ptr %l54, !tbaa !21
  br i1 %t101, label %bb41, label %bb42
bb41:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t108)
  store i1 %t110, ptr %l60
  br label %bb44
bb44:
  %t111 = load i1, ptr %l60, !tbaa !21
  store i1 %t111, ptr %l7, !tbaa !21
  br label %bb53
bb45:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t113 = load ptr, ptr %l61, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb46, label %bb47
bb46:
  %t116 = load ptr, ptr %l61, !tbaa !29
  %t117 = load i64, ptr %t116
  %t119 = icmp eq i64 %t117, 16
  store i1 %t119, ptr %l62, !tbaa !21
  br label %bb47
bb47:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb48, label %bb49
bb48:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l6, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t129 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t127)
  store i1 %t129, ptr %l68
  br label %bb51
bb51:
  %t130 = load i1, ptr %l68, !tbaa !21
  store i1 %t130, ptr %l7, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb53
bb53:
  %t131 = load i1, ptr %l7, !tbaa !21
  store i1 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/unparse:writer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store ptr %a2, ptr %l5, !tbaa !29
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v3)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t8, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %t9)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = insertvalue %"compiler/unparse:writer" undef, ptr %t12, 0
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = insertvalue %"compiler/unparse:writer" %t13, { i64, ptr } %t14, 1
  %t16 = load ptr, ptr %l5, !tbaa !29
  %t17 = insertvalue %"compiler/unparse:writer" %t15, ptr %t16, 2
  %t18 = load %"std/prelude/text:StringBuilder", ptr %l6
  %t19 = insertvalue %"compiler/unparse:writer" %t17, %"std/prelude/text:StringBuilder" %t18, 3
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = insertvalue %"compiler/unparse:writer" %t19, i64 %t20, 4
  %t23 = insertvalue %"compiler/unparse:writer" %t21, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, 5
  %t25 = insertvalue %"compiler/unparse:writer" %t23, i1 false, 6
  %t27 = insertvalue %"compiler/unparse:writer" %t25, i1 false, 7
  store %"compiler/unparse:writer" %t27, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/unparse:writer", ptr %rv
  ret %"compiler/unparse:writer" %rr
}

define dso_local void @olang_2einit_2ecompiler_2funparse() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2funparse_2eMaxIndent_2einit()
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant [3 x i8] c"{ }"
@.d1 = private constant [1 x i8] c"{"
@.d2 = private constant [1 x i8] c"}"
@.d3 = private constant [2 x i8] c": "
@.d4 = private constant [1 x i8] c" "
@.d5 = private constant [1 x i8] c" "
@.d6 = private constant [4 x i8] c" => "
@.d7 = private constant [1 x i8] c" "
@.d8 = private constant [6 x i8] c" catch"
@.d9 = private constant [2 x i8] c", "
@.d10 = private constant [1 x i8] c" "
@.d11 = private constant [1 x i8] c" "
@.d12 = private constant [9 x i8] c" default "
@.d13 = private constant [10 x i8] c"extern fn "
@.d14 = private constant [7 x i8] c"import "
@.d15 = private constant [1 x i8] c" "
@.d16 = private constant [6 x i8] c"error "
@.d17 = private constant [2 x i8] c" {"
@.d18 = private constant [1 x i8] c"}"
@.d19 = private constant [5 x i8] c"test "
@.d20 = private constant [1 x i8] c" "
declare void @__olang_check_failed(ptr)
@.c21 = private unnamed_addr constant [48 x i8] c"compiler/unparse.olang:58: unreachable reached\0A\00"
@.d22 = private constant [2 x i8] c" ?"
@.d23 = private constant [2 x i8] c", "
@.d24 = private constant [1 x i8] c" "
@.d25 = private constant [1 x i8] c"("
@.d26 = private constant [1 x i8] c")"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftoken_3aTok(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d27 = private constant [1 x i8] c" "
@.d28 = private constant [1 x i8] c" "
@.d29 = private constant [1 x i8] c" "
@.d30 = private constant [1 x i8] c" "
@.d31 = private constant [8 x i8] c" not in "
@.d32 = private constant [1 x i8] c" "
@.d33 = private constant [1 x i8] c" "
@.d34 = private constant [4 x i8] c" if "
@.d35 = private constant [6 x i8] c" else "
@.d36 = private constant [8 x i8] c" is not "
@.d37 = private constant [4 x i8] c" is "
@.d38 = private constant [8 x i8] c" is not "
@.d39 = private constant [4 x i8] c" is "
@.d40 = private constant [4 x i8] c" as "
@.d41 = private constant [1 x i8] c"("
@.d42 = private constant [1 x i8] c")"
@.d43 = private constant [1 x i8] c"&"
@.d44 = private constant [1 x i8] c"("
@.d45 = private constant [1 x i8] c")"
@.d46 = private constant [1 x i8] c"<"
@.d47 = private constant [1 x i8] c">"
@.d48 = private constant [1 x i8] c"."
@.d49 = private constant [1 x i8] c"["
@.d50 = private constant [1 x i8] c"]"
@.d51 = private constant [1 x i8] c"["
@.d52 = private constant [1 x i8] c":"
@.d53 = private constant [1 x i8] c"]"
@.d54 = private constant [1 x i8] c"["
@.d55 = private constant [1 x i8] c"]"
@.d56 = private constant [1 x i8] c"["
@.d57 = private constant [1 x i8] c"]"
@.d58 = private constant [1 x i8] c"["
@.d59 = private constant [5 x i8] c" for "
@.d60 = private constant [2 x i8] c", "
@.d61 = private constant [4 x i8] c" in "
@.d62 = private constant [4 x i8] c" if "
@.d63 = private constant [1 x i8] c"]"
@.d64 = private constant [1 x i8] c" "
@.d65 = private constant [8 x i8] c"checked "
@.d66 = private constant [4 x i8] c"try "
@.d67 = private constant [2 x i8] c"fn"
@.d68 = private constant [1 x i8] c" "
@.d69 = private constant [6 x i8] c"range "
@.d70 = private constant [7 x i8] c"default"
@.c71 = private unnamed_addr constant [49 x i8] c"compiler/unparse.olang:652: unreachable reached\0A\00"
@.d72 = private constant [2 x i8] c", "
@.d73 = private constant [3 x i8] c"fn "
@.d74 = private constant [1 x i8] c"("
@.d75 = private constant [2 x i8] c") "
@.d76 = private constant [1 x i8] c" "
@.d77 = private constant [3 x i8] c"if "
@.d78 = private constant [5 x i8] c" else"
@.c79 = private unnamed_addr constant [49 x i8] c"compiler/unparse.olang:549: unreachable reached\0A\00"
@.d80 = private constant [1 x i8] c" "
@.d81 = private constant [6 x i8] c"match "
@.d82 = private constant [2 x i8] c" {"
@.d83 = private constant [5 x i8] c"case "
@.d84 = private constant [2 x i8] c", "
@.d85 = private constant [2 x i8] c", "
@.d86 = private constant [4 x i8] c" if "
@.d87 = private constant [7 x i8] c"nomatch"
@.d88 = private constant [1 x i8] c"}"
@.d89 = private constant [4 x i8] c"    "
@.d90 = private constant [1 x i8] c" "
@.d91 = private constant [3 x i8] c" = "
@.d92 = private constant [2 x i8] c", "
@.d93 = private constant [1 x i8] c"."
@.d94 = private constant [1 x i8] c"_"
@.d95 = private constant [1 x i8] c"("
@.d96 = private constant [2 x i8] c", "
@.d97 = private constant [1 x i8] c")"
@.c98 = private unnamed_addr constant [49 x i8] c"compiler/unparse.olang:617: unreachable reached\0A\00"
@.d99 = private constant [1 x i8] c"("
@.d100 = private constant [1 x i8] c")"
@.d101 = private constant [9 x i8] c" noreturn"
@.d102 = private constant [2 x i8] c", "
@.d103 = private constant [1 x i8] c" "
@.c104 = private unnamed_addr constant [54 x i8] c"compiler/unparse.olang:43: slice bounds out of range\0A\00"
@.d105 = private constant [4 x i8] c" := "
@.d106 = private constant [3 x i8] c" = "
@.d107 = private constant [1 x i8] c" "
@.d108 = private constant [1 x i8] c" "
@.d109 = private constant [8 x i8] c"checked "
@.d110 = private constant [4 x i8] c"try "
@.d111 = private constant [4 x i8] c"for "
@.d112 = private constant [4 x i8] c"for "
@.d113 = private constant [4 x i8] c"for "
@.d114 = private constant [2 x i8] c", "
@.d115 = private constant [2 x i8] c", "
@.d116 = private constant [4 x i8] c"for "
@.d117 = private constant [2 x i8] c", "
@.d118 = private constant [4 x i8] c" in "
@.d119 = private constant [4 x i8] c"try "
@.d120 = private constant [3 x i8] c"do "
@.d121 = private constant [5 x i8] c" for "
@.d122 = private constant [6 x i8] c"return"
@.d123 = private constant [1 x i8] c" "
@.d124 = private constant [1 x i8] c" "
@.d125 = private constant [7 x i8] c"assert "
@.d126 = private constant [2 x i8] c", "
@.d127 = private constant [5 x i8] c"error"
@.d128 = private constant [1 x i8] c" "
@.d129 = private constant [6 x i8] c"spawn "
@.d130 = private constant [3 x i8] c" = "
@.d131 = private constant [4 x i8] c"try "
@.d132 = private constant [5 x i8] c"join "
@.d133 = private constant [6 x i8] c"defer "
@.c134 = private unnamed_addr constant [49 x i8] c"compiler/unparse.olang:427: unreachable reached\0A\00"
@.d135 = private constant [1 x i8] c"{"
@.d136 = private constant [1 x i8] c"}"
@.d137 = private constant [3 x i8] c"if "
@.d138 = private constant [1 x i8] c" "
@.d139 = private constant [6 x i8] c" else "
@.d140 = private constant [6 x i8] c" else "
@.d141 = private constant [1 x i8] c"."
@.d142 = private constant [1 x i8] c"<"
@.d143 = private constant [1 x i8] c">"
@.d144 = private constant [3 x i8] c"(fn"
@.d145 = private constant [2 x i8] c"fn"
@.d146 = private constant [1 x i8] c")"
@.d147 = private constant [1 x i8] c"&"
@.d148 = private constant [3 x i8] c"own"
@.d149 = private constant [1 x i8] c" "
@.d150 = private constant [3 x i8] c"mut"
@.d151 = private constant [1 x i8] c" "
@.c152 = private unnamed_addr constant [49 x i8] c"compiler/unparse.olang:307: unreachable reached\0A\00"
@.d153 = private constant [6 x i8] c"struct"
@.d154 = private constant [1 x i8] c"("
@.d155 = private constant [1 x i8] c")"
@.d156 = private constant [1 x i8] c" "
@.d157 = private constant [10 x i8] c" destruct "
@.d158 = private constant [6 x i8] c"enum {"
@.d159 = private constant [1 x i8] c"("
@.d160 = private constant [1 x i8] c")"
@.d161 = private constant [1 x i8] c"}"
@.d162 = private constant [7 x i8] c"trait {"
@.d163 = private constant [4 x i8] c"mut "
@.d164 = private constant [1 x i8] c"}"
@.d165 = private constant [1 x i8] c"("
@.d166 = private constant [1 x i8] c")"
@.d167 = private constant [1 x i8] c" "
@.c168 = private unnamed_addr constant [49 x i8] c"compiler/unparse.olang:236: unreachable reached\0A\00"
@.d169 = private constant [5 x i8] c"type "
@.d170 = private constant [8 x i8] c" extends"
@.d171 = private constant [1 x i8] c" "
@.d172 = private constant [1 x i8] c"<"
@.d173 = private constant [2 x i8] c", "
@.d174 = private constant [1 x i8] c" "
@.d175 = private constant [1 x i8] c">"
@.d176 = private constant [2 x i8] c", "
@.d177 = private constant [2 x i8] c", "
@.d178 = private constant [1 x i8] c" "
@.d179 = private constant [4 x i8] c" := "
@.d180 = private constant [1 x i8] c" "
@.d181 = private constant [3 x i8] c" = "
@.c182 = private unnamed_addr constant [49 x i8] c"compiler/unparse.olang:164: unreachable reached\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
