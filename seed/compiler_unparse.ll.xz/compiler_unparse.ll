; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/unparse:writer" = type { ptr, { i64, ptr }, ptr, %"std/prelude/text:StringBuilder", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/ast:Attr" = type { %"compiler/source:Span", ptr, i32 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1 }
@G_2ecompiler_2funparse_2eMaxIndent = constant <{ [8 x i8] }> <{ [8 x i8] c"\40\00\00\00\00\00\00\00" }>, align 8
define dso_local { i64, ptr } @compiler_2funparse_2eHeldBranches(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/unparse:writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca %"compiler/unparse:writer"
  %l20 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %a1, { i64, ptr } %a2, ptr %a3)
  store %"compiler/unparse:writer" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/unparse:writer", ptr %l12
  store %"compiler/unparse:writer" %t8, ptr %l4
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %s0, ptr %v0, ptr %l4, ptr %t29)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l6, !tbaa !24
  br label %bb2
bb8:
  %t38 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 5
  %t40 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %s0, ptr %t38)
  store { i64, ptr } %t40, ptr %l28
  br label %bb9
bb9:
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l30, !tbaa !24
  %t45 = mul i64 %t44, 8
  %t46 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t45)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l31, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l30, !tbaa !24
  %t54 = mul i64 %t53, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t50, ptr %t52, i64 %t54, i1 false)
  %t55 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2funparse_2eUnparse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"compiler/unparse:writer"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l12 = alloca %"compiler/unparse:writer"
  %l20 = alloca { i64, ptr }
  %l24 = alloca i1
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %a1, { i64, ptr } %a2, ptr %a3)
  store %"compiler/unparse:writer" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load %"compiler/unparse:writer", ptr %l12
  store %"compiler/unparse:writer" %t8, ptr %l4
  store { i64, ptr } %a0, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l8, !tbaa !29
  %t31 = load ptr, ptr %l8, !tbaa !29
  %t33 = call i1 @compiler_2funparse_2ehidden(ptr %v0, ptr %t31)
  store i1 %t33, ptr %l24
  br label %bb6
bb6:
  %t34 = load i1, ptr %l24, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %s0, ptr %v0, ptr %l4, ptr %t35)
  br label %bb10
bb10:
  %t38 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t38, i8 10)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l6, !tbaa !24
  br label %bb2
bb13:
  %t44 = getelementptr %"compiler/unparse:writer", ptr %l4, i32 0, i32 3
  %t46 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v4, ptr %t44)
  store { i64, ptr } %t46, ptr %l31
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2funparse_2ebareSpread(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %v1, ptr %a1, i32 %t17)
  store { i64, ptr } %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t22, ptr %l12
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  %t23 = load i1, ptr %l12, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_97fb03c83c422508_396f69b1ea6ff204)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eattrs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t23, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Attr", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t25, ptr %t29)
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t32, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb1
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l12 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l35 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t7, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l12, !tbaa !29
  %t12 = load ptr, ptr %l12, !tbaa !29
  %t13 = getelementptr %"compiler/unparse:writer", ptr %t12, i32 0, i32 4
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = add i64 %t14, 1
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = getelementptr %"compiler/unparse:writer", ptr %t18, i32 0, i32 4
  store i64 %t16, ptr %t19, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t20, i32 0, i32 6
  %t23 = load i1, ptr %t22, !tbaa !21
  store i1 %t23, ptr %l2, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/unparse:writer", ptr %t25, i32 0, i32 6
  store i1 false, ptr %t27, !tbaa !21
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t28, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l25, !tbaa !27
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l6, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t50)
  br label %bb10
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l4, !tbaa !24
  br label %bb6
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i1, ptr %l2, !tbaa !21
  %t64 = getelementptr %"compiler/unparse:writer", ptr %t60, i32 0, i32 6
  store i1 %t61, ptr %t64, !tbaa !21
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l35, !tbaa !29
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = getelementptr %"compiler/unparse:writer", ptr %t66, i32 0, i32 4
  %t68 = load i64, ptr %t67, !tbaa !24
  %t70 = sub i64 %t68, 1
  %t72 = load ptr, ptr %l35, !tbaa !29
  %t73 = getelementptr %"compiler/unparse:writer", ptr %t72, i32 0, i32 4
  store i64 %t70, ptr %t73, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t74)
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t76, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) })
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l31 = alloca i1
  %l33 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr ptr, ptr %t9, i64 0
  %t11 = load ptr, ptr %t10, !tbaa !39
  %t13 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t11)
  store %"compiler/source:Span" %t13, ptr %l8
  br label %bb3
bb2:
  br label %bb24
bb3:
  %t14 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t19 = sub i64 %t17, 1
  store i64 %t19, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sge i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/unparse:writer", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l16, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i8, ptr %t32, i64 %t29
  %t34 = load i8, ptr %t33, !tbaa !32
  %t36 = icmp eq i8 %t34, 32
  br i1 %t36, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/unparse:writer", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp eq i8 %t47, 9
  store i1 %t49, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t51 = load i1, ptr %l20, !tbaa !21
  store i1 %t51, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t52 = load i1, ptr %l14, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = sub i64 %t55, 1
  store i64 %t57, ptr %l2, !tbaa !24
  br label %bb14
bb14:
  br label %bb4
bb15:
  %t59 = load i64, ptr %l2, !tbaa !24
  %t61 = icmp sge i64 %t59, 0
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/unparse:writer", ptr %t63, i32 0, i32 1
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l33, !tbaa !27
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 58
  store i1 %t74, ptr %l31, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t76 = load i1, ptr %l31, !tbaa !21
  br i1 %t76, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t77, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t80, ptr %l39, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr ptr, ptr %t82, i64 0
  %t84 = load ptr, ptr %t83, !tbaa !39
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t79, ptr %t84)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t87, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) })
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t89, { i64, ptr } %t90)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/unparse:writer", ptr %t10, i32 0, i32 2
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Branch", ptr %t14, i32 0, i32 2
  %t17 = load i64, ptr %t16, !tbaa !24
  %t20 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t13, i64 %t17)
  store i1 %t20, ptr %l11
  br label %bb3
bb3:
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l6, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/unparse:writer", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l13, !tbaa !27
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Branch", ptr %t27, i32 0, i32 0
  %t30 = getelementptr %"compiler/source:Span", ptr %t29, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t35 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t33
  %t38 = load i8, ptr %t37, !tbaa !32
  %t40 = icmp ne i8 %t38, 58
  br i1 %t40, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t42, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Branch", ptr %t45, i32 0, i32 0
  %t48 = load %"compiler/source:Span", ptr %t47
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t44, %"compiler/source:Span" %t48)
  br label %bb11
bb11:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/unparse:writer", ptr %t51, i32 0, i32 5
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Branch", ptr %t54, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t53, %"compiler/source:Span" %t57)
  br label %bb12
bb12:
  br label %ret
bb13:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Branch", ptr %t61, i32 0, i32 1
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t60, { i64, ptr } %t64)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l7 = alloca ptr
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 5
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Case", ptr %t13, i32 0, i32 5
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6d411809e3c45284_6ddb613e25dacce8)
  unreachable
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Case", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t24, ptr %t23)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Case", ptr %t27, i32 0, i32 4
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t26, { i64, ptr } %t30)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t23, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) })
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l5, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Catch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load i64, ptr %l7, !tbaa !24
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l10, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l34, !tbaa !29
  %t55 = icmp sgt i64 %t42, 0
  br i1 %t55, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb12
bb12:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t57, { i64, ptr } %t58)
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t59, ptr %t60)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l7, !tbaa !24
  br label %bb6
bb16:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Catch", ptr %t67, i32 0, i32 5
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = icmp ne i32 %t70, 0
  br i1 %t72, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t74 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t74, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Catch", ptr %t77, i32 0, i32 5
  %t80 = load i32, ptr %t79, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t76, i32 %t80)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Catch", ptr %t83, i32 0, i32 4
  %t86 = load i1, ptr %t85, !tbaa !21
  br i1 %t86, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  %t88 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t88, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Catch", ptr %t91, i32 0, i32 2
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t90, { i64, ptr } %t94)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Catch", ptr %t97, i32 0, i32 3
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  %t106 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t106, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l5, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Catch", ptr %t109, i32 0, i32 3
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t108, { i64, ptr } %t112)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t115 = load i64, ptr %l3, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l3, !tbaa !24
  br label %bb1
bb33:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtract(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 5
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Sig", ptr %t8, i32 0, i32 5
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_3b272a795e4745a2_9a90297686d0fdde)
  unreachable
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Sig", ptr %t15, i32 0, i32 5
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l2, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t20, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb7
bb7:
  store i1 true, ptr %l3, !tbaa !21
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/ast:ContractBlock", ptr %t22, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t39, ptr %l25, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l7, !tbaa !29
  %t47 = load i1, ptr %l3, !tbaa !21
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t51 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t51, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb15:
  store i1 false, ptr %l3, !tbaa !21
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtractItem(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb8
bb18:
  %t61 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t61, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtractItem(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 22}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t17)
  br label %bb6
bb6:
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7ff52852c0aa476c_d4838bd4ef885ee0)
  unreachable
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l77 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l111 = alloca ptr
  %l116 = alloca ptr
  %l117 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l182 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l208 = alloca { i64, ptr }
  %l218 = alloca i1
  %l219 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l234 = alloca ptr
  %l239 = alloca ptr
  %l240 = alloca i1
  %l262 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l279 = alloca i1
  %l286 = alloca ptr
  %l287 = alloca i1
  %l299 = alloca ptr
  %l300 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t2 = load ptr, ptr %l44, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l44, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 11}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l45, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l45, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [8 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb191
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t21 = load ptr, ptr %l52, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l52, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 11}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l53, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l53, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [8 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { ptr }, ptr %t31, i32 0, i32 0
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t35, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb13
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexternFn(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb191
bb15:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t42 = load ptr, ptr %l61, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = load ptr, ptr %l61, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 11}
  %t48 = icmp eq i64 %t46, 10
  store i1 %t48, ptr %l62, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l62, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [8 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t52, i32 0, i32 1
  %t54 = load %"compiler/source:Span", ptr %t53
  store %"compiler/source:Span" %t54, ptr %l4
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [8 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t58, i32 0, i32 2
  %t60 = load { i64, ptr }, ptr %t59
  store { i64, ptr } %t60, ptr %l5, !tbaa !27
  br label %bb20
bb19:
  br label %bb58
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t62, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb21
bb21:
  %t64 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t65 = load i32, ptr %t64, !tbaa !23
  %t67 = icmp sgt i32 %t65, 0
  br i1 %t67, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t69, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t71, %"compiler/source:Span" %t72)
  br label %bb25
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t75, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  %t77 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t77, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) })
  br label %bb28
bb28:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l77, !tbaa !29
  %t80 = load ptr, ptr %l77, !tbaa !29
  %t81 = getelementptr %"compiler/unparse:writer", ptr %t80, i32 0, i32 4
  %t82 = load i64, ptr %t81, !tbaa !24
  %t84 = add i64 %t82, 1
  %t86 = load ptr, ptr %l77, !tbaa !29
  %t87 = getelementptr %"compiler/unparse:writer", ptr %t86, i32 0, i32 4
  store i64 %t84, ptr %t87, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t88, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  store i64 %t92, ptr %l8, !tbaa !24
  br label %bb29
bb29:
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb30, label %bb31
bb30:
  br label %bb55
bb31:
  br label %bb32
bb32:
  %t102 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t102, ptr %l87, !tbaa !27
  %t103 = load i64, ptr %l7, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 %t103
  %t108 = load ptr, ptr %t107, !tbaa !39
  store ptr %t108, ptr %l9, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t110)
  br label %bb33
bb33:
  %t112 = load ptr, ptr %l9, !tbaa !29
  store ptr %t112, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t113 = load ptr, ptr %l91, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb34, label %bb35
bb34:
  %t116 = load ptr, ptr %l91, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 11}
  %t119 = icmp eq i64 %t117, 1
  store i1 %t119, ptr %l92, !tbaa !21
  br label %bb35
bb35:
  %t120 = load i1, ptr %l92, !tbaa !21
  br i1 %t120, label %bb36, label %bb37
bb36:
  %t121 = load ptr, ptr %l9, !tbaa !29
  %t123 = getelementptr { i64, [8 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { ptr }, ptr %t123, i32 0, i32 0
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l10, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexternFn(ptr %v0, ptr %v1, ptr %t127, ptr %t128)
  br label %bb39
bb39:
  br label %bb53
bb40:
  %t131 = load ptr, ptr %l9, !tbaa !29
  store ptr %t131, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t132 = load ptr, ptr %l99, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb41, label %bb42
bb41:
  %t135 = load ptr, ptr %l99, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 11}
  %t138 = icmp eq i64 %t136, 2
  store i1 %t138, ptr %l100, !tbaa !21
  br label %bb42
bb42:
  %t139 = load i1, ptr %l100, !tbaa !21
  br i1 %t139, label %bb43, label %bb44
bb43:
  %t140 = load ptr, ptr %l9, !tbaa !29
  %t142 = getelementptr { i64, [8 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", ptr }, ptr %t142, i32 0, i32 1
  %t144 = load ptr, ptr %t143
  store ptr %t144, ptr %l11, !tbaa !29
  br label %bb45
bb44:
  br label %bb48
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t146 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t146, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) })
  br label %bb46
bb46:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l11, !tbaa !29
  %t151 = getelementptr %"compiler/ast:TypeDecl", ptr %t149, i32 0, i32 0
  %t152 = load i32, ptr %t151, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t148, i32 %t152)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_7f8607ca82c86e8f_41d7f7ff4057cd03)
  unreachable
bb53:
  br label %bb54
bb54:
  %t155 = load i64, ptr %l7, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l7, !tbaa !24
  br label %bb29
bb55:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l111, !tbaa !29
  %t160 = load ptr, ptr %l111, !tbaa !29
  %t161 = getelementptr %"compiler/unparse:writer", ptr %t160, i32 0, i32 4
  %t162 = load i64, ptr %t161, !tbaa !24
  %t164 = sub i64 %t162, 1
  %t166 = load ptr, ptr %l111, !tbaa !29
  %t167 = getelementptr %"compiler/unparse:writer", ptr %t166, i32 0, i32 4
  store i64 %t164, ptr %t167, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t168)
  br label %bb56
bb56:
  %t170 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t170, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) })
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s3)
  br label %bb191
bb58:
  %t172 = load ptr, ptr %l1, !tbaa !29
  store ptr %t172, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t173 = load ptr, ptr %l116, !tbaa !29
  %t174 = icmp ne ptr %t173, null
  br i1 %t174, label %bb59, label %bb60
bb59:
  %t176 = load ptr, ptr %l116, !tbaa !29
  %t177 = load i64, ptr %t176, !range !{i64 0, i64 11}
  %t179 = icmp eq i64 %t177, 2
  store i1 %t179, ptr %l117, !tbaa !21
  br label %bb60
bb60:
  %t180 = load i1, ptr %l117, !tbaa !21
  br i1 %t180, label %bb61, label %bb62
bb61:
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = getelementptr { i64, [8 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", ptr }, ptr %t183, i32 0, i32 1
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l12, !tbaa !29
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %t187, ptr %t188)
  br label %bb64
bb64:
  br label %bb191
bb65:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t192 = load ptr, ptr %l124, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb66, label %bb67
bb66:
  %t195 = load ptr, ptr %l124, !tbaa !29
  %t196 = load i64, ptr %t195, !range !{i64 0, i64 11}
  %t198 = icmp eq i64 %t196, 3
  store i1 %t198, ptr %l125, !tbaa !21
  br label %bb67
bb67:
  %t199 = load i1, ptr %l125, !tbaa !21
  br i1 %t199, label %bb68, label %bb69
bb68:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [8 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", ptr }, ptr %t202, i32 0, i32 1
  %t204 = load ptr, ptr %t203
  store ptr %t204, ptr %l13, !tbaa !29
  br label %bb70
bb69:
  br label %bb75
bb70:
  %t206 = load ptr, ptr %l13, !tbaa !29
  %t208 = getelementptr %"compiler/ast:VarDecl", ptr %t206, i32 0, i32 7
  %t209 = load i1, ptr %t208, !tbaa !21
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb71, label %bb72
bb71:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t213, ptr %t214)
  br label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb74
bb74:
  br label %bb191
bb75:
  %t217 = load ptr, ptr %l1, !tbaa !29
  store ptr %t217, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t218 = load ptr, ptr %l135, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb76, label %bb77
bb76:
  %t221 = load ptr, ptr %l135, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 11}
  %t224 = icmp eq i64 %t222, 4
  store i1 %t224, ptr %l136, !tbaa !21
  br label %bb77
bb77:
  %t225 = load i1, ptr %l136, !tbaa !21
  br i1 %t225, label %bb78, label %bb79
bb78:
  %t226 = load ptr, ptr %l1, !tbaa !29
  %t228 = getelementptr { i64, [8 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" }, ptr %t228, i32 0, i32 1
  %t230 = load i32, ptr %t229
  store i32 %t230, ptr %l14, !tbaa !23
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr { i64, [8 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" }, ptr %t234, i32 0, i32 2
  %t236 = load %"compiler/source:Span", ptr %t235
  store %"compiler/source:Span" %t236, ptr %l15
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr { i64, [8 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, %"compiler/source:Span", %"compiler/source:Span" }, ptr %t240, i32 0, i32 3
  %t242 = load %"compiler/source:Span", ptr %t241
  store %"compiler/source:Span" %t242, ptr %l16
  br label %bb80
bb79:
  br label %bb93
bb80:
  store %olang.scope zeroinitializer, ptr %s14
  %t244 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t244, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb81
bb81:
  %t246 = load i32, ptr %l14, !tbaa !23
  %t248 = icmp ne i32 %t246, 0
  br i1 %t248, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s15
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t250, i32 %t251)
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t254 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s15, ptr %t254, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s15)
  br label %bb86
bb86:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l15
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t256, %"compiler/source:Span" %t257)
  br label %bb87
bb87:
  %t260 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 1
  %t261 = load i32, ptr %t260, !tbaa !23
  %t263 = icmp sgt i32 %t261, 0
  br i1 %t263, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s16
  %t265 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t265, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l16
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t267, %"compiler/source:Span" %t268)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s16)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s14)
  br label %bb191
bb93:
  %t271 = load ptr, ptr %l1, !tbaa !29
  store ptr %t271, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t272 = load ptr, ptr %l158, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb94, label %bb95
bb94:
  %t275 = load ptr, ptr %l158, !tbaa !29
  %t276 = load i64, ptr %t275, !range !{i64 0, i64 11}
  %t278 = icmp eq i64 %t276, 5
  store i1 %t278, ptr %l159, !tbaa !21
  br label %bb95
bb95:
  %t279 = load i1, ptr %l159, !tbaa !21
  br i1 %t279, label %bb96, label %bb97
bb96:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t282 = getelementptr { i64, [8 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t282, i32 0, i32 1
  %t284 = load i32, ptr %t283
  store i32 %t284, ptr %l17, !tbaa !23
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr { i64, [8 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t288, i32 0, i32 2
  %t290 = load { i64, ptr }, ptr %t289
  store { i64, ptr } %t290, ptr %l18, !tbaa !27
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr { i64, [8 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t294, i32 0, i32 3
  %t296 = load { i64, ptr }, ptr %t295
  store { i64, ptr } %t296, ptr %l19, !tbaa !27
  %t298 = load ptr, ptr %l1, !tbaa !29
  %t300 = getelementptr { i64, [8 x i64] }, ptr %t298, i32 0, i32 1
  %t301 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t300, i32 0, i32 4
  %t302 = load { i64, ptr }, ptr %t301
  store { i64, ptr } %t302, ptr %l20, !tbaa !27
  br label %bb98
bb97:
  br label %bb136
bb98:
  store %olang.scope zeroinitializer, ptr %s17
  %t304 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t304, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb99
bb99:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load i32, ptr %l17, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t306, i32 %t307)
  br label %bb100
bb100:
  %t310 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t310, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb101
bb101:
  %t312 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t312, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t314 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t314, 0
  store i64 %t316, ptr %l23, !tbaa !24
  br label %bb102
bb102:
  store %olang.scope zeroinitializer, ptr %s19
  %t318 = load i64, ptr %l22, !tbaa !24
  %t319 = load i64, ptr %l23, !tbaa !24
  %t322 = icmp slt i64 %t318, %t319
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s19)
  br label %bb112
bb104:
  br label %bb105
bb105:
  %t326 = load i64, ptr %l22, !tbaa !24
  %t328 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t328, ptr %l182, !tbaa !27
  %t329 = load i64, ptr %l22, !tbaa !24
  %t331 = getelementptr { i64, ptr }, ptr %l182, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr ptr, ptr %t332, i64 %t329
  %t334 = load ptr, ptr %t333, !tbaa !39
  store ptr %t334, ptr %l25, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l185, !tbaa !29
  %t339 = icmp sgt i64 %t326, 0
  br i1 %t339, label %bb106, label %bb107
bb106:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l188, !tbaa !27
  br label %bb108
bb107:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l188, !tbaa !27
  br label %bb108
bb108:
  %t341 = load ptr, ptr %l185, !tbaa !29
  %t342 = load { i64, ptr }, ptr %l188, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t341, { i64, ptr } %t342)
  br label %bb109
bb109:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t343, ptr %t344)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s19)
  br label %bb111
bb111:
  %t347 = load i64, ptr %l22, !tbaa !24
  %t349 = add i64 %t347, 1
  store i64 %t349, ptr %l22, !tbaa !24
  br label %bb102
bb112:
  %t351 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t353 = extractvalue { i64, ptr } %t351, 0
  %t355 = icmp sgt i64 %t353, 0
  br i1 %t355, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s21
  %t357 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t357, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb115
bb114:
  br label %bb135
bb115:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l197, !tbaa !29
  %t360 = load ptr, ptr %l197, !tbaa !29
  %t361 = getelementptr %"compiler/unparse:writer", ptr %t360, i32 0, i32 4
  %t362 = load i64, ptr %t361, !tbaa !24
  %t364 = add i64 %t362, 1
  %t366 = load ptr, ptr %l197, !tbaa !29
  %t367 = getelementptr %"compiler/unparse:writer", ptr %t366, i32 0, i32 4
  store i64 %t364, ptr %t367, !tbaa !24
  %t368 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t368, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t370 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t370, 0
  store i64 %t372, ptr %l28, !tbaa !24
  br label %bb116
bb116:
  %t374 = load i64, ptr %l27, !tbaa !24
  %t375 = load i64, ptr %l28, !tbaa !24
  %t378 = icmp slt i64 %t374, %t375
  %t380 = xor i1 %t378, true
  br i1 %t380, label %bb117, label %bb118
bb117:
  br label %bb132
bb118:
  br label %bb119
bb119:
  %t382 = load i64, ptr %l27, !tbaa !24
  store i64 %t382, ptr %l29, !tbaa !24
  %t384 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t384, ptr %l208, !tbaa !27
  %t385 = load i64, ptr %l27, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr i32, ptr %t388, i64 %t385
  %t390 = load i32, ptr %t389, !tbaa !33
  store i32 %t390, ptr %l30, !tbaa !23
  %t392 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t392)
  br label %bb120
bb120:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load i32, ptr %l30, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t394, i32 %t395)
  br label %bb121
bb121:
  %t398 = load i64, ptr %l29, !tbaa !24
  %t399 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t404 = icmp slt i64 %t398, %t401
  br i1 %t404, label %bb122, label %bb123
bb122:
  %t406 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t406, ptr %l219, !tbaa !27
  %t407 = load i64, ptr %l29, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr ptr, ptr %t410, i64 %t407
  %t412 = load ptr, ptr %t411, !tbaa !39
  %t414 = getelementptr %"compiler/ast:CaseDecl", ptr %t412, i32 0, i32 2
  %t415 = load { i64, ptr }, ptr %t414, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t415, 0
  %t419 = icmp sgt i64 %t417, 0
  store i1 %t419, ptr %l218, !tbaa !21
  br label %bb124
bb123:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb124
bb124:
  %t421 = load i1, ptr %l218, !tbaa !21
  br i1 %t421, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s24
  %t422 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t422, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb127
bb126:
  br label %bb130
bb127:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t425, ptr %l227, !tbaa !27
  %t426 = load i64, ptr %l29, !tbaa !24
  %t428 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr ptr, ptr %t429, i64 %t426
  %t431 = load ptr, ptr %t430, !tbaa !39
  %t433 = getelementptr %"compiler/ast:CaseDecl", ptr %t431, i32 0, i32 2
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t424, { i64, ptr } %t434)
  br label %bb128
bb128:
  %t437 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t437, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s24)
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t439 = load i64, ptr %l27, !tbaa !24
  %t441 = add i64 %t439, 1
  store i64 %t441, ptr %l27, !tbaa !24
  br label %bb116
bb132:
  %t443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t443, ptr %l234, !tbaa !29
  %t444 = load ptr, ptr %l234, !tbaa !29
  %t445 = getelementptr %"compiler/unparse:writer", ptr %t444, i32 0, i32 4
  %t446 = load i64, ptr %t445, !tbaa !24
  %t448 = sub i64 %t446, 1
  %t450 = load ptr, ptr %l234, !tbaa !29
  %t451 = getelementptr %"compiler/unparse:writer", ptr %t450, i32 0, i32 4
  store i64 %t448, ptr %t451, !tbaa !24
  %t452 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t452)
  br label %bb133
bb133:
  %t454 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t454, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s21)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s17)
  br label %bb191
bb136:
  %t456 = load ptr, ptr %l1, !tbaa !29
  store ptr %t456, ptr %l239, !tbaa !29
  store i1 false, ptr %l240, !tbaa !21
  %t457 = load ptr, ptr %l239, !tbaa !29
  %t458 = icmp ne ptr %t457, null
  br i1 %t458, label %bb137, label %bb138
bb137:
  %t460 = load ptr, ptr %l239, !tbaa !29
  %t461 = load i64, ptr %t460, !range !{i64 0, i64 11}
  %t463 = icmp eq i64 %t461, 6
  store i1 %t463, ptr %l240, !tbaa !21
  br label %bb138
bb138:
  %t464 = load i1, ptr %l240, !tbaa !21
  br i1 %t464, label %bb139, label %bb140
bb139:
  %t465 = load ptr, ptr %l1, !tbaa !29
  %t467 = getelementptr { i64, [8 x i64] }, ptr %t465, i32 0, i32 1
  %t468 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t467, i32 0, i32 1
  %t469 = load %"compiler/source:Span", ptr %t468
  store %"compiler/source:Span" %t469, ptr %l31
  %t471 = load ptr, ptr %l1, !tbaa !29
  %t473 = getelementptr { i64, [8 x i64] }, ptr %t471, i32 0, i32 1
  %t474 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t473, i32 0, i32 2
  %t475 = load { i64, ptr }, ptr %t474
  store { i64, ptr } %t475, ptr %l32, !tbaa !27
  %t477 = load ptr, ptr %l1, !tbaa !29
  %t479 = getelementptr { i64, [8 x i64] }, ptr %t477, i32 0, i32 1
  %t480 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t479, i32 0, i32 3
  %t481 = load ptr, ptr %t480
  store ptr %t481, ptr %l33, !tbaa !29
  br label %bb141
bb140:
  br label %bb161
bb141:
  store %olang.scope zeroinitializer, ptr %s26
  %t483 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t483, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb142
bb142:
  %t485 = load ptr, ptr %l33, !tbaa !29
  %t487 = icmp eq ptr %t485, null
  %t489 = xor i1 %t487, true
  br i1 %t489, label %bb143, label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s27
  %t491 = load ptr, ptr %l33, !tbaa !29
  %t493 = getelementptr %"compiler/ast:Path", ptr %t491, i32 0, i32 1
  %t494 = load { i64, ptr }, ptr %t493, !tbaa !27
  store { i64, ptr } %t494, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t496 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t498 = extractvalue { i64, ptr } %t496, 0
  store i64 %t498, ptr %l36, !tbaa !24
  br label %bb145
bb144:
  br label %bb157
bb145:
  %t500 = load i64, ptr %l35, !tbaa !24
  %t501 = load i64, ptr %l36, !tbaa !24
  %t504 = icmp slt i64 %t500, %t501
  %t506 = xor i1 %t504, true
  br i1 %t506, label %bb146, label %bb147
bb146:
  br label %bb155
bb147:
  br label %bb148
bb148:
  %t508 = load i64, ptr %l35, !tbaa !24
  %t510 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t510, ptr %l262, !tbaa !27
  %t511 = load i64, ptr %l35, !tbaa !24
  %t513 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t514 = load ptr, ptr %t513, !tbaa !27
  %t515 = getelementptr i32, ptr %t514, i64 %t511
  %t516 = load i32, ptr %t515, !tbaa !33
  store i32 %t516, ptr %l38, !tbaa !23
  %t520 = icmp sgt i64 %t508, 0
  br i1 %t520, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s30
  %t522 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t522, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb151
bb150:
  br label %bb152
bb151:
  call void @__olang_scope_close(ptr %s30)
  br label %bb152
bb152:
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load i32, ptr %l38, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t524, i32 %t525)
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t528 = load i64, ptr %l35, !tbaa !24
  %t530 = add i64 %t528, 1
  store i64 %t530, ptr %l35, !tbaa !24
  br label %bb145
bb155:
  %t532 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s27, ptr %t532, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s27)
  br label %bb157
bb157:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t535 = load %"compiler/source:Span", ptr %l31
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t534, %"compiler/source:Span" %t535)
  br label %bb158
bb158:
  %t538 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t538, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb159
bb159:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t541 = load { i64, ptr }, ptr %l32, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t540, { i64, ptr } %t541)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s26)
  br label %bb191
bb161:
  %t544 = load ptr, ptr %l1, !tbaa !29
  store ptr %t544, ptr %l278, !tbaa !29
  store i1 false, ptr %l279, !tbaa !21
  %t545 = load ptr, ptr %l278, !tbaa !29
  %t546 = icmp ne ptr %t545, null
  br i1 %t546, label %bb162, label %bb163
bb162:
  %t548 = load ptr, ptr %l278, !tbaa !29
  %t549 = load i64, ptr %t548, !range !{i64 0, i64 11}
  %t551 = icmp eq i64 %t549, 7
  store i1 %t551, ptr %l279, !tbaa !21
  br label %bb163
bb163:
  %t552 = load i1, ptr %l279, !tbaa !21
  br i1 %t552, label %bb164, label %bb165
bb164:
  %t553 = load ptr, ptr %l1, !tbaa !29
  %t555 = getelementptr { i64, [8 x i64] }, ptr %t553, i32 0, i32 1
  %t556 = getelementptr { %"compiler/source:Span", ptr }, ptr %t555, i32 0, i32 1
  %t557 = load ptr, ptr %t556
  store ptr %t557, ptr %l39, !tbaa !29
  br label %bb166
bb165:
  br label %bb168
bb166:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t560 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t559, ptr %t560)
  br label %bb167
bb167:
  br label %bb191
bb168:
  %t563 = load ptr, ptr %l1, !tbaa !29
  store ptr %t563, ptr %l286, !tbaa !29
  store i1 false, ptr %l287, !tbaa !21
  %t564 = load ptr, ptr %l286, !tbaa !29
  %t565 = icmp ne ptr %t564, null
  br i1 %t565, label %bb169, label %bb170
bb169:
  %t567 = load ptr, ptr %l286, !tbaa !29
  %t568 = load i64, ptr %t567, !range !{i64 0, i64 11}
  %t570 = icmp eq i64 %t568, 8
  store i1 %t570, ptr %l287, !tbaa !21
  br label %bb170
bb170:
  %t571 = load i1, ptr %l287, !tbaa !21
  br i1 %t571, label %bb171, label %bb172
bb171:
  %t572 = load ptr, ptr %l1, !tbaa !29
  %t574 = getelementptr { i64, [8 x i64] }, ptr %t572, i32 0, i32 1
  %t575 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t574, i32 0, i32 1
  %t576 = load ptr, ptr %t575
  store ptr %t576, ptr %l40, !tbaa !29
  %t578 = load ptr, ptr %l1, !tbaa !29
  %t580 = getelementptr { i64, [8 x i64] }, ptr %t578, i32 0, i32 1
  %t581 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t580, i32 0, i32 2
  %t582 = load ptr, ptr %t581
  store ptr %t582, ptr %l41, !tbaa !29
  br label %bb173
bb172:
  br label %bb177
bb173:
  store %olang.scope zeroinitializer, ptr %s33
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t584, ptr %t585)
  br label %bb174
bb174:
  %t588 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s33, ptr %t588, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb175
bb175:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t590, ptr %t591)
  br label %bb176
bb176:
  call void @__olang_scope_close(ptr %s33)
  br label %bb191
bb177:
  %t594 = load ptr, ptr %l1, !tbaa !29
  store ptr %t594, ptr %l299, !tbaa !29
  store i1 false, ptr %l300, !tbaa !21
  %t595 = load ptr, ptr %l299, !tbaa !29
  %t596 = icmp ne ptr %t595, null
  br i1 %t596, label %bb178, label %bb179
bb178:
  %t598 = load ptr, ptr %l299, !tbaa !29
  %t599 = load i64, ptr %t598, !range !{i64 0, i64 11}
  %t601 = icmp eq i64 %t599, 9
  store i1 %t601, ptr %l300, !tbaa !21
  br label %bb179
bb179:
  %t602 = load i1, ptr %l300, !tbaa !21
  br i1 %t602, label %bb180, label %bb181
bb180:
  %t603 = load ptr, ptr %l1, !tbaa !29
  %t605 = getelementptr { i64, [8 x i64] }, ptr %t603, i32 0, i32 1
  %t606 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t605, i32 0, i32 1
  %t607 = load ptr, ptr %t606
  store ptr %t607, ptr %l42, !tbaa !29
  %t609 = load ptr, ptr %l1, !tbaa !29
  %t611 = getelementptr { i64, [8 x i64] }, ptr %t609, i32 0, i32 1
  %t612 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t611, i32 0, i32 2
  %t613 = load ptr, ptr %t612
  store ptr %t613, ptr %l43, !tbaa !29
  br label %bb182
bb181:
  br label %bb190
bb182:
  store %olang.scope zeroinitializer, ptr %s34
  %t615 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s34, ptr %t615, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb183
bb183:
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t618 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t617, ptr %t618)
  br label %bb184
bb184:
  %t621 = load ptr, ptr %l43, !tbaa !29
  %t623 = icmp eq ptr %t621, null
  %t625 = xor i1 %t623, true
  br i1 %t625, label %bb185, label %bb186
bb185:
  store %olang.scope zeroinitializer, ptr %s35
  %t627 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s35, ptr %t627, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb187
bb186:
  br label %bb189
bb187:
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t630 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t629, ptr %t630)
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s35)
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s34)
  br label %bb191
bb190:
  call void @__olang_check_failed(ptr @olang_loc_47d2a5c602f98a4e_7d860b0fe2aa1b82)
  unreachable
bb191:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Sig", ptr %t10, i32 0, i32 3
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb7:
  br label %bb8
bb8:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr ptr, ptr %t33, i64 %t30
  %t35 = load ptr, ptr %t34, !tbaa !39
  store ptr %t35, ptr %l6, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l23, !tbaa !29
  %t40 = icmp sgt i64 %t27, 0
  br i1 %t40, label %bb9, label %bb10
bb9:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb11
bb10:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l23, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t42, { i64, ptr } %t43)
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb5
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca ptr
  %l110 = alloca { i64, ptr }
  %l113 = alloca i1
  %l116 = alloca i1
  %l119 = alloca i1
  %l125 = alloca i1
  %l128 = alloca i1
  %l130 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %l144 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l147 = alloca ptr
  %l148 = alloca i1
  %l160 = alloca ptr
  %l162 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l167 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l194 = alloca { i64, ptr }
  %l200 = alloca ptr
  %l202 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l212 = alloca ptr
  %l213 = alloca i1
  %l230 = alloca ptr
  %l231 = alloca i1
  %l242 = alloca ptr
  %l244 = alloca { i64, ptr }
  %l247 = alloca ptr
  %l248 = alloca i1
  %l259 = alloca ptr
  %l261 = alloca { i64, ptr }
  %l264 = alloca ptr
  %l265 = alloca i1
  %l277 = alloca ptr
  %l278 = alloca i1
  %l291 = alloca ptr
  %l292 = alloca i1
  %l305 = alloca ptr
  %l306 = alloca i1
  %l318 = alloca ptr
  %l319 = alloca i1
  %l332 = alloca ptr
  %l333 = alloca i1
  %l357 = alloca ptr
  %l358 = alloca i1
  %l365 = alloca ptr
  %l373 = alloca ptr
  %l374 = alloca i1
  %l383 = alloca ptr
  %l384 = alloca i1
  %l392 = alloca ptr
  %l422 = alloca ptr
  %l432 = alloca ptr
  %l433 = alloca i1
  %l446 = alloca { i64, ptr }
  %l456 = alloca ptr
  %l457 = alloca i1
  %l469 = alloca ptr
  %l470 = alloca i1
  %l487 = alloca ptr
  %l488 = alloca i1
  %l495 = alloca ptr
  %l496 = alloca i1
  %l504 = alloca ptr
  %l505 = alloca i1
  %l509 = alloca ptr
  %l510 = alloca i1
  %l522 = alloca ptr
  %l523 = alloca i1
  %l535 = alloca ptr
  %l536 = alloca i1
  %l545 = alloca i1
  %l549 = alloca ptr
  %l550 = alloca i1
  %l563 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s52 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t2 = load ptr, ptr %l69, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l69, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l70, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l70, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t16, i32 %t17)
  br label %bb6
bb6:
  br label %bb373
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t21 = load ptr, ptr %l77, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l77, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 30}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l78, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l78, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32 }, ptr %t31, i32 0, i32 0
  %t33 = load %"compiler/source:Span", ptr %t32
  store %"compiler/source:Span" %t33, ptr %l3
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t35, %"compiler/source:Span" %t36)
  br label %bb13
bb13:
  br label %bb373
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t40 = load ptr, ptr %l85, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l85, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 30}
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l86, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l86, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb23
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t54, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) })
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/unparse:writer", ptr %t56, i32 0, i32 6
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l5, !tbaa !21
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/unparse:writer", ptr %t61, i32 0, i32 6
  store i1 false, ptr %t63, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  br label %bb21
bb21:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i1, ptr %l5, !tbaa !21
  %t72 = getelementptr %"compiler/unparse:writer", ptr %t68, i32 0, i32 6
  store i1 %t69, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t73, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb373
bb23:
  %t75 = load ptr, ptr %l1, !tbaa !29
  store ptr %t75, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t76 = load ptr, ptr %l100, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l100, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 30}
  %t82 = icmp eq i64 %t80, 3
  store i1 %t82, ptr %l101, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l101, !tbaa !21
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87, !range !{i32 0, i32 98}
  store i32 %t88, ptr %l6
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb56
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l108, !tbaa !29
  %t97 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t99 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t97)
  store { i64, ptr } %t99, ptr %l110
  br label %bb29
bb29:
  %t100 = load ptr, ptr %l108, !tbaa !29
  %t101 = load { i64, ptr }, ptr %l110, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t100, { i64, ptr } %t101)
  br label %bb30
bb30:
  %t102 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t104 = trunc i64 48 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb33
bb32:
  %t107 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t109 = trunc i64 13 to i32
  %t110 = icmp eq i32 %t107, %t109
  store i1 %t110, ptr %l113, !tbaa !21
  br label %bb33
bb33:
  %t112 = load i1, ptr %l113, !tbaa !21
  br i1 %t112, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb36
bb35:
  %t113 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t115 = trunc i64 18 to i32
  %t116 = icmp eq i32 %t113, %t115
  store i1 %t116, ptr %l116, !tbaa !21
  br label %bb36
bb36:
  %t118 = load i1, ptr %l116, !tbaa !21
  br i1 %t118, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb39
bb38:
  %t119 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t121 = trunc i64 51 to i32
  %t122 = icmp eq i32 %t119, %t121
  store i1 %t122, ptr %l119, !tbaa !21
  br label %bb39
bb39:
  %t124 = load i1, ptr %l119, !tbaa !21
  br i1 %t124, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s5
  %t125 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t125, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb42
bb41:
  %t127 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t129 = trunc i64 53 to i32
  %t130 = icmp eq i32 %t127, %t129
  br i1 %t130, label %bb43, label %bb44
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb54
bb43:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb45
bb44:
  %t132 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t134 = trunc i64 77 to i32
  %t135 = icmp eq i32 %t132, %t134
  store i1 %t135, ptr %l125, !tbaa !21
  br label %bb45
bb45:
  %t137 = load i1, ptr %l125, !tbaa !21
  br i1 %t137, label %bb46, label %bb47
bb46:
  %t138 = load ptr, ptr %l7, !tbaa !29
  %t140 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v1, ptr %t138)
  store i1 %t140, ptr %l130
  br label %bb48
bb47:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb49
bb48:
  %t141 = load i1, ptr %l130, !tbaa !21
  store i1 %t141, ptr %l128, !tbaa !21
  br label %bb49
bb49:
  %t142 = load i1, ptr %l128, !tbaa !21
  br i1 %t142, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s7
  %t143 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t143, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s4)
  br label %bb373
bb56:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t150 = load ptr, ptr %l134, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb57, label %bb58
bb57:
  %t153 = load ptr, ptr %l134, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 30}
  %t156 = icmp eq i64 %t154, 4
  store i1 %t156, ptr %l135, !tbaa !21
  br label %bb58
bb58:
  %t157 = load i1, ptr %l135, !tbaa !21
  br i1 %t157, label %bb59, label %bb60
bb59:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t160, i32 0, i32 1
  %t162 = load i32, ptr %t161, !range !{i32 0, i32 98}
  store i32 %t162, ptr %l8
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 2
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l9, !tbaa !29
  br label %bb61
bb60:
  br label %bb65
bb61:
  store %olang.scope zeroinitializer, ptr %s8
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t170, ptr %t171)
  br label %bb62
bb62:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l144, !tbaa !29
  %t175 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t177 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t175)
  store { i64, ptr } %t177, ptr %l146
  br label %bb63
bb63:
  %t178 = load ptr, ptr %l144, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l146, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t178, { i64, ptr } %t179)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s8)
  br label %bb373
bb65:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t181 = load ptr, ptr %l147, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb66, label %bb67
bb66:
  %t184 = load ptr, ptr %l147, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 30}
  %t187 = icmp eq i64 %t185, 5
  store i1 %t187, ptr %l148, !tbaa !21
  br label %bb67
bb67:
  %t188 = load i1, ptr %l148, !tbaa !21
  br i1 %t188, label %bb68, label %bb69
bb68:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t191, i32 0, i32 1
  %t193 = load i32, ptr %t192, !range !{i32 0, i32 98}
  store i32 %t193, ptr %l10
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t197, i32 0, i32 2
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l11, !tbaa !29
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t203, i32 0, i32 3
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l12, !tbaa !29
  br label %bb70
bb69:
  br label %bb77
bb70:
  store %olang.scope zeroinitializer, ptr %s9
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t207, ptr %t208)
  br label %bb71
bb71:
  %t211 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t211, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb72
bb72:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l160, !tbaa !29
  %t214 = load i32, ptr %l10, !range !{i32 0, i32 98}
  %t216 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t214)
  store { i64, ptr } %t216, ptr %l162
  br label %bb73
bb73:
  %t217 = load ptr, ptr %l160, !tbaa !29
  %t218 = load { i64, ptr }, ptr %l162, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t217, { i64, ptr } %t218)
  br label %bb74
bb74:
  %t219 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t219, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb75
bb75:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t221, ptr %t222)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s9)
  br label %bb373
bb77:
  %t225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t225, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t226 = load ptr, ptr %l166, !tbaa !29
  %t227 = icmp ne ptr %t226, null
  br i1 %t227, label %bb78, label %bb79
bb78:
  %t229 = load ptr, ptr %l166, !tbaa !29
  %t230 = load i64, ptr %t229, !range !{i64 0, i64 30}
  %t232 = icmp eq i64 %t230, 6
  store i1 %t232, ptr %l167, !tbaa !21
  br label %bb79
bb79:
  %t233 = load i1, ptr %l167, !tbaa !21
  br i1 %t233, label %bb80, label %bb81
bb80:
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t236 = getelementptr { i64, [4 x i64] }, ptr %t234, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t236, i32 0, i32 1
  %t238 = load ptr, ptr %t237
  store ptr %t238, ptr %l13, !tbaa !29
  %t240 = load ptr, ptr %l1, !tbaa !29
  %t242 = getelementptr { i64, [4 x i64] }, ptr %t240, i32 0, i32 1
  %t243 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t242, i32 0, i32 2
  %t244 = load ptr, ptr %t243
  store ptr %t244, ptr %l14, !tbaa !29
  br label %bb82
bb81:
  br label %bb86
bb82:
  store %olang.scope zeroinitializer, ptr %s10
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t246, ptr %t247)
  br label %bb83
bb83:
  %t250 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t250, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d53, i32 0, i32 1) })
  br label %bb84
bb84:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t252, ptr %t253)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s10)
  br label %bb373
bb86:
  %t256 = load ptr, ptr %l1, !tbaa !29
  store ptr %t256, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t257 = load ptr, ptr %l179, !tbaa !29
  %t258 = icmp ne ptr %t257, null
  br i1 %t258, label %bb87, label %bb88
bb87:
  %t260 = load ptr, ptr %l179, !tbaa !29
  %t261 = load i64, ptr %t260, !range !{i64 0, i64 30}
  %t263 = icmp eq i64 %t261, 7
  store i1 %t263, ptr %l180, !tbaa !21
  br label %bb88
bb88:
  %t264 = load i1, ptr %l180, !tbaa !21
  br i1 %t264, label %bb89, label %bb90
bb89:
  %t265 = load ptr, ptr %l1, !tbaa !29
  %t267 = getelementptr { i64, [4 x i64] }, ptr %t265, i32 0, i32 1
  %t268 = getelementptr { %"compiler/source:Span", ptr }, ptr %t267, i32 0, i32 1
  %t269 = load ptr, ptr %t268
  store ptr %t269, ptr %l15, !tbaa !29
  br label %bb91
bb90:
  br label %bb106
bb91:
  %t271 = load ptr, ptr %l15, !tbaa !29
  %t273 = getelementptr %"compiler/ast:Chain", ptr %t271, i32 0, i32 1
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  store { i64, ptr } %t274, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t276, 0
  store i64 %t278, ptr %l18, !tbaa !24
  br label %bb92
bb92:
  %t280 = load i64, ptr %l17, !tbaa !24
  %t281 = load i64, ptr %l18, !tbaa !24
  %t284 = icmp slt i64 %t280, %t281
  %t286 = xor i1 %t284, true
  br i1 %t286, label %bb93, label %bb94
bb93:
  br label %bb105
bb94:
  br label %bb95
bb95:
  %t288 = load i64, ptr %l17, !tbaa !24
  store i64 %t288, ptr %l19, !tbaa !24
  %t290 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t290, ptr %l194, !tbaa !27
  %t291 = load i64, ptr %l17, !tbaa !24
  %t293 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr ptr, ptr %t294, i64 %t291
  %t296 = load ptr, ptr %t295, !tbaa !39
  store ptr %t296, ptr %l20, !tbaa !29
  %t298 = load i64, ptr %l19, !tbaa !24
  %t300 = icmp sgt i64 %t298, 0
  br i1 %t300, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s14
  %t302 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t302, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) })
  br label %bb98
bb97:
  br label %bb102
bb98:
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l200, !tbaa !29
  %t305 = load ptr, ptr %l15, !tbaa !29
  %t307 = getelementptr %"compiler/ast:Chain", ptr %t305, i32 0, i32 0
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  store { i64, ptr } %t308, ptr %l202, !tbaa !27
  %t309 = load i64, ptr %l19, !tbaa !24
  %t311 = sub i64 %t309, 1
  %t313 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr i32, ptr %t314, i64 %t311
  %t316 = load i32, ptr %t315, !range !{i32 0, i32 98}
  %t318 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s14, i32 %t316)
  store { i64, ptr } %t318, ptr %l206
  br label %bb99
bb99:
  %t319 = load ptr, ptr %l200, !tbaa !29
  %t320 = load { i64, ptr }, ptr %l206, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t319, { i64, ptr } %t320)
  br label %bb100
bb100:
  %t321 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t321, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) })
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s14)
  br label %bb102
bb102:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t323, ptr %t324)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t327 = load i64, ptr %l17, !tbaa !24
  %t329 = add i64 %t327, 1
  store i64 %t329, ptr %l17, !tbaa !24
  br label %bb92
bb105:
  br label %bb373
bb106:
  %t331 = load ptr, ptr %l1, !tbaa !29
  store ptr %t331, ptr %l212, !tbaa !29
  store i1 false, ptr %l213, !tbaa !21
  %t332 = load ptr, ptr %l212, !tbaa !29
  %t333 = icmp ne ptr %t332, null
  br i1 %t333, label %bb107, label %bb108
bb107:
  %t335 = load ptr, ptr %l212, !tbaa !29
  %t336 = load i64, ptr %t335, !range !{i64 0, i64 30}
  %t338 = icmp eq i64 %t336, 8
  store i1 %t338, ptr %l213, !tbaa !21
  br label %bb108
bb108:
  %t339 = load i1, ptr %l213, !tbaa !21
  br i1 %t339, label %bb109, label %bb110
bb109:
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr { i64, [4 x i64] }, ptr %t340, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t342, i32 0, i32 1
  %t344 = load ptr, ptr %t343
  store ptr %t344, ptr %l21, !tbaa !29
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t348 = getelementptr { i64, [4 x i64] }, ptr %t346, i32 0, i32 1
  %t349 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t348, i32 0, i32 2
  %t350 = load ptr, ptr %t349
  store ptr %t350, ptr %l22, !tbaa !29
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t354 = getelementptr { i64, [4 x i64] }, ptr %t352, i32 0, i32 1
  %t355 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t354, i32 0, i32 3
  %t356 = load ptr, ptr %t355
  store ptr %t356, ptr %l23, !tbaa !29
  br label %bb111
bb110:
  br label %bb117
bb111:
  store %olang.scope zeroinitializer, ptr %s16
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t358, ptr %t359)
  br label %bb112
bb112:
  %t362 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t362, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) })
  br label %bb113
bb113:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t364, ptr %t365)
  br label %bb114
bb114:
  %t368 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t368, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb115
bb115:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t370, ptr %t371)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s16)
  br label %bb373
bb117:
  %t374 = load ptr, ptr %l1, !tbaa !29
  store ptr %t374, ptr %l230, !tbaa !29
  store i1 false, ptr %l231, !tbaa !21
  %t375 = load ptr, ptr %l230, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb118, label %bb119
bb118:
  %t378 = load ptr, ptr %l230, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 30}
  %t381 = icmp eq i64 %t379, 9
  store i1 %t381, ptr %l231, !tbaa !21
  br label %bb119
bb119:
  %t382 = load i1, ptr %l231, !tbaa !21
  br i1 %t382, label %bb120, label %bb121
bb120:
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = getelementptr { i64, [4 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t385, i32 0, i32 1
  %t387 = load ptr, ptr %t386
  store ptr %t387, ptr %l24, !tbaa !29
  %t389 = load ptr, ptr %l1, !tbaa !29
  %t391 = getelementptr { i64, [4 x i64] }, ptr %t389, i32 0, i32 1
  %t392 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t391, i32 0, i32 2
  %t393 = load ptr, ptr %t392
  store ptr %t393, ptr %l25, !tbaa !29
  %t395 = load ptr, ptr %l1, !tbaa !29
  %t397 = getelementptr { i64, [4 x i64] }, ptr %t395, i32 0, i32 1
  %t398 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t397, i32 0, i32 3
  %t399 = load i1, ptr %t398
  store i1 %t399, ptr %l26, !tbaa !21
  br label %bb122
bb121:
  br label %bb129
bb122:
  store %olang.scope zeroinitializer, ptr %s17
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t401, ptr %t402)
  br label %bb123
bb123:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l242, !tbaa !29
  %t406 = load i1, ptr %l26, !tbaa !21
  br i1 %t406, label %bb124, label %bb125
bb124:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l244, !tbaa !27
  br label %bb126
bb125:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l244, !tbaa !27
  br label %bb126
bb126:
  %t408 = load ptr, ptr %l242, !tbaa !29
  %t409 = load { i64, ptr }, ptr %l244, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t408, { i64, ptr } %t409)
  br label %bb127
bb127:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t410, ptr %t411)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s17)
  br label %bb373
bb129:
  %t414 = load ptr, ptr %l1, !tbaa !29
  store ptr %t414, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t415 = load ptr, ptr %l247, !tbaa !29
  %t416 = icmp ne ptr %t415, null
  br i1 %t416, label %bb130, label %bb131
bb130:
  %t418 = load ptr, ptr %l247, !tbaa !29
  %t419 = load i64, ptr %t418, !range !{i64 0, i64 30}
  %t421 = icmp eq i64 %t419, 10
  store i1 %t421, ptr %l248, !tbaa !21
  br label %bb131
bb131:
  %t422 = load i1, ptr %l248, !tbaa !21
  br i1 %t422, label %bb132, label %bb133
bb132:
  %t423 = load ptr, ptr %l1, !tbaa !29
  %t425 = getelementptr { i64, [4 x i64] }, ptr %t423, i32 0, i32 1
  %t426 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t425, i32 0, i32 1
  %t427 = load ptr, ptr %t426
  store ptr %t427, ptr %l27, !tbaa !29
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr { i64, [4 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t431, i32 0, i32 2
  %t433 = load ptr, ptr %t432
  store ptr %t433, ptr %l28, !tbaa !29
  %t435 = load ptr, ptr %l1, !tbaa !29
  %t437 = getelementptr { i64, [4 x i64] }, ptr %t435, i32 0, i32 1
  %t438 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t437, i32 0, i32 3
  %t439 = load i1, ptr %t438
  store i1 %t439, ptr %l29, !tbaa !21
  br label %bb134
bb133:
  br label %bb141
bb134:
  store %olang.scope zeroinitializer, ptr %s18
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t441, ptr %t442)
  br label %bb135
bb135:
  %t445 = load ptr, ptr %l0, !tbaa !29
  store ptr %t445, ptr %l259, !tbaa !29
  %t446 = load i1, ptr %l29, !tbaa !21
  br i1 %t446, label %bb136, label %bb137
bb136:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l261, !tbaa !27
  br label %bb138
bb137:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l261, !tbaa !27
  br label %bb138
bb138:
  %t448 = load ptr, ptr %l259, !tbaa !29
  %t449 = load { i64, ptr }, ptr %l261, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t448, { i64, ptr } %t449)
  br label %bb139
bb139:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t450, ptr %t451)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s18)
  br label %bb373
bb141:
  %t454 = load ptr, ptr %l1, !tbaa !29
  store ptr %t454, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t455 = load ptr, ptr %l264, !tbaa !29
  %t456 = icmp ne ptr %t455, null
  br i1 %t456, label %bb142, label %bb143
bb142:
  %t458 = load ptr, ptr %l264, !tbaa !29
  %t459 = load i64, ptr %t458, !range !{i64 0, i64 30}
  %t461 = icmp eq i64 %t459, 11
  store i1 %t461, ptr %l265, !tbaa !21
  br label %bb143
bb143:
  %t462 = load i1, ptr %l265, !tbaa !21
  br i1 %t462, label %bb144, label %bb145
bb144:
  %t463 = load ptr, ptr %l1, !tbaa !29
  %t465 = getelementptr { i64, [4 x i64] }, ptr %t463, i32 0, i32 1
  %t466 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t465, i32 0, i32 1
  %t467 = load ptr, ptr %t466
  store ptr %t467, ptr %l30, !tbaa !29
  %t469 = load ptr, ptr %l1, !tbaa !29
  %t471 = getelementptr { i64, [4 x i64] }, ptr %t469, i32 0, i32 1
  %t472 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t471, i32 0, i32 2
  %t473 = load ptr, ptr %t472
  store ptr %t473, ptr %l31, !tbaa !29
  br label %bb146
bb145:
  br label %bb150
bb146:
  store %olang.scope zeroinitializer, ptr %s19
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t475, ptr %t476)
  br label %bb147
bb147:
  %t479 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t479, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d62, i32 0, i32 1) })
  br label %bb148
bb148:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t481, ptr %t482)
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s19)
  br label %bb373
bb150:
  %t485 = load ptr, ptr %l1, !tbaa !29
  store ptr %t485, ptr %l277, !tbaa !29
  store i1 false, ptr %l278, !tbaa !21
  %t486 = load ptr, ptr %l277, !tbaa !29
  %t487 = icmp ne ptr %t486, null
  br i1 %t487, label %bb151, label %bb152
bb151:
  %t489 = load ptr, ptr %l277, !tbaa !29
  %t490 = load i64, ptr %t489, !range !{i64 0, i64 30}
  %t492 = icmp eq i64 %t490, 12
  store i1 %t492, ptr %l278, !tbaa !21
  br label %bb152
bb152:
  %t493 = load i1, ptr %l278, !tbaa !21
  br i1 %t493, label %bb153, label %bb154
bb153:
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t496 = getelementptr { i64, [4 x i64] }, ptr %t494, i32 0, i32 1
  %t497 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t496, i32 0, i32 1
  %t498 = load ptr, ptr %t497
  store ptr %t498, ptr %l32, !tbaa !29
  %t500 = load ptr, ptr %l1, !tbaa !29
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t500, i32 0, i32 1
  %t503 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t502, i32 0, i32 2
  %t504 = load { i64, ptr }, ptr %t503
  store { i64, ptr } %t504, ptr %l33, !tbaa !27
  br label %bb155
bb154:
  br label %bb160
bb155:
  store %olang.scope zeroinitializer, ptr %s20
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t506, ptr %t507)
  br label %bb156
bb156:
  %t510 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t510, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) })
  br label %bb157
bb157:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t513 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t512, { i64, ptr } %t513)
  br label %bb158
bb158:
  %t516 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t516, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s20)
  br label %bb373
bb160:
  %t518 = load ptr, ptr %l1, !tbaa !29
  store ptr %t518, ptr %l291, !tbaa !29
  store i1 false, ptr %l292, !tbaa !21
  %t519 = load ptr, ptr %l291, !tbaa !29
  %t520 = icmp ne ptr %t519, null
  br i1 %t520, label %bb161, label %bb162
bb161:
  %t522 = load ptr, ptr %l291, !tbaa !29
  %t523 = load i64, ptr %t522, !range !{i64 0, i64 30}
  %t525 = icmp eq i64 %t523, 13
  store i1 %t525, ptr %l292, !tbaa !21
  br label %bb162
bb162:
  %t526 = load i1, ptr %l292, !tbaa !21
  br i1 %t526, label %bb163, label %bb164
bb163:
  %t527 = load ptr, ptr %l1, !tbaa !29
  %t529 = getelementptr { i64, [4 x i64] }, ptr %t527, i32 0, i32 1
  %t530 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t529, i32 0, i32 1
  %t531 = load ptr, ptr %t530
  store ptr %t531, ptr %l34, !tbaa !29
  %t533 = load ptr, ptr %l1, !tbaa !29
  %t535 = getelementptr { i64, [4 x i64] }, ptr %t533, i32 0, i32 1
  %t536 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t535, i32 0, i32 2
  %t537 = load { i64, ptr }, ptr %t536
  store { i64, ptr } %t537, ptr %l35, !tbaa !27
  br label %bb165
bb164:
  br label %bb170
bb165:
  store %olang.scope zeroinitializer, ptr %s21
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t539, ptr %t540)
  br label %bb166
bb166:
  %t543 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t543, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) })
  br label %bb167
bb167:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load { i64, ptr }, ptr %l35, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t545, { i64, ptr } %t546)
  br label %bb168
bb168:
  %t549 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t549, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb169
bb169:
  call void @__olang_scope_close(ptr %s21)
  br label %bb373
bb170:
  %t551 = load ptr, ptr %l1, !tbaa !29
  store ptr %t551, ptr %l305, !tbaa !29
  store i1 false, ptr %l306, !tbaa !21
  %t552 = load ptr, ptr %l305, !tbaa !29
  %t553 = icmp ne ptr %t552, null
  br i1 %t553, label %bb171, label %bb172
bb171:
  %t555 = load ptr, ptr %l305, !tbaa !29
  %t556 = load i64, ptr %t555, !range !{i64 0, i64 30}
  %t558 = icmp eq i64 %t556, 14
  store i1 %t558, ptr %l306, !tbaa !21
  br label %bb172
bb172:
  %t559 = load i1, ptr %l306, !tbaa !21
  br i1 %t559, label %bb173, label %bb174
bb173:
  %t560 = load ptr, ptr %l1, !tbaa !29
  %t562 = getelementptr { i64, [4 x i64] }, ptr %t560, i32 0, i32 1
  %t563 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t562, i32 0, i32 1
  %t564 = load ptr, ptr %t563
  store ptr %t564, ptr %l36, !tbaa !29
  %t566 = load ptr, ptr %l1, !tbaa !29
  %t568 = getelementptr { i64, [4 x i64] }, ptr %t566, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t568, i32 0, i32 2
  %t570 = load i32, ptr %t569
  store i32 %t570, ptr %l37, !tbaa !23
  br label %bb175
bb174:
  br label %bb179
bb175:
  store %olang.scope zeroinitializer, ptr %s22
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t573 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t572, ptr %t573)
  br label %bb176
bb176:
  %t576 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t576, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) })
  br label %bb177
bb177:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load i32, ptr %l37, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t578, i32 %t579)
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s22)
  br label %bb373
bb179:
  %t582 = load ptr, ptr %l1, !tbaa !29
  store ptr %t582, ptr %l318, !tbaa !29
  store i1 false, ptr %l319, !tbaa !21
  %t583 = load ptr, ptr %l318, !tbaa !29
  %t584 = icmp ne ptr %t583, null
  br i1 %t584, label %bb180, label %bb181
bb180:
  %t586 = load ptr, ptr %l318, !tbaa !29
  %t587 = load i64, ptr %t586, !range !{i64 0, i64 30}
  %t589 = icmp eq i64 %t587, 15
  store i1 %t589, ptr %l319, !tbaa !21
  br label %bb181
bb181:
  %t590 = load i1, ptr %l319, !tbaa !21
  br i1 %t590, label %bb182, label %bb183
bb182:
  %t591 = load ptr, ptr %l1, !tbaa !29
  %t593 = getelementptr { i64, [4 x i64] }, ptr %t591, i32 0, i32 1
  %t594 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t593, i32 0, i32 1
  %t595 = load ptr, ptr %t594
  store ptr %t595, ptr %l38, !tbaa !29
  %t597 = load ptr, ptr %l1, !tbaa !29
  %t599 = getelementptr { i64, [4 x i64] }, ptr %t597, i32 0, i32 1
  %t600 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t599, i32 0, i32 2
  %t601 = load { i64, ptr }, ptr %t600
  store { i64, ptr } %t601, ptr %l39, !tbaa !27
  br label %bb184
bb183:
  br label %bb189
bb184:
  store %olang.scope zeroinitializer, ptr %s23
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t603, ptr %t604)
  br label %bb185
bb185:
  %t607 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t607, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) })
  br label %bb186
bb186:
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t610 = load { i64, ptr }, ptr %l39, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t609, { i64, ptr } %t610)
  br label %bb187
bb187:
  %t613 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t613, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) })
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s23)
  br label %bb373
bb189:
  %t615 = load ptr, ptr %l1, !tbaa !29
  store ptr %t615, ptr %l332, !tbaa !29
  store i1 false, ptr %l333, !tbaa !21
  %t616 = load ptr, ptr %l332, !tbaa !29
  %t617 = icmp ne ptr %t616, null
  br i1 %t617, label %bb190, label %bb191
bb190:
  %t619 = load ptr, ptr %l332, !tbaa !29
  %t620 = load i64, ptr %t619, !range !{i64 0, i64 30}
  %t622 = icmp eq i64 %t620, 16
  store i1 %t622, ptr %l333, !tbaa !21
  br label %bb191
bb191:
  %t623 = load i1, ptr %l333, !tbaa !21
  br i1 %t623, label %bb192, label %bb193
bb192:
  %t624 = load ptr, ptr %l1, !tbaa !29
  %t626 = getelementptr { i64, [4 x i64] }, ptr %t624, i32 0, i32 1
  %t627 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t626, i32 0, i32 1
  %t628 = load ptr, ptr %t627
  store ptr %t628, ptr %l40, !tbaa !29
  %t630 = load ptr, ptr %l1, !tbaa !29
  %t632 = getelementptr { i64, [4 x i64] }, ptr %t630, i32 0, i32 1
  %t633 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t632, i32 0, i32 2
  %t634 = load ptr, ptr %t633
  store ptr %t634, ptr %l41, !tbaa !29
  %t636 = load ptr, ptr %l1, !tbaa !29
  %t638 = getelementptr { i64, [4 x i64] }, ptr %t636, i32 0, i32 1
  %t639 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t638, i32 0, i32 3
  %t640 = load ptr, ptr %t639
  store ptr %t640, ptr %l42, !tbaa !29
  br label %bb194
bb193:
  br label %bb207
bb194:
  store %olang.scope zeroinitializer, ptr %s24
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load ptr, ptr %l40, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t642, ptr %t643)
  br label %bb195
bb195:
  %t646 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t646, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) })
  br label %bb196
bb196:
  %t648 = load ptr, ptr %l41, !tbaa !29
  %t650 = icmp eq ptr %t648, null
  %t652 = xor i1 %t650, true
  br i1 %t652, label %bb197, label %bb198
bb197:
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t655 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t654, ptr %t655)
  br label %bb199
bb198:
  br label %bb200
bb199:
  br label %bb200
bb200:
  %t658 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t658, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) })
  br label %bb201
bb201:
  %t660 = load ptr, ptr %l42, !tbaa !29
  %t662 = icmp eq ptr %t660, null
  %t664 = xor i1 %t662, true
  br i1 %t664, label %bb202, label %bb203
bb202:
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t667 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t666, ptr %t667)
  br label %bb204
bb203:
  br label %bb205
bb204:
  br label %bb205
bb205:
  %t670 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t670, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) })
  br label %bb206
bb206:
  call void @__olang_scope_close(ptr %s24)
  br label %bb373
bb207:
  %t672 = load ptr, ptr %l1, !tbaa !29
  store ptr %t672, ptr %l357, !tbaa !29
  store i1 false, ptr %l358, !tbaa !21
  %t673 = load ptr, ptr %l357, !tbaa !29
  %t674 = icmp ne ptr %t673, null
  br i1 %t674, label %bb208, label %bb209
bb208:
  %t676 = load ptr, ptr %l357, !tbaa !29
  %t677 = load i64, ptr %t676, !range !{i64 0, i64 30}
  %t679 = icmp eq i64 %t677, 17
  store i1 %t679, ptr %l358, !tbaa !21
  br label %bb209
bb209:
  %t680 = load i1, ptr %l358, !tbaa !21
  br i1 %t680, label %bb210, label %bb211
bb210:
  %t681 = load ptr, ptr %l1, !tbaa !29
  %t683 = getelementptr { i64, [4 x i64] }, ptr %t681, i32 0, i32 1
  %t684 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t683, i32 0, i32 1
  %t685 = load ptr, ptr %t684
  store ptr %t685, ptr %l43, !tbaa !29
  %t687 = load ptr, ptr %l1, !tbaa !29
  %t689 = getelementptr { i64, [4 x i64] }, ptr %t687, i32 0, i32 1
  %t690 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t689, i32 0, i32 2
  %t691 = load { i64, ptr }, ptr %t690
  store { i64, ptr } %t691, ptr %l44, !tbaa !27
  br label %bb212
bb211:
  br label %bb220
bb212:
  store %olang.scope zeroinitializer, ptr %s27
  %t693 = load ptr, ptr %l0, !tbaa !29
  store ptr %t693, ptr %l365, !tbaa !29
  %t694 = load ptr, ptr %l43, !tbaa !29
  %t696 = icmp eq ptr %t694, null
  br i1 %t696, label %bb213, label %bb214
bb213:
  call void @__olang_check_failed(ptr @olang_loc_577bb2401887ee03_bd83bee27b444ed7)
  unreachable
bb214:
  br label %bb215
bb215:
  %t698 = load ptr, ptr %l43, !tbaa !29
  %t699 = load ptr, ptr %l365, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t699, ptr %t698)
  br label %bb216
bb216:
  %t701 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s27, ptr %t701, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) })
  br label %bb217
bb217:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load { i64, ptr }, ptr %l44, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t703, { i64, ptr } %t704)
  br label %bb218
bb218:
  %t707 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s27, ptr %t707, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) })
  br label %bb219
bb219:
  call void @__olang_scope_close(ptr %s27)
  br label %bb373
bb220:
  %t709 = load ptr, ptr %l1, !tbaa !29
  store ptr %t709, ptr %l373, !tbaa !29
  store i1 false, ptr %l374, !tbaa !21
  %t710 = load ptr, ptr %l373, !tbaa !29
  %t711 = icmp ne ptr %t710, null
  br i1 %t711, label %bb221, label %bb222
bb221:
  %t713 = load ptr, ptr %l373, !tbaa !29
  %t714 = load i64, ptr %t713, !range !{i64 0, i64 30}
  %t716 = icmp eq i64 %t714, 18
  store i1 %t716, ptr %l374, !tbaa !21
  br label %bb222
bb222:
  %t717 = load i1, ptr %l374, !tbaa !21
  br i1 %t717, label %bb223, label %bb224
bb223:
  %t718 = load ptr, ptr %l1, !tbaa !29
  %t720 = getelementptr { i64, [4 x i64] }, ptr %t718, i32 0, i32 1
  %t721 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t720, i32 0, i32 1
  %t722 = load { i64, ptr }, ptr %t721
  store { i64, ptr } %t722, ptr %l45, !tbaa !27
  br label %bb225
bb224:
  br label %bb229
bb225:
  store %olang.scope zeroinitializer, ptr %s28
  %t724 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t724, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  br label %bb226
bb226:
  %t726 = load ptr, ptr %l0, !tbaa !29
  %t727 = load { i64, ptr }, ptr %l45, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t726, { i64, ptr } %t727)
  br label %bb227
bb227:
  %t730 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t730, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) })
  br label %bb228
bb228:
  call void @__olang_scope_close(ptr %s28)
  br label %bb373
bb229:
  %t732 = load ptr, ptr %l1, !tbaa !29
  store ptr %t732, ptr %l383, !tbaa !29
  store i1 false, ptr %l384, !tbaa !21
  %t733 = load ptr, ptr %l383, !tbaa !29
  %t734 = icmp ne ptr %t733, null
  br i1 %t734, label %bb230, label %bb231
bb230:
  %t736 = load ptr, ptr %l383, !tbaa !29
  %t737 = load i64, ptr %t736, !range !{i64 0, i64 30}
  %t739 = icmp eq i64 %t737, 19
  store i1 %t739, ptr %l384, !tbaa !21
  br label %bb231
bb231:
  %t740 = load i1, ptr %l384, !tbaa !21
  br i1 %t740, label %bb232, label %bb233
bb232:
  %t741 = load ptr, ptr %l1, !tbaa !29
  %t743 = getelementptr { i64, [4 x i64] }, ptr %t741, i32 0, i32 1
  %t744 = getelementptr { %"compiler/source:Span", ptr }, ptr %t743, i32 0, i32 1
  %t745 = load ptr, ptr %t744
  store ptr %t745, ptr %l46, !tbaa !29
  br label %bb234
bb233:
  br label %bb265
bb234:
  store %olang.scope zeroinitializer, ptr %s29
  %t747 = load ptr, ptr %l46, !tbaa !29
  %t749 = getelementptr %"compiler/ast:Compr", ptr %t747, i32 0, i32 6
  %t750 = load i1, ptr %t749, !tbaa !21
  %t752 = xor i1 %t750, true
  br i1 %t752, label %bb235, label %bb236
bb235:
  store %olang.scope zeroinitializer, ptr %s30
  %t754 = load ptr, ptr %l0, !tbaa !29
  store ptr %t754, ptr %l392, !tbaa !29
  %t755 = load ptr, ptr %l46, !tbaa !29
  %t757 = getelementptr %"compiler/ast:Compr", ptr %t755, i32 0, i32 0
  %t758 = load ptr, ptr %t757, !tbaa !29
  %t760 = icmp eq ptr %t758, null
  br i1 %t760, label %bb237, label %bb238
bb236:
  br label %bb242
bb237:
  call void @__olang_check_failed(ptr @olang_loc_47b511f5ef6d9e74_baf04e552c3da2b8)
  unreachable
bb238:
  br label %bb239
bb239:
  %t762 = load ptr, ptr %l46, !tbaa !29
  %t764 = getelementptr %"compiler/ast:Compr", ptr %t762, i32 0, i32 0
  %t765 = load ptr, ptr %t764, !tbaa !29
  %t766 = load ptr, ptr %l392, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t766, ptr %t765)
  br label %bb240
bb240:
  %t768 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t768, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) })
  br label %bb241
bb241:
  call void @__olang_scope_close(ptr %s30)
  br label %bb242
bb242:
  %t770 = load ptr, ptr %l0, !tbaa !29
  %t771 = load ptr, ptr %l46, !tbaa !29
  %t773 = getelementptr %"compiler/ast:Compr", ptr %t771, i32 0, i32 1
  %t774 = load ptr, ptr %t773, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t770, ptr %t774)
  br label %bb243
bb243:
  %t777 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t777, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d78, i32 0, i32 1) })
  br label %bb244
bb244:
  %t779 = load ptr, ptr %l46, !tbaa !29
  %t781 = getelementptr %"compiler/ast:Compr", ptr %t779, i32 0, i32 2
  %t782 = load i32, ptr %t781, !tbaa !23
  %t784 = icmp ne i32 %t782, 0
  br i1 %t784, label %bb245, label %bb246
bb245:
  store %olang.scope zeroinitializer, ptr %s31
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t787 = load ptr, ptr %l46, !tbaa !29
  %t789 = getelementptr %"compiler/ast:Compr", ptr %t787, i32 0, i32 2
  %t790 = load i32, ptr %t789, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t786, i32 %t790)
  br label %bb247
bb246:
  br label %bb249
bb247:
  %t793 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t793, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d79, i32 0, i32 1) })
  br label %bb248
bb248:
  call void @__olang_scope_close(ptr %s31)
  br label %bb249
bb249:
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t796 = load ptr, ptr %l46, !tbaa !29
  %t798 = getelementptr %"compiler/ast:Compr", ptr %t796, i32 0, i32 3
  %t799 = load i32, ptr %t798, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t795, i32 %t799)
  br label %bb250
bb250:
  %t802 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t802, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d80, i32 0, i32 1) })
  br label %bb251
bb251:
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t805 = load ptr, ptr %l46, !tbaa !29
  %t807 = getelementptr %"compiler/ast:Compr", ptr %t805, i32 0, i32 4
  %t808 = load ptr, ptr %t807, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t804, ptr %t808)
  br label %bb252
bb252:
  %t811 = load ptr, ptr %l46, !tbaa !29
  %t813 = getelementptr %"compiler/ast:Compr", ptr %t811, i32 0, i32 5
  %t814 = load ptr, ptr %t813, !tbaa !29
  %t816 = icmp eq ptr %t814, null
  %t818 = xor i1 %t816, true
  br i1 %t818, label %bb253, label %bb254
bb253:
  store %olang.scope zeroinitializer, ptr %s32
  %t820 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s32, ptr %t820, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d81, i32 0, i32 1) })
  br label %bb255
bb254:
  br label %bb260
bb255:
  %t822 = load ptr, ptr %l0, !tbaa !29
  store ptr %t822, ptr %l422, !tbaa !29
  %t823 = load ptr, ptr %l46, !tbaa !29
  %t825 = getelementptr %"compiler/ast:Compr", ptr %t823, i32 0, i32 5
  %t826 = load ptr, ptr %t825, !tbaa !29
  %t828 = icmp eq ptr %t826, null
  br i1 %t828, label %bb256, label %bb257
bb256:
  call void @__olang_check_failed(ptr @olang_loc_e6dde321a76d1169_ef8c066898e78ecd)
  unreachable
bb257:
  br label %bb258
bb258:
  %t830 = load ptr, ptr %l46, !tbaa !29
  %t832 = getelementptr %"compiler/ast:Compr", ptr %t830, i32 0, i32 5
  %t833 = load ptr, ptr %t832, !tbaa !29
  %t834 = load ptr, ptr %l422, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t834, ptr %t833)
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s32)
  br label %bb260
bb260:
  %t836 = load ptr, ptr %l46, !tbaa !29
  %t838 = getelementptr %"compiler/ast:Compr", ptr %t836, i32 0, i32 6
  %t839 = load i1, ptr %t838, !tbaa !21
  %t841 = xor i1 %t839, true
  br i1 %t841, label %bb261, label %bb262
bb261:
  store %olang.scope zeroinitializer, ptr %s33
  %t843 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s33, ptr %t843, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) })
  br label %bb263
bb262:
  br label %bb264
bb263:
  call void @__olang_scope_close(ptr %s33)
  br label %bb264
bb264:
  call void @__olang_scope_close(ptr %s29)
  br label %bb373
bb265:
  %t845 = load ptr, ptr %l1, !tbaa !29
  store ptr %t845, ptr %l432, !tbaa !29
  store i1 false, ptr %l433, !tbaa !21
  %t846 = load ptr, ptr %l432, !tbaa !29
  %t847 = icmp ne ptr %t846, null
  br i1 %t847, label %bb266, label %bb267
bb266:
  %t849 = load ptr, ptr %l432, !tbaa !29
  %t850 = load i64, ptr %t849, !range !{i64 0, i64 30}
  %t852 = icmp eq i64 %t850, 20
  store i1 %t852, ptr %l433, !tbaa !21
  br label %bb267
bb267:
  %t853 = load i1, ptr %l433, !tbaa !21
  br i1 %t853, label %bb268, label %bb269
bb268:
  %t854 = load ptr, ptr %l1, !tbaa !29
  %t856 = getelementptr { i64, [4 x i64] }, ptr %t854, i32 0, i32 1
  %t857 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t856, i32 0, i32 1
  %t858 = load { i64, ptr }, ptr %t857
  store { i64, ptr } %t858, ptr %l47, !tbaa !27
  br label %bb270
bb269:
  br label %bb282
bb270:
  %t860 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t860, ptr %l48, !tbaa !27
  store i64 0, ptr %l49, !tbaa !24
  %t862 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t864 = extractvalue { i64, ptr } %t862, 0
  store i64 %t864, ptr %l50, !tbaa !24
  br label %bb271
bb271:
  %t866 = load i64, ptr %l49, !tbaa !24
  %t867 = load i64, ptr %l50, !tbaa !24
  %t870 = icmp slt i64 %t866, %t867
  %t872 = xor i1 %t870, true
  br i1 %t872, label %bb272, label %bb273
bb272:
  br label %bb281
bb273:
  br label %bb274
bb274:
  %t874 = load i64, ptr %l49, !tbaa !24
  %t876 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t876, ptr %l446, !tbaa !27
  %t877 = load i64, ptr %l49, !tbaa !24
  %t879 = getelementptr { i64, ptr }, ptr %l446, i32 0, i32 1
  %t880 = load ptr, ptr %t879, !tbaa !27
  %t881 = getelementptr ptr, ptr %t880, i64 %t877
  %t882 = load ptr, ptr %t881, !tbaa !39
  store ptr %t882, ptr %l52, !tbaa !29
  %t886 = icmp sgt i64 %t874, 0
  br i1 %t886, label %bb275, label %bb276
bb275:
  store %olang.scope zeroinitializer, ptr %s37
  %t888 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s37, ptr %t888, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb277
bb276:
  br label %bb278
bb277:
  call void @__olang_scope_close(ptr %s37)
  br label %bb278
bb278:
  %t890 = load ptr, ptr %l0, !tbaa !29
  %t891 = load ptr, ptr %l52, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t890, ptr %t891)
  br label %bb279
bb279:
  br label %bb280
bb280:
  %t894 = load i64, ptr %l49, !tbaa !24
  %t896 = add i64 %t894, 1
  store i64 %t896, ptr %l49, !tbaa !24
  br label %bb271
bb281:
  br label %bb373
bb282:
  %t898 = load ptr, ptr %l1, !tbaa !29
  store ptr %t898, ptr %l456, !tbaa !29
  store i1 false, ptr %l457, !tbaa !21
  %t899 = load ptr, ptr %l456, !tbaa !29
  %t900 = icmp ne ptr %t899, null
  br i1 %t900, label %bb283, label %bb284
bb283:
  %t902 = load ptr, ptr %l456, !tbaa !29
  %t903 = load i64, ptr %t902, !range !{i64 0, i64 30}
  %t905 = icmp eq i64 %t903, 21
  store i1 %t905, ptr %l457, !tbaa !21
  br label %bb284
bb284:
  %t906 = load i1, ptr %l457, !tbaa !21
  br i1 %t906, label %bb285, label %bb286
bb285:
  %t907 = load ptr, ptr %l1, !tbaa !29
  %t909 = getelementptr { i64, [4 x i64] }, ptr %t907, i32 0, i32 1
  %t910 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t909, i32 0, i32 1
  %t911 = load ptr, ptr %t910
  store ptr %t911, ptr %l53, !tbaa !29
  %t913 = load ptr, ptr %l1, !tbaa !29
  %t915 = getelementptr { i64, [4 x i64] }, ptr %t913, i32 0, i32 1
  %t916 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t915, i32 0, i32 2
  %t917 = load { i64, ptr }, ptr %t916
  store { i64, ptr } %t917, ptr %l54, !tbaa !27
  br label %bb287
bb286:
  br label %bb291
bb287:
  store %olang.scope zeroinitializer, ptr %s39
  %t919 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s39, ptr %t919, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d84, i32 0, i32 1) })
  br label %bb288
bb288:
  %t921 = load ptr, ptr %l0, !tbaa !29
  %t922 = load ptr, ptr %l53, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t921, ptr %t922)
  br label %bb289
bb289:
  %t925 = load ptr, ptr %l0, !tbaa !29
  %t926 = load { i64, ptr }, ptr %l54, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t925, { i64, ptr } %t926)
  br label %bb290
bb290:
  call void @__olang_scope_close(ptr %s39)
  br label %bb373
bb291:
  %t929 = load ptr, ptr %l1, !tbaa !29
  store ptr %t929, ptr %l469, !tbaa !29
  store i1 false, ptr %l470, !tbaa !21
  %t930 = load ptr, ptr %l469, !tbaa !29
  %t931 = icmp ne ptr %t930, null
  br i1 %t931, label %bb292, label %bb293
bb292:
  %t933 = load ptr, ptr %l469, !tbaa !29
  %t934 = load i64, ptr %t933, !range !{i64 0, i64 30}
  %t936 = icmp eq i64 %t934, 22
  store i1 %t936, ptr %l470, !tbaa !21
  br label %bb293
bb293:
  %t937 = load i1, ptr %l470, !tbaa !21
  br i1 %t937, label %bb294, label %bb295
bb294:
  %t938 = load ptr, ptr %l1, !tbaa !29
  %t940 = getelementptr { i64, [4 x i64] }, ptr %t938, i32 0, i32 1
  %t941 = getelementptr { %"compiler/source:Span", ptr }, ptr %t940, i32 0, i32 1
  %t942 = load ptr, ptr %t941
  store ptr %t942, ptr %l55, !tbaa !29
  br label %bb296
bb295:
  br label %bb300
bb296:
  store %olang.scope zeroinitializer, ptr %s40
  %t944 = load ptr, ptr %l0, !tbaa !29
  %t946 = getelementptr %"compiler/unparse:writer", ptr %t944, i32 0, i32 6
  %t947 = load i1, ptr %t946, !tbaa !21
  store i1 %t947, ptr %l56, !tbaa !21
  %t949 = load ptr, ptr %l0, !tbaa !29
  %t951 = getelementptr %"compiler/unparse:writer", ptr %t949, i32 0, i32 6
  store i1 false, ptr %t951, !tbaa !21
  %t952 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s40, ptr %t952, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d85, i32 0, i32 1) })
  br label %bb297
bb297:
  %t954 = load ptr, ptr %l0, !tbaa !29
  %t955 = load ptr, ptr %l55, !tbaa !29
  %t957 = getelementptr %"compiler/ast:Func", ptr %t955, i32 0, i32 3
  %t958 = load ptr, ptr %t957, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t954, ptr %t958)
  br label %bb298
bb298:
  %t961 = load ptr, ptr %l0, !tbaa !29
  %t962 = load i1, ptr %l56, !tbaa !21
  %t965 = getelementptr %"compiler/unparse:writer", ptr %t961, i32 0, i32 6
  store i1 %t962, ptr %t965, !tbaa !21
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t967 = load ptr, ptr %l55, !tbaa !29
  %t969 = getelementptr %"compiler/ast:Func", ptr %t967, i32 0, i32 4
  %t970 = load { i64, ptr }, ptr %t969, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t966, { i64, ptr } %t970)
  br label %bb299
bb299:
  call void @__olang_scope_close(ptr %s40)
  br label %bb373
bb300:
  %t973 = load ptr, ptr %l1, !tbaa !29
  store ptr %t973, ptr %l487, !tbaa !29
  store i1 false, ptr %l488, !tbaa !21
  %t974 = load ptr, ptr %l487, !tbaa !29
  %t975 = icmp ne ptr %t974, null
  br i1 %t975, label %bb301, label %bb302
bb301:
  %t977 = load ptr, ptr %l487, !tbaa !29
  %t978 = load i64, ptr %t977, !range !{i64 0, i64 30}
  %t980 = icmp eq i64 %t978, 23
  store i1 %t980, ptr %l488, !tbaa !21
  br label %bb302
bb302:
  %t981 = load i1, ptr %l488, !tbaa !21
  br i1 %t981, label %bb303, label %bb304
bb303:
  %t982 = load ptr, ptr %l1, !tbaa !29
  %t984 = getelementptr { i64, [4 x i64] }, ptr %t982, i32 0, i32 1
  %t985 = getelementptr { %"compiler/source:Span", ptr }, ptr %t984, i32 0, i32 1
  %t986 = load ptr, ptr %t985
  store ptr %t986, ptr %l57, !tbaa !29
  br label %bb305
bb304:
  br label %bb307
bb305:
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t989 = load ptr, ptr %l57, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t988, ptr %t989)
  br label %bb306
bb306:
  br label %bb373
bb307:
  %t992 = load ptr, ptr %l1, !tbaa !29
  store ptr %t992, ptr %l495, !tbaa !29
  store i1 false, ptr %l496, !tbaa !21
  %t993 = load ptr, ptr %l495, !tbaa !29
  %t994 = icmp ne ptr %t993, null
  br i1 %t994, label %bb308, label %bb309
bb308:
  %t996 = load ptr, ptr %l495, !tbaa !29
  %t997 = load i64, ptr %t996, !range !{i64 0, i64 30}
  %t999 = icmp eq i64 %t997, 24
  store i1 %t999, ptr %l496, !tbaa !21
  br label %bb309
bb309:
  %t1000 = load i1, ptr %l496, !tbaa !21
  br i1 %t1000, label %bb310, label %bb311
bb310:
  %t1001 = load ptr, ptr %l1, !tbaa !29
  %t1003 = getelementptr { i64, [4 x i64] }, ptr %t1001, i32 0, i32 1
  %t1004 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t1003, i32 0, i32 1
  %t1005 = load { i64, ptr }, ptr %t1004
  store { i64, ptr } %t1005, ptr %l58, !tbaa !27
  br label %bb312
bb311:
  br label %bb315
bb312:
  store %olang.scope zeroinitializer, ptr %s42
  %t1007 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s42, ptr %t1007, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb313
bb313:
  %t1009 = load ptr, ptr %l0, !tbaa !29
  %t1010 = load { i64, ptr }, ptr %l58, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t1009, { i64, ptr } %t1010)
  br label %bb314
bb314:
  call void @__olang_scope_close(ptr %s42)
  br label %bb373
bb315:
  %t1013 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1013, ptr %l504, !tbaa !29
  store i1 false, ptr %l505, !tbaa !21
  %t1014 = load ptr, ptr %l504, !tbaa !29
  %t1015 = icmp ne ptr %t1014, null
  br i1 %t1015, label %bb316, label %bb317
bb316:
  %t1017 = load ptr, ptr %l504, !tbaa !29
  %t1018 = load i64, ptr %t1017, !range !{i64 0, i64 30}
  %t1020 = icmp eq i64 %t1018, 25
  store i1 %t1020, ptr %l505, !tbaa !21
  br label %bb317
bb317:
  %t1021 = load i1, ptr %l505, !tbaa !21
  br i1 %t1021, label %bb318, label %bb319
bb318:
  br label %bb320
bb319:
  br label %bb322
bb320:
  store %olang.scope zeroinitializer, ptr %s43
  %t1022 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s43, ptr %t1022, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d87, i32 0, i32 1) })
  br label %bb321
bb321:
  call void @__olang_scope_close(ptr %s43)
  br label %bb373
bb322:
  %t1024 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1024, ptr %l509, !tbaa !29
  store i1 false, ptr %l510, !tbaa !21
  %t1025 = load ptr, ptr %l509, !tbaa !29
  %t1026 = icmp ne ptr %t1025, null
  br i1 %t1026, label %bb323, label %bb324
bb323:
  %t1028 = load ptr, ptr %l509, !tbaa !29
  %t1029 = load i64, ptr %t1028, !range !{i64 0, i64 30}
  %t1031 = icmp eq i64 %t1029, 27
  store i1 %t1031, ptr %l510, !tbaa !21
  br label %bb324
bb324:
  %t1032 = load i1, ptr %l510, !tbaa !21
  br i1 %t1032, label %bb325, label %bb326
bb325:
  %t1033 = load ptr, ptr %l1, !tbaa !29
  %t1035 = getelementptr { i64, [4 x i64] }, ptr %t1033, i32 0, i32 1
  %t1036 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1035, i32 0, i32 1
  %t1037 = load ptr, ptr %t1036
  store ptr %t1037, ptr %l59, !tbaa !29
  br label %bb327
bb326:
  br label %bb334
bb327:
  store %olang.scope zeroinitializer, ptr %s44
  %t1039 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s44, ptr %t1039, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d88, i32 0, i32 1) })
  br label %bb328
bb328:
  %t1041 = load ptr, ptr %l59, !tbaa !29
  %t1043 = icmp eq ptr %t1041, null
  %t1045 = xor i1 %t1043, true
  br i1 %t1045, label %bb329, label %bb330
bb329:
  store %olang.scope zeroinitializer, ptr %s45
  %t1047 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s45, ptr %t1047, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb331
bb330:
  br label %bb333
bb331:
  %t1049 = load ptr, ptr %l0, !tbaa !29
  %t1050 = load ptr, ptr %l59, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t1049, ptr %t1050)
  br label %bb332
bb332:
  call void @__olang_scope_close(ptr %s45)
  br label %bb333
bb333:
  call void @__olang_scope_close(ptr %s44)
  br label %bb373
bb334:
  %t1053 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1053, ptr %l522, !tbaa !29
  store i1 false, ptr %l523, !tbaa !21
  %t1054 = load ptr, ptr %l522, !tbaa !29
  %t1055 = icmp ne ptr %t1054, null
  br i1 %t1055, label %bb335, label %bb336
bb335:
  %t1057 = load ptr, ptr %l522, !tbaa !29
  %t1058 = load i64, ptr %t1057, !range !{i64 0, i64 30}
  %t1060 = icmp eq i64 %t1058, 26
  store i1 %t1060, ptr %l523, !tbaa !21
  br label %bb336
bb336:
  %t1061 = load i1, ptr %l523, !tbaa !21
  br i1 %t1061, label %bb337, label %bb338
bb337:
  %t1062 = load ptr, ptr %l1, !tbaa !29
  %t1064 = getelementptr { i64, [4 x i64] }, ptr %t1062, i32 0, i32 1
  %t1065 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1064, i32 0, i32 1
  %t1066 = load i32, ptr %t1065
  store i32 %t1066, ptr %l60, !tbaa !23
  %t1068 = load ptr, ptr %l1, !tbaa !29
  %t1070 = getelementptr { i64, [4 x i64] }, ptr %t1068, i32 0, i32 1
  %t1071 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1070, i32 0, i32 2
  %t1072 = load ptr, ptr %t1071
  store ptr %t1072, ptr %l61, !tbaa !29
  br label %bb339
bb338:
  br label %bb343
bb339:
  store %olang.scope zeroinitializer, ptr %s46
  %t1074 = load ptr, ptr %l0, !tbaa !29
  %t1075 = load i32, ptr %l60, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t1074, i32 %t1075)
  br label %bb340
bb340:
  %t1078 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s46, ptr %t1078, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb341
bb341:
  %t1080 = load ptr, ptr %l0, !tbaa !29
  %t1081 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t1080, ptr %t1081)
  br label %bb342
bb342:
  call void @__olang_scope_close(ptr %s46)
  br label %bb373
bb343:
  %t1084 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1084, ptr %l535, !tbaa !29
  store i1 false, ptr %l536, !tbaa !21
  %t1085 = load ptr, ptr %l535, !tbaa !29
  %t1086 = icmp ne ptr %t1085, null
  br i1 %t1086, label %bb344, label %bb345
bb344:
  %t1088 = load ptr, ptr %l535, !tbaa !29
  %t1089 = load i64, ptr %t1088, !range !{i64 0, i64 30}
  %t1091 = icmp eq i64 %t1089, 28
  store i1 %t1091, ptr %l536, !tbaa !21
  br label %bb345
bb345:
  %t1092 = load i1, ptr %l536, !tbaa !21
  br i1 %t1092, label %bb346, label %bb347
bb346:
  %t1093 = load ptr, ptr %l1, !tbaa !29
  %t1095 = getelementptr { i64, [4 x i64] }, ptr %t1093, i32 0, i32 1
  %t1096 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1095, i32 0, i32 1
  %t1097 = load ptr, ptr %t1096
  store ptr %t1097, ptr %l62, !tbaa !29
  br label %bb348
bb347:
  br label %bb355
bb348:
  store %olang.scope zeroinitializer, ptr %s47
  %t1099 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s47, ptr %t1099, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb349
bb349:
  %t1101 = load ptr, ptr %l62, !tbaa !29
  %t1102 = load ptr, ptr %l0, !tbaa !29
  %t1104 = getelementptr %"compiler/unparse:writer", ptr %t1102, i32 0, i32 0
  %t1105 = load ptr, ptr %t1104, !tbaa !29
  %t1108 = call i1 @compiler_2funparse_2ebareSpread(ptr %v1, ptr %v0, ptr %t1101, ptr %t1105)
  store i1 %t1108, ptr %l545
  br label %bb350
bb350:
  %t1109 = load i1, ptr %l545, !tbaa !21
  %t1110 = xor i1 %t1109, true
  br i1 %t1110, label %bb351, label %bb352
bb351:
  %t1112 = load ptr, ptr %l0, !tbaa !29
  %t1113 = load ptr, ptr %l62, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t1112, ptr %t1113)
  br label %bb353
bb352:
  br label %bb354
bb353:
  br label %bb354
bb354:
  call void @__olang_scope_close(ptr %s47)
  br label %bb373
bb355:
  %t1116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1116, ptr %l549, !tbaa !29
  store i1 false, ptr %l550, !tbaa !21
  %t1117 = load ptr, ptr %l549, !tbaa !29
  %t1118 = icmp ne ptr %t1117, null
  br i1 %t1118, label %bb356, label %bb357
bb356:
  %t1120 = load ptr, ptr %l549, !tbaa !29
  %t1121 = load i64, ptr %t1120, !range !{i64 0, i64 30}
  %t1123 = icmp eq i64 %t1121, 29
  store i1 %t1123, ptr %l550, !tbaa !21
  br label %bb357
bb357:
  %t1124 = load i1, ptr %l550, !tbaa !21
  br i1 %t1124, label %bb358, label %bb359
bb358:
  %t1125 = load ptr, ptr %l1, !tbaa !29
  %t1127 = getelementptr { i64, [4 x i64] }, ptr %t1125, i32 0, i32 1
  %t1128 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t1127, i32 0, i32 1
  %t1129 = load { i64, ptr }, ptr %t1128
  store { i64, ptr } %t1129, ptr %l63, !tbaa !27
  br label %bb360
bb359:
  br label %bb372
bb360:
  %t1131 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t1131, ptr %l64, !tbaa !27
  store i64 0, ptr %l65, !tbaa !24
  %t1133 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t1135 = extractvalue { i64, ptr } %t1133, 0
  store i64 %t1135, ptr %l66, !tbaa !24
  br label %bb361
bb361:
  %t1137 = load i64, ptr %l65, !tbaa !24
  %t1138 = load i64, ptr %l66, !tbaa !24
  %t1141 = icmp slt i64 %t1137, %t1138
  %t1143 = xor i1 %t1141, true
  br i1 %t1143, label %bb362, label %bb363
bb362:
  br label %bb371
bb363:
  br label %bb364
bb364:
  %t1145 = load i64, ptr %l65, !tbaa !24
  %t1147 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t1147, ptr %l563, !tbaa !27
  %t1148 = load i64, ptr %l65, !tbaa !24
  %t1150 = getelementptr { i64, ptr }, ptr %l563, i32 0, i32 1
  %t1151 = load ptr, ptr %t1150, !tbaa !27
  %t1152 = getelementptr ptr, ptr %t1151, i64 %t1148
  %t1153 = load ptr, ptr %t1152, !tbaa !39
  store ptr %t1153, ptr %l68, !tbaa !29
  %t1157 = icmp sgt i64 %t1145, 0
  br i1 %t1157, label %bb365, label %bb366
bb365:
  store %olang.scope zeroinitializer, ptr %s52
  %t1159 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s52, ptr %t1159, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d92, i32 0, i32 1) })
  br label %bb367
bb366:
  br label %bb368
bb367:
  call void @__olang_scope_close(ptr %s52)
  br label %bb368
bb368:
  %t1161 = load ptr, ptr %l0, !tbaa !29
  %t1162 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t1161, ptr %t1162)
  br label %bb369
bb369:
  br label %bb370
bb370:
  %t1165 = load i64, ptr %l65, !tbaa !24
  %t1167 = add i64 %t1165, 1
  store i64 %t1167, ptr %l65, !tbaa !24
  br label %bb361
bb371:
  br label %bb373
bb372:
  call void @__olang_check_failed(ptr @olang_loc_af8532b2afdd02b1_ed9973e7a2ad66a5)
  unreachable
bb373:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t27 = icmp sgt i64 %t15, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t29, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d93, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexternFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d94, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Func", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %t6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t3, i32 %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Func", ptr %t11, i32 0, i32 3
  %t14 = load ptr, ptr %t13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t10, ptr %t14)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efunc(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l14 = alloca ptr
  %l22 = alloca i1
  %l23 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Func", ptr %t2, i32 0, i32 8
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eattrs(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Func", ptr %t8, i32 0, i32 7
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t13, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d95, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t15, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) })
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Func", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t26, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) })
  br label %bb9
bb8:
  br label %bb15
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l14, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Func", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = icmp eq ptr %t32, null
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_240300a98391f326_30555605a48ff2da)
  unreachable
bb11:
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/ast:Func", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t40, ptr %t39)
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t42, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d98, i32 0, i32 1) })
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v1, ptr %t44)
  store i1 %t46, ptr %l22
  br label %bb16
bb16:
  %t47 = load i1, ptr %l22, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l23, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Func", ptr %t49, i32 0, i32 9
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  br i1 %t54, label %bb19, label %bb20
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/ast:Func", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %t59, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t56, i32 %t60)
  br label %bb25
bb19:
  call void @__olang_check_failed(ptr @olang_loc_62b5cb0662a9bd0d_8638c84775e31461)
  unreachable
bb20:
  br label %bb21
bb21:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Func", ptr %t63, i32 0, i32 9
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t67 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t67, ptr %t66)
  br label %bb22
bb22:
  %t69 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t69, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb23
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 10
  %t75 = load i32, ptr %t74, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t71, i32 %t75)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/ast:Func", ptr %t79, i32 0, i32 5
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t78, { i64, ptr } %t82)
  br label %bb27
bb27:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/ast:Func", ptr %t86, i32 0, i32 3
  %t89 = load ptr, ptr %t88, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t85, ptr %t89)
  br label %bb28
bb28:
  %t92 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t92, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) })
  br label %bb29
bb29:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 4
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t94, { i64, ptr } %t98)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efuncType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb9
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Sig", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp sgt i64 %t16, 1
  br i1 %t18, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Sig", ptr %t20, i32 0, i32 3
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t27 = icmp sgt i64 %t25, 1
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l15, !tbaa !21
  store i1 %t29, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l10, !tbaa !21
  store i1 %t30, ptr %l7, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l7, !tbaa !21
  store i1 %t31, ptr %l3, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/unparse:writer", ptr %t32, i32 0, i32 7
  store i1 false, ptr %t34, !tbaa !21
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load i1, ptr %l3, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d101, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d102, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t38, { i64, ptr } %t39)
  br label %bb13
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %v2, ptr %t40, { i64, ptr } %a2)
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/unparse:writer", ptr %t44, i32 0, i32 6
  %t47 = load i1, ptr %t46, !tbaa !21
  store i1 %t47, ptr %l4, !tbaa !21
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/unparse:writer", ptr %t49, i32 0, i32 6
  store i1 false, ptr %t51, !tbaa !21
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i1, ptr %l4, !tbaa !21
  %t60 = getelementptr %"compiler/unparse:writer", ptr %t56, i32 0, i32 6
  store i1 %t57, ptr %t60, !tbaa !21
  %t61 = load i1, ptr %l3, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s1
  %t63 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t63, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l14 = alloca ptr
  %l20 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l42 = alloca ptr
  %l49 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:If", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_450b6e4c0e54f911_1dcad8b8a27ff01d)
  unreachable
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:If", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t20, ptr %t19)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t22, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:If", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_375b6e3c7dc4e00a_588d095da59240b6)
  unreachable
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/ast:If", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t36, ptr %t35)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l20, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:If", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_e1b6c554c381b10b_f727e5cc4e37ef67)
  unreachable
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/ast:If", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t50, ptr %t49)
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/ast:If", ptr %t52, i32 0, i32 2
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t61 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t61, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb43
bb19:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/ast:If", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l2, !tbaa !29
  %t68 = load ptr, ptr %l2, !tbaa !29
  store ptr %t68, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t69 = load ptr, ptr %l33, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load ptr, ptr %l33, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 22}
  %t75 = icmp eq i64 %t73, 5
  store i1 %t75, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t76 = load i1, ptr %l34, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", ptr }, ptr %t79, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t83 = load ptr, ptr %l3, !tbaa !29
  %t85 = getelementptr %"compiler/ast:If", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = icmp eq ptr %t86, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l42, !tbaa !29
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/ast:If", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb27, label %bb28
bb26:
  br label %bb31
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ba8e182b2fbe7a1c_99d493faf8d7cb48)
  unreachable
bb28:
  br label %bb29
bb29:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/ast:If", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebranch(ptr %v0, ptr %v1, ptr %t102, ptr %t101)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_a676b6f90e9ab794_adfa384105d75b88)
  unreachable
bb37:
  %t104 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t104, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d106, i32 0, i32 1) })
  br label %bb38
bb38:
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l49, !tbaa !29
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/ast:If", ptr %t107, i32 0, i32 2
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_8218e8270bec8206_ca247080b262927a)
  unreachable
bb40:
  br label %bb41
bb41:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/ast:If", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load ptr, ptr %l49, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t118, ptr %t117)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t9, { i64, ptr } %a1)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i1, ptr %l2, !tbaa !21
  %t17 = getelementptr %"compiler/unparse:writer", ptr %t13, i32 0, i32 6
  store i1 %t14, ptr %t17, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l21 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l90 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d107, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Match", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t3, ptr %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l21, !tbaa !29
  %t13 = load ptr, ptr %l21, !tbaa !29
  %t14 = getelementptr %"compiler/unparse:writer", ptr %t13, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = add i64 %t15, 1
  %t19 = load ptr, ptr %l21, !tbaa !29
  %t20 = getelementptr %"compiler/unparse:writer", ptr %t19, i32 0, i32 4
  store i64 %t17, ptr %t20, !tbaa !24
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Match", ptr %t21, i32 0, i32 3
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb6:
  br label %bb7
bb7:
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l32, !tbaa !27
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  store ptr %t44, ptr %l5, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t46)
  br label %bb8
bb8:
  %t48 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t48, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d109, i32 0, i32 1) })
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Case", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb11, label %bb12
bb11:
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l46, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l10, !tbaa !29
  %t79 = icmp sgt i64 %t67, 0
  br i1 %t79, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t81, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb10
bb20:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Case", ptr %t91, i32 0, i32 2
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l12, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t110, ptr %l65, !tbaa !27
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr ptr, ptr %t114, i64 %t111
  %t116 = load ptr, ptr %t115, !tbaa !39
  store ptr %t116, ptr %l15, !tbaa !29
  %t120 = icmp sgt i64 %t108, 0
  br i1 %t120, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t122 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t122, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb28:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l12, !tbaa !24
  br label %bb21
bb31:
  %t132 = load ptr, ptr %l5, !tbaa !29
  %t134 = getelementptr %"compiler/ast:Case", ptr %t132, i32 0, i32 3
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = icmp eq ptr %t135, null
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s11
  %t141 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t141, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l80, !tbaa !29
  %t144 = load ptr, ptr %l5, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_212921701ccd28fb_40c266614e32415f)
  unreachable
bb36:
  br label %bb37
bb37:
  %t151 = load ptr, ptr %l5, !tbaa !29
  %t153 = getelementptr %"compiler/ast:Case", ptr %t151, i32 0, i32 3
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = load ptr, ptr %l80, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t155, ptr %t154)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s11)
  br label %bb39
bb39:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ecaseBody(ptr %v0, ptr %v1, ptr %t157, ptr %t158)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t161 = load i64, ptr %l3, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l3, !tbaa !24
  br label %bb4
bb42:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l90, !tbaa !29
  %t166 = load ptr, ptr %l90, !tbaa !29
  %t167 = getelementptr %"compiler/unparse:writer", ptr %t166, i32 0, i32 4
  %t168 = load i64, ptr %t167, !tbaa !24
  %t170 = sub i64 %t168, 1
  %t172 = load ptr, ptr %l90, !tbaa !29
  %t173 = getelementptr %"compiler/unparse:writer", ptr %t172, i32 0, i32 4
  store i64 %t170, ptr %t173, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t174)
  br label %bb43
bb43:
  %t176 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t176, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t7, i32 %a1)
  store { i64, ptr } %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t12, { i64, ptr } %t13)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t3, i8 10)
  br label %bb1
bb1:
  store i64 0, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/unparse:writer", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2funparse_2eMaxIndent, !tbaa !24
  %t12 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t8, i64 %t9)
  store i64 %t12, ptr %l12
  br label %bb2
bb2:
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb8
bb5:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l19, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l19, !tbaa !24
  store i64 %t40, ptr %l16, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l16, !tbaa !24
  store i64 %t41, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l1, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l6, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/unparse:writer", ptr %t60, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t62, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d114, i32 0, i32 1) })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l5, !tbaa !24
  br label %bb9
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l19 = alloca ptr
  %l30 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Param", ptr %t2, i32 0, i32 4
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eattrs(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Param", ptr %t8, i32 0, i32 1
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = icmp ne i32 %t11, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Param", ptr %t16, i32 0, i32 1
  %t19 = load i32, ptr %t18, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t15, i32 %t19)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/ast:Param", ptr %t22, i32 0, i32 2
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Param", ptr %t31, i32 0, i32 1
  %t34 = load i32, ptr %t33, !tbaa !23
  %t36 = icmp ne i32 %t34, 0
  br i1 %t36, label %bb8, label %bb9
bb7:
  br label %bb16
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t38, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l19, !tbaa !29
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/ast:Param", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_2301005a90ba30f7_2e0b8cd6b5bb3c83)
  unreachable
bb13:
  br label %bb14
bb14:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Param", ptr %t48, i32 0, i32 2
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t52, ptr %t51)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Param", ptr %t54, i32 0, i32 3
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t63, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d116, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb24
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l30, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Param", ptr %t66, i32 0, i32 3
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_6385ebb2fa48e0d8_1e44ec8c8ca0ecf4)
  unreachable
bb21:
  br label %bb22
bb22:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Param", ptr %t73, i32 0, i32 3
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t77, ptr %t76)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l19 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l19, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l7, !tbaa !29
  %t35 = icmp sgt i64 %t23, 0
  br i1 %t35, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t37, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d117, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparam(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i1, ptr %l2, !tbaa !21
  %t51 = getelementptr %"compiler/unparse:writer", ptr %t47, i32 0, i32 6
  store i1 %t48, ptr %t51, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l16 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:Path", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i32, ptr %t24, i64 %t21
  %t26 = load i32, ptr %t25, !tbaa !33
  store i32 %t26, ptr %l6, !tbaa !23
  %t30 = icmp sgt i64 %t18, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t32, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t34, i32 %t35)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l50 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i1
  %l108 = alloca { i64, ptr }
  %l109 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t2 = load ptr, ptr %l18, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l18, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l19, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l19, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb87
bb7:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t13 = load ptr, ptr %l23, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb8, label %bb9
bb8:
  %t16 = load ptr, ptr %l23, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 9}
  %t19 = icmp eq i64 %t17, 1
  store i1 %t19, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t20 = load i1, ptr %l24, !tbaa !21
  br i1 %t20, label %bb10, label %bb11
bb10:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", ptr }, ptr %t23, i32 0, i32 1
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  br label %bb13
bb13:
  br label %bb87
bb14:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t32 = load ptr, ptr %l31, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb15, label %bb16
bb15:
  %t35 = load ptr, ptr %l31, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 9}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l32, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l32, !tbaa !21
  br i1 %t39, label %bb17, label %bb18
bb17:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t48, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49
  store { i64, ptr } %t50, ptr %l4, !tbaa !27
  br label %bb19
bb18:
  br label %bb34
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t56, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) })
  br label %bb21
bb21:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb22
bb22:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb23, label %bb24
bb23:
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l50, !tbaa !27
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l9, !tbaa !29
  %t84 = icmp sgt i64 %t72, 0
  br i1 %t84, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t86, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d121, i32 0, i32 1) })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t88, ptr %t89)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l6, !tbaa !24
  br label %bb22
bb32:
  %t96 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t96, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) })
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb87
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t99 = load ptr, ptr %l61, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb35, label %bb36
bb35:
  %t102 = load ptr, ptr %l61, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 9}
  %t105 = icmp eq i64 %t103, 3
  store i1 %t105, ptr %l62, !tbaa !21
  br label %bb36
bb36:
  %t106 = load i1, ptr %l62, !tbaa !21
  br i1 %t106, label %bb37, label %bb38
bb37:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32 }, ptr %t109, i32 0, i32 1
  %t111 = load i32, ptr %t110
  store i32 %t111, ptr %l10, !tbaa !23
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t113, i32 %t114)
  br label %bb40
bb40:
  br label %bb87
bb41:
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t118 = load ptr, ptr %l69, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb42, label %bb43
bb42:
  %t121 = load ptr, ptr %l69, !tbaa !29
  %t122 = load i64, ptr %t121, !range !{i64 0, i64 9}
  %t124 = icmp eq i64 %t122, 4
  store i1 %t124, ptr %l70, !tbaa !21
  br label %bb43
bb43:
  %t125 = load i1, ptr %l70, !tbaa !21
  br i1 %t125, label %bb44, label %bb45
bb44:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", ptr }, ptr %t128, i32 0, i32 1
  %t130 = load ptr, ptr %t129
  store ptr %t130, ptr %l11, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t132, ptr %t133)
  br label %bb47
bb47:
  br label %bb87
bb48:
  %t136 = load ptr, ptr %l1, !tbaa !29
  store ptr %t136, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t137 = load ptr, ptr %l77, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb49, label %bb50
bb49:
  %t140 = load ptr, ptr %l77, !tbaa !29
  %t141 = load i64, ptr %t140, !range !{i64 0, i64 9}
  %t143 = icmp eq i64 %t141, 5
  store i1 %t143, ptr %l78, !tbaa !21
  br label %bb50
bb50:
  %t144 = load i1, ptr %l78, !tbaa !21
  br i1 %t144, label %bb51, label %bb52
bb51:
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t147, i32 0, i32 1
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l12, !tbaa !29
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t153, i32 0, i32 2
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l13, !tbaa !23
  br label %bb53
bb52:
  br label %bb57
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t157, ptr %t158)
  br label %bb54
bb54:
  %t161 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t161, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) })
  br label %bb55
bb55:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t163, i32 %t164)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb87
bb57:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t168 = load ptr, ptr %l90, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb58, label %bb59
bb58:
  %t171 = load ptr, ptr %l90, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 9}
  %t174 = icmp eq i64 %t172, 6
  store i1 %t174, ptr %l91, !tbaa !21
  br label %bb59
bb59:
  %t175 = load i1, ptr %l91, !tbaa !21
  br i1 %t175, label %bb60, label %bb61
bb60:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l14, !tbaa !29
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t182, ptr %t183)
  br label %bb63
bb63:
  br label %bb87
bb64:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t187 = load ptr, ptr %l98, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb65, label %bb66
bb65:
  %t190 = load ptr, ptr %l98, !tbaa !29
  %t191 = load i64, ptr %t190, !range !{i64 0, i64 9}
  %t193 = icmp eq i64 %t191, 7
  store i1 %t193, ptr %l99, !tbaa !21
  br label %bb66
bb66:
  %t194 = load i1, ptr %l99, !tbaa !21
  br i1 %t194, label %bb67, label %bb68
bb67:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32 }, ptr %t197, i32 0, i32 1
  %t199 = load i32, ptr %t198
  store i32 %t199, ptr %l15, !tbaa !23
  br label %bb69
bb68:
  br label %bb77
bb69:
  store %olang.scope zeroinitializer, ptr %s12
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t201, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d124, i32 0, i32 1) })
  br label %bb70
bb70:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/unparse:writer", ptr %t203, i32 0, i32 0
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t207 = load i32, ptr %l15, !tbaa !23
  %t210 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t206, i32 %t207)
  store { i64, ptr } %t210, ptr %l108
  br label %bb71
bb71:
  %t211 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t212 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s12, { i64, ptr } %t211, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) })
  store i1 %t212, ptr %l109
  br label %bb72
bb72:
  %t213 = load i1, ptr %l109, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb73, label %bb74
bb73:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t216, i32 %t217)
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s12)
  br label %bb87
bb77:
  %t220 = load ptr, ptr %l1, !tbaa !29
  store ptr %t220, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t221 = load ptr, ptr %l113, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb78, label %bb79
bb78:
  %t224 = load ptr, ptr %l113, !tbaa !29
  %t225 = load i64, ptr %t224, !range !{i64 0, i64 9}
  %t227 = icmp eq i64 %t225, 8
  store i1 %t227, ptr %l114, !tbaa !21
  br label %bb79
bb79:
  %t228 = load i1, ptr %l114, !tbaa !21
  br i1 %t228, label %bb80, label %bb81
bb80:
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [4 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t231, i32 0, i32 1
  %t233 = load i32, ptr %t232
  store i32 %t233, ptr %l16, !tbaa !23
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr { i64, [4 x i64] }, ptr %t235, i32 0, i32 1
  %t238 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t237, i32 0, i32 2
  %t239 = load ptr, ptr %t238
  store ptr %t239, ptr %l17, !tbaa !29
  br label %bb82
bb81:
  br label %bb86
bb82:
  store %olang.scope zeroinitializer, ptr %s14
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l16, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t241, i32 %t242)
  br label %bb83
bb83:
  %t245 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t245, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d126, i32 0, i32 1) })
  br label %bb84
bb84:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epattern(ptr %v0, ptr %v1, ptr %t247, ptr %t248)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s14)
  br label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_19d95224243c5dd3_a108b37826b1917)
  unreachable
bb87:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/unparse:writer", ptr %a0, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l14 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l51 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d127, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %t7)
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Sig", ptr %t10, i32 0, i32 7
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l14, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Sig", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  br label %bb9
bb5:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d129, i32 0, i32 1) }, ptr %l19, !tbaa !27
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l14, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t25, { i64, ptr } %t26)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t27, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d130, i32 0, i32 1) })
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtract(ptr %v0, ptr %v1, ptr %t29, ptr %t30)
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Sig", ptr %t33, i32 0, i32 4
  %t36 = load i1, ptr %t35, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t38, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d131, i32 0, i32 1) })
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/unparse:writer", ptr %t40, i32 0, i32 6
  %t43 = load i1, ptr %t42, !tbaa !21
  store i1 %t43, ptr %l2, !tbaa !21
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/unparse:writer", ptr %t45, i32 0, i32 6
  store i1 true, ptr %t47, !tbaa !21
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Sig", ptr %t48, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  store { i64, ptr } %t51, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t57 = load i64, ptr %l4, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb18:
  br label %bb19
bb19:
  %t65 = load i64, ptr %l4, !tbaa !24
  store i64 %t65, ptr %l6, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t67, ptr %l38, !tbaa !27
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr ptr, ptr %t71, i64 %t68
  %t73 = load ptr, ptr %t72, !tbaa !39
  store ptr %t73, ptr %l7, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l41, !tbaa !29
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d132, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l41, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l44, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t80, { i64, ptr } %t81)
  br label %bb23
bb23:
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/ast:Sig", ptr %t83, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t90 = sub i64 %t88, 1
  %t93 = icmp eq i64 %t82, %t90
  br i1 %t93, label %bb24, label %bb25
bb24:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Sig", ptr %t95, i32 0, i32 2
  %t98 = load i1, ptr %t97, !tbaa !21
  store i1 %t98, ptr %l51, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb26
bb26:
  %t100 = load i1, ptr %l51, !tbaa !21
  br i1 %t100, label %bb27, label %bb28
bb27:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l54, !tbaa !29
  %t102 = load ptr, ptr %l7, !tbaa !29
  %t104 = call i1 @compiler_2funparse_2enoErrorsOf(ptr %v1, ptr %t102)
  store i1 %t104, ptr %l56
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t105 = load i1, ptr %l56, !tbaa !21
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = getelementptr %"compiler/unparse:writer", ptr %t106, i32 0, i32 7
  store i1 %t105, ptr %t107, !tbaa !21
  br label %bb30
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t108, ptr %t109)
  br label %bb31
bb31:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/unparse:writer", ptr %t112, i32 0, i32 7
  store i1 false, ptr %t114, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  %t115 = load i64, ptr %l4, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l4, !tbaa !24
  br label %bb16
bb33:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i1, ptr %l2, !tbaa !21
  %t123 = getelementptr %"compiler/unparse:writer", ptr %t119, i32 0, i32 6
  store i1 %t120, ptr %t123, !tbaa !21
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr %"compiler/ast:Sig", ptr %t124, i32 0, i32 6
  %t127 = load i1, ptr %t126, !tbaa !21
  br i1 %t127, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t129 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t129, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d134, i32 0, i32 1) })
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t131, ptr %t132)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 3
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/unparse:writer", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = sext i32 %t9 to i64
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l10, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sle i64 %t21, %t22
  br i1 %t23, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9c4378154f5f7dac_a032de2992525ef0)
  unreachable
bb3:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9c4378154f5f7dac_a032de2992525ef0)
  unreachable
bb5:
  %t29 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l9, !tbaa !24
  %t33 = getelementptr i8, ptr %t30, i64 %t31
  %t34 = sub i64 %t32, %t31
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t37, { i64, ptr } %t36)
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9c4378154f5f7dac_a032de2992525ef0)
  unreachable
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l59 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca i1
  %l79 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l139 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i1
  %l207 = alloca ptr
  %l208 = alloca i1
  %l220 = alloca ptr
  %l221 = alloca i1
  %l229 = alloca ptr
  %l230 = alloca i1
  %l238 = alloca ptr
  %l239 = alloca i1
  %l246 = alloca ptr
  %l248 = alloca { i64, ptr }
  %l255 = alloca ptr
  %l256 = alloca i1
  %l272 = alloca ptr
  %l273 = alloca i1
  %l294 = alloca ptr
  %l295 = alloca i1
  %l311 = alloca ptr
  %l312 = alloca i1
  %l327 = alloca ptr
  %l328 = alloca i1
  %l335 = alloca ptr
  %l337 = alloca { i64, ptr }
  %l340 = alloca ptr
  %l341 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t2 = load ptr, ptr %l34, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l34, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 22}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l35, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l35, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb246
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t21 = load ptr, ptr %l42, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l42, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 22}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l43, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l43, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb246
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t40 = load ptr, ptr %l50, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l50, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 22}
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l51, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l51, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", ptr }, ptr %t50, i32 0, i32 1
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb26
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Multi", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t54, { i64, ptr } %t58)
  br label %bb20
bb20:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l59, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Multi", ptr %t62, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d135, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d136, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l59, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l62, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t67, { i64, ptr } %t68)
  br label %bb24
bb24:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Multi", ptr %t70, i32 0, i32 2
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t69, { i64, ptr } %t73)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb246
bb26:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t77 = load ptr, ptr %l66, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l66, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 22}
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l67, !tbaa !21
  br label %bb28
bb28:
  %t84 = load i1, ptr %l67, !tbaa !21
  br i1 %t84, label %bb29, label %bb30
bb29:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88, !range !{i32 0, i32 98}
  store i32 %t89, ptr %l5
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l6, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t99, i32 0, i32 3
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l7, !tbaa !29
  br label %bb31
bb30:
  br label %bb38
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t103, ptr %t104)
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t107, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) })
  br label %bb33
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l79, !tbaa !29
  %t110 = load i32, ptr %l5, !range !{i32 0, i32 98}
  %t112 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t110)
  store { i64, ptr } %t112, ptr %l81
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l79, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l81, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t113, { i64, ptr } %t114)
  br label %bb35
bb35:
  %t115 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t115, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d138, i32 0, i32 1) })
  br label %bb36
bb36:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb246
bb38:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t122 = load ptr, ptr %l85, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %l85, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 22}
  %t128 = icmp eq i64 %t126, 4
  store i1 %t128, ptr %l86, !tbaa !21
  br label %bb40
bb40:
  %t129 = load i1, ptr %l86, !tbaa !21
  br i1 %t129, label %bb41, label %bb42
bb41:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l8, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t138, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139
  store { i64, ptr } %t140, ptr %l9, !tbaa !27
  br label %bb43
bb42:
  br label %bb47
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t142 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t142, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d139, i32 0, i32 1) })
  br label %bb44
bb44:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t144, ptr %t145)
  br label %bb45
bb45:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t148, { i64, ptr } %t149)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s5)
  br label %bb246
bb47:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t153 = load ptr, ptr %l98, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb48, label %bb49
bb48:
  %t156 = load ptr, ptr %l98, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 22}
  %t159 = icmp eq i64 %t157, 5
  store i1 %t159, ptr %l99, !tbaa !21
  br label %bb49
bb49:
  %t160 = load i1, ptr %l99, !tbaa !21
  br i1 %t160, label %bb50, label %bb51
bb50:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", ptr }, ptr %t163, i32 0, i32 1
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l10, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eifStmt(ptr %v0, ptr %v1, ptr %t167, ptr %t168)
  br label %bb53
bb53:
  br label %bb246
bb54:
  %t171 = load ptr, ptr %l1, !tbaa !29
  store ptr %t171, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t172 = load ptr, ptr %l106, !tbaa !29
  %t173 = icmp ne ptr %t172, null
  br i1 %t173, label %bb55, label %bb56
bb55:
  %t175 = load ptr, ptr %l106, !tbaa !29
  %t176 = load i64, ptr %t175, !range !{i64 0, i64 22}
  %t178 = icmp eq i64 %t176, 6
  store i1 %t178, ptr %l107, !tbaa !21
  br label %bb56
bb56:
  %t179 = load i1, ptr %l107, !tbaa !21
  br i1 %t179, label %bb57, label %bb58
bb57:
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t182, i32 0, i32 1
  %t184 = load { i64, ptr }, ptr %t183
  store { i64, ptr } %t184, ptr %l11, !tbaa !27
  br label %bb59
bb58:
  br label %bb62
bb59:
  store %olang.scope zeroinitializer, ptr %s7
  %t186 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s7, ptr %t186, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d140, i32 0, i32 1) })
  br label %bb60
bb60:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t188, { i64, ptr } %t189)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  br label %bb246
bb62:
  %t192 = load ptr, ptr %l1, !tbaa !29
  store ptr %t192, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t193 = load ptr, ptr %l115, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb63, label %bb64
bb63:
  %t196 = load ptr, ptr %l115, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 22}
  %t199 = icmp eq i64 %t197, 7
  store i1 %t199, ptr %l116, !tbaa !21
  br label %bb64
bb64:
  %t200 = load i1, ptr %l116, !tbaa !21
  br i1 %t200, label %bb65, label %bb66
bb65:
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t203, i32 0, i32 1
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l12, !tbaa !29
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t209, i32 0, i32 2
  %t211 = load { i64, ptr }, ptr %t210
  store { i64, ptr } %t211, ptr %l13, !tbaa !27
  br label %bb67
bb66:
  br label %bb71
bb67:
  store %olang.scope zeroinitializer, ptr %s8
  %t213 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t213, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d141, i32 0, i32 1) })
  br label %bb68
bb68:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t215, ptr %t216)
  br label %bb69
bb69:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t219, { i64, ptr } %t220)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s8)
  br label %bb246
bb71:
  %t223 = load ptr, ptr %l1, !tbaa !29
  store ptr %t223, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t224 = load ptr, ptr %l128, !tbaa !29
  %t225 = icmp ne ptr %t224, null
  br i1 %t225, label %bb72, label %bb73
bb72:
  %t227 = load ptr, ptr %l128, !tbaa !29
  %t228 = load i64, ptr %t227, !range !{i64 0, i64 22}
  %t230 = icmp eq i64 %t228, 8
  store i1 %t230, ptr %l129, !tbaa !21
  br label %bb73
bb73:
  %t231 = load i1, ptr %l129, !tbaa !21
  br i1 %t231, label %bb74, label %bb75
bb74:
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", ptr }, ptr %t234, i32 0, i32 1
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l14, !tbaa !29
  br label %bb76
bb75:
  br label %bb87
bb76:
  store %olang.scope zeroinitializer, ptr %s9
  %t238 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t238, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d142, i32 0, i32 1) })
  br label %bb77
bb77:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l14, !tbaa !29
  %t243 = getelementptr %"compiler/ast:For3", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t240, ptr %t244)
  br label %bb78
bb78:
  %t247 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t247, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d143, i32 0, i32 1) })
  br label %bb79
bb79:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l139, !tbaa !29
  %t250 = load ptr, ptr %l14, !tbaa !29
  %t252 = getelementptr %"compiler/ast:For3", ptr %t250, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = icmp eq ptr %t253, null
  br i1 %t255, label %bb80, label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_b263a57856eac862_46b7b1031f9001a6)
  unreachable
bb81:
  br label %bb82
bb82:
  %t257 = load ptr, ptr %l14, !tbaa !29
  %t259 = getelementptr %"compiler/ast:For3", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t261 = load ptr, ptr %l139, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t261, ptr %t260)
  br label %bb83
bb83:
  %t263 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t263, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d144, i32 0, i32 1) })
  br label %bb84
bb84:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l14, !tbaa !29
  %t268 = getelementptr %"compiler/ast:For3", ptr %t266, i32 0, i32 2
  %t269 = load ptr, ptr %t268, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t265, ptr %t269)
  br label %bb85
bb85:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load ptr, ptr %l14, !tbaa !29
  %t275 = getelementptr %"compiler/ast:For3", ptr %t273, i32 0, i32 3
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t272, { i64, ptr } %t276)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s9)
  br label %bb246
bb87:
  %t279 = load ptr, ptr %l1, !tbaa !29
  store ptr %t279, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t280 = load ptr, ptr %l152, !tbaa !29
  %t281 = icmp ne ptr %t280, null
  br i1 %t281, label %bb88, label %bb89
bb88:
  %t283 = load ptr, ptr %l152, !tbaa !29
  %t284 = load i64, ptr %t283, !range !{i64 0, i64 22}
  %t286 = icmp eq i64 %t284, 9
  store i1 %t286, ptr %l153, !tbaa !21
  br label %bb89
bb89:
  %t287 = load i1, ptr %l153, !tbaa !21
  br i1 %t287, label %bb90, label %bb91
bb90:
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr { i64, [4 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", ptr }, ptr %t290, i32 0, i32 1
  %t292 = load ptr, ptr %t291
  store ptr %t292, ptr %l15, !tbaa !29
  br label %bb92
bb91:
  br label %bb112
bb92:
  store %olang.scope zeroinitializer, ptr %s10
  %t294 = load ptr, ptr %l15, !tbaa !29
  %t296 = getelementptr %"compiler/ast:ForIn", ptr %t294, i32 0, i32 6
  %t297 = load i1, ptr %t296, !tbaa !21
  br i1 %t297, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s11
  %t299 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t299, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d145, i32 0, i32 1) })
  br label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_scope_close(ptr %s11)
  br label %bb96
bb96:
  %t301 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t301, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d146, i32 0, i32 1) })
  br label %bb97
bb97:
  %t303 = load ptr, ptr %l15, !tbaa !29
  %t305 = getelementptr %"compiler/ast:ForIn", ptr %t303, i32 0, i32 0
  %t306 = load i32, ptr %t305, !tbaa !23
  %t308 = icmp ne i32 %t306, 0
  br i1 %t308, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s12
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load ptr, ptr %l15, !tbaa !29
  %t313 = getelementptr %"compiler/ast:ForIn", ptr %t311, i32 0, i32 0
  %t314 = load i32, ptr %t313, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t310, i32 %t314)
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t317 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t317, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d147, i32 0, i32 1) })
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s12)
  br label %bb102
bb102:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load ptr, ptr %l15, !tbaa !29
  %t322 = getelementptr %"compiler/ast:ForIn", ptr %t320, i32 0, i32 1
  %t323 = load i32, ptr %t322, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t319, i32 %t323)
  br label %bb103
bb103:
  %t326 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t326, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d148, i32 0, i32 1) })
  br label %bb104
bb104:
  %t328 = load ptr, ptr %l15, !tbaa !29
  %t330 = getelementptr %"compiler/ast:ForIn", ptr %t328, i32 0, i32 3
  %t331 = load i1, ptr %t330, !tbaa !21
  br i1 %t331, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s13
  %t333 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t333, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d149, i32 0, i32 1) })
  br label %bb107
bb106:
  br label %bb108
bb107:
  call void @__olang_scope_close(ptr %s13)
  br label %bb108
bb108:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l15, !tbaa !29
  %t338 = getelementptr %"compiler/ast:ForIn", ptr %t336, i32 0, i32 2
  %t339 = load ptr, ptr %t338, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t335, ptr %t339)
  br label %bb109
bb109:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l15, !tbaa !29
  %t345 = getelementptr %"compiler/ast:ForIn", ptr %t343, i32 0, i32 4
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ebody(ptr %v0, ptr %v1, ptr %t342, { i64, ptr } %t346)
  br label %bb110
bb110:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load ptr, ptr %l15, !tbaa !29
  %t352 = getelementptr %"compiler/ast:ForIn", ptr %t350, i32 0, i32 5
  %t353 = load { i64, ptr }, ptr %t352, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t349, { i64, ptr } %t353)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s10)
  br label %bb246
bb112:
  %t356 = load ptr, ptr %l1, !tbaa !29
  store ptr %t356, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t357 = load ptr, ptr %l185, !tbaa !29
  %t358 = icmp ne ptr %t357, null
  br i1 %t358, label %bb113, label %bb114
bb113:
  %t360 = load ptr, ptr %l185, !tbaa !29
  %t361 = load i64, ptr %t360, !range !{i64 0, i64 22}
  %t363 = icmp eq i64 %t361, 10
  store i1 %t363, ptr %l186, !tbaa !21
  br label %bb114
bb114:
  %t364 = load i1, ptr %l186, !tbaa !21
  br i1 %t364, label %bb115, label %bb116
bb115:
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr { i64, [4 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t367, i32 0, i32 1
  %t369 = load { i64, ptr }, ptr %t368
  store { i64, ptr } %t369, ptr %l16, !tbaa !27
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [4 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t373, i32 0, i32 2
  %t375 = load ptr, ptr %t374
  store ptr %t375, ptr %l17, !tbaa !29
  br label %bb117
bb116:
  br label %bb122
bb117:
  store %olang.scope zeroinitializer, ptr %s14
  %t377 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t377, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d150, i32 0, i32 1) })
  br label %bb118
bb118:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t379, { i64, ptr } %t380)
  br label %bb119
bb119:
  %t383 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t383, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d151, i32 0, i32 1) })
  br label %bb120
bb120:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t385, ptr %t386)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s14)
  br label %bb246
bb122:
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t390 = load ptr, ptr %l199, !tbaa !29
  %t391 = icmp ne ptr %t390, null
  br i1 %t391, label %bb123, label %bb124
bb123:
  %t393 = load ptr, ptr %l199, !tbaa !29
  %t394 = load i64, ptr %t393, !range !{i64 0, i64 22}
  %t396 = icmp eq i64 %t394, 11
  store i1 %t396, ptr %l200, !tbaa !21
  br label %bb124
bb124:
  %t397 = load i1, ptr %l200, !tbaa !21
  br i1 %t397, label %bb125, label %bb126
bb125:
  %t398 = load ptr, ptr %l1, !tbaa !29
  %t400 = getelementptr { i64, [4 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", ptr }, ptr %t400, i32 0, i32 1
  %t402 = load ptr, ptr %t401
  store ptr %t402, ptr %l18, !tbaa !29
  br label %bb127
bb126:
  br label %bb129
bb127:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ematch(ptr %v0, ptr %v1, ptr %t404, ptr %t405)
  br label %bb128
bb128:
  br label %bb246
bb129:
  %t408 = load ptr, ptr %l1, !tbaa !29
  store ptr %t408, ptr %l207, !tbaa !29
  store i1 false, ptr %l208, !tbaa !21
  %t409 = load ptr, ptr %l207, !tbaa !29
  %t410 = icmp ne ptr %t409, null
  br i1 %t410, label %bb130, label %bb131
bb130:
  %t412 = load ptr, ptr %l207, !tbaa !29
  %t413 = load i64, ptr %t412, !range !{i64 0, i64 22}
  %t415 = icmp eq i64 %t413, 12
  store i1 %t415, ptr %l208, !tbaa !21
  br label %bb131
bb131:
  %t416 = load i1, ptr %l208, !tbaa !21
  br i1 %t416, label %bb132, label %bb133
bb132:
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr { i64, [4 x i64] }, ptr %t417, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t419, i32 0, i32 1
  %t421 = load { i64, ptr }, ptr %t420
  store { i64, ptr } %t421, ptr %l19, !tbaa !27
  br label %bb134
bb133:
  br label %bb141
bb134:
  store %olang.scope zeroinitializer, ptr %s16
  %t423 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s16, ptr %t423, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d152, i32 0, i32 1) })
  br label %bb135
bb135:
  %t425 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t429 = icmp sgt i64 %t427, 0
  br i1 %t429, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s17
  %t431 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t431, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d153, i32 0, i32 1) })
  br label %bb138
bb137:
  br label %bb140
bb138:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load { i64, ptr }, ptr %l19, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t433, { i64, ptr } %t434)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s17)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s16)
  br label %bb246
bb141:
  %t437 = load ptr, ptr %l1, !tbaa !29
  store ptr %t437, ptr %l220, !tbaa !29
  store i1 false, ptr %l221, !tbaa !21
  %t438 = load ptr, ptr %l220, !tbaa !29
  %t439 = icmp ne ptr %t438, null
  br i1 %t439, label %bb142, label %bb143
bb142:
  %t441 = load ptr, ptr %l220, !tbaa !29
  %t442 = load i64, ptr %t441, !range !{i64 0, i64 22}
  %t444 = icmp eq i64 %t442, 21
  store i1 %t444, ptr %l221, !tbaa !21
  br label %bb143
bb143:
  %t445 = load i1, ptr %l221, !tbaa !21
  br i1 %t445, label %bb144, label %bb145
bb144:
  %t446 = load ptr, ptr %l1, !tbaa !29
  %t448 = getelementptr { i64, [4 x i64] }, ptr %t446, i32 0, i32 1
  %t449 = getelementptr { %"compiler/source:Span", ptr }, ptr %t448, i32 0, i32 1
  %t450 = load ptr, ptr %t449
  store ptr %t450, ptr %l20, !tbaa !29
  br label %bb146
bb145:
  br label %bb149
bb146:
  store %olang.scope zeroinitializer, ptr %s18
  %t452 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s18, ptr %t452, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d154, i32 0, i32 1) })
  br label %bb147
bb147:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t455 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t454, ptr %t455)
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s18)
  br label %bb246
bb149:
  %t458 = load ptr, ptr %l1, !tbaa !29
  store ptr %t458, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t459 = load ptr, ptr %l229, !tbaa !29
  %t460 = icmp ne ptr %t459, null
  br i1 %t460, label %bb150, label %bb151
bb150:
  %t462 = load ptr, ptr %l229, !tbaa !29
  %t463 = load i64, ptr %t462, !range !{i64 0, i64 22}
  %t465 = icmp eq i64 %t463, 15
  store i1 %t465, ptr %l230, !tbaa !21
  br label %bb151
bb151:
  %t466 = load i1, ptr %l230, !tbaa !21
  br i1 %t466, label %bb152, label %bb153
bb152:
  %t467 = load ptr, ptr %l1, !tbaa !29
  %t469 = getelementptr { i64, [4 x i64] }, ptr %t467, i32 0, i32 1
  %t470 = getelementptr { %"compiler/source:Span", ptr }, ptr %t469, i32 0, i32 1
  %t471 = load ptr, ptr %t470
  store ptr %t471, ptr %l21, !tbaa !29
  br label %bb154
bb153:
  br label %bb157
bb154:
  store %olang.scope zeroinitializer, ptr %s19
  %t473 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t473, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d155, i32 0, i32 1) })
  br label %bb155
bb155:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t475, ptr %t476)
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s19)
  br label %bb246
bb157:
  %t479 = load ptr, ptr %l1, !tbaa !29
  store ptr %t479, ptr %l238, !tbaa !29
  store i1 false, ptr %l239, !tbaa !21
  %t480 = load ptr, ptr %l238, !tbaa !29
  %t481 = icmp ne ptr %t480, null
  br i1 %t481, label %bb158, label %bb159
bb158:
  %t483 = load ptr, ptr %l238, !tbaa !29
  %t484 = load i64, ptr %t483, !range !{i64 0, i64 22}
  %t486 = icmp eq i64 %t484, 13
  store i1 %t486, ptr %l239, !tbaa !21
  br label %bb159
bb159:
  %t487 = load i1, ptr %l239, !tbaa !21
  br i1 %t487, label %bb160, label %bb161
bb160:
  %t488 = load ptr, ptr %l1, !tbaa !29
  %t490 = getelementptr { i64, [4 x i64] }, ptr %t488, i32 0, i32 1
  %t491 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t490, i32 0, i32 1
  %t492 = load i32, ptr %t491, !range !{i32 0, i32 98}
  store i32 %t492, ptr %l22
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t496 = getelementptr { i64, [4 x i64] }, ptr %t494, i32 0, i32 1
  %t497 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t496, i32 0, i32 2
  %t498 = load ptr, ptr %t497
  store ptr %t498, ptr %l23, !tbaa !29
  br label %bb162
bb161:
  br label %bb170
bb162:
  store %olang.scope zeroinitializer, ptr %s20
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l246, !tbaa !29
  %t501 = load i32, ptr %l22, !range !{i32 0, i32 98}
  %t503 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s20, i32 %t501)
  store { i64, ptr } %t503, ptr %l248
  br label %bb163
bb163:
  %t504 = load ptr, ptr %l246, !tbaa !29
  %t505 = load { i64, ptr }, ptr %l248, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t504, { i64, ptr } %t505)
  br label %bb164
bb164:
  %t506 = load ptr, ptr %l23, !tbaa !29
  %t508 = icmp eq ptr %t506, null
  %t510 = xor i1 %t508, true
  br i1 %t510, label %bb165, label %bb166
bb165:
  store %olang.scope zeroinitializer, ptr %s21
  %t512 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t512, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d156, i32 0, i32 1) })
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t514, ptr %t515)
  br label %bb168
bb168:
  call void @__olang_scope_close(ptr %s21)
  br label %bb169
bb169:
  call void @__olang_scope_close(ptr %s20)
  br label %bb246
bb170:
  %t518 = load ptr, ptr %l1, !tbaa !29
  store ptr %t518, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t519 = load ptr, ptr %l255, !tbaa !29
  %t520 = icmp ne ptr %t519, null
  br i1 %t520, label %bb171, label %bb172
bb171:
  %t522 = load ptr, ptr %l255, !tbaa !29
  %t523 = load i64, ptr %t522, !range !{i64 0, i64 22}
  %t525 = icmp eq i64 %t523, 14
  store i1 %t525, ptr %l256, !tbaa !21
  br label %bb172
bb172:
  %t526 = load i1, ptr %l256, !tbaa !21
  br i1 %t526, label %bb173, label %bb174
bb173:
  %t527 = load ptr, ptr %l1, !tbaa !29
  %t529 = getelementptr { i64, [4 x i64] }, ptr %t527, i32 0, i32 1
  %t530 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t529, i32 0, i32 1
  %t531 = load ptr, ptr %t530
  store ptr %t531, ptr %l24, !tbaa !29
  %t533 = load ptr, ptr %l1, !tbaa !29
  %t535 = getelementptr { i64, [4 x i64] }, ptr %t533, i32 0, i32 1
  %t536 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t535, i32 0, i32 2
  %t537 = load ptr, ptr %t536
  store ptr %t537, ptr %l25, !tbaa !29
  br label %bb175
bb174:
  br label %bb183
bb175:
  store %olang.scope zeroinitializer, ptr %s22
  %t539 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t539, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d157, i32 0, i32 1) })
  br label %bb176
bb176:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t541, ptr %t542)
  br label %bb177
bb177:
  %t545 = load ptr, ptr %l25, !tbaa !29
  %t547 = icmp eq ptr %t545, null
  %t549 = xor i1 %t547, true
  br i1 %t549, label %bb178, label %bb179
bb178:
  store %olang.scope zeroinitializer, ptr %s23
  %t551 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s23, ptr %t551, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d158, i32 0, i32 1) })
  br label %bb180
bb179:
  br label %bb182
bb180:
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t553, ptr %t554)
  br label %bb181
bb181:
  call void @__olang_scope_close(ptr %s23)
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s22)
  br label %bb246
bb183:
  %t557 = load ptr, ptr %l1, !tbaa !29
  store ptr %t557, ptr %l272, !tbaa !29
  store i1 false, ptr %l273, !tbaa !21
  %t558 = load ptr, ptr %l272, !tbaa !29
  %t559 = icmp ne ptr %t558, null
  br i1 %t559, label %bb184, label %bb185
bb184:
  %t561 = load ptr, ptr %l272, !tbaa !29
  %t562 = load i64, ptr %t561, !range !{i64 0, i64 22}
  %t564 = icmp eq i64 %t562, 16
  store i1 %t564, ptr %l273, !tbaa !21
  br label %bb185
bb185:
  %t565 = load i1, ptr %l273, !tbaa !21
  br i1 %t565, label %bb186, label %bb187
bb186:
  %t566 = load ptr, ptr %l1, !tbaa !29
  %t568 = getelementptr { i64, [4 x i64] }, ptr %t566, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t568, i32 0, i32 1
  %t570 = load ptr, ptr %t569
  store ptr %t570, ptr %l26, !tbaa !29
  %t572 = load ptr, ptr %l1, !tbaa !29
  %t574 = getelementptr { i64, [4 x i64] }, ptr %t572, i32 0, i32 1
  %t575 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t574, i32 0, i32 2
  %t576 = load { i64, ptr }, ptr %t575
  store { i64, ptr } %t576, ptr %l27, !tbaa !27
  br label %bb188
bb187:
  br label %bb201
bb188:
  store %olang.scope zeroinitializer, ptr %s24
  %t578 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s24, ptr %t578, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d159, i32 0, i32 1) })
  br label %bb189
bb189:
  %t580 = load ptr, ptr %l26, !tbaa !29
  %t582 = icmp eq ptr %t580, null
  %t584 = xor i1 %t582, true
  br i1 %t584, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s25
  %t586 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s25, ptr %t586, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) })
  br label %bb192
bb191:
  br label %bb194
bb192:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t588, ptr %t589)
  br label %bb193
bb193:
  call void @__olang_scope_close(ptr %s25)
  br label %bb194
bb194:
  %t592 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t594 = extractvalue { i64, ptr } %t592, 0
  %t595 = extractvalue { i64, ptr } { i64 -1, ptr null }, 0
  %t596 = icmp eq i64 %t594, %t595
  %t597 = extractvalue { i64, ptr } %t592, 1
  %t598 = extractvalue { i64, ptr } { i64 -1, ptr null }, 1
  %t599 = icmp eq ptr %t597, %t598
  %t600 = and i1 %t596, %t599
  %t602 = xor i1 %t600, true
  br i1 %t602, label %bb195, label %bb196
bb195:
  store %olang.scope zeroinitializer, ptr %s26
  %t604 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t604, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d161, i32 0, i32 1) })
  br label %bb197
bb196:
  br label %bb200
bb197:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eitems(ptr %v0, ptr %v1, ptr %t606, { i64, ptr } %t607)
  br label %bb198
bb198:
  %t610 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t610, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) })
  br label %bb199
bb199:
  call void @__olang_scope_close(ptr %s26)
  br label %bb200
bb200:
  call void @__olang_scope_close(ptr %s24)
  br label %bb246
bb201:
  %t612 = load ptr, ptr %l1, !tbaa !29
  store ptr %t612, ptr %l294, !tbaa !29
  store i1 false, ptr %l295, !tbaa !21
  %t613 = load ptr, ptr %l294, !tbaa !29
  %t614 = icmp ne ptr %t613, null
  br i1 %t614, label %bb202, label %bb203
bb202:
  %t616 = load ptr, ptr %l294, !tbaa !29
  %t617 = load i64, ptr %t616, !range !{i64 0, i64 22}
  %t619 = icmp eq i64 %t617, 17
  store i1 %t619, ptr %l295, !tbaa !21
  br label %bb203
bb203:
  %t620 = load i1, ptr %l295, !tbaa !21
  br i1 %t620, label %bb204, label %bb205
bb204:
  %t621 = load ptr, ptr %l1, !tbaa !29
  %t623 = getelementptr { i64, [4 x i64] }, ptr %t621, i32 0, i32 1
  %t624 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t623, i32 0, i32 1
  %t625 = load { i64, ptr }, ptr %t624
  store { i64, ptr } %t625, ptr %l28, !tbaa !27
  %t627 = load ptr, ptr %l1, !tbaa !29
  %t629 = getelementptr { i64, [4 x i64] }, ptr %t627, i32 0, i32 1
  %t630 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t629, i32 0, i32 2
  %t631 = load ptr, ptr %t630
  store ptr %t631, ptr %l29, !tbaa !29
  br label %bb206
bb205:
  br label %bb214
bb206:
  store %olang.scope zeroinitializer, ptr %s27
  %t633 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s27, ptr %t633, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d163, i32 0, i32 1) })
  br label %bb207
bb207:
  %t635 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t637 = extractvalue { i64, ptr } %t635, 0
  %t639 = icmp sgt i64 %t637, 0
  br i1 %t639, label %bb208, label %bb209
bb208:
  store %olang.scope zeroinitializer, ptr %s28
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t641, { i64, ptr } %t642)
  br label %bb210
bb209:
  br label %bb212
bb210:
  %t645 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s28, ptr %t645, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d164, i32 0, i32 1) })
  br label %bb211
bb211:
  call void @__olang_scope_close(ptr %s28)
  br label %bb212
bb212:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t648 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t647, ptr %t648)
  br label %bb213
bb213:
  call void @__olang_scope_close(ptr %s27)
  br label %bb246
bb214:
  %t651 = load ptr, ptr %l1, !tbaa !29
  store ptr %t651, ptr %l311, !tbaa !29
  store i1 false, ptr %l312, !tbaa !21
  %t652 = load ptr, ptr %l311, !tbaa !29
  %t653 = icmp ne ptr %t652, null
  br i1 %t653, label %bb215, label %bb216
bb215:
  %t655 = load ptr, ptr %l311, !tbaa !29
  %t656 = load i64, ptr %t655, !range !{i64 0, i64 22}
  %t658 = icmp eq i64 %t656, 18
  store i1 %t658, ptr %l312, !tbaa !21
  br label %bb216
bb216:
  %t659 = load i1, ptr %l312, !tbaa !21
  br i1 %t659, label %bb217, label %bb218
bb217:
  %t660 = load ptr, ptr %l1, !tbaa !29
  %t662 = getelementptr { i64, [4 x i64] }, ptr %t660, i32 0, i32 1
  %t663 = getelementptr { %"compiler/source:Span", ptr }, ptr %t662, i32 0, i32 1
  %t664 = load ptr, ptr %t663
  store ptr %t664, ptr %l30, !tbaa !29
  br label %bb219
bb218:
  br label %bb227
bb219:
  store %olang.scope zeroinitializer, ptr %s29
  %t666 = load ptr, ptr %l30, !tbaa !29
  %t668 = getelementptr %"compiler/ast:JoinS", ptr %t666, i32 0, i32 0
  %t669 = load i1, ptr %t668, !tbaa !21
  br i1 %t669, label %bb220, label %bb221
bb220:
  store %olang.scope zeroinitializer, ptr %s30
  %t671 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s30, ptr %t671, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d165, i32 0, i32 1) })
  br label %bb222
bb221:
  br label %bb223
bb222:
  call void @__olang_scope_close(ptr %s30)
  br label %bb223
bb223:
  %t673 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t673, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d166, i32 0, i32 1) })
  br label %bb224
bb224:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t676 = load ptr, ptr %l30, !tbaa !29
  %t678 = getelementptr %"compiler/ast:JoinS", ptr %t676, i32 0, i32 1
  %t679 = load { i64, ptr }, ptr %t678, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t675, { i64, ptr } %t679)
  br label %bb225
bb225:
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t683 = load ptr, ptr %l30, !tbaa !29
  %t685 = getelementptr %"compiler/ast:JoinS", ptr %t683, i32 0, i32 2
  %t686 = load { i64, ptr }, ptr %t685, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eclauses(ptr %v0, ptr %v1, ptr %t682, { i64, ptr } %t686)
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s29)
  br label %bb246
bb227:
  %t689 = load ptr, ptr %l1, !tbaa !29
  store ptr %t689, ptr %l327, !tbaa !29
  store i1 false, ptr %l328, !tbaa !21
  %t690 = load ptr, ptr %l327, !tbaa !29
  %t691 = icmp ne ptr %t690, null
  br i1 %t691, label %bb228, label %bb229
bb228:
  %t693 = load ptr, ptr %l327, !tbaa !29
  %t694 = load i64, ptr %t693, !range !{i64 0, i64 22}
  %t696 = icmp eq i64 %t694, 19
  store i1 %t696, ptr %l328, !tbaa !21
  br label %bb229
bb229:
  %t697 = load i1, ptr %l328, !tbaa !21
  br i1 %t697, label %bb230, label %bb231
bb230:
  %t698 = load ptr, ptr %l1, !tbaa !29
  %t700 = getelementptr { i64, [4 x i64] }, ptr %t698, i32 0, i32 1
  %t701 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t700, i32 0, i32 1
  %t702 = load ptr, ptr %t701
  store ptr %t702, ptr %l31, !tbaa !29
  %t704 = load ptr, ptr %l1, !tbaa !29
  %t706 = getelementptr { i64, [4 x i64] }, ptr %t704, i32 0, i32 1
  %t707 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t706, i32 0, i32 2
  %t708 = load i1, ptr %t707
  store i1 %t708, ptr %l32, !tbaa !21
  br label %bb232
bb231:
  br label %bb238
bb232:
  store %olang.scope zeroinitializer, ptr %s31
  %t710 = load ptr, ptr %l0, !tbaa !29
  store ptr %t710, ptr %l335, !tbaa !29
  %t711 = load i1, ptr %l32, !tbaa !21
  br i1 %t711, label %bb233, label %bb234
bb233:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d167, i32 0, i32 1) }, ptr %l337, !tbaa !27
  br label %bb235
bb234:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d168, i32 0, i32 1) }, ptr %l337, !tbaa !27
  br label %bb235
bb235:
  %t713 = load ptr, ptr %l335, !tbaa !29
  %t714 = load { i64, ptr }, ptr %l337, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s31, ptr %t713, { i64, ptr } %t714)
  br label %bb236
bb236:
  %t715 = load ptr, ptr %l0, !tbaa !29
  %t716 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2estmt(ptr %v0, ptr %v1, ptr %t715, ptr %t716)
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s31)
  br label %bb246
bb238:
  %t719 = load ptr, ptr %l1, !tbaa !29
  store ptr %t719, ptr %l340, !tbaa !29
  store i1 false, ptr %l341, !tbaa !21
  %t720 = load ptr, ptr %l340, !tbaa !29
  %t721 = icmp ne ptr %t720, null
  br i1 %t721, label %bb239, label %bb240
bb239:
  %t723 = load ptr, ptr %l340, !tbaa !29
  %t724 = load i64, ptr %t723, !range !{i64 0, i64 22}
  %t726 = icmp eq i64 %t724, 20
  store i1 %t726, ptr %l341, !tbaa !21
  br label %bb240
bb240:
  %t727 = load i1, ptr %l341, !tbaa !21
  br i1 %t727, label %bb241, label %bb242
bb241:
  %t728 = load ptr, ptr %l1, !tbaa !29
  %t730 = getelementptr { i64, [4 x i64] }, ptr %t728, i32 0, i32 1
  %t731 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t730, i32 0, i32 1
  %t732 = load { i64, ptr }, ptr %t731
  store { i64, ptr } %t732, ptr %l33, !tbaa !27
  br label %bb243
bb242:
  br label %bb245
bb243:
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t735 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t734, { i64, ptr } %t735)
  br label %bb244
bb244:
  br label %bb246
bb245:
  call void @__olang_check_failed(ptr @olang_loc_9166140a1ac8280_ddd22134593fa34)
  unreachable
bb246:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l34 = alloca i1
  %l40 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopBranch", ptr %t5, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t4, i64 %t8)
  store i1 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopBranch", ptr %t14, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2espan(ptr %v0, ptr %t13, %"compiler/source:Span" %t17)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/unparse:writer", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TopBranch", ptr %t23, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t22, %"compiler/source:Span" %t26)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t29, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d169, i32 0, i32 1) })
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = getelementptr %"compiler/unparse:writer", ptr %t32, i32 0, i32 4
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = add i64 %t34, 1
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = getelementptr %"compiler/unparse:writer", ptr %t38, i32 0, i32 4
  store i64 %t36, ptr %t39, !tbaa !24
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TopBranch", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  store ptr %t63, ptr %l5, !tbaa !29
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t67 = call i1 @compiler_2funparse_2ehidden(ptr %v1, ptr %t65)
  store i1 %t67, ptr %l34
  br label %bb12
bb12:
  %t68 = load i1, ptr %l34, !tbaa !21
  br i1 %t68, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t69)
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2edecl(ptr %v0, ptr %v1, ptr %t71, ptr %t72)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l3, !tbaa !24
  br label %bb8
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l40, !tbaa !29
  %t80 = load ptr, ptr %l40, !tbaa !29
  %t81 = getelementptr %"compiler/unparse:writer", ptr %t80, i32 0, i32 4
  %t82 = load i64, ptr %t81, !tbaa !24
  %t84 = sub i64 %t82, 1
  %t86 = load ptr, ptr %l40, !tbaa !29
  %t87 = getelementptr %"compiler/unparse:writer", ptr %t86, i32 0, i32 4
  store i64 %t84, ptr %t87, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t88)
  br label %bb20
bb20:
  %t90 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t90, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d170, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l10 = alloca ptr
  %l21 = alloca ptr
  %l32 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d171, i32 0, i32 1) })
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/ast:TopIf", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_69b21e264e8a714a_b3e97d9d77526506)
  unreachable
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:TopIf", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t15 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t15, ptr %t14)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t17, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d172, i32 0, i32 1) })
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/ast:TopIf", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8585d6fe8f316a51_b60a12ce50df87ed)
  unreachable
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:TopIf", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t31, ptr %t30)
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/ast:TopIf", ptr %t33, i32 0, i32 2
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t42 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t42, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb13
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TopIf", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = icmp eq ptr %t47, null
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb18, label %bb19
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l21, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:TopIf", ptr %t54, i32 0, i32 2
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_eabe3ddcfaef285c_106dba970e52f8d8)
  unreachable
bb15:
  br label %bb16
bb16:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:TopIf", ptr %t61, i32 0, i32 2
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopIf(ptr %v0, ptr %v1, ptr %t65, ptr %t64)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t67, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d174, i32 0, i32 1) })
  br label %bb20
bb19:
  br label %bb25
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l32, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/ast:TopIf", ptr %t70, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_14b8182deed7e34b_cfe8cf3ea4c448f7)
  unreachable
bb22:
  br label %bb23
bb23:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/ast:TopIf", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etopBranch(ptr %v0, ptr %v1, ptr %t81, ptr %t80)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l40 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l82 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca ptr
  %l96 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l128 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l139 = alloca i1
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t2 = load ptr, ptr %l24, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l24, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l25, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l25, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb23
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb7, label %bb8
bb7:
  br label %bb16
bb8:
  br label %bb9
bb9:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t38, ptr %l40, !tbaa !27
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i32, ptr %t42, i64 %t39
  %t44 = load i32, ptr %t43, !tbaa !33
  store i32 %t44, ptr %l8, !tbaa !23
  %t48 = icmp sgt i64 %t36, 0
  br i1 %t48, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t50, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) })
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t52, i32 %t53)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb6
bb16:
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t66 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t66, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %t68, { i64, ptr } %t69)
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t72, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  br label %bb106
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t75 = load ptr, ptr %l57, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l57, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 8}
  %t81 = icmp eq i64 %t79, 1
  store i1 %t81, ptr %l58, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l58, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l9, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efuncType(ptr %v0, ptr %v1, ptr %s7, ptr %t89, ptr %t90, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d178, i32 0, i32 1) })
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb106
bb30:
  %t93 = load ptr, ptr %l1, !tbaa !29
  store ptr %t93, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t94 = load ptr, ptr %l65, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb31, label %bb32
bb31:
  %t97 = load ptr, ptr %l65, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 8}
  %t100 = icmp eq i64 %t98, 2
  store i1 %t100, ptr %l66, !tbaa !21
  br label %bb32
bb32:
  %t101 = load i1, ptr %l66, !tbaa !21
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr }, ptr %t104, i32 0, i32 1
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l10, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t108, ptr %t109)
  br label %bb36
bb36:
  br label %bb106
bb37:
  %t112 = load ptr, ptr %l1, !tbaa !29
  store ptr %t112, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t113 = load ptr, ptr %l73, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb38, label %bb39
bb38:
  %t116 = load ptr, ptr %l73, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 8}
  %t119 = icmp eq i64 %t117, 3
  store i1 %t119, ptr %l74, !tbaa !21
  br label %bb39
bb39:
  %t120 = load i1, ptr %l74, !tbaa !21
  br i1 %t120, label %bb40, label %bb41
bb40:
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l11, !tbaa !29
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t129, i32 0, i32 2
  %t131 = load i1, ptr %t130
  store i1 %t131, ptr %l12, !tbaa !21
  br label %bb42
bb41:
  br label %bb56
bb42:
  %t133 = load ptr, ptr %l11, !tbaa !29
  %t135 = call ptr @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eFuncSig(ptr %v1, ptr %v1, ptr %t133)
  store ptr %t135, ptr %l82
  br label %bb43
bb43:
  %t136 = load ptr, ptr %l82, !tbaa !29
  store ptr %t136, ptr %l13, !tbaa !29
  %t137 = load ptr, ptr %l13, !tbaa !29
  %t139 = icmp eq ptr %t137, null
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l86, !tbaa !29
  %t144 = load ptr, ptr %l13, !tbaa !29
  store ptr %t144, ptr %l87, !tbaa !29
  %t145 = load i1, ptr %l12, !tbaa !21
  br i1 %t145, label %bb46, label %bb47
bb45:
  store %olang.scope zeroinitializer, ptr %s11
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t147, ptr %t148)
  br label %bb50
bb46:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d179, i32 0, i32 1) }, ptr %l89, !tbaa !27
  br label %bb48
bb47:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d180, i32 0, i32 1) }, ptr %l89, !tbaa !27
  br label %bb48
bb48:
  %t151 = load ptr, ptr %l86, !tbaa !29
  %t152 = load ptr, ptr %l87, !tbaa !29
  %t153 = load { i64, ptr }, ptr %l89, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2efuncType(ptr %v0, ptr %v1, ptr %s10, ptr %t151, ptr %t152, { i64, ptr } %t153)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb50:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l92, !tbaa !29
  %t155 = load i1, ptr %l12, !tbaa !21
  br i1 %t155, label %bb51, label %bb52
bb51:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d181, i32 0, i32 1) }, ptr %l94, !tbaa !27
  br label %bb53
bb52:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d182, i32 0, i32 1) }, ptr %l94, !tbaa !27
  br label %bb53
bb53:
  %t157 = load ptr, ptr %l92, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l94, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t157, { i64, ptr } %t158)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb55:
  br label %bb106
bb56:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t160 = load ptr, ptr %l95, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb57, label %bb58
bb57:
  %t163 = load ptr, ptr %l95, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 8}
  %t166 = icmp eq i64 %t164, 5
  store i1 %t166, ptr %l96, !tbaa !21
  br label %bb58
bb58:
  %t167 = load i1, ptr %l96, !tbaa !21
  br i1 %t167, label %bb59, label %bb60
bb59:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [5 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr }, ptr %t170, i32 0, i32 1
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l14, !tbaa !29
  br label %bb61
bb60:
  br label %bb64
bb61:
  store %olang.scope zeroinitializer, ptr %s12
  %t174 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s12, ptr %t174, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d183, i32 0, i32 1) })
  br label %bb62
bb62:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t176, ptr %t177)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb106
bb64:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t181 = load ptr, ptr %l104, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb65, label %bb66
bb65:
  %t184 = load ptr, ptr %l104, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 8}
  %t187 = icmp eq i64 %t185, 7
  store i1 %t187, ptr %l105, !tbaa !21
  br label %bb66
bb66:
  %t188 = load i1, ptr %l105, !tbaa !21
  br i1 %t188, label %bb67, label %bb68
bb67:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", ptr }, ptr %t191, i32 0, i32 1
  %t193 = load ptr, ptr %t192
  store ptr %t193, ptr %l15, !tbaa !29
  br label %bb69
bb68:
  br label %bb72
bb69:
  store %olang.scope zeroinitializer, ptr %s13
  %t195 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t195, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d184, i32 0, i32 1) })
  br label %bb70
bb70:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t197, ptr %t198)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s13)
  br label %bb106
bb72:
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t202 = load ptr, ptr %l113, !tbaa !29
  %t203 = icmp ne ptr %t202, null
  br i1 %t203, label %bb73, label %bb74
bb73:
  %t205 = load ptr, ptr %l113, !tbaa !29
  %t206 = load i64, ptr %t205, !range !{i64 0, i64 8}
  %t208 = icmp eq i64 %t206, 6
  store i1 %t208, ptr %l114, !tbaa !21
  br label %bb74
bb74:
  %t209 = load i1, ptr %l114, !tbaa !21
  br i1 %t209, label %bb75, label %bb76
bb75:
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t212, i32 0, i32 1
  %t214 = load { i64, ptr }, ptr %t213
  store { i64, ptr } %t214, ptr %l16, !tbaa !27
  br label %bb77
bb76:
  br label %bb90
bb77:
  store %olang.scope zeroinitializer, ptr %s14
  %t216 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t216, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d185, i32 0, i32 1) })
  br label %bb78
bb78:
  %t218 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t218, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 0
  store i64 %t222, ptr %l19, !tbaa !24
  br label %bb79
bb79:
  %t224 = load i64, ptr %l18, !tbaa !24
  %t225 = load i64, ptr %l19, !tbaa !24
  %t228 = icmp slt i64 %t224, %t225
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb80, label %bb81
bb80:
  br label %bb89
bb81:
  br label %bb82
bb82:
  %t232 = load i64, ptr %l18, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t234, ptr %l128, !tbaa !27
  %t235 = load i64, ptr %l18, !tbaa !24
  %t237 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr ptr, ptr %t238, i64 %t235
  %t240 = load ptr, ptr %t239, !tbaa !39
  store ptr %t240, ptr %l21, !tbaa !29
  %t244 = icmp sgt i64 %t232, 0
  br i1 %t244, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s17
  %t246 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t246, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d186, i32 0, i32 1) })
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s17)
  br label %bb86
bb86:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t248, ptr %t249)
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t252 = load i64, ptr %l18, !tbaa !24
  %t254 = add i64 %t252, 1
  store i64 %t254, ptr %l18, !tbaa !24
  br label %bb79
bb89:
  call void @__olang_scope_close(ptr %s14)
  br label %bb106
bb90:
  %t256 = load ptr, ptr %l1, !tbaa !29
  store ptr %t256, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t257 = load ptr, ptr %l138, !tbaa !29
  %t258 = icmp ne ptr %t257, null
  br i1 %t258, label %bb91, label %bb92
bb91:
  %t260 = load ptr, ptr %l138, !tbaa !29
  %t261 = load i64, ptr %t260, !range !{i64 0, i64 8}
  %t263 = icmp eq i64 %t261, 4
  store i1 %t263, ptr %l139, !tbaa !21
  br label %bb92
bb92:
  %t264 = load i1, ptr %l139, !tbaa !21
  br i1 %t264, label %bb93, label %bb94
bb93:
  %t265 = load ptr, ptr %l1, !tbaa !29
  %t267 = getelementptr { i64, [5 x i64] }, ptr %t265, i32 0, i32 1
  %t268 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t267, i32 0, i32 1
  %t269 = load ptr, ptr %t268
  store ptr %t269, ptr %l22, !tbaa !29
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr { i64, [5 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t273, i32 0, i32 2
  %t275 = load i1, ptr %t274
  store i1 %t275, ptr %l23, !tbaa !21
  br label %bb95
bb94:
  br label %bb105
bb95:
  %t277 = load i1, ptr %l23, !tbaa !21
  br i1 %t277, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s20
  %t279 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s20, ptr %t279, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d187, i32 0, i32 1) })
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_scope_close(ptr %s20)
  br label %bb99
bb99:
  %t281 = load ptr, ptr %l22, !tbaa !29
  %t283 = icmp eq ptr %t281, null
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s21
  %t287 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s21, ptr %t287, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d188, i32 0, i32 1) })
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t289, ptr %t290)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s21)
  br label %bb104
bb104:
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_9034b6aed20fb51a_d179ca40c5e654ce)
  unreachable
bb106:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l48 = alloca ptr
  %l54 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i1
  %l87 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l140 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca i1
  %l168 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l203 = alloca ptr
  %l213 = alloca { i64, ptr }
  %l230 = alloca ptr
  %l235 = alloca ptr
  %l236 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s29 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t2 = load ptr, ptr %l29, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l29, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l30, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l30, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb151
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t11 = load ptr, ptr %l33, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l33, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 5}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l34, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l34, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [6 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { ptr }, ptr %t21, i32 0, i32 0
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb32
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t25, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d189, i32 0, i32 1) })
  br label %bb12
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/ast:StructBody", ptr %t28, i32 0, i32 5
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t27, { i64, ptr } %t31)
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t34, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d190, i32 0, i32 1) })
  br label %bb14
bb14:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:StructBody", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t36, { i64, ptr } %t40)
  br label %bb15
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t43, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d191, i32 0, i32 1) })
  br label %bb16
bb16:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l48, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/ast:StructBody", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8cd05a7785ffddf0_abfc69165374635c)
  unreachable
bb18:
  br label %bb19
bb19:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:StructBody", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtract(ptr %v0, ptr %v1, ptr %t57, ptr %t56)
  br label %bb20
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l54, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:StructBody", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_c53cd7dd70350acf_d5f64367475d1e4b)
  unreachable
bb22:
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = getelementptr %"compiler/ast:StructBody", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t71 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t71, ptr %t70)
  br label %bb24
bb24:
  %t73 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s2, ptr %t73, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d192, i32 0, i32 1) })
  br label %bb25
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:StructBody", ptr %t76, i32 0, i32 2
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t75, { i64, ptr } %t79)
  br label %bb26
bb26:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = getelementptr %"compiler/ast:StructBody", ptr %t82, i32 0, i32 3
  %t85 = getelementptr %"compiler/source:Span", ptr %t84, i32 0, i32 1
  %t86 = load i32, ptr %t85, !tbaa !23
  %t88 = icmp sgt i32 %t86, 0
  br i1 %t88, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t90, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d193, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/ast:StructBody", ptr %t93, i32 0, i32 4
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t92, { i64, ptr } %t96)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb151
bb32:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t100 = load ptr, ptr %l71, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l71, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 5}
  %t106 = icmp eq i64 %t104, 1
  store i1 %t106, ptr %l72, !tbaa !21
  br label %bb34
bb34:
  %t107 = load i1, ptr %l72, !tbaa !21
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [6 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { { i64, ptr }, ptr }, ptr %t110, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111
  store { i64, ptr } %t112, ptr %l3, !tbaa !27
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [6 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { { i64, ptr }, ptr }, ptr %t116, i32 0, i32 1
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l4, !tbaa !29
  br label %bb37
bb36:
  br label %bb78
bb37:
  store %olang.scope zeroinitializer, ptr %s4
  %t120 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t120, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d194, i32 0, i32 1) })
  br label %bb38
bb38:
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t128, ptr %t129)
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t132 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t132, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d195, i32 0, i32 1) })
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  %t134 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t134, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d196, i32 0, i32 1) })
  br label %bb44
bb44:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l87, !tbaa !29
  %t137 = load ptr, ptr %l87, !tbaa !29
  %t138 = getelementptr %"compiler/unparse:writer", ptr %t137, i32 0, i32 4
  %t139 = load i64, ptr %t138, !tbaa !24
  %t141 = add i64 %t139, 1
  %t143 = load ptr, ptr %l87, !tbaa !29
  %t144 = getelementptr %"compiler/unparse:writer", ptr %t143, i32 0, i32 4
  store i64 %t141, ptr %t144, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t145, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  store i64 %t149, ptr %l7, !tbaa !24
  br label %bb45
bb45:
  %t151 = load i64, ptr %l6, !tbaa !24
  %t152 = load i64, ptr %l7, !tbaa !24
  %t155 = icmp slt i64 %t151, %t152
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb46, label %bb47
bb46:
  br label %bb75
bb47:
  br label %bb48
bb48:
  %t159 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t159, ptr %l97, !tbaa !27
  %t160 = load i64, ptr %l6, !tbaa !24
  %t162 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr ptr, ptr %t163, i64 %t160
  %t165 = load ptr, ptr %t164, !tbaa !39
  store ptr %t165, ptr %l8, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t167)
  br label %bb49
bb49:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l8, !tbaa !29
  %t172 = getelementptr %"compiler/ast:CaseDecl", ptr %t170, i32 0, i32 5
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eattrs(ptr %v0, ptr %v1, ptr %t169, { i64, ptr } %t173)
  br label %bb50
bb50:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l8, !tbaa !29
  %t179 = getelementptr %"compiler/ast:CaseDecl", ptr %t177, i32 0, i32 1
  %t180 = load i32, ptr %t179, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t176, i32 %t180)
  br label %bb51
bb51:
  %t183 = load ptr, ptr %l8, !tbaa !29
  %t185 = getelementptr %"compiler/ast:CaseDecl", ptr %t183, i32 0, i32 3
  %t186 = load i1, ptr %t185, !tbaa !21
  br i1 %t186, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s8
  %t188 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t188, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d197, i32 0, i32 1) })
  br label %bb54
bb53:
  %t190 = load ptr, ptr %l8, !tbaa !29
  %t192 = getelementptr %"compiler/ast:CaseDecl", ptr %t190, i32 0, i32 2
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t197 = icmp sgt i64 %t195, 0
  br i1 %t197, label %bb59, label %bb60
bb54:
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l110, !tbaa !29
  %t200 = load ptr, ptr %l8, !tbaa !29
  %t202 = getelementptr %"compiler/ast:CaseDecl", ptr %t200, i32 0, i32 2
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  store { i64, ptr } %t203, ptr %l112, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr ptr, ptr %t205, i64 0
  %t207 = load ptr, ptr %t206, !tbaa !39
  %t209 = getelementptr %"compiler/ast:Param", ptr %t207, i32 0, i32 2
  %t210 = load ptr, ptr %t209, !tbaa !29
  store ptr %t210, ptr %l9, !tbaa !29
  %t212 = load ptr, ptr %l9, !tbaa !29
  %t214 = icmp eq ptr %t212, null
  br i1 %t214, label %bb55, label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_565cf8a51c2b309e_2af0495fa70fac4a)
  unreachable
bb56:
  br label %bb57
bb57:
  %t216 = load ptr, ptr %l9, !tbaa !29
  %t217 = load ptr, ptr %l110, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t217, ptr %t216)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s8)
  br label %bb65
bb59:
  store %olang.scope zeroinitializer, ptr %s10
  %t219 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t219, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d198, i32 0, i32 1) })
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l8, !tbaa !29
  %t224 = getelementptr %"compiler/ast:CaseDecl", ptr %t222, i32 0, i32 2
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t221, { i64, ptr } %t225)
  br label %bb62
bb62:
  %t228 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s10, ptr %t228, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d199, i32 0, i32 1) })
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t230 = load ptr, ptr %l8, !tbaa !29
  %t232 = getelementptr %"compiler/ast:CaseDecl", ptr %t230, i32 0, i32 4
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t235 = icmp eq ptr %t233, null
  %t237 = xor i1 %t235, true
  br i1 %t237, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s11
  %t239 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s11, ptr %t239, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d200, i32 0, i32 1) })
  br label %bb68
bb67:
  br label %bb73
bb68:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l132, !tbaa !29
  %t242 = load ptr, ptr %l8, !tbaa !29
  %t244 = getelementptr %"compiler/ast:CaseDecl", ptr %t242, i32 0, i32 4
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = icmp eq ptr %t245, null
  br i1 %t247, label %bb69, label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_a9c38de43eb77545_46c40237e7b6a551)
  unreachable
bb70:
  br label %bb71
bb71:
  %t249 = load ptr, ptr %l8, !tbaa !29
  %t251 = getelementptr %"compiler/ast:CaseDecl", ptr %t249, i32 0, i32 4
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t253 = load ptr, ptr %l132, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexpr(ptr %v0, ptr %v1, ptr %t253, ptr %t252)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t255 = load i64, ptr %l6, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l6, !tbaa !24
  br label %bb45
bb75:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l140, !tbaa !29
  %t260 = load ptr, ptr %l140, !tbaa !29
  %t261 = getelementptr %"compiler/unparse:writer", ptr %t260, i32 0, i32 4
  %t262 = load i64, ptr %t261, !tbaa !24
  %t264 = sub i64 %t262, 1
  %t266 = load ptr, ptr %l140, !tbaa !29
  %t267 = getelementptr %"compiler/unparse:writer", ptr %t266, i32 0, i32 4
  store i64 %t264, ptr %t267, !tbaa !24
  %t268 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t268)
  br label %bb76
bb76:
  %t270 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t270, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d201, i32 0, i32 1) })
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s4)
  br label %bb151
bb78:
  %t272 = load ptr, ptr %l1, !tbaa !29
  store ptr %t272, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t273 = load ptr, ptr %l145, !tbaa !29
  %t274 = icmp ne ptr %t273, null
  br i1 %t274, label %bb79, label %bb80
bb79:
  %t276 = load ptr, ptr %l145, !tbaa !29
  %t277 = load i64, ptr %t276, !range !{i64 0, i64 5}
  %t279 = icmp eq i64 %t277, 2
  store i1 %t279, ptr %l146, !tbaa !21
  br label %bb80
bb80:
  %t280 = load i1, ptr %l146, !tbaa !21
  br i1 %t280, label %bb81, label %bb82
bb81:
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr { i64, [6 x i64] }, ptr %t281, i32 0, i32 1
  %t284 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t283, i32 0, i32 0
  %t285 = load { i64, ptr }, ptr %t284
  store { i64, ptr } %t285, ptr %l10, !tbaa !27
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = getelementptr { i64, [6 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t289, i32 0, i32 1
  %t291 = load { i64, ptr }, ptr %t290
  store { i64, ptr } %t291, ptr %l11, !tbaa !27
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t295 = getelementptr { i64, [6 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t295, i32 0, i32 2
  %t297 = load { i64, ptr }, ptr %t296
  store { i64, ptr } %t297, ptr %l12, !tbaa !27
  br label %bb83
bb82:
  br label %bb133
bb83:
  store %olang.scope zeroinitializer, ptr %s13
  %t299 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t299, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d202, i32 0, i32 1) })
  br label %bb84
bb84:
  %t301 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t305 = icmp sgt i64 %t303, 0
  br i1 %t305, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s14
  %t307 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t307, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d203, i32 0, i32 1) })
  br label %bb87
bb86:
  br label %bb100
bb87:
  %t309 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t309, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t311 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t311, 0
  store i64 %t313, ptr %l15, !tbaa !24
  br label %bb88
bb88:
  %t315 = load i64, ptr %l14, !tbaa !24
  %t316 = load i64, ptr %l15, !tbaa !24
  %t319 = icmp slt i64 %t315, %t316
  %t321 = xor i1 %t319, true
  br i1 %t321, label %bb89, label %bb90
bb89:
  br label %bb98
bb90:
  br label %bb91
bb91:
  %t323 = load i64, ptr %l14, !tbaa !24
  %t325 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t325, ptr %l168, !tbaa !27
  %t326 = load i64, ptr %l14, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr ptr, ptr %t329, i64 %t326
  %t331 = load ptr, ptr %t330, !tbaa !39
  store ptr %t331, ptr %l17, !tbaa !29
  %t335 = icmp sgt i64 %t323, 0
  br i1 %t335, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s17
  %t337 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s17, ptr %t337, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d204, i32 0, i32 1) })
  br label %bb94
bb93:
  br label %bb95
bb94:
  call void @__olang_scope_close(ptr %s17)
  br label %bb95
bb95:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t339, ptr %t340)
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t343 = load i64, ptr %l14, !tbaa !24
  %t345 = add i64 %t343, 1
  store i64 %t345, ptr %l14, !tbaa !24
  br label %bb88
bb98:
  %t347 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s14, ptr %t347, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d205, i32 0, i32 1) })
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s14)
  br label %bb100
bb100:
  %t349 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t349, 0
  %t353 = icmp sgt i64 %t351, 0
  br i1 %t353, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s19
  %t355 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t355, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb103
bb102:
  br label %bb116
bb103:
  %t357 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t357, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t359 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t359, 0
  store i64 %t361, ptr %l20, !tbaa !24
  br label %bb104
bb104:
  %t363 = load i64, ptr %l19, !tbaa !24
  %t364 = load i64, ptr %l20, !tbaa !24
  %t367 = icmp slt i64 %t363, %t364
  %t369 = xor i1 %t367, true
  br i1 %t369, label %bb105, label %bb106
bb105:
  br label %bb114
bb106:
  br label %bb107
bb107:
  %t371 = load i64, ptr %l19, !tbaa !24
  %t373 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t373, ptr %l191, !tbaa !27
  %t374 = load i64, ptr %l19, !tbaa !24
  %t376 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr ptr, ptr %t377, i64 %t374
  %t379 = load ptr, ptr %t378, !tbaa !39
  store ptr %t379, ptr %l22, !tbaa !29
  %t383 = icmp sgt i64 %t371, 0
  br i1 %t383, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s22
  %t385 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s22, ptr %t385, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d207, i32 0, i32 1) })
  br label %bb110
bb109:
  br label %bb111
bb110:
  call void @__olang_scope_close(ptr %s22)
  br label %bb111
bb111:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t387, ptr %t388)
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t391 = load i64, ptr %l19, !tbaa !24
  %t393 = add i64 %t391, 1
  store i64 %t393, ptr %l19, !tbaa !24
  br label %bb104
bb114:
  %t395 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s19, ptr %t395, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) })
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s19)
  br label %bb116
bb116:
  %t397 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t397, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) })
  br label %bb117
bb117:
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l203, !tbaa !29
  %t400 = load ptr, ptr %l203, !tbaa !29
  %t401 = getelementptr %"compiler/unparse:writer", ptr %t400, i32 0, i32 4
  %t402 = load i64, ptr %t401, !tbaa !24
  %t404 = add i64 %t402, 1
  %t406 = load ptr, ptr %l203, !tbaa !29
  %t407 = getelementptr %"compiler/unparse:writer", ptr %t406, i32 0, i32 4
  store i64 %t404, ptr %t407, !tbaa !24
  %t408 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t408, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t410 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t410, 0
  store i64 %t412, ptr %l25, !tbaa !24
  br label %bb118
bb118:
  %t414 = load i64, ptr %l24, !tbaa !24
  %t415 = load i64, ptr %l25, !tbaa !24
  %t418 = icmp slt i64 %t414, %t415
  %t420 = xor i1 %t418, true
  br i1 %t420, label %bb119, label %bb120
bb119:
  br label %bb130
bb120:
  br label %bb121
bb121:
  %t422 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t422, ptr %l213, !tbaa !27
  %t423 = load i64, ptr %l24, !tbaa !24
  %t425 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !27
  %t427 = getelementptr ptr, ptr %t426, i64 %t423
  %t428 = load ptr, ptr %t427, !tbaa !39
  store ptr %t428, ptr %l26, !tbaa !29
  %t430 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t430)
  br label %bb122
bb122:
  %t432 = load ptr, ptr %l26, !tbaa !29
  %t434 = getelementptr %"compiler/ast:Func", ptr %t432, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !29
  %t437 = icmp eq ptr %t435, null
  %t439 = xor i1 %t437, true
  br i1 %t439, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s26
  %t441 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s26, ptr %t441, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d210, i32 0, i32 1) })
  br label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_scope_close(ptr %s26)
  br label %bb126
bb126:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load ptr, ptr %l26, !tbaa !29
  %t446 = getelementptr %"compiler/ast:Func", ptr %t444, i32 0, i32 2
  %t447 = load i32, ptr %t446, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t443, i32 %t447)
  br label %bb127
bb127:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load ptr, ptr %l26, !tbaa !29
  %t453 = getelementptr %"compiler/ast:Func", ptr %t451, i32 0, i32 3
  %t454 = load ptr, ptr %t453, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2esig(ptr %v0, ptr %v1, ptr %t450, ptr %t454)
  br label %bb128
bb128:
  br label %bb129
bb129:
  %t457 = load i64, ptr %l24, !tbaa !24
  %t459 = add i64 %t457, 1
  store i64 %t459, ptr %l24, !tbaa !24
  br label %bb118
bb130:
  %t461 = load ptr, ptr %l0, !tbaa !29
  store ptr %t461, ptr %l230, !tbaa !29
  %t462 = load ptr, ptr %l230, !tbaa !29
  %t463 = getelementptr %"compiler/unparse:writer", ptr %t462, i32 0, i32 4
  %t464 = load i64, ptr %t463, !tbaa !24
  %t466 = sub i64 %t464, 1
  %t468 = load ptr, ptr %l230, !tbaa !29
  %t469 = getelementptr %"compiler/unparse:writer", ptr %t468, i32 0, i32 4
  store i64 %t466, ptr %t469, !tbaa !24
  %t470 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2enl(ptr %v0, ptr %t470)
  br label %bb131
bb131:
  %t472 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s13, ptr %t472, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) })
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s13)
  br label %bb151
bb133:
  %t474 = load ptr, ptr %l1, !tbaa !29
  store ptr %t474, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t475 = load ptr, ptr %l235, !tbaa !29
  %t476 = icmp ne ptr %t475, null
  br i1 %t476, label %bb134, label %bb135
bb134:
  %t478 = load ptr, ptr %l235, !tbaa !29
  %t479 = load i64, ptr %t478, !range !{i64 0, i64 5}
  %t481 = icmp eq i64 %t479, 3
  store i1 %t481, ptr %l236, !tbaa !21
  br label %bb135
bb135:
  %t482 = load i1, ptr %l236, !tbaa !21
  br i1 %t482, label %bb136, label %bb137
bb136:
  %t483 = load ptr, ptr %l1, !tbaa !29
  %t485 = getelementptr { i64, [6 x i64] }, ptr %t483, i32 0, i32 1
  %t486 = getelementptr { ptr, ptr }, ptr %t485, i32 0, i32 0
  %t487 = load ptr, ptr %t486
  store ptr %t487, ptr %l27, !tbaa !29
  %t489 = load ptr, ptr %l1, !tbaa !29
  %t491 = getelementptr { i64, [6 x i64] }, ptr %t489, i32 0, i32 1
  %t492 = getelementptr { ptr, ptr }, ptr %t491, i32 0, i32 1
  %t493 = load ptr, ptr %t492
  store ptr %t493, ptr %l28, !tbaa !29
  br label %bb138
bb137:
  br label %bb150
bb138:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t496 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t495, ptr %t496)
  br label %bb139
bb139:
  %t499 = load ptr, ptr %l28, !tbaa !29
  %t501 = icmp eq ptr %t499, null
  %t503 = xor i1 %t501, true
  br i1 %t503, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s29
  %t505 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t505, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) })
  br label %bb142
bb141:
  br label %bb149
bb142:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load ptr, ptr %l28, !tbaa !29
  %t510 = getelementptr %"compiler/ast:Func", ptr %t508, i32 0, i32 3
  %t511 = load ptr, ptr %t510, !tbaa !29
  %t513 = getelementptr %"compiler/ast:Sig", ptr %t511, i32 0, i32 0
  %t514 = load { i64, ptr }, ptr %t513, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eparams(ptr %v0, ptr %v1, ptr %t507, { i64, ptr } %t514)
  br label %bb143
bb143:
  %t517 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t517, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d213, i32 0, i32 1) })
  br label %bb144
bb144:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load ptr, ptr %l28, !tbaa !29
  %t522 = getelementptr %"compiler/ast:Func", ptr %t520, i32 0, i32 3
  %t523 = load ptr, ptr %t522, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eerrors(ptr %v0, ptr %v1, ptr %t519, ptr %t523)
  br label %bb145
bb145:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t527 = load ptr, ptr %l28, !tbaa !29
  %t529 = getelementptr %"compiler/ast:Func", ptr %t527, i32 0, i32 3
  %t530 = load ptr, ptr %t529, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2econtract(ptr %v0, ptr %v1, ptr %t526, ptr %t530)
  br label %bb146
bb146:
  %t533 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s29, ptr %t533, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d214, i32 0, i32 1) })
  br label %bb147
bb147:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load ptr, ptr %l28, !tbaa !29
  %t538 = getelementptr %"compiler/ast:Func", ptr %t536, i32 0, i32 4
  %t539 = load { i64, ptr }, ptr %t538, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eblock(ptr %v0, ptr %v1, ptr %t535, { i64, ptr } %t539)
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s29)
  br label %bb149
bb149:
  br label %bb151
bb150:
  call void @__olang_check_failed(ptr @olang_loc_7b9eb6dfa833729b_791a1e6ae071d10f)
  unreachable
bb151:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l38 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:TypeDecl", ptr %t2, i32 0, i32 4
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eattrs(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/ast:TypeDecl", ptr %t8, i32 0, i32 3
  %t11 = load ptr, ptr %t10, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = load i64, ptr %t17, !range !{i64 0, i64 5}
  %t20 = icmp eq i64 %t18, 4
  store i1 %t20, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb9
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s1, ptr %t22, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TypeDecl", ptr %t25, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t24, i32 %t28)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ebbf44be12946e17_d86a8718ca658f6b)
  unreachable
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t31, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d216, i32 0, i32 1) })
  br label %bb15
bb15:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeDecl", ptr %t34, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t33, i32 %t37)
  br label %bb16
bb16:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TypeDecl", ptr %t41, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %t40, { i64, ptr } %t44)
  br label %bb17
bb17:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/ast:TypeDecl", ptr %t47, i32 0, i32 5
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 3}
  %t52 = trunc i64 1 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t55, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d217, i32 0, i32 1) })
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/ast:TypeDecl", ptr %t57, i32 0, i32 5
  %t60 = load i32, ptr %t59, !range !{i32 0, i32 3}
  %t62 = trunc i64 2 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t65 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t65, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d218, i32 0, i32 1) })
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/ast:TypeDecl", ptr %t67, i32 0, i32 6
  %t70 = load i1, ptr %t69, !tbaa !21
  br i1 %t70, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t72 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t72, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d219, i32 0, i32 1) })
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/ast:TypeDecl", ptr %t74, i32 0, i32 2
  %t77 = load i1, ptr %t76, !tbaa !21
  br i1 %t77, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t79 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t79, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d220, i32 0, i32 1) })
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  %t81 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t81, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) })
  br label %bb34
bb34:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l38, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/ast:TypeDecl", ptr %t84, i32 0, i32 3
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = icmp eq ptr %t87, null
  br i1 %t89, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_2cc3368697e3422f_b87e422715826713)
  unreachable
bb36:
  br label %bb37
bb37:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/ast:TypeDecl", ptr %t91, i32 0, i32 3
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t95 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeBody(ptr %v0, ptr %v1, ptr %t95, ptr %t94)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypeParams(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l64 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t7, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d222, i32 0, i32 1) })
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/unparse:writer", ptr %t9, i32 0, i32 6
  %t12 = load i1, ptr %t11, !tbaa !21
  store i1 %t12, ptr %l2, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/unparse:writer", ptr %t14, i32 0, i32 6
  store i1 true, ptr %t16, !tbaa !21
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %bb39
bb7:
  br label %bb8
bb8:
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l27, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  store ptr %t39, ptr %l7, !tbaa !29
  %t41 = load ptr, ptr %l7, !tbaa !29
  %t43 = getelementptr %"compiler/ast:TypeParam", ptr %t41, i32 0, i32 4
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb10:
  br label %bb16
bb11:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d223, i32 0, i32 1) }, ptr %l35, !tbaa !27
  br label %bb13
bb12:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d224, i32 0, i32 1) }, ptr %l35, !tbaa !27
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l32, !tbaa !29
  %t52 = load { i64, ptr }, ptr %l35, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s4, ptr %t51, { i64, ptr } %t52)
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t56 = getelementptr %"compiler/ast:TypeParam", ptr %t54, i32 0, i32 1
  %t57 = load i32, ptr %t56, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t53, i32 %t57)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb16:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t64, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d225, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = getelementptr %"compiler/ast:TypeParam", ptr %t67, i32 0, i32 1
  %t70 = load i32, ptr %t69, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t66, i32 %t70)
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l7, !tbaa !29
  %t75 = getelementptr %"compiler/ast:TypeParam", ptr %t73, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = icmp eq ptr %t76, null
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t82 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t82, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d226, i32 0, i32 1) })
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l50, !tbaa !29
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t87 = getelementptr %"compiler/ast:TypeParam", ptr %t85, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = icmp eq ptr %t88, null
  br i1 %t90, label %bb25, label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_b36b34168d540f92_3d8b83b8d4d4846)
  unreachable
bb26:
  br label %bb27
bb27:
  %t92 = load ptr, ptr %l7, !tbaa !29
  %t94 = getelementptr %"compiler/ast:TypeParam", ptr %t92, i32 0, i32 2
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t96, ptr %t95)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t98 = load ptr, ptr %l7, !tbaa !29
  %t100 = getelementptr %"compiler/ast:TypeParam", ptr %t98, i32 0, i32 3
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  store i64 %t105, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t107 = load i64, ptr %l9, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s8)
  br label %bb37
bb32:
  br label %bb33
bb33:
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t115, ptr %l64, !tbaa !27
  %t116 = load i64, ptr %l9, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr ptr, ptr %t119, i64 %t116
  %t121 = load ptr, ptr %t120, !tbaa !39
  store ptr %t121, ptr %l11, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t123, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) })
  br label %bb34
bb34:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t125, ptr %t126)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb36
bb36:
  %t129 = load i64, ptr %l9, !tbaa !24
  %t131 = add i64 %t129, 1
  store i64 %t131, ptr %l9, !tbaa !24
  br label %bb30
bb37:
  br label %bb38
bb38:
  %t133 = load i64, ptr %l4, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l4, !tbaa !24
  br label %bb5
bb39:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i1, ptr %l2, !tbaa !21
  %t141 = getelementptr %"compiler/unparse:writer", ptr %t137, i32 0, i32 6
  store i1 %t138, ptr %t141, !tbaa !21
  %t142 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t142, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d228, i32 0, i32 1) })
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2etypes(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/unparse:writer", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/unparse:writer", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb2, label %bb3
bb2:
  br label %bb37
bb3:
  br label %bb4
bb4:
  %t23 = load i64, ptr %l4, !tbaa !24
  store i64 %t23, ptr %l6, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l25, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l7, !tbaa !29
  %t33 = load ptr, ptr %l7, !tbaa !29
  store ptr %t33, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t37 = load ptr, ptr %l28, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 8}
  %t40 = icmp eq i64 %t38, 6
  store i1 %t40, ptr %l29, !tbaa !21
  br label %bb6
bb6:
  %t41 = load i1, ptr %l29, !tbaa !21
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t44, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l8, !tbaa !27
  br label %bb9
bb8:
  br label %bb25
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l34, !tbaa !29
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d229, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d230, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l34, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t53, { i64, ptr } %t54)
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t55, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  br label %bb24
bb16:
  br label %bb17
bb17:
  %t69 = load i64, ptr %l10, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t71, ptr %l46, !tbaa !27
  %t72 = load i64, ptr %l10, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr ptr, ptr %t75, i64 %t72
  %t77 = load ptr, ptr %t76, !tbaa !39
  store ptr %t77, ptr %l13, !tbaa !29
  %t81 = icmp sgt i64 %t69, 0
  br i1 %t81, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  %t83 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t83, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d231, i32 0, i32 1) })
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2epath(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l10, !tbaa !24
  br label %bb14
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_c02b53ca4cfea09e_de003c963f6a5612)
  unreachable
bb30:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t97 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s9, ptr %t97, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d232, i32 0, i32 1) })
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s9)
  br label %bb34
bb34:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t99, ptr %t100)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t103 = load i64, ptr %l4, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l4, !tbaa !24
  br label %bb1
bb37:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i1, ptr %l2, !tbaa !21
  %t111 = getelementptr %"compiler/unparse:writer", ptr %t107, i32 0, i32 6
  store i1 %t108, ptr %t111, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2funparse_2ecompiler_2funparse_3awriter_2evarDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i32
  %l19 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l50 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:VarDecl", ptr %t2, i32 0, i32 6
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eattrs(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/ast:VarDecl", ptr %t8, i32 0, i32 0
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l19, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  store i32 %t33, ptr %l6, !tbaa !23
  %t37 = icmp sgt i64 %t25, 0
  br i1 %t37, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s3, ptr %t39, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d233, i32 0, i32 1) })
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ename(ptr %v0, ptr %t41, i32 %t42)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l3, !tbaa !24
  br label %bb2
bb12:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/ast:VarDecl", ptr %t49, i32 0, i32 4
  %t52 = load i1, ptr %t51, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:VarDecl", ptr %t54, i32 0, i32 2
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb15, label %bb16
bb14:
  br label %bb25
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t63 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s6, ptr %t63, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d234, i32 0, i32 1) })
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l36, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:VarDecl", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_45ada3313b7506a3_5e369560cd76ab37)
  unreachable
bb19:
  br label %bb20
bb20:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/ast:VarDecl", ptr %t73, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t77, ptr %t76)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s5, ptr %t79, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d235, i32 0, i32 1) })
  br label %bb23
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/ast:VarDecl", ptr %t82, i32 0, i32 3
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t81, { i64, ptr } %t85)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/ast:VarDecl", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  br i1 %t93, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  br label %bb28
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s0, ptr %t95, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d236, i32 0, i32 1) })
  br label %bb29
bb29:
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l50, !tbaa !29
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/ast:VarDecl", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  br i1 %t103, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_89b7cc3957ccbb94_42e76e0711c83918)
  unreachable
bb31:
  br label %bb32
bb32:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr %"compiler/ast:VarDecl", ptr %t105, i32 0, i32 2
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t109 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2ety(ptr %v0, ptr %v1, ptr %t109, ptr %t108)
  br label %bb33
bb33:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/ast:VarDecl", ptr %t111, i32 0, i32 3
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t118 = icmp sgt i64 %t116, 0
  br i1 %t118, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t120 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eput(ptr %v0, ptr %s8, ptr %t120, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d237, i32 0, i32 1) })
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/ast:VarDecl", ptr %t123, i32 0, i32 3
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  call void @compiler_2funparse_2ecompiler_2funparse_3awriter_2eexprs(ptr %v0, ptr %v1, ptr %t122, { i64, ptr } %t126)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2funparse_2ehidden(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 11}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [8 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:VarDecl", ptr %t16, i32 0, i32 7
  %t19 = load i1, ptr %t18, !tbaa !21
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_47e1931f52a6072d_b10993d7b9a95051)
  unreachable
bb11:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2funparse_2enoErrorsOf(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eFuncSig(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Sig", ptr %t11, i32 0, i32 2
  %t14 = load i1, ptr %t13, !tbaa !21
  %t16 = xor i1 %t14, true
  store i1 %t16, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l7, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 98}
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t18 = trunc i64 53 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb7:
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t23 = trunc i64 77 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l7, !tbaa !21
  br label %bb55
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 30}
  %t34 = icmp eq i64 %t32, 1
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb55
bb15:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb16, label %bb17
bb16:
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 30}
  %t43 = icmp eq i64 %t41, 5
  store i1 %t43, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb18, label %bb19
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l2, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t51)
  store i1 %t53, ptr %l30
  br label %bb21
bb21:
  %t54 = load i1, ptr %l30, !tbaa !21
  store i1 %t54, ptr %l7, !tbaa !21
  br label %bb55
bb22:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb23, label %bb24
bb23:
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 30}
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb24
bb24:
  %t63 = load i1, ptr %l32, !tbaa !21
  br i1 %t63, label %bb25, label %bb26
bb25:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l3, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t70)
  store i1 %t72, ptr %l38
  br label %bb28
bb28:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l7, !tbaa !21
  br label %bb55
bb29:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb30, label %bb31
bb30:
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 30}
  %t81 = icmp eq i64 %t79, 12
  store i1 %t81, ptr %l40, !tbaa !21
  br label %bb31
bb31:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb32, label %bb33
bb32:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t85, i32 0, i32 1
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t89)
  store i1 %t91, ptr %l46
  br label %bb35
bb35:
  %t92 = load i1, ptr %l46, !tbaa !21
  store i1 %t92, ptr %l7, !tbaa !21
  br label %bb55
bb36:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t94 = load ptr, ptr %l47, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb37, label %bb38
bb37:
  %t97 = load ptr, ptr %l47, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 30}
  %t100 = icmp eq i64 %t98, 14
  store i1 %t100, ptr %l48, !tbaa !21
  br label %bb38
bb38:
  %t101 = load i1, ptr %l48, !tbaa !21
  br i1 %t101, label %bb39, label %bb40
bb39:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l5, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t108)
  store i1 %t110, ptr %l54
  br label %bb42
bb42:
  %t111 = load i1, ptr %l54, !tbaa !21
  store i1 %t111, ptr %l7, !tbaa !21
  br label %bb55
bb43:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t113 = load ptr, ptr %l55, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb44, label %bb45
bb44:
  %t116 = load ptr, ptr %l55, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 30}
  %t119 = icmp eq i64 %t117, 15
  store i1 %t119, ptr %l56, !tbaa !21
  br label %bb45
bb45:
  %t120 = load i1, ptr %l56, !tbaa !21
  br i1 %t120, label %bb46, label %bb47
bb46:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t123, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l6, !tbaa !29
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t129 = call i1 @compiler_2funparse_2estartsWithMinus(ptr %v0, ptr %t127)
  store i1 %t129, ptr %l62
  br label %bb49
bb49:
  %t130 = load i1, ptr %l62, !tbaa !21
  store i1 %t130, ptr %l7, !tbaa !21
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_d36f35e5fb1d5e1e_8f0854d909464512)
  unreachable
bb55:
  %t131 = load i1, ptr %l7, !tbaa !21
  store i1 %t131, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/unparse:writer" @compiler_2funparse_3awriter_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/unparse:writer"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store ptr %a2, ptr %l5, !tbaa !29
  %t7 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v3)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t8, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = insertvalue %"compiler/unparse:writer" undef, ptr %t11, 0
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = insertvalue %"compiler/unparse:writer" %t12, { i64, ptr } %t13, 1
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t16 = insertvalue %"compiler/unparse:writer" %t14, ptr %t15, 2
  %t17 = load %"std/prelude/text:StringBuilder", ptr %l6
  %t18 = insertvalue %"compiler/unparse:writer" %t16, %"std/prelude/text:StringBuilder" %t17, 3
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = insertvalue %"compiler/unparse:writer" %t18, i64 %t19, 4
  %t22 = insertvalue %"compiler/unparse:writer" %t20, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, 5
  %t24 = insertvalue %"compiler/unparse:writer" %t22, i1 false, 6
  %t26 = insertvalue %"compiler/unparse:writer" %t24, i1 false, 7
  store %"compiler/unparse:writer" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/unparse:writer", ptr %rv
  ret %"compiler/unparse:writer" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"{ }" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d10 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" catch" }>, align 8
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d15 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" default " }>, align 8
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d19 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
@.d20 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
@.d21 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"link " }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d24 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d26 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" link " }>, align 8
@.d29 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" error" }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" {" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d37 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"test " }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d42 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assert " }>, align 8
@.d43 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ?" }>, align 8
@.d45 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d53 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" not in " }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d57 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" else " }>, align 8
@.d58 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" is not " }>, align 8
@.d59 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" is " }>, align 8
@.d60 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" is not " }>, align 8
@.d61 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" is " }>, align 8
@.d62 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" as " }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d76 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d78 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d79 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d80 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d81 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d83 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d84 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d85 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d86 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"range " }>, align 8
@.d87 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"default" }>, align 8
@.d88 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d90 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d91 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d92 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d93 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d94 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d95 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"export " }>, align 8
@.d96 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d98 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d101 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"(fn" }>, align 8
@.d102 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d103 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d104 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"if " }>, align 8
@.d105 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" else" }>, align 8
@.d106 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d107 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"match " }>, align 8
@.d108 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" {" }>, align 8
@.d109 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"case " }>, align 8
@.d110 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d111 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d112 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" if " }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d114 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d116 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d117 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d120 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d121 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d122 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d123 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d124 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d126 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d127 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d128 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", ..." }>, align 8
@.d129 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d130 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d131 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" noreturn" }>, align 8
@.d132 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d133 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d134 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" commutes" }>, align 8
@.d135 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" := " }>, align 8
@.d136 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d138 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d139 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d140 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d141 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d142 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d143 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d144 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d145 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"comptime " }>, align 8
@.d146 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d147 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d148 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d149 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d150 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"do " }>, align 8
@.d151 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d152 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d153 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d154 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"yield " }>, align 8
@.d155 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"become " }>, align 8
@.d156 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d157 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"assert " }>, align 8
@.d158 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d159 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"error" }>, align 8
@.d160 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d161 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d162 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d163 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"spawn " }>, align 8
@.d164 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d165 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"try " }>, align 8
@.d166 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"join " }>, align 8
@.d167 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"errdefer " }>, align 8
@.d168 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"defer " }>, align 8
@.d169 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d170 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d171 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"if " }>, align 8
@.d172 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d173 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" else " }>, align 8
@.d174 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" else " }>, align 8
@.d175 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d176 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d177 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d178 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d179 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d180 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d181 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"?&" }>, align 8
@.d182 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d183 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"any " }>, align 8
@.d184 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d185 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d186 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d187 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"mut" }>, align 8
@.d188 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d189 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"struct" }>, align 8
@.d190 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d191 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d192 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d193 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" destruct " }>, align 8
@.d194 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"enum " }>, align 8
@.d195 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d196 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d197 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d198 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d199 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d200 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d201 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d202 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"trait " }>, align 8
@.d203 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"extends " }>, align 8
@.d204 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d205 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d206 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"for " }>, align 8
@.d207 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d208 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d209 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d210 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@.d211 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d212 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d213 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d214 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d215 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"extern type " }>, align 8
@.d216 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d217 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" immut" }>, align 8
@.d218 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" unique" }>, align 8
@.d219 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" packed" }>, align 8
@.d220 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" extends" }>, align 8
@.d221 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d222 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d223 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d224 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d225 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d226 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d227 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d228 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d229 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d230 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d231 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d232 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d233 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d234 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d235 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" := " }>, align 8
@.d236 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d237 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_97fb03c83c422508_396f69b1ea6ff204 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_6d411809e3c45284_6ddb613e25dacce8 = external constant [0 x i8]
@olang_loc_3b272a795e4745a2_9a90297686d0fdde = external constant [0 x i8]
@olang_loc_7ff52852c0aa476c_d4838bd4ef885ee0 = external constant [0 x i8]
@olang_loc_7f8607ca82c86e8f_41d7f7ff4057cd03 = external constant [0 x i8]
@olang_loc_47d2a5c602f98a4e_7d860b0fe2aa1b82 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
@olang_loc_577bb2401887ee03_bd83bee27b444ed7 = external constant [0 x i8]
@olang_loc_47b511f5ef6d9e74_baf04e552c3da2b8 = external constant [0 x i8]
@olang_loc_e6dde321a76d1169_ef8c066898e78ecd = external constant [0 x i8]
@olang_loc_af8532b2afdd02b1_ed9973e7a2ad66a5 = external constant [0 x i8]
@olang_loc_240300a98391f326_30555605a48ff2da = external constant [0 x i8]
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
@olang_loc_62b5cb0662a9bd0d_8638c84775e31461 = external constant [0 x i8]
@olang_loc_450b6e4c0e54f911_1dcad8b8a27ff01d = external constant [0 x i8]
@olang_loc_375b6e3c7dc4e00a_588d095da59240b6 = external constant [0 x i8]
@olang_loc_e1b6c554c381b10b_f727e5cc4e37ef67 = external constant [0 x i8]
@olang_loc_ba8e182b2fbe7a1c_99d493faf8d7cb48 = external constant [0 x i8]
@olang_loc_a676b6f90e9ab794_adfa384105d75b88 = external constant [0 x i8]
@olang_loc_8218e8270bec8206_ca247080b262927a = external constant [0 x i8]
@olang_loc_212921701ccd28fb_40c266614e32415f = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_2301005a90ba30f7_2e0b8cd6b5bb3c83 = external constant [0 x i8]
@olang_loc_6385ebb2fa48e0d8_1e44ec8c8ca0ecf4 = external constant [0 x i8]
@olang_loc_19d95224243c5dd3_a108b37826b1917 = external constant [0 x i8]
@olang_loc_9c4378154f5f7dac_a032de2992525ef0 = external constant [0 x i8]
@olang_loc_b263a57856eac862_46b7b1031f9001a6 = external constant [0 x i8]
@olang_loc_9166140a1ac8280_ddd22134593fa34 = external constant [0 x i8]
@olang_loc_69b21e264e8a714a_b3e97d9d77526506 = external constant [0 x i8]
@olang_loc_8585d6fe8f316a51_b60a12ce50df87ed = external constant [0 x i8]
@olang_loc_eabe3ddcfaef285c_106dba970e52f8d8 = external constant [0 x i8]
@olang_loc_14b8182deed7e34b_cfe8cf3ea4c448f7 = external constant [0 x i8]
declare ptr @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eFuncSig(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_9034b6aed20fb51a_d179ca40c5e654ce = external constant [0 x i8]
@olang_loc_8cd05a7785ffddf0_abfc69165374635c = external constant [0 x i8]
@olang_loc_c53cd7dd70350acf_d5f64367475d1e4b = external constant [0 x i8]
@olang_loc_565cf8a51c2b309e_2af0495fa70fac4a = external constant [0 x i8]
@olang_loc_a9c38de43eb77545_46c40237e7b6a551 = external constant [0 x i8]
@olang_loc_7b9eb6dfa833729b_791a1e6ae071d10f = external constant [0 x i8]
@olang_loc_ebbf44be12946e17_d86a8718ca658f6b = external constant [0 x i8]
@olang_loc_2cc3368697e3422f_b87e422715826713 = external constant [0 x i8]
@olang_loc_b36b34168d540f92_3d8b83b8d4d4846 = external constant [0 x i8]
@olang_loc_c02b53ca4cfea09e_de003c963f6a5612 = external constant [0 x i8]
@olang_loc_45ada3313b7506a3_5e369560cd76ab37 = external constant [0 x i8]
@olang_loc_89b7cc3957ccbb94_42e76e0711c83918 = external constant [0 x i8]
@olang_loc_47e1931f52a6072d_b10993d7b9a95051 = external constant [0 x i8]
@olang_loc_d36f35e5fb1d5e1e_8f0854d909464512 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
