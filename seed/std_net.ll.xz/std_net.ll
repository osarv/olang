; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/net:Addr" = type { %"std/net:IP", i16 }
%"std/net:IP" = type { i1, [16 x i8] }
%"std/net:Conn" = type { i32 }
%"std/net:Listener" = type { i32 }
%"std/net:UDP" = type { i32 }
@G_2estd_2fnet_2eafInet = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2estd_2fnet_2eafInet6 = constant <{ [4 x i8] }> <{ [4 x i8] c"\0A\00\00\00" }>, align 8
@G_2estd_2fnet_2eipprotoIpv6 = constant <{ [4 x i8] }> <{ [4 x i8] c"\29\00\00\00" }>, align 8
@G_2estd_2fnet_2eipv6V6only = constant <{ [4 x i8] }> <{ [4 x i8] c"\1A\00\00\00" }>, align 8
@G_2estd_2fnet_2emsgNosignal = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\40\00\00" }>, align 8
@G_2estd_2fnet_2eshutWr = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2estd_2fnet_2esoRcvtimeo = constant <{ [4 x i8] }> <{ [4 x i8] c"\14\00\00\00" }>, align 8
@G_2estd_2fnet_2esoReuseaddr = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2estd_2fnet_2esoSndtimeo = constant <{ [4 x i8] }> <{ [4 x i8] c"\15\00\00\00" }>, align 8
@G_2estd_2fnet_2esockCloexec = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\08\00" }>, align 8
@G_2estd_2fnet_2esockDgram = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2estd_2fnet_2esockStream = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2estd_2fnet_2esolSocket = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
define dso_local { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2eParse(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/net:Addr"
  %l3 = alloca %"std/net:Addr"
  %l4 = alloca i32
  %l6 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i64
  %l14 = alloca { i64, [2 x i64] }
  %s1 = alloca %olang.scope
  %rv = alloca { i32, %"std/net:Addr" }
  %t28 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2ehostPort(ptr %v0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/net:Addr" } %t3, 1
  %t5 = extractvalue { i32, %"std/net:Addr" } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/net:Addr" %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load %"std/net:Addr", ptr %l3
  store %"std/net:Addr" %t8, ptr %l1
  br label %bb5
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l9, !tbaa !24
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l9, !tbaa !24
  %t27 = mul i64 %t26, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 0
  store i64 5, ptr %t29
  %t30 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t31 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t30, 0
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, ptr } } %t31, ptr %t32
  %t33 = load { i64, [2 x i64] }, ptr %t28
  store { i64, [2 x i64] } %t33, ptr %l11
  %t34 = call ptr @__olang_errpay_push()
  %t35 = ptrtoint ptr %t34 to i64
  store i64 %t35, ptr %l12, !tbaa !24
  %t36 = load i64, ptr %l12
  %t37 = inttoptr i64 %t36 to ptr
  %t39 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t37, ptr %l11)
  store { i64, [2 x i64] } %t39, ptr %l14
  br label %bb4
bb4:
  %t40 = load { i64, [2 x i64] }, ptr %l14
  %t41 = load i64, ptr %l12
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_scope_alloc_a(ptr %t42, i64 24, i64 8)
  store { i64, [2 x i64] } %t40, ptr %t43
  call void @__olang_errpay_set(ptr %t43)
  call void @__olang_scope_close(ptr %s1)
  %t46 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 65541, 0
  store { i32, %"std/net:Addr" } %t46, ptr %rv
  br label %ret
bb5:
  %t47 = load %"std/net:Addr", ptr %l1
  %t48 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, %"std/net:Addr" %t47, 1
  store { i32, %"std/net:Addr" } %t48, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:Addr" }, ptr %rv
  ret { i32, %"std/net:Addr" } %rr
}

define dso_local %"std/net:Addr" @std_2fnet_2eAddr_2efromSockaddr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i16
  %l3 = alloca %"std/net:IP"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca %"std/net:IP"
  %l33 = alloca i64
  %l36 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i1
  %l59 = alloca { i64, ptr }
  %l68 = alloca %"std/net:Addr"
  %l69 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca %"std/net:IP"
  %l79 = alloca %"std/net:Addr"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"std/net:Addr"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l10, !tbaa !27
  %t2 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t3 = load ptr, ptr %t2, !tbaa !27
  %t4 = getelementptr i8, ptr %t3, i64 0
  %t5 = load i8, ptr %t4, !tbaa !32
  %t7 = zext i8 %t5 to i32
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l13, !tbaa !27
  %t9 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i8, ptr %t10, i64 1
  %t12 = load i8, ptr %t11, !tbaa !32
  %t14 = zext i8 %t12 to i32
  %t16 = shl i32 %t14, 8
  %t19 = or i32 %t7, %t16
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 2
  %t25 = load i8, ptr %t24, !tbaa !32
  %t27 = zext i8 %t25 to i16
  %t29 = shl i16 %t27, 8
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l22, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i8, ptr %t32, i64 3
  %t34 = load i8, ptr %t33, !tbaa !32
  %t36 = zext i8 %t34 to i16
  %t39 = or i16 %t29, %t36
  store i16 %t39, ptr %l2, !tbaa !63
  %t42 = load i32, ptr @G_2estd_2fnet_2eafInet6, !tbaa !23
  %t45 = icmp eq i32 %t19, %t42
  br i1 %t45, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t47 = call %"std/net:IP" @std_2fnet_3aIP_2ector(ptr %s1, i1 true)
  store %"std/net:IP" %t47, ptr %l29
  br label %bb3
bb2:
  br label %bb17
bb3:
  %t48 = load %"std/net:IP", ptr %l29
  store %"std/net:IP" %t48, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = icmp sgt i64 %t49, %t50
  br i1 %t53, label %bb4, label %bb5
bb4:
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb9
bb6:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t60 = load i64, ptr %l4, !tbaa !24
  %t63 = sub i64 %t59, %t60
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t63, %t64
  %t69 = sub i64 %t67, 1
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = sdiv i64 %t69, %t70
  store i64 %t73, ptr %l36, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb8
bb8:
  %t75 = load i64, ptr %l36, !tbaa !24
  store i64 %t75, ptr %l33, !tbaa !24
  br label %bb9
bb9:
  %t76 = load i64, ptr %l33, !tbaa !24
  store i64 %t76, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t78 = sub i64 %t77, 1
  store i64 %t78, ptr %l45, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp slt i64 %t79, 2147483648
  %t81 = load i64, ptr %l8, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  %t85 = and i1 %t80, %t82
  store i1 %t85, ptr %l48, !tbaa !21
  br label %bb10
bb10:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t94 = load i64, ptr %l4, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l6, !tbaa !24
  %t99 = mul i64 %t95, %t96
  %t102 = add i64 %t94, %t99
  store i64 %t102, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t105, ptr %l59, !tbaa !27
  %t106 = load i64, ptr %l9, !tbaa !24
  %t108 = add i64 8, %t106
  %t110 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i8, ptr %t111, i64 %t108
  %t113 = load i8, ptr %t112, !tbaa !32
  %t115 = getelementptr %"std/net:IP", ptr %l3, i32 0, i32 1
  %t117 = getelementptr [16 x i8], ptr %t115, i64 0, i64 %t104
  store i8 %t113, ptr %t117, !tbaa !32
  br label %bb14
bb14:
  %t118 = load i64, ptr %l8, !tbaa !24
  %t121 = add i64 %t118, 1
  store i64 %t121, ptr %l8, !tbaa !24
  br label %bb10
bb15:
  %t123 = load %"std/net:IP", ptr %l3
  %t124 = load i16, ptr %l2, !tbaa !63
  %t127 = call %"std/net:Addr" @std_2fnet_3aAddr_2ector(ptr %s1, %"std/net:IP" %t123, i16 %t124)
  store %"std/net:Addr" %t127, ptr %l68
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t128 = load %"std/net:Addr", ptr %l68
  store %"std/net:Addr" %t128, ptr %rv
  br label %ret
bb17:
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t129, ptr %l69, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i8, ptr %t131, i64 4
  %t133 = load i8, ptr %t132, !tbaa !32
  %t134 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t134, ptr %l71, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i8, ptr %t136, i64 5
  %t138 = load i8, ptr %t137, !tbaa !32
  %t139 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t139, ptr %l73, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr i8, ptr %t141, i64 6
  %t143 = load i8, ptr %t142, !tbaa !32
  %t144 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t144, ptr %l75, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i8, ptr %t146, i64 7
  %t148 = load i8, ptr %t147, !tbaa !32
  %t153 = call %"std/net:IP" @std_2fnet_2eIP_2eIPv4(i8 %t133, i8 %t138, i8 %t143, i8 %t148)
  store %"std/net:IP" %t153, ptr %l77
  br label %bb18
bb18:
  %t154 = load i16, ptr %l2, !tbaa !63
  %t155 = load %"std/net:IP", ptr %l77
  %t157 = call %"std/net:Addr" @std_2fnet_3aAddr_2ector(ptr %s0, %"std/net:IP" %t155, i16 %t154)
  store %"std/net:Addr" %t157, ptr %l79
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t158 = load %"std/net:Addr", ptr %l79
  store %"std/net:Addr" %t158, ptr %rv
  br label %ret
ret:
  %rr = load %"std/net:Addr", ptr %rv
  ret %"std/net:Addr" %rr
}

define dso_local { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2enameOf(i32 %a0, i1 %a1) #0 {
entry:
  %l2 = alloca [28 x i8]
  %l3 = alloca [28 x i8]
  %l8 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l13 = alloca i32
  %l17 = alloca %"std/net:Addr"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/net:Addr" }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 28
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [28 x i8], ptr %l3, i64 0, i64 %t5
  store i8 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  %t9 = load [28 x i8], ptr %l3
  store [28 x i8] %t9, ptr %l2
  %t12 = insertvalue { i64, ptr } undef, i64 28, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %l2, 1
  %t18 = call i32 @std_2fnet_2esysName(ptr %s0, i32 %a0, { i64, ptr } %t13, i1 %a1)
  store i32 %t18, ptr %l8
  br label %bb1
bb1:
  %t19 = load i32, ptr %l8, !tbaa !23
  %t20 = icmp slt i32 %t19, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = call i32 @std_2fnet_2esockErr()
  store i32 %t22, ptr %l10
  br label %bb4
bb3:
  br label %bb8
bb4:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t24 = load i32, ptr %l10, !tbaa !23
  %t26 = call i32 @std_2fnet_2eraise(i32 %t24, { i64, ptr } %t23)
  store i32 %t26, ptr %l13
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb6, label %ok.28, !prof !99
ok.28:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t29 = load i32, ptr %l13, !tbaa !23
  %t30 = lshr i32 %t29, 16
  %t31 = and i32 %t29, 65535
  %t32 = icmp eq i32 %t30, 1
  %t33 = select i1 %t32, i32 1, i32 0
  %t34 = icmp eq i32 %t29, 0
  %t35 = shl i32 %t33, 16
  %t36 = or i32 %t35, %t31
  %t37 = select i1 %t34, i32 0, i32 %t36
  call void @__olang_scope_close(ptr %s0)
  %t39 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 %t37, 0
  store { i32, %"std/net:Addr" } %t39, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t41 = insertvalue { i64, ptr } undef, i64 28, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %l2, 1
  %t44 = call %"std/net:Addr" @std_2fnet_2eAddr_2efromSockaddr(ptr %s0, { i64, ptr } %t42)
  store %"std/net:Addr" %t44, ptr %l17
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load %"std/net:Addr", ptr %l17
  %t46 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, %"std/net:Addr" %t45, 1
  store { i32, %"std/net:Addr" } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:Addr" }, ptr %rv
  ret { i32, %"std/net:Addr" } %rr
}

define dso_local %"std/net:IP" @std_2fnet_2eIP_2eAny4() #0 {
entry:
  %l0 = alloca %"std/net:IP"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/net:IP"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/net:IP" @std_2fnet_3aIP_2ector(ptr %s0, i1 false)
  store %"std/net:IP" %t1, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t2 = load %"std/net:IP", ptr %l0
  store %"std/net:IP" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/net:IP", ptr %rv
  ret %"std/net:IP" %rr
}

define dso_local %"std/net:IP" @std_2fnet_2eIP_2eAny6() #0 {
entry:
  %l0 = alloca %"std/net:IP"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/net:IP"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/net:IP" @std_2fnet_3aIP_2ector(ptr %s0, i1 true)
  store %"std/net:IP" %t1, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t2 = load %"std/net:IP", ptr %l0
  store %"std/net:IP" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/net:IP", ptr %rv
  ret %"std/net:IP" %rr
}

define dso_local %"std/net:IP" @std_2fnet_2eIP_2eIPv4(i8 %a0, i8 %a1, i8 %a2, i8 %a3) #0 {
entry:
  %l4 = alloca %"std/net:IP"
  %l5 = alloca %"std/net:IP"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/net:IP"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/net:IP" @std_2fnet_3aIP_2ector(ptr %s0, i1 false)
  store %"std/net:IP" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/net:IP", ptr %l5
  store %"std/net:IP" %t2, ptr %l4
  %t5 = getelementptr %"std/net:IP", ptr %l4, i32 0, i32 1
  %t6 = getelementptr [16 x i8], ptr %t5, i64 0, i64 0
  store i8 %a0, ptr %t6, !tbaa !32
  %t9 = getelementptr %"std/net:IP", ptr %l4, i32 0, i32 1
  %t10 = getelementptr [16 x i8], ptr %t9, i64 0, i64 1
  store i8 %a1, ptr %t10, !tbaa !32
  %t13 = getelementptr %"std/net:IP", ptr %l4, i32 0, i32 1
  %t14 = getelementptr [16 x i8], ptr %t13, i64 0, i64 2
  store i8 %a2, ptr %t14, !tbaa !32
  %t17 = getelementptr %"std/net:IP", ptr %l4, i32 0, i32 1
  %t18 = getelementptr [16 x i8], ptr %t17, i64 0, i64 3
  store i8 %a3, ptr %t18, !tbaa !32
  %t19 = load %"std/net:IP", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"std/net:IP" %t19, ptr %rv
  br label %ret
ret:
  %rr = load %"std/net:IP", ptr %rv
  ret %"std/net:IP" %rr
}

define dso_local { i32, %"std/net:IP" } @std_2fnet_2eIP_2eIPv6(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/net:IP"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca i64
  %l17 = alloca { i64, [2 x i64] }
  %l20 = alloca %"std/net:IP"
  %l24 = alloca i64
  %l27 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i1
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i32, %"std/net:IP" }
  %t20 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp ne i64 %t3, 16
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l11, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  call void @olang_2emir_2eHelperKind_2eRender_2eArray_3cU8_3e_26(ptr %s2, ptr %l11, i64 0)
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t9 = load ptr, ptr %s2
  %t10 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t9, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l13, !tbaa !27
  %t15 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t16 = load ptr, ptr %t15
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %sbgrew.18, label %sbdone.19
sbgrew.18:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.19
sbdone.19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 0
  store i64 5, ptr %t21
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t23 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t22, 0
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 1
  store { { i64, ptr } } %t23, ptr %t24
  %t25 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t25, ptr %l14
  %t26 = call ptr @__olang_errpay_push()
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l15, !tbaa !24
  %t28 = load i64, ptr %l15
  %t29 = inttoptr i64 %t28 to ptr
  %t31 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %t29, ptr %l14)
  store { i64, [2 x i64] } %t31, ptr %l17
  br label %bb4
bb4:
  %t32 = load { i64, [2 x i64] }, ptr %l17
  %t33 = load i64, ptr %l15
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_scope_alloc_a(ptr %t34, i64 24, i64 8)
  store { i64, [2 x i64] } %t32, ptr %t35
  call void @__olang_errpay_set(ptr %t35)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65541, 0
  store { i32, %"std/net:IP" } %t38, ptr %rv
  br label %ret
bb5:
  %t39 = call %"std/net:IP" @std_2fnet_3aIP_2ector(ptr %s0, i1 true)
  store %"std/net:IP" %t39, ptr %l20
  br label %bb6
bb6:
  %t40 = load %"std/net:IP", ptr %l20
  store %"std/net:IP" %t40, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  store i64 16, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb12
bb9:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l2, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l27, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l27, !tbaa !24
  store i64 %t67, ptr %l24, !tbaa !24
  br label %bb12
bb12:
  %t68 = load i64, ptr %l24, !tbaa !24
  store i64 %t68, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = sub i64 %t69, 1
  store i64 %t70, ptr %l36, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t72 = icmp slt i64 %t71, 2147483648
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  %t77 = and i1 %t72, %t74
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l7, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t97, ptr %l50, !tbaa !27
  %t98 = load i64, ptr %l7, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i8, ptr %t101, i64 %t98
  %t103 = load i8, ptr %t102, !tbaa !32
  %t105 = getelementptr %"std/net:IP", ptr %l1, i32 0, i32 1
  %t107 = getelementptr [16 x i8], ptr %t105, i64 0, i64 %t96
  store i8 %t103, ptr %t107, !tbaa !32
  br label %bb17
bb17:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t111 = add i64 %t108, 1
  store i64 %t111, ptr %l6, !tbaa !24
  br label %bb13
bb18:
  %t113 = load %"std/net:IP", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  %t115 = insertvalue { i32, %"std/net:IP" } zeroinitializer, %"std/net:IP" %t113, 1
  store { i32, %"std/net:IP" } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:IP" }, ptr %rv
  ret { i32, %"std/net:IP" } %rr
}

define dso_local %"std/net:IP" @std_2fnet_2eIP_2eLoopback6() #0 {
entry:
  %l0 = alloca %"std/net:IP"
  %l1 = alloca %"std/net:IP"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/net:IP"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/net:IP" @std_2fnet_3aIP_2ector(ptr %s0, i1 true)
  store %"std/net:IP" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load %"std/net:IP", ptr %l1
  store %"std/net:IP" %t2, ptr %l0
  %t3 = getelementptr %"std/net:IP", ptr %l0, i32 0, i32 1
  %t4 = getelementptr [16 x i8], ptr %t3, i64 0, i64 15
  store i8 1, ptr %t4, !tbaa !32
  %t5 = load %"std/net:IP", ptr %l0
  call void @__olang_scope_close(ptr %s0)
  store %"std/net:IP" %t5, ptr %rv
  br label %ret
ret:
  %rr = load %"std/net:IP", ptr %rv
  ret %"std/net:IP" %rr
}

define dso_local { i32, %"std/net:IP" } @std_2fnet_2eIP_2eparse4(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/net:IP"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, i64 }
  %l12 = alloca %"std/net:IP"
  %l16 = alloca i64
  %l19 = alloca i64
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, i64 }
  %l55 = alloca { i64, i64 }
  %l56 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/net:IP" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/net:IP" @std_2fnet_3aIP_2ector(ptr %s0, i1 false)
  store %"std/net:IP" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/net:IP", ptr %l12
  store %"std/net:IP" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 4, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t29 = load i64, ptr %l19, !tbaa !24
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb9, label %bb10
bb9:
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t59 = icmp sge i64 %t53, %t56
  br i1 %t59, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t61 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t61, ptr %l44, !tbaa !27
  %t62 = load i64, ptr %l2, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i8, ptr %t65, i64 %t62
  %t67 = load i8, ptr %t66, !tbaa !32
  %t69 = icmp ne i8 %t67, 46
  store i1 %t69, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t71 = load i1, ptr %l43, !tbaa !21
  br i1 %t71, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t73 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:IP" } %t73, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t74 = load i64, ptr %l2, !tbaa !24
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %l2, !tbaa !24
  br label %bb20
bb20:
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t80 = load i64, ptr %l2, !tbaa !24
  %t83 = call { i32, { i64, i64 } } @std_2fnet_2edecimalAt(ptr %v0, { i64, ptr } %t79, i64 %t80, i64 255)
  %t84 = extractvalue { i32, { i64, i64 } } %t83, 1
  %t85 = extractvalue { i32, { i64, i64 } } %t83, 0
  store i32 %t85, ptr %l56
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb22, label %ok.87, !prof !99
ok.87:
  store { i64, i64 } %t84, ptr %l55
  br label %bb21
bb21:
  %t88 = load { i64, i64 }, ptr %l55
  store { i64, i64 } %t88, ptr %l52
  br label %bb23
bb22:
  %t89 = load i32, ptr %l56, !tbaa !23
  %t90 = lshr i32 %t89, 16
  %t91 = and i32 %t89, 65535
  %t92 = icmp eq i32 %t90, 1
  %t93 = select i1 %t92, i32 1, i32 0
  %t94 = icmp eq i32 %t89, 0
  %t95 = shl i32 %t93, 16
  %t96 = or i32 %t95, %t91
  %t97 = select i1 %t94, i32 0, i32 %t96
  call void @__olang_scope_close(ptr %s0)
  %t99 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 %t97, 0
  store { i32, %"std/net:IP" } %t99, ptr %rv
  br label %ret
bb23:
  %t100 = load { i64, i64 }, ptr %l52
  store { i64, i64 } %t100, ptr %l9
  %t101 = getelementptr { i64, i64 }, ptr %l9, i32 0, i32 0
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = getelementptr { i64, i64 }, ptr %l9, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = trunc i64 %t102 to i8
  %t112 = getelementptr %"std/net:IP", ptr %l1, i32 0, i32 1
  %t114 = getelementptr [16 x i8], ptr %t112, i64 0, i64 %t107
  store i8 %t110, ptr %t114, !tbaa !32
  store i64 %t105, ptr %l2, !tbaa !24
  br label %bb24
bb24:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t120 = add i64 %t117, 1
  store i64 %t120, ptr %l7, !tbaa !24
  br label %bb8
bb25:
  %t122 = load i64, ptr %l2, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t128 = icmp ne i64 %t122, %t125
  br i1 %t128, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t131 = insertvalue { i32, %"std/net:IP" } zeroinitializer, i32 65536, 0
  store { i32, %"std/net:IP" } %t131, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t132 = load %"std/net:IP", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  %t134 = insertvalue { i32, %"std/net:IP" } zeroinitializer, %"std/net:IP" %t132, 1
  store { i32, %"std/net:IP" } %t134, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:IP" }, ptr %rv
  ret { i32, %"std/net:IP" } %rr
}

define dso_local { i64, ptr } @std_2fnet_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @std_2fnet_2esysReadable(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fnet_2ecloseSock(i32 %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @close(i32 %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, i64 } } @std_2fnet_2edecimalAt(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i1
  %l24 = alloca { i64, ptr }
  %l36 = alloca i1
  %l40 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, i64 } }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l11, !tbaa !27
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t17)
  store i1 %t19, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i1, ptr %l14, !tbaa !21
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t28 = icmp slt i64 %t26, 5
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l15, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = mul i64 %t33, 10
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i8, ptr %t41, i64 %t38
  %t43 = load i8, ptr %t42, !tbaa !32
  %t45 = sub i8 %t43, 48
  %t47 = zext i8 %t45 to i64
  %t50 = add i64 %t36, %t47
  store i64 %t50, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  br label %bb1
bb13:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t58 = load i64, ptr %l1, !tbaa !24
  %t61 = icmp eq i64 %t57, %t58
  br i1 %t61, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb16
bb15:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t67 = icmp sgt i64 %t63, %a2
  store i1 %t67, ptr %l36, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l36, !tbaa !21
  br i1 %t69, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb22
bb18:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l1, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t76 = icmp sgt i64 %t74, 1
  br i1 %t76, label %bb19, label %bb20
bb19:
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = load i64, ptr %l1, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i8, ptr %t82, i64 %t79
  %t84 = load i8, ptr %t83, !tbaa !32
  %t86 = icmp eq i8 %t84, 48
  store i1 %t86, ptr %l45, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb21
bb21:
  %t88 = load i1, ptr %l45, !tbaa !21
  store i1 %t88, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t89 = load i1, ptr %l40, !tbaa !21
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t91 = insertvalue { i32, { i64, i64 } } zeroinitializer, i32 65536, 0
  store { i32, { i64, i64 } } %t91, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t93 = load i64, ptr %l4, !tbaa !24
  %t95 = insertvalue { i64, i64 } undef, i64 %t92, 0
  %t97 = insertvalue { i64, i64 } %t95, i64 %t93, 1
  %t99 = insertvalue { i32, { i64, i64 } } zeroinitializer, { i64, i64 } %t97, 1
  store { i32, { i64, i64 } } %t99, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, i64 } }, ptr %rv
  ret { i32, { i64, i64 } } %rr
}

define dso_local i1 @std_2fnet_2einterrupted() #0 {
entry:
  %l0 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i32 @std_2fnet_2esockErr()
  store i32 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t2, 13
  store i1 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i32 } @std_2fnet_2eopen(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/net:Addr", ptr %t1, i32 0, i32 0
  %t4 = getelementptr %"std/net:IP", ptr %t3, i32 0, i32 0
  %t5 = load i1, ptr %t4, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr @G_2estd_2fnet_2eafInet6, !tbaa !23
  store i32 %t7, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  %t9 = load i32, ptr @G_2estd_2fnet_2eafInet, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  br label %bb3
bb3:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t14 = call i32 @std_2fnet_2esysSocket(i32 %t12, i32 %a1)
  store i32 %t14, ptr %l9
  br label %bb4
bb4:
  %t15 = load i32, ptr %l9, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = icmp slt i32 %t16, 0
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = call i32 @std_2fnet_2esockErr()
  store i32 %t20, ptr %l12
  br label %bb7
bb6:
  br label %bb12
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l13, !tbaa !29
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  call void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aAddr_26(ptr %s2, ptr %l13, i64 0)
  br label %bb8
bb8:
  %t23 = load ptr, ptr %s2
  %t24 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t25 = load i64, ptr %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t23, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l15, !tbaa !27
  %t29 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t30 = load ptr, ptr %t29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %sbgrew.32, label %sbdone.33
sbgrew.32:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.33
sbdone.33:
  %t34 = load i32, ptr %l12, !tbaa !23
  %t35 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t36 = call i32 @std_2fnet_2eraise(i32 %t34, { i64, ptr } %t35)
  store i32 %t36, ptr %l16
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38, !prof !99
ok.38:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t39 = load i32, ptr %l16, !tbaa !23
  %t40 = lshr i32 %t39, 16
  %t41 = and i32 %t39, 65535
  %t42 = icmp eq i32 %t40, 1
  %t43 = select i1 %t42, i32 1, i32 0
  %t44 = icmp eq i32 %t39, 0
  %t45 = shl i32 %t43, 16
  %t46 = or i32 %t45, %t41
  %t47 = select i1 %t44, i32 0, i32 %t46
  call void @__olang_scope_close(ptr %s1)
  %t49 = insertvalue { i32, i32 } zeroinitializer, i32 %t47, 0
  store { i32, i32 } %t49, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  %t50 = load i32, ptr %l2, !tbaa !23
  %t52 = insertvalue { i32, i32 } zeroinitializer, i32 %t50, 1
  store { i32, i32 } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @std_2fnet_2esetInt(i32 %a0, i32 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca [4 x i8]
  %s0 = alloca %olang.scope
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [4 x i8] undef, i8 0, 0
  %t2 = insertvalue [4 x i8] %t1, i8 0, 1
  %t3 = insertvalue [4 x i8] %t2, i8 0, 2
  %t4 = insertvalue [4 x i8] %t3, i8 0, 3
  store [4 x i8] %t4, ptr %l4
  %t6 = load i32, ptr %l3, !tbaa !23
  %t8 = and i32 %t6, 255
  %t10 = trunc i32 %t8 to i8
  %t12 = getelementptr [4 x i8], ptr %l4, i64 0, i64 0
  store i8 %t10, ptr %t12, !tbaa !32
  %t13 = load i32, ptr %l3, !tbaa !23
  %t15 = ashr i32 %t13, 8
  %t17 = and i32 %t15, 255
  %t19 = trunc i32 %t17 to i8
  %t21 = getelementptr [4 x i8], ptr %l4, i64 0, i64 1
  store i8 %t19, ptr %t21, !tbaa !32
  %t22 = load i32, ptr %l3, !tbaa !23
  %t24 = ashr i32 %t22, 16
  %t26 = and i32 %t24, 255
  %t28 = trunc i32 %t26 to i8
  %t30 = getelementptr [4 x i8], ptr %l4, i64 0, i64 2
  store i8 %t28, ptr %t30, !tbaa !32
  %t31 = load i32, ptr %l3, !tbaa !23
  %t33 = ashr i32 %t31, 24
  %t35 = and i32 %t33, 255
  %t37 = trunc i32 %t35 to i8
  %t39 = getelementptr [4 x i8], ptr %l4, i64 0, i64 3
  store i8 %t37, ptr %t39, !tbaa !32
  %t44 = insertvalue { i64, ptr } undef, i64 4, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %l4, 1
  call void @std_2fnet_2esysSetOpt(ptr %s0, i32 %a0, i32 %a1, i32 %a2, { i64, ptr } %t45)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fnet_2esockErr() #0 {
entry:
  %l0 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i32 @__olang_err()
  store i32 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i32, ptr %l0, !tbaa !23
  store i32 %t2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2fnet_2estd_2fnet_3aAddr_2eStr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca %"std/net:IP"
  %l6 = alloca i16
  %l8 = alloca { i64, ptr }
  %l10 = alloca %"std/net:IP"
  %l12 = alloca i16
  %l14 = alloca { i64, ptr }
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/net:Addr", ptr %t1, i32 0, i32 0
  %t4 = getelementptr %"std/net:IP", ptr %t3, i32 0, i32 0
  %t5 = load i1, ptr %t4, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/net:Addr", ptr %t7, i32 0, i32 0
  %t10 = load %"std/net:IP", ptr %t9
  store %"std/net:IP" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"std/net:Addr", ptr %t11, i32 0, i32 1
  %t14 = load i16, ptr %t13, !tbaa !63
  store i16 %t14, ptr %l6, !tbaa !63
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t15, i64 %t16)
  call void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aIP(ptr %s2, ptr %l4, i64 0)
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t18 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t18, i64 %t19)
  %t20 = load i16, ptr %l6, !tbaa !63
  %t21 = zext i16 %t20 to i64
  %t22 = call ptr @__olang_sb_room(ptr %s2, i64 24)
  %t23 = call i64 @__olang_fmt_u64(ptr %t22, i64 %t21)
  call void @__olang_sb_add(ptr %s2, i64 %t23)
  %t24 = load ptr, ptr %s2
  %t25 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t26 = load i64, ptr %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t24, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l8, !tbaa !27
  %t30 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t31 = load ptr, ptr %t30
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %sbgrew.33, label %sbdone.34
sbgrew.33:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.34
sbdone.34:
  %t35 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t35, ptr %rv
  br label %ret
bb4:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/net:Addr", ptr %t36, i32 0, i32 0
  %t39 = load %"std/net:IP", ptr %t38
  store %"std/net:IP" %t39, ptr %l10
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/net:Addr", ptr %t40, i32 0, i32 1
  %t43 = load i16, ptr %t42, !tbaa !63
  store i16 %t43, ptr %l12, !tbaa !63
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  call void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aIP(ptr %s3, ptr %l10, i64 0)
  br label %bb5
bb5:
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t45, i64 %t46)
  %t47 = load i16, ptr %l12, !tbaa !63
  %t48 = zext i16 %t47 to i64
  %t49 = call ptr @__olang_sb_room(ptr %s3, i64 24)
  %t50 = call i64 @__olang_fmt_u64(ptr %t49, i64 %t48)
  call void @__olang_sb_add(ptr %s3, i64 %t50)
  %t51 = load ptr, ptr %s3
  %t52 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t53 = load i64, ptr %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t53)
  call void @olang_textcopy(ptr %t54, ptr %t51, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l14, !tbaa !27
  %t57 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t58 = load ptr, ptr %t57
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %sbgrew.60, label %sbdone.61
sbgrew.60:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.61
sbdone.61:
  %t62 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fnet_2estd_2fnet_3aConn_2eCloseWrite(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:Conn", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t5 = load i32, ptr @G_2estd_2fnet_2eshutWr, !tbaa !23
  call void @std_2fnet_2esysShutdown(i32 %t4, i32 %t5)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fnet_2estd_2fnet_3aConn_2eFd(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:Conn", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"std/net:Addr" } @std_2fnet_2estd_2fnet_3aConn_2eLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/net:Addr"
  %l4 = alloca %"std/net:Addr"
  %l5 = alloca i32
  %rv = alloca { i32, %"std/net:Addr" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:Conn", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = call { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2enameOf(i32 %t4, i1 false)
  %t7 = extractvalue { i32, %"std/net:Addr" } %t6, 1
  %t8 = extractvalue { i32, %"std/net:Addr" } %t6, 0
  store i32 %t8, ptr %l5
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  store %"std/net:Addr" %t7, ptr %l4
  br label %bb1
bb1:
  %t11 = load %"std/net:Addr", ptr %l4
  store %"std/net:Addr" %t11, ptr %l1
  br label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t13 = lshr i32 %t12, 16
  %t14 = and i32 %t12, 65535
  %t15 = icmp eq i32 %t13, 1
  %t16 = select i1 %t15, i32 1, i32 0
  %t17 = icmp eq i32 %t12, 0
  %t18 = shl i32 %t16, 16
  %t19 = or i32 %t18, %t14
  %t20 = select i1 %t17, i32 0, i32 %t19
  %t22 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 %t20, 0
  store { i32, %"std/net:Addr" } %t22, ptr %rv
  br label %ret
bb3:
  %t23 = load %"std/net:Addr", ptr %l1
  %t24 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, %"std/net:Addr" %t23, 1
  store { i32, %"std/net:Addr" } %t24, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:Addr" }, ptr %rv
  ret { i32, %"std/net:Addr" } %rr
}

define dso_local { i32, %"std/net:Addr" } @std_2fnet_2estd_2fnet_3aConn_2eRemote(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/net:Addr"
  %l4 = alloca %"std/net:Addr"
  %l5 = alloca i32
  %rv = alloca { i32, %"std/net:Addr" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:Conn", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = call { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2enameOf(i32 %t4, i1 true)
  %t7 = extractvalue { i32, %"std/net:Addr" } %t6, 1
  %t8 = extractvalue { i32, %"std/net:Addr" } %t6, 0
  store i32 %t8, ptr %l5
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  store %"std/net:Addr" %t7, ptr %l4
  br label %bb1
bb1:
  %t11 = load %"std/net:Addr", ptr %l4
  store %"std/net:Addr" %t11, ptr %l1
  br label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t13 = lshr i32 %t12, 16
  %t14 = and i32 %t12, 65535
  %t15 = icmp eq i32 %t13, 1
  %t16 = select i1 %t15, i32 1, i32 0
  %t17 = icmp eq i32 %t12, 0
  %t18 = shl i32 %t16, 16
  %t19 = or i32 %t18, %t14
  %t20 = select i1 %t17, i32 0, i32 %t19
  %t22 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 %t20, 0
  store { i32, %"std/net:Addr" } %t22, ptr %rv
  br label %ret
bb3:
  %t23 = load %"std/net:Addr", ptr %l1
  %t24 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, %"std/net:Addr" %t23, 1
  store { i32, %"std/net:Addr" } %t24, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:Addr" }, ptr %rv
  ret { i32, %"std/net:Addr" } %rr
}

define dso_local void @std_2fnet_2estd_2fnet_3aConn_2eSetTimeout(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:Conn", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  call void @std_2fnet_2esysTimeout(i32 %t4, i64 %a1, i1 true)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fnet_2estd_2fnet_3aConn_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i64
  %l28 = alloca i1
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l33 = alloca i32
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp slt i64 %t1, %t4
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %bb24
bb3:
  br label %bb4
bb4:
  %t13 = getelementptr %"std/net:Conn", ptr %a0, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  store i32 %t14, ptr %l10, !tbaa !23
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %l12, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t17, 0
  store i64 %t20, ptr %l15, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l16, !tbaa !24
  %t23 = load i64, ptr %l12, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = icmp sle i64 %t26, %t27
  br i1 %t28, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_f586f295cd339b44_dfef29ed04e9a840)
  unreachable
bb7:
  %t30 = load i64, ptr %l15, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = icmp sle i64 %t30, %t31
  br i1 %t32, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f586f295cd339b44_dfef29ed04e9a840)
  unreachable
bb9:
  %t34 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = load i64, ptr %l12, !tbaa !24
  %t37 = load i64, ptr %l15, !tbaa !24
  %t38 = getelementptr i8, ptr %t35, i64 %t36
  %t39 = sub i64 %t37, %t36
  %t40 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  %t42 = load i32, ptr %l10, !tbaa !23
  %t44 = call i64 @std_2fnet_2esysSend(ptr %v1, i32 %t42, { i64, ptr } %t41)
  store i64 %t44, ptr %l21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f586f295cd339b44_dfef29ed04e9a840)
  unreachable
bb11:
  %t45 = load i64, ptr %l21, !tbaa !24
  store i64 %t45, ptr %l3, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = icmp sge i64 %t46, 0
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t50 = load i64, ptr %l2, !tbaa !24
  %t52 = load i64, ptr %l3, !tbaa !24
  %t55 = add i64 %t50, %t52
  store i64 %t55, ptr %l2, !tbaa !24
  br label %bb22
bb13:
  %t57 = call i1 @std_2fnet_2einterrupted()
  store i1 %t57, ptr %l28
  br label %bb14
bb14:
  %t58 = load i1, ptr %l28, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb15, label %bb16
bb15:
  %t61 = call i32 @std_2fnet_2esockErr()
  store i32 %t61, ptr %l30
  br label %bb17
bb16:
  br label %bb21
bb17:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t63 = load i32, ptr %l30, !tbaa !23
  %t65 = call i32 @std_2fnet_2eraise(i32 %t63, { i64, ptr } %t62)
  store i32 %t65, ptr %l33
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb19, label %ok.67, !prof !99
ok.67:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t68 = load i32, ptr %l33, !tbaa !23
  %t69 = lshr i32 %t68, 16
  %t70 = and i32 %t68, 65535
  %t71 = icmp eq i32 %t69, 1
  %t72 = select i1 %t71, i32 1, i32 0
  %t73 = icmp eq i32 %t68, 0
  %t74 = shl i32 %t72, 16
  %t75 = or i32 %t74, %t70
  %t76 = select i1 %t73, i32 0, i32 %t75
  store i32 %t76, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb1
bb24:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2fnet_2estd_2fnet_3aIP_2eBytes(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/net:IP", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 16, ptr %l10, !tbaa !24
  br label %bb3
bb2:
  store i64 4, ptr %l10, !tbaa !24
  br label %bb3
bb3:
  %t6 = load i64, ptr %l10, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_c4c0099ed746cf61_f3a8188923e5ddc5)
  unreachable
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb11
bb8:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l21, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t45 = load i64, ptr %l21, !tbaa !24
  store i64 %t45, ptr %l18, !tbaa !24
  br label %bb11
bb11:
  %t46 = load i64, ptr %l18, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = sub i64 %t47, 1
  store i64 %t48, ptr %l30, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = icmp slt i64 %t49, 2147483648
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp sge i64 %t51, 0
  %t55 = and i1 %t50, %t52
  store i1 %t55, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l4, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l7, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l7, !tbaa !24
  %t78 = getelementptr %"std/net:IP", ptr %t75, i32 0, i32 1
  %t80 = getelementptr [16 x i8], ptr %t78, i64 0, i64 %t76
  %t81 = load i8, ptr %t80, !tbaa !32
  %t84 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i8, ptr %t85, i64 %t74
  store i8 %t81, ptr %t86, !tbaa !32
  br label %bb16
bb16:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = add i64 %t87, 1
  store i64 %t90, ptr %l6, !tbaa !24
  br label %bb12
bb17:
  %t92 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @std_2fnet_2estd_2fnet_3aIP_2eIsLoopback(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/net:IP", ptr %t1, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/net:IP", ptr %t8, i32 0, i32 1
  %t11 = getelementptr [16 x i8], ptr %t10, i64 0, i64 0
  %t12 = load i8, ptr %t11, !tbaa !32
  %t14 = icmp eq i8 %t12, 127
  store i1 %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l1, !tbaa !24
  store i64 15, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb9
bb6:
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l19, !tbaa !24
  store i64 %t42, ptr %l16, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l16, !tbaa !24
  store i64 %t43, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = sub i64 %t44, 1
  store i64 %t45, ptr %l28, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp slt i64 %t46, 2147483648
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = icmp sge i64 %t48, 0
  %t52 = and i1 %t47, %t49
  store i1 %t52, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb11, label %bb12
bb11:
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t61 = load i64, ptr %l1, !tbaa !24
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"std/net:IP", ptr %t71, i32 0, i32 1
  %t76 = getelementptr [16 x i8], ptr %t74, i64 0, i64 %t69
  %t77 = load i8, ptr %t76, !tbaa !32
  %t79 = icmp ne i8 %t77, 0
  br i1 %t79, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb10
bb18:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"std/net:IP", ptr %t87, i32 0, i32 1
  %t90 = getelementptr [16 x i8], ptr %t89, i64 0, i64 15
  %t91 = load i8, ptr %t90, !tbaa !32
  %t93 = icmp eq i8 %t91, 1
  store i1 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, %"std/net:Conn" } @std_2fnet_2estd_2fnet_3aListener_2eAccept(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i32
  %l4 = alloca i32
  %l8 = alloca %"std/net:Conn"
  %l9 = alloca i1
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l14 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca { i32, %"std/net:Conn" }
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t3 = getelementptr %"std/net:Listener", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = call i32 @std_2fnet_2esysAccept(i32 %t4)
  store i32 %t6, ptr %l4
  br label %bb2
bb2:
  %t7 = load i32, ptr %l4, !tbaa !23
  store i32 %t7, ptr %l1, !tbaa !23
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = icmp sge i32 %t8, 0
  br i1 %t10, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t14 = call %"std/net:Conn" @std_2fnet_3aConn_2ector(ptr %s2, i32 %t12)
  store %"std/net:Conn" %t14, ptr %l8
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  %t15 = load %"std/net:Conn", ptr %l8
  %t16 = insertvalue { i32, %"std/net:Conn" } zeroinitializer, %"std/net:Conn" %t15, 1
  store { i32, %"std/net:Conn" } %t16, ptr %rv
  br label %ret
bb6:
  %t17 = call i1 @std_2fnet_2einterrupted()
  store i1 %t17, ptr %l9
  br label %bb7
bb7:
  %t18 = load i1, ptr %l9, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t21 = call i32 @std_2fnet_2esockErr()
  store i32 %t21, ptr %l11
  br label %bb10
bb9:
  br label %bb14
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t23 = load i32, ptr %l11, !tbaa !23
  %t25 = call i32 @std_2fnet_2eraise(i32 %t23, { i64, ptr } %t22)
  store i32 %t25, ptr %l14
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb12, label %ok.27, !prof !99
ok.27:
  br label %bb11
bb11:
  br label %bb13
bb12:
  %t28 = load i32, ptr %l14, !tbaa !23
  %t29 = lshr i32 %t28, 16
  %t30 = and i32 %t28, 65535
  %t31 = icmp eq i32 %t29, 1
  %t32 = select i1 %t31, i32 1, i32 0
  %t33 = icmp eq i32 %t28, 0
  %t34 = shl i32 %t32, 16
  %t35 = or i32 %t34, %t30
  %t36 = select i1 %t33, i32 0, i32 %t35
  %t38 = insertvalue { i32, %"std/net:Conn" } zeroinitializer, i32 %t36, 0
  store { i32, %"std/net:Conn" } %t38, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb1
ret:
  %rr = load { i32, %"std/net:Conn" }, ptr %rv
  ret { i32, %"std/net:Conn" } %rr
}

define dso_local { i32, %"std/net:Addr" } @std_2fnet_2estd_2fnet_3aListener_2eAddr(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/net:Addr"
  %l4 = alloca %"std/net:Addr"
  %l5 = alloca i32
  %rv = alloca { i32, %"std/net:Addr" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:Listener", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = call { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2enameOf(i32 %t4, i1 false)
  %t7 = extractvalue { i32, %"std/net:Addr" } %t6, 1
  %t8 = extractvalue { i32, %"std/net:Addr" } %t6, 0
  store i32 %t8, ptr %l5
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  store %"std/net:Addr" %t7, ptr %l4
  br label %bb1
bb1:
  %t11 = load %"std/net:Addr", ptr %l4
  store %"std/net:Addr" %t11, ptr %l1
  br label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t13 = lshr i32 %t12, 16
  %t14 = and i32 %t12, 65535
  %t15 = icmp eq i32 %t13, 1
  %t16 = select i1 %t15, i32 1, i32 0
  %t17 = icmp eq i32 %t12, 0
  %t18 = shl i32 %t16, 16
  %t19 = or i32 %t18, %t14
  %t20 = select i1 %t17, i32 0, i32 %t19
  %t22 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 %t20, 0
  store { i32, %"std/net:Addr" } %t22, ptr %rv
  br label %ret
bb3:
  %t23 = load %"std/net:Addr", ptr %l1
  %t24 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, %"std/net:Addr" %t23, 1
  store { i32, %"std/net:Addr" } %t24, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:Addr" }, ptr %rv
  ret { i32, %"std/net:Addr" } %rr
}

define dso_local i32 @std_2fnet_2estd_2fnet_3aListener_2eFd(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:Listener", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"std/net:Addr" } @std_2fnet_2estd_2fnet_3aUDP_2eLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/net:Addr"
  %l4 = alloca %"std/net:Addr"
  %l5 = alloca i32
  %rv = alloca { i32, %"std/net:Addr" }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:UDP", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = call { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2enameOf(i32 %t4, i1 false)
  %t7 = extractvalue { i32, %"std/net:Addr" } %t6, 1
  %t8 = extractvalue { i32, %"std/net:Addr" } %t6, 0
  store i32 %t8, ptr %l5
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  store %"std/net:Addr" %t7, ptr %l4
  br label %bb1
bb1:
  %t11 = load %"std/net:Addr", ptr %l4
  store %"std/net:Addr" %t11, ptr %l1
  br label %bb3
bb2:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t13 = lshr i32 %t12, 16
  %t14 = and i32 %t12, 65535
  %t15 = icmp eq i32 %t13, 1
  %t16 = select i1 %t15, i32 1, i32 0
  %t17 = icmp eq i32 %t12, 0
  %t18 = shl i32 %t16, 16
  %t19 = or i32 %t18, %t14
  %t20 = select i1 %t17, i32 0, i32 %t19
  %t22 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, i32 %t20, 0
  store { i32, %"std/net:Addr" } %t22, ptr %rv
  br label %ret
bb3:
  %t23 = load %"std/net:Addr", ptr %l1
  %t24 = insertvalue { i32, %"std/net:Addr" } zeroinitializer, %"std/net:Addr" %t23, 1
  store { i32, %"std/net:Addr" } %t24, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/net:Addr" }, ptr %rv
  ret { i32, %"std/net:Addr" } %rr
}

define dso_local i32 @std_2fnet_2estd_2fnet_3aUDP_2eSendTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l10 = alloca i64
  %l13 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call { i64, ptr } @std_2fnet_2esockaddr(ptr %v2, ptr %s0, ptr %t1)
  store { i64, ptr } %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  br label %bb2
bb2:
  %t7 = getelementptr %"std/net:UDP", ptr %a0, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = call i64 @std_2fnet_2esysSendTo(ptr %v1, ptr %s0, i32 %t8, { i64, ptr } %a1, { i64, ptr } %t10)
  store i64 %t14, ptr %l10
  br label %bb3
bb3:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = icmp slt i64 %t15, 0
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb17
bb5:
  br label %bb6
bb6:
  %t20 = call i1 @std_2fnet_2einterrupted()
  store i1 %t20, ptr %l13
  br label %bb7
bb7:
  %t21 = load i1, ptr %l13, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = call i32 @std_2fnet_2esockErr()
  store i32 %t24, ptr %l15
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  call void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aAddr_26(ptr %s3, ptr %l16, i64 0)
  br label %bb11
bb11:
  %t27 = load ptr, ptr %s3
  %t28 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t29 = load i64, ptr %t28
  %t30 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t27, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l18, !tbaa !27
  %t33 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t34 = load ptr, ptr %t33
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %sbgrew.36, label %sbdone.37
sbgrew.36:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.37
sbdone.37:
  %t38 = load i32, ptr %l15, !tbaa !23
  %t39 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t40 = call i32 @std_2fnet_2eraise(i32 %t38, { i64, ptr } %t39)
  store i32 %t40, ptr %l19
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb13, label %ok.42, !prof !99
ok.42:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t43 = load i32, ptr %l19, !tbaa !23
  %t44 = lshr i32 %t43, 16
  %t45 = and i32 %t43, 65535
  %t46 = icmp eq i32 %t44, 1
  %t47 = select i1 %t46, i32 1, i32 0
  %t48 = icmp eq i32 %t43, 0
  %t49 = shl i32 %t47, 16
  %t50 = or i32 %t49, %t45
  %t51 = select i1 %t48, i32 0, i32 %t50
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t51, ptr %rv
  br label %ret
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb2
bb17:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fnet_2estd_2fnet_3aUDP_2eSetTimeout(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:UDP", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  call void @std_2fnet_2esysTimeout(i32 %t4, i64 %a1, i1 false)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fnet_2esysAccept(i32 %a0) #0 {
entry:
  %l1 = alloca [28 x i8]
  %l2 = alloca [1 x i32]
  %l3 = alloca [28 x i8]
  %l10 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 28
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [28 x i8], ptr %l3, i64 0, i64 %t5
  store i8 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  %t9 = load [28 x i8], ptr %l3
  store [28 x i8] %t9, ptr %l1
  %t10 = insertvalue [1 x i32] undef, i32 28, 0
  store [1 x i32] %t10, ptr %l2
  %t14 = insertvalue { i64, ptr } undef, i64 1, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %l2, 1
  %t16 = load i32, ptr @G_2estd_2fnet_2esockCloexec, !tbaa !23
  %t20 = extractvalue { i64, ptr } %t15, 1
  %t21 = extractvalue { i64, ptr } %t15, 0
  %t23 = call i32 @accept4(i32 %a0, ptr %l1, ptr %t20, i32 %t16)
  store i32 %t23, ptr %l10
  br label %bb1
bb1:
  %t24 = load i32, ptr %l10, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fnet_2esysBind(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l7 = alloca i32
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t7 = trunc i64 %t5 to i32
  %t10 = extractvalue { i64, ptr } %t2, 1
  %t11 = extractvalue { i64, ptr } %t2, 0
  %t13 = call i32 @bind(i32 %a0, ptr %t10, i32 %t7)
  store i32 %t13, ptr %l7
  br label %bb1
bb1:
  %t14 = load i32, ptr %l7, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fnet_2esysName(ptr %v0, i32 %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l3 = alloca [1 x i32]
  %l13 = alloca i32
  %l18 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = trunc i64 %t3 to i32
  %t7 = insertvalue [1 x i32] undef, i32 %t5, 0
  store [1 x i32] %t7, ptr %l3
  br i1 %a2, label %bb1, label %bb2
bb1:
  %t11 = load i32, ptr %l0, !tbaa !23
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = insertvalue { i64, ptr } undef, i64 1, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %l3, 1
  %t18 = extractvalue { i64, ptr } %t12, 1
  %t19 = extractvalue { i64, ptr } %t12, 0
  %t21 = extractvalue { i64, ptr } %t15, 1
  %t22 = extractvalue { i64, ptr } %t15, 0
  %t23 = call i32 @getpeername(i32 %t11, ptr %t18, ptr %t21)
  store i32 %t23, ptr %l13
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t24 = load i32, ptr %l13, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb4:
  %t25 = load i32, ptr %l0, !tbaa !23
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = insertvalue { i64, ptr } undef, i64 1, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %l3, 1
  %t32 = extractvalue { i64, ptr } %t26, 1
  %t33 = extractvalue { i64, ptr } %t26, 0
  %t35 = extractvalue { i64, ptr } %t29, 1
  %t36 = extractvalue { i64, ptr } %t29, 0
  %t37 = call i32 @getsockname(i32 %t25, ptr %t32, ptr %t35)
  store i32 %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load i32, ptr %l18, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @std_2fnet_2esysSend(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l8 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t7 = load i32, ptr @G_2estd_2fnet_2emsgNosignal, !tbaa !23
  %t10 = extractvalue { i64, ptr } %t2, 1
  %t11 = extractvalue { i64, ptr } %t2, 0
  %t14 = call i64 @send(i32 %a0, ptr %t10, i64 %t5, i32 %t7)
  store i64 %t14, ptr %l8
  br label %bb1
bb1:
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fnet_2esysSendTo(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l13 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t7 = load i32, ptr @G_2estd_2fnet_2emsgNosignal, !tbaa !23
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = trunc i64 %t11 to i32
  %t16 = extractvalue { i64, ptr } %t2, 1
  %t17 = extractvalue { i64, ptr } %t2, 0
  %t21 = extractvalue { i64, ptr } %t8, 1
  %t22 = extractvalue { i64, ptr } %t8, 0
  %t24 = call i64 @sendto(i32 %a0, ptr %t16, i64 %t5, i32 %t7, ptr %t21, i32 %t13)
  store i64 %t24, ptr %l13
  br label %bb1
bb1:
  %t25 = load i64, ptr %l13, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fnet_2esysSetOpt(ptr %v0, i32 %a0, i32 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l11 = alloca i32
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = trunc i64 %t7 to i32
  %t14 = extractvalue { i64, ptr } %t4, 1
  %t15 = extractvalue { i64, ptr } %t4, 0
  %t17 = call i32 @setsockopt(i32 %a0, i32 %a1, i32 %a2, ptr %t14, i32 %t9)
  store i32 %t17, ptr %l11
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fnet_2esysShutdown(i32 %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @shutdown(i32 %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fnet_2esysSocket(i32 %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load i32, ptr @G_2estd_2fnet_2esockCloexec, !tbaa !23
  %t6 = or i32 %a1, %t3
  %t9 = call i32 @socket(i32 %a0, i32 %t6, i32 0)
  store i32 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fnet_2ewsaClass(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, 10013
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 3, ptr %rv
  br label %ret
bb4:
  %t6 = load i32, ptr %l0, !tbaa !23
  %t8 = icmp eq i32 %t6, 10061
  br i1 %t8, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i32 7, ptr %rv
  br label %ret
bb8:
  %t11 = load i32, ptr %l0, !tbaa !23
  %t13 = icmp eq i32 %t11, 10048
  br i1 %t13, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i32 8, ptr %rv
  br label %ret
bb12:
  %t16 = load i32, ptr %l0, !tbaa !23
  %t18 = icmp eq i32 %t16, 10060
  br i1 %t18, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 9, ptr %rv
  br label %ret
bb16:
  %t21 = load i32, ptr %l0, !tbaa !23
  %t23 = icmp eq i32 %t21, 10054
  br i1 %t23, label %bb17, label %bb18
bb17:
  br label %bb21
bb18:
  %t25 = load i32, ptr %l0, !tbaa !23
  %t27 = icmp eq i32 %t25, 10053
  br i1 %t27, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i32 10, ptr %rv
  br label %ret
bb22:
  %t30 = load i32, ptr %l0, !tbaa !23
  %t32 = icmp eq i32 %t30, 10051
  br i1 %t32, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  %t34 = load i32, ptr %l0, !tbaa !23
  %t36 = icmp eq i32 %t34, 10065
  br i1 %t36, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i32 11, ptr %rv
  br label %ret
bb28:
  %t39 = load i32, ptr %l0, !tbaa !23
  %t41 = icmp eq i32 %t39, 10049
  br i1 %t41, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  %t43 = load i32, ptr %l0, !tbaa !23
  %t45 = icmp eq i32 %t43, 10047
  br i1 %t45, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i32 12, ptr %rv
  br label %ret
bb34:
  %t48 = load i32, ptr %l0, !tbaa !23
  %t50 = icmp eq i32 %t48, 10004
  br i1 %t50, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i32 13, ptr %rv
  br label %ret
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i32 0, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_4896c8ff75bc736f_324304f76e2984bb)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/net:Addr" @std_2fnet_3aAddr_2ector(ptr %v0, %"std/net:IP" %a0, i16 %a1) #0 {
entry:
  %rv = alloca %"std/net:Addr"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"std/net:Addr" undef, %"std/net:IP" %a0, 0
  %t8 = insertvalue %"std/net:Addr" %t6, i16 %a1, 1
  store %"std/net:Addr" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/net:Addr", ptr %rv
  ret %"std/net:Addr" %rr
}

define dso_local %"std/net:Conn" @std_2fnet_3aConn_2ector(ptr %v0, i32 %a0) #0 {
entry:
  %rv = alloca %"std/net:Conn"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"std/net:Conn" undef, i32 %a0, 0
  store %"std/net:Conn" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/net:Conn", ptr %rv
  ret %"std/net:Conn" %rr
}

define dso_local void @std_2fnet_3aConn_2edtor(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:Conn", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  call void @std_2fnet_2ecloseSock(i32 %t4)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local %"std/net:IP" @std_2fnet_3aIP_2ector(ptr %v0, i1 %a0) #0 {
entry:
  %rv = alloca %"std/net:IP"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = insertvalue [16 x i8] undef, i8 0, 0
  %t4 = insertvalue [16 x i8] %t3, i8 0, 1
  %t5 = insertvalue [16 x i8] %t4, i8 0, 2
  %t6 = insertvalue [16 x i8] %t5, i8 0, 3
  %t7 = insertvalue [16 x i8] %t6, i8 0, 4
  %t8 = insertvalue [16 x i8] %t7, i8 0, 5
  %t9 = insertvalue [16 x i8] %t8, i8 0, 6
  %t10 = insertvalue [16 x i8] %t9, i8 0, 7
  %t11 = insertvalue [16 x i8] %t10, i8 0, 8
  %t12 = insertvalue [16 x i8] %t11, i8 0, 9
  %t13 = insertvalue [16 x i8] %t12, i8 0, 10
  %t14 = insertvalue [16 x i8] %t13, i8 0, 11
  %t15 = insertvalue [16 x i8] %t14, i8 0, 12
  %t16 = insertvalue [16 x i8] %t15, i8 0, 13
  %t17 = insertvalue [16 x i8] %t16, i8 0, 14
  %t18 = insertvalue [16 x i8] %t17, i8 0, 15
  %t21 = insertvalue %"std/net:IP" undef, i1 %a0, 0
  %t23 = insertvalue %"std/net:IP" %t21, [16 x i8] %t18, 1
  store %"std/net:IP" %t23, ptr %rv
  br label %ret
ret:
  %rr = load %"std/net:IP", ptr %rv
  ret %"std/net:IP" %rr
}

define dso_local void @std_2fnet_3aListener_2edtor(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:Listener", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  call void @std_2fnet_2ecloseSock(i32 %t4)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fnet_3aUDP_2edtor(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/net:UDP", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  call void @std_2fnet_2ecloseSock(i32 %t4)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_errpay_push() cold
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 10}
  switch i64 %t3, label %bb1 [ i64 5, label %bb2 i64 6, label %bb3 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { { i64, ptr } }, ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, ptr } }, ptr %t42, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t43
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_errpay_set(ptr) cold
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2eArray_3cU8_3e_26(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  br label %bb1
bb1:
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = icmp sge i64 %t3, 8
  br i1 %t4, label %bb3, label %bb4
bb2:
  br label %ret
bb3:
  %t6 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  br label %bb2
bb4:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = add i64 %t8, 1
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @olang_2emir_2eHelperKind_2eRender_2eArray_3cU8_3e(ptr %v0, { i64, ptr } %t10, i64 %t9)
  br label %bb5
bb5:
  br label %bb2
ret:
  ret void
}

define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_sb_done(ptr)
declare i32 @close(i32)
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aAddr_26(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %a0, !tbaa !29
  store ptr %t2, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = icmp ne ptr %t3, null
  br i1 %t4, label %bb1, label %bb3
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sge i64 %t6, 8
  br i1 %t7, label %bb4, label %bb5
bb2:
  br label %ret
bb3:
  %t9 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb2
bb4:
  %t11 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb2
bb5:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t13, 1
  store i64 %t14, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l2, !tbaa !29
  store ptr %t15, ptr %l6, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l6, !tbaa !29
  %t17 = call ptr @__olang_scope_of(ptr %t16, ptr null)
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  %t21 = inttoptr i64 %t19 to ptr
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t23 = call { i64, ptr } @std_2fnet_2estd_2fnet_3aAddr_2eStr(ptr %t21, ptr %s1, ptr %t22)
  store { i64, ptr } %t23, ptr %l7
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  call void @__olang_scope_close(ptr %s1)
  br label %bb2
ret:
  ret void
}

declare i32 @__olang_err()
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aIP(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = call ptr @__olang_scope_of(ptr %t2, ptr null)
  %t4 = call ptr @__olang_scope_hold(ptr %t3)
  %t5 = ptrtoint ptr %t4 to i64
  %t7 = inttoptr i64 %t5 to ptr
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = call { i64, ptr } @std_2fnet_2estd_2fnet_3aIP_2eStr(ptr %t7, ptr %s1, ptr %t8)
  store { i64, ptr } %t9, ptr %l3
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]:" }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_u64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare i32 @accept4(i32, ptr, ptr, i32)
declare i32 @bind(i32, ptr, i32)
declare i32 @getpeername(i32, ptr, ptr)
declare i32 @getsockname(i32, ptr, ptr)
declare i64 @send(i32, ptr, i64, i32)
declare i64 @sendto(i32, ptr, i64, i32, ptr, i32)
declare i32 @setsockopt(i32, i32, i32, ptr, i32)
declare i32 @shutdown(i32, i32)
declare i32 @socket(i32, i32, i32)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d4 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2eArray_3cU8_3e(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t1, i64 %t2)
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  store i64 %t4, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, %t6
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp eq i64 %t9, 0
  br i1 %t10, label %bb5, label %bb4
bb3:
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t12, i64 %t13)
  br label %ret
bb4:
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t14, i64 %t15)
  br label %bb5
bb5:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i8, ptr %t18, i64 %t16
  %t20 = load i8, ptr %t19, !tbaa !32
  %t22 = zext i8 %t20 to i64
  %t23 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t24 = call i64 @__olang_fmt_u64(ptr %t23, i64 %t22)
  call void @__olang_sb_add(ptr %v0, i64 %t24)
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t25, 1
  store i64 %t26, ptr %l3, !tbaa !24
  br label %bb1
ret:
  ret void
}

declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d5 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
declare ptr @__olang_sb_grow(ptr, i64) noinline
@.d6 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Array<U8>[" }>, align 8
@.d7 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d8 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2ehostPort(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fnet_2eraise(i32 %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fnet_2esysReadable(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fnet_2esysTimeout(i32 %a0, i64 %a1, i1 %a2)
@olang_loc_f586f295cd339b44_dfef29ed04e9a840 = external constant [0 x i8]
@olang_loc_c4c0099ed746cf61_f3a8188923e5ddc5 = external constant [0 x i8]
declare { i64, ptr } @std_2fnet_2esockaddr(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_4896c8ff75bc736f_324304f76e2984bb = external constant [0 x i8]
declare { i64, ptr } @std_2fnet_2estd_2fnet_3aIP_2eStr(ptr %v0, ptr %v1, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
