; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/os:Process" = type { i32, i32, i32, i1, i1 }
%"std/os:FileInfo" = type { i32, i64, i64 }
define dso_local { i64, ptr } @std_2fos_2eArgs(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i64 @__olang_arg_count()
  store i64 %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load i64, ptr %l9, !tbaa !24
  store i64 %t2, ptr %l0, !tbaa !24
  %t3 = load i64, ptr %l0, !tbaa !24
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  store i1 %t5, ptr %l11, !tbaa !21
  %t6 = load i1, ptr %l11, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = icmp sle i64 %t7, 576460752303423487
  store i1 %t8, ptr %l12, !tbaa !21
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb4:
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t10, 16
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l13, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 16
  %t19 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %l1, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l0, !tbaa !24
  store i64 %t23, ptr %l15, !tbaa !24
  %t24 = load i64, ptr %l15, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  store i64 %t25, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = load i64, ptr %l17, !tbaa !24
  %t29 = icmp sgt i64 %t27, %t28
  store i1 %t29, ptr %l18, !tbaa !21
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb6:
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l20, !tbaa !24
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = icmp sgt i64 %t32, 0
  store i1 %t33, ptr %l21, !tbaa !21
  %t34 = load i1, ptr %l21, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb11
bb8:
  %t35 = load i64, ptr %l3, !tbaa !24
  store i64 %t35, ptr %l23, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  store i64 %t36, ptr %l24, !tbaa !24
  %t37 = load i64, ptr %l23, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = sub i64 %t37, %t38
  store i64 %t39, ptr %l25, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  store i64 %t40, ptr %l26, !tbaa !24
  %t41 = load i64, ptr %l25, !tbaa !24
  %t42 = load i64, ptr %l26, !tbaa !24
  %t43 = add i64 %t41, %t42
  store i64 %t43, ptr %l27, !tbaa !24
  %t44 = load i64, ptr %l27, !tbaa !24
  %t45 = sub i64 %t44, 1
  store i64 %t45, ptr %l28, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  store i64 %t46, ptr %l29, !tbaa !24
  %t47 = load i64, ptr %l28, !tbaa !24
  %t48 = load i64, ptr %l29, !tbaa !24
  %t49 = sdiv i64 %t47, %t48
  store i64 %t49, ptr %l30, !tbaa !24
  %t50 = load i64, ptr %l30, !tbaa !24
  store i64 %t50, ptr %l22, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb10
bb10:
  %t51 = load i64, ptr %l22, !tbaa !24
  store i64 %t51, ptr %l19, !tbaa !24
  br label %bb11
bb11:
  %t52 = load i64, ptr %l19, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load i64, ptr %l6, !tbaa !24
  store i64 %t53, ptr %l31, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  store i64 %t54, ptr %l32, !tbaa !24
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = icmp slt i64 %t55, %t56
  store i1 %t57, ptr %l33, !tbaa !21
  %t58 = load i1, ptr %l33, !tbaa !21
  %t59 = xor i1 %t58, true
  store i1 %t59, ptr %l34, !tbaa !21
  %t60 = load i1, ptr %l34, !tbaa !21
  br i1 %t60, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t61 = load i64, ptr %l2, !tbaa !24
  store i64 %t61, ptr %l35, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  store i64 %t62, ptr %l36, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  store i64 %t63, ptr %l37, !tbaa !24
  %t64 = load i64, ptr %l36, !tbaa !24
  %t65 = load i64, ptr %l37, !tbaa !24
  %t66 = mul i64 %t64, %t65
  store i64 %t66, ptr %l38, !tbaa !24
  %t67 = load i64, ptr %l35, !tbaa !24
  %t68 = load i64, ptr %l38, !tbaa !24
  %t69 = add i64 %t67, %t68
  store i64 %t69, ptr %l39, !tbaa !24
  %t70 = load i64, ptr %l39, !tbaa !24
  store i64 %t70, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  store i64 %t71, ptr %l40, !tbaa !24
  %t72 = icmp sge i64 0, 0
  store i1 %t72, ptr %l41, !tbaa !21
  %t73 = load i1, ptr %l41, !tbaa !21
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t74 = mul i64 0, 1
  %t75 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 0, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l42, !tbaa !27
  %t78 = load i64, ptr %l40, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = call i64 @__olang_arg(i64 %t78, ptr %t80, i64 0)
  store i64 %t82, ptr %l43
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb18:
  %t83 = load i64, ptr %l43, !tbaa !24
  %t84 = icmp sge i64 %t83, 0
  store i1 %t84, ptr %l44, !tbaa !21
  %t85 = load i1, ptr %l44, !tbaa !21
  br i1 %t85, label %bb19, label %bb20
bb19:
  %t86 = load i64, ptr %l43, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l45, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t91, ptr %l46, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t94 = extractvalue { i64, ptr } %t92, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l47, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t99, ptr %l8, !tbaa !27
  %t100 = load i64, ptr %l7, !tbaa !24
  store i64 %t100, ptr %l48, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t101, ptr %l49, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t102, ptr %l50, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t103, ptr %l51, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t104, ptr %l52, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  store i64 %t106, ptr %l53, !tbaa !24
  %t107 = load i64, ptr %l48, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = call i64 @__olang_arg(i64 %t107, ptr %t109, i64 %t111)
  store i64 %t112, ptr %l54
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb21:
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t113, ptr %l55, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  store i64 %t114, ptr %l56, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t115, ptr %l57, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t117 = load i64, ptr %l56, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %t119, i64 %t117
  store { i64, ptr } %t116, ptr %t120, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t121 = load i64, ptr %l6, !tbaa !24
  store i64 %t121, ptr %l58, !tbaa !24
  %t122 = load i64, ptr %l58, !tbaa !24
  %t123 = add i64 %t122, 1
  store i64 %t123, ptr %l59, !tbaa !24
  %t124 = load i64, ptr %l59, !tbaa !24
  store i64 %t124, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb23:
  call void @__olang_scope_close(ptr %s1)
  %t125 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t125, ptr %l60, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t126 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t126, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @std_2fos_2eClose(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l1, !tbaa !23
  %t3 = call i32 @close(i32 %t2)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  %t5 = sext i32 %t4 to i64
  store i64 %t5, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = call i32 @std_2fos_2echeck(i64 %t6)
  store i32 %t7, ptr %l4
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  store i32 %t18, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i32, ptr %l5, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @std_2fos_2eCreate(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i32, i32 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = call i32 @creat(ptr %t15, i32 438)
  store i32 %t17, ptr %l5
  br label %bb1
bb1:
  %t18 = load i32, ptr %l5, !tbaa !23
  store i32 %t18, ptr %l1, !tbaa !23
  %t19 = load i32, ptr %l1, !tbaa !23
  store i32 %t19, ptr %l6, !tbaa !23
  %t20 = load i32, ptr %l6, !tbaa !23
  %t21 = sext i32 %t20 to i64
  store i64 %t21, ptr %l7, !tbaa !24
  %t22 = load i64, ptr %l7, !tbaa !24
  %t23 = call i32 @std_2fos_2echeck(i64 %t22)
  store i32 %t23, ptr %l8
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb3, label %ok.25
ok.25:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t26 = load i32, ptr %l8, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  store i32 %t34, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t35 = load i32, ptr %l9, !tbaa !23
  %t36 = insertvalue { i32, i32 } zeroinitializer, i32 %t35, 0
  store { i32, i32 } %t36, ptr %rv
  br label %ret
bb4:
  %t37 = load i32, ptr %l1, !tbaa !23
  store i32 %t37, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i32, ptr %l10, !tbaa !23
  %t39 = insertvalue { i32, i32 } zeroinitializer, i32 %t38, 1
  store { i32, i32 } %t39, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v0, { i64, ptr } { i64 1, ptr @.d3 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l1
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t6, ptr %l0, !tbaa !27
  br label %bb3
bb2:
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = lshr i32 %t7, 16
  %t9 = and i32 %t7, 65535
  %t10 = icmp eq i32 %t8, 1
  %t11 = select i1 %t10, i32 1, i32 0
  %t12 = icmp eq i32 %t7, 0
  %t13 = shl i32 %t11, 16
  %t14 = or i32 %t13, %t9
  %t15 = select i1 %t12, i32 0, i32 %t14
  store i32 %t15, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t16, 0
  store { i32, { i64, ptr } } %t17, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t18, 1
  store { i32, { i64, ptr } } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { ptr, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i32
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t17 = alloca { { i64, ptr }, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t13, ptr %l1, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t14, ptr %l5, !tbaa !27
  %t15 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t16 = ptrtoint ptr %t15 to i64
  %t18 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t19 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !28
  %t20 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 1
  store ptr %s0, ptr %t20, !tbaa !28
  %t21 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_5, 0
  %t22 = insertvalue { ptr, ptr } %t21, ptr %t17, 1
  store { ptr, ptr } %t22, ptr %l6
  %t23 = load { ptr, ptr }, ptr %l6
  %t24 = extractvalue { ptr, ptr } %t23, 0
  %t25 = extractvalue { ptr, ptr } %t23, 1
  %t26 = call { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %s0, ptr %v1, ptr %t24, ptr %t25)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l8
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb2, label %ok.30
ok.30:
  store { i64, ptr } %t27, ptr %l7
  br label %bb1
bb1:
  %t31 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb6
bb2:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = ashr i32 %t32, 16
  store i32 %t33, ptr %l9, !tbaa !23
  %t34 = load i32, ptr %l9, !tbaa !23
  %t35 = icmp eq i32 %t34, 1
  store i1 %t35, ptr %l10, !tbaa !21
  %t36 = load i1, ptr %l10, !tbaa !21
  br i1 %t36, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t37 = load i32, ptr %l8, !tbaa !23
  %t38 = lshr i32 %t37, 16
  %t39 = and i32 %t37, 65535
  %t40 = icmp eq i32 %t38, 1
  %t41 = select i1 %t40, i32 1, i32 0
  %t42 = icmp eq i32 %t37, 0
  %t43 = shl i32 %t41, 16
  %t44 = or i32 %t43, %t39
  %t45 = select i1 %t42, i32 0, i32 %t44
  store i32 %t45, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t46 = load i32, ptr %l11, !tbaa !23
  %t47 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t46, 0
  store { i32, { i64, ptr } } %t47, ptr %rv
  br label %ret
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 65536, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t48 = load i32, ptr %l12, !tbaa !23
  %t49 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t48, 0
  store { i32, { i64, ptr } } %t49, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t51 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t50, 1
  store { i32, { i64, ptr } } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:Process"
  %l5 = alloca %"std/os:Process"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/os:Process"
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca %"std/os:Output"
  %l14 = alloca ptr
  %l15 = alloca %"std/os:Output"
  %l16 = alloca i32
  %l17 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l7, !tbaa !27
  %t3 = load i1, ptr %l2, !tbaa !21
  store i1 %t3, ptr %l8, !tbaa !21
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l9, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t7 = load i1, ptr %l8, !tbaa !21
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t9 = call { i32, %"std/os:Process" } @std_2fos_2eStart(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %t5, { i64, ptr } %t6, i1 %t7, { i64, ptr } %t8)
  %t10 = extractvalue { i32, %"std/os:Process" } %t9, 1
  %t11 = extractvalue { i32, %"std/os:Process" } %t9, 0
  store i32 %t11, ptr %l11
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13
ok.13:
  store %"std/os:Process" %t10, ptr %l10
  br label %bb1
bb1:
  %t14 = load %"std/os:Process", ptr %l10
  store %"std/os:Process" %t14, ptr %l5
  br label %bb3
bb2:
  %t15 = load i32, ptr %l11, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  store i32 %t23, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i32, ptr %l12, !tbaa !23
  %t25 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t24, 0
  store { i32, %"std/os:Output" } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load %"std/os:Process", ptr %l5
  store %"std/os:Process" %t26, ptr %l4
  store ptr %l4, ptr %l14, !tbaa !29
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWait(ptr %s0, ptr %v3, ptr %t27)
  %t29 = extractvalue { i32, %"std/os:Output" } %t28, 1
  %t30 = extractvalue { i32, %"std/os:Output" } %t28, 0
  store i32 %t30, ptr %l16
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb5, label %ok.32
ok.32:
  store %"std/os:Output" %t29, ptr %l15
  br label %bb4
bb4:
  %t33 = load %"std/os:Output", ptr %l15
  store %"std/os:Output" %t33, ptr %l13
  br label %bb6
bb5:
  %t34 = load i32, ptr %l16, !tbaa !23
  %t35 = lshr i32 %t34, 16
  %t36 = and i32 %t34, 65535
  %t37 = icmp eq i32 %t35, 1
  %t38 = select i1 %t37, i32 1, i32 0
  %t39 = icmp eq i32 %t34, 0
  %t40 = shl i32 %t38, 16
  %t41 = or i32 %t40, %t36
  %t42 = select i1 %t39, i32 0, i32 %t41
  store i32 %t42, ptr %l17, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l17, !tbaa !23
  %t44 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t43, 0
  store { i32, %"std/os:Output" } %t44, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load %"std/os:Output", ptr %l13
  %t46 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t45, 1
  store { i32, %"std/os:Output" } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i8
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i32
  %l37 = alloca i1
  %l38 = alloca i32
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca i1
  %l51 = alloca i32
  %l52 = alloca i64
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i8
  %l75 = alloca i64
  %l76 = alloca i8
  %l77 = alloca i8
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca i32
  %l93 = alloca i32
  %l94 = alloca i32
  %l95 = alloca i32
  %l96 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.builder
  %s15room = alloca [64 x i8], align 8
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l19, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l20, !tbaa !24
  %t4 = load i64, ptr %l20, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l21, !tbaa !21
  %t6 = load i1, ptr %l21, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65542, ptr %l22, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l22, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l23, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t10, ptr %l24, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l25, !tbaa !24
  %t13 = load i64, ptr %l25, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %l26, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  store i64 %t15, ptr %l27, !tbaa !24
  %t16 = load i64, ptr %l26, !tbaa !24
  %t17 = load i64, ptr %l27, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  store i1 %t18, ptr %l28, !tbaa !21
  %t19 = load i1, ptr %l28, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l29, !tbaa !21
  %t21 = load i1, ptr %l29, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l30, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  store i64 %t23, ptr %l31, !tbaa !24
  %t24 = load i64, ptr %l31, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %t26, i64 %t24
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !37
  store { i64, ptr } %t28, ptr %l32, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  store i1 true, ptr %l7, !tbaa !21
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t30, ptr %l34, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t32 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t31, i8 0)
  %t33 = extractvalue { i32, i64 } %t32, 1
  %t34 = extractvalue { i32, i64 } %t32, 0
  store i32 %t34, ptr %l36
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb9, label %ok.36
ok.36:
  store i64 %t33, ptr %l35
  br label %bb8
bb8:
  %t37 = load i64, ptr %l35, !tbaa !24
  store i64 %t37, ptr %l33, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb11
bb11:
  %t38 = load i1, ptr %l7, !tbaa !21
  store i1 %t38, ptr %l37, !tbaa !21
  %t39 = load i1, ptr %l37, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  store i32 65542, ptr %l38, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i32, ptr %l38, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t41 = load i64, ptr %l2, !tbaa !24
  store i64 %t41, ptr %l39, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t42, ptr %l40, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  store i64 %t44, ptr %l41, !tbaa !24
  %t45 = load i64, ptr %l41, !tbaa !24
  %t46 = add i64 %t45, 1
  store i64 %t46, ptr %l42, !tbaa !24
  %t47 = load i64, ptr %l39, !tbaa !24
  %t48 = load i64, ptr %l42, !tbaa !24
  %t49 = add i64 %t47, %t48
  store i64 %t49, ptr %l43, !tbaa !24
  %t50 = load i64, ptr %l43, !tbaa !24
  store i64 %t50, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l44, !tbaa !24
  %t52 = load i64, ptr %l44, !tbaa !24
  %t53 = add i64 %t52, 1
  store i64 %t53, ptr %l45, !tbaa !24
  %t54 = load i64, ptr %l45, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb4
bb16:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %l8, !tbaa !21
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l47, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t57 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t56, i8 0)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l49
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb18, label %ok.61
ok.61:
  store i64 %t58, ptr %l48
  br label %bb17
bb17:
  %t62 = load i64, ptr %l48, !tbaa !24
  store i64 %t62, ptr %l46, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s7
  store i1 false, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb20
bb20:
  %t63 = load i1, ptr %l8, !tbaa !21
  store i1 %t63, ptr %l50, !tbaa !21
  %t64 = load i1, ptr %l50, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 65542, ptr %l51, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t65 = load i32, ptr %l51, !tbaa !23
  store i32 %t65, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t66 = load i64, ptr %l2, !tbaa !24
  store i64 %t66, ptr %l52, !tbaa !24
  %t67 = load i64, ptr %l52, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  store i1 %t68, ptr %l53, !tbaa !21
  %t69 = load i1, ptr %l53, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  %t70 = load i64, ptr %l52, !tbaa !24
  %t71 = mul i64 %t70, 1
  %t72 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l54, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t75, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s9
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l55, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t77, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t78, ptr %l56, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l57, !tbaa !24
  %t81 = load i64, ptr %l57, !tbaa !24
  store i64 %t81, ptr %l13, !tbaa !24
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @.c6)
  unreachable
bb26:
  store %olang.scope zeroinitializer, ptr %s10
  %t82 = load i64, ptr %l12, !tbaa !24
  store i64 %t82, ptr %l58, !tbaa !24
  %t83 = load i64, ptr %l13, !tbaa !24
  store i64 %t83, ptr %l59, !tbaa !24
  %t84 = load i64, ptr %l58, !tbaa !24
  %t85 = load i64, ptr %l59, !tbaa !24
  %t86 = icmp slt i64 %t84, %t85
  store i1 %t86, ptr %l60, !tbaa !21
  %t87 = load i1, ptr %l60, !tbaa !21
  %t88 = xor i1 %t87, true
  store i1 %t88, ptr %l61, !tbaa !21
  %t89 = load i1, ptr %l61, !tbaa !21
  br i1 %t89, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s10)
  br label %bb37
bb28:
  br label %bb29
bb29:
  %t90 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t90, ptr %l62, !tbaa !27
  %t91 = load i64, ptr %l12, !tbaa !24
  store i64 %t91, ptr %l63, !tbaa !24
  %t92 = load i64, ptr %l63, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %t94, i64 %t92
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !37
  store { i64, ptr } %t96, ptr %l64, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t97, ptr %l14, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s11
  %t98 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t98, ptr %l65, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t99, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t100, ptr %l66, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l67, !tbaa !24
  %t103 = load i64, ptr %l67, !tbaa !24
  store i64 %t103, ptr %l17, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s12
  %t104 = load i64, ptr %l16, !tbaa !24
  store i64 %t104, ptr %l68, !tbaa !24
  %t105 = load i64, ptr %l17, !tbaa !24
  store i64 %t105, ptr %l69, !tbaa !24
  %t106 = load i64, ptr %l68, !tbaa !24
  %t107 = load i64, ptr %l69, !tbaa !24
  %t108 = icmp slt i64 %t106, %t107
  store i1 %t108, ptr %l70, !tbaa !21
  %t109 = load i1, ptr %l70, !tbaa !21
  %t110 = xor i1 %t109, true
  store i1 %t110, ptr %l71, !tbaa !21
  %t111 = load i1, ptr %l71, !tbaa !21
  br i1 %t111, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s12)
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t112 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t112, ptr %l72, !tbaa !27
  %t113 = load i64, ptr %l16, !tbaa !24
  store i64 %t113, ptr %l73, !tbaa !24
  %t114 = load i64, ptr %l73, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i8, ptr %t116, i64 %t114
  %t118 = load i8, ptr %t117, !tbaa !32
  store i8 %t118, ptr %l74, !tbaa !22
  %t119 = load i8, ptr %l74, !tbaa !22
  store i8 %t119, ptr %l18, !tbaa !22
  %t120 = load i64, ptr %l10, !tbaa !24
  store i64 %t120, ptr %l75, !tbaa !24
  %t121 = load i8, ptr %l18, !tbaa !22
  store i8 %t121, ptr %l76, !tbaa !22
  %t122 = load i8, ptr %l76, !tbaa !22
  store i8 %t122, ptr %l77, !tbaa !22
  %t123 = load i8, ptr %l77, !tbaa !22
  %t124 = load i64, ptr %l75, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i8, ptr %t126, i64 %t124
  store i8 %t123, ptr %t127, !tbaa !32
  %t128 = load i64, ptr %l10, !tbaa !24
  store i64 %t128, ptr %l78, !tbaa !24
  %t129 = load i64, ptr %l78, !tbaa !24
  %t130 = add i64 %t129, 1
  store i64 %t130, ptr %l79, !tbaa !24
  %t131 = load i64, ptr %l79, !tbaa !24
  store i64 %t131, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s13
  %t132 = load i64, ptr %l16, !tbaa !24
  store i64 %t132, ptr %l80, !tbaa !24
  %t133 = load i64, ptr %l80, !tbaa !24
  %t134 = add i64 %t133, 1
  store i64 %t134, ptr %l81, !tbaa !24
  %t135 = load i64, ptr %l81, !tbaa !24
  store i64 %t135, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb30
bb35:
  call void @__olang_scope_close(ptr %s11)
  %t136 = load i64, ptr %l10, !tbaa !24
  store i64 %t136, ptr %l82, !tbaa !24
  %t137 = load i64, ptr %l82, !tbaa !24
  %t138 = add i64 %t137, 1
  store i64 %t138, ptr %l83, !tbaa !24
  %t139 = load i64, ptr %l83, !tbaa !24
  store i64 %t139, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s14
  %t140 = load i64, ptr %l12, !tbaa !24
  store i64 %t140, ptr %l84, !tbaa !24
  %t141 = load i64, ptr %l84, !tbaa !24
  %t142 = add i64 %t141, 1
  store i64 %t142, ptr %l85, !tbaa !24
  %t143 = load i64, ptr %l85, !tbaa !24
  store i64 %t143, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb26
bb37:
  call void @__olang_scope_close(ptr %s9)
  %t144 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t144, ptr %l86, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s15
  store ptr %s15room, ptr %s15
  %t145 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  call void @__olang_sb_put(ptr %s15, ptr %t146, i64 %t147)
  %t148 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t148, i64 %t149)
  %t150 = load ptr, ptr %s15
  %t151 = getelementptr %olang.builder, ptr %s15, i32 0, i32 1
  %t152 = load i64, ptr %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t150, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l87, !tbaa !27
  call void @__olang_sb_done(ptr %s15)
  %t156 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t156, ptr %l88, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t157, ptr %l89, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t158, ptr %l90, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l91, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t164 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = load i64, ptr %l91, !tbaa !24
  %t168 = call i32 @__olang_exec(ptr %t162, ptr %t165, i64 %t167)
  store i32 %t168, ptr %l92
  br label %bb38
bb38:
  %t169 = call i32 @__olang_err()
  store i32 %t169, ptr %l93
  br label %bb39
bb39:
  %t170 = load i32, ptr %l93, !tbaa !23
  %t171 = call i32 @std_2fos_2eraise(i32 %t170)
  store i32 %t171, ptr %l94
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb41, label %ok.173
ok.173:
  br label %bb40
bb40:
  br label %bb42
bb41:
  %t174 = load i32, ptr %l94, !tbaa !23
  %t175 = lshr i32 %t174, 16
  %t176 = and i32 %t174, 65535
  %t177 = icmp eq i32 %t175, 1
  %t178 = select i1 %t177, i32 1, i32 0
  %t179 = icmp eq i32 %t174, 0
  %t180 = shl i32 %t178, 16
  %t181 = or i32 %t180, %t176
  %t182 = select i1 %t179, i32 0, i32 %t181
  store i32 %t182, ptr %l95, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t183 = load i32, ptr %l95, !tbaa !23
  store i32 %t183, ptr %rv
  br label %ret
bb42:
  store i32 65542, ptr %l96, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t184 = load i32, ptr %l96, !tbaa !23
  store i32 %t184, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca [3 x i64]
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store [3 x i64] zeroinitializer, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  store ptr %l1, ptr %l5
  %t14 = load ptr, ptr %l5
  %t15 = insertvalue { i64, ptr } undef, i64 3, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t17, ptr %l7, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = call i32 @__olang_stat(ptr %t19, ptr %t22)
  store i32 %t24, ptr %l8
  br label %bb1
bb1:
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = icmp eq i32 %t25, 0
  store i1 %t26, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i1, ptr %l9, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @std_2fos_2eExit(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %s0 = alloca %olang.scope
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l1, !tbaa !23
  call void @exit(i32 %t2)
  unreachable
bb1:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
ret:
  ret void
}

define dso_local i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca [3 x i64]
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store [3 x i64] zeroinitializer, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  store ptr %l1, ptr %l5
  %t14 = load ptr, ptr %l5
  %t15 = insertvalue { i64, ptr } undef, i64 3, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t17, ptr %l7, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = call i32 @__olang_stat(ptr %t19, ptr %t22)
  store i32 %t24, ptr %l8
  br label %bb1
bb1:
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = icmp eq i32 %t25, 0
  store i1 %t26, ptr %l9, !tbaa !21
  %t27 = load i1, ptr %l9, !tbaa !21
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t28 = getelementptr [3 x i64], ptr %l1, i64 0, i64 0
  %t29 = load i64, ptr %t28, !tbaa !34
  store i64 %t29, ptr %l11, !tbaa !24
  %t30 = load i64, ptr %l11, !tbaa !24
  %t31 = icmp eq i64 %t30, 2
  store i1 %t31, ptr %l12, !tbaa !21
  %t32 = load i1, ptr %l12, !tbaa !21
  store i1 %t32, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i1, ptr %l10, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fos_2eIsTerminal(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l1, !tbaa !23
  %t3 = call i32 @isatty(i32 %t2)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t4, 1
  store i1 %t5, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i1, ptr %l3, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i8
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l58 = alloca i1
  %l59 = alloca i32
  %l60 = alloca i32
  %l61 = alloca i1
  %l62 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i32
  %l65 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i32
  %l69 = alloca i64
  %l70 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l9, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t2)
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 1, ptr %l1, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l11, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l12, !tbaa !24
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = add i64 %t8, 1
  store i64 %t9, ptr %l13, !tbaa !24
  %t10 = load i64, ptr %l13, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l14, !tbaa !24
  %t12 = load i64, ptr %l1, !tbaa !24
  store i64 %t12, ptr %l15, !tbaa !24
  %t13 = load i64, ptr %l14, !tbaa !24
  %t14 = load i64, ptr %l15, !tbaa !24
  %t15 = icmp sgt i64 %t13, %t14
  store i1 %t15, ptr %l16, !tbaa !21
  %t16 = load i1, ptr %l16, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l18, !tbaa !24
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = icmp sgt i64 %t18, 0
  store i1 %t19, ptr %l19, !tbaa !21
  %t20 = load i1, ptr %l19, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb10
bb7:
  %t21 = load i64, ptr %l2, !tbaa !24
  store i64 %t21, ptr %l21, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  store i64 %t22, ptr %l22, !tbaa !24
  %t23 = load i64, ptr %l21, !tbaa !24
  %t24 = load i64, ptr %l22, !tbaa !24
  %t25 = sub i64 %t23, %t24
  store i64 %t25, ptr %l23, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l24, !tbaa !24
  %t27 = load i64, ptr %l23, !tbaa !24
  %t28 = load i64, ptr %l24, !tbaa !24
  %t29 = add i64 %t27, %t28
  store i64 %t29, ptr %l25, !tbaa !24
  %t30 = load i64, ptr %l25, !tbaa !24
  %t31 = sub i64 %t30, 1
  store i64 %t31, ptr %l26, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  store i64 %t32, ptr %l27, !tbaa !24
  %t33 = load i64, ptr %l26, !tbaa !24
  %t34 = load i64, ptr %l27, !tbaa !24
  %t35 = sdiv i64 %t33, %t34
  store i64 %t35, ptr %l28, !tbaa !24
  %t36 = load i64, ptr %l28, !tbaa !24
  store i64 %t36, ptr %l20, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l20, !tbaa !24
  store i64 %t37, ptr %l17, !tbaa !24
  br label %bb10
bb10:
  %t38 = load i64, ptr %l17, !tbaa !24
  store i64 %t38, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l5, !tbaa !24
  store i64 %t39, ptr %l29, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  store i64 %t40, ptr %l30, !tbaa !24
  %t41 = load i64, ptr %l29, !tbaa !24
  %t42 = load i64, ptr %l30, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  store i1 %t43, ptr %l31, !tbaa !21
  %t44 = load i1, ptr %l31, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l32, !tbaa !21
  %t46 = load i1, ptr %l32, !tbaa !21
  br i1 %t46, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l1, !tbaa !24
  store i64 %t47, ptr %l33, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  store i64 %t48, ptr %l34, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  store i64 %t49, ptr %l35, !tbaa !24
  %t50 = load i64, ptr %l34, !tbaa !24
  %t51 = load i64, ptr %l35, !tbaa !24
  %t52 = mul i64 %t50, %t51
  store i64 %t52, ptr %l36, !tbaa !24
  %t53 = load i64, ptr %l33, !tbaa !24
  %t54 = load i64, ptr %l36, !tbaa !24
  %t55 = add i64 %t53, %t54
  store i64 %t55, ptr %l37, !tbaa !24
  %t56 = load i64, ptr %l37, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  store i64 %t57, ptr %l38, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t58, ptr %l39, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l40, !tbaa !24
  %t61 = load i64, ptr %l38, !tbaa !24
  %t62 = load i64, ptr %l40, !tbaa !24
  %t63 = icmp slt i64 %t61, %t62
  store i1 %t63, ptr %l41, !tbaa !21
  %t64 = load i1, ptr %l41, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t65, ptr %l43, !tbaa !27
  %t66 = load i64, ptr %l6, !tbaa !24
  store i64 %t66, ptr %l44, !tbaa !24
  %t67 = load i64, ptr %l44, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i8, ptr %t69, i64 %t67
  %t71 = load i8, ptr %t70, !tbaa !32
  store i8 %t71, ptr %l45, !tbaa !22
  %t72 = load i8, ptr %l45, !tbaa !22
  %t73 = icmp ne i8 %t72, 47
  store i1 %t73, ptr %l46, !tbaa !21
  %t74 = load i1, ptr %l46, !tbaa !21
  store i1 %t74, ptr %l42, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t75 = load i1, ptr %l42, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb19:
  br label %bb20
bb20:
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = load i64, ptr %l6, !tbaa !24
  store i64 %t77, ptr %l48, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l49, !tbaa !24
  %t80 = icmp sge i64 0, 0
  store i1 %t80, ptr %l50, !tbaa !21
  %t81 = load i1, ptr %l50, !tbaa !21
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t82 = load i64, ptr %l48, !tbaa !24
  %t83 = icmp sle i64 0, %t82
  store i1 %t83, ptr %l51, !tbaa !21
  %t84 = load i1, ptr %l51, !tbaa !21
  br i1 %t84, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb23:
  %t85 = load i64, ptr %l48, !tbaa !24
  %t86 = load i64, ptr %l49, !tbaa !24
  %t87 = icmp sle i64 %t85, %t86
  store i1 %t87, ptr %l52, !tbaa !21
  %t88 = load i1, ptr %l52, !tbaa !21
  br i1 %t88, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb25:
  %t89 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = load i64, ptr %l48, !tbaa !24
  %t92 = getelementptr i8, ptr %t90, i64 0
  %t93 = sub i64 %t91, 0
  %t94 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  store { i64, ptr } %t95, ptr %l53, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t96, ptr %l7, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t97, ptr %l54, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t98 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  call void @__olang_sb_put(ptr %s5, ptr %t99, i64 %t100)
  %t101 = extractvalue { i64, ptr } { i64 1, ptr @.d12 }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr @.d12 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t101, i64 %t102)
  %t103 = load ptr, ptr %s5
  %t104 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t105 = load i64, ptr %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t103, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l55, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  %t109 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t109, ptr %l56, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 1
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t113 = call i32 @mkdir(ptr %t111, i32 511)
  store i32 %t113, ptr %l57
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb27:
  %t114 = load i32, ptr %l57, !tbaa !23
  %t115 = icmp ne i32 %t114, 0
  store i1 %t115, ptr %l58, !tbaa !21
  %t116 = load i1, ptr %l58, !tbaa !21
  br i1 %t116, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t117 = call i32 @__olang_err()
  store i32 %t117, ptr %l59
  br label %bb30
bb29:
  br label %bb41
bb30:
  %t118 = load i32, ptr %l59, !tbaa !23
  store i32 %t118, ptr %l8, !tbaa !23
  %t119 = load i32, ptr %l8, !tbaa !23
  store i32 %t119, ptr %l60, !tbaa !23
  %t120 = load i32, ptr %l60, !tbaa !23
  %t121 = icmp ne i32 %t120, 2
  store i1 %t121, ptr %l61, !tbaa !21
  %t122 = load i1, ptr %l61, !tbaa !21
  br i1 %t122, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t123 = load i32, ptr %l8, !tbaa !23
  store i32 %t123, ptr %l62, !tbaa !23
  %t124 = load i32, ptr %l62, !tbaa !23
  %t125 = call i32 @std_2fos_2eraise(i32 %t124)
  store i32 %t125, ptr %l63
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb34, label %ok.127
ok.127:
  br label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb35
bb34:
  %t128 = load i32, ptr %l63, !tbaa !23
  %t129 = lshr i32 %t128, 16
  %t130 = and i32 %t128, 65535
  %t131 = icmp eq i32 %t129, 1
  %t132 = select i1 %t131, i32 1, i32 0
  %t133 = icmp eq i32 %t128, 0
  %t134 = shl i32 %t132, 16
  %t135 = or i32 %t134, %t130
  %t136 = select i1 %t133, i32 0, i32 %t135
  store i32 %t136, ptr %l64, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t137 = load i32, ptr %l64, !tbaa !23
  store i32 %t137, ptr %rv
  br label %ret
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  %t138 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t138, ptr %l65, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t140 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t139)
  store i1 %t140, ptr %l66
  br label %bb37
bb37:
  %t141 = load i1, ptr %l66, !tbaa !21
  %t142 = xor i1 %t141, true
  store i1 %t142, ptr %l67, !tbaa !21
  %t143 = load i1, ptr %l67, !tbaa !21
  br i1 %t143, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 65539, ptr %l68, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t144 = load i32, ptr %l68, !tbaa !23
  store i32 %t144, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s9
  %t145 = load i64, ptr %l5, !tbaa !24
  store i64 %t145, ptr %l69, !tbaa !24
  %t146 = load i64, ptr %l69, !tbaa !24
  %t147 = add i64 %t146, 1
  store i64 %t147, ptr %l70, !tbaa !24
  %t148 = load i64, ptr %l70, !tbaa !24
  store i64 %t148, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb11
bb43:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t2, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 1, ptr @.d13 }, ptr %l7, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t3, { i64, ptr } %t4)
  store i1 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i1, ptr %l8, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65542, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l9, !tbaa !23
  %t8 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t7, 0
  store { i32, { i64, ptr } } %t8, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l10, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t11 = call { i64, ptr } @std_2fos_2etempDir(ptr %v0, ptr %s0, { i64, ptr } %t10)
  store { i64, ptr } %t11, ptr %l11
  br label %bb5
bb5:
  %t12 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t13, ptr %l12, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 1, ptr @.d14 })
  store i1 %t15, ptr %l13
  br label %bb6
bb6:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 0, ptr @.d15 }, ptr %l14, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 1, ptr @.d16 }, ptr %l14, !tbaa !27
  br label %bb9
bb9:
  %t17 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l16, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l17, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t21 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  call void @__olang_sb_put(ptr %s2, ptr %t22, i64 %t23)
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  call void @__olang_sb_put(ptr %s2, ptr %t25, i64 %t26)
  %t27 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  call void @__olang_sb_put(ptr %s2, ptr %t28, i64 %t29)
  %t30 = extractvalue { i64, ptr } { i64 7, ptr @.d17 }, 1
  %t31 = extractvalue { i64, ptr } { i64 7, ptr @.d17 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t30, i64 %t31)
  %t32 = load ptr, ptr %s2
  %t33 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t34 = load i64, ptr %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t32, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l18, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t40 = extractvalue { i64, ptr } %t38, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l19, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l20, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t47, ptr %l21, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t48, ptr %l22, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = call i32 @__olang_mkdtemp(ptr %t50)
  store i32 %t52, ptr %l23
  br label %bb10
bb10:
  %t53 = load i32, ptr %l23, !tbaa !23
  %t54 = icmp ne i32 %t53, 0
  store i1 %t54, ptr %l24, !tbaa !21
  %t55 = load i1, ptr %l24, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = call i32 @__olang_err()
  store i32 %t56, ptr %l25
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t57 = load i32, ptr %l25, !tbaa !23
  %t58 = call i32 @std_2fos_2eraise(i32 %t57)
  store i32 %t58, ptr %l26
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb15, label %ok.60
ok.60:
  br label %bb14
bb14:
  br label %bb16
bb15:
  %t61 = load i32, ptr %l26, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 1, i32 0
  %t66 = icmp eq i32 %t61, 0
  %t67 = shl i32 %t65, 16
  %t68 = or i32 %t67, %t63
  %t69 = select i1 %t66, i32 0, i32 %t68
  store i32 %t69, ptr %l27, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t70 = load i32, ptr %l27, !tbaa !23
  %t71 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t70, 0
  store { i32, { i64, ptr } } %t71, ptr %rv
  br label %ret
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t72, ptr %l28, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t73, ptr %l29, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l30, !tbaa !24
  %t76 = load i64, ptr %l30, !tbaa !24
  %t77 = sub i64 %t76, 1
  store i64 %t77, ptr %l31, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l32, !tbaa !24
  %t80 = icmp sge i64 0, 0
  store i1 %t80, ptr %l33, !tbaa !21
  %t81 = load i1, ptr %l33, !tbaa !21
  br i1 %t81, label %bb18, label %bb19
bb18:
  %t82 = load i64, ptr %l31, !tbaa !24
  %t83 = icmp sle i64 0, %t82
  store i1 %t83, ptr %l34, !tbaa !21
  %t84 = load i1, ptr %l34, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb20:
  %t85 = load i64, ptr %l31, !tbaa !24
  %t86 = load i64, ptr %l32, !tbaa !24
  %t87 = icmp sle i64 %t85, %t86
  store i1 %t87, ptr %l35, !tbaa !21
  %t88 = load i1, ptr %l35, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb22:
  %t89 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = load i64, ptr %l31, !tbaa !24
  %t92 = getelementptr i8, ptr %t90, i64 0
  %t93 = sub i64 %t91, 0
  %t94 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  store { i64, ptr } %t95, ptr %l36, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t96 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t97 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t96, 1
  store { i32, { i64, ptr } } %t97, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @std_2fos_2eOnCrash(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t3, ptr %l3, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = load i64, ptr %l5, !tbaa !24
  call void @__olang_on_crash(ptr %t8, i64 %t10)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { ptr, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { ptr, ptr }
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t17 = alloca { { i64, ptr }, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l4, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d19 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l5, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t13, ptr %l1, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t14, ptr %l7, !tbaa !27
  %t15 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t16 = ptrtoint ptr %t15 to i64
  %t18 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t19 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !28
  %t20 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 1
  store ptr %s0, ptr %t20, !tbaa !28
  %t21 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_20, 0
  %t22 = insertvalue { ptr, ptr } %t21, ptr %t17, 1
  store { ptr, ptr } %t22, ptr %l8
  %t23 = load { ptr, ptr }, ptr %l8
  %t24 = extractvalue { ptr, ptr } %t23, 0
  %t25 = extractvalue { ptr, ptr } %t23, 1
  %t26 = call { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %s0, ptr %v1, ptr %t24, ptr %t25)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l10
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb2, label %ok.30
ok.30:
  store { i64, ptr } %t27, ptr %l9
  br label %bb1
bb1:
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  br label %bb3
bb2:
  %t32 = load i32, ptr %l10, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 1, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  store i32 %t40, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i32, ptr %l11, !tbaa !23
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t41, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb3:
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t44, ptr %l12, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l13, !tbaa !24
  %t47 = load i64, ptr %l13, !tbaa !24
  %t48 = icmp eq i64 %t47, 0
  store i1 %t48, ptr %l14, !tbaa !21
  %t49 = load i1, ptr %l14, !tbaa !21
  br i1 %t49, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = icmp sge i64 0, 0
  store i1 %t50, ptr %l15, !tbaa !21
  %t51 = load i1, ptr %l15, !tbaa !21
  br i1 %t51, label %bb6, label %bb7
bb5:
  br label %bb10
bb6:
  %t52 = icmp sle i64 0, 576460752303423487
  store i1 %t52, ptr %l16, !tbaa !21
  %t53 = load i1, ptr %l16, !tbaa !21
  br i1 %t53, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb8:
  %t54 = mul i64 0, 16
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 0, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l17, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  %t60 = extractvalue { i64, ptr } %t58, 1
  %t61 = mul i64 %t59, 16
  %t62 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t65 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t66 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t65, 1
  store { i32, { i64, ptr } } %t66, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb10:
  %t67 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t67, ptr %l19, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l20, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l21, !tbaa !24
  %t71 = load i64, ptr %l21, !tbaa !24
  %t72 = sub i64 %t71, 1
  store i64 %t72, ptr %l22, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l23, !tbaa !24
  %t75 = icmp sge i64 0, 0
  store i1 %t75, ptr %l24, !tbaa !21
  %t76 = load i1, ptr %l24, !tbaa !21
  br i1 %t76, label %bb11, label %bb12
bb11:
  %t77 = load i64, ptr %l22, !tbaa !24
  %t78 = icmp sle i64 0, %t77
  store i1 %t78, ptr %l25, !tbaa !21
  %t79 = load i1, ptr %l25, !tbaa !21
  br i1 %t79, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c22)
  unreachable
bb13:
  %t80 = load i64, ptr %l22, !tbaa !24
  %t81 = load i64, ptr %l23, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  store i1 %t82, ptr %l26, !tbaa !21
  %t83 = load i1, ptr %l26, !tbaa !21
  br i1 %t83, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c22)
  unreachable
bb15:
  %t84 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l22, !tbaa !24
  %t87 = getelementptr i8, ptr %t85, i64 0
  %t88 = sub i64 %t86, 0
  %t89 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  store { i64, ptr } %t90, ptr %l27, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t92 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s0, { i64, ptr } %t91, { i64, ptr } { i64 1, ptr @.d23 })
  store { i64, ptr } %t92, ptr %l28
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c22)
  unreachable
bb17:
  %t93 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t93, ptr %l3, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t94, ptr %l29, !tbaa !27
  %t95 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_24, 0
  %t96 = insertvalue { ptr, ptr } %t95, ptr null, 1
  store { ptr, ptr } %t96, ptr %l30
  %t97 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t98 = load { ptr, ptr }, ptr %l30
  %t99 = extractvalue { ptr, ptr } %t98, 0
  %t100 = extractvalue { ptr, ptr } %t98, 1
  call void @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eSort_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v1, ptr %s0, { i64, ptr } %t97, ptr %t99, ptr %t100)
  br label %bb18
bb18:
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t101, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t102 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t103 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t102, 1
  store { i32, { i64, ptr } } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i1
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i8
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i32
  %l101 = alloca i32
  %l102 = alloca i32
  %l103 = alloca i32
  %l104 = alloca i64
  %l105 = alloca i1
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i32
  %l110 = alloca i32
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca i1
  %l117 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l13, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t2)
  store i1 %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load i1, ptr %l14, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65540, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t5 = load i32, ptr %l15, !tbaa !23
  %t6 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t5, 0
  store { i32, { i64, ptr } } %t6, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l16, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t8 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s2, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s2
  %t14 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t19 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = call i32 @open(ptr %t21, i32 0)
  store i32 %t23, ptr %l19
  br label %bb5
bb5:
  %t24 = load i32, ptr %l19, !tbaa !23
  store i32 %t24, ptr %l1, !tbaa !23
  %t25 = load i32, ptr %l1, !tbaa !23
  store i32 %t25, ptr %l20, !tbaa !23
  %t26 = load i32, ptr %l20, !tbaa !23
  %t27 = sext i32 %t26 to i64
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load i64, ptr %l21, !tbaa !24
  %t29 = call i32 @std_2fos_2echeck(i64 %t28)
  store i32 %t29, ptr %l22
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb7, label %ok.31
ok.31:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t32 = load i32, ptr %l22, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 1, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  store i32 %t40, ptr %l23, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t41, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb8:
  %t43 = load i32, ptr %l1, !tbaa !23
  store i32 %t43, ptr %l24, !tbaa !23
  %t44 = load i32, ptr %l24, !tbaa !23
  %t45 = call i64 @lseek(i32 %t44, i64 0, i32 2)
  store i64 %t45, ptr %l25
  br label %bb9
bb9:
  %t46 = load i64, ptr %l25, !tbaa !24
  store i64 %t46, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l26, !tbaa !24
  %t48 = load i64, ptr %l26, !tbaa !24
  %t49 = icmp slt i64 %t48, 0
  store i1 %t49, ptr %l27, !tbaa !21
  %t50 = load i1, ptr %l27, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  store i64 0, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t51 = load i32, ptr %l1, !tbaa !23
  store i32 %t51, ptr %l28, !tbaa !23
  %t52 = load i32, ptr %l28, !tbaa !23
  %t53 = call i64 @lseek(i32 %t52, i64 0, i32 0)
  store i64 %t53, ptr %l29
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t54 = load i64, ptr %l2, !tbaa !24
  store i64 %t54, ptr %l30, !tbaa !24
  %t55 = load i64, ptr %l30, !tbaa !24
  %t56 = add i64 %t55, 1
  store i64 %t56, ptr %l31, !tbaa !24
  %t57 = load i64, ptr %l31, !tbaa !24
  %t58 = icmp sge i64 %t57, 0
  store i1 %t58, ptr %l32, !tbaa !21
  %t59 = load i1, ptr %l32, !tbaa !21
  br i1 %t59, label %bb14, label %bb15
bb14:
  %t60 = load i64, ptr %l31, !tbaa !24
  %t61 = mul i64 %t60, 1
  %t62 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l33, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t65, ptr %l34, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l35, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t73, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t74 = load i64, ptr %l4, !tbaa !24
  store i64 %t74, ptr %l36, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t75, ptr %l37, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l38, !tbaa !24
  %t78 = load i64, ptr %l36, !tbaa !24
  %t79 = load i64, ptr %l38, !tbaa !24
  %t80 = icmp eq i64 %t78, %t79
  store i1 %t80, ptr %l39, !tbaa !21
  %t81 = load i1, ptr %l39, !tbaa !21
  br i1 %t81, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t82, ptr %l40, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l41, !tbaa !24
  %t85 = load i64, ptr %l41, !tbaa !24
  %t86 = mul i64 %t85, 2
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load i64, ptr %l42, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  store i1 %t88, ptr %l43, !tbaa !21
  %t89 = load i1, ptr %l43, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb18:
  br label %bb33
bb19:
  %t90 = load i64, ptr %l42, !tbaa !24
  %t91 = mul i64 %t90, 1
  %t92 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l44, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t95, ptr %l45, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = extractvalue { i64, ptr } %t96, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l46, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t103, ptr %l5, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s7
  store i64 0, ptr %l6, !tbaa !24
  %t104 = load i64, ptr %l4, !tbaa !24
  store i64 %t104, ptr %l47, !tbaa !24
  %t105 = load i64, ptr %l47, !tbaa !24
  store i64 %t105, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t106 = load i64, ptr %l7, !tbaa !24
  store i64 %t106, ptr %l48, !tbaa !24
  %t107 = load i64, ptr %l6, !tbaa !24
  store i64 %t107, ptr %l49, !tbaa !24
  %t108 = load i64, ptr %l48, !tbaa !24
  %t109 = load i64, ptr %l49, !tbaa !24
  %t110 = icmp sgt i64 %t108, %t109
  store i1 %t110, ptr %l50, !tbaa !21
  %t111 = load i1, ptr %l50, !tbaa !21
  br i1 %t111, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb21:
  %t112 = load i64, ptr %l8, !tbaa !24
  store i64 %t112, ptr %l52, !tbaa !24
  %t113 = load i64, ptr %l52, !tbaa !24
  %t114 = icmp sgt i64 %t113, 0
  store i1 %t114, ptr %l53, !tbaa !21
  %t115 = load i1, ptr %l53, !tbaa !21
  br i1 %t115, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb26
bb23:
  %t116 = load i64, ptr %l7, !tbaa !24
  store i64 %t116, ptr %l55, !tbaa !24
  %t117 = load i64, ptr %l6, !tbaa !24
  store i64 %t117, ptr %l56, !tbaa !24
  %t118 = load i64, ptr %l55, !tbaa !24
  %t119 = load i64, ptr %l56, !tbaa !24
  %t120 = sub i64 %t118, %t119
  store i64 %t120, ptr %l57, !tbaa !24
  %t121 = load i64, ptr %l8, !tbaa !24
  store i64 %t121, ptr %l58, !tbaa !24
  %t122 = load i64, ptr %l57, !tbaa !24
  %t123 = load i64, ptr %l58, !tbaa !24
  %t124 = add i64 %t122, %t123
  store i64 %t124, ptr %l59, !tbaa !24
  %t125 = load i64, ptr %l59, !tbaa !24
  %t126 = sub i64 %t125, 1
  store i64 %t126, ptr %l60, !tbaa !24
  %t127 = load i64, ptr %l8, !tbaa !24
  store i64 %t127, ptr %l61, !tbaa !24
  %t128 = load i64, ptr %l60, !tbaa !24
  %t129 = load i64, ptr %l61, !tbaa !24
  %t130 = sdiv i64 %t128, %t129
  store i64 %t130, ptr %l62, !tbaa !24
  %t131 = load i64, ptr %l62, !tbaa !24
  store i64 %t131, ptr %l54, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb25
bb25:
  %t132 = load i64, ptr %l54, !tbaa !24
  store i64 %t132, ptr %l51, !tbaa !24
  br label %bb26
bb26:
  %t133 = load i64, ptr %l51, !tbaa !24
  store i64 %t133, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  %t134 = load i64, ptr %l10, !tbaa !24
  store i64 %t134, ptr %l63, !tbaa !24
  %t135 = load i64, ptr %l9, !tbaa !24
  store i64 %t135, ptr %l64, !tbaa !24
  %t136 = load i64, ptr %l63, !tbaa !24
  %t137 = load i64, ptr %l64, !tbaa !24
  %t138 = icmp slt i64 %t136, %t137
  store i1 %t138, ptr %l65, !tbaa !21
  %t139 = load i1, ptr %l65, !tbaa !21
  %t140 = xor i1 %t139, true
  store i1 %t140, ptr %l66, !tbaa !21
  %t141 = load i1, ptr %l66, !tbaa !21
  br i1 %t141, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s8)
  br label %bb32
bb29:
  br label %bb30
bb30:
  %t142 = load i64, ptr %l6, !tbaa !24
  store i64 %t142, ptr %l67, !tbaa !24
  %t143 = load i64, ptr %l10, !tbaa !24
  store i64 %t143, ptr %l68, !tbaa !24
  %t144 = load i64, ptr %l8, !tbaa !24
  store i64 %t144, ptr %l69, !tbaa !24
  %t145 = load i64, ptr %l68, !tbaa !24
  %t146 = load i64, ptr %l69, !tbaa !24
  %t147 = mul i64 %t145, %t146
  store i64 %t147, ptr %l70, !tbaa !24
  %t148 = load i64, ptr %l67, !tbaa !24
  %t149 = load i64, ptr %l70, !tbaa !24
  %t150 = add i64 %t148, %t149
  store i64 %t150, ptr %l71, !tbaa !24
  %t151 = load i64, ptr %l71, !tbaa !24
  store i64 %t151, ptr %l11, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t152, ptr %l72, !tbaa !27
  %t153 = load i64, ptr %l11, !tbaa !24
  store i64 %t153, ptr %l73, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t154, ptr %l74, !tbaa !27
  %t155 = load i64, ptr %l11, !tbaa !24
  store i64 %t155, ptr %l75, !tbaa !24
  %t156 = load i64, ptr %l75, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i8, ptr %t158, i64 %t156
  %t160 = load i8, ptr %t159, !tbaa !32
  store i8 %t160, ptr %l76, !tbaa !22
  %t161 = load i8, ptr %l76, !tbaa !22
  %t162 = load i64, ptr %l73, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i8, ptr %t164, i64 %t162
  store i8 %t161, ptr %t165, !tbaa !32
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t166 = load i64, ptr %l10, !tbaa !24
  store i64 %t166, ptr %l77, !tbaa !24
  %t167 = load i64, ptr %l77, !tbaa !24
  %t168 = add i64 %t167, 1
  store i64 %t168, ptr %l78, !tbaa !24
  %t169 = load i64, ptr %l78, !tbaa !24
  store i64 %t169, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb27
bb32:
  call void @__olang_scope_close(ptr %s7)
  %t170 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t170, ptr %l79, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t171, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  %t172 = load i32, ptr %l1, !tbaa !23
  store i32 %t172, ptr %l80, !tbaa !23
  %t173 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t173, ptr %l81, !tbaa !27
  %t174 = load i64, ptr %l4, !tbaa !24
  store i64 %t174, ptr %l82, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t175, ptr %l83, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t176, ptr %l84, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  store i64 %t178, ptr %l85, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l86, !tbaa !24
  %t181 = load i64, ptr %l82, !tbaa !24
  %t182 = icmp sge i64 %t181, 0
  store i1 %t182, ptr %l87, !tbaa !21
  %t183 = load i1, ptr %l87, !tbaa !21
  br i1 %t183, label %bb34, label %bb35
bb34:
  %t184 = load i64, ptr %l82, !tbaa !24
  %t185 = load i64, ptr %l85, !tbaa !24
  %t186 = icmp sle i64 %t184, %t185
  store i1 %t186, ptr %l88, !tbaa !21
  %t187 = load i1, ptr %l88, !tbaa !21
  br i1 %t187, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb36:
  %t188 = load i64, ptr %l85, !tbaa !24
  %t189 = load i64, ptr %l86, !tbaa !24
  %t190 = icmp sle i64 %t188, %t189
  store i1 %t190, ptr %l89, !tbaa !21
  %t191 = load i1, ptr %l89, !tbaa !21
  br i1 %t191, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb38:
  %t192 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l82, !tbaa !24
  %t195 = load i64, ptr %l85, !tbaa !24
  %t196 = getelementptr i8, ptr %t193, i64 %t194
  %t197 = sub i64 %t195, %t194
  %t198 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t196, 1
  store { i64, ptr } %t199, ptr %l90, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t200, ptr %l91, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t201, ptr %l92, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t202, ptr %l93, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  store i64 %t204, ptr %l94, !tbaa !24
  %t205 = load i64, ptr %l4, !tbaa !24
  store i64 %t205, ptr %l95, !tbaa !24
  %t206 = load i64, ptr %l94, !tbaa !24
  %t207 = load i64, ptr %l95, !tbaa !24
  %t208 = sub i64 %t206, %t207
  store i64 %t208, ptr %l96, !tbaa !24
  %t209 = load i32, ptr %l80, !tbaa !23
  %t210 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = load i64, ptr %l96, !tbaa !24
  %t214 = call i64 @read(i32 %t209, ptr %t211, i64 %t213)
  store i64 %t214, ptr %l97
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb40:
  %t215 = load i64, ptr %l97, !tbaa !24
  store i64 %t215, ptr %l12, !tbaa !24
  %t216 = load i64, ptr %l12, !tbaa !24
  store i64 %t216, ptr %l98, !tbaa !24
  %t217 = load i64, ptr %l98, !tbaa !24
  %t218 = icmp slt i64 %t217, 0
  store i1 %t218, ptr %l99, !tbaa !21
  %t219 = load i1, ptr %l99, !tbaa !21
  br i1 %t219, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s10
  %t220 = load i32, ptr %l1, !tbaa !23
  store i32 %t220, ptr %l100, !tbaa !23
  %t221 = call i32 @__olang_err()
  store i32 %t221, ptr %l101
  br label %bb43
bb42:
  br label %bb47
bb43:
  %t222 = load i32, ptr %l100, !tbaa !23
  %t223 = load i32, ptr %l101, !tbaa !23
  %t224 = call i32 @std_2fos_2ecloseAndRaise(i32 %t222, i32 %t223)
  store i32 %t224, ptr %l102
  %t225 = icmp ne i32 %t224, 0
  br i1 %t225, label %bb45, label %ok.226
ok.226:
  br label %bb44
bb44:
  br label %bb46
bb45:
  %t227 = load i32, ptr %l102, !tbaa !23
  %t228 = lshr i32 %t227, 16
  %t229 = and i32 %t227, 65535
  %t230 = icmp eq i32 %t228, 1
  %t231 = select i1 %t230, i32 1, i32 0
  %t232 = icmp eq i32 %t227, 0
  %t233 = shl i32 %t231, 16
  %t234 = or i32 %t233, %t229
  %t235 = select i1 %t232, i32 0, i32 %t234
  store i32 %t235, ptr %l103, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t236 = load i32, ptr %l103, !tbaa !23
  %t237 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t236, 0
  store { i32, { i64, ptr } } %t237, ptr %rv
  br label %ret
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb47:
  %t238 = load i64, ptr %l12, !tbaa !24
  store i64 %t238, ptr %l104, !tbaa !24
  %t239 = load i64, ptr %l104, !tbaa !24
  %t240 = icmp eq i64 %t239, 0
  store i1 %t240, ptr %l105, !tbaa !21
  %t241 = load i1, ptr %l105, !tbaa !21
  br i1 %t241, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s11
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb49:
  br label %bb50
bb50:
  %t242 = load i64, ptr %l4, !tbaa !24
  store i64 %t242, ptr %l106, !tbaa !24
  %t243 = load i64, ptr %l12, !tbaa !24
  store i64 %t243, ptr %l107, !tbaa !24
  %t244 = load i64, ptr %l106, !tbaa !24
  %t245 = load i64, ptr %l107, !tbaa !24
  %t246 = add i64 %t244, %t245
  store i64 %t246, ptr %l108, !tbaa !24
  %t247 = load i64, ptr %l108, !tbaa !24
  store i64 %t247, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb51:
  br label %bb16
bb52:
  %t248 = load i32, ptr %l1, !tbaa !23
  store i32 %t248, ptr %l109, !tbaa !23
  %t249 = load i32, ptr %l109, !tbaa !23
  %t250 = call i32 @close(i32 %t249)
  store i32 %t250, ptr %l110
  br label %bb53
bb53:
  %t251 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t251, ptr %l111, !tbaa !27
  %t252 = load i64, ptr %l4, !tbaa !24
  store i64 %t252, ptr %l112, !tbaa !24
  %t253 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  store i64 %t254, ptr %l113, !tbaa !24
  %t255 = icmp sge i64 0, 0
  store i1 %t255, ptr %l114, !tbaa !21
  %t256 = load i1, ptr %l114, !tbaa !21
  br i1 %t256, label %bb54, label %bb55
bb54:
  %t257 = load i64, ptr %l112, !tbaa !24
  %t258 = icmp sle i64 0, %t257
  store i1 %t258, ptr %l115, !tbaa !21
  %t259 = load i1, ptr %l115, !tbaa !21
  br i1 %t259, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb56:
  %t260 = load i64, ptr %l112, !tbaa !24
  %t261 = load i64, ptr %l113, !tbaa !24
  %t262 = icmp sle i64 %t260, %t261
  store i1 %t262, ptr %l116, !tbaa !21
  %t263 = load i1, ptr %l116, !tbaa !21
  br i1 %t263, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb58:
  %t264 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = load i64, ptr %l112, !tbaa !24
  %t267 = getelementptr i8, ptr %t265, i64 0
  %t268 = sub i64 %t266, 0
  %t269 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t267, 1
  store { i64, ptr } %t270, ptr %l117, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t271 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t272 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t271, 1
  store { i32, { i64, ptr } } %t272, ptr %rv
  br label %ret
bb59:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d30 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t13, ptr %l1, !tbaa !27
  store i64 256, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  store i1 %t16, ptr %l8, !tbaa !21
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l9, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t30, ptr %l3, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t31, ptr %l11, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t32, ptr %l12, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l13, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t34, ptr %l14, !tbaa !27
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l15, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = load i64, ptr %l15, !tbaa !24
  %t43 = call i64 @readlink(ptr %t37, ptr %t40, i64 %t42)
  store i64 %t43, ptr %l16
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @.c31)
  unreachable
bb3:
  %t44 = load i64, ptr %l16, !tbaa !24
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l4, !tbaa !24
  store i64 %t45, ptr %l17, !tbaa !24
  %t46 = load i64, ptr %l2, !tbaa !24
  store i64 %t46, ptr %l18, !tbaa !24
  %t47 = load i64, ptr %l17, !tbaa !24
  %t48 = load i64, ptr %l18, !tbaa !24
  %t49 = icmp eq i64 %t47, %t48
  store i1 %t49, ptr %l19, !tbaa !21
  %t50 = load i1, ptr %l19, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l20, !tbaa !21
  %t52 = load i1, ptr %l20, !tbaa !21
  br i1 %t52, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb6:
  br label %bb7
bb7:
  %t53 = load i64, ptr %l2, !tbaa !24
  store i64 %t53, ptr %l21, !tbaa !24
  %t54 = load i64, ptr %l21, !tbaa !24
  %t55 = mul i64 %t54, 2
  store i64 %t55, ptr %l22, !tbaa !24
  %t56 = load i64, ptr %l22, !tbaa !24
  store i64 %t56, ptr %l2, !tbaa !24
  %t57 = load i64, ptr %l2, !tbaa !24
  store i64 %t57, ptr %l23, !tbaa !24
  %t58 = load i64, ptr %l23, !tbaa !24
  %t59 = icmp sge i64 %t58, 0
  store i1 %t59, ptr %l24, !tbaa !21
  %t60 = load i1, ptr %l24, !tbaa !21
  br i1 %t60, label %bb8, label %bb9
bb8:
  %t61 = load i64, ptr %l23, !tbaa !24
  %t62 = mul i64 %t61, 1
  %t63 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l25, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t68 = extractvalue { i64, ptr } %t66, 1
  %t69 = mul i64 %t67, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t68, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l26, !tbaa !27
  %t73 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t73, ptr %l3, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t74, ptr %l27, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t75, ptr %l28, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t76, ptr %l29, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t77, ptr %l30, !tbaa !27
  %t78 = load i64, ptr %l2, !tbaa !24
  store i64 %t78, ptr %l31, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = load i64, ptr %l31, !tbaa !24
  %t86 = call i64 @readlink(ptr %t80, ptr %t83, i64 %t85)
  store i64 %t86, ptr %l32
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @.c32)
  unreachable
bb10:
  %t87 = load i64, ptr %l32, !tbaa !24
  store i64 %t87, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %bb4
bb12:
  %t88 = load i64, ptr %l4, !tbaa !24
  store i64 %t88, ptr %l33, !tbaa !24
  %t89 = load i64, ptr %l33, !tbaa !24
  %t90 = call i32 @std_2fos_2echeck(i64 %t89)
  store i32 %t90, ptr %l34
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb14, label %ok.92
ok.92:
  br label %bb13
bb13:
  br label %bb15
bb14:
  %t93 = load i32, ptr %l34, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  store i32 %t101, ptr %l35, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t102 = load i32, ptr %l35, !tbaa !23
  %t103 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t102, 0
  store { i32, { i64, ptr } } %t103, ptr %rv
  br label %ret
bb15:
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t104, ptr %l36, !tbaa !27
  %t105 = load i64, ptr %l4, !tbaa !24
  store i64 %t105, ptr %l37, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l38, !tbaa !24
  %t108 = icmp sge i64 0, 0
  store i1 %t108, ptr %l39, !tbaa !21
  %t109 = load i1, ptr %l39, !tbaa !21
  br i1 %t109, label %bb16, label %bb17
bb16:
  %t110 = load i64, ptr %l37, !tbaa !24
  %t111 = icmp sle i64 0, %t110
  store i1 %t111, ptr %l40, !tbaa !21
  %t112 = load i1, ptr %l40, !tbaa !21
  br i1 %t112, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @.c33)
  unreachable
bb18:
  %t113 = load i64, ptr %l37, !tbaa !24
  %t114 = load i64, ptr %l38, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  store i1 %t115, ptr %l41, !tbaa !21
  %t116 = load i1, ptr %l41, !tbaa !21
  br i1 %t116, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c33)
  unreachable
bb20:
  %t117 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l37, !tbaa !24
  %t120 = getelementptr i8, ptr %t118, i64 0
  %t121 = sub i64 %t119, 0
  %t122 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t120, 1
  store { i64, ptr } %t123, ptr %l42, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t124, ptr %l43, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t125 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t126 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t125, 1
  store { i32, { i64, ptr } } %t126, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @.c33)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { ptr, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i32, { i64, ptr } }
  %t17 = alloca { { i64, ptr }, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t13, ptr %l1, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t14, ptr %l5, !tbaa !27
  %t15 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t16 = ptrtoint ptr %t15 to i64
  %t18 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t19 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !28
  %t20 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 1
  store ptr %s0, ptr %t20, !tbaa !28
  %t21 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_35, 0
  %t22 = insertvalue { ptr, ptr } %t21, ptr %t17, 1
  store { ptr, ptr } %t22, ptr %l6
  %t23 = load { ptr, ptr }, ptr %l6
  %t24 = extractvalue { ptr, ptr } %t23, 0
  %t25 = extractvalue { ptr, ptr } %t23, 1
  %t26 = call { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %s0, ptr %v1, ptr %t24, ptr %t25)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l8
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb2, label %ok.30
ok.30:
  store { i64, ptr } %t27, ptr %l7
  br label %bb1
bb1:
  %t31 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 1, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  store i32 %t40, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i32, ptr %l9, !tbaa !23
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t41, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t44 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t43, 1
  store { i32, { i64, ptr } } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t13, ptr %l3, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = call i32 @remove(ptr %t15)
  store i32 %t17, ptr %l4
  br label %bb1
bb1:
  %t18 = load i32, ptr %l4, !tbaa !23
  %t19 = sext i32 %t18 to i64
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t21 = call i32 @std_2fos_2echeck(i64 %t20)
  store i32 %t21, ptr %l6
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb3, label %ok.23
ok.23:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t24 = load i32, ptr %l6, !tbaa !23
  %t25 = lshr i32 %t24, 16
  %t26 = and i32 %t24, 65535
  %t27 = icmp eq i32 %t25, 1
  %t28 = select i1 %t27, i32 1, i32 0
  %t29 = icmp eq i32 %t24, 0
  %t30 = shl i32 %t28, 16
  %t31 = or i32 %t30, %t26
  %t32 = select i1 %t29, i32 0, i32 %t31
  store i32 %t32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i32, ptr %l7, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i8
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i8
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l45 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l4, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l5, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp sgt i64 %t6, 1
  store i1 %t7, ptr %l7, !tbaa !21
  %t8 = load i1, ptr %l7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load i64, ptr %l10, !tbaa !24
  %t12 = sub i64 %t11, 1
  store i64 %t12, ptr %l11, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t13
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l12, !tbaa !22
  %t18 = load i8, ptr %l12, !tbaa !22
  %t19 = icmp eq i8 %t18, 47
  store i1 %t19, ptr %l13, !tbaa !21
  %t20 = load i1, ptr %l13, !tbaa !21
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l8, !tbaa !21
  %t22 = xor i1 %t21, true
  store i1 %t22, ptr %l14, !tbaa !21
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l15, !tbaa !24
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = sub i64 %t25, 1
  store i64 %t26, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  store i64 %t27, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t28 = load i64, ptr %l1, !tbaa !24
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load i64, ptr %l2, !tbaa !24
  store i64 %t30, ptr %l18, !tbaa !24
  %t31 = load i64, ptr %l18, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  store i1 %t32, ptr %l19, !tbaa !21
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t34, ptr %l21, !tbaa !27
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = sub i64 %t36, 1
  store i64 %t37, ptr %l23, !tbaa !24
  %t38 = load i64, ptr %l23, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t38
  %t42 = load i8, ptr %t41, !tbaa !32
  store i8 %t42, ptr %l24, !tbaa !22
  %t43 = load i8, ptr %l24, !tbaa !22
  %t44 = icmp ne i8 %t43, 47
  store i1 %t44, ptr %l25, !tbaa !21
  %t45 = load i1, ptr %l25, !tbaa !21
  store i1 %t45, ptr %l20, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t46 = load i1, ptr %l20, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l26, !tbaa !21
  %t48 = load i1, ptr %l26, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t49 = load i64, ptr %l2, !tbaa !24
  store i64 %t49, ptr %l27, !tbaa !24
  %t50 = load i64, ptr %l27, !tbaa !24
  %t51 = sub i64 %t50, 1
  store i64 %t51, ptr %l28, !tbaa !24
  %t52 = load i64, ptr %l28, !tbaa !24
  store i64 %t52, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb10
bb18:
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l29, !tbaa !27
  %t54 = load i64, ptr %l2, !tbaa !24
  store i64 %t54, ptr %l30, !tbaa !24
  %t55 = load i64, ptr %l1, !tbaa !24
  store i64 %t55, ptr %l31, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l32, !tbaa !24
  %t58 = load i64, ptr %l30, !tbaa !24
  %t59 = icmp sge i64 %t58, 0
  store i1 %t59, ptr %l33, !tbaa !21
  %t60 = load i1, ptr %l33, !tbaa !21
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = load i64, ptr %l31, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  store i1 %t63, ptr %l34, !tbaa !21
  %t64 = load i1, ptr %l34, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @.c37)
  unreachable
bb21:
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = load i64, ptr %l32, !tbaa !24
  %t67 = icmp sle i64 %t65, %t66
  store i1 %t67, ptr %l35, !tbaa !21
  %t68 = load i1, ptr %l35, !tbaa !21
  br i1 %t68, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c37)
  unreachable
bb23:
  %t69 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l30, !tbaa !24
  %t72 = load i64, ptr %l31, !tbaa !24
  %t73 = getelementptr i8, ptr %t70, i64 %t71
  %t74 = sub i64 %t72, %t71
  %t75 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t73, 1
  store { i64, ptr } %t76, ptr %l36, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t77, ptr %l3, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t78, ptr %l37, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t79, { i64, ptr } { i64 1, ptr @.d38 })
  store i1 %t80, ptr %l38
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @.c37)
  unreachable
bb25:
  %t81 = load i1, ptr %l38, !tbaa !21
  br i1 %t81, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb29
bb27:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t82, ptr %l40, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t83, { i64, ptr } { i64 2, ptr @.d39 })
  store i1 %t84, ptr %l41
  br label %bb28
bb28:
  %t85 = load i1, ptr %l41, !tbaa !21
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb29
bb29:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 65542, ptr %l42, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i32, ptr %l42, !tbaa !23
  store i32 %t87, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t88 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t88, ptr %l43, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t90 = call i32 @std_2fos_2eremoveTree(ptr %v0, { i64, ptr } %t89)
  store i32 %t90, ptr %l44
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb34, label %ok.92
ok.92:
  br label %bb33
bb33:
  br label %bb35
bb34:
  %t93 = load i32, ptr %l44, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  store i32 %t101, ptr %l45, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t102 = load i32, ptr %l45, !tbaa !23
  store i32 %t102, ptr %rv
  br label %ret
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d40 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d40 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t13, ptr %l4, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t14, ptr %l5, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  call void @__olang_sb_put(ptr %s2, ptr %t16, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t18, i64 %t19)
  %t20 = load ptr, ptr %s2
  %t21 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t22 = load i64, ptr %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t20, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l6, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = call i32 @rename(ptr %t28, ptr %t31)
  store i32 %t33, ptr %l8
  br label %bb1
bb1:
  %t34 = load i32, ptr %l8, !tbaa !23
  %t35 = sext i32 %t34 to i64
  store i64 %t35, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l9, !tbaa !24
  %t37 = call i32 @std_2fos_2echeck(i64 %t36)
  store i32 %t37, ptr %l10
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb3, label %ok.39
ok.39:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t40 = load i32, ptr %l10, !tbaa !23
  %t41 = lshr i32 %t40, 16
  %t42 = and i32 %t40, 65535
  %t43 = icmp eq i32 %t41, 1
  %t44 = select i1 %t43, i32 1, i32 0
  %t45 = icmp eq i32 %t40, 0
  %t46 = shl i32 %t44, 16
  %t47 = or i32 %t46, %t42
  %t48 = select i1 %t45, i32 0, i32 %t47
  store i32 %t48, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t49 = load i32, ptr %l11, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fos_2eRunOnStack(ptr %v0, i64 %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { ptr, ptr }
  %l2 = alloca i64
  %l3 = alloca { ptr, ptr }
  %s0 = alloca %olang.scope
  store i64 %a0, ptr %l0
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  store { ptr, ptr } %pg1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load { ptr, ptr }, ptr %l1
  store { ptr, ptr } %t2, ptr %l3
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { ptr, ptr }, ptr %l3
  %t5 = extractvalue { ptr, ptr } %t4, 0
  %t6 = extractvalue { ptr, ptr } %t4, 1
  call void @__olang_run_on_stack(i64 %t3, ptr %t5, ptr %t6)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"std/os:Process" } @std_2fos_2eStart(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca %"std/os:FileInfo"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i8
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i32
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i32
  %l59 = alloca i1
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca %"std/os:FileInfo"
  %l65 = alloca { i64, ptr }
  %l66 = alloca %"std/os:FileInfo"
  %l67 = alloca i32
  %l68 = alloca i32
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca i1
  %l74 = alloca i1
  %l75 = alloca i32
  %l76 = alloca i64
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i1
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i8
  %l99 = alloca i64
  %l100 = alloca i8
  %l101 = alloca i8
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i32
  %l111 = alloca i32
  %l112 = alloca i32
  %l113 = alloca i32
  %l114 = alloca i32
  %l115 = alloca { i64, ptr }
  %l116 = alloca i32
  %l117 = alloca i32
  %l118 = alloca i1
  %l119 = alloca i32
  %l120 = alloca i32
  %l121 = alloca i32
  %l122 = alloca i32
  %l123 = alloca i32
  %l124 = alloca i32
  %l125 = alloca i32
  %l126 = alloca i64
  %l127 = alloca i1
  %l128 = alloca i32
  %l129 = alloca i32
  %l130 = alloca i32
  %l131 = alloca i32
  %l132 = alloca i32
  %l133 = alloca i32
  %l134 = alloca { i64, ptr }
  %l135 = alloca i32
  %l136 = alloca i32
  %l137 = alloca i1
  %l138 = alloca i32
  %l139 = alloca i32
  %l140 = alloca i32
  %l141 = alloca i32
  %l142 = alloca i32
  %l143 = alloca i32
  %l144 = alloca i32
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca i32
  %l149 = alloca i32
  %l150 = alloca i32
  %l151 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l154 = alloca i32
  %l155 = alloca i32
  %l156 = alloca i1
  %l157 = alloca i32
  %l158 = alloca i1
  %l159 = alloca i32
  %l160 = alloca i32
  %l161 = alloca i32
  %l162 = alloca i32
  %l163 = alloca i32
  %l164 = alloca i32
  %l165 = alloca i32
  %l166 = alloca i32
  %l167 = alloca i32
  %l168 = alloca i32
  %l169 = alloca i32
  %l170 = alloca i32
  %l171 = alloca i1
  %l172 = alloca %"std/os:Process"
  %l173 = alloca i32
  %l174 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Process" }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l28, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l29, !tbaa !24
  %t4 = load i64, ptr %l29, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l30, !tbaa !21
  %t6 = load i1, ptr %l30, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65542, ptr %l31, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l31, !tbaa !23
  %t8 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t7, 0
  store { i32, %"std/os:Process" } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l4, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l32, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t11, ptr %l33, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l34, !tbaa !24
  %t14 = load i64, ptr %l34, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load i64, ptr %l6, !tbaa !24
  store i64 %t15, ptr %l35, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  store i64 %t16, ptr %l36, !tbaa !24
  %t17 = load i64, ptr %l35, !tbaa !24
  %t18 = load i64, ptr %l36, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l37, !tbaa !21
  %t20 = load i1, ptr %l37, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l38, !tbaa !21
  %t22 = load i1, ptr %l38, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l39, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  store i64 %t24, ptr %l40, !tbaa !24
  %t25 = load i64, ptr %l40, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %t27, i64 %t25
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !37
  store { i64, ptr } %t29, ptr %l41, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t30, ptr %l8, !tbaa !27
  store i1 true, ptr %l9, !tbaa !21
  %t31 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t31, ptr %l43, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t33 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t32, i8 0)
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l45
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb9, label %ok.37
ok.37:
  store i64 %t34, ptr %l44
  br label %bb8
bb8:
  %t38 = load i64, ptr %l44, !tbaa !24
  store i64 %t38, ptr %l42, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb11
bb11:
  %t39 = load i1, ptr %l9, !tbaa !21
  store i1 %t39, ptr %l46, !tbaa !21
  %t40 = load i1, ptr %l46, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  store i32 65542, ptr %l47, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i32, ptr %l47, !tbaa !23
  %t42 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t41, 0
  store { i32, %"std/os:Process" } %t42, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t43 = load i64, ptr %l4, !tbaa !24
  store i64 %t43, ptr %l48, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t44, ptr %l49, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l50, !tbaa !24
  %t47 = load i64, ptr %l50, !tbaa !24
  %t48 = add i64 %t47, 1
  store i64 %t48, ptr %l51, !tbaa !24
  %t49 = load i64, ptr %l48, !tbaa !24
  %t50 = load i64, ptr %l51, !tbaa !24
  %t51 = add i64 %t49, %t50
  store i64 %t51, ptr %l52, !tbaa !24
  %t52 = load i64, ptr %l52, !tbaa !24
  store i64 %t52, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t53 = load i64, ptr %l6, !tbaa !24
  store i64 %t53, ptr %l53, !tbaa !24
  %t54 = load i64, ptr %l53, !tbaa !24
  %t55 = add i64 %t54, 1
  store i64 %t55, ptr %l54, !tbaa !24
  %t56 = load i64, ptr %l54, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb4
bb16:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %l10, !tbaa !21
  %t57 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t57, ptr %l56, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t59 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v2, { i64, ptr } %t58, i8 0)
  %t60 = extractvalue { i32, i64 } %t59, 1
  %t61 = extractvalue { i32, i64 } %t59, 0
  store i32 %t61, ptr %l58
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb18, label %ok.63
ok.63:
  store i64 %t60, ptr %l57
  br label %bb17
bb17:
  %t64 = load i64, ptr %l57, !tbaa !24
  store i64 %t64, ptr %l55, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s7
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb20
bb20:
  %t65 = load i1, ptr %l10, !tbaa !21
  store i1 %t65, ptr %l59, !tbaa !21
  %t66 = load i1, ptr %l59, !tbaa !21
  br i1 %t66, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 65542, ptr %l60, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t67 = load i32, ptr %l60, !tbaa !23
  %t68 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t67, 0
  store { i32, %"std/os:Process" } %t68, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t69, ptr %l61, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l62, !tbaa !24
  %t72 = load i64, ptr %l62, !tbaa !24
  %t73 = icmp sgt i64 %t72, 0
  store i1 %t73, ptr %l63, !tbaa !21
  %t74 = load i1, ptr %l63, !tbaa !21
  br i1 %t74, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s9
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t75, ptr %l65, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t77 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v2, { i64, ptr } %t76)
  %t78 = extractvalue { i32, %"std/os:FileInfo" } %t77, 1
  %t79 = extractvalue { i32, %"std/os:FileInfo" } %t77, 0
  store i32 %t79, ptr %l67
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb27, label %ok.81
ok.81:
  store %"std/os:FileInfo" %t78, ptr %l66
  br label %bb26
bb25:
  br label %bb33
bb26:
  %t82 = load %"std/os:FileInfo", ptr %l66
  store %"std/os:FileInfo" %t82, ptr %l64
  br label %bb28
bb27:
  %t83 = load i32, ptr %l67, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  store i32 %t91, ptr %l68, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t92 = load i32, ptr %l68, !tbaa !23
  %t93 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t92, 0
  store { i32, %"std/os:Process" } %t93, ptr %rv
  br label %ret
bb28:
  %t94 = load %"std/os:FileInfo", ptr %l64
  store %"std/os:FileInfo" %t94, ptr %l11
  %t95 = getelementptr %"std/os:FileInfo", ptr %l11, i32 0, i32 0
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l69
  store ptr %l69, ptr %l70, !tbaa !29
  store i32 1, ptr %l71
  store ptr %l71, ptr %l72, !tbaa !29
  %t97 = load ptr, ptr %l70, !tbaa !29
  %t98 = load ptr, ptr %l72, !tbaa !29
  %t99 = call i1 @olang_2eHelperKind_2eEqual_2estd_2fos_3aFileKind(ptr %t97, ptr %t98)
  store i1 %t99, ptr %l73
  br label %bb29
bb29:
  %t100 = load i1, ptr %l73, !tbaa !21
  %t101 = xor i1 %t100, true
  store i1 %t101, ptr %l74, !tbaa !21
  %t102 = load i1, ptr %l74, !tbaa !21
  br i1 %t102, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s10
  store i32 65539, ptr %l75, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t103 = load i32, ptr %l75, !tbaa !23
  %t104 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t103, 0
  store { i32, %"std/os:Process" } %t104, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb33:
  %t105 = load i64, ptr %l4, !tbaa !24
  store i64 %t105, ptr %l76, !tbaa !24
  %t106 = load i64, ptr %l76, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  store i1 %t107, ptr %l77, !tbaa !21
  %t108 = load i1, ptr %l77, !tbaa !21
  br i1 %t108, label %bb34, label %bb35
bb34:
  %t109 = load i64, ptr %l76, !tbaa !24
  %t110 = mul i64 %t109, 1
  %t111 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l78, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t114, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s11
  %t115 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t115, ptr %l79, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t116, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t117, ptr %l80, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l81, !tbaa !24
  %t120 = load i64, ptr %l81, !tbaa !24
  store i64 %t120, ptr %l16, !tbaa !24
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb36:
  store %olang.scope zeroinitializer, ptr %s12
  %t121 = load i64, ptr %l15, !tbaa !24
  store i64 %t121, ptr %l82, !tbaa !24
  %t122 = load i64, ptr %l16, !tbaa !24
  store i64 %t122, ptr %l83, !tbaa !24
  %t123 = load i64, ptr %l82, !tbaa !24
  %t124 = load i64, ptr %l83, !tbaa !24
  %t125 = icmp slt i64 %t123, %t124
  store i1 %t125, ptr %l84, !tbaa !21
  %t126 = load i1, ptr %l84, !tbaa !21
  %t127 = xor i1 %t126, true
  store i1 %t127, ptr %l85, !tbaa !21
  %t128 = load i1, ptr %l85, !tbaa !21
  br i1 %t128, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s12)
  br label %bb47
bb38:
  br label %bb39
bb39:
  %t129 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t129, ptr %l86, !tbaa !27
  %t130 = load i64, ptr %l15, !tbaa !24
  store i64 %t130, ptr %l87, !tbaa !24
  %t131 = load i64, ptr %l87, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %t133, i64 %t131
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !37
  store { i64, ptr } %t135, ptr %l88, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t136, ptr %l17, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s13
  %t137 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t137, ptr %l89, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t138, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t139, ptr %l90, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 0
  store i64 %t141, ptr %l91, !tbaa !24
  %t142 = load i64, ptr %l91, !tbaa !24
  store i64 %t142, ptr %l20, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s14
  %t143 = load i64, ptr %l19, !tbaa !24
  store i64 %t143, ptr %l92, !tbaa !24
  %t144 = load i64, ptr %l20, !tbaa !24
  store i64 %t144, ptr %l93, !tbaa !24
  %t145 = load i64, ptr %l92, !tbaa !24
  %t146 = load i64, ptr %l93, !tbaa !24
  %t147 = icmp slt i64 %t145, %t146
  store i1 %t147, ptr %l94, !tbaa !21
  %t148 = load i1, ptr %l94, !tbaa !21
  %t149 = xor i1 %t148, true
  store i1 %t149, ptr %l95, !tbaa !21
  %t150 = load i1, ptr %l95, !tbaa !21
  br i1 %t150, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s14)
  br label %bb45
bb42:
  br label %bb43
bb43:
  %t151 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t151, ptr %l96, !tbaa !27
  %t152 = load i64, ptr %l19, !tbaa !24
  store i64 %t152, ptr %l97, !tbaa !24
  %t153 = load i64, ptr %l97, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i8, ptr %t155, i64 %t153
  %t157 = load i8, ptr %t156, !tbaa !32
  store i8 %t157, ptr %l98, !tbaa !22
  %t158 = load i8, ptr %l98, !tbaa !22
  store i8 %t158, ptr %l21, !tbaa !22
  %t159 = load i64, ptr %l13, !tbaa !24
  store i64 %t159, ptr %l99, !tbaa !24
  %t160 = load i8, ptr %l21, !tbaa !22
  store i8 %t160, ptr %l100, !tbaa !22
  %t161 = load i8, ptr %l100, !tbaa !22
  store i8 %t161, ptr %l101, !tbaa !22
  %t162 = load i8, ptr %l101, !tbaa !22
  %t163 = load i64, ptr %l99, !tbaa !24
  %t164 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr i8, ptr %t165, i64 %t163
  store i8 %t162, ptr %t166, !tbaa !32
  %t167 = load i64, ptr %l13, !tbaa !24
  store i64 %t167, ptr %l102, !tbaa !24
  %t168 = load i64, ptr %l102, !tbaa !24
  %t169 = add i64 %t168, 1
  store i64 %t169, ptr %l103, !tbaa !24
  %t170 = load i64, ptr %l103, !tbaa !24
  store i64 %t170, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s15
  %t171 = load i64, ptr %l19, !tbaa !24
  store i64 %t171, ptr %l104, !tbaa !24
  %t172 = load i64, ptr %l104, !tbaa !24
  %t173 = add i64 %t172, 1
  store i64 %t173, ptr %l105, !tbaa !24
  %t174 = load i64, ptr %l105, !tbaa !24
  store i64 %t174, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb40
bb45:
  call void @__olang_scope_close(ptr %s13)
  %t175 = load i64, ptr %l13, !tbaa !24
  store i64 %t175, ptr %l106, !tbaa !24
  %t176 = load i64, ptr %l106, !tbaa !24
  %t177 = add i64 %t176, 1
  store i64 %t177, ptr %l107, !tbaa !24
  %t178 = load i64, ptr %l107, !tbaa !24
  store i64 %t178, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s16
  %t179 = load i64, ptr %l15, !tbaa !24
  store i64 %t179, ptr %l108, !tbaa !24
  %t180 = load i64, ptr %l108, !tbaa !24
  %t181 = add i64 %t180, 1
  store i64 %t181, ptr %l109, !tbaa !24
  %t182 = load i64, ptr %l109, !tbaa !24
  store i64 %t182, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb36
bb47:
  call void @__olang_scope_close(ptr %s11)
  %t183 = call { i32, i32 } @std_2fos_2ememFile()
  %t184 = extractvalue { i32, i32 } %t183, 1
  %t185 = extractvalue { i32, i32 } %t183, 0
  store i32 %t185, ptr %l112
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb49, label %ok.187
ok.187:
  store i32 %t184, ptr %l111
  br label %bb48
bb48:
  %t188 = load i32, ptr %l111, !tbaa !23
  store i32 %t188, ptr %l110, !tbaa !23
  br label %bb50
bb49:
  %t189 = load i32, ptr %l112, !tbaa !23
  %t190 = lshr i32 %t189, 16
  %t191 = and i32 %t189, 65535
  %t192 = icmp eq i32 %t190, 1
  %t193 = select i1 %t192, i32 1, i32 0
  %t194 = icmp eq i32 %t189, 0
  %t195 = shl i32 %t193, 16
  %t196 = or i32 %t195, %t191
  %t197 = select i1 %t194, i32 0, i32 %t196
  store i32 %t197, ptr %l113, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t198 = load i32, ptr %l113, !tbaa !23
  %t199 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t198, 0
  store { i32, %"std/os:Process" } %t199, ptr %rv
  br label %ret
bb50:
  %t200 = load i32, ptr %l110, !tbaa !23
  store i32 %t200, ptr %l22, !tbaa !23
  %t201 = load i32, ptr %l22, !tbaa !23
  store i32 %t201, ptr %l114, !tbaa !23
  %t202 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t202, ptr %l115, !tbaa !27
  %t203 = load i32, ptr %l114, !tbaa !23
  %t204 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t205 = call i32 @std_2fio_2eWrite(ptr %v1, i32 %t203, { i64, ptr } %t204)
  store i32 %t205, ptr %l116
  %t206 = icmp ne i32 %t205, 0
  br i1 %t206, label %bb52, label %ok.207
ok.207:
  br label %bb51
bb51:
  br label %bb58
bb52:
  %t208 = load i32, ptr %l116, !tbaa !23
  %t209 = ashr i32 %t208, 16
  store i32 %t209, ptr %l117, !tbaa !23
  %t210 = load i32, ptr %l117, !tbaa !23
  %t211 = icmp eq i32 %t210, 1
  store i1 %t211, ptr %l118, !tbaa !21
  %t212 = load i1, ptr %l118, !tbaa !21
  br i1 %t212, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  %t213 = load i32, ptr %l116, !tbaa !23
  %t214 = lshr i32 %t213, 16
  %t215 = and i32 %t213, 65535
  %t216 = icmp eq i32 %t214, 1
  %t217 = select i1 %t216, i32 0, i32 0
  %t218 = icmp eq i32 %t213, 0
  %t219 = shl i32 %t217, 16
  %t220 = or i32 %t219, %t215
  %t221 = select i1 %t218, i32 0, i32 %t220
  store i32 %t221, ptr %l119, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s17
  %t222 = load i32, ptr %l22, !tbaa !23
  store i32 %t222, ptr %l120, !tbaa !23
  %t223 = load i32, ptr %l120, !tbaa !23
  %t224 = call i32 @close(i32 %t223)
  store i32 %t224, ptr %l121
  br label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s18
  store i32 65542, ptr %l122, !tbaa !23
  call void @__olang_scope_close(ptr %s18)
  store %olang.scope zeroinitializer, ptr %s19
  %t225 = load i32, ptr %l22, !tbaa !23
  store i32 %t225, ptr %l123, !tbaa !23
  %t226 = load i32, ptr %l123, !tbaa !23
  %t227 = call i32 @close(i32 %t226)
  store i32 %t227, ptr %l124
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t228 = load i32, ptr %l119, !tbaa !23
  %t229 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t228, 0
  store { i32, %"std/os:Process" } %t229, ptr %rv
  br label %ret
bb57:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t230 = load i32, ptr %l122, !tbaa !23
  %t231 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t230, 0
  store { i32, %"std/os:Process" } %t231, ptr %rv
  br label %ret
bb58:
  %t232 = load i32, ptr %l22, !tbaa !23
  store i32 %t232, ptr %l125, !tbaa !23
  %t233 = load i32, ptr %l125, !tbaa !23
  %t234 = call i64 @lseek(i32 %t233, i64 0, i32 0)
  store i64 %t234, ptr %l126
  br label %bb59
bb59:
  store i32 -1, ptr %l23, !tbaa !23
  store i32 -1, ptr %l24, !tbaa !23
  %t235 = load i1, ptr %l2, !tbaa !21
  store i1 %t235, ptr %l127, !tbaa !21
  %t236 = load i1, ptr %l127, !tbaa !21
  br i1 %t236, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s20
  %t237 = call { i32, i32 } @std_2fos_2ememFile()
  %t238 = extractvalue { i32, i32 } %t237, 1
  %t239 = extractvalue { i32, i32 } %t237, 0
  store i32 %t239, ptr %l130
  %t240 = icmp ne i32 %t239, 0
  br i1 %t240, label %bb63, label %ok.241
ok.241:
  store i32 %t238, ptr %l129
  br label %bb62
bb61:
  br label %bb75
bb62:
  %t242 = load i32, ptr %l129, !tbaa !23
  store i32 %t242, ptr %l128, !tbaa !23
  br label %bb65
bb63:
  %t243 = load i32, ptr %l130, !tbaa !23
  %t244 = lshr i32 %t243, 16
  %t245 = and i32 %t243, 65535
  %t246 = icmp eq i32 %t244, 1
  %t247 = select i1 %t246, i32 1, i32 0
  %t248 = icmp eq i32 %t243, 0
  %t249 = shl i32 %t247, 16
  %t250 = or i32 %t249, %t245
  %t251 = select i1 %t248, i32 0, i32 %t250
  store i32 %t251, ptr %l131, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  store %olang.scope zeroinitializer, ptr %s21
  %t252 = load i32, ptr %l22, !tbaa !23
  store i32 %t252, ptr %l132, !tbaa !23
  %t253 = load i32, ptr %l132, !tbaa !23
  %t254 = call i32 @close(i32 %t253)
  store i32 %t254, ptr %l133
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t255 = load i32, ptr %l131, !tbaa !23
  %t256 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t255, 0
  store { i32, %"std/os:Process" } %t256, ptr %rv
  br label %ret
bb65:
  %t257 = load i32, ptr %l128, !tbaa !23
  store i32 %t257, ptr %l23, !tbaa !23
  store { i64, ptr } { i64 6, ptr @.d43 }, ptr %l134, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = call i32 @memfd_create(ptr %t259, i32 1)
  store i32 %t261, ptr %l135
  br label %bb66
bb66:
  %t262 = load i32, ptr %l135, !tbaa !23
  store i32 %t262, ptr %l25, !tbaa !23
  %t263 = load i32, ptr %l25, !tbaa !23
  store i32 %t263, ptr %l136, !tbaa !23
  %t264 = load i32, ptr %l136, !tbaa !23
  %t265 = icmp slt i32 %t264, 0
  store i1 %t265, ptr %l137, !tbaa !21
  %t266 = load i1, ptr %l137, !tbaa !21
  br i1 %t266, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s22
  %t267 = load i32, ptr %l23, !tbaa !23
  store i32 %t267, ptr %l138, !tbaa !23
  %t268 = call i32 @__olang_err()
  store i32 %t268, ptr %l139
  br label %bb69
bb68:
  br label %bb74
bb69:
  %t269 = load i32, ptr %l138, !tbaa !23
  %t270 = load i32, ptr %l139, !tbaa !23
  %t271 = call i32 @std_2fos_2ecloseAndRaise(i32 %t269, i32 %t270)
  store i32 %t271, ptr %l140
  %t272 = icmp ne i32 %t271, 0
  br i1 %t272, label %bb71, label %ok.273
ok.273:
  br label %bb70
bb70:
  br label %bb73
bb71:
  %t274 = load i32, ptr %l140, !tbaa !23
  %t275 = lshr i32 %t274, 16
  %t276 = and i32 %t274, 65535
  %t277 = icmp eq i32 %t275, 1
  %t278 = select i1 %t277, i32 1, i32 0
  %t279 = icmp eq i32 %t274, 0
  %t280 = shl i32 %t278, 16
  %t281 = or i32 %t280, %t276
  %t282 = select i1 %t279, i32 0, i32 %t281
  store i32 %t282, ptr %l141, !tbaa !23
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s20)
  store %olang.scope zeroinitializer, ptr %s23
  %t283 = load i32, ptr %l22, !tbaa !23
  store i32 %t283, ptr %l142, !tbaa !23
  %t284 = load i32, ptr %l142, !tbaa !23
  %t285 = call i32 @close(i32 %t284)
  store i32 %t285, ptr %l143
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t286 = load i32, ptr %l141, !tbaa !23
  %t287 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t286, 0
  store { i32, %"std/os:Process" } %t287, ptr %rv
  br label %ret
bb73:
  call void @__olang_scope_close(ptr %s22)
  br label %bb74
bb74:
  %t288 = load i32, ptr %l25, !tbaa !23
  store i32 %t288, ptr %l144, !tbaa !23
  %t289 = load i32, ptr %l144, !tbaa !23
  store i32 %t289, ptr %l24, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  br label %bb75
bb75:
  %t290 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t290, ptr %l145, !tbaa !27
  %t291 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t291, ptr %l146, !tbaa !27
  %t292 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 0
  store i64 %t293, ptr %l147, !tbaa !24
  %t294 = load i32, ptr %l22, !tbaa !23
  store i32 %t294, ptr %l148, !tbaa !23
  %t295 = load i32, ptr %l23, !tbaa !23
  store i32 %t295, ptr %l149, !tbaa !23
  %t296 = load i32, ptr %l24, !tbaa !23
  store i32 %t296, ptr %l150, !tbaa !23
  %t297 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t297, ptr %l151, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  %t298 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t298, 1
  %t300 = extractvalue { i64, ptr } %t298, 0
  call void @__olang_sb_put(ptr %s24, ptr %t299, i64 %t300)
  %t301 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 1
  %t302 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 0
  call void @__olang_sb_put(ptr %s24, ptr %t301, i64 %t302)
  %t303 = load ptr, ptr %s24
  %t304 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t305 = load i64, ptr %t304
  %t306 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t305)
  call void @llvm.memcpy.p0.p0.i64(ptr %t306, ptr %t303, i64 %t305, i1 false)
  %t307 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  store { i64, ptr } %t308, ptr %l152, !tbaa !27
  call void @__olang_sb_done(ptr %s24)
  %t309 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t309, ptr %l153, !tbaa !27
  %t310 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = load i64, ptr %l147, !tbaa !24
  %t314 = load i32, ptr %l148, !tbaa !23
  %t315 = load i32, ptr %l149, !tbaa !23
  %t316 = load i32, ptr %l150, !tbaa !23
  %t317 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = call i32 @__olang_spawn(ptr %t311, i64 %t313, i32 %t314, i32 %t315, i32 %t316, ptr %t318)
  store i32 %t320, ptr %l154
  br label %bb76
bb76:
  %t321 = load i32, ptr %l154, !tbaa !23
  store i32 %t321, ptr %l26, !tbaa !23
  %t322 = load i32, ptr %l26, !tbaa !23
  store i32 %t322, ptr %l155, !tbaa !23
  %t323 = load i32, ptr %l155, !tbaa !23
  %t324 = icmp slt i32 %t323, 0
  store i1 %t324, ptr %l156, !tbaa !21
  %t325 = load i1, ptr %l156, !tbaa !21
  br i1 %t325, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s25
  %t326 = call i32 @__olang_err()
  store i32 %t326, ptr %l157
  br label %bb79
bb78:
  br label %bb89
bb79:
  %t327 = load i32, ptr %l157, !tbaa !23
  store i32 %t327, ptr %l27, !tbaa !23
  %t328 = load i1, ptr %l2, !tbaa !21
  store i1 %t328, ptr %l158, !tbaa !21
  %t329 = load i1, ptr %l158, !tbaa !21
  br i1 %t329, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s26
  %t330 = load i32, ptr %l23, !tbaa !23
  store i32 %t330, ptr %l159, !tbaa !23
  %t331 = load i32, ptr %l159, !tbaa !23
  %t332 = call i32 @close(i32 %t331)
  store i32 %t332, ptr %l160
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t333 = load i32, ptr %l24, !tbaa !23
  store i32 %t333, ptr %l161, !tbaa !23
  %t334 = load i32, ptr %l161, !tbaa !23
  %t335 = call i32 @close(i32 %t334)
  store i32 %t335, ptr %l162
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s26)
  br label %bb84
bb84:
  %t336 = load i32, ptr %l27, !tbaa !23
  store i32 %t336, ptr %l163, !tbaa !23
  %t337 = load i32, ptr %l163, !tbaa !23
  %t338 = call i32 @std_2fos_2eraise(i32 %t337)
  store i32 %t338, ptr %l164
  %t339 = icmp ne i32 %t338, 0
  br i1 %t339, label %bb86, label %ok.340
ok.340:
  br label %bb85
bb85:
  br label %bb88
bb86:
  %t341 = load i32, ptr %l164, !tbaa !23
  %t342 = lshr i32 %t341, 16
  %t343 = and i32 %t341, 65535
  %t344 = icmp eq i32 %t342, 1
  %t345 = select i1 %t344, i32 1, i32 0
  %t346 = icmp eq i32 %t341, 0
  %t347 = shl i32 %t345, 16
  %t348 = or i32 %t347, %t343
  %t349 = select i1 %t346, i32 0, i32 %t348
  store i32 %t349, ptr %l165, !tbaa !23
  call void @__olang_scope_close(ptr %s25)
  store %olang.scope zeroinitializer, ptr %s27
  %t350 = load i32, ptr %l22, !tbaa !23
  store i32 %t350, ptr %l166, !tbaa !23
  %t351 = load i32, ptr %l166, !tbaa !23
  %t352 = call i32 @close(i32 %t351)
  store i32 %t352, ptr %l167
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s0)
  %t353 = load i32, ptr %l165, !tbaa !23
  %t354 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t353, 0
  store { i32, %"std/os:Process" } %t354, ptr %rv
  br label %ret
bb88:
  call void @__olang_scope_close(ptr %s25)
  br label %bb89
bb89:
  %t355 = load i32, ptr %l26, !tbaa !23
  store i32 %t355, ptr %l168, !tbaa !23
  %t356 = load i32, ptr %l23, !tbaa !23
  store i32 %t356, ptr %l169, !tbaa !23
  %t357 = load i32, ptr %l24, !tbaa !23
  store i32 %t357, ptr %l170, !tbaa !23
  %t358 = load i1, ptr %l2, !tbaa !21
  store i1 %t358, ptr %l171, !tbaa !21
  %t359 = load i32, ptr %l168, !tbaa !23
  %t360 = load i32, ptr %l169, !tbaa !23
  %t361 = load i32, ptr %l170, !tbaa !23
  %t362 = load i1, ptr %l171, !tbaa !21
  %t363 = call %"std/os:Process" @std_2fos_3aProcess_2ector(ptr %s0, i32 %t359, i32 %t360, i32 %t361, i1 %t362)
  store %"std/os:Process" %t363, ptr %l172
  br label %bb90
bb90:
  store %olang.scope zeroinitializer, ptr %s28
  %t364 = load i32, ptr %l22, !tbaa !23
  store i32 %t364, ptr %l173, !tbaa !23
  %t365 = load i32, ptr %l173, !tbaa !23
  %t366 = call i32 @close(i32 %t365)
  store i32 %t366, ptr %l174
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s0)
  %t367 = load %"std/os:Process", ptr %l172
  %t368 = insertvalue { i32, %"std/os:Process" } zeroinitializer, %"std/os:Process" %t367, 1
  store { i32, %"std/os:Process" } %t368, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Process" }, ptr %rv
  ret { i32, %"std/os:Process" } %rr
}

define dso_local { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca [3 x i64]
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"std/os:FileInfo"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:FileInfo" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store [3 x i64] zeroinitializer, ptr %l1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 1
  %t4 = extractvalue { i64, ptr } %t2, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d45 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d45 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l4, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t13, ptr %l5, !tbaa !27
  store ptr %l1, ptr %l6
  %t14 = load ptr, ptr %l6
  %t15 = insertvalue { i64, ptr } undef, i64 3, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l7, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t17, ptr %l8, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = call i32 @__olang_stat(ptr %t19, ptr %t22)
  store i32 %t24, ptr %l9
  br label %bb1
bb1:
  %t25 = load i32, ptr %l9, !tbaa !23
  %t26 = sext i32 %t25 to i64
  store i64 %t26, ptr %l10, !tbaa !24
  %t27 = load i64, ptr %l10, !tbaa !24
  %t28 = call i32 @std_2fos_2echeck(i64 %t27)
  store i32 %t28, ptr %l11
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb3, label %ok.30
ok.30:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t31 = load i32, ptr %l11, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 1, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  store i32 %t39, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i32, ptr %l12, !tbaa !23
  %t41 = insertvalue { i32, %"std/os:FileInfo" } zeroinitializer, i32 %t40, 0
  store { i32, %"std/os:FileInfo" } %t41, ptr %rv
  br label %ret
bb4:
  store i32 2, ptr %l13
  %t42 = load i32, ptr %l13
  store i32 %t42, ptr %l2
  %t43 = getelementptr [3 x i64], ptr %l1, i64 0, i64 0
  %t44 = load i64, ptr %t43, !tbaa !34
  store i64 %t44, ptr %l14, !tbaa !24
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = icmp eq i64 %t45, 1
  store i1 %t46, ptr %l15, !tbaa !21
  %t47 = load i1, ptr %l15, !tbaa !21
  br i1 %t47, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 0, ptr %l16
  %t48 = load i32, ptr %l16
  store i32 %t48, ptr %l2
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t49 = getelementptr [3 x i64], ptr %l1, i64 0, i64 0
  %t50 = load i64, ptr %t49, !tbaa !34
  store i64 %t50, ptr %l17, !tbaa !24
  %t51 = load i64, ptr %l17, !tbaa !24
  %t52 = icmp eq i64 %t51, 2
  store i1 %t52, ptr %l18, !tbaa !21
  %t53 = load i1, ptr %l18, !tbaa !21
  br i1 %t53, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 1, ptr %l19
  %t54 = load i32, ptr %l19
  store i32 %t54, ptr %l2
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t55 = load i32, ptr %l2
  store i32 %t55, ptr %l20
  %t56 = getelementptr [3 x i64], ptr %l1, i64 0, i64 1
  %t57 = load i64, ptr %t56, !tbaa !34
  store i64 %t57, ptr %l21, !tbaa !24
  %t58 = getelementptr [3 x i64], ptr %l1, i64 0, i64 2
  %t59 = load i64, ptr %t58, !tbaa !34
  store i64 %t59, ptr %l22, !tbaa !24
  %t60 = load i32, ptr %l20
  %t61 = load i64, ptr %l21, !tbaa !24
  %t62 = load i64, ptr %l22, !tbaa !24
  %t63 = call %"std/os:FileInfo" @std_2fos_3aFileInfo_2ector(ptr %s0, i32 %t60, i64 %t61, i64 %t62)
  store %"std/os:FileInfo" %t63, ptr %l23
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load %"std/os:FileInfo", ptr %l23
  %t65 = insertvalue { i32, %"std/os:FileInfo" } zeroinitializer, %"std/os:FileInfo" %t64, 1
  store { i32, %"std/os:FileInfo" } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:FileInfo" }, ptr %rv
  ret { i32, %"std/os:FileInfo" } %rr
}

define dso_local i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l4, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t3 = call { i32, i32 } @std_2fos_2eCreate(ptr %v0, { i64, ptr } %t2)
  %t4 = extractvalue { i32, i32 } %t3, 1
  %t5 = extractvalue { i32, i32 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i32 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  store i32 %t17, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l7, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  %t19 = load i32, ptr %l3, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load i32, ptr %l2, !tbaa !23
  store i32 %t20, ptr %l8, !tbaa !23
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t21, ptr %l9, !tbaa !27
  %t22 = load i32, ptr %l8, !tbaa !23
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t24 = call i32 @std_2fio_2eWrite(ptr %v1, i32 %t22, { i64, ptr } %t23)
  store i32 %t24, ptr %l10
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb5, label %ok.26
ok.26:
  br label %bb4
bb4:
  br label %bb13
bb5:
  %t27 = load i32, ptr %l10, !tbaa !23
  %t28 = ashr i32 %t27, 16
  store i32 %t28, ptr %l11, !tbaa !23
  %t29 = load i32, ptr %l11, !tbaa !23
  %t30 = icmp eq i32 %t29, 1
  store i1 %t30, ptr %l12, !tbaa !21
  %t31 = load i1, ptr %l12, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  %t32 = load i32, ptr %l10, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 0, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  store i32 %t40, ptr %l13, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i32, ptr %l13, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t42 = load i32, ptr %l2, !tbaa !23
  store i32 %t42, ptr %l14, !tbaa !23
  %t43 = call i32 @__olang_err()
  store i32 %t43, ptr %l15
  br label %bb9
bb9:
  %t44 = load i32, ptr %l14, !tbaa !23
  %t45 = load i32, ptr %l15, !tbaa !23
  %t46 = call i32 @std_2fos_2ecloseAndRaise(i32 %t44, i32 %t45)
  store i32 %t46, ptr %l16
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb11, label %ok.48
ok.48:
  br label %bb10
bb10:
  br label %bb12
bb11:
  %t49 = load i32, ptr %l16, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  store i32 %t57, ptr %l17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l17, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  %t59 = load i32, ptr %l2, !tbaa !23
  store i32 %t59, ptr %l18, !tbaa !23
  %t60 = load i32, ptr %l18, !tbaa !23
  %t61 = call i32 @std_2fos_2eClose(i32 %t60)
  store i32 %t61, ptr %l19
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb15, label %ok.63
ok.63:
  br label %bb14
bb14:
  br label %bb16
bb15:
  %t64 = load i32, ptr %l19, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  store i32 %t72, ptr %l20, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t73 = load i32, ptr %l20, !tbaa !23
  store i32 %t73, ptr %rv
  br label %ret
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2echeck(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t2, 0
  store i1 %t3, ptr %l2, !tbaa !21
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call i32 @__olang_err()
  store i32 %t5, ptr %l3
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = call i32 @std_2fos_2eraise(i32 %t6)
  store i32 %t7, ptr %l4
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb5, label %ok.9
ok.9:
  br label %bb4
bb4:
  br label %bb6
bb5:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  store i32 %t18, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i32, ptr %l5, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2ecloseAndRaise(i32 %a0, i32 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %l2, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = call i32 @close(i32 %t2)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = call i32 @std_2fos_2eraise(i32 %t5)
  store i32 %t6, ptr %l5
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb3, label %ok.8
ok.8:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  store i32 %t17, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l6, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %v0, ptr %v1, ptr %a0c, ptr %a0e) #0 {
entry:
  %l0 = alloca { ptr, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { ptr, ptr }
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { ptr, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %pf0 = insertvalue { ptr, ptr } undef, ptr %a0c, 0
  %pg0 = insertvalue { ptr, ptr } %pf0, ptr %a0e, 1
  store { ptr, ptr } %pg0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { ptr, ptr }, ptr %l0
  store { ptr, ptr } %t1, ptr %l4
  %t2 = icmp sge i64 0, 0
  store i1 %t2, ptr %l5, !tbaa !21
  %t3 = load i1, ptr %l5, !tbaa !21
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t4 = mul i64 0, 1
  %t5 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 0, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l7, !tbaa !27
  %t15 = load { ptr, ptr }, ptr %l4
  %t16 = extractvalue { ptr, ptr } %t15, 0
  %t17 = extractvalue { ptr, ptr } %t15, 1
  %t18 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t19 = call i64 %t16(ptr %t17, ptr %s0, { i64, ptr } %t18)
  store i64 %t19, ptr %l8
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @.c46)
  unreachable
bb3:
  %t20 = load i64, ptr %l8, !tbaa !24
  store i64 %t20, ptr %l1, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t21 = load i64, ptr %l1, !tbaa !24
  store i64 %t21, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = call i32 @std_2fos_2echeck(i64 %t22)
  store i32 %t23, ptr %l10
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb6, label %ok.25
ok.25:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t26 = load i32, ptr %l10, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  store i32 %t34, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t35 = load i32, ptr %l11, !tbaa !23
  %t36 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t35, 0
  store { i32, { i64, ptr } } %t36, ptr %rv
  br label %ret
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l12, !tbaa !24
  %t38 = load i64, ptr %l12, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  store i1 %t39, ptr %l13, !tbaa !21
  %t40 = load i1, ptr %l13, !tbaa !21
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t41 = load i64, ptr %l12, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l14, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t46, ptr %l15, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l16, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t54, ptr %l2, !tbaa !27
  %t55 = load { ptr, ptr }, ptr %l0
  store { ptr, ptr } %t55, ptr %l17
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %l18, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t57, ptr %l19, !tbaa !27
  %t58 = load { ptr, ptr }, ptr %l17
  %t59 = extractvalue { ptr, ptr } %t58, 0
  %t60 = extractvalue { ptr, ptr } %t58, 1
  %t61 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t62 = call i64 %t59(ptr %t60, ptr %v1, { i64, ptr } %t61)
  store i64 %t62, ptr %l20
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @.c47)
  unreachable
bb10:
  %t63 = load i64, ptr %l20, !tbaa !24
  store i64 %t63, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l3, !tbaa !24
  store i64 %t64, ptr %l21, !tbaa !24
  %t65 = load i64, ptr %l1, !tbaa !24
  store i64 %t65, ptr %l22, !tbaa !24
  %t66 = load i64, ptr %l21, !tbaa !24
  %t67 = load i64, ptr %l22, !tbaa !24
  %t68 = icmp sle i64 %t66, %t67
  store i1 %t68, ptr %l23, !tbaa !21
  %t69 = load i1, ptr %l23, !tbaa !21
  br i1 %t69, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t70 = load i64, ptr %l3, !tbaa !24
  store i64 %t70, ptr %l24, !tbaa !24
  %t71 = load i64, ptr %l24, !tbaa !24
  %t72 = call i32 @std_2fos_2echeck(i64 %t71)
  store i32 %t72, ptr %l25
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb14, label %ok.74
ok.74:
  br label %bb13
bb12:
  br label %bb22
bb13:
  br label %bb15
bb14:
  %t75 = load i32, ptr %l25, !tbaa !23
  %t76 = lshr i32 %t75, 16
  %t77 = and i32 %t75, 65535
  %t78 = icmp eq i32 %t76, 1
  %t79 = select i1 %t78, i32 1, i32 0
  %t80 = icmp eq i32 %t75, 0
  %t81 = shl i32 %t79, 16
  %t82 = or i32 %t81, %t77
  %t83 = select i1 %t80, i32 0, i32 %t82
  store i32 %t83, ptr %l26, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t84 = load i32, ptr %l26, !tbaa !23
  %t85 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t84, 0
  store { i32, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb15:
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t86, ptr %l27, !tbaa !27
  %t87 = load i64, ptr %l3, !tbaa !24
  store i64 %t87, ptr %l28, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  store i64 %t89, ptr %l29, !tbaa !24
  %t90 = icmp sge i64 0, 0
  store i1 %t90, ptr %l30, !tbaa !21
  %t91 = load i1, ptr %l30, !tbaa !21
  br i1 %t91, label %bb16, label %bb17
bb16:
  %t92 = load i64, ptr %l28, !tbaa !24
  %t93 = icmp sle i64 0, %t92
  store i1 %t93, ptr %l31, !tbaa !21
  %t94 = load i1, ptr %l31, !tbaa !21
  br i1 %t94, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @.c48)
  unreachable
bb18:
  %t95 = load i64, ptr %l28, !tbaa !24
  %t96 = load i64, ptr %l29, !tbaa !24
  %t97 = icmp sle i64 %t95, %t96
  store i1 %t97, ptr %l32, !tbaa !21
  %t98 = load i1, ptr %l32, !tbaa !21
  br i1 %t98, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c48)
  unreachable
bb20:
  %t99 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = load i64, ptr %l28, !tbaa !24
  %t102 = getelementptr i8, ptr %t100, i64 0
  %t103 = sub i64 %t101, 0
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  store { i64, ptr } %t105, ptr %l33, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t106 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t107 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t106, 1
  store { i32, { i64, ptr } } %t107, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @.c48)
  unreachable
bb22:
  %t108 = load i64, ptr %l3, !tbaa !24
  store i64 %t108, ptr %l34, !tbaa !24
  %t109 = load i64, ptr %l34, !tbaa !24
  store i64 %t109, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb23:
  br label %bb4
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i32 } @std_2fos_2ememFile() #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 6, ptr @.d49 }, ptr %l1, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 1
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = call i32 @memfd_create(ptr %t2, i32 1)
  store i32 %t4, ptr %l2
  br label %bb1
bb1:
  %t5 = load i32, ptr %l2, !tbaa !23
  store i32 %t5, ptr %l0, !tbaa !23
  %t6 = load i32, ptr %l0, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = sext i32 %t7 to i64
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = call i32 @std_2fos_2echeck(i64 %t9)
  store i32 %t10, ptr %l5
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb3, label %ok.12
ok.12:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t13 = load i32, ptr %l5, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  store i32 %t21, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i32, ptr %l6, !tbaa !23
  %t23 = insertvalue { i32, i32 } zeroinitializer, i32 %t22, 0
  store { i32, i32 } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load i32, ptr %l0, !tbaa !23
  store i32 %t24, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l7, !tbaa !23
  %t26 = insertvalue { i32, i32 } zeroinitializer, i32 %t25, 1
  store { i32, i32 } %t26, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i32 @std_2fos_2eraise(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i32
  %l19 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %l1, !tbaa !23
  %t2 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t2, 1
  store i1 %t3, ptr %l2, !tbaa !21
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t5 = load i32, ptr %l3, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb4:
  %t6 = load i32, ptr %l0, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = icmp eq i32 %t7, 2
  store i1 %t8, ptr %l5, !tbaa !21
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 65537, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i32, ptr %l6, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
bb8:
  %t11 = load i32, ptr %l0, !tbaa !23
  store i32 %t11, ptr %l7, !tbaa !23
  %t12 = load i32, ptr %l7, !tbaa !23
  %t13 = icmp eq i32 %t12, 3
  store i1 %t13, ptr %l8, !tbaa !21
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 65538, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i32, ptr %l9, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
bb12:
  %t16 = load i32, ptr %l0, !tbaa !23
  store i32 %t16, ptr %l10, !tbaa !23
  %t17 = load i32, ptr %l10, !tbaa !23
  %t18 = icmp eq i32 %t17, 4
  store i1 %t18, ptr %l11, !tbaa !21
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store i32 65539, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i32, ptr %l12, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
bb16:
  %t21 = load i32, ptr %l0, !tbaa !23
  store i32 %t21, ptr %l13, !tbaa !23
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = icmp eq i32 %t22, 5
  store i1 %t23, ptr %l14, !tbaa !21
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  store i32 65540, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l15, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb20:
  %t26 = load i32, ptr %l0, !tbaa !23
  store i32 %t26, ptr %l16, !tbaa !23
  %t27 = load i32, ptr %l16, !tbaa !23
  %t28 = icmp eq i32 %t27, 6
  store i1 %t28, ptr %l17, !tbaa !21
  %t29 = load i1, ptr %l17, !tbaa !21
  br i1 %t29, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  store i32 65541, ptr %l18, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i32, ptr %l18, !tbaa !23
  store i32 %t30, ptr %rv
  br label %ret
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  store i32 65542, ptr %l19, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2ereadBack(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca i32
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %l5, !tbaa !23
  %t2 = load i32, ptr %l5, !tbaa !23
  %t3 = call i64 @lseek(i32 %t2, i64 0, i32 2)
  store i64 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i64, ptr %l6, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load i64, ptr %l7, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  store i1 %t7, ptr %l8, !tbaa !21
  %t8 = load i1, ptr %l8, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = call i32 @__olang_err()
  store i32 %t9, ptr %l9
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = call i32 @std_2fos_2eraise(i32 %t10)
  store i32 %t11, ptr %l10
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13
ok.13:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  store i32 %t22, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l11, !tbaa !23
  %t24 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t23, 0
  store { i32, { i64, ptr } } %t24, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t25 = load i32, ptr %l0, !tbaa !23
  store i32 %t25, ptr %l12, !tbaa !23
  %t26 = load i32, ptr %l12, !tbaa !23
  %t27 = call i64 @lseek(i32 %t26, i64 0, i32 0)
  store i64 %t27, ptr %l13
  br label %bb9
bb9:
  %t28 = load i64, ptr %l1, !tbaa !24
  store i64 %t28, ptr %l14, !tbaa !24
  %t29 = load i64, ptr %l14, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  store i1 %t30, ptr %l15, !tbaa !21
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l16, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t37, ptr %l17, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t40 = extractvalue { i64, ptr } %t38, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l18, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t45, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @.c50)
  unreachable
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load i64, ptr %l3, !tbaa !24
  store i64 %t46, ptr %l19, !tbaa !24
  %t47 = load i64, ptr %l1, !tbaa !24
  store i64 %t47, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l19, !tbaa !24
  %t49 = load i64, ptr %l20, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  store i1 %t50, ptr %l21, !tbaa !21
  %t51 = load i1, ptr %l21, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l22, !tbaa !21
  %t53 = load i1, ptr %l22, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb14:
  br label %bb15
bb15:
  %t54 = load i32, ptr %l0, !tbaa !23
  store i32 %t54, ptr %l23, !tbaa !23
  %t55 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t55, ptr %l24, !tbaa !27
  %t56 = load i64, ptr %l3, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t57, ptr %l26, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t58, ptr %l27, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l28, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l29, !tbaa !24
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  store i1 %t64, ptr %l30, !tbaa !21
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb16, label %bb17
bb16:
  %t66 = load i64, ptr %l25, !tbaa !24
  %t67 = load i64, ptr %l28, !tbaa !24
  %t68 = icmp sle i64 %t66, %t67
  store i1 %t68, ptr %l31, !tbaa !21
  %t69 = load i1, ptr %l31, !tbaa !21
  br i1 %t69, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @.c51)
  unreachable
bb18:
  %t70 = load i64, ptr %l28, !tbaa !24
  %t71 = load i64, ptr %l29, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  store i1 %t72, ptr %l32, !tbaa !21
  %t73 = load i1, ptr %l32, !tbaa !21
  br i1 %t73, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c51)
  unreachable
bb20:
  %t74 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l25, !tbaa !24
  %t77 = load i64, ptr %l28, !tbaa !24
  %t78 = getelementptr i8, ptr %t75, i64 %t76
  %t79 = sub i64 %t77, %t76
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l33, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t82, ptr %l34, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t83, ptr %l35, !tbaa !27
  %t84 = load i64, ptr %l1, !tbaa !24
  store i64 %t84, ptr %l36, !tbaa !24
  %t85 = load i64, ptr %l3, !tbaa !24
  store i64 %t85, ptr %l37, !tbaa !24
  %t86 = load i64, ptr %l36, !tbaa !24
  %t87 = load i64, ptr %l37, !tbaa !24
  %t88 = sub i64 %t86, %t87
  store i64 %t88, ptr %l38, !tbaa !24
  %t89 = load i32, ptr %l23, !tbaa !23
  %t90 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = load i64, ptr %l38, !tbaa !24
  %t94 = call i64 @read(i32 %t89, ptr %t91, i64 %t93)
  store i64 %t94, ptr %l39
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c51)
  unreachable
bb22:
  %t95 = load i64, ptr %l39, !tbaa !24
  store i64 %t95, ptr %l4, !tbaa !24
  %t96 = load i64, ptr %l4, !tbaa !24
  store i64 %t96, ptr %l40, !tbaa !24
  %t97 = load i64, ptr %l40, !tbaa !24
  %t98 = icmp slt i64 %t97, 0
  store i1 %t98, ptr %l41, !tbaa !21
  %t99 = load i1, ptr %l41, !tbaa !21
  br i1 %t99, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t100 = call i32 @__olang_err()
  store i32 %t100, ptr %l42
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t101 = load i32, ptr %l42, !tbaa !23
  %t102 = call i32 @std_2fos_2eraise(i32 %t101)
  store i32 %t102, ptr %l43
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb27, label %ok.104
ok.104:
  br label %bb26
bb26:
  br label %bb28
bb27:
  %t105 = load i32, ptr %l43, !tbaa !23
  %t106 = lshr i32 %t105, 16
  %t107 = and i32 %t105, 65535
  %t108 = icmp eq i32 %t106, 1
  %t109 = select i1 %t108, i32 1, i32 0
  %t110 = icmp eq i32 %t105, 0
  %t111 = shl i32 %t109, 16
  %t112 = or i32 %t111, %t107
  %t113 = select i1 %t110, i32 0, i32 %t112
  store i32 %t113, ptr %l44, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t114 = load i32, ptr %l44, !tbaa !23
  %t115 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t114, 0
  store { i32, { i64, ptr } } %t115, ptr %rv
  br label %ret
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t116 = load i64, ptr %l4, !tbaa !24
  store i64 %t116, ptr %l45, !tbaa !24
  %t117 = load i64, ptr %l45, !tbaa !24
  %t118 = icmp eq i64 %t117, 0
  store i1 %t118, ptr %l46, !tbaa !21
  %t119 = load i1, ptr %l46, !tbaa !21
  br i1 %t119, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  store i32 65542, ptr %l47, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t120 = load i32, ptr %l47, !tbaa !23
  %t121 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t120, 0
  store { i32, { i64, ptr } } %t121, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t122 = load i64, ptr %l3, !tbaa !24
  store i64 %t122, ptr %l48, !tbaa !24
  %t123 = load i64, ptr %l4, !tbaa !24
  store i64 %t123, ptr %l49, !tbaa !24
  %t124 = load i64, ptr %l48, !tbaa !24
  %t125 = load i64, ptr %l49, !tbaa !24
  %t126 = add i64 %t124, %t125
  store i64 %t126, ptr %l50, !tbaa !24
  %t127 = load i64, ptr %l50, !tbaa !24
  store i64 %t127, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  br label %bb12
bb34:
  %t128 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t128, ptr %l51, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t129 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t130 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t129, 1
  store { i32, { i64, ptr } } %t130, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fos_2eremoveTree(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l51 = alloca i64
  %l52 = alloca i32
  %l53 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l8, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l9, !tbaa !21
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l10, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s2, ptr %t9, i64 %t10)
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d52 }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr @.d52 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t11, i64 %t12)
  %t13 = load ptr, ptr %s2
  %t14 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t15 = load i64, ptr %t14
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t13, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l11, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t19 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t19, ptr %l1, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l12, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t21, ptr %l13, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = call i32 @remove(ptr %t23)
  store i32 %t25, ptr %l14
  br label %bb4
bb4:
  %t26 = load i32, ptr %l14, !tbaa !23
  %t27 = icmp eq i32 %t26, 0
  store i1 %t27, ptr %l15, !tbaa !21
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t29 = call i32 @__olang_err()
  store i32 %t29, ptr %l16
  br label %bb8
bb8:
  %t30 = load i32, ptr %l16, !tbaa !23
  store i32 %t30, ptr %l2, !tbaa !23
  %t31 = load i32, ptr %l2, !tbaa !23
  store i32 %t31, ptr %l17, !tbaa !23
  %t32 = load i32, ptr %l17, !tbaa !23
  %t33 = icmp eq i32 %t32, 1
  store i1 %t33, ptr %l18, !tbaa !21
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = load i32, ptr %l2, !tbaa !23
  store i32 %t35, ptr %l19, !tbaa !23
  %t36 = load i32, ptr %l19, !tbaa !23
  %t37 = icmp ne i32 %t36, 6
  store i1 %t37, ptr %l20, !tbaa !21
  %t38 = load i1, ptr %l20, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t39 = load i32, ptr %l2, !tbaa !23
  store i32 %t39, ptr %l22, !tbaa !23
  %t40 = load i32, ptr %l22, !tbaa !23
  %t41 = icmp ne i32 %t40, 2
  store i1 %t41, ptr %l23, !tbaa !21
  %t42 = load i1, ptr %l23, !tbaa !21
  store i1 %t42, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l21, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t44 = load i32, ptr %l2, !tbaa !23
  store i32 %t44, ptr %l24, !tbaa !23
  %t45 = load i32, ptr %l24, !tbaa !23
  %t46 = call i32 @std_2fos_2eraise(i32 %t45)
  store i32 %t46, ptr %l25
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb18, label %ok.48
ok.48:
  br label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb19
bb18:
  %t49 = load i32, ptr %l25, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  store i32 %t57, ptr %l26, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l26, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t59, ptr %l27, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t61 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s6, { i64, ptr } %t60)
  %t62 = extractvalue { i32, { i64, ptr } } %t61, 1
  %t63 = extractvalue { i32, { i64, ptr } } %t61, 0
  store i32 %t63, ptr %l29
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb22, label %ok.65
ok.65:
  store { i64, ptr } %t62, ptr %l28
  br label %bb21
bb21:
  %t66 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t66, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t67, ptr %l31, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l32, !tbaa !24
  %t70 = load i64, ptr %l32, !tbaa !24
  store i64 %t70, ptr %l5, !tbaa !24
  br label %bb23
bb22:
  %t71 = load i32, ptr %l29, !tbaa !23
  %t72 = lshr i32 %t71, 16
  %t73 = and i32 %t71, 65535
  %t74 = icmp eq i32 %t72, 1
  %t75 = select i1 %t74, i32 1, i32 0
  %t76 = icmp eq i32 %t71, 0
  %t77 = shl i32 %t75, 16
  %t78 = or i32 %t77, %t73
  %t79 = select i1 %t76, i32 0, i32 %t78
  store i32 %t79, ptr %l30, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i32, ptr %l30, !tbaa !23
  store i32 %t80, ptr %rv
  br label %ret
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  %t81 = load i64, ptr %l4, !tbaa !24
  store i64 %t81, ptr %l33, !tbaa !24
  %t82 = load i64, ptr %l5, !tbaa !24
  store i64 %t82, ptr %l34, !tbaa !24
  %t83 = load i64, ptr %l33, !tbaa !24
  %t84 = load i64, ptr %l34, !tbaa !24
  %t85 = icmp slt i64 %t83, %t84
  store i1 %t85, ptr %l35, !tbaa !21
  %t86 = load i1, ptr %l35, !tbaa !21
  %t87 = xor i1 %t86, true
  store i1 %t87, ptr %l36, !tbaa !21
  %t88 = load i1, ptr %l36, !tbaa !21
  br i1 %t88, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t89, ptr %l37, !tbaa !27
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l38, !tbaa !24
  %t91 = load i64, ptr %l38, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %t93, i64 %t91
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !37
  store { i64, ptr } %t95, ptr %l39, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t96, ptr %l6, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t97, ptr %l40, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t98, ptr %l41, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t99 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  call void @__olang_sb_put(ptr %s8, ptr %t100, i64 %t101)
  %t102 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 1
  %t103 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t102, i64 %t103)
  %t104 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  call void @__olang_sb_put(ptr %s8, ptr %t105, i64 %t106)
  %t107 = load ptr, ptr %s8
  %t108 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t109 = load i64, ptr %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t107, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l42, !tbaa !27
  call void @__olang_sb_done(ptr %s8)
  %t113 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l43, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t121 = call i32 @std_2fos_2eremoveTree(ptr %s7, { i64, ptr } %t120)
  store i32 %t121, ptr %l44
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb28, label %ok.123
ok.123:
  br label %bb27
bb27:
  br label %bb29
bb28:
  %t124 = load i32, ptr %l44, !tbaa !23
  %t125 = lshr i32 %t124, 16
  %t126 = and i32 %t124, 65535
  %t127 = icmp eq i32 %t125, 1
  %t128 = select i1 %t127, i32 1, i32 0
  %t129 = icmp eq i32 %t124, 0
  %t130 = shl i32 %t128, 16
  %t131 = or i32 %t130, %t126
  %t132 = select i1 %t129, i32 0, i32 %t131
  store i32 %t132, ptr %l45, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t133 = load i32, ptr %l45, !tbaa !23
  store i32 %t133, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t134 = load i64, ptr %l4, !tbaa !24
  store i64 %t134, ptr %l46, !tbaa !24
  %t135 = load i64, ptr %l46, !tbaa !24
  %t136 = add i64 %t135, 1
  store i64 %t136, ptr %l47, !tbaa !24
  %t137 = load i64, ptr %l47, !tbaa !24
  store i64 %t137, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb23
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t138 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t138, ptr %l48, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t139, ptr %l49, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = call i32 @remove(ptr %t141)
  store i32 %t143, ptr %l50
  br label %bb33
bb33:
  %t144 = load i32, ptr %l50, !tbaa !23
  %t145 = sext i32 %t144 to i64
  store i64 %t145, ptr %l51, !tbaa !24
  %t146 = load i64, ptr %l51, !tbaa !24
  %t147 = call i32 @std_2fos_2echeck(i64 %t146)
  store i32 %t147, ptr %l52
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb35, label %ok.149
ok.149:
  br label %bb34
bb34:
  br label %bb36
bb35:
  %t150 = load i32, ptr %l52, !tbaa !23
  %t151 = lshr i32 %t150, 16
  %t152 = and i32 %t150, 65535
  %t153 = icmp eq i32 %t151, 1
  %t154 = select i1 %t153, i32 1, i32 0
  %t155 = icmp eq i32 %t150, 0
  %t156 = shl i32 %t154, 16
  %t157 = or i32 %t156, %t152
  %t158 = select i1 %t155, i32 0, i32 %t157
  store i32 %t158, ptr %l53, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t159 = load i32, ptr %l53, !tbaa !23
  store i32 %t159, ptr %rv
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWait(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca [1 x i32]
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca %"std/os:Output"
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca %"std/os:Output"
  %l20 = alloca i32
  %l21 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t2, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l3, !tbaa !21
  %t5 = load i1, ptr %l3, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65542, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t6, 0
  store { i32, %"std/os:Output" } %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store [1 x i32] zeroinitializer, ptr %l1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"std/os:Process", ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  store ptr %l1, ptr %l7
  %t12 = load ptr, ptr %l7
  %t13 = insertvalue { i64, ptr } undef, i64 1, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = load i32, ptr %l6, !tbaa !23
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = call i32 @waitpid(i32 %t16, ptr %t18, i32 0)
  store i32 %t20, ptr %l10
  br label %bb4
bb4:
  %t21 = load i32, ptr %l10, !tbaa !23
  %t22 = icmp slt i32 %t21, 0
  store i1 %t22, ptr %l11, !tbaa !21
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l12, !tbaa !29
  %t25 = call i32 @__olang_err()
  store i32 %t25, ptr %l13
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i32, ptr %l13, !tbaa !23
  %t28 = call i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t28, ptr %l14
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb9, label %ok.30
ok.30:
  br label %bb8
bb8:
  br label %bb10
bb9:
  %t31 = load i32, ptr %l14, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 1, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  store i32 %t39, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i32, ptr %l15, !tbaa !23
  %t41 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t40, 0
  store { i32, %"std/os:Output" } %t41, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l17, !tbaa !29
  %t43 = getelementptr [1 x i32], ptr %l1, i64 0, i64 0
  %t44 = load i32, ptr %t43, !tbaa !33
  store i32 %t44, ptr %l18, !tbaa !23
  %t45 = load ptr, ptr %l17, !tbaa !29
  %t46 = load i32, ptr %l18, !tbaa !23
  %t47 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %v1, ptr %t45, i32 %t46)
  %t48 = extractvalue { i32, %"std/os:Output" } %t47, 1
  %t49 = extractvalue { i32, %"std/os:Output" } %t47, 0
  store i32 %t49, ptr %l20
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb13, label %ok.51
ok.51:
  store %"std/os:Output" %t48, ptr %l19
  br label %bb12
bb12:
  %t52 = load %"std/os:Output", ptr %l19
  store %"std/os:Output" %t52, ptr %l16
  br label %bb14
bb13:
  %t53 = load i32, ptr %l20, !tbaa !23
  %t54 = lshr i32 %t53, 16
  %t55 = and i32 %t53, 65535
  %t56 = icmp eq i32 %t54, 1
  %t57 = select i1 %t56, i32 1, i32 0
  %t58 = icmp eq i32 %t53, 0
  %t59 = shl i32 %t57, 16
  %t60 = or i32 %t59, %t55
  %t61 = select i1 %t58, i32 0, i32 %t60
  store i32 %t61, ptr %l21, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t62 = load i32, ptr %l21, !tbaa !23
  %t63 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t62, 0
  store { i32, %"std/os:Output" } %t63, ptr %rv
  br label %ret
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load %"std/os:Output", ptr %l16
  %t65 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t64, 1
  store { i32, %"std/os:Output" } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i32
  %l17 = alloca %"std/os:Output"
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca %"std/os:Output"
  %l44 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t2, i32 0, i32 4
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = ashr i32 %t5, 8
  store i32 %t6, ptr %l5, !tbaa !23
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = and i32 %t7, 255
  store i32 %t8, ptr %l6, !tbaa !23
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l1, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = and i32 %t11, 127
  store i32 %t12, ptr %l8, !tbaa !23
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = icmp ne i32 %t13, 0
  store i1 %t14, ptr %l9, !tbaa !21
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l10, !tbaa !23
  %t17 = load i32, ptr %l10, !tbaa !23
  %t18 = and i32 %t17, 127
  store i32 %t18, ptr %l11, !tbaa !23
  %t19 = load i32, ptr %l11, !tbaa !23
  %t20 = add i32 128, %t19
  store i32 %t20, ptr %l12, !tbaa !23
  %t21 = load i32, ptr %l12, !tbaa !23
  store i32 %t21, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = getelementptr %"std/os:Process", ptr %t23, i32 0, i32 3
  %t25 = load i1, ptr %t24, !tbaa !21
  store i1 %t25, ptr %l14, !tbaa !21
  %t26 = load i1, ptr %l14, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l15, !tbaa !21
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i32, ptr %l2, !tbaa !23
  store i32 %t29, ptr %l16, !tbaa !23
  %t30 = load i32, ptr %l16, !tbaa !23
  %t31 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t30, { i64, ptr } { i64 0, ptr @.d54 }, { i64, ptr } { i64 0, ptr @.d55 })
  store %"std/os:Output" %t31, ptr %l17
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t32 = load %"std/os:Output", ptr %l17
  %t33 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t32, 1
  store { i32, %"std/os:Output" } %t33, ptr %rv
  br label %ret
bb7:
  %t34 = load i32, ptr %l2, !tbaa !23
  store i32 %t34, ptr %l18, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l20, !tbaa !29
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = getelementptr %"std/os:Process", ptr %t36, i32 0, i32 1
  %t38 = load i32, ptr %t37, !tbaa !23
  store i32 %t38, ptr %l21, !tbaa !23
  %t39 = load i32, ptr %l21, !tbaa !23
  %t40 = call { i32, { i64, ptr } } @std_2fos_2ereadBack(ptr %v1, i32 %t39)
  %t41 = extractvalue { i32, { i64, ptr } } %t40, 1
  %t42 = extractvalue { i32, { i64, ptr } } %t40, 0
  store i32 %t42, ptr %l23
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb9, label %ok.44
ok.44:
  store { i64, ptr } %t41, ptr %l22
  br label %bb8
bb8:
  %t45 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t45, ptr %l19, !tbaa !27
  br label %bb12
bb9:
  %t46 = load i32, ptr %l23, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  store i32 %t54, ptr %l24, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s3
  store %olang.scope zeroinitializer, ptr %s4
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l25, !tbaa !29
  %t56 = load ptr, ptr %l25, !tbaa !29
  %t57 = getelementptr %"std/os:Process", ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57, !tbaa !23
  store i32 %t58, ptr %l26, !tbaa !23
  %t59 = load i32, ptr %l26, !tbaa !23
  %t60 = call i32 @close(i32 %t59)
  store i32 %t60, ptr %l27
  br label %bb10
bb10:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l28, !tbaa !29
  %t62 = load ptr, ptr %l28, !tbaa !29
  %t63 = getelementptr %"std/os:Process", ptr %t62, i32 0, i32 2
  %t64 = load i32, ptr %t63, !tbaa !23
  store i32 %t64, ptr %l29, !tbaa !23
  %t65 = load i32, ptr %l29, !tbaa !23
  %t66 = call i32 @close(i32 %t65)
  store i32 %t66, ptr %l30
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t67 = load i32, ptr %l24, !tbaa !23
  %t68 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t67, 0
  store { i32, %"std/os:Output" } %t68, ptr %rv
  br label %ret
bb12:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l32, !tbaa !29
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = getelementptr %"std/os:Process", ptr %t70, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  store i32 %t72, ptr %l33, !tbaa !23
  %t73 = load i32, ptr %l33, !tbaa !23
  %t74 = call { i32, { i64, ptr } } @std_2fos_2ereadBack(ptr %v1, i32 %t73)
  %t75 = extractvalue { i32, { i64, ptr } } %t74, 1
  %t76 = extractvalue { i32, { i64, ptr } } %t74, 0
  store i32 %t76, ptr %l35
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb14, label %ok.78
ok.78:
  store { i64, ptr } %t75, ptr %l34
  br label %bb13
bb13:
  %t79 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t79, ptr %l31, !tbaa !27
  br label %bb17
bb14:
  %t80 = load i32, ptr %l35, !tbaa !23
  %t81 = lshr i32 %t80, 16
  %t82 = and i32 %t80, 65535
  %t83 = icmp eq i32 %t81, 1
  %t84 = select i1 %t83, i32 1, i32 0
  %t85 = icmp eq i32 %t80, 0
  %t86 = shl i32 %t84, 16
  %t87 = or i32 %t86, %t82
  %t88 = select i1 %t85, i32 0, i32 %t87
  store i32 %t88, ptr %l36, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s5
  store %olang.scope zeroinitializer, ptr %s6
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l37, !tbaa !29
  %t90 = load ptr, ptr %l37, !tbaa !29
  %t91 = getelementptr %"std/os:Process", ptr %t90, i32 0, i32 1
  %t92 = load i32, ptr %t91, !tbaa !23
  store i32 %t92, ptr %l38, !tbaa !23
  %t93 = load i32, ptr %l38, !tbaa !23
  %t94 = call i32 @close(i32 %t93)
  store i32 %t94, ptr %l39
  br label %bb15
bb15:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l40, !tbaa !29
  %t96 = load ptr, ptr %l40, !tbaa !29
  %t97 = getelementptr %"std/os:Process", ptr %t96, i32 0, i32 2
  %t98 = load i32, ptr %t97, !tbaa !23
  store i32 %t98, ptr %l41, !tbaa !23
  %t99 = load i32, ptr %l41, !tbaa !23
  %t100 = call i32 @close(i32 %t99)
  store i32 %t100, ptr %l42
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t101 = load i32, ptr %l36, !tbaa !23
  %t102 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t101, 0
  store { i32, %"std/os:Output" } %t102, ptr %rv
  br label %ret
bb17:
  %t103 = load i32, ptr %l18, !tbaa !23
  %t104 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t106 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t103, { i64, ptr } %t104, { i64, ptr } %t105)
  store %"std/os:Output" %t106, ptr %l43
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s7
  store %olang.scope zeroinitializer, ptr %s8
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l44, !tbaa !29
  %t108 = load ptr, ptr %l44, !tbaa !29
  %t109 = getelementptr %"std/os:Process", ptr %t108, i32 0, i32 1
  %t110 = load i32, ptr %t109, !tbaa !23
  store i32 %t110, ptr %l45, !tbaa !23
  %t111 = load i32, ptr %l45, !tbaa !23
  %t112 = call i32 @close(i32 %t111)
  store i32 %t112, ptr %l46
  br label %bb19
bb19:
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l47, !tbaa !29
  %t114 = load ptr, ptr %l47, !tbaa !29
  %t115 = getelementptr %"std/os:Process", ptr %t114, i32 0, i32 2
  %t116 = load i32, ptr %t115, !tbaa !23
  store i32 %t116, ptr %l48, !tbaa !23
  %t117 = load i32, ptr %l48, !tbaa !23
  %t118 = call i32 @close(i32 %t117)
  store i32 %t118, ptr %l49
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t119 = load %"std/os:Output", ptr %l43
  %t120 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t119, 1
  store { i32, %"std/os:Output" } %t120, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t2, i32 0, i32 4
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"std/os:Process", ptr %t5, i32 0, i32 3
  %t7 = load i1, ptr %t6, !tbaa !21
  store i1 %t7, ptr %l4, !tbaa !21
  %t8 = load i1, ptr %l4, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l5, !tbaa !29
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = getelementptr %"std/os:Process", ptr %t10, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l6, !tbaa !23
  %t13 = load i32, ptr %l6, !tbaa !23
  %t14 = call i32 @close(i32 %t13)
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"std/os:Process", ptr %t16, i32 0, i32 2
  %t18 = load i32, ptr %t17, !tbaa !23
  store i32 %t18, ptr %l9, !tbaa !23
  %t19 = load i32, ptr %l9, !tbaa !23
  %t20 = call i32 @close(i32 %t19)
  store i32 %t20, ptr %l10
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t21 = load i32, ptr %l1, !tbaa !23
  store i32 %t21, ptr %l11, !tbaa !23
  %t22 = load i32, ptr %l11, !tbaa !23
  %t23 = call i32 @std_2fos_2eraise(i32 %t22)
  store i32 %t23, ptr %l12
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb7, label %ok.25
ok.25:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t26 = load i32, ptr %l12, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  store i32 %t34, ptr %l13, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t35 = load i32, ptr %l13, !tbaa !23
  store i32 %t35, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2fos_2etempDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = icmp sgt i64 %t4, 0
  store i1 %t5, ptr %l4, !tbaa !21
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s2, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s2
  %t12 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t17 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t17, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t18 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 6, ptr @.d56 })
  %t19 = extractvalue { i32, { i64, ptr } } %t18, 1
  %t20 = extractvalue { i32, { i64, ptr } } %t18, 0
  store i32 %t20, ptr %l9
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb5, label %ok.22
ok.22:
  store { i64, ptr } %t19, ptr %l8
  br label %bb4
bb4:
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  store { i64, ptr } { i64 0, ptr @.d57 }, ptr %l10, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t24, ptr %l11, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l12, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t32, ptr %l7, !tbaa !27
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t33, ptr %l1, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t34, ptr %l13, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l14, !tbaa !24
  %t37 = load i64, ptr %l14, !tbaa !24
  %t38 = icmp sgt i64 %t37, 0
  store i1 %t38, ptr %l15, !tbaa !21
  %t39 = load i1, ptr %l15, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t40, ptr %l16, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t41 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  call void @__olang_sb_put(ptr %s4, ptr %t42, i64 %t43)
  %t44 = load ptr, ptr %s4
  %t45 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t46 = load i64, ptr %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t44, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l17, !tbaa !27
  call void @__olang_sb_done(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store { i64, ptr } { i64 4, ptr @.d58 }, ptr %l18, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t51, ptr %l19, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l20, !tbaa !24
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = mul i64 %t54, 1
  %t56 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l21, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l20, !tbaa !24
  %t64 = mul i64 %t63, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t60, ptr %t62, i64 %t64, i1 false)
  %t65 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t65, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t66 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t66, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/os:FileInfo" @std_2fos_3aFileInfo_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/os:FileInfo"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/os:FileInfo"
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l6
  %t2 = load i32, ptr %l6
  store i32 %t2, ptr %l3
  %t3 = load i64, ptr %l1, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load i64, ptr %l7, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load i32, ptr %l3
  %t8 = insertvalue %"std/os:FileInfo" undef, i32 %t7, 0
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = insertvalue %"std/os:FileInfo" %t8, i64 %t9, 1
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = insertvalue %"std/os:FileInfo" %t10, i64 %t11, 2
  store %"std/os:FileInfo" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"std/os:FileInfo", ptr %l9
  store %"std/os:FileInfo" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:FileInfo", ptr %rv
  ret %"std/os:FileInfo" %rr
}

define dso_local %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/os:Output"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/os:Output"
  store i32 %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %l6, !tbaa !23
  %t2 = load i32, ptr %l6, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l7, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = insertvalue %"std/os:Output" undef, i32 %t7, 0
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t10 = insertvalue %"std/os:Output" %t8, { i64, ptr } %t9, 1
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t12 = insertvalue %"std/os:Output" %t10, { i64, ptr } %t11, 2
  store %"std/os:Output" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"std/os:Output", ptr %l9
  store %"std/os:Output" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:Output", ptr %rv
  ret %"std/os:Output" %rr
}

define dso_local %"std/os:Process" @std_2fos_3aProcess_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca %"std/os:Process"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/os:Process"
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %l9, !tbaa !23
  %t2 = load i32, ptr %l9, !tbaa !23
  store i32 %t2, ptr %l4, !tbaa !23
  %t3 = load i32, ptr %l1, !tbaa !23
  store i32 %t3, ptr %l10, !tbaa !23
  %t4 = load i32, ptr %l10, !tbaa !23
  store i32 %t4, ptr %l5, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  store i32 %t5, ptr %l11, !tbaa !23
  %t6 = load i32, ptr %l11, !tbaa !23
  store i32 %t6, ptr %l6, !tbaa !23
  %t7 = load i1, ptr %l3, !tbaa !21
  store i1 %t7, ptr %l12, !tbaa !21
  %t8 = load i1, ptr %l12, !tbaa !21
  store i1 %t8, ptr %l7, !tbaa !21
  store i1 false, ptr %l8, !tbaa !21
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = insertvalue %"std/os:Process" undef, i32 %t9, 0
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = insertvalue %"std/os:Process" %t10, i32 %t11, 1
  %t13 = load i32, ptr %l6, !tbaa !23
  %t14 = insertvalue %"std/os:Process" %t12, i32 %t13, 2
  %t15 = load i1, ptr %l7, !tbaa !21
  %t16 = insertvalue %"std/os:Process" %t14, i1 %t15, 3
  %t17 = load i1, ptr %l8, !tbaa !21
  %t18 = insertvalue %"std/os:Process" %t16, i1 %t17, 4
  store %"std/os:Process" %t18, ptr %l13
  call void @__olang_scope_close(ptr %s0)
  %t19 = load %"std/os:Process", ptr %l13
  store %"std/os:Process" %t19, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:Process", ptr %rv
  ret %"std/os:Process" %rr
}

declare i64 @__olang_arg_count()
declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [44 x i8] c"std/os.olang:92: array length out of range\0A\00"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare i64 @__olang_arg(i64, ptr, i64)
@.c1 = private unnamed_addr constant [44 x i8] c"std/os.olang:94: array length out of range\0A\00"
declare i32 @close(i32)
declare void @__olang_sb_put(ptr, ptr, i64)
@.d2 = private constant [1 x i8] c"\00"
declare void @__olang_sb_done(ptr)
declare i32 @creat(ptr, i32)
@.d3 = private constant [1 x i8] c"."
@.d4 = private constant [1 x i8] c"\00"
define internal i64 @olang_lambda_5(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  store { i64, ptr } %cv0, ptr %l1
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t2, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t3, ptr %l4, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = call i64 @__olang_env(ptr %t10, ptr %t13, i64 %t15)
  store i64 %t16, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i64, ptr %l9, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.c6 = private unnamed_addr constant [45 x i8] c"std/os.olang:199: array length out of range\0A\00"
@.d7 = private constant [1 x i8] c"\00"
declare i32 @__olang_exec(ptr, ptr, i64)
declare i32 @__olang_err()
@.d8 = private constant [1 x i8] c"\00"
declare i32 @__olang_stat(ptr, ptr)
declare void @exit(i32) noreturn
@.c9 = private unnamed_addr constant [44 x i8] c"std/os.olang:112: reached unreachable code\0A\00"
@.d10 = private constant [1 x i8] c"\00"
declare i32 @isatty(i32)
@.c11 = private unnamed_addr constant [45 x i8] c"std/os.olang:480: slice bounds out of range\0A\00"
@.d12 = private constant [1 x i8] c"\00"
declare i32 @mkdir(ptr, i32)
@.d13 = private constant [1 x i8] c"/"
@.d14 = private constant [1 x i8] c"/"
@.d15 = private constant [0 x i8] c""
@.d16 = private constant [1 x i8] c"/"
@.d17 = private constant [7 x i8] c"XXXXXX\00"
declare i32 @__olang_mkdtemp(ptr)
@.c18 = private unnamed_addr constant [45 x i8] c"std/os.olang:531: slice bounds out of range\0A\00"
declare void @__olang_on_crash(ptr, i64)
@.d19 = private constant [1 x i8] c"\00"
define internal i64 @olang_lambda_20(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  store { i64, ptr } %cv0, ptr %l1
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t2, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t3, ptr %l4, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = call i64 @__olang_dir(ptr %t10, ptr %t13, i64 %t15)
  store i64 %t16, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i64, ptr %l9, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.c21 = private unnamed_addr constant [45 x i8] c"std/os.olang:577: array length out of range\0A\00"
@.c22 = private unnamed_addr constant [45 x i8] c"std/os.olang:578: slice bounds out of range\0A\00"
@.d23 = private constant [1 x i8] c"\00"
define internal i1 @olang_lambda_24(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = call i32 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eCompare(ptr %v0, ptr %v1, { i64, ptr } %t3, { i64, ptr } %t4)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = icmp slt i32 %t6, 0
  store i1 %t7, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d25 = private constant [1 x i8] c"\00"
declare i32 @open(ptr, i32)
declare i64 @lseek(i32, i64, i32)
@.c26 = private unnamed_addr constant [45 x i8] c"std/os.olang:379: array length out of range\0A\00"
@.c27 = private unnamed_addr constant [45 x i8] c"std/os.olang:383: array length out of range\0A\00"
@.c28 = private unnamed_addr constant [45 x i8] c"std/os.olang:387: slice bounds out of range\0A\00"
declare i64 @read(i32, ptr, i64)
@.c29 = private unnamed_addr constant [45 x i8] c"std/os.olang:393: slice bounds out of range\0A\00"
@.d30 = private constant [1 x i8] c"\00"
declare i64 @readlink(ptr, ptr, i64)
@.c31 = private unnamed_addr constant [45 x i8] c"std/os.olang:551: array length out of range\0A\00"
@.c32 = private unnamed_addr constant [45 x i8] c"std/os.olang:555: array length out of range\0A\00"
@.c33 = private unnamed_addr constant [45 x i8] c"std/os.olang:559: slice bounds out of range\0A\00"
@.d34 = private constant [1 x i8] c"\00"
define internal i64 @olang_lambda_35(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  store { i64, ptr } %cv0, ptr %l1
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t2, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t3, ptr %l4, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = load i64, ptr %l8, !tbaa !24
  %t16 = call i64 @__olang_realpath(ptr %t10, ptr %t13, i64 %t15)
  store i64 %t16, ptr %l9
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i64, ptr %l9, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.d36 = private constant [1 x i8] c"\00"
declare i32 @remove(ptr)
@.c37 = private unnamed_addr constant [45 x i8] c"std/os.olang:504: slice bounds out of range\0A\00"
@.d38 = private constant [1 x i8] c"."
@.d39 = private constant [2 x i8] c".."
@.d40 = private constant [1 x i8] c"\00"
@.d41 = private constant [1 x i8] c"\00"
declare i32 @rename(ptr, ptr)
declare void @__olang_run_on_stack(i64, ptr, ptr)
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2estd_2fos_3aFileKind(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c42 = private unnamed_addr constant [45 x i8] c"std/os.olang:246: array length out of range\0A\00"
@.d43 = private constant [6 x i8] c"olang\00"
declare i32 @memfd_create(ptr, i32)
@.d44 = private constant [1 x i8] c"\00"
declare i32 @__olang_spawn(ptr, i64, i32, i32, i32, ptr)
@.d45 = private constant [1 x i8] c"\00"
@.c46 = private unnamed_addr constant [44 x i8] c"std/os.olang:74: array length out of range\0A\00"
@.c47 = private unnamed_addr constant [44 x i8] c"std/os.olang:77: array length out of range\0A\00"
@.c48 = private unnamed_addr constant [44 x i8] c"std/os.olang:81: slice bounds out of range\0A\00"
@.d49 = private constant [6 x i8] c"olang\00"
@.c50 = private unnamed_addr constant [45 x i8] c"std/os.olang:357: array length out of range\0A\00"
@.c51 = private unnamed_addr constant [45 x i8] c"std/os.olang:360: slice bounds out of range\0A\00"
@.d52 = private constant [1 x i8] c"\00"
@.d53 = private constant [1 x i8] c"/"
declare i32 @waitpid(i32, ptr, i32)
@.d54 = private constant [0 x i8] c""
@.d55 = private constant [0 x i8] c""
@.d56 = private constant [6 x i8] c"TMPDIR"
@.d57 = private constant [0 x i8] c""
@.d58 = private constant [4 x i8] c"/tmp"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare i64 @__olang_env(ptr, ptr, i64)
declare i64 @__olang_dir(ptr, ptr, i64)
declare i64 @__olang_realpath(ptr, ptr, i64)
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
@__olang_self = external thread_local(initialexec) global ptr
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eSort_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare i32 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eCompare(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
