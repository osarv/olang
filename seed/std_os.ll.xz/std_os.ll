; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/os:Process" = type { i32, i32, i32, i1, i1 }
%"std/os:FileInfo" = type { i32, i64, i64 }
define dso_local { i64, ptr } @std_2fos_2eArgs(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t13 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @__olang_arg_count()
  store i64 %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load i64, ptr %l9, !tbaa !24
  store i64 %t2, ptr %l0, !tbaa !24
  %t3 = load i64, ptr %l0, !tbaa !24
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = icmp sle i64 %t7, 576460752303423487
  br i1 %t8, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_2e089b9dcc6d7cfd_6f26744b60ea9b91)
  unreachable
bb4:
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t10, 16
  %t12 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t11)
  store i64 0, ptr %t13
  br label %fill.14
fill.14:
  %t17 = load i64, ptr %t13
  %t18 = icmp slt i64 %t17, %t10
  br i1 %t18, label %fillb.15, label %filld.16
fillb.15:
  %t19 = getelementptr { i64, ptr }, ptr %t12, i64 %t17
  store { i64, ptr } { i64 0, ptr @.d0 }, ptr %t19
  %t20 = add i64 %t17, 1
  store i64 %t20, ptr %t13
  br label %fill.14
filld.16:
  %t21 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t12, 1
  store { i64, ptr } %t22, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t24 = load i64, ptr %l0, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2e089b9dcc6d7cfd_6f26744b60ea9b91)
  unreachable
bb6:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb11
bb8:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l2, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l21, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l21, !tbaa !24
  store i64 %t52, ptr %l18, !tbaa !24
  br label %bb11
bb11:
  %t53 = load i64, ptr %l18, !tbaa !24
  store i64 %t53, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t62 = load i64, ptr %l2, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l7, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  store i64 %t72, ptr %l39, !tbaa !24
  %t73 = icmp sge i64 0, 0
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = mul i64 0, 1
  %t76 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 0, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  %t79 = load i64, ptr %l39, !tbaa !24
  %t81 = extractvalue { i64, ptr } %t78, 1
  %t82 = extractvalue { i64, ptr } %t78, 0
  %t83 = call i64 @__olang_arg(i64 %t79, ptr %t81, i64 0)
  store i64 %t83, ptr %l42
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_722c60a9fee6cfd0_5c8c3a8aa9ab1a84)
  unreachable
bb18:
  %t84 = load i64, ptr %l42, !tbaa !24
  %t85 = icmp sge i64 %t84, 0
  br i1 %t85, label %bb19, label %bb20
bb19:
  %t87 = load i64, ptr %l42, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t94 = extractvalue { i64, ptr } %t91, 0
  %t95 = extractvalue { i64, ptr } %t91, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l8, !tbaa !27
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t110 = extractvalue { i64, ptr } %t102, 1
  %t111 = extractvalue { i64, ptr } %t102, 0
  %t113 = call i64 @__olang_arg(i64 %t101, ptr %t110, i64 %t107)
  store i64 %t113, ptr %l53
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_722c60a9fee6cfd0_5c8c3a8aa9ab1a84)
  unreachable
bb21:
  %t114 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t114, ptr %l54, !tbaa !27
  %t115 = load i64, ptr %l7, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %t120, i64 %t115
  store { i64, ptr } %t116, ptr %t121, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l6, !tbaa !24
  br label %bb12
bb23:
  %t126 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t126, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @std_2fos_2eClose(i32 %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @close(i32 %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  %t5 = sext i32 %t4 to i64
  %t7 = call i32 @std_2fos_2echeck(i64 %t5)
  store i32 %t7, ptr %l4
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  store i32 %t18, ptr %rv
  br label %ret
bb4:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @std_2fos_2eCreate(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d1 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d1 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = extractvalue { i64, ptr } %t11, 0
  %t16 = call i32 @creat(ptr %t14, i32 438)
  store i32 %t16, ptr %l5
  br label %bb1
bb1:
  %t17 = load i32, ptr %l5, !tbaa !23
  store i32 %t17, ptr %l1, !tbaa !23
  %t18 = load i32, ptr %l1, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t22 = call i32 @std_2fos_2echeck(i64 %t20)
  store i32 %t22, ptr %l8
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb3, label %ok.24
ok.24:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = lshr i32 %t25, 16
  %t27 = and i32 %t25, 65535
  %t28 = icmp eq i32 %t26, 1
  %t29 = select i1 %t28, i32 1, i32 0
  %t30 = icmp eq i32 %t25, 0
  %t31 = shl i32 %t29, 16
  %t32 = or i32 %t31, %t27
  %t33 = select i1 %t30, i32 0, i32 %t32
  call void @__olang_scope_close(ptr %s0)
  %t35 = insertvalue { i32, i32 } zeroinitializer, i32 %t33, 0
  store { i32, i32 } %t35, ptr %rv
  br label %ret
bb4:
  %t36 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, i32 } zeroinitializer, i32 %t36, 1
  store { i32, i32 } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v0, { i64, ptr } { i64 1, ptr @.d2 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l1
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t6, ptr %l0, !tbaa !27
  br label %bb3
bb2:
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = lshr i32 %t7, 16
  %t9 = and i32 %t7, 65535
  %t10 = icmp eq i32 %t8, 1
  %t11 = select i1 %t10, i32 1, i32 0
  %t12 = icmp eq i32 %t7, 0
  %t13 = shl i32 %t11, 16
  %t14 = or i32 %t13, %t9
  %t15 = select i1 %t12, i32 0, i32 %t14
  %t17 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t15, 0
  store { i32, { i64, ptr } } %t17, ptr %rv
  br label %ret
bb3:
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t18, 1
  store { i32, { i64, ptr } } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t16 = alloca { { i64, ptr }, ptr }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t15 = ptrtoint ptr %t14 to i64
  %t17 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 0
  store { i64, ptr } %t11, ptr %t17, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t19 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 1
  store ptr %s0, ptr %t19, !tbaa !28
  %t20 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_4, 0
  %t21 = insertvalue { ptr, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { ptr, ptr } %t21, 0
  %t24 = extractvalue { ptr, ptr } %t21, 1
  %t25 = call { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %s0, ptr %v1, ptr %t23, ptr %t24)
  %t26 = extractvalue { i32, { i64, ptr } } %t25, 1
  %t27 = extractvalue { i32, { i64, ptr } } %t25, 0
  store i32 %t27, ptr %l8
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb2, label %ok.29
ok.29:
  store { i64, ptr } %t26, ptr %l7
  br label %bb1
bb1:
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  br label %bb6
bb2:
  %t31 = load i32, ptr %l8, !tbaa !23
  %t32 = ashr i32 %t31, 16
  %t34 = icmp eq i32 %t32, 1
  br i1 %t34, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t36 = load i32, ptr %l8, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  call void @__olang_scope_close(ptr %s0)
  %t46 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t44, 0
  store { i32, { i64, ptr } } %t46, ptr %rv
  br label %ret
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t48 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t48, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t50 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t49, 1
  store { i32, { i64, ptr } } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca %"std/os:Process"
  %l5 = alloca %"std/os:Process"
  %l10 = alloca %"std/os:Process"
  %l11 = alloca i32
  %l13 = alloca %"std/os:Output"
  %l15 = alloca %"std/os:Output"
  %l16 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t9 = call { i32, %"std/os:Process" } @std_2fos_2eStart(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
  %t10 = extractvalue { i32, %"std/os:Process" } %t9, 1
  %t11 = extractvalue { i32, %"std/os:Process" } %t9, 0
  store i32 %t11, ptr %l11
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13
ok.13:
  store %"std/os:Process" %t10, ptr %l10
  br label %bb1
bb1:
  %t14 = load %"std/os:Process", ptr %l10
  store %"std/os:Process" %t14, ptr %l5
  br label %bb3
bb2:
  %t15 = load i32, ptr %l11, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  call void @__olang_scope_close(ptr %s0)
  %t25 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t23, 0
  store { i32, %"std/os:Output" } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load %"std/os:Process", ptr %l5
  store %"std/os:Process" %t26, ptr %l4
  %t28 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWait(ptr %s0, ptr %v3, ptr %l4)
  %t29 = extractvalue { i32, %"std/os:Output" } %t28, 1
  %t30 = extractvalue { i32, %"std/os:Output" } %t28, 0
  store i32 %t30, ptr %l16
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb5, label %ok.32
ok.32:
  store %"std/os:Output" %t29, ptr %l15
  br label %bb4
bb4:
  %t33 = load %"std/os:Output", ptr %l15
  store %"std/os:Output" %t33, ptr %l13
  br label %bb6
bb5:
  %t34 = load i32, ptr %l16, !tbaa !23
  %t35 = lshr i32 %t34, 16
  %t36 = and i32 %t34, 65535
  %t37 = icmp eq i32 %t35, 1
  %t38 = select i1 %t37, i32 1, i32 0
  %t39 = icmp eq i32 %t34, 0
  %t40 = shl i32 %t38, 16
  %t41 = or i32 %t40, %t36
  %t42 = select i1 %t39, i32 0, i32 %t41
  call void @__olang_scope_close(ptr %s0)
  %t44 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t42, 0
  store { i32, %"std/os:Output" } %t44, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load %"std/os:Output", ptr %l13
  %t46 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t45, 1
  store { i32, %"std/os:Output" } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l30 = alloca { i64, ptr }
  %l33 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i32
  %l46 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i32
  %l52 = alloca i64
  %l62 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l92 = alloca i32
  %l93 = alloca i32
  %l94 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i32 65542, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l30, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %t26, i64 %t23
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !37
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  store i1 true, ptr %l7, !tbaa !21
  %t30 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t32 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t30, i8 0)
  %t33 = extractvalue { i32, i64 } %t32, 1
  %t34 = extractvalue { i32, i64 } %t32, 0
  store i32 %t34, ptr %l36
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb9, label %ok.36
ok.36:
  store i64 %t33, ptr %l35
  br label %bb8
bb8:
  %t37 = load i64, ptr %l35, !tbaa !24
  store i64 %t37, ptr %l33, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l7, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 65542, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = add i64 %t44, 1
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb4
bb16:
  store i1 true, ptr %l8, !tbaa !21
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t55, i8 0)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l49
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb18, label %ok.61
ok.61:
  store i64 %t58, ptr %l48
  br label %bb17
bb17:
  %t62 = load i64, ptr %l48, !tbaa !24
  store i64 %t62, ptr %l46, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l8, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i32 65542, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t66 = load i64, ptr %l2, !tbaa !24
  store i64 %t66, ptr %l52, !tbaa !24
  %t67 = load i64, ptr %l52, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb24, label %bb25
bb24:
  %t70 = load i64, ptr %l52, !tbaa !24
  %t71 = mul i64 %t70, 1
  %t72 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l13, !tbaa !24
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_c6732c6b36ef1233_192580cd7896553f)
  unreachable
bb26:
  store %olang.scope zeroinitializer, ptr %s10
  %t82 = load i64, ptr %l12, !tbaa !24
  %t83 = load i64, ptr %l13, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s10)
  br label %bb37
bb28:
  br label %bb29
bb29:
  %t90 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t90, ptr %l62, !tbaa !27
  %t91 = load i64, ptr %l12, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %t94, i64 %t91
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !37
  store { i64, ptr } %t96, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  store i64 %t102, ptr %l17, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s12
  %t104 = load i64, ptr %l16, !tbaa !24
  %t105 = load i64, ptr %l17, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s12)
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t112 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t112, ptr %l72, !tbaa !27
  %t113 = load i64, ptr %l16, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i8, ptr %t116, i64 %t113
  %t118 = load i8, ptr %t117, !tbaa !32
  %t120 = load i64, ptr %l10, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i8, ptr %t126, i64 %t120
  store i8 %t118, ptr %t127, !tbaa !32
  %t128 = load i64, ptr %l10, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb34
bb34:
  %t132 = load i64, ptr %l16, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l16, !tbaa !24
  br label %bb30
bb35:
  %t136 = load i64, ptr %l10, !tbaa !24
  %t138 = add i64 %t136, 1
  store i64 %t138, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb36
bb36:
  %t140 = load i64, ptr %l12, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l12, !tbaa !24
  br label %bb26
bb37:
  %t144 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t144, 1
  %t147 = extractvalue { i64, ptr } %t144, 0
  %t148 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 0
  %t150 = add i64 %t147, %t149
  %t151 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t146, i64 %t147)
  %t152 = getelementptr i8, ptr %t151, i64 %t147
  call void @olang_textcopy(ptr %t152, ptr %t148, i64 %t149)
  %t153 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t151, 1
  %t156 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t161 = extractvalue { i64, ptr } %t154, 1
  %t162 = extractvalue { i64, ptr } %t154, 0
  %t164 = extractvalue { i64, ptr } %t156, 1
  %t165 = extractvalue { i64, ptr } %t156, 0
  %t167 = call i32 @__olang_exec(ptr %t161, ptr %t164, i64 %t159)
  store i32 %t167, ptr %l92
  br label %bb38
bb38:
  %t168 = call i32 @__olang_err()
  store i32 %t168, ptr %l93
  br label %bb39
bb39:
  %t169 = load i32, ptr %l93, !tbaa !23
  %t170 = call i32 @std_2fos_2eraise(i32 %t169)
  store i32 %t170, ptr %l94
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb41, label %ok.172
ok.172:
  br label %bb40
bb40:
  br label %bb42
bb41:
  %t173 = load i32, ptr %l94, !tbaa !23
  %t174 = lshr i32 %t173, 16
  %t175 = and i32 %t173, 65535
  %t176 = icmp eq i32 %t174, 1
  %t177 = select i1 %t176, i32 1, i32 0
  %t178 = icmp eq i32 %t173, 0
  %t179 = shl i32 %t177, 16
  %t180 = or i32 %t179, %t175
  %t181 = select i1 %t178, i32 0, i32 %t180
  call void @__olang_scope_close(ptr %s0)
  store i32 %t181, ptr %rv
  br label %ret
bb42:
  call void @__olang_scope_close(ptr %s0)
  store i32 65542, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2eExecUntil(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, { i64, ptr } %a4) #0 {
entry:
  %l5 = alloca %"std/os:Process"
  %l6 = alloca %"std/os:Process"
  %l11 = alloca %"std/os:Process"
  %l12 = alloca i32
  %l14 = alloca %"std/os:Output"
  %l17 = alloca %"std/os:Output"
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t9 = call { i32, %"std/os:Process" } @std_2fos_2eStart(ptr %v0, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a2, i1 %a3, { i64, ptr } %a4)
  %t10 = extractvalue { i32, %"std/os:Process" } %t9, 1
  %t11 = extractvalue { i32, %"std/os:Process" } %t9, 0
  store i32 %t11, ptr %l12
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13
ok.13:
  store %"std/os:Process" %t10, ptr %l11
  br label %bb1
bb1:
  %t14 = load %"std/os:Process", ptr %l11
  store %"std/os:Process" %t14, ptr %l6
  br label %bb3
bb2:
  %t15 = load i32, ptr %l12, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  call void @__olang_scope_close(ptr %s0)
  %t25 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t23, 0
  store { i32, %"std/os:Output" } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load %"std/os:Process", ptr %l6
  store %"std/os:Process" %t26, ptr %l5
  %t30 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWaitUntil(ptr %s0, ptr %v1, ptr %v4, ptr %l5, ptr %a1)
  %t31 = extractvalue { i32, %"std/os:Output" } %t30, 1
  %t32 = extractvalue { i32, %"std/os:Output" } %t30, 0
  store i32 %t32, ptr %l18
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb5, label %ok.34
ok.34:
  store %"std/os:Output" %t31, ptr %l17
  br label %bb4
bb4:
  %t35 = load %"std/os:Output", ptr %l17
  store %"std/os:Output" %t35, ptr %l14
  br label %bb6
bb5:
  %t36 = load i32, ptr %l18, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t37, 2
  %t42 = select i1 %t41, i32 2, i32 %t40
  %t43 = icmp eq i32 %t36, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t38
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s0)
  %t48 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t46, 0
  store { i32, %"std/os:Output" } %t48, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t49 = load %"std/os:Output", ptr %l14
  %t50 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t49, 1
  store { i32, %"std/os:Output" } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca [3 x i64]
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [3 x i64] undef, i64 0, 0
  %t2 = insertvalue [3 x i64] %t1, i64 0, 1
  %t3 = insertvalue [3 x i64] %t2, i64 0, 2
  store [3 x i64] %t3, ptr %l1
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d6 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d6 }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t7, i64 %t8)
  %t13 = getelementptr i8, ptr %t12, i64 %t8
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t18 = insertvalue { i64, ptr } undef, i64 3, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %l1, 1
  %t22 = extractvalue { i64, ptr } %t15, 1
  %t23 = extractvalue { i64, ptr } %t15, 0
  %t25 = extractvalue { i64, ptr } %t19, 1
  %t26 = extractvalue { i64, ptr } %t19, 0
  %t27 = call i32 @__olang_stat(ptr %t22, ptr %t25)
  store i32 %t27, ptr %l9
  br label %bb1
bb1:
  %t28 = load i32, ptr %l9, !tbaa !23
  %t29 = icmp eq i32 %t28, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @std_2fos_2eExit(i32 %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @exit(i32 %a0)
  unreachable
bb1:
  call void @__olang_check_failed(ptr @olang_loc_bf01453b0cfded25_a369431636c6fdd9)
  unreachable
ret:
  ret void
}

define dso_local i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca [3 x i64]
  %l9 = alloca i32
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [3 x i64] undef, i64 0, 0
  %t2 = insertvalue [3 x i64] %t1, i64 0, 1
  %t3 = insertvalue [3 x i64] %t2, i64 0, 2
  store [3 x i64] %t3, ptr %l1
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d7 }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t7, i64 %t8)
  %t13 = getelementptr i8, ptr %t12, i64 %t8
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t18 = insertvalue { i64, ptr } undef, i64 3, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %l1, 1
  %t22 = extractvalue { i64, ptr } %t15, 1
  %t23 = extractvalue { i64, ptr } %t15, 0
  %t25 = extractvalue { i64, ptr } %t19, 1
  %t26 = extractvalue { i64, ptr } %t19, 0
  %t27 = call i32 @__olang_stat(ptr %t22, ptr %t25)
  store i32 %t27, ptr %l9
  br label %bb1
bb1:
  %t28 = load i32, ptr %l9, !tbaa !23
  %t29 = icmp eq i32 %t28, 0
  br i1 %t29, label %bb2, label %bb3
bb2:
  %t31 = getelementptr [3 x i64], ptr %l1, i64 0, i64 0
  %t32 = load i64, ptr %t31, !tbaa !34
  %t34 = icmp eq i64 %t32, 2
  store i1 %t34, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t36 = load i1, ptr %l11, !tbaa !21
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fos_2eIsTerminal(i32 %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @isatty(i32 %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t4, 1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @std_2fos_2eLink(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l8 = alloca i32
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d8 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = getelementptr i8, ptr %t20, i64 %t16
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t26 = extractvalue { i64, ptr } %t11, 1
  %t27 = extractvalue { i64, ptr } %t11, 0
  %t29 = extractvalue { i64, ptr } %t23, 1
  %t30 = extractvalue { i64, ptr } %t23, 0
  %t31 = call i32 @link(ptr %t26, ptr %t29)
  store i32 %t31, ptr %l8
  br label %bb1
bb1:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = sext i32 %t32 to i64
  %t35 = call i32 @std_2fos_2echeck(i64 %t33)
  store i32 %t35, ptr %l10
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb3, label %ok.37
ok.37:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t38 = load i32, ptr %l10, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 1, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s0)
  store i32 %t46, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2eMkDir(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = extractvalue { i64, ptr } %t11, 0
  %t16 = call i32 @mkdir(ptr %t14, i32 511)
  store i32 %t16, ptr %l4
  br label %bb1
bb1:
  %t17 = load i32, ptr %l4, !tbaa !23
  %t18 = sext i32 %t17 to i64
  %t20 = call i32 @std_2fos_2echeck(i64 %t18)
  store i32 %t20, ptr %l6
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb3, label %ok.22
ok.22:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t23 = load i32, ptr %l6, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  call void @__olang_scope_close(ptr %s0)
  store i32 %t31, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l10 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i64
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l57 = alloca i32
  %l59 = alloca i32
  %l63 = alloca i32
  %l66 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t1)
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i32 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 1, ptr %l1, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = add i64 %t7, 1
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb10
bb7:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l20, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l20, !tbaa !24
  store i64 %t37, ptr %l17, !tbaa !24
  br label %bb10
bb10:
  %t38 = load i64, ptr %l17, !tbaa !24
  store i64 %t38, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l1, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = icmp slt i64 %t57, %t60
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t65, ptr %l43, !tbaa !27
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i8, ptr %t69, i64 %t66
  %t71 = load i8, ptr %t70, !tbaa !32
  %t73 = icmp ne i8 %t71, 47
  store i1 %t73, ptr %l42, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t75 = load i1, ptr %l42, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb19:
  br label %bb20
bb20:
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = load i64, ptr %l6, !tbaa !24
  store i64 %t77, ptr %l48, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l49, !tbaa !24
  %t80 = icmp sge i64 0, 0
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load i64, ptr %l48, !tbaa !24
  %t83 = icmp sle i64 0, %t82
  br i1 %t83, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_1b39f3aec8a2d100_9d79a3da2d056474)
  unreachable
bb23:
  %t85 = load i64, ptr %l48, !tbaa !24
  %t86 = load i64, ptr %l49, !tbaa !24
  %t87 = icmp sle i64 %t85, %t86
  br i1 %t87, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_1b39f3aec8a2d100_9d79a3da2d056474)
  unreachable
bb25:
  %t89 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = load i64, ptr %l48, !tbaa !24
  %t92 = getelementptr i8, ptr %t90, i64 0
  %t93 = sub i64 %t91, 0
  %t94 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  store { i64, ptr } %t95, ptr %l7, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 1
  %t100 = extractvalue { i64, ptr } %t97, 0
  %t101 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr @.d11 }, 0
  %t103 = add i64 %t100, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t99, i64 %t100)
  %t105 = getelementptr i8, ptr %t104, i64 %t100
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  %t110 = extractvalue { i64, ptr } %t107, 1
  %t111 = extractvalue { i64, ptr } %t107, 0
  %t112 = call i32 @mkdir(ptr %t110, i32 511)
  store i32 %t112, ptr %l57
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_1b39f3aec8a2d100_9d79a3da2d056474)
  unreachable
bb27:
  %t113 = load i32, ptr %l57, !tbaa !23
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb28, label %bb29
bb28:
  %t116 = call i32 @__olang_err()
  store i32 %t116, ptr %l59
  br label %bb30
bb29:
  br label %bb41
bb30:
  %t117 = load i32, ptr %l59, !tbaa !23
  store i32 %t117, ptr %l8, !tbaa !23
  %t118 = load i32, ptr %l8, !tbaa !23
  %t120 = icmp ne i32 %t118, 2
  br i1 %t120, label %bb31, label %bb32
bb31:
  %t122 = load i32, ptr %l8, !tbaa !23
  %t124 = call i32 @std_2fos_2eraise(i32 %t122)
  store i32 %t124, ptr %l63
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb34, label %ok.126
ok.126:
  br label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb35
bb34:
  %t127 = load i32, ptr %l63, !tbaa !23
  %t128 = lshr i32 %t127, 16
  %t129 = and i32 %t127, 65535
  %t130 = icmp eq i32 %t128, 1
  %t131 = select i1 %t130, i32 1, i32 0
  %t132 = icmp eq i32 %t127, 0
  %t133 = shl i32 %t131, 16
  %t134 = or i32 %t133, %t129
  %t135 = select i1 %t132, i32 0, i32 %t134
  call void @__olang_scope_close(ptr %s3)
  store i32 %t135, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t139 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t137)
  store i1 %t139, ptr %l66
  br label %bb37
bb37:
  %t140 = load i1, ptr %l66, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s3)
  store i32 65539, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  %t144 = load i64, ptr %l5, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l5, !tbaa !24
  br label %bb11
bb43:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eMkTemp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l23 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l28 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 1, ptr @.d12 }, ptr %l7, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t4)
  store i1 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i1, ptr %l8, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t8 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65542, 0
  store { i32, { i64, ptr } } %t8, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = call { i64, ptr } @std_2fos_2etempDir(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t11, ptr %l11
  br label %bb5
bb5:
  %t12 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 1, ptr @.d13 })
  store i1 %t15, ptr %l13
  br label %bb6
bb6:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 0, ptr @.d14 }, ptr %l14, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 1, ptr @.d15 }, ptr %l14, !tbaa !27
  br label %bb9
bb9:
  %t17 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t18, 1
  %t23 = extractvalue { i64, ptr } %t18, 0
  %t25 = extractvalue { i64, ptr } %t17, 1
  %t26 = extractvalue { i64, ptr } %t17, 0
  %t27 = add i64 %t23, %t26
  %t29 = extractvalue { i64, ptr } %t20, 1
  %t30 = extractvalue { i64, ptr } %t20, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 7, ptr @.d16 }, 1
  %t33 = extractvalue { i64, ptr } { i64 7, ptr @.d16 }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t22, i64 %t23)
  %t36 = getelementptr i8, ptr %t35, i64 %t23
  call void @olang_textcopy(ptr %t36, ptr %t25, i64 %t26)
  %t37 = getelementptr i8, ptr %t36, i64 %t26
  call void @olang_textcopy(ptr %t37, ptr %t29, i64 %t30)
  %t38 = getelementptr i8, ptr %t37, i64 %t30
  call void @olang_textcopy(ptr %t38, ptr %t32, i64 %t33)
  %t39 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t35, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l4, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t49, 1
  %t54 = extractvalue { i64, ptr } %t49, 0
  %t55 = call i32 @__olang_mkdtemp(ptr %t53)
  store i32 %t55, ptr %l23
  br label %bb10
bb10:
  %t56 = load i32, ptr %l23, !tbaa !23
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb11, label %bb12
bb11:
  %t59 = call i32 @__olang_err()
  store i32 %t59, ptr %l25
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t60 = load i32, ptr %l25, !tbaa !23
  %t61 = call i32 @std_2fos_2eraise(i32 %t60)
  store i32 %t61, ptr %l26
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb15, label %ok.63
ok.63:
  br label %bb14
bb14:
  br label %bb16
bb15:
  %t64 = load i32, ptr %l26, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  call void @__olang_scope_close(ptr %s0)
  %t74 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t72, 0
  store { i32, { i64, ptr } } %t74, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t75, ptr %l28, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = sub i64 %t78, 1
  store i64 %t80, ptr %l31, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l32, !tbaa !24
  %t83 = icmp sge i64 0, 0
  br i1 %t83, label %bb18, label %bb19
bb18:
  %t85 = load i64, ptr %l31, !tbaa !24
  %t86 = icmp sle i64 0, %t85
  br i1 %t86, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_93142f54c4ba4464_592b0bc010c9eac8)
  unreachable
bb20:
  %t88 = load i64, ptr %l31, !tbaa !24
  %t89 = load i64, ptr %l32, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_93142f54c4ba4464_592b0bc010c9eac8)
  unreachable
bb22:
  %t92 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l31, !tbaa !24
  %t95 = getelementptr i8, ptr %t93, i64 0
  %t96 = sub i64 %t94, 0
  %t97 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  call void @__olang_scope_close(ptr %s0)
  %t100 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t98, 1
  store { i32, { i64, ptr } } %t100, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_93142f54c4ba4464_592b0bc010c9eac8)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @std_2fos_2eOnCrash(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = extractvalue { i64, ptr } %t1, 1
  %t9 = extractvalue { i64, ptr } %t1, 0
  call void @__olang_on_crash(ptr %t8, i64 %t6)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i32 } @std_2fos_2eOpen(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d17 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = extractvalue { i64, ptr } %t11, 0
  %t16 = call i32 @open(ptr %t14, i32 0)
  store i32 %t16, ptr %l5
  br label %bb1
bb1:
  %t17 = load i32, ptr %l5, !tbaa !23
  store i32 %t17, ptr %l1, !tbaa !23
  %t18 = load i32, ptr %l1, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t22 = call i32 @std_2fos_2echeck(i64 %t20)
  store i32 %t22, ptr %l8
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb3, label %ok.24
ok.24:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = lshr i32 %t25, 16
  %t27 = and i32 %t25, 65535
  %t28 = icmp eq i32 %t26, 1
  %t29 = select i1 %t28, i32 1, i32 0
  %t30 = icmp eq i32 %t25, 0
  %t31 = shl i32 %t29, 16
  %t32 = or i32 %t31, %t27
  %t33 = select i1 %t30, i32 0, i32 %t32
  call void @__olang_scope_close(ptr %s0)
  %t35 = insertvalue { i32, i32 } zeroinitializer, i32 %t33, 0
  store { i32, i32 } %t35, ptr %rv
  br label %ret
bb4:
  %t36 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t38 = insertvalue { i32, i32 } zeroinitializer, i32 %t36, 1
  store { i32, i32 } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i64, ptr } @std_2fos_2eQuote(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 1, ptr @.d18 }, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = icmp eq i8 %t57, 39
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t61, ptr %l39, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t62, ptr %l40, !tbaa !27
  %t63 = load i64, ptr %l2, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  store i64 %t64, ptr %l42, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l43, !tbaa !24
  %t67 = load i64, ptr %l41, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb13, label %bb14
bb12:
  br label %bb19
bb13:
  %t70 = load i64, ptr %l41, !tbaa !24
  %t71 = load i64, ptr %l42, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_3ae06a7cd351f714_4bcb8792cbdf34a0)
  unreachable
bb15:
  %t74 = load i64, ptr %l42, !tbaa !24
  %t75 = load i64, ptr %l43, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_3ae06a7cd351f714_4bcb8792cbdf34a0)
  unreachable
bb17:
  %t78 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l41, !tbaa !24
  %t81 = load i64, ptr %l42, !tbaa !24
  %t82 = getelementptr i8, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  %t86 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t90 = extractvalue { i64, ptr } %t85, 1
  %t91 = extractvalue { i64, ptr } %t85, 0
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 4, ptr @.d19 }, 1
  %t94 = extractvalue { i64, ptr } { i64 4, ptr @.d19 }, 0
  %t95 = add i64 %t92, %t94
  %t96 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t95)
  call void @olang_textcopy(ptr %t96, ptr %t87, i64 %t88)
  %t97 = getelementptr i8, ptr %t96, i64 %t88
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = getelementptr i8, ptr %t97, i64 %t91
  call void @olang_textcopy(ptr %t98, ptr %t93, i64 %t94)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t96, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l1, !tbaa !27
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l2, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_3ae06a7cd351f714_4bcb8792cbdf34a0)
  unreachable
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l7, !tbaa !24
  br label %bb7
bb21:
  %t117 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t117, ptr %l54, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t118, ptr %l55, !tbaa !27
  %t119 = load i64, ptr %l2, !tbaa !24
  store i64 %t119, ptr %l56, !tbaa !24
  %t120 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t120, 0
  store i64 %t123, ptr %l59, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  store i64 %t125, ptr %l60, !tbaa !24
  %t126 = load i64, ptr %l56, !tbaa !24
  %t127 = icmp sge i64 %t126, 0
  br i1 %t127, label %bb22, label %bb23
bb22:
  %t129 = load i64, ptr %l56, !tbaa !24
  %t130 = load i64, ptr %l59, !tbaa !24
  %t131 = icmp sle i64 %t129, %t130
  br i1 %t131, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_63ca89910fe1f481_50e57e01f8d90efd)
  unreachable
bb24:
  %t133 = load i64, ptr %l59, !tbaa !24
  %t134 = load i64, ptr %l60, !tbaa !24
  %t135 = icmp sle i64 %t133, %t134
  br i1 %t135, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_63ca89910fe1f481_50e57e01f8d90efd)
  unreachable
bb26:
  %t137 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = load i64, ptr %l56, !tbaa !24
  %t140 = load i64, ptr %l59, !tbaa !24
  %t141 = getelementptr i8, ptr %t138, i64 %t139
  %t142 = sub i64 %t140, %t139
  %t143 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t141, 1
  %t145 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t149 = extractvalue { i64, ptr } %t144, 1
  %t150 = extractvalue { i64, ptr } %t144, 0
  %t151 = add i64 %t147, %t150
  %t152 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 1
  %t153 = extractvalue { i64, ptr } { i64 1, ptr @.d20 }, 0
  %t154 = add i64 %t151, %t153
  %t155 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t154)
  call void @olang_textcopy(ptr %t155, ptr %t146, i64 %t147)
  %t156 = getelementptr i8, ptr %t155, i64 %t147
  call void @olang_textcopy(ptr %t156, ptr %t149, i64 %t150)
  %t157 = getelementptr i8, ptr %t156, i64 %t150
  call void @olang_textcopy(ptr %t157, ptr %t152, i64 %t153)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t155, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t166, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @olang_loc_63ca89910fe1f481_50e57e01f8d90efd)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l18 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t16 = alloca { { i64, ptr }, ptr }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d21 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t15 = ptrtoint ptr %t14 to i64
  %t17 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 0
  store { i64, ptr } %t11, ptr %t17, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t19 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 1
  store ptr %s0, ptr %t19, !tbaa !28
  %t20 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_22, 0
  %t21 = insertvalue { ptr, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { ptr, ptr } %t21, 0
  %t24 = extractvalue { ptr, ptr } %t21, 1
  %t25 = call { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %s0, ptr %v1, ptr %t23, ptr %t24)
  %t26 = extractvalue { i32, { i64, ptr } } %t25, 1
  %t27 = extractvalue { i32, { i64, ptr } } %t25, 0
  store i32 %t27, ptr %l10
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb2, label %ok.29
ok.29:
  store { i64, ptr } %t26, ptr %l9
  br label %bb1
bb1:
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t30, ptr %l6, !tbaa !27
  br label %bb3
bb2:
  %t31 = load i32, ptr %l10, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 1, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  call void @__olang_scope_close(ptr %s0)
  %t41 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t39, 0
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb3:
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t42, ptr %l2, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = icmp eq i64 %t45, 0
  br i1 %t47, label %bb4, label %bb5
bb4:
  %t49 = icmp sge i64 0, 0
  br i1 %t49, label %bb6, label %bb7
bb5:
  br label %bb10
bb6:
  %t51 = icmp sle i64 0, 576460752303423487
  br i1 %t51, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_879ad2febb339b7d_10a4c06fe5c76379)
  unreachable
bb8:
  %t53 = mul i64 0, 16
  %t54 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 0, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  call void @__olang_scope_close(ptr %s0)
  %t58 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t56, 1
  store { i32, { i64, ptr } } %t58, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_879ad2febb339b7d_10a4c06fe5c76379)
  unreachable
bb10:
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t59, ptr %l18, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = sub i64 %t62, 1
  store i64 %t64, ptr %l21, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l22, !tbaa !24
  %t67 = icmp sge i64 0, 0
  br i1 %t67, label %bb11, label %bb12
bb11:
  %t69 = load i64, ptr %l21, !tbaa !24
  %t70 = icmp sle i64 0, %t69
  br i1 %t70, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_2b89142fbf8fc460_df42bdef933d62c4)
  unreachable
bb13:
  %t72 = load i64, ptr %l21, !tbaa !24
  %t73 = load i64, ptr %l22, !tbaa !24
  %t74 = icmp sle i64 %t72, %t73
  br i1 %t74, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_2b89142fbf8fc460_df42bdef933d62c4)
  unreachable
bb15:
  %t76 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l21, !tbaa !24
  %t79 = getelementptr i8, ptr %t77, i64 0
  %t80 = sub i64 %t78, 0
  %t81 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s0, { i64, ptr } %t82, { i64, ptr } { i64 1, ptr @.d23 })
  store { i64, ptr } %t84, ptr %l27
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_2b89142fbf8fc460_df42bdef933d62c4)
  unreachable
bb17:
  %t85 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t85, ptr %l3, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_24, 0
  %t88 = insertvalue { ptr, ptr } %t87, ptr null, 1
  %t91 = extractvalue { ptr, ptr } %t88, 0
  %t92 = extractvalue { ptr, ptr } %t88, 1
  call void @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eSort_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v1, ptr %s0, { i64, ptr } %t86, ptr %t91, ptr %t92)
  br label %bb18
bb18:
  %t93 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t95 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t93, 1
  store { i32, { i64, ptr } } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l19 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l42 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l80 = alloca i32
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l97 = alloca i64
  %l100 = alloca i32
  %l101 = alloca i32
  %l102 = alloca i32
  %l110 = alloca i32
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %t1)
  store i1 %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load i1, ptr %l14, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t6 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65540, 0
  store { i32, { i64, ptr } } %t6, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = getelementptr i8, ptr %t14, i64 %t10
  call void @olang_textcopy(ptr %t15, ptr %t11, i64 %t12)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t14, 1
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = extractvalue { i64, ptr } %t17, 0
  %t22 = call i32 @open(ptr %t20, i32 0)
  store i32 %t22, ptr %l19
  br label %bb5
bb5:
  %t23 = load i32, ptr %l19, !tbaa !23
  store i32 %t23, ptr %l1, !tbaa !23
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t28 = call i32 @std_2fos_2echeck(i64 %t26)
  store i32 %t28, ptr %l22
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb7, label %ok.30
ok.30:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t31 = load i32, ptr %l22, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 1, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  call void @__olang_scope_close(ptr %s0)
  %t41 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t39, 0
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb8:
  %t42 = load i32, ptr %l1, !tbaa !23
  %t44 = call i64 @lseek(i32 %t42, i64 0, i32 2)
  store i64 %t44, ptr %l25
  br label %bb9
bb9:
  %t45 = load i64, ptr %l25, !tbaa !24
  store i64 %t45, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l2, !tbaa !24
  %t48 = icmp slt i64 %t46, 0
  br i1 %t48, label %bb10, label %bb11
bb10:
  store i64 0, ptr %l2, !tbaa !24
  br label %bb13
bb11:
  %t50 = load i32, ptr %l1, !tbaa !23
  %t52 = call i64 @lseek(i32 %t50, i64 0, i32 0)
  store i64 %t52, ptr %l29
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l31, !tbaa !24
  %t57 = icmp sge i64 %t56, 0
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load i64, ptr %l31, !tbaa !24
  %t60 = mul i64 %t59, 1
  %t61 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = extractvalue { i64, ptr } %t63, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_587e358192386240_8b720e6e0da4b04)
  unreachable
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t73 = load i64, ptr %l4, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t79 = icmp eq i64 %t73, %t76
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t81 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t85 = mul i64 %t83, 2
  store i64 %t85, ptr %l42, !tbaa !24
  %t86 = load i64, ptr %l42, !tbaa !24
  %t87 = icmp sge i64 %t86, 0
  br i1 %t87, label %bb19, label %bb20
bb18:
  br label %bb33
bb19:
  %t89 = load i64, ptr %l42, !tbaa !24
  %t90 = mul i64 %t89, 1
  %t91 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t90)
  %t92 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t96 = extractvalue { i64, ptr } %t93, 0
  %t97 = extractvalue { i64, ptr } %t93, 1
  %t98 = mul i64 %t96, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t97, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t103 = load i64, ptr %l4, !tbaa !24
  store i64 %t103, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t105 = load i64, ptr %l7, !tbaa !24
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = icmp sgt i64 %t105, %t106
  br i1 %t109, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_79e8bbcf109c76d_1b515aa79819cc11)
  unreachable
bb21:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = icmp sgt i64 %t111, 0
  br i1 %t113, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb26
bb23:
  %t115 = load i64, ptr %l7, !tbaa !24
  %t116 = load i64, ptr %l6, !tbaa !24
  %t119 = sub i64 %t115, %t116
  %t120 = load i64, ptr %l8, !tbaa !24
  %t123 = add i64 %t119, %t120
  %t125 = sub i64 %t123, 1
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = sdiv i64 %t125, %t126
  store i64 %t129, ptr %l54, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb25
bb25:
  %t131 = load i64, ptr %l54, !tbaa !24
  store i64 %t131, ptr %l51, !tbaa !24
  br label %bb26
bb26:
  %t132 = load i64, ptr %l51, !tbaa !24
  store i64 %t132, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load i64, ptr %l9, !tbaa !24
  %t137 = icmp slt i64 %t133, %t134
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s8)
  br label %bb32
bb29:
  br label %bb30
bb30:
  %t141 = load i64, ptr %l6, !tbaa !24
  %t142 = load i64, ptr %l10, !tbaa !24
  %t143 = load i64, ptr %l8, !tbaa !24
  %t146 = mul i64 %t142, %t143
  %t149 = add i64 %t141, %t146
  store i64 %t149, ptr %l11, !tbaa !24
  %t151 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t151, ptr %l72, !tbaa !27
  %t152 = load i64, ptr %l11, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t153, ptr %l74, !tbaa !27
  %t154 = load i64, ptr %l11, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i8, ptr %t157, i64 %t154
  %t159 = load i8, ptr %t158, !tbaa !32
  %t162 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i8, ptr %t163, i64 %t152
  store i8 %t159, ptr %t164, !tbaa !32
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb31:
  %t165 = load i64, ptr %l10, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l10, !tbaa !24
  br label %bb27
bb32:
  %t169 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t169, ptr %l3, !tbaa !27
  br label %bb33
bb33:
  %t171 = load i32, ptr %l1, !tbaa !23
  store i32 %t171, ptr %l80, !tbaa !23
  %t172 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t172, ptr %l81, !tbaa !27
  %t173 = load i64, ptr %l4, !tbaa !24
  store i64 %t173, ptr %l82, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t174, 0
  store i64 %t177, ptr %l85, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  store i64 %t179, ptr %l86, !tbaa !24
  %t180 = load i64, ptr %l82, !tbaa !24
  %t181 = icmp sge i64 %t180, 0
  br i1 %t181, label %bb34, label %bb35
bb34:
  %t183 = load i64, ptr %l82, !tbaa !24
  %t184 = load i64, ptr %l85, !tbaa !24
  %t185 = icmp sle i64 %t183, %t184
  br i1 %t185, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_b2d60bcaef35f8ee_ec573b413169e46a)
  unreachable
bb36:
  %t187 = load i64, ptr %l85, !tbaa !24
  %t188 = load i64, ptr %l86, !tbaa !24
  %t189 = icmp sle i64 %t187, %t188
  br i1 %t189, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_b2d60bcaef35f8ee_ec573b413169e46a)
  unreachable
bb38:
  %t191 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = load i64, ptr %l82, !tbaa !24
  %t194 = load i64, ptr %l85, !tbaa !24
  %t195 = getelementptr i8, ptr %t192, i64 %t193
  %t196 = sub i64 %t194, %t193
  %t197 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t195, 1
  %t201 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = load i64, ptr %l4, !tbaa !24
  %t207 = sub i64 %t203, %t204
  %t208 = load i32, ptr %l80, !tbaa !23
  %t210 = extractvalue { i64, ptr } %t198, 1
  %t211 = extractvalue { i64, ptr } %t198, 0
  %t213 = call i64 @read(i32 %t208, ptr %t210, i64 %t207)
  store i64 %t213, ptr %l97
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_b2d60bcaef35f8ee_ec573b413169e46a)
  unreachable
bb40:
  %t214 = load i64, ptr %l97, !tbaa !24
  store i64 %t214, ptr %l12, !tbaa !24
  %t215 = load i64, ptr %l12, !tbaa !24
  %t217 = icmp slt i64 %t215, 0
  br i1 %t217, label %bb41, label %bb42
bb41:
  %t219 = load i32, ptr %l1, !tbaa !23
  store i32 %t219, ptr %l100, !tbaa !23
  %t220 = call i32 @__olang_err()
  store i32 %t220, ptr %l101
  br label %bb43
bb42:
  br label %bb47
bb43:
  %t221 = load i32, ptr %l100, !tbaa !23
  %t222 = load i32, ptr %l101, !tbaa !23
  %t223 = call i32 @std_2fos_2ecloseAndRaise(i32 %t221, i32 %t222)
  store i32 %t223, ptr %l102
  %t224 = icmp ne i32 %t223, 0
  br i1 %t224, label %bb45, label %ok.225
ok.225:
  br label %bb44
bb44:
  br label %bb46
bb45:
  %t226 = load i32, ptr %l102, !tbaa !23
  %t227 = lshr i32 %t226, 16
  %t228 = and i32 %t226, 65535
  %t229 = icmp eq i32 %t227, 1
  %t230 = select i1 %t229, i32 1, i32 0
  %t231 = icmp eq i32 %t226, 0
  %t232 = shl i32 %t230, 16
  %t233 = or i32 %t232, %t228
  %t234 = select i1 %t231, i32 0, i32 %t233
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t236 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t234, 0
  store { i32, { i64, ptr } } %t236, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t237 = load i64, ptr %l12, !tbaa !24
  %t239 = icmp eq i64 %t237, 0
  br i1 %t239, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb49:
  br label %bb50
bb50:
  %t241 = load i64, ptr %l4, !tbaa !24
  %t242 = load i64, ptr %l12, !tbaa !24
  %t245 = add i64 %t241, %t242
  store i64 %t245, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb51:
  br label %bb16
bb52:
  %t247 = load i32, ptr %l1, !tbaa !23
  %t249 = call i32 @close(i32 %t247)
  store i32 %t249, ptr %l110
  br label %bb53
bb53:
  %t250 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t250, ptr %l111, !tbaa !27
  %t251 = load i64, ptr %l4, !tbaa !24
  store i64 %t251, ptr %l112, !tbaa !24
  %t252 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 0
  store i64 %t253, ptr %l113, !tbaa !24
  %t254 = icmp sge i64 0, 0
  br i1 %t254, label %bb54, label %bb55
bb54:
  %t256 = load i64, ptr %l112, !tbaa !24
  %t257 = icmp sle i64 0, %t256
  br i1 %t257, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_870dc790e95aa6eb_a67bfaf9489a2847)
  unreachable
bb56:
  %t259 = load i64, ptr %l112, !tbaa !24
  %t260 = load i64, ptr %l113, !tbaa !24
  %t261 = icmp sle i64 %t259, %t260
  br i1 %t261, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_870dc790e95aa6eb_a67bfaf9489a2847)
  unreachable
bb58:
  %t263 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = load i64, ptr %l112, !tbaa !24
  %t266 = getelementptr i8, ptr %t264, i64 0
  %t267 = sub i64 %t265, 0
  %t268 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t266, 1
  call void @__olang_scope_close(ptr %s0)
  %t271 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t269, 1
  store { i32, { i64, ptr } } %t271, ptr %rv
  br label %ret
bb59:
  call void @__olang_check_failed(ptr @olang_loc_870dc790e95aa6eb_a67bfaf9489a2847)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l7 = alloca i64
  %l15 = alloca i64
  %l22 = alloca i64
  %l30 = alloca i64
  %l32 = alloca i32
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d26 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l1, !tbaa !27
  store i64 256, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l7, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l3, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = extractvalue { i64, ptr } %t23, 1
  %t30 = extractvalue { i64, ptr } %t23, 0
  %t32 = extractvalue { i64, ptr } %t25, 1
  %t33 = extractvalue { i64, ptr } %t25, 0
  %t35 = call i64 @readlink(ptr %t29, ptr %t32, i64 %t27)
  store i64 %t35, ptr %l15
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_3bbcea0c000efd36_21b55d08ecf81e22)
  unreachable
bb3:
  %t36 = load i64, ptr %l15, !tbaa !24
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = icmp eq i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb6:
  br label %bb7
bb7:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = mul i64 %t45, 2
  store i64 %t47, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l2, !tbaa !24
  store i64 %t49, ptr %l22, !tbaa !24
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb8, label %bb9
bb8:
  %t53 = load i64, ptr %l22, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l3, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t63 = load i64, ptr %l2, !tbaa !24
  %t65 = extractvalue { i64, ptr } %t59, 1
  %t66 = extractvalue { i64, ptr } %t59, 0
  %t68 = extractvalue { i64, ptr } %t61, 1
  %t69 = extractvalue { i64, ptr } %t61, 0
  %t71 = call i64 @readlink(ptr %t65, ptr %t68, i64 %t63)
  store i64 %t71, ptr %l30
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ff17d2e56a811dcb_410ea2db80d8aad7)
  unreachable
bb10:
  %t72 = load i64, ptr %l30, !tbaa !24
  store i64 %t72, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %bb4
bb12:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = call i32 @std_2fos_2echeck(i64 %t73)
  store i32 %t75, ptr %l32
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb14, label %ok.77
ok.77:
  br label %bb13
bb13:
  br label %bb15
bb14:
  %t78 = load i32, ptr %l32, !tbaa !23
  %t79 = lshr i32 %t78, 16
  %t80 = and i32 %t78, 65535
  %t81 = icmp eq i32 %t79, 1
  %t82 = select i1 %t81, i32 1, i32 0
  %t83 = icmp eq i32 %t78, 0
  %t84 = shl i32 %t82, 16
  %t85 = or i32 %t84, %t80
  %t86 = select i1 %t83, i32 0, i32 %t85
  call void @__olang_scope_close(ptr %s0)
  %t88 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t86, 0
  store { i32, { i64, ptr } } %t88, ptr %rv
  br label %ret
bb15:
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t89, ptr %l34, !tbaa !27
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l35, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l36, !tbaa !24
  %t93 = icmp sge i64 0, 0
  br i1 %t93, label %bb16, label %bb17
bb16:
  %t95 = load i64, ptr %l35, !tbaa !24
  %t96 = icmp sle i64 0, %t95
  br i1 %t96, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_d7f228265709f418_7e9f802c53b666ac)
  unreachable
bb18:
  %t98 = load i64, ptr %l35, !tbaa !24
  %t99 = load i64, ptr %l36, !tbaa !24
  %t100 = icmp sle i64 %t98, %t99
  br i1 %t100, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_d7f228265709f418_7e9f802c53b666ac)
  unreachable
bb20:
  %t102 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l35, !tbaa !24
  %t105 = getelementptr i8, ptr %t103, i64 0
  %t106 = sub i64 %t104, 0
  %t107 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t105, 1
  call void @__olang_scope_close(ptr %s0)
  %t111 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t108, 1
  store { i32, { i64, ptr } } %t111, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_d7f228265709f418_7e9f802c53b666ac)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t16 = alloca { { i64, ptr }, ptr }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d27 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d27 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t15 = ptrtoint ptr %t14 to i64
  %t17 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 0
  store { i64, ptr } %t11, ptr %t17, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t19 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 1
  store ptr %s0, ptr %t19, !tbaa !28
  %t20 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_28, 0
  %t21 = insertvalue { ptr, ptr } %t20, ptr %t16, 1
  %t23 = extractvalue { ptr, ptr } %t21, 0
  %t24 = extractvalue { ptr, ptr } %t21, 1
  %t25 = call { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %s0, ptr %v1, ptr %t23, ptr %t24)
  %t26 = extractvalue { i32, { i64, ptr } } %t25, 1
  %t27 = extractvalue { i32, { i64, ptr } } %t25, 0
  store i32 %t27, ptr %l8
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb2, label %ok.29
ok.29:
  store { i64, ptr } %t26, ptr %l7
  br label %bb1
bb1:
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  %t31 = load i32, ptr %l8, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 1, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  call void @__olang_scope_close(ptr %s0)
  %t41 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t39, 0
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t42, 1
  store { i32, { i64, ptr } } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d29 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d29 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = extractvalue { i64, ptr } %t11, 0
  %t16 = call i32 @remove(ptr %t14)
  store i32 %t16, ptr %l4
  br label %bb1
bb1:
  %t17 = load i32, ptr %l4, !tbaa !23
  %t18 = sext i32 %t17 to i64
  %t20 = call i32 @std_2fos_2echeck(i64 %t18)
  store i32 %t20, ptr %l6
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb3, label %ok.22
ok.22:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t23 = load i32, ptr %l6, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  call void @__olang_scope_close(ptr %s0)
  store i32 %t31, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sgt i64 %t5, 1
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = sub i64 %t10, 1
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp eq i8 %t17, 47
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l8, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t24 = load i64, ptr %l1, !tbaa !24
  %t26 = sub i64 %t24, 1
  store i64 %t26, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t28 = load i64, ptr %l1, !tbaa !24
  store i64 %t28, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t34, ptr %l21, !tbaa !27
  %t35 = load i64, ptr %l2, !tbaa !24
  %t37 = sub i64 %t35, 1
  %t39 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t37
  %t42 = load i8, ptr %t41, !tbaa !32
  %t44 = icmp ne i8 %t42, 47
  store i1 %t44, ptr %l20, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t46 = load i1, ptr %l20, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = sub i64 %t49, 1
  store i64 %t51, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb10
bb18:
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l29, !tbaa !27
  %t54 = load i64, ptr %l2, !tbaa !24
  store i64 %t54, ptr %l30, !tbaa !24
  %t55 = load i64, ptr %l1, !tbaa !24
  store i64 %t55, ptr %l31, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l32, !tbaa !24
  %t58 = load i64, ptr %l30, !tbaa !24
  %t59 = icmp sge i64 %t58, 0
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = load i64, ptr %l31, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_9d6ebd177b1045e9_d85719897e835afd)
  unreachable
bb21:
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = load i64, ptr %l32, !tbaa !24
  %t67 = icmp sle i64 %t65, %t66
  br i1 %t67, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9d6ebd177b1045e9_d85719897e835afd)
  unreachable
bb23:
  %t69 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l30, !tbaa !24
  %t72 = load i64, ptr %l31, !tbaa !24
  %t73 = getelementptr i8, ptr %t70, i64 %t71
  %t74 = sub i64 %t72, %t71
  %t75 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t73, 1
  store { i64, ptr } %t76, ptr %l3, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t78, { i64, ptr } { i64 1, ptr @.d30 })
  store i1 %t80, ptr %l38
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_9d6ebd177b1045e9_d85719897e835afd)
  unreachable
bb25:
  %t81 = load i1, ptr %l38, !tbaa !21
  br i1 %t81, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb29
bb27:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t82, { i64, ptr } { i64 2, ptr @.d31 })
  store i1 %t84, ptr %l41
  br label %bb28
bb28:
  %t85 = load i1, ptr %l41, !tbaa !21
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb29
bb29:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i32 65542, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t88 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t90 = call i32 @std_2fos_2eremoveTree(ptr %v0, { i64, ptr } %t88)
  store i32 %t90, ptr %l44
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb34, label %ok.92
ok.92:
  br label %bb33
bb33:
  br label %bb35
bb34:
  %t93 = load i32, ptr %l44, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  call void @__olang_scope_close(ptr %s0)
  store i32 %t101, ptr %rv
  br label %ret
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l8 = alloca i32
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr @.d33 }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = getelementptr i8, ptr %t20, i64 %t16
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t26 = extractvalue { i64, ptr } %t11, 1
  %t27 = extractvalue { i64, ptr } %t11, 0
  %t29 = extractvalue { i64, ptr } %t23, 1
  %t30 = extractvalue { i64, ptr } %t23, 0
  %t31 = call i32 @rename(ptr %t26, ptr %t29)
  store i32 %t31, ptr %l8
  br label %bb1
bb1:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = sext i32 %t32 to i64
  %t35 = call i32 @std_2fos_2echeck(i64 %t33)
  store i32 %t35, ptr %l10
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb3, label %ok.37
ok.37:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t38 = load i32, ptr %l10, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 1, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s0)
  store i32 %t46, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2eRun(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i32
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr @.d34 }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = extractvalue { i64, ptr } %t11, 0
  %t16 = call i32 @system(ptr %t14)
  store i32 %t16, ptr %l5
  br label %bb1
bb1:
  %t17 = load i32, ptr %l5, !tbaa !23
  store i32 %t17, ptr %l1, !tbaa !23
  %t18 = load i32, ptr %l1, !tbaa !23
  %t20 = icmp slt i32 %t18, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i32 127, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = srem i32 %t23, 256
  %t27 = icmp ne i32 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i32, ptr %l1, !tbaa !23
  %t31 = srem i32 %t29, 128
  %t33 = add i32 128, %t31
  call void @__olang_scope_close(ptr %s0)
  store i32 %t33, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t35 = load i32, ptr %l1, !tbaa !23
  %t37 = sdiv i32 %t35, 256
  call void @__olang_scope_close(ptr %s0)
  store i32 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fos_2eRunOnStack(ptr %v0, i64 %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { ptr, ptr } %pg1, 0
  %t6 = extractvalue { ptr, ptr } %pg1, 1
  call void @__olang_run_on_stack(i64 %a0, ptr %t5, ptr %t6)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"std/os:Process" } @std_2fos_2eStart(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca %"std/os:FileInfo"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i32
  %l55 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i32
  %l64 = alloca %"std/os:FileInfo"
  %l66 = alloca %"std/os:FileInfo"
  %l67 = alloca i32
  %l73 = alloca i64
  %l83 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l107 = alloca i32
  %l108 = alloca i32
  %l109 = alloca i32
  %l113 = alloca i32
  %l116 = alloca i32
  %l118 = alloca i32
  %l119 = alloca i32
  %l121 = alloca i32
  %l123 = alloca i64
  %l125 = alloca i32
  %l126 = alloca i32
  %l127 = alloca i32
  %l128 = alloca i32
  %l130 = alloca i32
  %l131 = alloca { i64, ptr }
  %l132 = alloca i32
  %l135 = alloca i32
  %l136 = alloca i32
  %l137 = alloca i32
  %l138 = alloca i32
  %l140 = alloca i32
  %l151 = alloca i32
  %l154 = alloca i32
  %l157 = alloca i32
  %l159 = alloca i32
  %l161 = alloca i32
  %l162 = alloca i32
  %l164 = alloca i32
  %l169 = alloca %"std/os:Process"
  %l171 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Process" }
  store { i64, ptr } %a0, ptr %l0
  store i1 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t8 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 65542, 0
  store { i32, %"std/os:Process" } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l4, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l39, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %t27, i64 %t24
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !37
  store { i64, ptr } %t29, ptr %l8, !tbaa !27
  store i1 true, ptr %l9, !tbaa !21
  %t31 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t33 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t31, i8 0)
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l45
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb9, label %ok.37
ok.37:
  store i64 %t34, ptr %l44
  br label %bb8
bb8:
  %t38 = load i64, ptr %l44, !tbaa !24
  store i64 %t38, ptr %l42, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l9, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t42 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 65542, 0
  store { i32, %"std/os:Process" } %t42, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t48 = add i64 %t46, 1
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t53 = load i64, ptr %l6, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l6, !tbaa !24
  br label %bb4
bb16:
  store i1 true, ptr %l10, !tbaa !21
  %t57 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t59 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v2, { i64, ptr } %t57, i8 0)
  %t60 = extractvalue { i32, i64 } %t59, 1
  %t61 = extractvalue { i32, i64 } %t59, 0
  store i32 %t61, ptr %l58
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb18, label %ok.63
ok.63:
  store i64 %t60, ptr %l57
  br label %bb17
bb17:
  %t64 = load i64, ptr %l57, !tbaa !24
  store i64 %t64, ptr %l55, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb20
bb20:
  %t65 = load i1, ptr %l10, !tbaa !21
  br i1 %t65, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t68 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 65542, 0
  store { i32, %"std/os:Process" } %t68, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb24, label %bb25
bb24:
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t77 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v2, { i64, ptr } %t75)
  %t78 = extractvalue { i32, %"std/os:FileInfo" } %t77, 1
  %t79 = extractvalue { i32, %"std/os:FileInfo" } %t77, 0
  store i32 %t79, ptr %l67
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb27, label %ok.81
ok.81:
  store %"std/os:FileInfo" %t78, ptr %l66
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t82 = load %"std/os:FileInfo", ptr %l66
  store %"std/os:FileInfo" %t82, ptr %l64
  br label %bb28
bb27:
  %t83 = load i32, ptr %l67, !tbaa !23
  %t84 = lshr i32 %t83, 16
  %t85 = and i32 %t83, 65535
  %t86 = icmp eq i32 %t84, 1
  %t87 = select i1 %t86, i32 1, i32 0
  %t88 = icmp eq i32 %t83, 0
  %t89 = shl i32 %t87, 16
  %t90 = or i32 %t89, %t85
  %t91 = select i1 %t88, i32 0, i32 %t90
  call void @__olang_scope_close(ptr %s0)
  %t93 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t91, 0
  store { i32, %"std/os:Process" } %t93, ptr %rv
  br label %ret
bb28:
  %t94 = load %"std/os:FileInfo", ptr %l64
  store %"std/os:FileInfo" %t94, ptr %l11
  %t95 = getelementptr %"std/os:FileInfo", ptr %l11, i32 0, i32 0
  %t96 = load i32, ptr %t95
  %t98 = trunc i64 1 to i32
  %t99 = icmp eq i32 %t96, %t98
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t104 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 65539, 0
  store { i32, %"std/os:Process" } %t104, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t105 = load i64, ptr %l4, !tbaa !24
  store i64 %t105, ptr %l73, !tbaa !24
  %t106 = load i64, ptr %l73, !tbaa !24
  %t107 = icmp sge i64 %t106, 0
  br i1 %t107, label %bb33, label %bb34
bb33:
  %t109 = load i64, ptr %l73, !tbaa !24
  %t110 = mul i64 %t109, 1
  %t111 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t115, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  store i64 %t119, ptr %l16, !tbaa !24
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_2520df159ef45bd8_53b6e0dcdbf625cc)
  unreachable
bb35:
  store %olang.scope zeroinitializer, ptr %s12
  %t121 = load i64, ptr %l15, !tbaa !24
  %t122 = load i64, ptr %l16, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s12)
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t129 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t129, ptr %l83, !tbaa !27
  %t130 = load i64, ptr %l15, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %t133, i64 %t130
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !37
  store { i64, ptr } %t135, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  store i64 %t141, ptr %l20, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s14
  %t143 = load i64, ptr %l19, !tbaa !24
  %t144 = load i64, ptr %l20, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s14)
  br label %bb44
bb41:
  br label %bb42
bb42:
  %t151 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t151, ptr %l93, !tbaa !27
  %t152 = load i64, ptr %l19, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i8, ptr %t155, i64 %t152
  %t157 = load i8, ptr %t156, !tbaa !32
  %t159 = load i64, ptr %l13, !tbaa !24
  %t164 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr i8, ptr %t165, i64 %t159
  store i8 %t157, ptr %t166, !tbaa !32
  %t167 = load i64, ptr %l13, !tbaa !24
  %t169 = add i64 %t167, 1
  store i64 %t169, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb43
bb43:
  %t171 = load i64, ptr %l19, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l19, !tbaa !24
  br label %bb39
bb44:
  %t175 = load i64, ptr %l13, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb45
bb45:
  %t179 = load i64, ptr %l15, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l15, !tbaa !24
  br label %bb35
bb46:
  %t183 = call { i32, i32 } @std_2fos_2ememFile()
  %t184 = extractvalue { i32, i32 } %t183, 1
  %t185 = extractvalue { i32, i32 } %t183, 0
  store i32 %t185, ptr %l109
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb48, label %ok.187
ok.187:
  store i32 %t184, ptr %l108
  br label %bb47
bb47:
  %t188 = load i32, ptr %l108, !tbaa !23
  store i32 %t188, ptr %l107, !tbaa !23
  br label %bb49
bb48:
  %t189 = load i32, ptr %l109, !tbaa !23
  %t190 = lshr i32 %t189, 16
  %t191 = and i32 %t189, 65535
  %t192 = icmp eq i32 %t190, 1
  %t193 = select i1 %t192, i32 1, i32 0
  %t194 = icmp eq i32 %t189, 0
  %t195 = shl i32 %t193, 16
  %t196 = or i32 %t195, %t191
  %t197 = select i1 %t194, i32 0, i32 %t196
  call void @__olang_scope_close(ptr %s0)
  %t199 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t197, 0
  store { i32, %"std/os:Process" } %t199, ptr %rv
  br label %ret
bb49:
  %t200 = load i32, ptr %l107, !tbaa !23
  store i32 %t200, ptr %l22, !tbaa !23
  %t201 = load i32, ptr %l22, !tbaa !23
  %t205 = call i32 @std_2fio_2eWrite(ptr %v1, i32 %t201, { i64, ptr } %a1)
  store i32 %t205, ptr %l113
  %t206 = icmp ne i32 %t205, 0
  br i1 %t206, label %bb51, label %ok.207
ok.207:
  br label %bb50
bb50:
  br label %bb57
bb51:
  %t208 = load i32, ptr %l113, !tbaa !23
  %t209 = ashr i32 %t208, 16
  %t211 = icmp eq i32 %t209, 1
  br i1 %t211, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  %t213 = load i32, ptr %l113, !tbaa !23
  %t214 = lshr i32 %t213, 16
  %t215 = and i32 %t213, 65535
  %t216 = icmp eq i32 %t214, 1
  %t217 = select i1 %t216, i32 0, i32 0
  %t218 = icmp eq i32 %t213, 0
  %t219 = shl i32 %t217, 16
  %t220 = or i32 %t219, %t215
  %t221 = select i1 %t218, i32 0, i32 %t220
  store i32 %t221, ptr %l116, !tbaa !23
  %t222 = load i32, ptr %l22, !tbaa !23
  %t224 = call i32 @close(i32 %t222)
  store i32 %t224, ptr %l118
  br label %bb55
bb54:
  store i32 65542, ptr %l119, !tbaa !23
  %t225 = load i32, ptr %l22, !tbaa !23
  %t227 = call i32 @close(i32 %t225)
  store i32 %t227, ptr %l121
  br label %bb56
bb55:
  call void @__olang_scope_close(ptr %s0)
  %t228 = load i32, ptr %l116, !tbaa !23
  %t229 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t228, 0
  store { i32, %"std/os:Process" } %t229, ptr %rv
  br label %ret
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t230 = load i32, ptr %l119, !tbaa !23
  %t231 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t230, 0
  store { i32, %"std/os:Process" } %t231, ptr %rv
  br label %ret
bb57:
  %t232 = load i32, ptr %l22, !tbaa !23
  %t234 = call i64 @lseek(i32 %t232, i64 0, i32 0)
  store i64 %t234, ptr %l123
  br label %bb58
bb58:
  store i32 -1, ptr %l23, !tbaa !23
  store i32 -1, ptr %l24, !tbaa !23
  %t235 = load i1, ptr %l2, !tbaa !21
  br i1 %t235, label %bb59, label %bb60
bb59:
  %t237 = call { i32, i32 } @std_2fos_2ememFile()
  %t238 = extractvalue { i32, i32 } %t237, 1
  %t239 = extractvalue { i32, i32 } %t237, 0
  store i32 %t239, ptr %l127
  %t240 = icmp ne i32 %t239, 0
  br i1 %t240, label %bb62, label %ok.241
ok.241:
  store i32 %t238, ptr %l126
  br label %bb61
bb60:
  br label %bb74
bb61:
  %t242 = load i32, ptr %l126, !tbaa !23
  store i32 %t242, ptr %l125, !tbaa !23
  br label %bb64
bb62:
  %t243 = load i32, ptr %l127, !tbaa !23
  %t244 = lshr i32 %t243, 16
  %t245 = and i32 %t243, 65535
  %t246 = icmp eq i32 %t244, 1
  %t247 = select i1 %t246, i32 1, i32 0
  %t248 = icmp eq i32 %t243, 0
  %t249 = shl i32 %t247, 16
  %t250 = or i32 %t249, %t245
  %t251 = select i1 %t248, i32 0, i32 %t250
  store i32 %t251, ptr %l128, !tbaa !23
  %t252 = load i32, ptr %l22, !tbaa !23
  %t254 = call i32 @close(i32 %t252)
  store i32 %t254, ptr %l130
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  %t255 = load i32, ptr %l128, !tbaa !23
  %t256 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t255, 0
  store { i32, %"std/os:Process" } %t256, ptr %rv
  br label %ret
bb64:
  %t257 = load i32, ptr %l125, !tbaa !23
  store i32 %t257, ptr %l23, !tbaa !23
  store { i64, ptr } { i64 6, ptr @.d35 }, ptr %l131, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = call i32 @memfd_create(ptr %t259, i32 1)
  store i32 %t261, ptr %l132
  br label %bb65
bb65:
  %t262 = load i32, ptr %l132, !tbaa !23
  store i32 %t262, ptr %l25, !tbaa !23
  %t263 = load i32, ptr %l25, !tbaa !23
  %t265 = icmp slt i32 %t263, 0
  br i1 %t265, label %bb66, label %bb67
bb66:
  %t267 = load i32, ptr %l23, !tbaa !23
  store i32 %t267, ptr %l135, !tbaa !23
  %t268 = call i32 @__olang_err()
  store i32 %t268, ptr %l136
  br label %bb68
bb67:
  br label %bb73
bb68:
  %t269 = load i32, ptr %l135, !tbaa !23
  %t270 = load i32, ptr %l136, !tbaa !23
  %t271 = call i32 @std_2fos_2ecloseAndRaise(i32 %t269, i32 %t270)
  store i32 %t271, ptr %l137
  %t272 = icmp ne i32 %t271, 0
  br i1 %t272, label %bb70, label %ok.273
ok.273:
  br label %bb69
bb69:
  br label %bb72
bb70:
  %t274 = load i32, ptr %l137, !tbaa !23
  %t275 = lshr i32 %t274, 16
  %t276 = and i32 %t274, 65535
  %t277 = icmp eq i32 %t275, 1
  %t278 = select i1 %t277, i32 1, i32 0
  %t279 = icmp eq i32 %t274, 0
  %t280 = shl i32 %t278, 16
  %t281 = or i32 %t280, %t276
  %t282 = select i1 %t279, i32 0, i32 %t281
  store i32 %t282, ptr %l138, !tbaa !23
  %t283 = load i32, ptr %l22, !tbaa !23
  %t285 = call i32 @close(i32 %t283)
  store i32 %t285, ptr %l140
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s0)
  %t286 = load i32, ptr %l138, !tbaa !23
  %t287 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t286, 0
  store { i32, %"std/os:Process" } %t287, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  %t288 = load i32, ptr %l25, !tbaa !23
  store i32 %t288, ptr %l24, !tbaa !23
  br label %bb74
bb74:
  %t290 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t291 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t291, 0
  %t294 = load i32, ptr %l22, !tbaa !23
  %t295 = load i32, ptr %l23, !tbaa !23
  %t296 = load i32, ptr %l24, !tbaa !23
  %t297 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 1
  %t300 = extractvalue { i64, ptr } %t297, 0
  %t301 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 1
  %t302 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 0
  %t303 = add i64 %t300, %t302
  %t304 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t303)
  call void @olang_textcopy(ptr %t304, ptr %t299, i64 %t300)
  %t305 = getelementptr i8, ptr %t304, i64 %t300
  call void @olang_textcopy(ptr %t305, ptr %t301, i64 %t302)
  %t306 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t304, 1
  %t310 = extractvalue { i64, ptr } %t290, 1
  %t311 = extractvalue { i64, ptr } %t290, 0
  %t317 = extractvalue { i64, ptr } %t307, 1
  %t318 = extractvalue { i64, ptr } %t307, 0
  %t319 = call i32 @__olang_spawn(ptr %t310, i64 %t293, i32 %t294, i32 %t295, i32 %t296, ptr %t317)
  store i32 %t319, ptr %l151
  br label %bb75
bb75:
  %t320 = load i32, ptr %l151, !tbaa !23
  store i32 %t320, ptr %l26, !tbaa !23
  %t321 = load i32, ptr %l26, !tbaa !23
  %t323 = icmp slt i32 %t321, 0
  br i1 %t323, label %bb76, label %bb77
bb76:
  %t325 = call i32 @__olang_err()
  store i32 %t325, ptr %l154
  br label %bb78
bb77:
  br label %bb88
bb78:
  %t326 = load i32, ptr %l154, !tbaa !23
  store i32 %t326, ptr %l27, !tbaa !23
  %t327 = load i1, ptr %l2, !tbaa !21
  br i1 %t327, label %bb79, label %bb80
bb79:
  %t329 = load i32, ptr %l23, !tbaa !23
  %t331 = call i32 @close(i32 %t329)
  store i32 %t331, ptr %l157
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t332 = load i32, ptr %l24, !tbaa !23
  %t334 = call i32 @close(i32 %t332)
  store i32 %t334, ptr %l159
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t335 = load i32, ptr %l27, !tbaa !23
  %t337 = call i32 @std_2fos_2eraise(i32 %t335)
  store i32 %t337, ptr %l161
  %t338 = icmp ne i32 %t337, 0
  br i1 %t338, label %bb85, label %ok.339
ok.339:
  br label %bb84
bb84:
  br label %bb87
bb85:
  %t340 = load i32, ptr %l161, !tbaa !23
  %t341 = lshr i32 %t340, 16
  %t342 = and i32 %t340, 65535
  %t343 = icmp eq i32 %t341, 1
  %t344 = select i1 %t343, i32 1, i32 0
  %t345 = icmp eq i32 %t340, 0
  %t346 = shl i32 %t344, 16
  %t347 = or i32 %t346, %t342
  %t348 = select i1 %t345, i32 0, i32 %t347
  store i32 %t348, ptr %l162, !tbaa !23
  %t349 = load i32, ptr %l22, !tbaa !23
  %t351 = call i32 @close(i32 %t349)
  store i32 %t351, ptr %l164
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s0)
  %t352 = load i32, ptr %l162, !tbaa !23
  %t353 = insertvalue { i32, %"std/os:Process" } zeroinitializer, i32 %t352, 0
  store { i32, %"std/os:Process" } %t353, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  %t354 = load i32, ptr %l26, !tbaa !23
  %t355 = load i32, ptr %l23, !tbaa !23
  %t356 = load i32, ptr %l24, !tbaa !23
  %t357 = load i1, ptr %l2, !tbaa !21
  %t362 = call %"std/os:Process" @std_2fos_3aProcess_2ector(ptr %s0, i32 %t354, i32 %t355, i32 %t356, i1 %t357)
  store %"std/os:Process" %t362, ptr %l169
  br label %bb89
bb89:
  %t363 = load i32, ptr %l22, !tbaa !23
  %t365 = call i32 @close(i32 %t363)
  store i32 %t365, ptr %l171
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s0)
  %t366 = load %"std/os:Process", ptr %l169
  %t367 = insertvalue { i32, %"std/os:Process" } zeroinitializer, %"std/os:Process" %t366, 1
  store { i32, %"std/os:Process" } %t367, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Process" }, ptr %rv
  ret { i32, %"std/os:Process" } %rr
}

define dso_local { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca [3 x i64]
  %l2 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i32
  %l24 = alloca %"std/os:FileInfo"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:FileInfo" }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [3 x i64] undef, i64 0, 0
  %t2 = insertvalue [3 x i64] %t1, i64 0, 1
  %t3 = insertvalue [3 x i64] %t2, i64 0, 2
  store [3 x i64] %t3, ptr %l1
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d37 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d37 }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t7, i64 %t8)
  %t13 = getelementptr i8, ptr %t12, i64 %t8
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t18 = insertvalue { i64, ptr } undef, i64 3, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %l1, 1
  %t22 = extractvalue { i64, ptr } %t15, 1
  %t23 = extractvalue { i64, ptr } %t15, 0
  %t25 = extractvalue { i64, ptr } %t19, 1
  %t26 = extractvalue { i64, ptr } %t19, 0
  %t27 = call i32 @__olang_stat(ptr %t22, ptr %t25)
  store i32 %t27, ptr %l10
  br label %bb1
bb1:
  %t28 = load i32, ptr %l10, !tbaa !23
  %t29 = sext i32 %t28 to i64
  %t31 = call i32 @std_2fos_2echeck(i64 %t29)
  store i32 %t31, ptr %l12
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb3, label %ok.33
ok.33:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t34 = load i32, ptr %l12, !tbaa !23
  %t35 = lshr i32 %t34, 16
  %t36 = and i32 %t34, 65535
  %t37 = icmp eq i32 %t35, 1
  %t38 = select i1 %t37, i32 1, i32 0
  %t39 = icmp eq i32 %t34, 0
  %t40 = shl i32 %t38, 16
  %t41 = or i32 %t40, %t36
  %t42 = select i1 %t39, i32 0, i32 %t41
  call void @__olang_scope_close(ptr %s0)
  %t44 = insertvalue { i32, %"std/os:FileInfo" } zeroinitializer, i32 %t42, 0
  store { i32, %"std/os:FileInfo" } %t44, ptr %rv
  br label %ret
bb4:
  store i32 2, ptr %l2
  %t46 = getelementptr [3 x i64], ptr %l1, i64 0, i64 0
  %t47 = load i64, ptr %t46, !tbaa !34
  %t49 = icmp eq i64 %t47, 1
  br i1 %t49, label %bb5, label %bb6
bb5:
  store i32 0, ptr %l2
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t52 = getelementptr [3 x i64], ptr %l1, i64 0, i64 0
  %t53 = load i64, ptr %t52, !tbaa !34
  %t55 = icmp eq i64 %t53, 2
  br i1 %t55, label %bb8, label %bb9
bb8:
  store i32 1, ptr %l2
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t58 = load i32, ptr %l2
  %t59 = getelementptr [3 x i64], ptr %l1, i64 0, i64 1
  %t60 = load i64, ptr %t59, !tbaa !34
  %t61 = getelementptr [3 x i64], ptr %l1, i64 0, i64 2
  %t62 = load i64, ptr %t61, !tbaa !34
  %t66 = call %"std/os:FileInfo" @std_2fos_3aFileInfo_2ector(ptr %s0, i32 %t58, i64 %t60, i64 %t62)
  store %"std/os:FileInfo" %t66, ptr %l24
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t67 = load %"std/os:FileInfo", ptr %l24
  %t68 = insertvalue { i32, %"std/os:FileInfo" } zeroinitializer, %"std/os:FileInfo" %t67, 1
  store { i32, %"std/os:FileInfo" } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:FileInfo" }, ptr %rv
  ret { i32, %"std/os:FileInfo" } %rr
}

define dso_local i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca i32
  %l3 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, i32 } @std_2fos_2eCreate(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, i32 } %t3, 1
  %t5 = extractvalue { i32, i32 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i32 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i32, ptr %l5, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  br label %bb3
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  store i32 %t17, ptr %rv
  br label %ret
bb3:
  %t19 = load i32, ptr %l3, !tbaa !23
  store i32 %t19, ptr %l2, !tbaa !23
  %t20 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @std_2fio_2eWrite(ptr %v1, i32 %t20, { i64, ptr } %a1)
  store i32 %t24, ptr %l10
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb5, label %ok.26
ok.26:
  br label %bb4
bb4:
  br label %bb13
bb5:
  %t27 = load i32, ptr %l10, !tbaa !23
  %t28 = ashr i32 %t27, 16
  %t30 = icmp eq i32 %t28, 1
  br i1 %t30, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  %t32 = load i32, ptr %l10, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 0, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  store i32 %t40, ptr %rv
  br label %ret
bb8:
  %t42 = load i32, ptr %l2, !tbaa !23
  store i32 %t42, ptr %l14, !tbaa !23
  %t43 = call i32 @__olang_err()
  store i32 %t43, ptr %l15
  br label %bb9
bb9:
  %t44 = load i32, ptr %l14, !tbaa !23
  %t45 = load i32, ptr %l15, !tbaa !23
  %t46 = call i32 @std_2fos_2ecloseAndRaise(i32 %t44, i32 %t45)
  store i32 %t46, ptr %l16
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb11, label %ok.48
ok.48:
  br label %bb10
bb10:
  br label %bb12
bb11:
  %t49 = load i32, ptr %l16, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  store i32 %t57, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t59 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @std_2fos_2eClose(i32 %t59)
  store i32 %t61, ptr %l19
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb15, label %ok.63
ok.63:
  br label %bb14
bb14:
  br label %bb16
bb15:
  %t64 = load i32, ptr %l19, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  store i32 %t72, ptr %rv
  br label %ret
bb16:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2echeck(i64 %a0) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = icmp slt i64 %a0, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call i32 @__olang_err()
  store i32 %t5, ptr %l3
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = call i32 @std_2fos_2eraise(i32 %t6)
  store i32 %t7, ptr %l4
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb5, label %ok.9
ok.9:
  br label %bb4
bb4:
  br label %bb6
bb5:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  store i32 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @std_2fos_2echurn() #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !24
  store i64 0, ptr %l1, !tbaa !24
  store i64 300, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l11, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  %t49 = call i64 @__olang_fmt_i64(ptr null, i64 %t45)
  %t50 = extractvalue { i64, ptr } { i64 61, ptr @.d38 }, 1
  %t51 = extractvalue { i64, ptr } { i64 61, ptr @.d38 }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t52)
  %t54 = call i64 @__olang_fmt_i64(ptr %t53, i64 %t45)
  %t55 = getelementptr i8, ptr %t53, i64 %t49
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = load i64, ptr %l0, !tbaa !24
  %t62 = extractvalue { i64, ptr } %t57, 0
  %t65 = add i64 %t59, %t62
  store i64 %t65, ptr %l0, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l5, !tbaa !24
  br label %bb7
bb12:
  %t71 = load i64, ptr %l0, !tbaa !24
  store i64 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @std_2fos_2ecloseAndRaise(i32 %a0, i32 %a1) #0 {
entry:
  %l3 = alloca i32
  %l5 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @close(i32 %a0)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t6 = call i32 @std_2fos_2eraise(i32 %a1)
  store i32 %t6, ptr %l5
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb3, label %ok.8
ok.8:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  store i32 %t17, ptr %rv
  br label %ret
bb4:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %v0, ptr %v1, ptr %a0c, ptr %a0e) #0 {
entry:
  %l0 = alloca { ptr, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { ptr, ptr }
  %l7 = alloca i64
  %l9 = alloca i32
  %l11 = alloca i64
  %l19 = alloca i64
  %l24 = alloca i32
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %pf0 = insertvalue { ptr, ptr } undef, ptr %a0c, 0
  %pg0 = insertvalue { ptr, ptr } %pf0, ptr %a0e, 1
  store { ptr, ptr } %pg0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { ptr, ptr }, ptr %l0
  store { ptr, ptr } %t1, ptr %l4
  %t2 = icmp sge i64 0, 0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = mul i64 0, 1
  %t5 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 0, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  %t8 = load { ptr, ptr }, ptr %l4
  %t9 = extractvalue { ptr, ptr } %t8, 0
  %t10 = extractvalue { ptr, ptr } %t8, 1
  %t12 = call i64 %t9(ptr %t10, ptr %s0, { i64, ptr } %t7)
  store i64 %t12, ptr %l7
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_7455114053b9a685_f9a96b9bd4adb589)
  unreachable
bb3:
  %t13 = load i64, ptr %l7, !tbaa !24
  store i64 %t13, ptr %l1, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = call i32 @std_2fos_2echeck(i64 %t14)
  store i32 %t16, ptr %l9
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb6, label %ok.18
ok.18:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t19 = load i32, ptr %l9, !tbaa !23
  %t20 = lshr i32 %t19, 16
  %t21 = and i32 %t19, 65535
  %t22 = icmp eq i32 %t20, 1
  %t23 = select i1 %t22, i32 1, i32 0
  %t24 = icmp eq i32 %t19, 0
  %t25 = shl i32 %t23, 16
  %t26 = or i32 %t25, %t21
  %t27 = select i1 %t24, i32 0, i32 %t26
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t27, 0
  store { i32, { i64, ptr } } %t29, ptr %rv
  br label %ret
bb7:
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l11, !tbaa !24
  %t31 = load i64, ptr %l11, !tbaa !24
  %t32 = icmp sge i64 %t31, 0
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load i64, ptr %l11, !tbaa !24
  %t35 = mul i64 %t34, 1
  %t36 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t41 = extractvalue { i64, ptr } %t38, 0
  %t42 = extractvalue { i64, ptr } %t38, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l2, !tbaa !27
  %t48 = load { ptr, ptr }, ptr %l0
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t52 = extractvalue { ptr, ptr } %t48, 0
  %t53 = extractvalue { ptr, ptr } %t48, 1
  %t55 = call i64 %t52(ptr %t53, ptr %v1, { i64, ptr } %t49)
  store i64 %t55, ptr %l19
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_d680568c47c09218_ee59193b16d39a3c)
  unreachable
bb10:
  %t56 = load i64, ptr %l19, !tbaa !24
  store i64 %t56, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l3, !tbaa !24
  %t58 = load i64, ptr %l1, !tbaa !24
  %t61 = icmp sle i64 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = call i32 @std_2fos_2echeck(i64 %t63)
  store i32 %t65, ptr %l24
  %t66 = icmp ne i32 %t65, 0
  br i1 %t66, label %bb14, label %ok.67
ok.67:
  br label %bb13
bb12:
  br label %bb22
bb13:
  br label %bb15
bb14:
  %t68 = load i32, ptr %l24, !tbaa !23
  %t69 = lshr i32 %t68, 16
  %t70 = and i32 %t68, 65535
  %t71 = icmp eq i32 %t69, 1
  %t72 = select i1 %t71, i32 1, i32 0
  %t73 = icmp eq i32 %t68, 0
  %t74 = shl i32 %t72, 16
  %t75 = or i32 %t74, %t70
  %t76 = select i1 %t73, i32 0, i32 %t75
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t78 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t76, 0
  store { i32, { i64, ptr } } %t78, ptr %rv
  br label %ret
bb15:
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t79, ptr %l26, !tbaa !27
  %t80 = load i64, ptr %l3, !tbaa !24
  store i64 %t80, ptr %l27, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l28, !tbaa !24
  %t83 = icmp sge i64 0, 0
  br i1 %t83, label %bb16, label %bb17
bb16:
  %t85 = load i64, ptr %l27, !tbaa !24
  %t86 = icmp sle i64 0, %t85
  br i1 %t86, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_a97aa98585cf6243_3a57acf5b7e1165f)
  unreachable
bb18:
  %t88 = load i64, ptr %l27, !tbaa !24
  %t89 = load i64, ptr %l28, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_a97aa98585cf6243_3a57acf5b7e1165f)
  unreachable
bb20:
  %t92 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l27, !tbaa !24
  %t95 = getelementptr i8, ptr %t93, i64 0
  %t96 = sub i64 %t94, 0
  %t97 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t95, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t100 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t98, 1
  store { i32, { i64, ptr } } %t100, ptr %rv
  br label %ret
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a97aa98585cf6243_3a57acf5b7e1165f)
  unreachable
bb22:
  %t101 = load i64, ptr %l3, !tbaa !24
  store i64 %t101, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb23
bb23:
  br label %bb4
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local %"std/os:Output" @std_2fos_2eechoed(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca %"std/os:Output"
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/os:Output"
  %l10 = alloca i32
  %rv = alloca %"std/os:Output"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 4, ptr @.d39 }, 1
  %t3 = extractvalue { i64, ptr } { i64 4, ptr @.d39 }, 0
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %a0)
  %t6 = add i64 %t3, %t5
  %t7 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t6)
  call void @olang_textcopy(ptr %t7, ptr %t2, i64 %t3)
  %t8 = getelementptr i8, ptr %t7, i64 %t3
  %t9 = call i64 @__olang_fmt_i64(ptr %t8, i64 %a0)
  %t10 = insertvalue { i64, ptr } undef, i64 %t6, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t7, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t19 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 4, ptr @.d40 }, 0
  %t21 = insertvalue [2 x { i64, ptr }] %t19, { i64, ptr } %t18, 1
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call ptr @__olang_scope_alloc(ptr %t23, i64 32)
  store [2 x { i64, ptr }] %t21, ptr %t24
  %t25 = insertvalue { i64, ptr } undef, i64 2, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } %t26, 1
  %t30 = mul i64 %t28, 16
  %t31 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } { i64 0, ptr @.d41 }, ptr %l8, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t36 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t33, { i64, ptr } %t35, i1 true, { i64, ptr } { i64 0, ptr @.d42 })
  %t37 = extractvalue { i32, %"std/os:Output" } %t36, 1
  %t38 = extractvalue { i32, %"std/os:Output" } %t36, 0
  store i32 %t38, ptr %l10
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb2, label %ok.40
ok.40:
  store %"std/os:Output" %t37, ptr %l9
  br label %bb1
bb1:
  %t41 = load %"std/os:Output", ptr %l9
  store %"std/os:Output" %t41, ptr %l1
  br label %bb17
bb2:
  %t42 = load i32, ptr %l10, !tbaa !23
  %t43 = icmp eq i32 %t42, 65536
  br i1 %t43, label %bb3, label %bb4
bb3:
  call void @__olang_bang_failed(ptr @olang_loc_21d8d073ead0b48c_1401d59a5b17ee70)
  unreachable
bb4:
  %t45 = load i32, ptr %l10, !tbaa !23
  %t46 = icmp eq i32 %t45, 65537
  br i1 %t46, label %bb5, label %bb6
bb5:
  call void @__olang_bang_failed(ptr @olang_loc_601d7eabe5b7e97_232c885d24e9436b)
  unreachable
bb6:
  %t48 = load i32, ptr %l10, !tbaa !23
  %t49 = icmp eq i32 %t48, 65538
  br i1 %t49, label %bb7, label %bb8
bb7:
  call void @__olang_bang_failed(ptr @olang_loc_9d383fd056946097_8db3183fe22ffef3)
  unreachable
bb8:
  %t51 = load i32, ptr %l10, !tbaa !23
  %t52 = icmp eq i32 %t51, 65539
  br i1 %t52, label %bb9, label %bb10
bb9:
  call void @__olang_bang_failed(ptr @olang_loc_5c76252fd2d36ffa_a1ff0071ca7ba98e)
  unreachable
bb10:
  %t54 = load i32, ptr %l10, !tbaa !23
  %t55 = icmp eq i32 %t54, 65540
  br i1 %t55, label %bb11, label %bb12
bb11:
  call void @__olang_bang_failed(ptr @olang_loc_1dd2f2e12bb459b4_8d674368c6e14ca0)
  unreachable
bb12:
  %t57 = load i32, ptr %l10, !tbaa !23
  %t58 = icmp eq i32 %t57, 65541
  br i1 %t58, label %bb13, label %bb14
bb13:
  call void @__olang_bang_failed(ptr @olang_loc_9c835828fad75776_632582b031a9f72)
  unreachable
bb14:
  %t60 = load i32, ptr %l10, !tbaa !23
  %t61 = icmp eq i32 %t60, 65542
  br i1 %t61, label %bb15, label %bb16
bb15:
  call void @__olang_bang_failed(ptr @olang_loc_897ca47240d419e5_aac9bade8a27e691)
  unreachable
bb16:
  call void @__olang_bang_failed(ptr @olang_loc_ee5ec65de8eaa06c_5f01c64e98d79bf8)
  unreachable
bb17:
  %t63 = load %"std/os:Output", ptr %l1
  store %"std/os:Output" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:Output", ptr %rv
  ret %"std/os:Output" %rr
}

define dso_local { i32, i32 } @std_2fos_2ememFile() #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l5 = alloca i32
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 6, ptr @.d43 }, ptr %l1, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 1
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = call i32 @memfd_create(ptr %t2, i32 1)
  store i32 %t4, ptr %l2
  br label %bb1
bb1:
  %t5 = load i32, ptr %l2, !tbaa !23
  store i32 %t5, ptr %l0, !tbaa !23
  %t6 = load i32, ptr %l0, !tbaa !23
  %t8 = sext i32 %t6 to i64
  %t10 = call i32 @std_2fos_2echeck(i64 %t8)
  store i32 %t10, ptr %l5
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb3, label %ok.12
ok.12:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t13 = load i32, ptr %l5, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, i32 } zeroinitializer, i32 %t21, 0
  store { i32, i32 } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load i32, ptr %l0, !tbaa !23
  %t26 = insertvalue { i32, i32 } zeroinitializer, i32 %t24, 1
  store { i32, i32 } %t26, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i32 @std_2fos_2eraise(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 65536, ptr %rv
  br label %ret
bb4:
  %t6 = load i32, ptr %l0, !tbaa !23
  %t8 = icmp eq i32 %t6, 2
  br i1 %t8, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i32 65537, ptr %rv
  br label %ret
bb8:
  %t11 = load i32, ptr %l0, !tbaa !23
  %t13 = icmp eq i32 %t11, 3
  br i1 %t13, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i32 65538, ptr %rv
  br label %ret
bb12:
  %t16 = load i32, ptr %l0, !tbaa !23
  %t18 = icmp eq i32 %t16, 4
  br i1 %t18, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 65539, ptr %rv
  br label %ret
bb16:
  %t21 = load i32, ptr %l0, !tbaa !23
  %t23 = icmp eq i32 %t21, 5
  br i1 %t23, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 65540, ptr %rv
  br label %ret
bb20:
  %t26 = load i32, ptr %l0, !tbaa !23
  %t28 = icmp eq i32 %t26, 6
  br i1 %t28, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 65541, ptr %rv
  br label %ret
bb24:
  store i32 65542, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2ereadBack(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i32
  %l43 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = call i64 @lseek(i32 %t1, i64 0, i32 2)
  store i64 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i64, ptr %l6, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = call i32 @__olang_err()
  store i32 %t9, ptr %l9
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = call i32 @std_2fos_2eraise(i32 %t10)
  store i32 %t11, ptr %l10
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb6, label %ok.13
ok.13:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t22, 0
  store { i32, { i64, ptr } } %t24, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t25 = load i32, ptr %l0, !tbaa !23
  %t27 = call i64 @lseek(i32 %t25, i64 0, i32 0)
  store i64 %t27, ptr %l13
  br label %bb9
bb9:
  %t28 = load i64, ptr %l1, !tbaa !24
  store i64 %t28, ptr %l14, !tbaa !24
  %t29 = load i64, ptr %l14, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = mul i64 %t32, 1
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t39 = extractvalue { i64, ptr } %t36, 0
  %t40 = extractvalue { i64, ptr } %t36, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_63206310f1419a1b_2cb9bc5fa11cb777)
  unreachable
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load i64, ptr %l3, !tbaa !24
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb14:
  br label %bb15
bb15:
  %t54 = load i32, ptr %l0, !tbaa !23
  store i32 %t54, ptr %l23, !tbaa !23
  %t55 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t55, ptr %l24, !tbaa !27
  %t56 = load i64, ptr %l3, !tbaa !24
  store i64 %t56, ptr %l25, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t57, 0
  store i64 %t60, ptr %l28, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l29, !tbaa !24
  %t63 = load i64, ptr %l25, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load i64, ptr %l25, !tbaa !24
  %t67 = load i64, ptr %l28, !tbaa !24
  %t68 = icmp sle i64 %t66, %t67
  br i1 %t68, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_57657329f9419e06_2a1a8642ca70aa5a)
  unreachable
bb18:
  %t70 = load i64, ptr %l28, !tbaa !24
  %t71 = load i64, ptr %l29, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_57657329f9419e06_2a1a8642ca70aa5a)
  unreachable
bb20:
  %t74 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l25, !tbaa !24
  %t77 = load i64, ptr %l28, !tbaa !24
  %t78 = getelementptr i8, ptr %t75, i64 %t76
  %t79 = sub i64 %t77, %t76
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = load i64, ptr %l3, !tbaa !24
  %t88 = sub i64 %t84, %t85
  %t89 = load i32, ptr %l23, !tbaa !23
  %t91 = extractvalue { i64, ptr } %t81, 1
  %t92 = extractvalue { i64, ptr } %t81, 0
  %t94 = call i64 @read(i32 %t89, ptr %t91, i64 %t88)
  store i64 %t94, ptr %l39
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_57657329f9419e06_2a1a8642ca70aa5a)
  unreachable
bb22:
  %t95 = load i64, ptr %l39, !tbaa !24
  store i64 %t95, ptr %l4, !tbaa !24
  %t96 = load i64, ptr %l4, !tbaa !24
  %t98 = icmp slt i64 %t96, 0
  br i1 %t98, label %bb23, label %bb24
bb23:
  %t100 = call i32 @__olang_err()
  store i32 %t100, ptr %l42
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t101 = load i32, ptr %l42, !tbaa !23
  %t102 = call i32 @std_2fos_2eraise(i32 %t101)
  store i32 %t102, ptr %l43
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb27, label %ok.104
ok.104:
  br label %bb26
bb26:
  br label %bb28
bb27:
  %t105 = load i32, ptr %l43, !tbaa !23
  %t106 = lshr i32 %t105, 16
  %t107 = and i32 %t105, 65535
  %t108 = icmp eq i32 %t106, 1
  %t109 = select i1 %t108, i32 1, i32 0
  %t110 = icmp eq i32 %t105, 0
  %t111 = shl i32 %t109, 16
  %t112 = or i32 %t111, %t107
  %t113 = select i1 %t110, i32 0, i32 %t112
  call void @__olang_scope_close(ptr %s2)
  %t115 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t113, 0
  store { i32, { i64, ptr } } %t115, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t116 = load i64, ptr %l4, !tbaa !24
  %t118 = icmp eq i64 %t116, 0
  br i1 %t118, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s2)
  %t121 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65542, 0
  store { i32, { i64, ptr } } %t121, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t122 = load i64, ptr %l3, !tbaa !24
  %t123 = load i64, ptr %l4, !tbaa !24
  %t126 = add i64 %t122, %t123
  store i64 %t126, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  br label %bb12
bb34:
  %t128 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t130 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t128, 1
  store { i32, { i64, ptr } } %t130, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fos_2eremoveTree(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca i32
  %l16 = alloca i32
  %l21 = alloca i1
  %l25 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l37 = alloca { i64, ptr }
  %l44 = alloca i32
  %l50 = alloca i32
  %l52 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = getelementptr i8, ptr %t14, i64 %t10
  call void @olang_textcopy(ptr %t15, ptr %t11, i64 %t12)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t14, 1
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = extractvalue { i64, ptr } %t19, 0
  %t24 = call i32 @remove(ptr %t22)
  store i32 %t24, ptr %l14
  br label %bb4
bb4:
  %t25 = load i32, ptr %l14, !tbaa !23
  %t26 = icmp eq i32 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t28 = call i32 @__olang_err()
  store i32 %t28, ptr %l16
  br label %bb8
bb8:
  %t29 = load i32, ptr %l16, !tbaa !23
  store i32 %t29, ptr %l2, !tbaa !23
  %t30 = load i32, ptr %l2, !tbaa !23
  %t32 = icmp eq i32 %t30, 1
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t34 = load i32, ptr %l2, !tbaa !23
  %t36 = icmp ne i32 %t34, 6
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load i32, ptr %l2, !tbaa !23
  %t40 = icmp ne i32 %t38, 2
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb15, label %bb16
bb15:
  %t43 = load i32, ptr %l2, !tbaa !23
  %t45 = call i32 @std_2fos_2eraise(i32 %t43)
  store i32 %t45, ptr %l25
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb18, label %ok.47
ok.47:
  br label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb19
bb18:
  %t48 = load i32, ptr %l25, !tbaa !23
  %t49 = lshr i32 %t48, 16
  %t50 = and i32 %t48, 65535
  %t51 = icmp eq i32 %t49, 1
  %t52 = select i1 %t51, i32 1, i32 0
  %t53 = icmp eq i32 %t48, 0
  %t54 = shl i32 %t52, 16
  %t55 = or i32 %t54, %t50
  %t56 = select i1 %t53, i32 0, i32 %t55
  call void @__olang_scope_close(ptr %s0)
  store i32 %t56, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t60 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s6, { i64, ptr } %t58)
  %t61 = extractvalue { i32, { i64, ptr } } %t60, 1
  %t62 = extractvalue { i32, { i64, ptr } } %t60, 0
  store i32 %t62, ptr %l29
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb22, label %ok.64
ok.64:
  store { i64, ptr } %t61, ptr %l28
  br label %bb21
bb21:
  %t65 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t65, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l5, !tbaa !24
  br label %bb23
bb22:
  %t70 = load i32, ptr %l29, !tbaa !23
  %t71 = lshr i32 %t70, 16
  %t72 = and i32 %t70, 65535
  %t73 = icmp eq i32 %t71, 1
  %t74 = select i1 %t73, i32 1, i32 0
  %t75 = icmp eq i32 %t70, 0
  %t76 = shl i32 %t74, 16
  %t77 = or i32 %t76, %t72
  %t78 = select i1 %t75, i32 0, i32 %t77
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t78, ptr %rv
  br label %ret
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  %t80 = load i64, ptr %l4, !tbaa !24
  %t81 = load i64, ptr %l5, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t88 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t88, ptr %l37, !tbaa !27
  %t89 = load i64, ptr %l4, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %t92, i64 %t89
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !37
  %t96 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t96, 1
  %t100 = extractvalue { i64, ptr } %t96, 0
  %t101 = extractvalue { i64, ptr } { i64 1, ptr @.d45 }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr @.d45 }, 0
  %t103 = add i64 %t100, %t102
  %t105 = extractvalue { i64, ptr } %t94, 1
  %t106 = extractvalue { i64, ptr } %t94, 0
  %t107 = add i64 %t103, %t106
  %t108 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t107)
  call void @olang_textcopy(ptr %t108, ptr %t99, i64 %t100)
  %t109 = getelementptr i8, ptr %t108, i64 %t100
  call void @olang_textcopy(ptr %t109, ptr %t101, i64 %t102)
  %t110 = getelementptr i8, ptr %t109, i64 %t102
  call void @olang_textcopy(ptr %t110, ptr %t105, i64 %t106)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t108, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = extractvalue { i64, ptr } %t112, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t121 = call i32 @std_2fos_2eremoveTree(ptr %s7, { i64, ptr } %t119)
  store i32 %t121, ptr %l44
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb28, label %ok.123
ok.123:
  br label %bb27
bb27:
  br label %bb29
bb28:
  %t124 = load i32, ptr %l44, !tbaa !23
  %t125 = lshr i32 %t124, 16
  %t126 = and i32 %t124, 65535
  %t127 = icmp eq i32 %t125, 1
  %t128 = select i1 %t127, i32 1, i32 0
  %t129 = icmp eq i32 %t124, 0
  %t130 = shl i32 %t128, 16
  %t131 = or i32 %t130, %t126
  %t132 = select i1 %t129, i32 0, i32 %t131
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t132, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t134 = load i64, ptr %l4, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l4, !tbaa !24
  br label %bb23
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t138 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = extractvalue { i64, ptr } %t138, 0
  %t143 = call i32 @remove(ptr %t141)
  store i32 %t143, ptr %l50
  br label %bb33
bb33:
  %t144 = load i32, ptr %l50, !tbaa !23
  %t145 = sext i32 %t144 to i64
  %t147 = call i32 @std_2fos_2echeck(i64 %t145)
  store i32 %t147, ptr %l52
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb35, label %ok.149
ok.149:
  br label %bb34
bb34:
  br label %bb36
bb35:
  %t150 = load i32, ptr %l52, !tbaa !23
  %t151 = lshr i32 %t150, 16
  %t152 = and i32 %t150, 65535
  %t153 = icmp eq i32 %t151, 1
  %t154 = select i1 %t153, i32 1, i32 0
  %t155 = icmp eq i32 %t150, 0
  %t156 = shl i32 %t154, 16
  %t157 = or i32 %t156, %t152
  %t158 = select i1 %t155, i32 0, i32 %t157
  call void @__olang_scope_close(ptr %s0)
  store i32 %t158, ptr %rv
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fos_2estd_2fos_3aProcess_2eKill(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/os:Process", ptr %t8, i32 0, i32 0
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = call i32 @kill(i32 %t11, i32 9)
  store i32 %t13, ptr %l6
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fos_2estd_2fos_3aProcess_2ePid(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/os:Process", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWait(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca [1 x i32]
  %l11 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l17 = alloca %"std/os:Output"
  %l20 = alloca %"std/os:Output"
  %l21 = alloca i32
  %rv = alloca { i32, %"std/os:Output" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t7 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 65542, 0
  store { i32, %"std/os:Output" } %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t8, ptr %l1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/os:Process", ptr %t10, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = insertvalue { i64, ptr } undef, i64 1, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %l1, 1
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = call i32 @waitpid(i32 %t13, ptr %t20, i32 0)
  store i32 %t22, ptr %l11
  br label %bb4
bb4:
  %t23 = load i32, ptr %l11, !tbaa !23
  %t24 = icmp slt i32 %t23, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l13, !tbaa !29
  %t27 = call i32 @__olang_err()
  store i32 %t27, ptr %l14
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t28 = load ptr, ptr %l13, !tbaa !29
  %t29 = load i32, ptr %l14, !tbaa !23
  %t30 = call i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l15
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb9, label %ok.32
ok.32:
  br label %bb8
bb8:
  br label %bb10
bb9:
  %t33 = load i32, ptr %l15, !tbaa !23
  %t34 = lshr i32 %t33, 16
  %t35 = and i32 %t33, 65535
  %t36 = icmp eq i32 %t34, 1
  %t37 = select i1 %t36, i32 1, i32 0
  %t38 = icmp eq i32 %t33, 0
  %t39 = shl i32 %t37, 16
  %t40 = or i32 %t39, %t35
  %t41 = select i1 %t38, i32 0, i32 %t40
  %t43 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t41, 0
  store { i32, %"std/os:Output" } %t43, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr [1 x i32], ptr %l1, i64 0, i64 0
  %t46 = load i32, ptr %t45, !tbaa !33
  %t49 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %v1, ptr %t44, i32 %t46)
  %t50 = extractvalue { i32, %"std/os:Output" } %t49, 1
  %t51 = extractvalue { i32, %"std/os:Output" } %t49, 0
  store i32 %t51, ptr %l21
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb13, label %ok.53
ok.53:
  store %"std/os:Output" %t50, ptr %l20
  br label %bb12
bb12:
  %t54 = load %"std/os:Output", ptr %l20
  store %"std/os:Output" %t54, ptr %l17
  br label %bb14
bb13:
  %t55 = load i32, ptr %l21, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  %t65 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t63, 0
  store { i32, %"std/os:Output" } %t65, ptr %rv
  br label %ret
bb14:
  %t66 = load %"std/os:Output", ptr %l17
  %t67 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t66, 1
  store { i32, %"std/os:Output" } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWaitUntil(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca [1 x i32]
  %l3 = alloca [2 x i64]
  %l4 = alloca [2 x i64]
  %l5 = alloca i64
  %l6 = alloca i32
  %l18 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %l29 = alloca %"std/os:Output"
  %l32 = alloca %"std/os:Output"
  %l33 = alloca i32
  %l36 = alloca i1
  %l43 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l49 = alloca %"std/os:Output"
  %l52 = alloca %"std/os:Output"
  %l53 = alloca i32
  %l58 = alloca i32
  %l67 = alloca i32
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t7 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 65542, 0
  store { i32, %"std/os:Output" } %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t8, ptr %l2
  %t10 = insertvalue [2 x i64] undef, i64 0, 0
  %t11 = insertvalue [2 x i64] %t10, i64 0, 1
  store [2 x i64] %t11, ptr %l3
  %t13 = insertvalue [2 x i64] undef, i64 0, 0
  %t14 = insertvalue [2 x i64] %t13, i64 0, 1
  store [2 x i64] %t14, ptr %l4
  store i64 50000, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/os:Process", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = insertvalue { i64, ptr } undef, i64 1, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %l2, 1
  %t26 = extractvalue { i64, ptr } %t22, 1
  %t27 = extractvalue { i64, ptr } %t22, 0
  %t28 = call i32 @waitpid(i32 %t19, ptr %t26, i32 1)
  store i32 %t28, ptr %l18
  br label %bb5
bb5:
  %t29 = load i32, ptr %l18, !tbaa !23
  store i32 %t29, ptr %l6, !tbaa !23
  %t30 = load i32, ptr %l6, !tbaa !23
  %t32 = icmp slt i32 %t30, 0
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = call i32 @__olang_err()
  store i32 %t35, ptr %l22
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load i32, ptr %l22, !tbaa !23
  %t38 = call i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t38, ptr %l23
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb10, label %ok.40
ok.40:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = lshr i32 %t41, 16
  %t43 = and i32 %t41, 65535
  %t44 = icmp eq i32 %t42, 1
  %t45 = select i1 %t44, i32 1, i32 0
  %t46 = icmp eq i32 %t41, 0
  %t47 = shl i32 %t45, 16
  %t48 = or i32 %t47, %t43
  %t49 = select i1 %t46, i32 0, i32 %t48
  call void @__olang_scope_close(ptr %s2)
  %t51 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t49, 0
  store { i32, %"std/os:Output" } %t51, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t52 = load i32, ptr %l6, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/os:Process", ptr %t53, i32 0, i32 0
  %t56 = load i32, ptr %t55, !tbaa !23
  %t59 = icmp eq i32 %t52, %t56
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr [1 x i32], ptr %l2, i64 0, i64 0
  %t63 = load i32, ptr %t62, !tbaa !33
  %t66 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %v2, ptr %t61, i32 %t63)
  %t67 = extractvalue { i32, %"std/os:Output" } %t66, 1
  %t68 = extractvalue { i32, %"std/os:Output" } %t66, 0
  store i32 %t68, ptr %l33
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb16, label %ok.70
ok.70:
  store %"std/os:Output" %t67, ptr %l32
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t71 = load %"std/os:Output", ptr %l32
  store %"std/os:Output" %t71, ptr %l29
  br label %bb17
bb16:
  %t72 = load i32, ptr %l33, !tbaa !23
  %t73 = lshr i32 %t72, 16
  %t74 = and i32 %t72, 65535
  %t75 = icmp eq i32 %t73, 1
  %t76 = select i1 %t75, i32 1, i32 0
  %t77 = icmp eq i32 %t72, 0
  %t78 = shl i32 %t76, 16
  %t79 = or i32 %t78, %t74
  %t80 = select i1 %t77, i32 0, i32 %t79
  call void @__olang_scope_close(ptr %s2)
  %t82 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t80, 0
  store { i32, %"std/os:Output" } %t82, ptr %rv
  br label %ret
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t83 = load %"std/os:Output", ptr %l29
  %t84 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t83, 1
  store { i32, %"std/os:Output" } %t84, ptr %rv
  br label %ret
bb18:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = call i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v1, ptr %t85)
  store i1 %t87, ptr %l36
  br label %bb19
bb19:
  %t88 = load i1, ptr %l36, !tbaa !21
  br i1 %t88, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t89 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fos_2estd_2fos_3aProcess_2eKill(ptr %v0, ptr %t89)
  br label %bb22
bb21:
  br label %bb40
bb22:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"std/os:Process", ptr %t91, i32 0, i32 0
  %t94 = load i32, ptr %t93, !tbaa !23
  %t96 = insertvalue { i64, ptr } undef, i64 1, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %l2, 1
  %t101 = extractvalue { i64, ptr } %t97, 1
  %t102 = extractvalue { i64, ptr } %t97, 0
  %t103 = call i32 @waitpid(i32 %t94, ptr %t101, i32 0)
  store i32 %t103, ptr %l43
  br label %bb23
bb23:
  %t104 = load i32, ptr %l43, !tbaa !23
  %t105 = icmp slt i32 %t104, 0
  br i1 %t105, label %bb24, label %bb25
bb24:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l45, !tbaa !29
  %t108 = call i32 @__olang_err()
  store i32 %t108, ptr %l46
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t109 = load ptr, ptr %l45, !tbaa !29
  %t110 = load i32, ptr %l46, !tbaa !23
  %t111 = call i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t111, ptr %l47
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb28, label %ok.113
ok.113:
  br label %bb27
bb27:
  br label %bb29
bb28:
  %t114 = load i32, ptr %l47, !tbaa !23
  %t115 = lshr i32 %t114, 16
  %t116 = and i32 %t114, 65535
  %t117 = icmp eq i32 %t115, 1
  %t118 = select i1 %t117, i32 1, i32 0
  %t119 = icmp eq i32 %t114, 0
  %t120 = shl i32 %t118, 16
  %t121 = or i32 %t120, %t116
  %t122 = select i1 %t119, i32 0, i32 %t121
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  %t124 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t122, 0
  store { i32, %"std/os:Output" } %t124, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr [1 x i32], ptr %l2, i64 0, i64 0
  %t127 = load i32, ptr %t126, !tbaa !33
  %t130 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %s5, ptr %t125, i32 %t127)
  %t131 = extractvalue { i32, %"std/os:Output" } %t130, 1
  %t132 = extractvalue { i32, %"std/os:Output" } %t130, 0
  store i32 %t132, ptr %l53
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb32, label %ok.134
ok.134:
  store %"std/os:Output" %t131, ptr %l52
  br label %bb31
bb31:
  %t135 = load %"std/os:Output", ptr %l52
  store %"std/os:Output" %t135, ptr %l49
  br label %bb36
bb32:
  %t136 = load i32, ptr %l53, !tbaa !23
  %t137 = ashr i32 %t136, 16
  %t139 = icmp eq i32 %t137, 1
  br i1 %t139, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  %t141 = load i32, ptr %l53, !tbaa !23
  %t142 = lshr i32 %t141, 16
  %t143 = and i32 %t141, 65535
  %t144 = icmp eq i32 %t142, 1
  %t145 = select i1 %t144, i32 1, i32 0
  %t146 = icmp eq i32 %t141, 0
  %t147 = shl i32 %t145, 16
  %t148 = or i32 %t147, %t143
  %t149 = select i1 %t146, i32 0, i32 %t148
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  %t151 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t149, 0
  store { i32, %"std/os:Output" } %t151, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = call i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v1, ptr %t152)
  store i32 %t154, ptr %l58
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb38, label %ok.156
ok.156:
  br label %bb37
bb37:
  br label %bb39
bb38:
  %t157 = load i32, ptr %l58, !tbaa !23
  %t158 = lshr i32 %t157, 16
  %t159 = and i32 %t157, 65535
  %t160 = icmp eq i32 %t158, 1
  %t161 = select i1 %t160, i32 2, i32 0
  %t162 = icmp eq i32 %t157, 0
  %t163 = shl i32 %t161, 16
  %t164 = or i32 %t163, %t159
  %t165 = select i1 %t162, i32 0, i32 %t164
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  %t167 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t165, 0
  store { i32, %"std/os:Output" } %t167, ptr %rv
  br label %ret
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb40:
  %t168 = getelementptr [2 x i64], ptr %l3, i64 0, i64 0
  store i64 0, ptr %t168, !tbaa !34
  %t169 = load i64, ptr %l5, !tbaa !24
  %t171 = getelementptr [2 x i64], ptr %l3, i64 0, i64 1
  store i64 %t169, ptr %t171, !tbaa !34
  %t173 = insertvalue { i64, ptr } undef, i64 2, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %l3, 1
  %t177 = insertvalue { i64, ptr } undef, i64 2, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %l4, 1
  %t181 = extractvalue { i64, ptr } %t174, 1
  %t182 = extractvalue { i64, ptr } %t174, 0
  %t184 = extractvalue { i64, ptr } %t178, 1
  %t185 = extractvalue { i64, ptr } %t178, 0
  %t186 = call i32 @nanosleep(ptr %t181, ptr %t184)
  store i32 %t186, ptr %l67
  br label %bb41
bb41:
  %t187 = load i64, ptr %l5, !tbaa !24
  %t188 = load i64, ptr @G_2estd_2fcancel_2ePollNs, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  br i1 %t191, label %bb42, label %bb43
bb42:
  %t193 = load i64, ptr %l5, !tbaa !24
  %t195 = mul i64 %t193, 2
  store i64 %t195, ptr %l5, !tbaa !24
  br label %bb44
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb45:
  br label %bb4
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eended(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l17 = alloca %"std/os:Output"
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l36 = alloca i32
  %l39 = alloca i32
  %l42 = alloca i32
  %l43 = alloca %"std/os:Output"
  %l46 = alloca i32
  %l49 = alloca i32
  %rv = alloca { i32, %"std/os:Output" }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t1, i32 0, i32 4
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = ashr i32 %t4, 8
  %t8 = and i32 %t6, 255
  store i32 %t8, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l1, !tbaa !23
  %t12 = and i32 %t10, 127
  %t14 = icmp ne i32 %t12, 0
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = and i32 %t16, 127
  %t20 = add i32 128, %t18
  store i32 %t20, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/os:Process", ptr %t22, i32 0, i32 3
  %t25 = load i1, ptr %t24, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i32, ptr %l2, !tbaa !23
  %t31 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t29, { i64, ptr } { i64 0, ptr @.d46 }, { i64, ptr } { i64 0, ptr @.d47 })
  store %"std/os:Output" %t31, ptr %l17
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t32 = load %"std/os:Output", ptr %l17
  %t33 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t32, 1
  store { i32, %"std/os:Output" } %t33, ptr %rv
  br label %ret
bb7:
  %t34 = load i32, ptr %l2, !tbaa !23
  store i32 %t34, ptr %l18, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"std/os:Process", ptr %t35, i32 0, i32 1
  %t38 = load i32, ptr %t37, !tbaa !23
  %t40 = call { i32, { i64, ptr } } @std_2fos_2ereadBack(ptr %v1, i32 %t38)
  %t41 = extractvalue { i32, { i64, ptr } } %t40, 1
  %t42 = extractvalue { i32, { i64, ptr } } %t40, 0
  store i32 %t42, ptr %l23
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb9, label %ok.44
ok.44:
  store { i64, ptr } %t41, ptr %l22
  br label %bb8
bb8:
  %t45 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t45, ptr %l19, !tbaa !27
  br label %bb12
bb9:
  %t46 = load i32, ptr %l23, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  store i32 %t54, ptr %l24, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/os:Process", ptr %t55, i32 0, i32 1
  %t58 = load i32, ptr %t57, !tbaa !23
  %t60 = call i32 @close(i32 %t58)
  store i32 %t60, ptr %l27
  br label %bb10
bb10:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"std/os:Process", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = call i32 @close(i32 %t64)
  store i32 %t66, ptr %l30
  br label %bb11
bb11:
  %t67 = load i32, ptr %l24, !tbaa !23
  %t68 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t67, 0
  store { i32, %"std/os:Output" } %t68, ptr %rv
  br label %ret
bb12:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"std/os:Process", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = call { i32, { i64, ptr } } @std_2fos_2ereadBack(ptr %v1, i32 %t72)
  %t75 = extractvalue { i32, { i64, ptr } } %t74, 1
  %t76 = extractvalue { i32, { i64, ptr } } %t74, 0
  store i32 %t76, ptr %l35
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb14, label %ok.78
ok.78:
  store { i64, ptr } %t75, ptr %l34
  br label %bb13
bb13:
  %t79 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t79, ptr %l31, !tbaa !27
  br label %bb17
bb14:
  %t80 = load i32, ptr %l35, !tbaa !23
  %t81 = lshr i32 %t80, 16
  %t82 = and i32 %t80, 65535
  %t83 = icmp eq i32 %t81, 1
  %t84 = select i1 %t83, i32 1, i32 0
  %t85 = icmp eq i32 %t80, 0
  %t86 = shl i32 %t84, 16
  %t87 = or i32 %t86, %t82
  %t88 = select i1 %t85, i32 0, i32 %t87
  store i32 %t88, ptr %l36, !tbaa !23
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/os:Process", ptr %t89, i32 0, i32 1
  %t92 = load i32, ptr %t91, !tbaa !23
  %t94 = call i32 @close(i32 %t92)
  store i32 %t94, ptr %l39
  br label %bb15
bb15:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"std/os:Process", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %t97, !tbaa !23
  %t100 = call i32 @close(i32 %t98)
  store i32 %t100, ptr %l42
  br label %bb16
bb16:
  %t101 = load i32, ptr %l36, !tbaa !23
  %t102 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t101, 0
  store { i32, %"std/os:Output" } %t102, ptr %rv
  br label %ret
bb17:
  %t103 = load i32, ptr %l18, !tbaa !23
  %t104 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t106 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t103, { i64, ptr } %t104, { i64, ptr } %t105)
  store %"std/os:Output" %t106, ptr %l43
  br label %bb18
bb18:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"std/os:Process", ptr %t107, i32 0, i32 1
  %t110 = load i32, ptr %t109, !tbaa !23
  %t112 = call i32 @close(i32 %t110)
  store i32 %t112, ptr %l46
  br label %bb19
bb19:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"std/os:Process", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = call i32 @close(i32 %t116)
  store i32 %t118, ptr %l49
  br label %bb20
bb20:
  %t119 = load %"std/os:Output", ptr %l43
  %t120 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t119, 1
  store { i32, %"std/os:Output" } %t120, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t1, i32 0, i32 4
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"std/os:Process", ptr %t4, i32 0, i32 3
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/os:Process", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = call i32 @close(i32 %t12)
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/os:Process", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = call i32 @close(i32 %t18)
  store i32 %t20, ptr %l10
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t23 = call i32 @std_2fos_2eraise(i32 %a1)
  store i32 %t23, ptr %l12
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb7, label %ok.25
ok.25:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t26 = load i32, ptr %l12, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  store i32 %t34, ptr %rv
  br label %ret
bb8:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @std_2fos_2etempDir(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t9, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t13, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t15 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 6, ptr @.d48 })
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l9
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19
ok.19:
  store { i64, ptr } %t16, ptr %l8
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t20, ptr %l7, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  store { i64, ptr } { i64 0, ptr @.d49 }, ptr %l10, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t30, ptr %l1, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = extractvalue { i64, ptr } %t37, 0
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t39, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t43, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store { i64, ptr } { i64 4, ptr @.d50 }, ptr %l18, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t45, ptr %l19, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l20, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l21, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l20, !tbaa !24
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t59, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/os:FileInfo" @std_2fos_3aFileInfo_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"std/os:FileInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"std/os:FileInfo" undef, i32 %a0, 0
  %t10 = insertvalue %"std/os:FileInfo" %t8, i64 %a1, 1
  %t12 = insertvalue %"std/os:FileInfo" %t10, i64 %a2, 2
  store %"std/os:FileInfo" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:FileInfo", ptr %rv
  ret %"std/os:FileInfo" %rr
}

define dso_local %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"std/os:Output"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"std/os:Output" undef, i32 %a0, 0
  %t10 = insertvalue %"std/os:Output" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"std/os:Output" %t10, { i64, ptr } %a2, 2
  store %"std/os:Output" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:Output", ptr %rv
  ret %"std/os:Output" %rr
}

define dso_local %"std/os:Process" @std_2fos_3aProcess_2ector(ptr %v0, i32 %a0, i32 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"std/os:Process"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"std/os:Process" undef, i32 %a0, 0
  %t12 = insertvalue %"std/os:Process" %t10, i32 %a1, 1
  %t14 = insertvalue %"std/os:Process" %t12, i32 %a2, 2
  %t16 = insertvalue %"std/os:Process" %t14, i1 %a3, 3
  %t18 = insertvalue %"std/os:Process" %t16, i1 false, 4
  store %"std/os:Process" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:Process", ptr %rv
  ret %"std/os:Process" %rr
}

declare i64 @__olang_arg_count()
declare void @__olang_check_failed(ptr)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d0 = private constant [0 x i8] c""
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare i64 @__olang_arg(i64, ptr, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @close(i32)
@.d1 = private constant [1 x i8] c"\00"
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare i32 @creat(ptr, i32)
@.d2 = private constant [1 x i8] c"."
@.d3 = private constant [1 x i8] c"\00"
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i64 @olang_lambda_4(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l9 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t10 = extractvalue { i64, ptr } %cv0, 1
  %t11 = extractvalue { i64, ptr } %cv0, 0
  %t13 = extractvalue { i64, ptr } %t4, 1
  %t14 = extractvalue { i64, ptr } %t4, 0
  %t16 = call i64 @__olang_env(ptr %t10, ptr %t13, i64 %t8)
  store i64 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i64, ptr %l9, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.d5 = private constant [1 x i8] c"\00"
declare i32 @__olang_exec(ptr, ptr, i64)
declare i32 @__olang_err()
@.d6 = private constant [1 x i8] c"\00"
declare i32 @__olang_stat(ptr, ptr)
declare void @exit(i32) noreturn
@.d7 = private constant [1 x i8] c"\00"
declare i32 @isatty(i32)
@.d8 = private constant [1 x i8] c"\00"
@.d9 = private constant [1 x i8] c"\00"
declare i32 @link(ptr, ptr)
@.d10 = private constant [1 x i8] c"\00"
declare i32 @mkdir(ptr, i32)
@.d11 = private constant [1 x i8] c"\00"
@.d12 = private constant [1 x i8] c"/"
@.d13 = private constant [1 x i8] c"/"
@.d14 = private constant [0 x i8] c""
@.d15 = private constant [1 x i8] c"/"
@.d16 = private constant [7 x i8] c"XXXXXX\00"
declare i32 @__olang_mkdtemp(ptr)
declare void @__olang_on_crash(ptr, i64)
@.d17 = private constant [1 x i8] c"\00"
declare i32 @open(ptr, i32)
@.d18 = private constant [1 x i8] c"'"
@.d19 = private constant [4 x i8] c"'\5C''"
@.d20 = private constant [1 x i8] c"'"
@.d21 = private constant [1 x i8] c"\00"
define internal i64 @olang_lambda_22(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l9 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t10 = extractvalue { i64, ptr } %cv0, 1
  %t11 = extractvalue { i64, ptr } %cv0, 0
  %t13 = extractvalue { i64, ptr } %t4, 1
  %t14 = extractvalue { i64, ptr } %t4, 0
  %t16 = call i64 @__olang_dir(ptr %t10, ptr %t13, i64 %t8)
  store i64 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i64, ptr %l9, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.d23 = private constant [1 x i8] c"\00"
define internal i1 @olang_lambda_24(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eCompare(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = icmp slt i32 %t6, 0
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d25 = private constant [1 x i8] c"\00"
declare i64 @lseek(i32, i64, i32)
declare i64 @read(i32, ptr, i64)
@.d26 = private constant [1 x i8] c"\00"
declare i64 @readlink(ptr, ptr, i64)
@.d27 = private constant [1 x i8] c"\00"
define internal i64 @olang_lambda_28(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l9 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t10 = extractvalue { i64, ptr } %cv0, 1
  %t11 = extractvalue { i64, ptr } %cv0, 0
  %t13 = extractvalue { i64, ptr } %t4, 1
  %t14 = extractvalue { i64, ptr } %t4, 0
  %t16 = call i64 @__olang_realpath(ptr %t10, ptr %t13, i64 %t8)
  store i64 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i64, ptr %l9, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.d29 = private constant [1 x i8] c"\00"
declare i32 @remove(ptr)
@.d30 = private constant [1 x i8] c"."
@.d31 = private constant [2 x i8] c".."
@.d32 = private constant [1 x i8] c"\00"
@.d33 = private constant [1 x i8] c"\00"
declare i32 @rename(ptr, ptr)
@.d34 = private constant [1 x i8] c"\00"
declare i32 @system(ptr)
declare void @__olang_run_on_stack(i64, ptr, ptr)
@.d35 = private constant [6 x i8] c"olang\00"
declare i32 @memfd_create(ptr, i32)
@.d36 = private constant [1 x i8] c"\00"
declare i32 @__olang_spawn(ptr, i64, i32, i32, i32, ptr)
@.d37 = private constant [1 x i8] c"\00"
declare i64 @__olang_fmt_i64(ptr, i64)
@.d38 = private constant [61 x i8] c"-------------------------------------------------------------"
@.d39 = private constant [4 x i8] c"run "
@.d40 = private constant [4 x i8] c"echo"
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d41 = private constant [0 x i8] c""
@.d42 = private constant [0 x i8] c""
declare void @__olang_bang_failed(ptr)
@.d43 = private constant [6 x i8] c"olang\00"
@.d44 = private constant [1 x i8] c"\00"
@.d45 = private constant [1 x i8] c"/"
declare i32 @kill(i32, i32)
declare i32 @waitpid(i32, ptr, i32)
declare i32 @nanosleep(ptr, ptr)
@.d46 = private constant [0 x i8] c""
@.d47 = private constant [0 x i8] c""
@.d48 = private constant [6 x i8] c"TMPDIR"
@.d49 = private constant [0 x i8] c""
@.d50 = private constant [4 x i8] c"/tmp"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare i64 @__olang_env(ptr, ptr, i64)
declare i64 @__olang_dir(ptr, ptr, i64)
declare i64 @__olang_realpath(ptr, ptr, i64)
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
@olang_loc_2e089b9dcc6d7cfd_6f26744b60ea9b91 = external constant [0 x i8]
@olang_loc_722c60a9fee6cfd0_5c8c3a8aa9ab1a84 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_c6732c6b36ef1233_192580cd7896553f = external constant [0 x i8]
@olang_loc_bf01453b0cfded25_a369431636c6fdd9 = external constant [0 x i8]
@olang_loc_1b39f3aec8a2d100_9d79a3da2d056474 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_93142f54c4ba4464_592b0bc010c9eac8 = external constant [0 x i8]
@olang_loc_3ae06a7cd351f714_4bcb8792cbdf34a0 = external constant [0 x i8]
@olang_loc_63ca89910fe1f481_50e57e01f8d90efd = external constant [0 x i8]
@olang_loc_879ad2febb339b7d_10a4c06fe5c76379 = external constant [0 x i8]
@olang_loc_2b89142fbf8fc460_df42bdef933d62c4 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eSort_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
@olang_loc_587e358192386240_8b720e6e0da4b04 = external constant [0 x i8]
@olang_loc_79e8bbcf109c76d_1b515aa79819cc11 = external constant [0 x i8]
@olang_loc_b2d60bcaef35f8ee_ec573b413169e46a = external constant [0 x i8]
@olang_loc_870dc790e95aa6eb_a67bfaf9489a2847 = external constant [0 x i8]
@olang_loc_3bbcea0c000efd36_21b55d08ecf81e22 = external constant [0 x i8]
@olang_loc_ff17d2e56a811dcb_410ea2db80d8aad7 = external constant [0 x i8]
@olang_loc_d7f228265709f418_7e9f802c53b666ac = external constant [0 x i8]
@olang_loc_9d6ebd177b1045e9_d85719897e835afd = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2520df159ef45bd8_53b6e0dcdbf625cc = external constant [0 x i8]
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_7455114053b9a685_f9a96b9bd4adb589 = external constant [0 x i8]
@olang_loc_d680568c47c09218_ee59193b16d39a3c = external constant [0 x i8]
@olang_loc_a97aa98585cf6243_3a57acf5b7e1165f = external constant [0 x i8]
@olang_loc_21d8d073ead0b48c_1401d59a5b17ee70 = external constant [0 x i8]
@olang_loc_601d7eabe5b7e97_232c885d24e9436b = external constant [0 x i8]
@olang_loc_9d383fd056946097_8db3183fe22ffef3 = external constant [0 x i8]
@olang_loc_5c76252fd2d36ffa_a1ff0071ca7ba98e = external constant [0 x i8]
@olang_loc_1dd2f2e12bb459b4_8d674368c6e14ca0 = external constant [0 x i8]
@olang_loc_9c835828fad75776_632582b031a9f72 = external constant [0 x i8]
@olang_loc_897ca47240d419e5_aac9bade8a27e691 = external constant [0 x i8]
@olang_loc_ee5ec65de8eaa06c_5f01c64e98d79bf8 = external constant [0 x i8]
@olang_loc_63206310f1419a1b_2cb9bc5fa11cb777 = external constant [0 x i8]
@olang_loc_57657329f9419e06_2a1a8642ca70aa5a = external constant [0 x i8]
declare i1 @std_2fcancel_2estd_2fcancel_3aToken_2eCancelled(ptr %v0, ptr %a0)
declare i32 @std_2fcancel_2estd_2fcancel_3aToken_2eReason(ptr %v0, ptr %a0)
@G_2estd_2fcancel_2ePollNs = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\80\96\98\00\00\00\00\00" }>, align 8
declare i32 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eCompare(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
