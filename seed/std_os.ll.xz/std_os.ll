; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/os:File" = type { i32 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/os:Process" = type { i32, i32, i32, i1, i1, i64 }
define dso_local { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s0, ptr %v0, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l1
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t6, ptr %l0, !tbaa !27
  br label %bb3
bb2:
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = lshr i32 %t7, 16
  %t9 = and i32 %t7, 65535
  %t10 = icmp eq i32 %t8, 1
  %t11 = select i1 %t10, i32 1, i32 0
  %t12 = icmp eq i32 %t7, 0
  %t13 = shl i32 %t11, 16
  %t14 = or i32 %t13, %t9
  %t15 = select i1 %t12, i32 0, i32 %t14
  call void @__olang_scope_close(ptr %s0)
  %t17 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t15, 0
  store { i32, { i64, ptr } } %t17, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t18, 1
  store { i32, { i64, ptr } } %t19, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca [3 x i64]
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [3 x i64] undef, i64 0, 0
  %t2 = insertvalue [3 x i64] %t1, i64 0, 1
  %t3 = insertvalue [3 x i64] %t2, i64 0, 2
  store [3 x i64] %t3, ptr %l1
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t7, i64 %t8)
  %t13 = getelementptr i8, ptr %t12, i64 %t8
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t18 = insertvalue { i64, ptr } undef, i64 3, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %l1, 1
  %t22 = extractvalue { i64, ptr } %t15, 1
  %t23 = extractvalue { i64, ptr } %t15, 0
  %t25 = extractvalue { i64, ptr } %t19, 1
  %t26 = extractvalue { i64, ptr } %t19, 0
  %t27 = call i32 @__olang_stat(ptr %t22, ptr %t25)
  store i32 %t27, ptr %l9
  br label %bb1
bb1:
  %t28 = load i32, ptr %l9, !tbaa !23
  %t29 = icmp eq i32 %t28, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @std_2fos_2eExit(i32 %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @exit(i32 %a0)
  unreachable
bb1:
  call void @__olang_check_failed(ptr @olang_loc_bf01453b0cfded25_a369431636c6fdd9)
  unreachable
ret:
  ret void
}

define dso_local { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca [3 x i64]
  %l2 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i32
  %l25 = alloca %"std/os:FileInfo"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:FileInfo" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [3 x i64] undef, i64 0, 0
  %t2 = insertvalue [3 x i64] %t1, i64 0, 1
  %t3 = insertvalue [3 x i64] %t2, i64 0, 2
  store [3 x i64] %t3, ptr %l1
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t7, i64 %t8)
  %t13 = getelementptr i8, ptr %t12, i64 %t8
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t18 = insertvalue { i64, ptr } undef, i64 3, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %l1, 1
  %t22 = extractvalue { i64, ptr } %t15, 1
  %t23 = extractvalue { i64, ptr } %t15, 0
  %t25 = extractvalue { i64, ptr } %t19, 1
  %t26 = extractvalue { i64, ptr } %t19, 0
  %t27 = call i32 @__olang_stat(ptr %t22, ptr %t25)
  store i32 %t27, ptr %l10
  br label %bb1
bb1:
  %t28 = load i32, ptr %l10, !tbaa !23
  %t29 = sext i32 %t28 to i64
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = call i32 @std_2fos_2echeck(ptr %v0, i64 %t29, { i64, ptr } %t30)
  store i32 %t33, ptr %l13
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb3, label %ok.35, !prof !99
ok.35:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t36 = load i32, ptr %l13, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  call void @__olang_scope_close(ptr %s0)
  %t46 = insertvalue { i32, %"std/os:FileInfo" } zeroinitializer, i32 %t44, 0
  store { i32, %"std/os:FileInfo" } %t46, ptr %rv
  br label %ret
bb4:
  store i32 2, ptr %l2
  %t48 = getelementptr [3 x i64], ptr %l1, i64 0, i64 0
  %t49 = load i64, ptr %t48, !tbaa !34
  %t51 = icmp eq i64 %t49, 1
  br i1 %t51, label %bb5, label %bb6
bb5:
  store i32 0, ptr %l2
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t54 = getelementptr [3 x i64], ptr %l1, i64 0, i64 0
  %t55 = load i64, ptr %t54, !tbaa !34
  %t57 = icmp eq i64 %t55, 2
  br i1 %t57, label %bb8, label %bb9
bb8:
  store i32 1, ptr %l2
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t60 = load i32, ptr %l2, !range !{i32 0, i32 3}
  %t61 = getelementptr [3 x i64], ptr %l1, i64 0, i64 1
  %t62 = load i64, ptr %t61, !tbaa !34
  %t63 = getelementptr [3 x i64], ptr %l1, i64 0, i64 2
  %t64 = load i64, ptr %t63, !tbaa !34
  %t68 = call %"std/os:FileInfo" @std_2fos_3aFileInfo_2ector(ptr %s0, i32 %t60, i64 %t62, i64 %t64)
  store %"std/os:FileInfo" %t68, ptr %l25
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load %"std/os:FileInfo", ptr %l25
  %t70 = insertvalue { i32, %"std/os:FileInfo" } zeroinitializer, %"std/os:FileInfo" %t69, 1
  store { i32, %"std/os:FileInfo" } %t70, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:FileInfo" }, ptr %rv
  ret { i32, %"std/os:FileInfo" } %rr
}

define dso_local { i32, %"std/os:File" } @std_2fos_2eFile_2eOpen(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i32
  %l14 = alloca %"std/os:File"
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:File" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t13, ptr %l5
  br label %bb1
bb1:
  %t14 = load i1, ptr %l5, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i32 32768, ptr %l6, !tbaa !23
  br label %bb4
bb3:
  store i32 0, ptr %l6, !tbaa !23
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t18 = load i32, ptr %l6, !tbaa !23
  %t19 = call i32 (ptr, i32, ...) @open(ptr %t16, i32 %t18)
  store i32 %t19, ptr %l7
  br label %bb5
bb5:
  %t20 = load i32, ptr %l7, !tbaa !23
  store i32 %t20, ptr %l1, !tbaa !23
  %t21 = load i32, ptr %l1, !tbaa !23
  %t23 = sext i32 %t21 to i64
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = call i32 @std_2fos_2echeck(ptr %v0, i64 %t23, { i64, ptr } %t24)
  store i32 %t27, ptr %l11
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb7, label %ok.29, !prof !99
ok.29:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t30 = load i32, ptr %l11, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  call void @__olang_scope_close(ptr %s0)
  %t40 = insertvalue { i32, %"std/os:File" } zeroinitializer, i32 %t38, 0
  store { i32, %"std/os:File" } %t40, ptr %rv
  br label %ret
bb8:
  %t41 = load i32, ptr %l1, !tbaa !23
  %t43 = call %"std/os:File" @std_2fos_3aFile_2ector(ptr %s0, i32 %t41)
  store %"std/os:File" %t43, ptr %l14
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load %"std/os:File", ptr %l14
  %t45 = insertvalue { i32, %"std/os:File" } zeroinitializer, %"std/os:File" %t44, 1
  store { i32, %"std/os:File" } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:File" }, ptr %rv
  ret { i32, %"std/os:File" } %rr
}

define dso_local i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca [3 x i64]
  %l9 = alloca i32
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [3 x i64] undef, i64 0, 0
  %t2 = insertvalue [3 x i64] %t1, i64 0, 1
  %t3 = insertvalue [3 x i64] %t2, i64 0, 2
  store [3 x i64] %t3, ptr %l1
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t7, i64 %t8)
  %t13 = getelementptr i8, ptr %t12, i64 %t8
  call void @olang_textcopy(ptr %t13, ptr %t9, i64 %t10)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t12, 1
  %t18 = insertvalue { i64, ptr } undef, i64 3, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %l1, 1
  %t22 = extractvalue { i64, ptr } %t15, 1
  %t23 = extractvalue { i64, ptr } %t15, 0
  %t25 = extractvalue { i64, ptr } %t19, 1
  %t26 = extractvalue { i64, ptr } %t19, 0
  %t27 = call i32 @__olang_stat(ptr %t22, ptr %t25)
  store i32 %t27, ptr %l9
  br label %bb1
bb1:
  %t28 = load i32, ptr %l9, !tbaa !23
  %t29 = icmp eq i32 %t28, 0
  br i1 %t29, label %bb2, label %bb3
bb2:
  %t31 = getelementptr [3 x i64], ptr %l1, i64 0, i64 0
  %t32 = load i64, ptr %t31, !tbaa !34
  %t34 = icmp eq i64 %t32, 2
  store i1 %t34, ptr %l11, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t36 = load i1, ptr %l11, !tbaa !21
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fos_2eIsTerminal(i32 %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @isatty(i32 %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  %t5 = icmp eq i32 %t4, 1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @std_2fos_2eLink(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l8 = alloca i32
  %l11 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = getelementptr i8, ptr %t20, i64 %t16
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t26 = extractvalue { i64, ptr } %t11, 1
  %t27 = extractvalue { i64, ptr } %t11, 0
  %t29 = extractvalue { i64, ptr } %t23, 1
  %t30 = extractvalue { i64, ptr } %t23, 0
  %t31 = call i32 @link(ptr %t26, ptr %t29)
  store i32 %t31, ptr %l8
  br label %bb1
bb1:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = sext i32 %t32 to i64
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = call i32 @std_2fos_2echeck(ptr %v0, i64 %t33, { i64, ptr } %t34)
  store i32 %t37, ptr %l11
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb3, label %ok.39, !prof !99
ok.39:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t40 = load i32, ptr %l11, !tbaa !23
  %t41 = lshr i32 %t40, 16
  %t42 = and i32 %t40, 65535
  %t43 = icmp eq i32 %t41, 1
  %t44 = select i1 %t43, i32 1, i32 0
  %t45 = icmp eq i32 %t40, 0
  %t46 = shl i32 %t44, 16
  %t47 = or i32 %t46, %t42
  %t48 = select i1 %t45, i32 0, i32 %t47
  call void @__olang_scope_close(ptr %s1)
  store i32 %t48, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s1)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2eMkDir(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i32
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = call i32 @std_2fos_2emkdir(ptr %s0, { i64, ptr } %t11)
  store i32 %t14, ptr %l4
  br label %bb1
bb1:
  %t15 = load i32, ptr %l4, !tbaa !23
  %t16 = sext i32 %t15 to i64
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t20 = call i32 @std_2fos_2echeck(ptr %v0, i64 %t16, { i64, ptr } %t17)
  store i32 %t20, ptr %l7
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb3, label %ok.22, !prof !99
ok.22:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t23 = load i32, ptr %l7, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  call void @__olang_scope_close(ptr %s0)
  store i32 %t31, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fos_2eOnCrash(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = extractvalue { i64, ptr } %t1, 1
  %t9 = extractvalue { i64, ptr } %t1, 0
  call void @__olang_on_crash(ptr %t8, i64 %t6)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca %"std/os:Process"
  %l5 = alloca %"std/os:Process"
  %l10 = alloca %"std/os:Process"
  %l11 = alloca i32
  %l13 = alloca %"std/os:Output"
  %l15 = alloca %"std/os:Output"
  %l16 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t9 = call { i32, %"std/os:Process" } @std_2fos_2eProcess_2eStart(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
  %t10 = extractvalue { i32, %"std/os:Process" } %t9, 1
  %t11 = extractvalue { i32, %"std/os:Process" } %t9, 0
  store i32 %t11, ptr %l11
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13, !prof !99
ok.13:
  store %"std/os:Process" %t10, ptr %l10
  br label %bb1
bb1:
  %t14 = load %"std/os:Process", ptr %l10
  store %"std/os:Process" %t14, ptr %l5
  br label %bb3
bb2:
  %t15 = load i32, ptr %l11, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  call void @__olang_scope_close(ptr %s0)
  %t25 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t23, 0
  store { i32, %"std/os:Output" } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load %"std/os:Process", ptr %l5
  store %"std/os:Process" %t26, ptr %l4
  %t28 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWait(ptr %s0, ptr %v3, ptr %l4)
  %t29 = extractvalue { i32, %"std/os:Output" } %t28, 1
  %t30 = extractvalue { i32, %"std/os:Output" } %t28, 0
  store i32 %t30, ptr %l16
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb5, label %ok.32, !prof !99
ok.32:
  store %"std/os:Output" %t29, ptr %l15
  br label %bb4
bb4:
  %t33 = load %"std/os:Output", ptr %l15
  store %"std/os:Output" %t33, ptr %l13
  br label %bb6
bb5:
  %t34 = load i32, ptr %l16, !tbaa !23
  %t35 = lshr i32 %t34, 16
  %t36 = and i32 %t34, 65535
  %t37 = icmp eq i32 %t35, 1
  %t38 = select i1 %t37, i32 1, i32 0
  %t39 = icmp eq i32 %t34, 0
  %t40 = shl i32 %t38, 16
  %t41 = or i32 %t40, %t36
  %t42 = select i1 %t39, i32 0, i32 %t41
  call void @__olang_scope_close(ptr %s0)
  %t44 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t42, 0
  store { i32, %"std/os:Output" } %t44, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load %"std/os:Output", ptr %l13
  %t46 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t45, 1
  store { i32, %"std/os:Output" } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExecUntil(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, { i64, ptr } %a4) #0 {
entry:
  %l5 = alloca %"std/os:Process"
  %l6 = alloca %"std/os:Process"
  %l11 = alloca %"std/os:Process"
  %l12 = alloca i32
  %l14 = alloca %"std/os:Output"
  %l17 = alloca %"std/os:Output"
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t9 = call { i32, %"std/os:Process" } @std_2fos_2eProcess_2eStart(ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, { i64, ptr } %a4)
  %t10 = extractvalue { i32, %"std/os:Process" } %t9, 1
  %t11 = extractvalue { i32, %"std/os:Process" } %t9, 0
  store i32 %t11, ptr %l12
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13, !prof !99
ok.13:
  store %"std/os:Process" %t10, ptr %l11
  br label %bb1
bb1:
  %t14 = load %"std/os:Process", ptr %l11
  store %"std/os:Process" %t14, ptr %l6
  br label %bb3
bb2:
  %t15 = load i32, ptr %l12, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  call void @__olang_scope_close(ptr %s0)
  %t25 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t23, 0
  store { i32, %"std/os:Output" } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load %"std/os:Process", ptr %l6
  store %"std/os:Process" %t26, ptr %l5
  %t30 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWaitUntil(ptr %s0, ptr %v0, ptr %v4, ptr %l5, ptr %a0)
  %t31 = extractvalue { i32, %"std/os:Output" } %t30, 1
  %t32 = extractvalue { i32, %"std/os:Output" } %t30, 0
  store i32 %t32, ptr %l18
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb5, label %ok.34, !prof !99
ok.34:
  store %"std/os:Output" %t31, ptr %l17
  br label %bb4
bb4:
  %t35 = load %"std/os:Output", ptr %l17
  store %"std/os:Output" %t35, ptr %l14
  br label %bb6
bb5:
  %t36 = load i32, ptr %l18, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t37, 2
  %t42 = select i1 %t41, i32 2, i32 %t40
  %t43 = icmp eq i32 %t36, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t38
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s0)
  %t48 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t46, 0
  store { i32, %"std/os:Output" } %t48, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t49 = load %"std/os:Output", ptr %l14
  %t50 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t49, 1
  store { i32, %"std/os:Output" } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t16 = alloca { { i64, ptr }, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t15 = ptrtoint ptr %t14 to i64
  %t17 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 0
  store { i64, ptr } %t11, ptr %t17, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t19 = call ptr @__olang_scope_hold(ptr %s0)
  %t20 = getelementptr { { i64, ptr }, ptr }, ptr %t16, i32 0, i32 1
  store ptr %t19, ptr %t20, !tbaa !28
  %t21 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_11, 0
  %t22 = insertvalue { ptr, ptr } %t21, ptr %t16, 1
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { ptr, ptr } %t22, 0
  %t26 = extractvalue { ptr, ptr } %t22, 1
  %t28 = call { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %s0, ptr %v0, ptr %v1, ptr %t25, ptr %t26, { i64, ptr } %t23)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l9
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb2, label %ok.32, !prof !99
ok.32:
  store { i64, ptr } %t29, ptr %l8
  br label %bb1
bb1:
  %t33 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  %t34 = load i32, ptr %l9, !tbaa !23
  %t35 = lshr i32 %t34, 16
  %t36 = and i32 %t34, 65535
  %t37 = icmp eq i32 %t35, 1
  %t38 = select i1 %t37, i32 1, i32 0
  %t39 = icmp eq i32 %t34, 0
  %t40 = shl i32 %t38, 16
  %t41 = or i32 %t40, %t36
  %t42 = select i1 %t39, i32 0, i32 %t41
  call void @__olang_scope_close(ptr %s0)
  %t44 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t42, 0
  store { i32, { i64, ptr } } %t44, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t46 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t45, 1
  store { i32, { i64, ptr } } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l4 = alloca i32
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = call i32 @std_2fos_2eremove(ptr %s0, { i64, ptr } %t11)
  store i32 %t14, ptr %l4
  br label %bb1
bb1:
  %t15 = load i32, ptr %l4, !tbaa !23
  %t16 = sext i32 %t15 to i64
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t20 = call i32 @std_2fos_2echeck(ptr %v0, i64 %t16, { i64, ptr } %t17)
  store i32 %t20, ptr %l7
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb3, label %ok.22, !prof !99
ok.22:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t23 = load i32, ptr %l7, !tbaa !23
  %t24 = lshr i32 %t23, 16
  %t25 = and i32 %t23, 65535
  %t26 = icmp eq i32 %t24, 1
  %t27 = select i1 %t26, i32 1, i32 0
  %t28 = icmp eq i32 %t23, 0
  %t29 = shl i32 %t27, 16
  %t30 = or i32 %t29, %t25
  %t31 = select i1 %t28, i32 0, i32 %t30
  call void @__olang_scope_close(ptr %s0)
  store i32 %t31, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l8 = alloca i32
  %l11 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = getelementptr i8, ptr %t20, i64 %t16
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t26 = extractvalue { i64, ptr } %t11, 1
  %t27 = extractvalue { i64, ptr } %t11, 0
  %t29 = extractvalue { i64, ptr } %t23, 1
  %t30 = extractvalue { i64, ptr } %t23, 0
  %t31 = call i32 @rename(ptr %t26, ptr %t29)
  store i32 %t31, ptr %l8
  br label %bb1
bb1:
  %t32 = load i32, ptr %l8, !tbaa !23
  %t33 = sext i32 %t32 to i64
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = call i32 @std_2fos_2echeck(ptr %v0, i64 %t33, { i64, ptr } %t34)
  store i32 %t37, ptr %l11
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb3, label %ok.39, !prof !99
ok.39:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t40 = load i32, ptr %l11, !tbaa !23
  %t41 = lshr i32 %t40, 16
  %t42 = and i32 %t40, 65535
  %t43 = icmp eq i32 %t41, 1
  %t44 = select i1 %t43, i32 1, i32 0
  %t45 = icmp eq i32 %t40, 0
  %t46 = shl i32 %t44, 16
  %t47 = or i32 %t46, %t42
  %t48 = select i1 %t45, i32 0, i32 %t47
  call void @__olang_scope_close(ptr %s1)
  store i32 %t48, ptr %rv
  br label %ret
bb4:
  call void @__olang_scope_close(ptr %s1)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2eRun(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i32
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = extractvalue { i64, ptr } %t11, 0
  %t16 = call i32 @system(ptr %t14)
  store i32 %t16, ptr %l5
  br label %bb1
bb1:
  %t17 = load i32, ptr %l5, !tbaa !23
  store i32 %t17, ptr %l1, !tbaa !23
  %t18 = load i32, ptr %l1, !tbaa !23
  %t20 = icmp slt i32 %t18, 0
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i32 127, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = srem i32 %t23, 256
  %t27 = icmp ne i32 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i32, ptr %l1, !tbaa !23
  %t31 = srem i32 %t29, 128
  %t33 = add i32 128, %t31
  call void @__olang_scope_close(ptr %s0)
  store i32 %t33, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t35 = load i32, ptr %l1, !tbaa !23
  %t37 = sdiv i32 %t35, 256
  call void @__olang_scope_close(ptr %s0)
  store i32 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fos_2eRunOnStack(ptr %v0, i64 %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { ptr, ptr } %pg1, 0
  %t6 = extractvalue { ptr, ptr } %pg1, 1
  call void @__olang_run_on_stack(i64 %a0, ptr %t5, ptr %t6)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/os:File"
  %l3 = alloca i1
  %l4 = alloca %"std/os:File"
  %l6 = alloca %"std/os:File"
  %l7 = alloca i32
  %l11 = alloca i32
  %l13 = alloca i1
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, %"std/os:File" } @std_2fos_2eFile_2eCreate(ptr %v0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:File" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:File" } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:File" %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"std/os:File", ptr %l6
  store %"std/os:File" %t8, ptr %l4
  br label %bb3
bb2:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  call void @__olang_scope_close(ptr %s0)
  store i32 %t17, ptr %rv
  br label %ret
bb3:
  %t19 = load %"std/os:File", ptr %l4
  store %"std/os:File" %t19, ptr %l2
  store i1 true, ptr %l3, !tbaa !21
  %t23 = call i32 @std_2fos_2estd_2fos_3aFile_2eWrite(ptr %s0, ptr %v1, ptr %l2, { i64, ptr } %a1)
  store i32 %t23, ptr %l11
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  br label %bb4
bb4:
  br label %bb17
bb5:
  %t26 = load i32, ptr %l11, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  store i1 %t29, ptr %l13, !tbaa !21
  %t30 = load i32, ptr %l11, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  br i1 %t33, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t35 = call i32 @__olang_err()
  store i32 %t35, ptr %l16
  br label %bb9
bb9:
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t37 = load i32, ptr %l16, !tbaa !23
  %t39 = call i32 @std_2fos_2eraise(ptr %v0, i32 %t37, { i64, ptr } %t36)
  store i32 %t39, ptr %l18
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb11, label %ok.41, !prof !99
ok.41:
  br label %bb10
bb10:
  br label %bb16
bb11:
  %t42 = load i32, ptr %l18, !tbaa !23
  %t43 = lshr i32 %t42, 16
  %t44 = and i32 %t42, 65535
  %t45 = icmp eq i32 %t43, 1
  %t46 = select i1 %t45, i32 1, i32 0
  %t47 = icmp eq i32 %t42, 0
  %t48 = shl i32 %t46, 16
  %t49 = or i32 %t48, %t44
  %t50 = select i1 %t47, i32 0, i32 %t49
  store i32 %t50, ptr %l19, !tbaa !23
  %t51 = load i1, ptr %l3, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fos_3aFile(ptr %s3, ptr %l2)
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load i32, ptr %l19, !tbaa !23
  store i32 %t54, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t55 = load i1, ptr %l3, !tbaa !21
  br i1 %t55, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fos_3aFile(ptr %s5, ptr %l2)
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2echeck(ptr %v0, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i32
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = icmp slt i64 %a0, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call i32 @__olang_err()
  store i32 %t5, ptr %l4
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t7 = load i32, ptr %l4, !tbaa !23
  %t9 = call i32 @std_2fos_2eraise(ptr %v0, i32 %t7, { i64, ptr } %a1)
  store i32 %t9, ptr %l6
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb5, label %ok.11, !prof !99
ok.11:
  br label %bb4
bb4:
  br label %bb6
bb5:
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = lshr i32 %t12, 16
  %t14 = and i32 %t12, 65535
  %t15 = icmp eq i32 %t13, 1
  %t16 = select i1 %t15, i32 1, i32 0
  %t17 = icmp eq i32 %t12, 0
  %t18 = shl i32 %t16, 16
  %t19 = or i32 %t18, %t14
  %t20 = select i1 %t17, i32 0, i32 %t19
  store i32 %t20, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @std_2fos_2echurn() #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !24
  store i64 0, ptr %l1, !tbaa !24
  store i64 300, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l14, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l11, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  %t49 = call i64 @__olang_fmt_i64(ptr null, i64 %t45)
  %t50 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t52)
  %t54 = call i64 @__olang_fmt_i64(ptr %t53, i64 %t45)
  %t55 = getelementptr i8, ptr %t53, i64 %t49
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = load i64, ptr %l0, !tbaa !24
  %t62 = extractvalue { i64, ptr } %t57, 0
  %t65 = add i64 %t59, %t62
  store i64 %t65, ptr %l0, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = add i64 %t67, 1
  store i64 %t70, ptr %l5, !tbaa !24
  br label %bb7
bb12:
  %t72 = load i64, ptr %l0, !tbaa !24
  store i64 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @std_2fos_2eisOpen(i32 %a0) #0 {
entry:
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t5 = sext i32 %a0 to i64
  %t6 = call i64 @__olang_fmt_i64(ptr null, i64 %t5)
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  %t10 = call i64 @__olang_fmt_i64(ptr %t9, i64 %t5)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t8, 1
  %t15 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t12)
  store i1 %t15, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t16 = load i1, ptr %l4, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @std_2fos_2ememfd() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l0, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 1
  %t4 = extractvalue { i64, ptr } %t1, 0
  %t5 = call i32 @memfd_create(ptr %t3, i32 1)
  store i32 %t5, ptr %l2
  br label %bb1
bb1:
  %t6 = load i32, ptr %l2, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2emkdir(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = call i32 @mkdir(ptr %t5, i32 511)
  store i32 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load i32, ptr %l4, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2eopenedAndLetGo(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:File"
  %l2 = alloca i1
  %l3 = alloca %"std/os:File"
  %l5 = alloca %"std/os:File"
  %l6 = alloca i32
  %l9 = alloca %"std/os:File"
  %l11 = alloca i32
  %l12 = alloca i1
  %l14 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, %"std/os:File" } @std_2fos_2eFile_2eOpen(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, %"std/os:File" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:File" } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:File" %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load %"std/os:File", ptr %l5
  store %"std/os:File" %t8, ptr %l3
  br label %bb7
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t14 = call %"std/os:File" @std_2fos_3aFile_2ector(ptr %s0, i32 -1)
  store %"std/os:File" %t14, ptr %l9
  br label %bb6
bb6:
  %t15 = load %"std/os:File", ptr %l9
  store %"std/os:File" %t15, ptr %l3
  br label %bb7
bb7:
  %t16 = load %"std/os:File", ptr %l3
  store %"std/os:File" %t16, ptr %l1
  store i1 true, ptr %l2, !tbaa !21
  %t18 = call i32 @std_2fos_2estd_2fos_3aFile_2eFd(ptr %s0, ptr %l1)
  store i32 %t18, ptr %l11
  br label %bb8
bb8:
  %t19 = load i32, ptr %l11, !tbaa !23
  %t20 = call i1 @std_2fos_2eisOpen(i32 %t19)
  store i1 %t20, ptr %l12
  br label %bb9
bb9:
  %t21 = load i1, ptr %l12, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  %t23 = call i32 @std_2fos_2estd_2fos_3aFile_2eFd(ptr %s0, ptr %l1)
  store i32 %t23, ptr %l14
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8db2c92be8bc1f99_baf0cd8fa0453875)
  unreachable
bb12:
  %t24 = load i1, ptr %l2, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fos_3aFile(ptr %s2, ptr %l1)
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l14, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @std_2fos_2erawRead(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l7 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t9 = extractvalue { i64, ptr } %t2, 1
  %t10 = extractvalue { i64, ptr } %t2, 0
  %t12 = call i64 @read(i32 %a0, ptr %t9, i64 %t5)
  store i64 %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = load i64, ptr %l7, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @std_2fos_2eremove(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = call i32 @remove(ptr %t5)
  store i32 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load i32, ptr %l4, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @std_2fos_2eseek(i32 %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @lseek(i32 %a0, i64 0, i32 %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @std_2fos_2estd_2fos_3aFile_2eFd(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/os:File", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fos_2estd_2fos_3aFile_2eRead(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/os:File", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t8 = call { i32, { i64, ptr } } @std_2fio_2eRead(ptr %v1, ptr %v2, i32 %t4, { i64, ptr } %a1)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l7
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb2, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l6
  br label %bb1
bb1:
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t14 = load i32, ptr %l7, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t22, 0
  store { i32, { i64, ptr } } %t24, ptr %rv
  br label %ret
bb3:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t25, 1
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fos_2estd_2fos_3aFile_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l5 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/os:File", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t8 = call i32 @std_2fio_2eWrite(ptr %v1, i32 %t4, { i64, ptr } %a1)
  store i32 %t8, ptr %l5
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10, !prof !99
ok.10:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  store i32 %t19, ptr %rv
  br label %ret
bb3:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fos_2estd_2fos_3aProcess_2eKill(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/os:Process", ptr %t6, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t11 = call i32 @kill(i32 %t9, i32 9)
  store i32 %t11, ptr %l5
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fos_2estd_2fos_3aProcess_2ePid(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/os:Process", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWaitUntil(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l11 = alloca { i64, [2 x i64] }
  %l14 = alloca %"std/os:Output"
  %l17 = alloca %"std/os:Output"
  %l18 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca { i32, %"std/os:Output" }
  %t20 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 0
  store i64 6, ptr %t21
  %t22 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t23 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t22, 0
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 1
  store { { i64, ptr } } %t23, ptr %t24
  %t25 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t25, ptr %l8
  %t26 = call ptr @__olang_errpay_push()
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l9, !tbaa !24
  %t28 = load i64, ptr %l9
  %t29 = inttoptr i64 %t28 to ptr
  %t31 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %t29, ptr %l8)
  store { i64, [2 x i64] } %t31, ptr %l11
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t32 = load { i64, [2 x i64] }, ptr %l11
  %t33 = load i64, ptr %l9
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_scope_alloc_a(ptr %t34, i64 24, i64 8)
  store { i64, [2 x i64] } %t32, ptr %t35
  call void @__olang_errpay_set(ptr %t35)
  call void @__olang_scope_close(ptr %s1)
  %t38 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 65542, 0
  store { i32, %"std/os:Output" } %t38, ptr %rv
  br label %ret
bb4:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2ewaitPolling(ptr %v0, ptr %v1, ptr %v2, ptr %t39, ptr %a1)
  %t44 = extractvalue { i32, %"std/os:Output" } %t43, 1
  %t45 = extractvalue { i32, %"std/os:Output" } %t43, 0
  store i32 %t45, ptr %l18
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb6, label %ok.47, !prof !99
ok.47:
  store %"std/os:Output" %t44, ptr %l17
  br label %bb5
bb5:
  %t48 = load %"std/os:Output", ptr %l17
  store %"std/os:Output" %t48, ptr %l14
  br label %bb7
bb6:
  %t49 = load i32, ptr %l18, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t50, 2
  %t55 = select i1 %t54, i32 2, i32 %t53
  %t56 = icmp eq i32 %t49, 0
  %t57 = shl i32 %t55, 16
  %t58 = or i32 %t57, %t51
  %t59 = select i1 %t56, i32 0, i32 %t58
  %t61 = insertvalue { i32, %"std/os:Output" } zeroinitializer, i32 %t59, 0
  store { i32, %"std/os:Output" } %t61, ptr %rv
  br label %ret
bb7:
  %t62 = load %"std/os:Output", ptr %l14
  %t63 = insertvalue { i32, %"std/os:Output" } zeroinitializer, %"std/os:Output" %t62, 1
  store { i32, %"std/os:Output" } %t63, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/os:Output" }, ptr %rv
  ret { i32, %"std/os:Output" } %rr
}

define dso_local i32 @std_2fos_2estd_2fos_3aProcess_2elost(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/os:Process", ptr %t1, i32 0, i32 4
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"std/os:Process", ptr %t4, i32 0, i32 3
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/os:Process", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = call i32 @close(i32 %t12)
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/os:Process", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = call i32 @close(i32 %t18)
  store i32 %t20, ptr %l10
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t23 = call i32 @std_2fos_2eraise(ptr %s0, i32 %a1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i32 %t23, ptr %l12
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb7, label %ok.25, !prof !99
ok.25:
  br label %bb6
bb6:
  br label %bb8
bb7:
  %t26 = load i32, ptr %l12, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s0)
  store i32 %t34, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fos_2ewaitFor(ptr %v0, i32 %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l3, !tbaa !23
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  br i1 %a2, label %bb1, label %bb2
bb1:
  store i32 1, ptr %l6, !tbaa !23
  br label %bb3
bb2:
  store i32 0, ptr %l6, !tbaa !23
  br label %bb3
bb3:
  %t5 = load i32, ptr %l3, !tbaa !23
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = call i32 @waitpid(i32 %t5, ptr %t7, i32 %t9)
  store i32 %t10, ptr %l7
  br label %bb4
bb4:
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fos_2ewaitStopped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca %"std/os:Output"
  %l6 = alloca %"std/os:Output"
  %l7 = alloca i32
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWaitUntil(ptr %v0, ptr %v1, ptr %s0, ptr %a0, ptr %a1)
  %t6 = extractvalue { i32, %"std/os:Output" } %t5, 1
  %t7 = extractvalue { i32, %"std/os:Output" } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store %"std/os:Output" %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load %"std/os:Output", ptr %l6
  store %"std/os:Output" %t10, ptr %l3
  br label %bb11
bb2:
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = icmp eq i32 %t11, 131072
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i32, ptr %l7, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb5, label %bb6
bb4:
  %t19 = load i32, ptr %l7, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb8, label %bb9
bb5:
  call void @__olang_errpay_pop()
  br label %bb6
bb6:
  br label %bb7
bb7:
  store { i64, ptr } %a2, ptr %l13, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr i1, ptr %t26, i64 0
  store i1 true, ptr %t27, !tbaa !31
  br label %bb11
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/os:FileInfo" @std_2fos_3aFileInfo_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"std/os:FileInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"std/os:FileInfo" undef, i32 %a0, 0
  %t10 = insertvalue %"std/os:FileInfo" %t8, i64 %a1, 1
  %t12 = insertvalue %"std/os:FileInfo" %t10, i64 %a2, 2
  store %"std/os:FileInfo" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:FileInfo", ptr %rv
  ret %"std/os:FileInfo" %rr
}

define dso_local %"std/os:File" @std_2fos_3aFile_2ector(ptr %v0, i32 %a0) #0 {
entry:
  %rv = alloca %"std/os:File"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"std/os:File" undef, i32 %a0, 0
  store %"std/os:File" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:File", ptr %rv
  ret %"std/os:File" %rr
}

define dso_local void @std_2fos_3aFile_2edtor(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/os:File", ptr %a0, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = call i32 @close(i32 %t4)
  store i32 %t6, ptr %l3
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"std/os:Output"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"std/os:Output" undef, i32 %a0, 0
  %t10 = insertvalue %"std/os:Output" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"std/os:Output" %t10, { i64, ptr } %a2, 2
  store %"std/os:Output" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/os:Output", ptr %rv
  ret %"std/os:Output" %rr
}

@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare i32 @__olang_stat(ptr, ptr)
declare void @exit(i32) noreturn
declare void @__olang_check_failed(ptr) cold noreturn
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d4 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"linux" }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
declare i32 @open(ptr, i32, ...)
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @isatty(i32)
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @link(ptr, ptr)
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare void @__olang_on_crash(ptr, i64)
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
define internal i64 @olang_lambda_11(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l9 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  %t10 = extractvalue { i64, ptr } %cv0, 1
  %t11 = extractvalue { i64, ptr } %cv0, 0
  %t13 = extractvalue { i64, ptr } %t4, 1
  %t14 = extractvalue { i64, ptr } %t4, 0
  %t16 = call i64 @__olang_realpath(ptr %t10, ptr %t13, i64 %t8)
  store i64 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load i64, ptr %l9, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @rename(ptr, ptr)
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @system(ptr)
declare void @__olang_run_on_stack(i64, ptr, ptr)
declare void @__olang_errpay_pop()
declare i32 @__olang_err()
define linkonce_odr void @olang_2emir_2eHelperKind_2eDrop_2estd_2fos_3aFile(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @std_2fos_3aFile_2edtor(ptr %v0, ptr %a0)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

declare i64 @__olang_fmt_i64(ptr, i64)
@.d16 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"-------------------------------------------------------------" }>, align 8
@.d17 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/fd/" }>, align 8
@.d18 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"olang\00" }>, align 8
declare i32 @memfd_create(ptr, i32)
declare i32 @mkdir(ptr, i32)
declare i64 @read(i32, ptr, i64)
declare i32 @remove(ptr)
declare i64 @lseek(i32, i64, i32)
declare i32 @kill(i32, i32)
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_errpay_push() cold
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 7}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { { i64, ptr } }, ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, ptr } }, ptr %t42, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t43
  br label %bb1
bb4:
  %t44 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l9, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  store i64 %t48, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = mul i64 %t49, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l11, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = mul i64 %t58, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %t57, i64 %t59, i1 false)
  %t60 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t61 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { { i64, ptr } }, ptr %t61, i32 0, i32 0
  store { i64, ptr } %t60, ptr %t62
  br label %bb1
bb5:
  %t63 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { { i64, ptr } }, ptr %t63, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64
  store { i64, ptr } %t65, ptr %l12, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l13, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l14, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l13, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t80 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t81 = getelementptr { { i64, ptr } }, ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81
  br label %bb1
bb6:
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t83 = getelementptr { { i64, ptr } }, ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83
  store { i64, ptr } %t84, ptr %l15, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l17, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t99 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, ptr } }, ptr %t99, i32 0, i32 0
  store { i64, ptr } %t98, ptr %t100
  br label %bb1
bb7:
  %t101 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t102 = getelementptr { { i64, ptr } }, ptr %t101, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102
  store { i64, ptr } %t103, ptr %l18, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l19, !tbaa !24
  %t106 = load i64, ptr %l19, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l20, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l19, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t119 = getelementptr { { i64, ptr } }, ptr %t118, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t119
  br label %bb1
bb8:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { { i64, ptr } }, ptr %t120, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l21, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l22, !tbaa !24
  %t125 = load i64, ptr %l22, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l23, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l22, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t137 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t138 = getelementptr { { i64, ptr } }, ptr %t137, i32 0, i32 0
  store { i64, ptr } %t136, ptr %t138
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_errpay_set(ptr) cold
declare i32 @close(i32)
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i32 @waitpid(i32, ptr, i32)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_self = external thread_local(initialexec) global ptr
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare i64 @__olang_realpath(ptr, ptr, i64)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
@olang_loc_bf01453b0cfded25_a369431636c6fdd9 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, %"std/os:Process" } @std_2fos_2eProcess_2eStart(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2eWait(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2ecopyOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0c, ptr %a0e, { i64, ptr } %a1)
declare { i32, %"std/os:File" } @std_2fos_2eFile_2eCreate(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eraise(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_8db2c92be8bc1f99_baf0cd8fa0453875 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fio_2eRead(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare { i32, %"std/os:Output" } @std_2fos_2estd_2fos_3aProcess_2ewaitPolling(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
