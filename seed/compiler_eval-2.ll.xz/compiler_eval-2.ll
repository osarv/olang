; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", i32 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/eval:Ptr" = type { i64, i64 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/eval:scope" = type { i64, i1, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/eval:gkey" = type { i64, i32 }
%"compiler/eval:global" = type { i64, i1, i64, i64, i64, i1, i1 }
%"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" = type { i64, %"compiler/source:Span" }
%"compiler/eval:alloc" = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i1 }
%"compiler/eval:frame" = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i64, i64, i1, i64, i32, i32 }
%"compiler/eval:cfn" = type { i64, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, { i64, ptr } }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [8 x i64] } }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/eval:task" = type { i64, i64, i64, i64 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/eval:genRec" = type { i64, i64, %"compiler/eval:frame", i64, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/eval:Blob" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
define dso_local void @compiler_2feval_2eB0_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eForeignId_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  store i64 %t1, ptr @G_2ecompiler_2feval_2eForeignId, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eNewMachine(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca %"compiler/eval:Machine"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/eval:scope"
  %l16 = alloca i64
  %l22 = alloca %"compiler/eval:Ptr"
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l53 = alloca %"compiler/eval:Ptr"
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i32
  %l60 = alloca { i64, ptr }
  %l63 = alloca i1
  %l65 = alloca %"compiler/eval:Machine"
  %s0 = alloca %olang.scope
  %t3 = alloca %"compiler/eval:Machine", align 8
  %t10 = alloca %"compiler/eval:scope", align 8
  %t12 = alloca %"compiler/eval:scope", align 8
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load i32, ptr %l1
  call void @compiler_2feval_3aMachine_2ector(ptr %t3, ptr %v0, ptr %v1, ptr %a0, i32 %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %t3, i64 784, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 784, i64 8)
  store ptr %t6, ptr %lp2
  %t7 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %l11, i64 784, i1 false)
  %t8 = load ptr, ptr %lp2
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t8, i32 0, i32 43
  store ptr %t9, ptr %l12, !tbaa !29
  call void @compiler_2feval_3ascope_2ector(ptr %t10, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t10, i64 136, i1 false)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l12, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t12, ptr %l13, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2ePush_3ccompiler_2feval_3ascope_3e(ptr %v1, ptr %t11, ptr %t12)
  br label %bb3
bb3:
  %t13 = load ptr, ptr %lp2
  %t14 = load i64, ptr @G_2ecompiler_2feval_2esProgram, !tbaa !24
  %t17 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l16
  br label %bb4
bb4:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = load ptr, ptr %lp2
  %t20 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 61
  store i64 %t18, ptr %t20, !tbaa !24
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 1 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %lp2
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t26, i32 0, i32 2
  store i64 -1, ptr %t27, !tbaa !24
  %t28 = load ptr, ptr %lp2
  %t29 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 3
  store i64 -1, ptr %t29, !tbaa !24
  %t30 = load ptr, ptr %lp2
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 4
  store i64 10000000, ptr %t31, !tbaa !24
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t32 = load ptr, ptr %lp2
  %t33 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t34 = load ptr, ptr %lp2
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t34, i32 0, i32 61
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v1, ptr %t32, i64 64, i64 %t33, i64 %t36)
  store %"compiler/eval:Ptr" %t40, ptr %l22
  br label %bb8
bb8:
  %t41 = getelementptr %"compiler/eval:Ptr", ptr %l22, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = load ptr, ptr %lp2
  %t45 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 62
  store i64 %t42, ptr %t45, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = icmp sgt i64 %t46, %t47
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp sgt i64 %t52, 0
  br i1 %t54, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb14
bb11:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l3, !tbaa !24
  %t60 = sub i64 %t56, %t57
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t60, %t61
  %t66 = sub i64 %t64, 1
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = sdiv i64 %t66, %t67
  store i64 %t70, ptr %l30, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t72 = load i64, ptr %l30, !tbaa !24
  store i64 %t72, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t73 = load i64, ptr %l27, !tbaa !24
  store i64 %t73, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t74 = load i64, ptr %l7, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  %t87 = mul i64 %t83, %t84
  %t90 = add i64 %t82, %t87
  %t92 = load ptr, ptr %lp2
  %t93 = getelementptr %"compiler/eval:Machine", ptr %t92, i32 0, i32 63
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l48, !tbaa !27
  store i64 %t90, ptr %l49, !tbaa !24
  %t96 = load ptr, ptr %lp2
  %t97 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t98 = load ptr, ptr %lp2
  %t99 = getelementptr %"compiler/eval:Machine", ptr %t98, i32 0, i32 61
  %t100 = load i64, ptr %t99, !tbaa !24
  %t104 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v1, ptr %t96, i64 64, i64 %t97, i64 %t100)
  store %"compiler/eval:Ptr" %t104, ptr %l53
  br label %bb19
bb19:
  %t105 = getelementptr %"compiler/eval:Ptr", ptr %l53, i32 0, i32 0
  %t106 = load i64, ptr %t105, !tbaa !24
  %t108 = load i64, ptr %l49, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i64, ptr %t110, i64 %t108
  store i64 %t106, ptr %t111, !tbaa !34
  br label %bb20
bb20:
  %t112 = load i64, ptr %l7, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l7, !tbaa !24
  br label %bb15
bb21:
  %t116 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d0, i32 0, i32 1) })
  %t117 = extractvalue { i32, { i64, ptr } } %t116, 1
  %t118 = extractvalue { i32, { i64, ptr } } %t116, 0
  store i32 %t118, ptr %l59
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb23, label %ok.120, !prof !99
ok.120:
  store { i64, ptr } %t117, ptr %l58
  br label %bb22
bb22:
  %t121 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t121, ptr %l57, !tbaa !27
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l60, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = extractvalue { i64, ptr } %t122, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l57, !tbaa !27
  br label %bb25
bb25:
  %t131 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t131, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t132, ptr %l63
  br label %bb26
bb26:
  %t133 = load i1, ptr %l63, !tbaa !21
  %t134 = xor i1 %t133, true
  %t136 = load ptr, ptr %lp2
  %t137 = getelementptr %"compiler/eval:Machine", ptr %t136, i32 0, i32 8
  store i1 %t134, ptr %t137, !tbaa !21
  %t138 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t138, i64 784, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l65, i64 784, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eNullPtr_2einit() #0 {
entry:
  %l0 = alloca %"compiler/eval:Ptr"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %t1, i64 0, i64 0)
  store %"compiler/eval:Ptr" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/eval:Ptr", ptr %l0
  store %"compiler/eval:Ptr" %t3, ptr @G_2ecompiler_2feval_2eNullPtr
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eSp0_2einit() #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %t1, i32 0, i32 0)
  store %"compiler/source:Span" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/source:Span", ptr %l0
  store %"compiler/source:Span" %t3, ptr @G_2ecompiler_2feval_2eSp0
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyDivMin_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyDivMin, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyEqDepth_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyEqDepth, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyExtern_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyExtern, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyFreedEarly_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyFreedEarly, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyNaNOp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 84, ptr getelementptr inbounds (<{ i64, [84 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyNaNOp, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyNoGlobal_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyNoGlobal, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyNotModelled_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyNullCall_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyNullCall, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyStale_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyStale, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyWaits_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyWaits, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyWritesGlobal_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyWritesGlobal, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eaCode_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2feval_2eaCode, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eaData_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2feval_2eaData, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eaFree_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eaValue_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2feval_2eadd128(i64 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i64
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t5 = add i64 %t1, %a2
  store i64 %t5, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l8, !tbaa !24
  %t12 = add i64 %a1, %a3
  store i64 %t12, ptr %l11, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l0, !tbaa !24
  %t17 = call i1 @compiler_2feval_2eult64(i64 %t13, i64 %t14)
  store i1 %t17, ptr %l14
  br label %bb1
bb1:
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i64 1, ptr %l15, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb4
bb4:
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l15, !tbaa !24
  %t21 = add i64 %t19, %t20
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = insertvalue { i64, i64 } undef, i64 %t22, 0
  %t25 = insertvalue { i64, i64 } %t23, i64 %t21, 1
  store { i64, i64 } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i64 @compiler_2feval_2ebmask(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sge i64 %t1, 64
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  %t5 = load i64, ptr %l0, !tbaa !24
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = shl i64 1, %t7
  %t10 = sub i64 %t8, 1
  store i64 %t10, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t12 = load i64, ptr %l3, !tbaa !24
  store i64 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecatchFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i32
  %lp6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i32
  %l23 = alloca i32
  %l24 = alloca %"compiler/mir:Fn"
  %l28 = alloca i32
  %l32 = alloca i32
  %l34 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i32
  %l40 = alloca i32
  %l41 = alloca ptr
  %l43 = alloca { i64, [2 x i64] }
  %l45 = alloca { i64, [7 x i64] }
  %l46 = alloca ptr
  %l47 = alloca { i64, [4 x i64] }
  %l48 = alloca { i64, ptr }
  %l49 = alloca %"compiler/mir:Range"
  %l50 = alloca %"compiler/mir:Range"
  %l52 = alloca %"compiler/mir:Lvalue"
  %l56 = alloca %"compiler/mir:Call"
  %l57 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca %"compiler/source:Span"
  %l73 = alloca %"compiler/mir:Lvalue"
  %l76 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca %"compiler/mir:Lvalue"
  %l80 = alloca { i64, [4 x i64] }
  %l81 = alloca ptr
  %l84 = alloca %"compiler/mir:Case"
  %l85 = alloca { i64, ptr }
  %l86 = alloca %"compiler/mir:Range"
  %l113 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t18 = alloca %"compiler/mir:Fn", align 8
  %t61 = alloca { i64, [7 x i64] }, align 8
  %t105 = alloca { i64, [8 x i64] }, align 8
  %t120 = alloca { i64, [21 x i64] }, align 8
  %t139 = alloca { i64, [4 x i64] }, align 8
  %t145 = alloca { i64, [8 x i64] }, align 8
  %t161 = alloca { i64, [4 x i64] }, align 8
  %t185 = alloca { i64, [8 x i64] }, align 8
  %t202 = alloca { i64, [21 x i64] }, align 8
  %t219 = alloca { i64, [4 x i64] }, align 8
  %t226 = alloca { i64, [8 x i64] }, align 8
  %t241 = alloca { i64, [21 x i64] }, align 8
  %t258 = alloca { i64, [4 x i64] }, align 8
  %t265 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i32 %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load i32, ptr %l15, !tbaa !23
  store i32 %t4, ptr %l5, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l16, !tbaa !29
  store i64 %a1, ptr %l17, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l18, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l5, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l21
  br label %bb2
bb2:
  %t13 = load i32, ptr %l5, !tbaa !23
  %t14 = load ptr, ptr %l18, !tbaa !29
  %t15 = load i32, ptr %l21, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t14, i32 %t15, i32 %t13, i32 0, i32 0, i64 0)
  store i32 %t17, ptr %l23
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t20 = load i64, ptr %l17, !tbaa !24
  %t21 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2feval_2etfn(ptr %t18, ptr %v0, ptr %v1, ptr %t19, i64 %t20, i32 %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t18, i64 248, i1 false)
  br label %bb4
bb4:
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 248, i64 8)
  store ptr %t22, ptr %lp6
  %t23 = load ptr, ptr %lp6
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %l24, i64 248, i1 false)
  %t24 = load ptr, ptr %lp6
  %t25 = load i32, ptr %l5, !tbaa !23
  %t26 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t30 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t24, i32 %t25, %"compiler/source:Span" %t26)
  store i32 %t30, ptr %l28
  br label %bb5
bb5:
  %t31 = load i32, ptr %l28, !tbaa !23
  store i32 %t31, ptr %l7, !tbaa !23
  %t32 = load ptr, ptr %lp6
  %t33 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t34 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t38 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t32, i32 %t33, %"compiler/source:Span" %t34)
  store i32 %t38, ptr %l32
  br label %bb6
bb6:
  %t39 = load i32, ptr %l32, !tbaa !23
  store i32 %t39, ptr %l8, !tbaa !23
  %t40 = load ptr, ptr %lp6
  %t42 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t40)
  store i32 %t42, ptr %l34
  br label %bb7
bb7:
  %t43 = load i32, ptr %l34, !tbaa !23
  store i32 %t43, ptr %l9, !tbaa !23
  %t44 = load ptr, ptr %lp6
  %t46 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t44)
  store i32 %t46, ptr %l36
  br label %bb8
bb8:
  %t47 = load i32, ptr %l36, !tbaa !23
  store i32 %t47, ptr %l10, !tbaa !23
  %t48 = load ptr, ptr %lp6
  %t50 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t48)
  store i32 %t50, ptr %l38
  br label %bb9
bb9:
  %t51 = load i32, ptr %l38, !tbaa !23
  store i32 %t51, ptr %l11, !tbaa !23
  %t52 = load ptr, ptr %lp6
  %t54 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t52)
  store i32 %t54, ptr %l40
  br label %bb10
bb10:
  %t55 = load i32, ptr %l40, !tbaa !23
  store i32 %t55, ptr %l12, !tbaa !23
  %t56 = load ptr, ptr %lp6
  store ptr %t56, ptr %l41, !tbaa !29
  %t59 = call { i64, [2 x i64] } @compiler_2feval_2etkey(i64 %a2)
  store { i64, [2 x i64] } %t59, ptr %l43
  br label %bb11
bb11:
  store { i64, [7 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [7 x i64] }, ptr %t61, i32 0, i32 0
  store i64 0, ptr %t62
  %t63 = load { i64, [2 x i64] }, ptr %l43
  %t64 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t63, 0
  %t66 = insertvalue { { i64, [2 x i64] }, i32 } %t64, i32 %a3, 1
  %t67 = getelementptr { i64, [7 x i64] }, ptr %t61, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t66, ptr %t67
  %t68 = load { i64, [7 x i64] }, ptr %t61
  store { i64, [7 x i64] } %t68, ptr %l45
  %t69 = load ptr, ptr %lp6
  store ptr %t69, ptr %l46, !tbaa !29
  %t70 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t70, ptr %l47
  br label %bb12
bb12:
  %t71 = mul i64 1, 40
  %t72 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 1, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l48, !tbaa !27
  %t75 = load { i64, [4 x i64] }, ptr %l47
  %t76 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t77, i64 0
  store { i64, [4 x i64] } %t75, ptr %t78
  %t79 = load ptr, ptr %l46, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t81 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t79, { i64, ptr } %t80)
  store %"compiler/mir:Range" %t81, ptr %l49
  br label %bb13
bb13:
  %t82 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t82, ptr %l50
  %t83 = load i32, ptr %l7, !tbaa !23
  %t85 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t83)
  store %"compiler/mir:Lvalue" %t85, ptr %l52
  br label %bb14
bb14:
  %t86 = load i32, ptr %l9, !tbaa !23
  %t87 = load i32, ptr %l8, !tbaa !23
  %t88 = load i32, ptr %l10, !tbaa !23
  %t89 = load { i64, [7 x i64] }, ptr %l45
  %t90 = load %"compiler/mir:Range", ptr %l49
  %t91 = load %"compiler/mir:Range", ptr %l50
  %t92 = load %"compiler/mir:Lvalue", ptr %l52
  %t96 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t89, %"compiler/mir:Range" %t90, %"compiler/mir:Range" %t91, %"compiler/mir:Lvalue" %t92, i1 true, i32 %t86, i32 %t87, i32 %t88)
  store %"compiler/mir:Call" %t96, ptr %l56
  br label %bb15
bb15:
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load %"compiler/mir:Call", ptr %l56
  %t99 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v1, ptr %t97, %"compiler/mir:Call" %t98)
  store i32 %t99, ptr %l57
  br label %bb16
bb16:
  %t100 = load i32, ptr %l57, !tbaa !23
  %t101 = load ptr, ptr %lp6
  %t102 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  %t103 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [8 x i64] }, ptr %t105, i32 0, i32 0
  store i64 4, ptr %t106
  %t108 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t103, 0
  %t110 = insertvalue { %"compiler/source:Span", i32 } %t108, i32 %t100, 1
  %t111 = getelementptr { i64, [8 x i64] }, ptr %t105, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t110, ptr %t111
  %t112 = load { i64, [8 x i64] }, ptr %t105
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t101, i32 %t102, { i64, [8 x i64] } %t112)
  br label %bb17
bb17:
  %t116 = load ptr, ptr %lp6
  %t117 = load i32, ptr %l9, !tbaa !23
  %t118 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t119 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [21 x i64] }, ptr %t120, i32 0, i32 0
  store i64 4, ptr %t121
  %t123 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t118, 0
  %t125 = insertvalue { %"compiler/source:Span", i32 } %t123, i32 %t119, 1
  %t126 = getelementptr { i64, [21 x i64] }, ptr %t120, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t125, ptr %t126
  %t127 = load { i64, [21 x i64] }, ptr %t120
  %t129 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t127, ptr %t129
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t116, i32 %t117, ptr %t129)
  br label %bb18
bb18:
  %t133 = load ptr, ptr %lp6
  store ptr %t133, ptr %l69, !tbaa !29
  %t134 = load i32, ptr %l9, !tbaa !23
  store i32 %t134, ptr %l70, !tbaa !23
  %t135 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t135, ptr %l71
  %t136 = load i32, ptr %l7, !tbaa !23
  %t138 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t136)
  store %"compiler/mir:Lvalue" %t138, ptr %l73
  br label %bb19
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 0
  store i64 1, ptr %t140
  %t141 = load %"compiler/mir:Lvalue", ptr %l73
  %t142 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t141, 0
  %t143 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t142, ptr %t143
  %t144 = load { i64, [4 x i64] }, ptr %t139
  store { i64, [8 x i64] } zeroinitializer, ptr %t145
  %t146 = getelementptr { i64, [8 x i64] }, ptr %t145, i32 0, i32 0
  store i64 5, ptr %t146
  %t147 = load %"compiler/source:Span", ptr %l71
  %t148 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t147, 0
  %t150 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t148, { i64, [4 x i64] } %t144, 1
  %t151 = getelementptr { i64, [8 x i64] }, ptr %t145, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t150, ptr %t151
  %t152 = load { i64, [8 x i64] }, ptr %t145
  %t153 = load ptr, ptr %l69, !tbaa !29
  %t154 = load i32, ptr %l70, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t153, i32 %t154, { i64, [8 x i64] } %t152)
  br label %bb20
bb20:
  %t156 = load ptr, ptr %lp6
  store ptr %t156, ptr %l76, !tbaa !29
  %t157 = load i32, ptr %l10, !tbaa !23
  store i32 %t157, ptr %l77, !tbaa !23
  %t158 = load i32, ptr %l8, !tbaa !23
  %t160 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t158)
  store %"compiler/mir:Lvalue" %t160, ptr %l79
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 0
  store i64 1, ptr %t162
  %t163 = load %"compiler/mir:Lvalue", ptr %l79
  %t164 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t163, 0
  %t165 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t164, ptr %t165
  %t166 = load { i64, [4 x i64] }, ptr %t161
  store { i64, [4 x i64] } %t166, ptr %l80
  %t167 = load ptr, ptr %lp6
  store ptr %t167, ptr %l81, !tbaa !29
  %t169 = load i32, ptr %l11, !tbaa !23
  %t172 = call %"compiler/mir:Case" @compiler_2fmir_3aCase_2ector(ptr %s0, i64 %a4, i32 %t169)
  store %"compiler/mir:Case" %t172, ptr %l84
  br label %bb22
bb22:
  %t173 = mul i64 1, 16
  %t174 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 1, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l85, !tbaa !27
  %t177 = load %"compiler/mir:Case", ptr %l84
  %t178 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr %"compiler/mir:Case", ptr %t179, i64 0
  store %"compiler/mir:Case" %t177, ptr %t180
  %t181 = load ptr, ptr %l81, !tbaa !29
  %t182 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t183 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCases(ptr %v1, ptr %s0, ptr %t181, { i64, ptr } %t182)
  store %"compiler/mir:Range" %t183, ptr %l86
  br label %bb23
bb23:
  %t184 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t185
  %t186 = getelementptr { i64, [8 x i64] }, ptr %t185, i32 0, i32 0
  store i64 3, ptr %t186
  %t187 = load { i64, [4 x i64] }, ptr %l80
  %t188 = insertvalue { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } undef, { i64, [4 x i64] } %t187, 0
  %t189 = load %"compiler/mir:Range", ptr %l86
  %t190 = insertvalue { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } %t188, %"compiler/mir:Range" %t189, 1
  %t192 = insertvalue { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } %t190, i32 %t184, 2
  %t193 = getelementptr { i64, [8 x i64] }, ptr %t185, i32 0, i32 1
  store { { i64, [4 x i64] }, %"compiler/mir:Range", i32 } %t192, ptr %t193
  %t194 = load { i64, [8 x i64] }, ptr %t185
  %t195 = load ptr, ptr %l76, !tbaa !29
  %t196 = load i32, ptr %l77, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t195, i32 %t196, { i64, [8 x i64] } %t194)
  br label %bb24
bb24:
  %t198 = load ptr, ptr %lp6
  %t199 = load i32, ptr %l11, !tbaa !23
  %t200 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t201 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t202
  %t203 = getelementptr { i64, [21 x i64] }, ptr %t202, i32 0, i32 0
  store i64 4, ptr %t203
  %t205 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t200, 0
  %t207 = insertvalue { %"compiler/source:Span", i32 } %t205, i32 %t201, 1
  %t208 = getelementptr { i64, [21 x i64] }, ptr %t202, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t207, ptr %t208
  %t209 = load { i64, [21 x i64] }, ptr %t202
  %t211 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t209, ptr %t211
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t198, i32 %t199, ptr %t211)
  br label %bb25
bb25:
  %t215 = load ptr, ptr %lp6
  %t216 = load i32, ptr %l11, !tbaa !23
  %t217 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t218 = load i32, ptr %l5, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 0
  store i64 2, ptr %t220
  %t222 = insertvalue { i32, i64 } undef, i32 %t218, 0
  %t223 = insertvalue { i32, i64 } %t222, i64 -1, 1
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 1
  store { i32, i64 } %t223, ptr %t224
  %t225 = load { i64, [4 x i64] }, ptr %t219
  store { i64, [8 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [8 x i64] }, ptr %t226, i32 0, i32 0
  store i64 5, ptr %t227
  %t229 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t217, 0
  %t231 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t229, { i64, [4 x i64] } %t225, 1
  %t232 = getelementptr { i64, [8 x i64] }, ptr %t226, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t231, ptr %t232
  %t233 = load { i64, [8 x i64] }, ptr %t226
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t215, i32 %t216, { i64, [8 x i64] } %t233)
  br label %bb26
bb26:
  %t237 = load ptr, ptr %lp6
  %t238 = load i32, ptr %l12, !tbaa !23
  %t239 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t240 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t241
  %t242 = getelementptr { i64, [21 x i64] }, ptr %t241, i32 0, i32 0
  store i64 4, ptr %t242
  %t244 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t239, 0
  %t246 = insertvalue { %"compiler/source:Span", i32 } %t244, i32 %t240, 1
  %t247 = getelementptr { i64, [21 x i64] }, ptr %t241, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t246, ptr %t247
  %t248 = load { i64, [21 x i64] }, ptr %t241
  %t250 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t248, ptr %t250
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t237, i32 %t238, ptr %t250)
  br label %bb27
bb27:
  %t254 = load ptr, ptr %lp6
  %t255 = load i32, ptr %l12, !tbaa !23
  %t256 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t257 = load i32, ptr %l5, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t258
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 0
  store i64 2, ptr %t259
  %t261 = insertvalue { i32, i64 } undef, i32 %t257, 0
  %t262 = insertvalue { i32, i64 } %t261, i64 -2, 1
  %t263 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  store { i32, i64 } %t262, ptr %t263
  %t264 = load { i64, [4 x i64] }, ptr %t258
  store { i64, [8 x i64] } zeroinitializer, ptr %t265
  %t266 = getelementptr { i64, [8 x i64] }, ptr %t265, i32 0, i32 0
  store i64 5, ptr %t266
  %t268 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t256, 0
  %t270 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t268, { i64, [4 x i64] } %t264, 1
  %t271 = getelementptr { i64, [8 x i64] }, ptr %t265, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t270, ptr %t271
  %t272 = load { i64, [8 x i64] }, ptr %t265
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t254, i32 %t255, { i64, [8 x i64] } %t272)
  br label %bb28
bb28:
  %t276 = load ptr, ptr %lp6
  call void @llvm.memmove.p0.p0.i64(ptr %l113, ptr %t276, i64 248, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l113, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecmp128(i64 %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = icmp ne i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  br i1 %a4, label %bb3, label %bb4
bb2:
  br label %bb13
bb3:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  br i1 %t13, label %bb5, label %bb6
bb4:
  br label %bb8
bb5:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb7
bb6:
  store i64 1, ptr %l12, !tbaa !24
  br label %bb7
bb7:
  %t15 = load i64, ptr %l12, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
bb8:
  %t16 = load i64, ptr %l1, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = call i1 @compiler_2feval_2eult64(i64 %t16, i64 %t17)
  store i1 %t20, ptr %l15
  br label %bb9
bb9:
  %t21 = load i1, ptr %l15, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  store i64 -1, ptr %l16, !tbaa !24
  br label %bb12
bb11:
  store i64 1, ptr %l16, !tbaa !24
  br label %bb12
bb12:
  %t22 = load i64, ptr %l16, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
bb13:
  %t23 = load i64, ptr %l0, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = icmp eq i64 %t23, %t24
  br i1 %t27, label %bb14, label %bb15
bb14:
  store i64 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t30 = load i64, ptr %l0, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call i1 @compiler_2feval_2eult64(i64 %t30, i64 %t31)
  store i1 %t34, ptr %l23
  br label %bb17
bb17:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb18, label %bb19
bb18:
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb20
bb19:
  store i64 1, ptr %l24, !tbaa !24
  br label %bb20
bb20:
  %t36 = load i64, ptr %l24, !tbaa !24
  store i64 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineDestructor(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 28
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Haf69023555548e8239d9db5dde4c25f9(ptr %v0, ptr %t3, i32 %a1, { i64, [2 x i64] } %a2)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineExtern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 25
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = extractvalue { i64, ptr } %a2, 1
  %t8 = extractvalue { i64, ptr } %a2, 0
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t7, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v0, ptr %t3, i64 %t4, { i64, ptr } %t18)
  br label %bb1
bb1:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb2, label %bb3
bb2:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/eval:Machine", ptr %t26, i32 0, i32 26
  %t29 = load i64, ptr %l1, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t28, i64 %t29, i64 %t30)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineTable(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l7 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 30
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_H6f34e373626f6b99bb5e62c0fd8bd7a4(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i1, ptr %l7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 29
  %t12 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__Hbdd7c5068e376aa260a62181a9f99429(ptr %v0, ptr %t11, i64 %t12, i32 %a2)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 30
  %t20 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_Hd8d89e440939766a34c786789c5d3b97(ptr %v0, ptr %v1, ptr %t19, i64 %t20, { i64, ptr } %a3)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eInitGlobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l14 = alloca %"compiler/eval:gkey"
  %l15 = alloca i64
  %l16 = alloca i32
  %l24 = alloca %"compiler/eval:global"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [5 x i64] }
  %t5 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 13
  store i1 false, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [5 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t7 = load { i64, [5 x i64] }, ptr %t5
  %t10 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 12
  store { i64, [5 x i64] } %t7, ptr %t10
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t11, i32 0, i32 6
  store i64 0, ptr %t13, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 34
  store ptr %t16, ptr %l11, !tbaa !29
  %t21 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s0, i64 %a1, i32 %a2)
  store %"compiler/eval:gkey" %t21, ptr %l14
  br label %bb1
bb1:
  %t22 = load ptr, ptr %l11, !tbaa !29
  %t23 = load %"compiler/eval:gkey", ptr %l14
  %t24 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t22, %"compiler/eval:gkey" %t23)
  %t25 = extractvalue { i32, i64 } %t24, 1
  %t26 = extractvalue { i32, i64 } %t24, 0
  store i32 %t26, ptr %l16
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb3, label %ok.28, !prof !99
ok.28:
  store i64 %t25, ptr %l15
  br label %bb2
bb2:
  %t29 = load i64, ptr %l15, !tbaa !24
  store i64 %t29, ptr %l9, !tbaa !24
  br label %bb6
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t32 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t32, ptr %t30, { i64, ptr } %t31)
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/eval:Machine", ptr %t35, i32 0, i32 12
  %t38 = load { i64, [5 x i64] }, ptr %t37
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t38, ptr %rv
  br label %ret
bb6:
  %t40 = load i64, ptr %l9, !tbaa !24
  store i64 %t40, ptr %l3, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/eval:Machine", ptr %t41, i32 0, i32 33
  %t44 = load i64, ptr %l3, !tbaa !24
  %t47 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t43, i64 %t44)
  store %"compiler/eval:global" %t47, ptr %l24
  br label %bb7
bb7:
  %t48 = getelementptr %"compiler/eval:global", ptr %l24, i32 0, i32 4
  %t49 = load i64, ptr %t48, !tbaa !24
  %t51 = icmp ne i64 %t49, 2
  br i1 %t51, label %bb8, label %bb9
bb8:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/eval:Machine", ptr %t53, i32 0, i32 50
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l4, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartGlobal(ptr %v0, ptr %t58, i64 %t59)
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %t62, i64 %t63)
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunwind(ptr %v0, ptr %t66, i64 %t67)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t70, i32 0, i32 12
  %t73 = load { i64, [5 x i64] }, ptr %t72
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local { i64, %"compiler/source:Span" } @compiler_2feval_2ecompiler_2feval_3aMachine_2eStaleGrewAt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %l5 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %l18 = alloca %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba"
  %s1 = alloca %olang.scope
  %rv = alloca { i64, %"compiler/source:Span" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 72
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/eval:Machine", ptr %t8, i32 0, i32 72
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t12, i32 0, i32 71
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l10
  br label %bb3
bb3:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = icmp sge i64 %t17, %t18
  store i1 %t19, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l5, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t22, ptr %l12
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t23 = insertvalue { i64, %"compiler/source:Span" } undef, i64 -1, 0
  %t24 = load %"compiler/source:Span", ptr %l12
  %t25 = insertvalue { i64, %"compiler/source:Span" } %t23, %"compiler/source:Span" %t24, 1
  call void @__olang_scope_close(ptr %s1)
  store { i64, %"compiler/source:Span" } %t25, ptr %rv
  br label %ret
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/eval:Machine", ptr %t27, i32 0, i32 71
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 72
  %t33 = load i64, ptr %t32, !tbaa !24
  %t36 = call %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H1a77801a5ab3ea58cbf0ff15b43ff2de(ptr %v0, ptr %t29, i64 %t33)
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t36, ptr %l18
  br label %bb9
bb9:
  %t37 = load %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l18
  store %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" %t37, ptr %l1
  %t38 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l1, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = getelementptr %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba", ptr %l1, i32 0, i32 1
  %t41 = load %"compiler/source:Span", ptr %t40
  %t43 = insertvalue { i64, %"compiler/source:Span" } undef, i64 %t39, 0
  %t45 = insertvalue { i64, %"compiler/source:Span" } %t43, %"compiler/source:Span" %t41, 1
  store { i64, %"compiler/source:Span" } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, %"compiler/source:Span" }, ptr %rv
  ret { i64, %"compiler/source:Span" } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceLen(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 75
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !24
  %t7 = sdiv i64 %t6, 4
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/eval:alloc"
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/eval:scope"
  %l34 = alloca i1
  %l43 = alloca i1
  %l55 = alloca i64
  %l57 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l67 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l96 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l114 = alloca i64
  %l117 = alloca ptr
  %l119 = alloca i64
  %l122 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i32
  %l128 = alloca i64
  %l130 = alloca { i64, ptr }
  %l157 = alloca %"compiler/eval:scope"
  %l163 = alloca { i64, ptr }
  %l170 = alloca %"compiler/eval:scope"
  %l175 = alloca %"compiler/eval:scope"
  %l179 = alloca i1
  %l184 = alloca i1
  %l191 = alloca { i64, ptr }
  %l194 = alloca ptr
  %l199 = alloca i64
  %l203 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  %t292 = alloca %"compiler/eval:scope", align 8
  %t323 = alloca %"compiler/eval:scope", align 8
  %t335 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 13
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/eval:Ptr" %t6, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, 0
  br i1 %t10, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = icmp sgt i64 %t12, 1099511627776
  store i1 %t14, ptr %l34, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l34, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyLong, !tbaa !27
  %t19 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t19, ptr %t17, { i64, ptr } %t18)
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t22 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/eval:Ptr" %t22, ptr %rv
  br label %ret
bb10:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/eval:Machine", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %t26, !tbaa !24
  %t29 = icmp sge i64 %t27, 0
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/eval:Machine", ptr %t31, i32 0, i32 7
  %t34 = load i64, ptr %t33, !tbaa !24
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 3
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = icmp sgt i64 %t38, %t42
  store i1 %t45, ptr %l43, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l43, !tbaa !21
  br i1 %t47, label %bb14, label %bb15
bb14:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyMemory, !tbaa !27
  %t50 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t50, ptr %t48, { i64, ptr } %t49)
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t53 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/eval:Ptr" %t53, ptr %rv
  br label %ret
bb17:
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = call i64 @compiler_2feval_2eclassOf(i64 %t55)
  store i64 %t57, ptr %l55
  br label %bb18
bb18:
  %t58 = load i64, ptr %l55, !tbaa !24
  store i64 %t58, ptr %l4, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/eval:Machine", ptr %t59, i32 0, i32 39
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l57, !tbaa !27
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i64, ptr %t66, i64 %t63
  %t68 = load i64, ptr %t67, !tbaa !34
  store i64 %t68, ptr %l5, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t72 = icmp ne i64 %t70, 0
  br i1 %t72, label %bb19, label %bb20
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/eval:Machine", ptr %t74, i32 0, i32 39
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l63, !tbaa !27
  %t78 = load i64, ptr %l4, !tbaa !24
  store i64 %t78, ptr %l64, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i64, ptr %l5, !tbaa !24
  %t83 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t79, i64 %t80, i64 8)
  store i64 %t83, ptr %l67
  br label %bb21
bb20:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/eval:Machine", ptr %t84, i32 0, i32 38
  %t87 = load i64, ptr %t86, !tbaa !24
  store i64 %t87, ptr %l5, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/eval:Machine", ptr %t90, i32 0, i32 38
  %t93 = load i64, ptr %t92, !tbaa !24
  %t94 = load i64, ptr %l4, !tbaa !24
  store i64 %t94, ptr %l114, !tbaa !24
  %t95 = load i64, ptr %l114, !tbaa !24
  %t96 = load i64, ptr %l114, !tbaa !24
  %t97 = shl i64 1, %t96
  %t100 = add i64 %t93, %t97
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2egrow(ptr %v0, ptr %t89, i64 %t100)
  br label %bb34
bb21:
  %t103 = load i64, ptr %l67, !tbaa !24
  %t104 = load i64, ptr %l64, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i64, ptr %t106, i64 %t104
  store i64 %t103, ptr %t107, !tbaa !34
  store i64 0, ptr %l6, !tbaa !24
  %t108 = load i64, ptr %l1, !tbaa !24
  %t110 = add i64 %t108, 7
  %t112 = sdiv i64 %t110, 8
  store i64 %t112, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb22, label %bb23
bb22:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb27
bb24:
  %t124 = load i64, ptr %l7, !tbaa !24
  %t125 = load i64, ptr %l6, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l8, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l8, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l77, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb26
bb26:
  %t140 = load i64, ptr %l77, !tbaa !24
  store i64 %t140, ptr %l74, !tbaa !24
  br label %bb27
bb27:
  %t141 = load i64, ptr %l74, !tbaa !24
  store i64 %t141, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb28
bb28:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t143 = load i64, ptr %l9, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t150 = load i64, ptr %l6, !tbaa !24
  %t151 = load i64, ptr %l10, !tbaa !24
  %t152 = load i64, ptr %l8, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l11, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/eval:Machine", ptr %t160, i32 0, i32 36
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l96, !tbaa !27
  %t164 = load i64, ptr %l5, !tbaa !24
  %t166 = sdiv i64 %t164, 8
  %t167 = load i64, ptr %l11, !tbaa !24
  %t170 = add i64 %t166, %t167
  %t172 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i64, ptr %t173, i64 %t170
  store i64 0, ptr %t174, !tbaa !34
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/eval:Machine", ptr %t175, i32 0, i32 37
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l102, !tbaa !27
  %t179 = load i64, ptr %l5, !tbaa !24
  %t181 = sdiv i64 %t179, 8
  %t182 = load i64, ptr %l11, !tbaa !24
  %t185 = add i64 %t181, %t182
  %t187 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i64, ptr %t188, i64 %t185
  store i64 0, ptr %t189, !tbaa !34
  br label %bb32
bb32:
  %t190 = load i64, ptr %l10, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l10, !tbaa !24
  br label %bb28
bb33:
  br label %bb35
bb34:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l117, !tbaa !29
  %t195 = load ptr, ptr %l117, !tbaa !29
  %t196 = getelementptr %"compiler/eval:Machine", ptr %t195, i32 0, i32 38
  %t197 = load i64, ptr %t196, !tbaa !24
  %t198 = load i64, ptr %l4, !tbaa !24
  store i64 %t198, ptr %l119, !tbaa !24
  %t199 = load i64, ptr %l119, !tbaa !24
  %t200 = load i64, ptr %l119, !tbaa !24
  %t201 = shl i64 1, %t200
  %t204 = add i64 %t197, %t201
  %t206 = load ptr, ptr %l117, !tbaa !29
  %t207 = getelementptr %"compiler/eval:Machine", ptr %t206, i32 0, i32 38
  store i64 %t204, ptr %t207, !tbaa !24
  br label %bb35
bb35:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/eval:Machine", ptr %t208, i32 0, i32 42
  %t212 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t210)
  %t213 = extractvalue { i32, i64 } %t212, 1
  %t214 = extractvalue { i32, i64 } %t212, 0
  store i32 %t214, ptr %l126
  %t215 = icmp ne i32 %t214, 0
  br i1 %t215, label %bb37, label %ok.216, !prof !99
ok.216:
  store i64 %t213, ptr %l125
  br label %bb36
bb36:
  %t217 = load i64, ptr %l125, !tbaa !24
  store i64 %t217, ptr %l122, !tbaa !24
  br label %bb40
bb37:
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewSlot(ptr %v0, ptr %t218)
  store i64 %t220, ptr %l128
  br label %bb39
bb39:
  %t221 = load i64, ptr %l128, !tbaa !24
  store i64 %t221, ptr %l122, !tbaa !24
  br label %bb40
bb40:
  %t222 = load i64, ptr %l122, !tbaa !24
  store i64 %t222, ptr %l12, !tbaa !24
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/eval:Machine", ptr %t223, i32 0, i32 40
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  store { i64, ptr } %t226, ptr %l130, !tbaa !27
  %t227 = load i64, ptr %l12, !tbaa !24
  %t229 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr %"compiler/eval:alloc", ptr %t230, i64 %t227
  %t232 = load %"compiler/eval:alloc", ptr %t231
  store %"compiler/eval:alloc" %t232, ptr %l13
  %t234 = load i64, ptr %l5, !tbaa !24
  %t236 = load i64, ptr %l1, !tbaa !24
  %t238 = load i64, ptr %l4, !tbaa !24
  %t242 = load i64, ptr %l3, !tbaa !24
  %t246 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 0
  store i64 %t234, ptr %t246, !tbaa !24
  %t249 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 1
  store i64 %t236, ptr %t249, !tbaa !24
  %t252 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 2
  store i64 %t238, ptr %t252, !tbaa !24
  %t255 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 4
  store i64 %a2, ptr %t255, !tbaa !24
  %t258 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 5
  store i64 %t242, ptr %t258, !tbaa !24
  %t261 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 8
  store i64 -1, ptr %t261, !tbaa !24
  %t264 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 10
  store i1 false, ptr %t264, !tbaa !21
  %t267 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 11
  store i64 -1, ptr %t267, !tbaa !24
  %t270 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 12
  store i1 false, ptr %t270, !tbaa !21
  %t271 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 9
  store i64 -1, ptr %t271, !tbaa !24
  %t274 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 6
  store i64 0, ptr %t274, !tbaa !24
  %t277 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 7
  store i64 0, ptr %t277, !tbaa !24
  %t278 = load i64, ptr %l3, !tbaa !24
  %t280 = icmp ne i64 %t278, 0
  br i1 %t280, label %bb41, label %bb42
bb41:
  %t282 = load i64, ptr %l3, !tbaa !24
  %t283 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t286 = and i64 %t282, %t283
  store i64 %t286, ptr %l25, !tbaa !24
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/eval:Machine", ptr %t288, i32 0, i32 43
  %t291 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t292, ptr %v0, ptr %t290, i64 %t291)
  call void @llvm.memmove.p0.p0.i64(ptr %l157, ptr %t292, i64 136, i1 false)
  br label %bb43
bb42:
  br label %bb58
bb43:
  %t295 = getelementptr %"compiler/eval:scope", ptr %l157, i32 0, i32 3
  %t296 = load i64, ptr %t295, !tbaa !24
  store i64 %t296, ptr %l26, !tbaa !24
  %t298 = load i64, ptr %l26, !tbaa !24
  %t300 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 7
  store i64 %t298, ptr %t300, !tbaa !24
  %t301 = load i64, ptr %l26, !tbaa !24
  %t303 = icmp ne i64 %t301, 0
  br i1 %t303, label %bb44, label %bb45
bb44:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/eval:Machine", ptr %t305, i32 0, i32 40
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  store { i64, ptr } %t308, ptr %l163, !tbaa !27
  %t309 = load i64, ptr %l26, !tbaa !24
  %t310 = load i64, ptr %l12, !tbaa !24
  %t313 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr %"compiler/eval:alloc", ptr %t314, i64 %t309
  %t316 = getelementptr %"compiler/eval:alloc", ptr %t315, i32 0, i32 6
  store i64 %t310, ptr %t316, !tbaa !24
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t317 = load i64, ptr %l25, !tbaa !24
  store i64 %t317, ptr %l27, !tbaa !24
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/eval:Machine", ptr %t319, i32 0, i32 43
  %t322 = load i64, ptr %l27, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t323, ptr %v0, ptr %t321, i64 %t322)
  call void @llvm.memmove.p0.p0.i64(ptr %l170, ptr %t323, i64 136, i1 false)
  br label %bb47
bb47:
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %l170, i64 136, i1 false)
  %t326 = load i64, ptr %l12, !tbaa !24
  %t328 = getelementptr %"compiler/eval:scope", ptr %l28, i32 0, i32 3
  store i64 %t326, ptr %t328, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/eval:Machine", ptr %t329, i32 0, i32 43
  %t332 = load i64, ptr %l27, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l175, ptr %l28, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t335, ptr %l175, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t331, i64 %t332, ptr %t335)
  br label %bb48
bb48:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/eval:Machine", ptr %t336, i32 0, i32 1
  %t339 = load i32, ptr %t338
  %t341 = trunc i64 0 to i32
  %t342 = icmp eq i32 %t339, %t341
  br i1 %t342, label %bb49, label %bb50
bb49:
  %t344 = load i64, ptr %l3, !tbaa !24
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/eval:Machine", ptr %t345, i32 0, i32 61
  %t348 = load i64, ptr %t347, !tbaa !24
  %t351 = icmp eq i64 %t344, %t348
  store i1 %t351, ptr %l179, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb51
bb51:
  %t353 = load i1, ptr %l179, !tbaa !21
  br i1 %t353, label %bb52, label %bb53
bb52:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/eval:Machine", ptr %t354, i32 0, i32 64
  %t357 = load i64, ptr %t356, !tbaa !24
  %t359 = icmp sge i64 %t357, 0
  store i1 %t359, ptr %l184, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb54
bb54:
  %t361 = load i1, ptr %l184, !tbaa !21
  br i1 %t361, label %bb55, label %bb56
bb55:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/eval:Machine", ptr %t362, i32 0, i32 64
  %t365 = load i64, ptr %t364, !tbaa !24
  %t367 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 8
  store i64 %t365, ptr %t367, !tbaa !24
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/eval:Machine", ptr %t368, i32 0, i32 40
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  store { i64, ptr } %t371, ptr %l191, !tbaa !27
  %t372 = load i64, ptr %l12, !tbaa !24
  %t373 = load %"compiler/eval:alloc", ptr %l13
  %t376 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr %"compiler/eval:alloc", ptr %t377, i64 %t372
  store %"compiler/eval:alloc" %t373, ptr %t378
  %t379 = load ptr, ptr %l0, !tbaa !29
  store ptr %t379, ptr %l194, !tbaa !29
  %t380 = load ptr, ptr %l194, !tbaa !29
  %t381 = getelementptr %"compiler/eval:Machine", ptr %t380, i32 0, i32 7
  %t382 = load i64, ptr %t381, !tbaa !24
  %t383 = load i64, ptr %l1, !tbaa !24
  %t386 = add i64 %t382, %t383
  %t388 = load ptr, ptr %l194, !tbaa !29
  %t389 = getelementptr %"compiler/eval:Machine", ptr %t388, i32 0, i32 7
  store i64 %t386, ptr %t389, !tbaa !24
  %t390 = getelementptr %"compiler/eval:alloc", ptr %l13, i32 0, i32 3
  %t391 = load i64, ptr %t390, !tbaa !24
  %t392 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t392, ptr %l199, !tbaa !24
  %t394 = load i64, ptr %l199, !tbaa !24
  %t395 = load i64, ptr %l199, !tbaa !24
  %t396 = shl i64 %t391, %t395
  %t397 = load i64, ptr %l12, !tbaa !24
  %t400 = or i64 %t396, %t397
  %t402 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t400, i64 0)
  store %"compiler/eval:Ptr" %t402, ptr %l203
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t403 = load %"compiler/eval:Ptr", ptr %l203
  store %"compiler/eval:Ptr" %t403, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Range" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %rv = alloca { i64, [4 x i64] }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Range" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 17
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 49
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i64 %a1
  %t14 = getelementptr %"compiler/eval:frame", ptr %t13, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr %"compiler/eval:cfn", ptr %t18, i64 %t15
  %t20 = getelementptr %"compiler/eval:cfn", ptr %t19, i32 0, i32 4
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t22 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t29 = add i64 %t25, %a3
  %t31 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t32, i64 %t29
  %t34 = load { i64, [4 x i64] }, ptr %t33
  store { i64, [4 x i64] } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eassign(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2, { i64, [15 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca { %"compiler/eval:Ptr", i32 }
  %l5 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca %"compiler/mir:Lvalue"
  %l10 = alloca i32
  %l11 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca { %"compiler/eval:Ptr", i32 }
  %l13 = alloca %"compiler/eval:Ptr"
  %l15 = alloca i64
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"compiler/mir:Range"
  %l20 = alloca %"compiler/eval:Ptr"
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca %"compiler/mir:Range"
  %l26 = alloca %"compiler/mir:Lvalue"
  %l27 = alloca { %"compiler/eval:Ptr", i32 }
  %l30 = alloca i32
  %l31 = alloca i64
  %l32 = alloca %"compiler/mir:Range"
  %l33 = alloca { i64, [1 x i64] }
  %l34 = alloca { i64, [4 x i64] }
  %l35 = alloca i32
  %l36 = alloca { i64, [1 x i64] }
  %l37 = alloca i32
  %l38 = alloca { i64, [4 x i64] }
  %l39 = alloca { i64, [4 x i64] }
  %l40 = alloca %"compiler/mir:Lvalue"
  %l41 = alloca { i64, [4 x i64] }
  %l42 = alloca { i64, [4 x i64] }
  %l43 = alloca i32
  %l44 = alloca { i64, [2 x i64] }
  %l45 = alloca { i64, [1 x i64] }
  %l46 = alloca %"compiler/mir:Range"
  %l47 = alloca { i64, [4 x i64] }
  %l48 = alloca i32
  %l49 = alloca i32
  %l50 = alloca { i64, [1 x i64] }
  %l51 = alloca { i64, [1 x i64] }
  %l52 = alloca { i64, [1 x i64] }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca %"compiler/eval:scope"
  %l57 = alloca { i64, [4 x i64] }
  %l58 = alloca { i64, [1 x i64] }
  %l59 = alloca i64
  %l63 = alloca { %"compiler/eval:Ptr", i32 }
  %l70 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca i64
  %l86 = alloca { i64, ptr }
  %l114 = alloca { %"compiler/eval:Ptr", i32 }
  %l119 = alloca i64
  %l122 = alloca %"compiler/eval:Ptr"
  %l141 = alloca i1
  %l144 = alloca i32
  %l147 = alloca ptr
  %l148 = alloca i64
  %l149 = alloca %"compiler/eval:Ptr"
  %l153 = alloca { i64, [4 x i64] }
  %l157 = alloca i1
  %l159 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca i32
  %l167 = alloca ptr
  %l168 = alloca i64
  %l169 = alloca %"compiler/eval:Ptr"
  %l170 = alloca i32
  %l174 = alloca { i64, [4 x i64] }
  %l177 = alloca i1
  %l179 = alloca ptr
  %l183 = alloca i32
  %l184 = alloca i32
  %l187 = alloca ptr
  %l188 = alloca i64
  %l189 = alloca %"compiler/eval:Ptr"
  %l190 = alloca i32
  %l194 = alloca { i64, [4 x i64] }
  %l197 = alloca ptr
  %l198 = alloca ptr
  %l199 = alloca i64
  %l203 = alloca { i64, [4 x i64] }
  %l204 = alloca %"compiler/eval:Ptr"
  %l205 = alloca %"compiler/eval:Ptr"
  %l206 = alloca ptr
  %l207 = alloca i64
  %l211 = alloca { i64, [4 x i64] }
  %l212 = alloca i64
  %l216 = alloca ptr
  %l220 = alloca %"compiler/eval:Ptr"
  %l223 = alloca %"compiler/eval:Ptr"
  %l227 = alloca %"compiler/eval:Ptr"
  %l230 = alloca ptr
  %l231 = alloca %"compiler/eval:Ptr"
  %l232 = alloca ptr
  %l233 = alloca ptr
  %l234 = alloca i64
  %l238 = alloca { i64, [4 x i64] }
  %l239 = alloca %"compiler/eval:Ptr"
  %l240 = alloca %"compiler/eval:Ptr"
  %l245 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca %"compiler/eval:Ptr"
  %l256 = alloca i64
  %l262 = alloca i64
  %l272 = alloca i1
  %l273 = alloca i1
  %l279 = alloca i1
  %l285 = alloca i1
  %l286 = alloca ptr
  %l287 = alloca %"compiler/eval:Ptr"
  %l289 = alloca i64
  %l296 = alloca { %"compiler/eval:Ptr", i32 }
  %l299 = alloca ptr
  %l300 = alloca %"compiler/eval:Ptr"
  %l304 = alloca i64
  %l369 = alloca ptr
  %l370 = alloca %"compiler/eval:Ptr"
  %l371 = alloca ptr
  %l372 = alloca ptr
  %l376 = alloca i64
  %l378 = alloca i64
  %l381 = alloca i64
  %l397 = alloca i64
  %l402 = alloca i64
  %l411 = alloca %"compiler/eval:scope"
  %l421 = alloca %"compiler/eval:scope"
  %l426 = alloca %"compiler/eval:scope"
  %l434 = alloca ptr
  %l438 = alloca %"compiler/eval:Ptr"
  %l439 = alloca i64
  %l445 = alloca i64
  %s10 = alloca %olang.scope
  %t803 = alloca %"compiler/eval:scope", align 8
  %t823 = alloca %"compiler/eval:scope", align 8
  %t835 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [15 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t7 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t1, i64 %t2, %"compiler/mir:Lvalue" %a2)
  store { %"compiler/eval:Ptr", i32 } %t7, ptr %l63
  br label %bb1
bb1:
  %t8 = load { %"compiler/eval:Ptr", i32 }, ptr %l63
  store { %"compiler/eval:Ptr", i32 } %t8, ptr %l4
  %t9 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l4, i32 0, i32 0
  %t10 = load %"compiler/eval:Ptr", ptr %t9
  store %"compiler/eval:Ptr" %t10, ptr %l5
  %t12 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l4, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l6, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:Machine", ptr %t15, i32 0, i32 13
  %t18 = load i1, ptr %t17, !tbaa !21
  br i1 %t18, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l7, !tbaa !29
  store ptr %t25, ptr %l70, !tbaa !29
  %t26 = load ptr, ptr %l7, !tbaa !29
  %t27 = load i32, ptr %l6, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l73
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l70, !tbaa !29
  %t32 = load i32, ptr %l73, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t33, ptr %l74
  br label %bb6
bb6:
  %t34 = load i1, ptr %l74, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l7, !tbaa !29
  store ptr %t35, ptr %l76, !tbaa !29
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t37 = load i32, ptr %l6, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l79
  br label %bb9
bb8:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb11
bb9:
  %t41 = load ptr, ptr %l76, !tbaa !29
  %t42 = load i32, ptr %l79, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t43, ptr %l80
  br label %bb10
bb10:
  %t44 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t45 = load i64, ptr %l80, !tbaa !24
  %t47 = and i64 %t45, %t44
  %t49 = icmp ne i64 %t47, 0
  store i1 %t49, ptr %l75, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l75, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/eval:Machine", ptr %t53, i32 0, i32 40
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l86, !tbaa !27
  %t57 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t62 = and i64 %t58, %t59
  %t64 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr %"compiler/eval:alloc", ptr %t65, i64 %t62
  %t67 = getelementptr %"compiler/eval:alloc", ptr %t66, i32 0, i32 5
  %t68 = load i64, ptr %t67, !tbaa !24
  %t71 = getelementptr %"compiler/eval:Machine", ptr %t52, i32 0, i32 65
  store i64 %t68, ptr %t71, !tbaa !24
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t72 = load { i64, [15 x i64] }, ptr %l3
  %t74 = extractvalue { i64, [15 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 0
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t78 = getelementptr { { i64, [4 x i64] } }, ptr %t77, i32 0, i32 0
  %t79 = load { i64, [4 x i64] }, ptr %t78
  store { i64, [4 x i64] } %t79, ptr %l8
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  %t83 = load %"compiler/eval:Ptr", ptr %l5
  %t84 = load i32, ptr %l6, !tbaa !23
  %t85 = load { i64, [4 x i64] }, ptr %l8
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t81, i64 %t82, %"compiler/eval:Ptr" %t83, i32 %t84, { i64, [4 x i64] } %t85)
  br label %bb18
bb18:
  br label %bb185
bb19:
  %t91 = load { i64, [15 x i64] }, ptr %l3
  %t93 = extractvalue { i64, [15 x i64] } %t91, 0
  %t94 = icmp eq i64 %t93, 1
  br i1 %t94, label %bb20, label %bb21
bb20:
  %t96 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t97 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t96, i32 0, i32 0
  %t98 = load %"compiler/mir:Lvalue", ptr %t97
  store %"compiler/mir:Lvalue" %t98, ptr %l9
  %t100 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t101 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t100, i32 0, i32 1
  %t102 = load i32, ptr %t101
  store i32 %t102, ptr %l10, !tbaa !23
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i64, ptr %l1, !tbaa !24
  %t106 = load %"compiler/eval:Ptr", ptr %l5
  %t107 = load %"compiler/mir:Lvalue", ptr %l9
  %t108 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eref(ptr %v0, ptr %t104, i64 %t105, %"compiler/eval:Ptr" %t106, %"compiler/mir:Lvalue" %t107, i32 %t108)
  br label %bb23
bb23:
  br label %bb185
bb24:
  %t114 = load { i64, [15 x i64] }, ptr %l3
  %t116 = extractvalue { i64, [15 x i64] } %t114, 0
  %t117 = icmp eq i64 %t116, 2
  br i1 %t117, label %bb25, label %bb26
bb25:
  %t119 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t120 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/mir:Lvalue", ptr %t120
  store %"compiler/mir:Lvalue" %t121, ptr %l11
  br label %bb27
bb26:
  br label %bb34
bb27:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i64, ptr %l1, !tbaa !24
  %t125 = load %"compiler/mir:Lvalue", ptr %l11
  %t129 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t123, i64 %t124, %"compiler/mir:Lvalue" %t125)
  store { %"compiler/eval:Ptr", i32 } %t129, ptr %l114
  br label %bb28
bb28:
  %t130 = load { %"compiler/eval:Ptr", i32 }, ptr %l114
  store { %"compiler/eval:Ptr", i32 } %t130, ptr %l12
  %t131 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l12, i32 0, i32 0
  %t132 = load %"compiler/eval:Ptr", ptr %t131
  store %"compiler/eval:Ptr" %t132, ptr %l13
  %t134 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l12, i32 0, i32 1
  %t135 = load i32, ptr %t134, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t137, i32 %t135)
  store i64 %t141, ptr %l119
  br label %bb29
bb29:
  %t142 = load i64, ptr %l119, !tbaa !24
  store i64 %t142, ptr %l15, !tbaa !24
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2escratchFor(ptr %v0, ptr %t143, i64 0, i64 %t144)
  store %"compiler/eval:Ptr" %t147, ptr %l122
  br label %bb30
bb30:
  %t148 = load %"compiler/eval:Ptr", ptr %l122
  store %"compiler/eval:Ptr" %t148, ptr %l16
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load %"compiler/eval:Ptr", ptr %l16
  %t151 = load %"compiler/eval:Ptr", ptr %l13
  %t152 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t149, %"compiler/eval:Ptr" %t150, %"compiler/eval:Ptr" %t151, i64 %t152)
  br label %bb31
bb31:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/eval:Ptr", ptr %l13
  %t159 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ezero(ptr %v0, ptr %t157, %"compiler/eval:Ptr" %t158, i64 %t159)
  br label %bb32
bb32:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load %"compiler/eval:Ptr", ptr %l5
  %t165 = load %"compiler/eval:Ptr", ptr %l16
  %t166 = load i64, ptr %l15, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t163, %"compiler/eval:Ptr" %t164, %"compiler/eval:Ptr" %t165, i64 %t166)
  br label %bb33
bb33:
  br label %bb185
bb34:
  %t171 = load { i64, [15 x i64] }, ptr %l3
  %t173 = extractvalue { i64, [15 x i64] } %t171, 0
  %t174 = icmp eq i64 %t173, 3
  br i1 %t174, label %bb35, label %bb36
bb35:
  %t176 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t177 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t176, i32 0, i32 0
  %t178 = load i32, ptr %t177
  store i32 %t178, ptr %l17
  %t180 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t181 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t180, i32 0, i32 1
  %t182 = load i32, ptr %t181
  store i32 %t182, ptr %l18, !tbaa !23
  %t184 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t185 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t184, i32 0, i32 2
  %t186 = load %"compiler/mir:Range", ptr %t185
  store %"compiler/mir:Range" %t186, ptr %l19
  br label %bb37
bb36:
  br label %bb97
bb37:
  %t188 = load i32, ptr %l17
  %t190 = trunc i64 20 to i32
  %t191 = icmp eq i32 %t188, %t190
  br i1 %t191, label %bb38, label %bb39
bb38:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i32, ptr %l18, !tbaa !23
  %t197 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayOf(ptr %v0, ptr %t193, i32 %t194)
  store i32 %t197, ptr %l144
  br label %bb40
bb39:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb41
bb40:
  %t198 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t199 = load i32, ptr %l144, !tbaa !23
  %t201 = icmp ne i32 %t199, %t198
  store i1 %t201, ptr %l141, !tbaa !21
  br label %bb41
bb41:
  %t203 = load i1, ptr %l141, !tbaa !21
  br i1 %t203, label %bb42, label %bb43
bb42:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l147, !tbaa !29
  %t205 = load i64, ptr %l1, !tbaa !24
  store i64 %t205, ptr %l148, !tbaa !24
  %t206 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t206, ptr %l149
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i64, ptr %l1, !tbaa !24
  %t209 = load %"compiler/mir:Range", ptr %l19
  %t213 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t207, i64 %t208, %"compiler/mir:Range" %t209, i64 0)
  store { i64, [4 x i64] } %t213, ptr %l153
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t214 = load i32, ptr %l18, !tbaa !23
  %t215 = load ptr, ptr %l147, !tbaa !29
  %t216 = load i64, ptr %l148, !tbaa !24
  %t217 = load %"compiler/eval:Ptr", ptr %l149
  %t218 = load { i64, [4 x i64] }, ptr %l153
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2econvertArray(ptr %v0, ptr %t215, i64 %t216, %"compiler/eval:Ptr" %t217, { i64, [4 x i64] } %t218, i32 %t214)
  br label %bb45
bb45:
  br label %ret
bb46:
  %t220 = load i32, ptr %l17
  %t222 = trunc i64 20 to i32
  %t223 = icmp eq i32 %t220, %t222
  br i1 %t223, label %bb47, label %bb48
bb47:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/eval:Machine", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  store ptr %t228, ptr %l159, !tbaa !29
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/eval:Machine", ptr %t229, i32 0, i32 0
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t233 = load i32, ptr %l18, !tbaa !23
  %t236 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t232, i32 %t233)
  store i32 %t236, ptr %l163
  br label %bb49
bb48:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb51
bb49:
  %t237 = load ptr, ptr %l159, !tbaa !29
  %t238 = load i32, ptr %l163, !tbaa !23
  %t239 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t237, i32 %t238)
  store i32 %t239, ptr %l164
  br label %bb50
bb50:
  %t240 = load i32, ptr %l164
  %t242 = trunc i64 20 to i32
  %t243 = icmp eq i32 %t240, %t242
  store i1 %t243, ptr %l157, !tbaa !21
  br label %bb51
bb51:
  %t245 = load i1, ptr %l157, !tbaa !21
  br i1 %t245, label %bb52, label %bb53
bb52:
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l167, !tbaa !29
  %t247 = load i64, ptr %l1, !tbaa !24
  store i64 %t247, ptr %l168, !tbaa !24
  %t248 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t248, ptr %l169
  %t249 = load i32, ptr %l18, !tbaa !23
  store i32 %t249, ptr %l170, !tbaa !23
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i64, ptr %l1, !tbaa !24
  %t252 = load %"compiler/mir:Range", ptr %l19
  %t256 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t250, i64 %t251, %"compiler/mir:Range" %t252, i64 0)
  store { i64, [4 x i64] } %t256, ptr %l174
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t257 = load ptr, ptr %l167, !tbaa !29
  %t258 = load i64, ptr %l168, !tbaa !24
  %t259 = load %"compiler/eval:Ptr", ptr %l169
  %t260 = load i32, ptr %l170, !tbaa !23
  %t261 = load { i64, [4 x i64] }, ptr %l174
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t257, i64 %t258, %"compiler/eval:Ptr" %t259, i32 %t260, { i64, [4 x i64] } %t261)
  br label %bb55
bb55:
  br label %ret
bb56:
  %t262 = load i32, ptr %l17
  %t264 = trunc i64 20 to i32
  %t265 = icmp eq i32 %t262, %t264
  br i1 %t265, label %bb57, label %bb58
bb57:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/eval:Machine", ptr %t267, i32 0, i32 0
  %t270 = load ptr, ptr %t269, !tbaa !29
  store ptr %t270, ptr %l179, !tbaa !29
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/eval:Machine", ptr %t271, i32 0, i32 0
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t275 = load i32, ptr %l18, !tbaa !23
  %t278 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t274, i32 %t275)
  store i32 %t278, ptr %l183
  br label %bb59
bb58:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb61
bb59:
  %t279 = load ptr, ptr %l179, !tbaa !29
  %t280 = load i32, ptr %l183, !tbaa !23
  %t281 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t279, i32 %t280)
  store i32 %t281, ptr %l184
  br label %bb60
bb60:
  %t282 = load i32, ptr %l184
  %t284 = trunc i64 21 to i32
  %t285 = icmp eq i32 %t282, %t284
  store i1 %t285, ptr %l177, !tbaa !21
  br label %bb61
bb61:
  %t287 = load i1, ptr %l177, !tbaa !21
  br i1 %t287, label %bb62, label %bb63
bb62:
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l187, !tbaa !29
  %t289 = load i64, ptr %l1, !tbaa !24
  store i64 %t289, ptr %l188, !tbaa !24
  %t290 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t290, ptr %l189
  %t291 = load i32, ptr %l18, !tbaa !23
  store i32 %t291, ptr %l190, !tbaa !23
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load i64, ptr %l1, !tbaa !24
  %t294 = load %"compiler/mir:Range", ptr %l19
  %t298 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t292, i64 %t293, %"compiler/mir:Range" %t294, i64 0)
  store { i64, [4 x i64] } %t298, ptr %l194
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t299 = load ptr, ptr %l187, !tbaa !29
  %t300 = load i64, ptr %l188, !tbaa !24
  %t301 = load %"compiler/eval:Ptr", ptr %l189
  %t302 = load i32, ptr %l190, !tbaa !23
  %t303 = load { i64, [4 x i64] }, ptr %l194
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t299, i64 %t300, %"compiler/eval:Ptr" %t301, i32 %t302, { i64, [4 x i64] } %t303)
  br label %bb65
bb65:
  br label %ret
bb66:
  %t304 = load i32, ptr %l17
  %t306 = trunc i64 40 to i32
  %t307 = icmp eq i32 %t304, %t306
  br i1 %t307, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l197, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l198, !tbaa !29
  %t311 = load i64, ptr %l1, !tbaa !24
  store i64 %t311, ptr %l199, !tbaa !24
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load i64, ptr %l1, !tbaa !24
  %t314 = load %"compiler/mir:Range", ptr %l19
  %t318 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t312, i64 %t313, %"compiler/mir:Range" %t314, i64 0)
  store { i64, [4 x i64] } %t318, ptr %l203
  br label %bb69
bb68:
  br label %bb81
bb69:
  %t319 = load ptr, ptr %l198, !tbaa !29
  %t320 = load i64, ptr %l199, !tbaa !24
  %t321 = load { i64, [4 x i64] }, ptr %l203
  %t322 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t319, i64 %t320, { i64, [4 x i64] } %t321, i64 1)
  store %"compiler/eval:Ptr" %t322, ptr %l204
  br label %bb70
bb70:
  %t323 = load ptr, ptr %l197, !tbaa !29
  %t324 = load %"compiler/eval:Ptr", ptr %l204
  %t325 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t323, %"compiler/eval:Ptr" %t324)
  store %"compiler/eval:Ptr" %t325, ptr %l205
  br label %bb71
bb71:
  %t326 = load %"compiler/eval:Ptr", ptr %l205
  store %"compiler/eval:Ptr" %t326, ptr %l20
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l206, !tbaa !29
  %t328 = load i64, ptr %l1, !tbaa !24
  store i64 %t328, ptr %l207, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i64, ptr %l1, !tbaa !24
  %t331 = load %"compiler/mir:Range", ptr %l19
  %t335 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t329, i64 %t330, %"compiler/mir:Range" %t331, i64 1)
  store { i64, [4 x i64] } %t335, ptr %l211
  br label %bb72
bb72:
  %t336 = load ptr, ptr %l206, !tbaa !29
  %t337 = load i64, ptr %l207, !tbaa !24
  %t338 = load { i64, [4 x i64] }, ptr %l211
  %t339 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t336, i64 %t337, { i64, [4 x i64] } %t338)
  store i64 %t339, ptr %l212
  br label %bb73
bb73:
  %t340 = load i64, ptr %l212, !tbaa !24
  store i64 %t340, ptr %l21, !tbaa !24
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load %"compiler/eval:Ptr", ptr %l5
  %t343 = load %"compiler/eval:Ptr", ptr %l20
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t341, %"compiler/eval:Ptr" %t342, %"compiler/eval:Ptr" %t343)
  br label %bb74
bb74:
  %t347 = load ptr, ptr %l0, !tbaa !29
  store ptr %t347, ptr %l216, !tbaa !29
  %t348 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t349 = load i64, ptr %t348, !tbaa !24
  %t350 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 1
  %t351 = load i64, ptr %t350, !tbaa !24
  %t353 = add i64 %t351, 8
  %t356 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s10, i64 %t349, i64 %t353)
  store %"compiler/eval:Ptr" %t356, ptr %l220
  br label %bb75
bb75:
  %t357 = getelementptr %"compiler/eval:Ptr", ptr %l20, i32 0, i32 0
  %t358 = load i64, ptr %t357, !tbaa !24
  %t360 = icmp eq i64 %t358, 0
  br i1 %t360, label %bb76, label %bb77
bb76:
  %t362 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t362, ptr %l223
  br label %bb79
bb77:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load i64, ptr %l21, !tbaa !24
  %t368 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2etable(ptr %v0, ptr %t364, i64 %t365)
  store %"compiler/eval:Ptr" %t368, ptr %l227
  br label %bb78
bb78:
  %t369 = load %"compiler/eval:Ptr", ptr %l227
  store %"compiler/eval:Ptr" %t369, ptr %l223
  br label %bb79
bb79:
  %t370 = load ptr, ptr %l216, !tbaa !29
  %t371 = load %"compiler/eval:Ptr", ptr %l220
  %t372 = load %"compiler/eval:Ptr", ptr %l223
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t370, %"compiler/eval:Ptr" %t371, %"compiler/eval:Ptr" %t372)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s10)
  br label %ret
bb81:
  %t373 = load i32, ptr %l17
  %t375 = trunc i64 41 to i32
  %t376 = icmp eq i32 %t373, %t375
  br i1 %t376, label %bb82, label %bb83
bb82:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l230, !tbaa !29
  %t379 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t379, ptr %l231
  %t380 = load ptr, ptr %l0, !tbaa !29
  store ptr %t380, ptr %l232, !tbaa !29
  %t381 = load ptr, ptr %l0, !tbaa !29
  store ptr %t381, ptr %l233, !tbaa !29
  %t382 = load i64, ptr %l1, !tbaa !24
  store i64 %t382, ptr %l234, !tbaa !24
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load i64, ptr %l1, !tbaa !24
  %t385 = load %"compiler/mir:Range", ptr %l19
  %t389 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t383, i64 %t384, %"compiler/mir:Range" %t385, i64 0)
  store { i64, [4 x i64] } %t389, ptr %l238
  br label %bb84
bb83:
  br label %bb88
bb84:
  %t390 = load ptr, ptr %l233, !tbaa !29
  %t391 = load i64, ptr %l234, !tbaa !24
  %t392 = load { i64, [4 x i64] }, ptr %l238
  %t393 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t390, i64 %t391, { i64, [4 x i64] } %t392, i64 1)
  store %"compiler/eval:Ptr" %t393, ptr %l239
  br label %bb85
bb85:
  %t394 = load ptr, ptr %l232, !tbaa !29
  %t395 = load %"compiler/eval:Ptr", ptr %l239
  %t396 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t394, %"compiler/eval:Ptr" %t395)
  store %"compiler/eval:Ptr" %t396, ptr %l240
  br label %bb86
bb86:
  %t397 = load ptr, ptr %l230, !tbaa !29
  %t398 = load %"compiler/eval:Ptr", ptr %l231
  %t399 = load %"compiler/eval:Ptr", ptr %l240
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t397, %"compiler/eval:Ptr" %t398, %"compiler/eval:Ptr" %t399)
  br label %bb87
bb87:
  br label %ret
bb88:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load i64, ptr %l1, !tbaa !24
  %t402 = load i32, ptr %l18, !tbaa !23
  %t403 = load %"compiler/mir:Range", ptr %l19
  %t408 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOp(ptr %v0, ptr %t400, i64 %t401, i32 %t402, %"compiler/mir:Range" %t403)
  store i1 %t408, ptr %l245
  br label %bb89
bb89:
  %t409 = load i1, ptr %l245, !tbaa !21
  br i1 %t409, label %bb90, label %bb91
bb90:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load i64, ptr %l1, !tbaa !24
  %t412 = load %"compiler/eval:Ptr", ptr %l5
  %t413 = load i32, ptr %l17
  %t414 = load i32, ptr %l18, !tbaa !23
  %t415 = load %"compiler/mir:Range", ptr %l19
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eprimWide(ptr %v0, ptr %t410, i64 %t411, %"compiler/eval:Ptr" %t412, i32 %t413, i32 %t414, %"compiler/mir:Range" %t415)
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %ret
bb93:
  %t422 = load ptr, ptr %l0, !tbaa !29
  store ptr %t422, ptr %l252, !tbaa !29
  %t423 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t423, ptr %l253
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load i32, ptr %l18, !tbaa !23
  %t428 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t424, i32 %t425)
  store i64 %t428, ptr %l256
  br label %bb94
bb94:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i64, ptr %l1, !tbaa !24
  %t431 = load i32, ptr %l17
  %t432 = load i32, ptr %l18, !tbaa !23
  %t433 = load %"compiler/mir:Range", ptr %l19
  %t439 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eprim(ptr %v0, ptr %t429, i64 %t430, i32 %t431, i32 %t432, %"compiler/mir:Range" %t433)
  store i64 %t439, ptr %l262
  br label %bb95
bb95:
  %t440 = load ptr, ptr %l252, !tbaa !29
  %t441 = load %"compiler/eval:Ptr", ptr %l253
  %t442 = load i64, ptr %l256, !tbaa !24
  %t443 = load i64, ptr %l262, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t440, %"compiler/eval:Ptr" %t441, i64 %t442, i64 %t443)
  br label %bb96
bb96:
  br label %bb185
bb97:
  %t444 = load { i64, [15 x i64] }, ptr %l3
  %t446 = extractvalue { i64, [15 x i64] } %t444, 0
  %t447 = icmp eq i64 %t446, 4
  br i1 %t447, label %bb98, label %bb99
bb98:
  %t449 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t450 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t449, i32 0, i32 0
  %t451 = load i32, ptr %t450
  store i32 %t451, ptr %l22
  %t453 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t454 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t453, i32 0, i32 1
  %t455 = load i32, ptr %t454
  store i32 %t455, ptr %l23, !tbaa !23
  %t457 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t458 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t457, i32 0, i32 2
  %t459 = load %"compiler/mir:Range", ptr %t458
  store %"compiler/mir:Range" %t459, ptr %l24
  br label %bb100
bb99:
  br label %bb111
bb100:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load i64, ptr %l1, !tbaa !24
  %t463 = load i32, ptr %l23, !tbaa !23
  %t464 = load %"compiler/mir:Range", ptr %l24
  %t469 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOp(ptr %v0, ptr %t461, i64 %t462, i32 %t463, %"compiler/mir:Range" %t464)
  store i1 %t469, ptr %l272
  br label %bb101
bb101:
  %t470 = load i1, ptr %l272, !tbaa !21
  br i1 %t470, label %bb102, label %bb103
bb102:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load i64, ptr %l1, !tbaa !24
  %t473 = load i32, ptr %l22
  %t474 = load i32, ptr %l23, !tbaa !23
  %t475 = load %"compiler/mir:Range", ptr %l24
  %t481 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoverflowsWide(ptr %v0, ptr %t471, i64 %t472, i32 %t473, i32 %t474, %"compiler/mir:Range" %t475)
  store i1 %t481, ptr %l279
  br label %bb104
bb103:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load i64, ptr %l1, !tbaa !24
  %t484 = load i32, ptr %l22
  %t485 = load i32, ptr %l23, !tbaa !23
  %t486 = load %"compiler/mir:Range", ptr %l24
  %t492 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoverflows(ptr %v0, ptr %t482, i64 %t483, i32 %t484, i32 %t485, %"compiler/mir:Range" %t486)
  store i1 %t492, ptr %l285
  br label %bb105
bb104:
  %t493 = load i1, ptr %l279, !tbaa !21
  store i1 %t493, ptr %l273, !tbaa !21
  br label %bb106
bb105:
  %t494 = load i1, ptr %l285, !tbaa !21
  store i1 %t494, ptr %l273, !tbaa !21
  br label %bb106
bb106:
  %t495 = load i1, ptr %l273, !tbaa !21
  %t496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t496, ptr %l286, !tbaa !29
  %t497 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t497, ptr %l287
  br i1 %t495, label %bb107, label %bb108
bb107:
  store i64 1, ptr %l289, !tbaa !24
  br label %bb109
bb108:
  store i64 0, ptr %l289, !tbaa !24
  br label %bb109
bb109:
  %t500 = load ptr, ptr %l286, !tbaa !29
  %t501 = load %"compiler/eval:Ptr", ptr %l287
  %t502 = load i64, ptr %l289, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t500, %"compiler/eval:Ptr" %t501, i64 1, i64 %t502)
  br label %bb110
bb110:
  br label %bb185
bb111:
  %t503 = load { i64, [15 x i64] }, ptr %l3
  %t505 = extractvalue { i64, [15 x i64] } %t503, 0
  %t506 = icmp eq i64 %t505, 5
  br i1 %t506, label %bb112, label %bb113
bb112:
  %t508 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t509 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t508, i32 0, i32 0
  %t510 = load %"compiler/mir:Lvalue", ptr %t509
  store %"compiler/mir:Lvalue" %t510, ptr %l26
  br label %bb114
bb113:
  br label %bb118
bb114:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t513 = load i64, ptr %l1, !tbaa !24
  %t514 = load %"compiler/mir:Lvalue", ptr %l26
  %t518 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t512, i64 %t513, %"compiler/mir:Lvalue" %t514)
  store { %"compiler/eval:Ptr", i32 } %t518, ptr %l296
  br label %bb115
bb115:
  %t519 = load { %"compiler/eval:Ptr", i32 }, ptr %l296
  store { %"compiler/eval:Ptr", i32 } %t519, ptr %l27
  %t520 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l27, i32 0, i32 0
  %t521 = load %"compiler/eval:Ptr", ptr %t520
  %t523 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l27, i32 0, i32 1
  %t524 = load i32, ptr %t523, !tbaa !23
  %t526 = load ptr, ptr %l0, !tbaa !29
  store ptr %t526, ptr %l299, !tbaa !29
  %t527 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t527, ptr %l300
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t534 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2etagOf(ptr %v0, ptr %t528, %"compiler/eval:Ptr" %t521, i32 %t524)
  store i64 %t534, ptr %l304
  br label %bb116
bb116:
  %t535 = load ptr, ptr %l299, !tbaa !29
  %t536 = load %"compiler/eval:Ptr", ptr %l300
  %t537 = load i64, ptr %l304, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t535, %"compiler/eval:Ptr" %t536, i64 8, i64 %t537)
  br label %bb117
bb117:
  br label %bb185
bb118:
  %t538 = load { i64, [15 x i64] }, ptr %l3
  %t540 = extractvalue { i64, [15 x i64] } %t538, 0
  %t541 = icmp eq i64 %t540, 6
  br i1 %t541, label %bb119, label %bb120
bb119:
  %t543 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t544 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t543, i32 0, i32 0
  %t545 = load i32, ptr %t544
  store i32 %t545, ptr %l30, !tbaa !23
  %t547 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t548 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t547, i32 0, i32 1
  %t549 = load i64, ptr %t548
  store i64 %t549, ptr %l31, !tbaa !24
  %t551 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t552 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t551, i32 0, i32 2
  %t553 = load %"compiler/mir:Range", ptr %t552
  store %"compiler/mir:Range" %t553, ptr %l32
  br label %bb121
bb120:
  br label %bb123
bb121:
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t556 = load i64, ptr %l1, !tbaa !24
  %t557 = load %"compiler/eval:Ptr", ptr %l5
  %t558 = load i32, ptr %l30, !tbaa !23
  %t559 = load i64, ptr %l31, !tbaa !24
  %t560 = load %"compiler/mir:Range", ptr %l32
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaggregate(ptr %v0, ptr %t555, i64 %t556, %"compiler/eval:Ptr" %t557, i32 %t558, i64 %t559, %"compiler/mir:Range" %t560)
  br label %bb122
bb122:
  br label %bb185
bb123:
  %t567 = load { i64, [15 x i64] }, ptr %l3
  %t569 = extractvalue { i64, [15 x i64] } %t567, 0
  %t570 = icmp eq i64 %t569, 7
  br i1 %t570, label %bb124, label %bb125
bb124:
  %t572 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t573 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t572, i32 0, i32 0
  %t574 = load { i64, [1 x i64] }, ptr %t573
  store { i64, [1 x i64] } %t574, ptr %l33
  %t576 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t577 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t576, i32 0, i32 1
  %t578 = load { i64, [4 x i64] }, ptr %t577
  store { i64, [4 x i64] } %t578, ptr %l34
  %t580 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t581 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t580, i32 0, i32 2
  %t582 = load i32, ptr %t581
  store i32 %t582, ptr %l35, !tbaa !23
  br label %bb126
bb125:
  br label %bb128
bb126:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load i64, ptr %l1, !tbaa !24
  %t586 = load %"compiler/eval:Ptr", ptr %l5
  %t587 = load { i64, [1 x i64] }, ptr %l33
  %t588 = load { i64, [4 x i64] }, ptr %l34
  %t589 = load i32, ptr %l35, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2enewRef(ptr %v0, ptr %t584, i64 %t585, %"compiler/eval:Ptr" %t586, { i64, [1 x i64] } %t587, { i64, [4 x i64] } %t588, i32 %t589)
  br label %bb127
bb127:
  br label %bb185
bb128:
  %t596 = load { i64, [15 x i64] }, ptr %l3
  %t598 = extractvalue { i64, [15 x i64] } %t596, 0
  %t599 = icmp eq i64 %t598, 8
  br i1 %t599, label %bb129, label %bb130
bb129:
  %t601 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t602 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t601, i32 0, i32 0
  %t603 = load { i64, [1 x i64] }, ptr %t602
  store { i64, [1 x i64] } %t603, ptr %l36
  %t605 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t606 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t605, i32 0, i32 1
  %t607 = load i32, ptr %t606
  store i32 %t607, ptr %l37, !tbaa !23
  %t609 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t610 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t609, i32 0, i32 2
  %t611 = load { i64, [4 x i64] }, ptr %t610
  store { i64, [4 x i64] } %t611, ptr %l38
  %t613 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t614 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t613, i32 0, i32 3
  %t615 = load { i64, [4 x i64] }, ptr %t614
  store { i64, [4 x i64] } %t615, ptr %l39
  br label %bb131
bb130:
  br label %bb133
bb131:
  %t617 = load ptr, ptr %l0, !tbaa !29
  %t618 = load i64, ptr %l1, !tbaa !24
  %t619 = load %"compiler/eval:Ptr", ptr %l5
  %t620 = load { i64, [1 x i64] }, ptr %l36
  %t621 = load i32, ptr %l37, !tbaa !23
  %t622 = load { i64, [4 x i64] }, ptr %l38
  %t623 = load { i64, [4 x i64] }, ptr %l39
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2enewArray(ptr %v0, ptr %t617, i64 %t618, %"compiler/eval:Ptr" %t619, { i64, [1 x i64] } %t620, i32 %t621, { i64, [4 x i64] } %t622, { i64, [4 x i64] } %t623)
  br label %bb132
bb132:
  br label %bb185
bb133:
  %t631 = load { i64, [15 x i64] }, ptr %l3
  %t633 = extractvalue { i64, [15 x i64] } %t631, 0
  %t634 = icmp eq i64 %t633, 9
  br i1 %t634, label %bb134, label %bb135
bb134:
  %t636 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t637 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t636, i32 0, i32 0
  %t638 = load %"compiler/mir:Lvalue", ptr %t637
  store %"compiler/mir:Lvalue" %t638, ptr %l40
  %t640 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t641 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t640, i32 0, i32 1
  %t642 = load { i64, [4 x i64] }, ptr %t641
  store { i64, [4 x i64] } %t642, ptr %l41
  %t644 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t645 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t644, i32 0, i32 2
  %t646 = load { i64, [4 x i64] }, ptr %t645
  store { i64, [4 x i64] } %t646, ptr %l42
  %t648 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t649 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t648, i32 0, i32 3
  %t650 = load i32, ptr %t649
  store i32 %t650, ptr %l43, !tbaa !23
  br label %bb136
bb135:
  br label %bb138
bb136:
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t653 = load i64, ptr %l1, !tbaa !24
  %t654 = load %"compiler/eval:Ptr", ptr %l5
  %t655 = load %"compiler/mir:Lvalue", ptr %l40
  %t656 = load { i64, [4 x i64] }, ptr %l41
  %t657 = load { i64, [4 x i64] }, ptr %l42
  %t658 = load i32, ptr %l43, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eslice(ptr %v0, ptr %t652, i64 %t653, %"compiler/eval:Ptr" %t654, %"compiler/mir:Lvalue" %t655, { i64, [4 x i64] } %t656, { i64, [4 x i64] } %t657, i32 %t658)
  br label %bb137
bb137:
  br label %bb185
bb138:
  %t666 = load { i64, [15 x i64] }, ptr %l3
  %t668 = extractvalue { i64, [15 x i64] } %t666, 0
  %t669 = icmp eq i64 %t668, 10
  br i1 %t669, label %bb139, label %bb140
bb139:
  %t671 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t672 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t671, i32 0, i32 0
  %t673 = load { i64, [2 x i64] }, ptr %t672
  store { i64, [2 x i64] } %t673, ptr %l44
  %t675 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t676 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t675, i32 0, i32 2
  %t677 = load { i64, [1 x i64] }, ptr %t676
  store { i64, [1 x i64] } %t677, ptr %l45
  %t679 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t680 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t679, i32 0, i32 3
  %t681 = load %"compiler/mir:Range", ptr %t680
  store %"compiler/mir:Range" %t681, ptr %l46
  br label %bb141
bb140:
  br label %bb143
bb141:
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t684 = load i64, ptr %l1, !tbaa !24
  %t685 = load %"compiler/eval:Ptr", ptr %l5
  %t686 = load { i64, [2 x i64] }, ptr %l44
  %t687 = load { i64, [1 x i64] }, ptr %l45
  %t688 = load %"compiler/mir:Range", ptr %l46
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eclosure(ptr %v0, ptr %t683, i64 %t684, %"compiler/eval:Ptr" %t685, { i64, [2 x i64] } %t686, { i64, [1 x i64] } %t687, %"compiler/mir:Range" %t688)
  br label %bb142
bb142:
  br label %bb185
bb143:
  %t695 = load { i64, [15 x i64] }, ptr %l3
  %t697 = extractvalue { i64, [15 x i64] } %t695, 0
  %t698 = icmp eq i64 %t697, 11
  br i1 %t698, label %bb144, label %bb145
bb144:
  %t700 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t701 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t700, i32 0, i32 0
  %t702 = load { i64, [4 x i64] }, ptr %t701
  store { i64, [4 x i64] } %t702, ptr %l47
  %t704 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t705 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t704, i32 0, i32 1
  %t706 = load i32, ptr %t705
  store i32 %t706, ptr %l48, !tbaa !23
  %t708 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t709 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t708, i32 0, i32 2
  %t710 = load i32, ptr %t709
  store i32 %t710, ptr %l49, !tbaa !23
  br label %bb146
bb145:
  br label %bb151
bb146:
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l369, !tbaa !29
  %t713 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t713, ptr %l370
  %t714 = load ptr, ptr %l0, !tbaa !29
  store ptr %t714, ptr %l371, !tbaa !29
  %t715 = load ptr, ptr %l0, !tbaa !29
  store ptr %t715, ptr %l372, !tbaa !29
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = load i64, ptr %l1, !tbaa !24
  %t718 = load { i64, [4 x i64] }, ptr %l47
  %t722 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t716, i64 %t717, { i64, [4 x i64] } %t718)
  store i64 %t722, ptr %l376
  br label %bb147
bb147:
  %t723 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t724 = load ptr, ptr %l372, !tbaa !29
  %t725 = load i64, ptr %l376, !tbaa !24
  %t727 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t724, i64 %t725, i32 %t723)
  store i64 %t727, ptr %l378
  br label %bb148
bb148:
  %t728 = load i32, ptr %l48, !tbaa !23
  %t729 = load i32, ptr %l49, !tbaa !23
  %t730 = load ptr, ptr %l371, !tbaa !29
  %t731 = load i64, ptr %l378, !tbaa !24
  %t734 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erecode(ptr %v0, ptr %t730, i64 %t731, i32 %t728, i32 %t729)
  store i64 %t734, ptr %l381
  br label %bb149
bb149:
  %t735 = load ptr, ptr %l369, !tbaa !29
  %t736 = load %"compiler/eval:Ptr", ptr %l370
  %t737 = load i64, ptr %l381, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t735, %"compiler/eval:Ptr" %t736, i64 4, i64 %t737)
  br label %bb150
bb150:
  br label %bb185
bb151:
  %t738 = load { i64, [15 x i64] }, ptr %l3
  %t740 = extractvalue { i64, [15 x i64] } %t738, 0
  %t741 = icmp eq i64 %t740, 12
  br i1 %t741, label %bb152, label %bb153
bb152:
  %t743 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t744 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t743, i32 0, i32 0
  %t745 = load { i64, [1 x i64] }, ptr %t744
  store { i64, [1 x i64] } %t745, ptr %l50
  %t747 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t748 = getelementptr { { i64, [1 x i64] }, { i64, [1 x i64] }, i32 }, ptr %t747, i32 0, i32 1
  %t749 = load { i64, [1 x i64] }, ptr %t748
  store { i64, [1 x i64] } %t749, ptr %l51
  br label %bb154
bb153:
  br label %bb156
bb154:
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t752 = load i64, ptr %l1, !tbaa !24
  %t753 = load %"compiler/eval:Ptr", ptr %l5
  %t754 = load { i64, [1 x i64] }, ptr %l50
  %t755 = load { i64, [1 x i64] }, ptr %l51
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2etext(ptr %v0, ptr %t751, i64 %t752, %"compiler/eval:Ptr" %t753, { i64, [1 x i64] } %t754, { i64, [1 x i64] } %t755)
  br label %bb155
bb155:
  br label %bb185
bb156:
  %t761 = load { i64, [15 x i64] }, ptr %l3
  %t763 = extractvalue { i64, [15 x i64] } %t761, 0
  %t764 = icmp eq i64 %t763, 13
  br i1 %t764, label %bb157, label %bb158
bb157:
  %t766 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t767 = getelementptr { { i64, [1 x i64] } }, ptr %t766, i32 0, i32 0
  %t768 = load { i64, [1 x i64] }, ptr %t767
  store { i64, [1 x i64] } %t768, ptr %l52
  br label %bb159
bb158:
  br label %bb173
bb159:
  %t770 = load ptr, ptr %l0, !tbaa !29
  %t771 = load i64, ptr %l1, !tbaa !24
  %t772 = load { i64, [1 x i64] }, ptr %l52
  %t776 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %t770, i64 %t771, { i64, [1 x i64] } %t772)
  store i64 %t776, ptr %l397
  br label %bb160
bb160:
  %t777 = load i64, ptr %l397, !tbaa !24
  store i64 %t777, ptr %l53, !tbaa !24
  %t778 = load ptr, ptr %l0, !tbaa !29
  %t780 = getelementptr %"compiler/eval:Machine", ptr %t778, i32 0, i32 13
  %t781 = load i1, ptr %t780, !tbaa !21
  br i1 %t781, label %bb161, label %bb162
bb161:
  br label %ret
bb162:
  br label %bb163
bb163:
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t787 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v0, ptr %t783, i64 %t784)
  store i64 %t787, ptr %l402
  br label %bb164
bb164:
  %t788 = load i64, ptr %l402, !tbaa !24
  store i64 %t788, ptr %l54, !tbaa !24
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = load i64, ptr %l54, !tbaa !24
  %t791 = load i64, ptr %l53, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eadopt(ptr %v0, ptr %t789, i64 %t790, i64 %t791)
  br label %bb165
bb165:
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t797 = getelementptr %"compiler/eval:Machine", ptr %t795, i32 0, i32 43
  %t798 = load i64, ptr %l53, !tbaa !24
  %t799 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t802 = and i64 %t798, %t799
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t803, ptr %v0, ptr %t797, i64 %t802)
  call void @llvm.memmove.p0.p0.i64(ptr %l411, ptr %t803, i64 136, i1 false)
  br label %bb166
bb166:
  %t806 = getelementptr %"compiler/eval:scope", ptr %l411, i32 0, i32 2
  %t807 = load i64, ptr %t806, !tbaa !24
  %t808 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t811 = icmp ne i64 %t807, %t808
  br i1 %t811, label %bb167, label %bb168
bb167:
  %t813 = load i64, ptr %l54, !tbaa !24
  %t814 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t817 = and i64 %t813, %t814
  store i64 %t817, ptr %l55, !tbaa !24
  %t819 = load ptr, ptr %l0, !tbaa !29
  %t821 = getelementptr %"compiler/eval:Machine", ptr %t819, i32 0, i32 43
  %t822 = load i64, ptr %l55, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t823, ptr %v0, ptr %t821, i64 %t822)
  call void @llvm.memmove.p0.p0.i64(ptr %l421, ptr %t823, i64 136, i1 false)
  br label %bb169
bb168:
  br label %bb171
bb169:
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %l421, i64 136, i1 false)
  %t826 = load i64, ptr %l53, !tbaa !24
  %t828 = getelementptr %"compiler/eval:scope", ptr %l56, i32 0, i32 15
  store i64 %t826, ptr %t828, !tbaa !24
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t831 = getelementptr %"compiler/eval:Machine", ptr %t829, i32 0, i32 43
  %t832 = load i64, ptr %l55, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l426, ptr %l56, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t835, ptr %l426, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t831, i64 %t832, ptr %t835)
  br label %bb170
bb170:
  br label %bb171
bb171:
  %t836 = load ptr, ptr %l0, !tbaa !29
  %t837 = load %"compiler/eval:Ptr", ptr %l5
  %t838 = load i64, ptr %l54, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t836, %"compiler/eval:Ptr" %t837, i64 8, i64 %t838)
  br label %bb172
bb172:
  br label %bb185
bb173:
  %t842 = load { i64, [15 x i64] }, ptr %l3
  %t844 = extractvalue { i64, [15 x i64] } %t842, 0
  %t845 = icmp eq i64 %t844, 14
  br i1 %t845, label %bb174, label %bb175
bb174:
  %t847 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t848 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t847, i32 0, i32 0
  %t849 = load { i64, [4 x i64] }, ptr %t848
  store { i64, [4 x i64] } %t849, ptr %l57
  %t851 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t852 = getelementptr { { i64, [4 x i64] }, { i64, [1 x i64] } }, ptr %t851, i32 0, i32 1
  %t853 = load { i64, [1 x i64] }, ptr %t852
  store { i64, [1 x i64] } %t853, ptr %l58
  br label %bb176
bb175:
  br label %bb184
bb176:
  %t855 = load ptr, ptr %l0, !tbaa !29
  store ptr %t855, ptr %l434, !tbaa !29
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t857 = load i64, ptr %l1, !tbaa !24
  %t858 = load { i64, [4 x i64] }, ptr %l57
  %t862 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eobjectOf(ptr %v0, ptr %t856, i64 %t857, { i64, [4 x i64] } %t858)
  store %"compiler/eval:Ptr" %t862, ptr %l438
  br label %bb177
bb177:
  %t863 = load ptr, ptr %l434, !tbaa !29
  %t864 = load %"compiler/eval:Ptr", ptr %l438
  %t865 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eregionOfObject(ptr %v0, ptr %t863, %"compiler/eval:Ptr" %t864)
  store i64 %t865, ptr %l439
  br label %bb178
bb178:
  %t866 = load i64, ptr %l439, !tbaa !24
  store i64 %t866, ptr %l59, !tbaa !24
  %t867 = load i64, ptr %l59, !tbaa !24
  %t869 = icmp eq i64 %t867, 0
  br i1 %t869, label %bb179, label %bb180
bb179:
  %t871 = load ptr, ptr %l0, !tbaa !29
  %t872 = load i64, ptr %l1, !tbaa !24
  %t873 = load { i64, [1 x i64] }, ptr %l58
  %t877 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t871, i64 %t872, { i64, [1 x i64] } %t873)
  store i64 %t877, ptr %l445
  br label %bb181
bb180:
  br label %bb182
bb181:
  %t878 = load i64, ptr %l445, !tbaa !24
  store i64 %t878, ptr %l59, !tbaa !24
  br label %bb182
bb182:
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t880 = load %"compiler/eval:Ptr", ptr %l5
  %t881 = load i64, ptr %l59, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t879, %"compiler/eval:Ptr" %t880, i64 8, i64 %t881)
  br label %bb183
bb183:
  br label %bb185
bb184:
  call void @__olang_check_failed(ptr @olang_loc_140721f2aee0298e_beee5014d741f7d2)
  unreachable
bb185:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/eval:Machine", ptr %t2, i32 0, i32 17
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  store { i64, ptr } %t5, ptr %l5, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr %"compiler/eval:cfn", ptr %t9, i64 %a1
  %t11 = getelementptr %"compiler/eval:cfn", ptr %t10, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 69
  store i64 %t12, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 70
  store %"compiler/source:Span" %a2, ptr %t20
  br label %ret
ret:
  ret void
}

define dso_local { i32, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallIndex(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Call" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/mir:Call"
  %l3 = alloca { i64, [8 x i64] }
  %l4 = alloca i32
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/mir:Call" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 17
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 49
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i64 %t9
  %t14 = getelementptr %"compiler/eval:frame", ptr %t13, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr %"compiler/eval:cfn", ptr %t18, i64 %t15
  %t20 = getelementptr %"compiler/eval:cfn", ptr %t19, i32 0, i32 9
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l11, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/eval:Machine", ptr %t22, i32 0, i32 49
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr %"compiler/eval:frame", ptr %t29, i64 %t26
  %t31 = getelementptr %"compiler/eval:frame", ptr %t30, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, [8 x i64] }, ptr %t35, i64 %t32
  %t37 = load { i64, [8 x i64] }, ptr %t36
  store { i64, [8 x i64] } %t37, ptr %l3
  %t39 = load { i64, [8 x i64] }, ptr %l3
  %t41 = extractvalue { i64, [8 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 4
  br i1 %t42, label %bb1, label %bb2
bb1:
  %t44 = getelementptr { i64, [8 x i64] }, ptr %l3, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32 }, ptr %t44, i32 0, i32 1
  %t46 = load i32, ptr %t45
  store i32 %t46, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t48 = load i32, ptr %l4, !tbaa !23
  %t50 = sext i32 %t48 to i64
  %t52 = insertvalue { i32, i64 } zeroinitializer, i64 %t50, 1
  store { i32, i64 } %t52, ptr %rv
  br label %ret
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t54 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t54, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_40e1a1a182bd943_2fb0eb1e2dc82487)
  unreachable
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecanonBits(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l2, !tbaa !24
  store i64 %t20, ptr %l14, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l17
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t26 = load i64, ptr %l17, !tbaa !24
  %t27 = call i64 @compiler_2feval_2ebmask(i64 %t26)
  store i64 %t27, ptr %l18
  br label %bb8
bb8:
  %t28 = load i64, ptr %l14, !tbaa !24
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = and i64 %t28, %t29
  store i64 %t30, ptr %rv
  br label %ret
bb9:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t36 = icmp eq i64 %t32, %t33
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load i64, ptr %l2, !tbaa !24
  store i64 %t40, ptr %l24, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l25, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t42, i32 %t43)
  store i64 %t46, ptr %l28
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i64, ptr %l28, !tbaa !24
  %t49 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t47, i64 %t48)
  store i64 %t49, ptr %l29
  br label %bb14
bb14:
  %t50 = load i64, ptr %l24, !tbaa !24
  %t51 = load i64, ptr %l29, !tbaa !24
  %t52 = and i64 %t50, %t51
  store i64 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2edecode(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/mir:BasicBlock"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/mir:BasicBlock"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, [21 x i64] }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/eval:cfn"
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca %"compiler/mir:BasicBlock"
  %l56 = alloca i64
  %l58 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l69 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i32
  %l86 = alloca i64
  %l87 = alloca %"compiler/source:Span"
  %l92 = alloca i64
  %l96 = alloca i64
  %l100 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i64
  %l131 = alloca %"compiler/mir:BasicBlock"
  %l132 = alloca { i64, ptr }
  %l136 = alloca i64
  %l138 = alloca i64
  %l143 = alloca { i64, [21 x i64] }
  %l144 = alloca { i64, ptr }
  %l146 = alloca { i64, [21 x i64] }
  %l147 = alloca { i64, ptr }
  %l148 = alloca i64
  %l151 = alloca i1
  %l152 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l169 = alloca i64
  %l172 = alloca i1
  %l175 = alloca { i64, ptr }
  %l180 = alloca i64
  %l185 = alloca i64
  %l189 = alloca i64
  %l192 = alloca i64
  %l210 = alloca { i64, ptr }
  %l211 = alloca i64
  %l212 = alloca ptr
  %l214 = alloca ptr
  %l218 = alloca i32
  %l220 = alloca %"compiler/mir:Local"
  %l222 = alloca i1
  %l223 = alloca i1
  %l224 = alloca ptr
  %l225 = alloca ptr
  %l229 = alloca i32
  %l230 = alloca i1
  %l233 = alloca %"compiler/eval:cfn"
  %s7 = alloca %olang.scope
  %t1 = alloca %"compiler/eval:cfn", align 8
  %t162 = alloca i64
  %t187 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2feval_3acfn_2ector(ptr %t1, ptr %v2)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t1, i64 264, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 264, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l25, i64 264, i1 false)
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = load ptr, ptr %lp2
  %t10 = getelementptr %"compiler/eval:cfn", ptr %t9, i32 0, i32 0
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/mir:Fn", ptr %t11, i32 0, i32 7
  %t15 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eToArray_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %v2, ptr %t13)
  store { i64, ptr } %t15, ptr %l30
  br label %bb2
bb2:
  %t16 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t17 = load ptr, ptr %lp2
  %t18 = getelementptr %"compiler/eval:cfn", ptr %t17, i32 0, i32 1
  store { i64, ptr } %t16, ptr %t18, !tbaa !27
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/mir:Fn", ptr %t19, i32 0, i32 8
  %t23 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eToArra_H6fd2d5f022de1d6918789edb46830007(ptr %v1, ptr %v2, ptr %t21)
  store { i64, ptr } %t23, ptr %l33
  br label %bb3
bb3:
  %t24 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t25 = load ptr, ptr %lp2
  %t26 = getelementptr %"compiler/eval:cfn", ptr %t25, i32 0, i32 2
  store { i64, ptr } %t24, ptr %t26, !tbaa !27
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/mir:Fn", ptr %t27, i32 0, i32 10
  %t31 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eToArray_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %v2, ptr %t29)
  store { i64, ptr } %t31, ptr %l36
  br label %bb4
bb4:
  %t32 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t33 = load ptr, ptr %lp2
  %t34 = getelementptr %"compiler/eval:cfn", ptr %t33, i32 0, i32 3
  store { i64, ptr } %t32, ptr %t34, !tbaa !27
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/mir:Fn", ptr %t35, i32 0, i32 11
  %t39 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eToArray_3ccompiler_2fmir_3aOperand_3e(ptr %v1, ptr %v2, ptr %t37)
  store { i64, ptr } %t39, ptr %l39
  br label %bb5
bb5:
  %t40 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t41 = load ptr, ptr %lp2
  %t42 = getelementptr %"compiler/eval:cfn", ptr %t41, i32 0, i32 4
  store { i64, ptr } %t40, ptr %t42, !tbaa !27
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/mir:Fn", ptr %t43, i32 0, i32 14
  %t47 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eToArray_3ccompiler_2fmir_3aCall_3e(ptr %v1, ptr %v2, ptr %t45)
  store { i64, ptr } %t47, ptr %l42
  br label %bb6
bb6:
  %t48 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t49 = load ptr, ptr %lp2
  %t50 = getelementptr %"compiler/eval:cfn", ptr %t49, i32 0, i32 5
  store { i64, ptr } %t48, ptr %t50, !tbaa !27
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/mir:Fn", ptr %t51, i32 0, i32 15
  %t55 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eToArray_3ccompiler_2fmir_3aCase_3e(ptr %v1, ptr %v2, ptr %t53)
  store { i64, ptr } %t55, ptr %l45
  br label %bb7
bb7:
  %t56 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t57 = load ptr, ptr %lp2
  %t58 = getelementptr %"compiler/eval:cfn", ptr %t57, i32 0, i32 6
  store { i64, ptr } %t56, ptr %t58, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/mir:Fn", ptr %t59, i32 0, i32 9
  store ptr %t61, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l48, !tbaa !24
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v1, ptr %t64)
  store i64 %t66, ptr %l50
  br label %bb9
bb9:
  %t67 = load i64, ptr %l48, !tbaa !24
  %t68 = load i64, ptr %l50, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v1, ptr %v1, ptr %t73, i64 %t74)
  store %"compiler/mir:BasicBlock" %t77, ptr %l55
  br label %bb13
bb13:
  %t78 = load %"compiler/mir:BasicBlock", ptr %l55
  store %"compiler/mir:BasicBlock" %t78, ptr %l6
  %t79 = load i64, ptr %l3, !tbaa !24
  store i64 %t79, ptr %l56, !tbaa !24
  %t80 = getelementptr %"compiler/mir:BasicBlock", ptr %l6, i32 0, i32 0
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v1, ptr %t80)
  store i64 %t82, ptr %l58
  br label %bb14
bb14:
  %t83 = load i64, ptr %l56, !tbaa !24
  %t84 = load i64, ptr %l58, !tbaa !24
  %t85 = add i64 %t83, %t84
  store i64 %t85, ptr %l3, !tbaa !24
  br label %bb15
bb15:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb8
bb16:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/mir:Fn", ptr %t91, i32 0, i32 9
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v1, ptr %t93)
  store i64 %t95, ptr %l64
  br label %bb17
bb17:
  %t96 = load i64, ptr %l64, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  store i64 %t97, ptr %l65, !tbaa !24
  %t98 = load i64, ptr %l65, !tbaa !24
  %t99 = icmp sge i64 %t98, 0
  br i1 %t99, label %bb18, label %bb19
bb18:
  %t101 = load i64, ptr %l65, !tbaa !24
  %t102 = icmp sle i64 %t101, 52405522936674862
  br i1 %t102, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_241753625ba0fed0_6f3de102ac38e444)
  unreachable
bb20:
  %t104 = load i64, ptr %l65, !tbaa !24
  %t105 = mul i64 %t104, 176
  %t106 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t110 = load ptr, ptr %lp2
  %t111 = getelementptr %"compiler/eval:cfn", ptr %t110, i32 0, i32 7
  store { i64, ptr } %t108, ptr %t111, !tbaa !27
  %t112 = load i64, ptr %l3, !tbaa !24
  store i64 %t112, ptr %l69, !tbaa !24
  %t113 = load i64, ptr %l69, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  br i1 %t114, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_241753625ba0fed0_6f3de102ac38e444)
  unreachable
bb22:
  %t116 = load i64, ptr %l69, !tbaa !24
  %t117 = mul i64 %t116, 1
  %t118 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t117)
  %t119 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t122 = load ptr, ptr %lp2
  %t123 = getelementptr %"compiler/eval:cfn", ptr %t122, i32 0, i32 10
  store { i64, ptr } %t120, ptr %t123, !tbaa !27
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr %"compiler/mir:Fn", ptr %t124, i32 0, i32 6
  %t128 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v1, ptr %t126)
  store i64 %t128, ptr %l74
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_dff38e562927abfd_2c5e94ab37a21251)
  unreachable
bb24:
  %t129 = load i64, ptr %l74, !tbaa !24
  %t130 = load ptr, ptr %lp2
  %t131 = getelementptr %"compiler/eval:cfn", ptr %t130, i32 0, i32 15
  store i64 %t129, ptr %t131, !tbaa !24
  %t132 = load i64, ptr %l3, !tbaa !24
  %t133 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t136 = mul i64 %t132, %t133
  store i64 %t136, ptr %l77, !tbaa !24
  %t137 = load i64, ptr %l77, !tbaa !24
  %t138 = icmp sge i64 %t137, 0
  br i1 %t138, label %bb25, label %bb26
bb25:
  %t140 = load i64, ptr %l77, !tbaa !24
  %t141 = icmp sle i64 %t140, 1152921504606846975
  br i1 %t141, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f974da260d2147be_261330901ffea532)
  unreachable
bb27:
  %t143 = load i64, ptr %l77, !tbaa !24
  %t144 = mul i64 %t143, 8
  %t145 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t144)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t149 = load ptr, ptr %lp2
  %t150 = getelementptr %"compiler/eval:cfn", ptr %t149, i32 0, i32 13
  store { i64, ptr } %t147, ptr %t150, !tbaa !27
  %t151 = load i64, ptr %l3, !tbaa !24
  store i64 %t151, ptr %l81, !tbaa !24
  store i32 3, ptr %l82
  %t152 = load i64, ptr %l81, !tbaa !24
  %t153 = icmp sge i64 %t152, 0
  br i1 %t153, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_f974da260d2147be_261330901ffea532)
  unreachable
bb29:
  %t155 = load i64, ptr %l81, !tbaa !24
  %t156 = icmp sle i64 %t155, 2305843009213693951
  br i1 %t156, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_d12e80ad37c716f3_175b69241b7dc127)
  unreachable
bb31:
  %t158 = load i64, ptr %l81, !tbaa !24
  %t159 = mul i64 %t158, 4
  %t160 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t159)
  %t161 = load i32, ptr %l82
  store i64 0, ptr %t162
  br label %fill.163
fill.163:
  %t166 = load i64, ptr %t162
  %t167 = icmp slt i64 %t166, %t158
  br i1 %t167, label %fillb.164, label %filld.165
fillb.164:
  %t168 = getelementptr i32, ptr %t160, i64 %t166
  store i32 %t161, ptr %t168
  %t169 = add i64 %t166, 1
  store i64 %t169, ptr %t162
  br label %fill.163
filld.165:
  %t170 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t160, 1
  %t173 = load ptr, ptr %lp2
  %t174 = getelementptr %"compiler/eval:cfn", ptr %t173, i32 0, i32 14
  store { i64, ptr } %t171, ptr %t174, !tbaa !27
  %t175 = load i64, ptr %l3, !tbaa !24
  store i64 %t175, ptr %l86, !tbaa !24
  %t176 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t176, ptr %l87
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_d12e80ad37c716f3_175b69241b7dc127)
  unreachable
bb33:
  %t177 = load i64, ptr %l86, !tbaa !24
  %t178 = icmp sge i64 %t177, 0
  br i1 %t178, label %bb34, label %bb35
bb34:
  %t180 = load i64, ptr %l86, !tbaa !24
  %t181 = icmp sle i64 %t180, 1152921504606846975
  br i1 %t181, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_b7a31071d3fea69c_48dc013a177eb8)
  unreachable
bb36:
  %t183 = load i64, ptr %l86, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t184)
  %t186 = load %"compiler/source:Span", ptr %l87
  store i64 0, ptr %t187
  br label %fill.188
fill.188:
  %t191 = load i64, ptr %t187
  %t192 = icmp slt i64 %t191, %t183
  br i1 %t192, label %fillb.189, label %filld.190
fillb.189:
  %t193 = getelementptr %"compiler/source:Span", ptr %t185, i64 %t191
  store %"compiler/source:Span" %t186, ptr %t193
  %t194 = add i64 %t191, 1
  store i64 %t194, ptr %t187
  br label %fill.188
filld.190:
  %t195 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t185, 1
  %t198 = load ptr, ptr %lp2
  %t199 = getelementptr %"compiler/eval:cfn", ptr %t198, i32 0, i32 18
  store { i64, ptr } %t196, ptr %t199, !tbaa !27
  %t200 = load i64, ptr %l7, !tbaa !24
  %t202 = add i64 %t200, 1
  store i64 %t202, ptr %l92, !tbaa !24
  %t203 = load i64, ptr %l92, !tbaa !24
  %t204 = icmp sge i64 %t203, 0
  br i1 %t204, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_b7a31071d3fea69c_48dc013a177eb8)
  unreachable
bb38:
  %t206 = load i64, ptr %l92, !tbaa !24
  %t207 = icmp sle i64 %t206, 1152921504606846975
  br i1 %t207, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3b5c2c57d838d869_14cf45850b137925)
  unreachable
bb40:
  %t209 = load i64, ptr %l92, !tbaa !24
  %t210 = mul i64 %t209, 8
  %t211 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t210)
  %t212 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  %t215 = load ptr, ptr %lp2
  %t216 = getelementptr %"compiler/eval:cfn", ptr %t215, i32 0, i32 8
  store { i64, ptr } %t213, ptr %t216, !tbaa !27
  %t217 = load i64, ptr %l7, !tbaa !24
  store i64 %t217, ptr %l96, !tbaa !24
  %t218 = load i64, ptr %l96, !tbaa !24
  %t219 = icmp sge i64 %t218, 0
  br i1 %t219, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_3b5c2c57d838d869_14cf45850b137925)
  unreachable
bb42:
  %t221 = load i64, ptr %l96, !tbaa !24
  %t222 = icmp sle i64 %t221, 128102389400760775
  br i1 %t222, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_8cc95a5d9353ea2a_915fe4a94e905706)
  unreachable
bb44:
  %t224 = load i64, ptr %l96, !tbaa !24
  %t225 = mul i64 %t224, 72
  %t226 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t225)
  %t227 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t230 = load ptr, ptr %lp2
  %t231 = getelementptr %"compiler/eval:cfn", ptr %t230, i32 0, i32 9
  store { i64, ptr } %t228, ptr %t231, !tbaa !27
  %t232 = load i64, ptr %l7, !tbaa !24
  store i64 %t232, ptr %l100, !tbaa !24
  %t233 = load i64, ptr %l100, !tbaa !24
  %t234 = icmp sge i64 %t233, 0
  br i1 %t234, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_8cc95a5d9353ea2a_915fe4a94e905706)
  unreachable
bb46:
  %t236 = load i64, ptr %l100, !tbaa !24
  %t237 = mul i64 %t236, 1
  %t238 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t237)
  %t239 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t242 = load ptr, ptr %lp2
  %t243 = getelementptr %"compiler/eval:cfn", ptr %t242, i32 0, i32 11
  store { i64, ptr } %t240, ptr %t243, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t244 = load i64, ptr %l7, !tbaa !24
  store i64 %t244, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t246 = load i64, ptr %l10, !tbaa !24
  %t247 = load i64, ptr %l9, !tbaa !24
  %t250 = icmp sgt i64 %t246, %t247
  br i1 %t250, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_82df08a25f1b1bff_dd8fde79650f209b)
  unreachable
bb48:
  %t252 = load i64, ptr %l11, !tbaa !24
  %t254 = icmp sgt i64 %t252, 0
  br i1 %t254, label %bb50, label %bb51
bb49:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb53
bb50:
  %t256 = load i64, ptr %l10, !tbaa !24
  %t257 = load i64, ptr %l9, !tbaa !24
  %t260 = sub i64 %t256, %t257
  %t261 = load i64, ptr %l11, !tbaa !24
  %t264 = add i64 %t260, %t261
  %t266 = sub i64 %t264, 1
  %t267 = load i64, ptr %l11, !tbaa !24
  %t270 = sdiv i64 %t266, %t267
  store i64 %t270, ptr %l110, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb52
bb52:
  %t272 = load i64, ptr %l110, !tbaa !24
  store i64 %t272, ptr %l107, !tbaa !24
  br label %bb53
bb53:
  %t273 = load i64, ptr %l107, !tbaa !24
  store i64 %t273, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb54
bb54:
  %t274 = load i64, ptr %l13, !tbaa !24
  %t275 = load i64, ptr %l12, !tbaa !24
  %t278 = icmp slt i64 %t274, %t275
  %t280 = xor i1 %t278, true
  br i1 %t280, label %bb55, label %bb56
bb55:
  br label %bb74
bb56:
  br label %bb57
bb57:
  %t282 = load i64, ptr %l9, !tbaa !24
  %t283 = load i64, ptr %l13, !tbaa !24
  %t284 = load i64, ptr %l11, !tbaa !24
  %t287 = mul i64 %t283, %t284
  %t290 = add i64 %t282, %t287
  store i64 %t290, ptr %l14, !tbaa !24
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr %"compiler/mir:Fn", ptr %t292, i32 0, i32 9
  %t295 = load i64, ptr %l14, !tbaa !24
  %t298 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v1, ptr %v1, ptr %t294, i64 %t295)
  store %"compiler/mir:BasicBlock" %t298, ptr %l131
  br label %bb58
bb58:
  %t299 = load %"compiler/mir:BasicBlock", ptr %l131
  store %"compiler/mir:BasicBlock" %t299, ptr %l15
  %t300 = load ptr, ptr %lp2
  %t301 = getelementptr %"compiler/eval:cfn", ptr %t300, i32 0, i32 8
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  store { i64, ptr } %t302, ptr %l132, !tbaa !27
  %t303 = load i64, ptr %l14, !tbaa !24
  %t304 = load i64, ptr %l8, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i64, ptr %t308, i64 %t303
  store i64 %t304, ptr %t309, !tbaa !34
  %t310 = getelementptr %"compiler/mir:BasicBlock", ptr %l15, i32 0, i32 0
  store ptr %t310, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s7
  %t312 = load i64, ptr %l17, !tbaa !24
  store i64 %t312, ptr %l136, !tbaa !24
  %t313 = load ptr, ptr %l16, !tbaa !29
  %t315 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v1, ptr %t313)
  store i64 %t315, ptr %l138
  br label %bb60
bb60:
  %t316 = load i64, ptr %l136, !tbaa !24
  %t317 = load i64, ptr %l138, !tbaa !24
  %t318 = icmp slt i64 %t316, %t317
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb62:
  br label %bb63
bb63:
  %t322 = load ptr, ptr %l16, !tbaa !29
  %t323 = load i64, ptr %l17, !tbaa !24
  %t326 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v1, ptr %t322, i64 %t323)
  store { i64, [21 x i64] } %t326, ptr %l143
  br label %bb64
bb64:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l143, i64 176, i1 false)
  %t327 = load ptr, ptr %lp2
  %t328 = getelementptr %"compiler/eval:cfn", ptr %t327, i32 0, i32 7
  %t329 = load { i64, ptr }, ptr %t328, !tbaa !27
  store { i64, ptr } %t329, ptr %l144, !tbaa !27
  %t330 = load i64, ptr %l8, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l146, ptr %l18, i64 176, i1 false)
  %t332 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr { i64, [21 x i64] }, ptr %t333, i64 %t330
  call void @llvm.memmove.p0.p0.i64(ptr %t334, ptr %l146, i64 176, i1 false)
  %t335 = load ptr, ptr %lp2
  %t336 = getelementptr %"compiler/eval:cfn", ptr %t335, i32 0, i32 10
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l147, !tbaa !27
  %t338 = load i64, ptr %l8, !tbaa !24
  store i64 %t338, ptr %l148, !tbaa !24
  %t339 = load ptr, ptr %l1, !tbaa !29
  %t342 = call i1 @compiler_2feval_2estmtNamesGlobal(ptr %v1, ptr %s7, ptr %t339, ptr %l18)
  store i1 %t342, ptr %l151
  br label %bb65
bb65:
  %t343 = load i1, ptr %l151, !tbaa !21
  %t344 = load i64, ptr %l148, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr i1, ptr %t346, i64 %t344
  store i1 %t343, ptr %t347, !tbaa !31
  %t348 = load ptr, ptr %lp2
  %t349 = getelementptr %"compiler/eval:cfn", ptr %t348, i32 0, i32 10
  %t350 = load { i64, ptr }, ptr %t349, !tbaa !27
  store { i64, ptr } %t350, ptr %l152, !tbaa !27
  %t351 = load i64, ptr %l8, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr i1, ptr %t354, i64 %t351
  %t356 = load i1, ptr %t355, !tbaa !31
  %t358 = xor i1 %t356, true
  br i1 %t358, label %bb66, label %bb67
bb66:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t362 = load ptr, ptr %lp2
  %t363 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatten(ptr %v0, ptr %v1, ptr %s7, ptr %v2, ptr %t360, ptr %t361, ptr %l18, ptr %t362, i64 %t363)
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  %t369 = load i64, ptr %l8, !tbaa !24
  %t371 = add i64 %t369, 1
  store i64 %t371, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb70:
  %t373 = load i64, ptr %l17, !tbaa !24
  %t375 = add i64 %t373, 1
  store i64 %t375, ptr %l17, !tbaa !24
  br label %bb59
bb71:
  %t377 = load ptr, ptr %lp2
  %t378 = getelementptr %"compiler/eval:cfn", ptr %t377, i32 0, i32 9
  %t379 = load { i64, ptr }, ptr %t378, !tbaa !27
  store { i64, ptr } %t379, ptr %l165, !tbaa !27
  %t380 = load i64, ptr %l14, !tbaa !24
  %t381 = getelementptr %"compiler/mir:BasicBlock", ptr %l15, i32 0, i32 1
  %t382 = load { i64, [8 x i64] }, ptr %t381
  %t385 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr { i64, [8 x i64] }, ptr %t386, i64 %t380
  store { i64, [8 x i64] } %t382, ptr %t387
  %t388 = load ptr, ptr %lp2
  %t389 = getelementptr %"compiler/eval:cfn", ptr %t388, i32 0, i32 11
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  store { i64, ptr } %t390, ptr %l168, !tbaa !27
  %t391 = load i64, ptr %l14, !tbaa !24
  store i64 %t391, ptr %l169, !tbaa !24
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t393 = getelementptr %"compiler/mir:BasicBlock", ptr %l15, i32 0, i32 1
  %t394 = load { i64, [8 x i64] }, ptr %t393
  %t397 = call i1 @compiler_2feval_2etermNamesGlobal(ptr %v1, ptr %t392, { i64, [8 x i64] } %t394)
  store i1 %t397, ptr %l172
  br label %bb72
bb72:
  %t398 = load i1, ptr %l172, !tbaa !21
  %t399 = load i64, ptr %l169, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr i1, ptr %t401, i64 %t399
  store i1 %t398, ptr %t402, !tbaa !31
  br label %bb73
bb73:
  %t403 = load i64, ptr %l13, !tbaa !24
  %t405 = add i64 %t403, 1
  store i64 %t405, ptr %l13, !tbaa !24
  br label %bb54
bb74:
  %t407 = load ptr, ptr %lp2
  %t408 = getelementptr %"compiler/eval:cfn", ptr %t407, i32 0, i32 8
  %t409 = load { i64, ptr }, ptr %t408, !tbaa !27
  store { i64, ptr } %t409, ptr %l175, !tbaa !27
  %t410 = load i64, ptr %l7, !tbaa !24
  %t411 = load i64, ptr %l8, !tbaa !24
  %t414 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t415 = load ptr, ptr %t414, !tbaa !27
  %t416 = getelementptr i64, ptr %t415, i64 %t410
  store i64 %t411, ptr %t416, !tbaa !34
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr %"compiler/mir:Fn", ptr %t417, i32 0, i32 4
  %t421 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t419)
  store i64 %t421, ptr %l180
  br label %bb75
bb75:
  %t422 = load i64, ptr %l180, !tbaa !24
  %t423 = icmp sge i64 %t422, 0
  br i1 %t423, label %bb76, label %bb77
bb76:
  %t425 = load i64, ptr %l180, !tbaa !24
  %t426 = mul i64 %t425, 1
  %t427 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t426)
  %t428 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t429 = insertvalue { i64, ptr } %t428, ptr %t427, 1
  %t431 = load ptr, ptr %lp2
  %t432 = getelementptr %"compiler/eval:cfn", ptr %t431, i32 0, i32 12
  store { i64, ptr } %t429, ptr %t432, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t435 = getelementptr %"compiler/mir:Fn", ptr %t433, i32 0, i32 4
  %t437 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t435)
  store i64 %t437, ptr %l185
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_1d233abf61feac98_d906727ad02ddbc)
  unreachable
bb78:
  %t438 = load i64, ptr %l185, !tbaa !24
  store i64 %t438, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t439 = load i64, ptr %l20, !tbaa !24
  %t440 = load i64, ptr %l19, !tbaa !24
  %t443 = icmp sgt i64 %t439, %t440
  br i1 %t443, label %bb79, label %bb80
bb79:
  %t445 = load i64, ptr %l21, !tbaa !24
  %t447 = icmp sgt i64 %t445, 0
  br i1 %t447, label %bb81, label %bb82
bb80:
  store i64 0, ptr %l189, !tbaa !24
  br label %bb84
bb81:
  %t449 = load i64, ptr %l20, !tbaa !24
  %t450 = load i64, ptr %l19, !tbaa !24
  %t453 = sub i64 %t449, %t450
  %t454 = load i64, ptr %l21, !tbaa !24
  %t457 = add i64 %t453, %t454
  %t459 = sub i64 %t457, 1
  %t460 = load i64, ptr %l21, !tbaa !24
  %t463 = sdiv i64 %t459, %t460
  store i64 %t463, ptr %l192, !tbaa !24
  br label %bb83
bb82:
  store i64 0, ptr %l192, !tbaa !24
  br label %bb83
bb83:
  %t465 = load i64, ptr %l192, !tbaa !24
  store i64 %t465, ptr %l189, !tbaa !24
  br label %bb84
bb84:
  %t466 = load i64, ptr %l189, !tbaa !24
  store i64 %t466, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb85
bb85:
  %t467 = load i64, ptr %l23, !tbaa !24
  %t468 = load i64, ptr %l22, !tbaa !24
  %t471 = icmp slt i64 %t467, %t468
  %t473 = xor i1 %t471, true
  br i1 %t473, label %bb86, label %bb87
bb86:
  br label %bb98
bb87:
  br label %bb88
bb88:
  %t475 = load i64, ptr %l19, !tbaa !24
  %t476 = load i64, ptr %l23, !tbaa !24
  %t477 = load i64, ptr %l21, !tbaa !24
  %t480 = mul i64 %t476, %t477
  %t483 = add i64 %t475, %t480
  store i64 %t483, ptr %l24, !tbaa !24
  %t485 = load ptr, ptr %lp2
  %t486 = getelementptr %"compiler/eval:cfn", ptr %t485, i32 0, i32 12
  %t487 = load { i64, ptr }, ptr %t486, !tbaa !27
  store { i64, ptr } %t487, ptr %l210, !tbaa !27
  %t488 = load i64, ptr %l24, !tbaa !24
  store i64 %t488, ptr %l211, !tbaa !24
  %t489 = load ptr, ptr %l0, !tbaa !29
  store ptr %t489, ptr %l212, !tbaa !29
  %t490 = load ptr, ptr %l1, !tbaa !29
  %t492 = getelementptr %"compiler/mir:Fn", ptr %t490, i32 0, i32 7
  store ptr %t492, ptr %l214, !tbaa !29
  %t493 = load ptr, ptr %l1, !tbaa !29
  %t495 = getelementptr %"compiler/mir:Fn", ptr %t493, i32 0, i32 4
  %t496 = load i64, ptr %l24, !tbaa !24
  %t499 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t495, i64 %t496)
  store i32 %t499, ptr %l218
  br label %bb89
bb89:
  %t500 = load i32, ptr %l218, !tbaa !23
  %t501 = sext i32 %t500 to i64
  %t502 = load ptr, ptr %l214, !tbaa !29
  %t504 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t502, i64 %t501)
  store %"compiler/mir:Local" %t504, ptr %l220
  br label %bb90
bb90:
  %t505 = getelementptr %"compiler/mir:Local", ptr %l220, i32 0, i32 2
  %t506 = load i32, ptr %t505, !tbaa !23
  %t507 = load ptr, ptr %l212, !tbaa !29
  %t509 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ertArrayValue(ptr %v0, ptr %t507, i32 %t506)
  store i1 %t509, ptr %l222
  br label %bb91
bb91:
  %t510 = load i1, ptr %l222, !tbaa !21
  br i1 %t510, label %bb92, label %bb93
bb92:
  %t511 = load ptr, ptr %l0, !tbaa !29
  store ptr %t511, ptr %l224, !tbaa !29
  %t512 = load ptr, ptr %l1, !tbaa !29
  store ptr %t512, ptr %l225, !tbaa !29
  %t513 = load ptr, ptr %l1, !tbaa !29
  %t515 = getelementptr %"compiler/mir:Fn", ptr %t513, i32 0, i32 4
  %t516 = load i64, ptr %l24, !tbaa !24
  %t519 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t515, i64 %t516)
  store i32 %t519, ptr %l229
  br label %bb94
bb93:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb96
bb94:
  %t520 = load ptr, ptr %l224, !tbaa !29
  %t521 = load ptr, ptr %l225, !tbaa !29
  %t522 = load i32, ptr %l229, !tbaa !23
  %t523 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewritesInto(ptr %v0, ptr %v1, ptr %t520, ptr %t521, i32 %t522)
  store i1 %t523, ptr %l230
  br label %bb95
bb95:
  %t524 = load i1, ptr %l230, !tbaa !21
  store i1 %t524, ptr %l223, !tbaa !21
  br label %bb96
bb96:
  %t525 = load i1, ptr %l223, !tbaa !21
  %t526 = load i64, ptr %l211, !tbaa !24
  %t527 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = getelementptr i1, ptr %t528, i64 %t526
  store i1 %t525, ptr %t529, !tbaa !31
  br label %bb97
bb97:
  %t530 = load i64, ptr %l23, !tbaa !24
  %t532 = add i64 %t530, 1
  store i64 %t532, ptr %l23, !tbaa !24
  br label %bb85
bb98:
  %t534 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l233, ptr %t534, i64 264, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l233, i64 264, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2edeliver(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/eval:frame"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/mir:Call"
  %l8 = alloca { %"compiler/eval:Ptr", i32 }
  %l12 = alloca %"compiler/eval:Ptr"
  %l15 = alloca %"compiler/eval:global"
  %l17 = alloca { i64, ptr }
  %l25 = alloca i32
  %l34 = alloca %"compiler/mir:Fn"
  %l37 = alloca %"compiler/mir:Call"
  %l42 = alloca { %"compiler/eval:Ptr", i32 }
  %l55 = alloca i64
  %l61 = alloca %"compiler/eval:Ptr"
  %l79 = alloca %"compiler/eval:global"
  %l80 = alloca ptr
  %l81 = alloca i64
  %l83 = alloca %"compiler/eval:Ptr"
  %s5 = alloca %olang.scope
  %t40 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 49
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l17, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  %t10 = load %"compiler/eval:frame", ptr %t9
  store %"compiler/eval:frame" %t10, ptr %l3
  %t12 = load { i64, [4 x i64] }, ptr %l2
  %t14 = extractvalue { i64, [4 x i64] } %t12, 0
  %t15 = icmp eq i64 %t14, 0
  br i1 %t15, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t19 = load { i64, [4 x i64] }, ptr %l2
  %t23 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t17, i64 %t18, { i64, [4 x i64] } %t19)
  store i32 %t23, ptr %l25
  br label %bb4
bb4:
  %t24 = load i32, ptr %l25, !tbaa !23
  store i32 %t24, ptr %l4, !tbaa !23
  %t25 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 7
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2feval_2erCall, !tbaa !24
  %t32 = icmp eq i64 %t28, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb15
bb7:
  %t34 = load i64, ptr %l1, !tbaa !24
  %t36 = sub i64 %t34, 1
  store i64 %t36, ptr %l6, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %t40, ptr %v0, ptr %v0, ptr %t38, i64 %t39)
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %t40, i64 248, i1 false)
  br label %bb8
bb8:
  %t43 = getelementptr %"compiler/mir:Fn", ptr %l34, i32 0, i32 14
  %t44 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 8
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t43, i64 %t45)
  store %"compiler/mir:Call" %t48, ptr %l37
  br label %bb9
bb9:
  %t49 = load %"compiler/mir:Call", ptr %l37
  store %"compiler/mir:Call" %t49, ptr %l7
  %t50 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 4
  %t51 = load i1, ptr %t50, !tbaa !21
  br i1 %t51, label %bb10, label %bb11
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = getelementptr %"compiler/mir:Call", ptr %l7, i32 0, i32 3
  %t56 = load %"compiler/mir:Lvalue", ptr %t55
  %t60 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t53, i64 %t54, %"compiler/mir:Lvalue" %t56)
  store { %"compiler/eval:Ptr", i32 } %t60, ptr %l42
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t61 = load { %"compiler/eval:Ptr", i32 }, ptr %l42
  store { %"compiler/eval:Ptr", i32 } %t61, ptr %l8
  %t62 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l8, i32 0, i32 0
  %t63 = load %"compiler/eval:Ptr", ptr %t62
  %t65 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l8, i32 0, i32 1
  %t66 = load i32, ptr %t65, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  %t72 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t68, i64 %t69, %"compiler/eval:Ptr" %t63, i32 %t66, { i64, [4 x i64] } %t72)
  br label %bb13
bb13:
  br label %bb14
bb14:
  br label %bb41
bb15:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t79 = load i64, ptr @G_2ecompiler_2feval_2erRequest, !tbaa !24
  %t82 = icmp eq i64 %t78, %t79
  br i1 %t82, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t84, i32 %t85)
  store i64 %t88, ptr %l55
  br label %bb19
bb19:
  %t89 = load i64, ptr %l55, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/eval:Machine", ptr %t93, i32 0, i32 61
  %t96 = load i64, ptr %t95, !tbaa !24
  %t101 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t90, i64 %t89, i64 %t92, i64 %t96)
  store %"compiler/eval:Ptr" %t101, ptr %l61
  br label %bb20
bb20:
  %t102 = load %"compiler/eval:Ptr", ptr %l61
  store %"compiler/eval:Ptr" %t102, ptr %l12
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i64, ptr %l1, !tbaa !24
  %t105 = load %"compiler/eval:Ptr", ptr %l12
  %t106 = load i32, ptr %l4, !tbaa !23
  %t107 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t103, i64 %t104, %"compiler/eval:Ptr" %t105, i32 %t106, { i64, [4 x i64] } %t107)
  br label %bb21
bb21:
  %t113 = load %"compiler/eval:Ptr", ptr %l12
  %t115 = load i32, ptr %l4, !tbaa !23
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/eval:Machine", ptr %t117, i32 0, i32 10
  store %"compiler/eval:Ptr" %t113, ptr %t121
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/eval:Machine", ptr %t122, i32 0, i32 11
  store i32 %t115, ptr %t126, !tbaa !23
  br label %bb41
bb22:
  %t127 = load i64, ptr %l5, !tbaa !24
  %t128 = load i64, ptr @G_2ecompiler_2feval_2erGlobal, !tbaa !24
  %t131 = icmp eq i64 %t127, %t128
  br i1 %t131, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb29
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 33
  %t136 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 8
  %t137 = load i64, ptr %t136, !tbaa !24
  %t140 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t135, i64 %t137)
  store %"compiler/eval:global" %t140, ptr %l79
  br label %bb26
bb26:
  %t141 = load %"compiler/eval:global", ptr %l79
  store %"compiler/eval:global" %t141, ptr %l15
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l80, !tbaa !29
  %t143 = load i64, ptr %l1, !tbaa !24
  store i64 %t143, ptr %l81, !tbaa !24
  %t144 = getelementptr %"compiler/eval:global", ptr %l15, i32 0, i32 3
  %t145 = load i64, ptr %t144, !tbaa !24
  %t147 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t145, i64 0)
  store %"compiler/eval:Ptr" %t147, ptr %l83
  br label %bb27
bb27:
  %t148 = getelementptr %"compiler/eval:global", ptr %l15, i32 0, i32 0
  %t149 = load i64, ptr %t148, !tbaa !24
  %t151 = trunc i64 %t149 to i32
  %t153 = load { i64, [4 x i64] }, ptr %l2
  %t154 = load ptr, ptr %l80, !tbaa !29
  %t155 = load i64, ptr %l81, !tbaa !24
  %t156 = load %"compiler/eval:Ptr", ptr %l83
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t154, i64 %t155, %"compiler/eval:Ptr" %t156, i32 %t151, { i64, [4 x i64] } %t153)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb29:
  %t159 = load i64, ptr %l5, !tbaa !24
  %t160 = load i64, ptr @G_2ecompiler_2feval_2erTask, !tbaa !24
  %t163 = icmp eq i64 %t159, %t160
  br i1 %t163, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  %t165 = load i64, ptr %l5, !tbaa !24
  %t166 = load i64, ptr @G_2ecompiler_2feval_2erClause, !tbaa !24
  %t169 = icmp eq i64 %t165, %t166
  br i1 %t169, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i64, ptr %l1, !tbaa !24
  %t173 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 8
  %t174 = load i64, ptr %t173, !tbaa !24
  %t175 = load { i64, [4 x i64] }, ptr %l2
  %t176 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2etoTargets(ptr %v0, ptr %t171, i64 %t172, i64 %t174, { i64, [4 x i64] } %t175, i32 %t176)
  br label %bb35
bb35:
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_17d12c125f58d820_35ade4b878109a14)
  unreachable
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2edisown(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/eval:scope"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/eval:scope"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/eval:scope"
  %l22 = alloca %"compiler/eval:scope"
  %l26 = alloca i1
  %l29 = alloca i1
  %l37 = alloca %"compiler/eval:scope"
  %l45 = alloca %"compiler/eval:scope"
  %l50 = alloca %"compiler/eval:scope"
  %l55 = alloca %"compiler/eval:scope"
  %l59 = alloca %"compiler/eval:scope"
  %l69 = alloca %"compiler/eval:scope"
  %l80 = alloca %"compiler/eval:scope"
  %l85 = alloca %"compiler/eval:scope"
  %l90 = alloca %"compiler/eval:scope"
  %l96 = alloca %"compiler/eval:scope"
  %l101 = alloca %"compiler/eval:scope"
  %t11 = alloca %"compiler/eval:scope", align 8
  %t40 = alloca %"compiler/eval:scope", align 8
  %t56 = alloca %"compiler/eval:scope", align 8
  %t63 = alloca %"compiler/eval:scope", align 8
  %t73 = alloca %"compiler/eval:scope", align 8
  %t85 = alloca %"compiler/eval:scope", align 8
  %t103 = alloca %"compiler/eval:scope", align 8
  %t125 = alloca %"compiler/eval:scope", align 8
  %t135 = alloca %"compiler/eval:scope", align 8
  %t147 = alloca %"compiler/eval:scope", align 8
  %t156 = alloca %"compiler/eval:scope", align 8
  %t168 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t5 = and i64 %t1, %t2
  store i64 %t5, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 43
  %t10 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t11, ptr %v0, ptr %t9, i64 %t10)
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t11, i64 136, i1 false)
  br label %bb1
bb1:
  %t14 = getelementptr %"compiler/eval:scope", ptr %l22, i32 0, i32 5
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp eq i64 %t17, 0
  br i1 %t19, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb5
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t21, i64 %t22)
  store i1 %t25, ptr %l29
  br label %bb4
bb4:
  %t26 = load i1, ptr %l29, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l26, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t34 = and i64 %t30, %t31
  store i64 %t34, ptr %l4, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/eval:Machine", ptr %t36, i32 0, i32 43
  %t39 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t40, ptr %v0, ptr %t38, i64 %t39)
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t40, i64 136, i1 false)
  br label %bb9
bb9:
  %t43 = getelementptr %"compiler/eval:scope", ptr %l37, i32 0, i32 6
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = icmp eq i64 %t44, %t45
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load i64, ptr %l4, !tbaa !24
  store i64 %t50, ptr %l5, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/eval:Machine", ptr %t52, i32 0, i32 43
  %t55 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t56, ptr %v0, ptr %t54, i64 %t55)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t56, i64 136, i1 false)
  br label %bb12
bb11:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/eval:Machine", ptr %t59, i32 0, i32 43
  %t62 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t63, ptr %v0, ptr %t61, i64 %t62)
  call void @llvm.memmove.p0.p0.i64(ptr %l59, ptr %t63, i64 136, i1 false)
  br label %bb15
bb12:
  %t66 = getelementptr %"compiler/eval:scope", ptr %l45, i32 0, i32 7
  %t67 = load i64, ptr %t66, !tbaa !24
  store i64 %t67, ptr %l6, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/eval:Machine", ptr %t69, i32 0, i32 43
  %t72 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t73, ptr %v0, ptr %t71, i64 %t72)
  call void @llvm.memmove.p0.p0.i64(ptr %l50, ptr %t73, i64 136, i1 false)
  br label %bb13
bb13:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l50, i64 136, i1 false)
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = getelementptr %"compiler/eval:scope", ptr %l7, i32 0, i32 6
  store i64 %t76, ptr %t78, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/eval:Machine", ptr %t79, i32 0, i32 43
  %t82 = load i64, ptr %l5, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %l7, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t85, ptr %l55, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t81, i64 %t82, ptr %t85)
  br label %bb14
bb14:
  br label %bb29
bb15:
  %t86 = getelementptr %"compiler/eval:scope", ptr %l59, i32 0, i32 6
  %t87 = load i64, ptr %t86, !tbaa !24
  store i64 %t87, ptr %l8, !tbaa !24
  br label %bb16
bb16:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp ne i64 %t89, 0
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb17, label %bb18
bb17:
  br label %bb28
bb18:
  br label %bb19
bb19:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/eval:Machine", ptr %t95, i32 0, i32 43
  %t98 = load i64, ptr %l8, !tbaa !24
  %t99 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t102 = and i64 %t98, %t99
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t103, ptr %v0, ptr %t97, i64 %t102)
  call void @llvm.memmove.p0.p0.i64(ptr %l69, ptr %t103, i64 136, i1 false)
  br label %bb20
bb20:
  %t106 = getelementptr %"compiler/eval:scope", ptr %l69, i32 0, i32 7
  %t107 = load i64, ptr %t106, !tbaa !24
  store i64 %t107, ptr %l9, !tbaa !24
  %t109 = load i64, ptr %l9, !tbaa !24
  %t110 = load i64, ptr %l1, !tbaa !24
  %t113 = icmp eq i64 %t109, %t110
  br i1 %t113, label %bb21, label %bb22
bb21:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t116 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t119 = and i64 %t115, %t116
  store i64 %t119, ptr %l10, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/eval:Machine", ptr %t121, i32 0, i32 43
  %t124 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t125, ptr %v0, ptr %t123, i64 %t124)
  call void @llvm.memmove.p0.p0.i64(ptr %l80, ptr %t125, i64 136, i1 false)
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t128 = getelementptr %"compiler/eval:scope", ptr %l80, i32 0, i32 7
  %t129 = load i64, ptr %t128, !tbaa !24
  store i64 %t129, ptr %l11, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/eval:Machine", ptr %t131, i32 0, i32 43
  %t134 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t135, ptr %v0, ptr %t133, i64 %t134)
  call void @llvm.memmove.p0.p0.i64(ptr %l85, ptr %t135, i64 136, i1 false)
  br label %bb24
bb24:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l85, i64 136, i1 false)
  %t138 = load i64, ptr %l11, !tbaa !24
  %t140 = getelementptr %"compiler/eval:scope", ptr %l12, i32 0, i32 7
  store i64 %t138, ptr %t140, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/eval:Machine", ptr %t141, i32 0, i32 43
  %t144 = load i64, ptr %l10, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l90, ptr %l12, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t147, ptr %l90, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t143, i64 %t144, ptr %t147)
  br label %bb25
bb25:
  br label %bb28
bb26:
  %t148 = load i64, ptr %l9, !tbaa !24
  store i64 %t148, ptr %l8, !tbaa !24
  br label %bb27
bb27:
  br label %bb16
bb28:
  br label %bb29
bb29:
  %t150 = load i64, ptr %l2, !tbaa !24
  store i64 %t150, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/eval:Machine", ptr %t152, i32 0, i32 43
  %t155 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t156, ptr %v0, ptr %t154, i64 %t155)
  call void @llvm.memmove.p0.p0.i64(ptr %l96, ptr %t156, i64 136, i1 false)
  br label %bb30
bb30:
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %l96, i64 136, i1 false)
  %t159 = load i64, ptr %l14, !tbaa !24
  %t161 = getelementptr %"compiler/eval:scope", ptr %l15, i32 0, i32 5
  store i64 %t159, ptr %t161, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/eval:Machine", ptr %t162, i32 0, i32 43
  %t165 = load i64, ptr %l13, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l101, ptr %l15, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t168, ptr %l101, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t164, i64 %t165, ptr %t168)
  br label %bb31
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropOwnDefers(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 57
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t11, i32 0, i32 57
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = sub i64 %t14, 1
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t16)
  store i64 %t19, ptr %l13
  br label %bb5
bb4:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t21 = load i64, ptr %l13, !tbaa !24
  %t23 = icmp sge i64 %t21, %a1
  store i1 %t23, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l8, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = sub i64 %t28, 1
  store i64 %t30, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 57
  %t35 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 58
  %t41 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t40, i64 %t41)
  br label %bb13
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 59
  %t47 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t46, i64 %t47)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eexternCall(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Call" %a2, i64 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/mir:Call"
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/mir:Fn"
  %l8 = alloca %"compiler/eval:Ptr"
  %l9 = alloca { %"compiler/eval:Ptr", i32 }
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l18 = alloca %"compiler/mir:Fn"
  %l20 = alloca i1
  %l25 = alloca { i64, [4 x i64] }
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, [7 x i64] }
  %l30 = alloca %"compiler/mir:Range"
  %l31 = alloca %"compiler/mir:Range"
  %l32 = alloca i64
  %l33 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i32
  %l40 = alloca i1
  %l41 = alloca i64
  %l47 = alloca { %"compiler/eval:Ptr", i32 }
  %l56 = alloca i1
  %s0 = alloca %olang.scope
  %t16 = alloca %"compiler/mir:Fn", align 8
  %t34 = alloca { i64, [7 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/mir:Call" %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 25
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l15
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l14
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t12, ptr %l10, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l10, !tbaa !27
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t13, ptr %l5, !tbaa !27
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %t16, ptr %v0, ptr %v0, ptr %t14, i64 %t15)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t16, i64 248, i1 false)
  br label %bb5
bb5:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l18, i64 248, i1 false)
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t21, ptr %l20
  br label %bb6
bb6:
  %t22 = load i1, ptr %l20, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = getelementptr %"compiler/mir:Fn", ptr %l6, i32 0, i32 11
  %t24 = getelementptr %"compiler/mir:Call", ptr %l2, i32 0, i32 1
  %t25 = getelementptr %"compiler/mir:Range", ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t30 = add i64 %t28, 1
  %t33 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t23, i64 %t30)
  store { i64, [4 x i64] } %t33, ptr %l25
  br label %bb9
bb8:
  br label %bb15
bb9:
  store { i64, [7 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [7 x i64] }, ptr %t34, i32 0, i32 0
  store i64 2, ptr %t35
  %t36 = load { i64, [4 x i64] }, ptr %l25
  %t37 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t36, 0
  %t38 = getelementptr { i64, [7 x i64] }, ptr %t34, i32 0, i32 1
  store { { i64, [4 x i64] } } %t37, ptr %t38
  %t39 = load { i64, [7 x i64] }, ptr %t34
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l27, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  store i64 %t42, ptr %l28, !tbaa !24
  store { i64, [7 x i64] } %t39, ptr %l29
  %t44 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t44, ptr %l30
  %t45 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t45, ptr %l31
  %t46 = load i64, ptr @G_2ecompiler_2feval_2erCall, !tbaa !24
  store i64 %t46, ptr %l32, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l1, !tbaa !24
  %t49 = load %"compiler/mir:Call", ptr %l2
  %t53 = call { i32, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallIndex(ptr %v0, ptr %t47, i64 %t48, %"compiler/mir:Call" %t49)
  %t54 = extractvalue { i32, i64 } %t53, 1
  %t55 = extractvalue { i32, i64 } %t53, 0
  store i32 %t55, ptr %l38
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb11, label %ok.57, !prof !99
ok.57:
  store i64 %t54, ptr %l37
  br label %bb10
bb10:
  %t58 = load i64, ptr %l37, !tbaa !24
  store i64 %t58, ptr %l33, !tbaa !24
  br label %bb13
bb11:
  %t59 = load i32, ptr %l38, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  store i1 %t62, ptr %l40, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l27, !tbaa !29
  %t64 = load i64, ptr %l28, !tbaa !24
  %t65 = load { i64, [7 x i64] }, ptr %l29
  %t66 = load %"compiler/mir:Range", ptr %l30
  %t67 = load %"compiler/mir:Range", ptr %l31
  %t68 = load i64, ptr %l32, !tbaa !24
  %t69 = load i64, ptr %l33, !tbaa !24
  %t70 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eenter(ptr %v0, ptr %t63, i64 %t64, { i64, [7 x i64] } %t65, %"compiler/mir:Range" %t66, %"compiler/mir:Range" %t67, i64 %t68, i64 %t69)
  store i64 %t70, ptr %l41
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t71 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t71, ptr %l8
  %t73 = getelementptr %"compiler/mir:Call", ptr %l2, i32 0, i32 4
  %t74 = load i1, ptr %t73, !tbaa !21
  br i1 %t74, label %bb16, label %bb17
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l1, !tbaa !24
  %t78 = getelementptr %"compiler/mir:Call", ptr %l2, i32 0, i32 3
  %t79 = load %"compiler/mir:Lvalue", ptr %t78
  %t83 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t76, i64 %t77, %"compiler/mir:Lvalue" %t79)
  store { %"compiler/eval:Ptr", i32 } %t83, ptr %l47
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t84 = load { %"compiler/eval:Ptr", i32 }, ptr %l47
  store { %"compiler/eval:Ptr", i32 } %t84, ptr %l9
  %t85 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l9, i32 0, i32 0
  %t86 = load %"compiler/eval:Ptr", ptr %t85
  store %"compiler/eval:Ptr" %t86, ptr %l8
  br label %bb19
bb19:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load i64, ptr %l3, !tbaa !24
  %t92 = getelementptr %"compiler/mir:Call", ptr %l2, i32 0, i32 1
  %t93 = load %"compiler/mir:Range", ptr %t92
  %t94 = load %"compiler/eval:Ptr", ptr %l8
  %t95 = getelementptr %"compiler/mir:Call", ptr %l2, i32 0, i32 4
  %t96 = load i1, ptr %t95, !tbaa !21
  %t104 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallExtern(ptr %v0, ptr %t88, i64 %t89, i64 %t90, i32 %a4, %"compiler/mir:Range" %t93, %"compiler/eval:Ptr" %t94, i1 %t96)
  store i1 %t104, ptr %l56
  br label %bb20
bb20:
  %t105 = load i1, ptr %l56, !tbaa !21
  br i1 %t105, label %bb21, label %bb22
bb21:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l1, !tbaa !24
  %t108 = getelementptr %"compiler/mir:Call", ptr %l2, i32 0, i32 5
  %t109 = load i32, ptr %t108, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %t106, i64 %t107, i32 %t109)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiKind(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load i32, ptr %l2, !tbaa !23
  %t12 = icmp eq i32 %t10, 3
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 0, ptr %l7
  br label %bb54
bb5:
  %t15 = load i32, ptr %l2, !tbaa !23
  %t17 = icmp eq i32 %t15, 4
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i32 1, ptr %l7
  br label %bb54
bb9:
  %t20 = load i32, ptr %l2, !tbaa !23
  %t22 = icmp eq i32 %t20, 5
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i32 2, ptr %l7
  br label %bb54
bb13:
  %t25 = load i32, ptr %l2, !tbaa !23
  %t27 = icmp eq i32 %t25, 7
  br i1 %t27, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i32 4, ptr %l7
  br label %bb54
bb17:
  %t30 = load i32, ptr %l2, !tbaa !23
  %t32 = icmp eq i32 %t30, 8
  br i1 %t32, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i32 5, ptr %l7
  br label %bb54
bb21:
  %t35 = load i32, ptr %l2, !tbaa !23
  %t37 = icmp eq i32 %t35, 9
  br i1 %t37, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i32 6, ptr %l7
  br label %bb54
bb25:
  %t40 = load i32, ptr %l2, !tbaa !23
  %t42 = icmp eq i32 %t40, 10
  br i1 %t42, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i32 7, ptr %l7
  br label %bb54
bb29:
  %t45 = load i32, ptr %l2, !tbaa !23
  %t47 = icmp eq i32 %t45, 11
  br i1 %t47, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i32 8, ptr %l7
  br label %bb54
bb33:
  %t50 = load i32, ptr %l2, !tbaa !23
  %t52 = icmp eq i32 %t50, 12
  br i1 %t52, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i32 9, ptr %l7
  br label %bb54
bb37:
  %t55 = load i32, ptr %l2, !tbaa !23
  %t57 = icmp eq i32 %t55, 13
  br i1 %t57, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store i32 10, ptr %l7
  br label %bb54
bb41:
  %t60 = load i32, ptr %l2, !tbaa !23
  %t62 = icmp eq i32 %t60, 14
  br i1 %t62, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i32 11, ptr %l7
  br label %bb54
bb45:
  %t65 = load i32, ptr %l2, !tbaa !23
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t69 = icmp eq i32 %t65, %t66
  br i1 %t69, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i32 4, ptr %l7
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store i32 3, ptr %l7
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_b477747d616f01f0_6d4a3c12dca1cf4c)
  unreachable
bb54:
  %t73 = load i32, ptr %l7
  store i32 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiScalar(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l11
  br label %bb2
bb2:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t19 = load i32, ptr %l3, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t23 = icmp eq i32 %t19, %t20
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l12, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb14
bb7:
  br i1 %a2, label %bb8, label %bb9
bb8:
  %t28 = load i32, ptr %l3, !tbaa !23
  %t29 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t32 = icmp eq i32 %t28, %t29
  br i1 %t32, label %bb10, label %bb11
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb13
bb10:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb12
bb11:
  %t34 = load i32, ptr %l3, !tbaa !23
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t38 = icmp eq i32 %t34, %t35
  store i1 %t38, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l22, !tbaa !21
  store i1 %t40, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t41 = load i1, ptr %l18, !tbaa !21
  store i1 %t41, ptr %l16, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l16, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l9
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t18 = load i32, ptr %l9, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l10
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load i32, ptr %l10, !tbaa !23
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t20, i32 %t21)
  store i64 %t22, ptr %l11
  br label %bb3
bb3:
  %t23 = load i64, ptr %l11, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatIndex(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l21 = alloca %"compiler/eval:Ptr"
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load i64, ptr %l3, !tbaa !24
  %t4 = add i64 %t2, 8
  %t6 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr i64, ptr %t7, i64 %t4
  %t9 = load i64, ptr %t8, !tbaa !34
  %t11 = trunc i64 %t9 to i32
  store i32 %t11, ptr %l4, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l12, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = add i64 %t19, 5
  %t23 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i64, ptr %t24, i64 %t21
  %t26 = load i64, ptr %t25, !tbaa !34
  %t28 = trunc i64 %t26 to i32
  %t33 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t16, i64 %a1, i32 %t28)
  store %"compiler/eval:Ptr" %t33, ptr %l21
  br label %bb1
bb1:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l4, !tbaa !23
  %t38 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l24
  br label %bb2
bb2:
  %t39 = load ptr, ptr %l12, !tbaa !29
  %t40 = load %"compiler/eval:Ptr", ptr %l21
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t39, %"compiler/eval:Ptr" %t40, i64 %t41)
  store i64 %t42, ptr %l25
  br label %bb3
bb3:
  %t43 = load i32, ptr %l4, !tbaa !23
  %t44 = load ptr, ptr %l11, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t47 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t44, i64 %t45, i32 %t43)
  store i64 %t47, ptr %l27
  br label %bb4
bb4:
  %t48 = load i64, ptr %l27, !tbaa !24
  store i64 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatValue(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca i64
  %l28 = alloca { i64, ptr }
  %l32 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t2 = load i64, ptr %l3, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i64, ptr %t5, i64 %t2
  %t7 = load i64, ptr %t6, !tbaa !34
  store i64 %t7, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t13, ptr %l11, !tbaa !27
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = add i64 %t14, 1
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t27, 1
  %t31 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i64, ptr %t32, i64 %t29
  %t34 = load i64, ptr %t33, !tbaa !34
  %t39 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalAt(ptr %v0, ptr %t23, i64 %a1, i64 %t25, i64 %t34, i1 false)
  store i64 %t39, ptr %l22
  br label %bb4
bb4:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l28, !tbaa !27
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = add i64 %t49, 1
  %t53 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i64, ptr %t54, i64 %t51
  %t56 = load i64, ptr %t55, !tbaa !34
  %t60 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t46, i64 %t47, i64 %t56)
  store i64 %t60, ptr %l32
  br label %bb8
bb8:
  %t61 = load i64, ptr %l32, !tbaa !24
  store i64 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatten(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/mir:Lvalue"
  %l7 = alloca { i64, [15 x i64] }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, [4 x i64] }
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"compiler/mir:Lvalue"
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, [1 x i64] }
  %l27 = alloca i32
  %l28 = alloca i32
  %l32 = alloca i64
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca %"compiler/mir:Range"
  %l37 = alloca i64
  %l38 = alloca { i64, [1 x i64] }
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i64
  %l42 = alloca { i64, [4 x i64] }
  %l47 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i1
  %l60 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca i1
  %l73 = alloca ptr
  %l77 = alloca %"compiler/mir:Local"
  %l79 = alloca i1
  %l81 = alloca ptr
  %l85 = alloca %"compiler/mir:Local"
  %l87 = alloca i64
  %l93 = alloca %"compiler/mir:Local"
  %l97 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l120 = alloca i1
  %l122 = alloca i1
  %l125 = alloca i64
  %l132 = alloca i64
  %l134 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l153 = alloca i64
  %l156 = alloca i1
  %l157 = alloca ptr
  %l161 = alloca %"compiler/mir:Local"
  %l163 = alloca i1
  %l165 = alloca i1
  %l166 = alloca ptr
  %l170 = alloca %"compiler/mir:Local"
  %l172 = alloca i64
  %l179 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l195 = alloca i64
  %l202 = alloca { i64, [1 x i64] }
  %l206 = alloca ptr
  %l210 = alloca %"compiler/mir:Local"
  %l212 = alloca i32
  %l215 = alloca i1
  %l217 = alloca i1
  %l220 = alloca i64
  %l223 = alloca i1
  %l226 = alloca i64
  %l229 = alloca ptr
  %l234 = alloca %"compiler/mir:Local"
  %l236 = alloca i1
  %l243 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l252 = alloca { i64, ptr }
  %l259 = alloca %"compiler/mir:Local"
  %l266 = alloca %"compiler/mir:Local"
  %l270 = alloca { i64, ptr }
  %l275 = alloca { i64, ptr }
  %l286 = alloca i1
  %l288 = alloca i1
  %l291 = alloca i64
  %l294 = alloca i1
  %l296 = alloca i1
  %l298 = alloca ptr
  %l299 = alloca ptr
  %l304 = alloca { i64, [4 x i64] }
  %l310 = alloca i1
  %l314 = alloca i1
  %l317 = alloca i1
  %l323 = alloca { i64, ptr }
  %l328 = alloca i1
  %l329 = alloca ptr
  %l330 = alloca ptr
  %l336 = alloca { i64, [4 x i64] }
  %l342 = alloca i1
  %l345 = alloca { i64, ptr }
  %l350 = alloca { i64, ptr }
  %l356 = alloca i1
  %l357 = alloca i1
  %l360 = alloca { i64, ptr }
  %l366 = alloca i1
  %l367 = alloca i1
  %l369 = alloca i1
  %l371 = alloca { i64, ptr }
  %l375 = alloca { i64, ptr }
  %l381 = alloca i64
  %l388 = alloca { i64, [1 x i64] }
  %l392 = alloca ptr
  %l396 = alloca %"compiler/mir:Local"
  %l398 = alloca i32
  %l401 = alloca i1
  %l403 = alloca i1
  %l406 = alloca i64
  %l409 = alloca i64
  %l413 = alloca i64
  %l429 = alloca i1
  %l433 = alloca { i64, ptr }
  %l439 = alloca i64
  %l442 = alloca ptr
  %l447 = alloca %"compiler/mir:Local"
  %l449 = alloca i1
  %l457 = alloca { i64, ptr }
  %l461 = alloca { i64, ptr }
  %l466 = alloca { i64, ptr }
  %l471 = alloca { i64, ptr }
  %l478 = alloca %"compiler/mir:Local"
  %l485 = alloca %"compiler/mir:Local"
  %l489 = alloca { i64, ptr }
  %l494 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t2 = load ptr, ptr %l49, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l49, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l50, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l50, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l5
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t18, i32 0, i32 1
  %t20 = load %"compiler/mir:Lvalue", ptr %t19
  store %"compiler/mir:Lvalue" %t20, ptr %l6
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr { i64, [21 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t24, i32 0, i32 2
  %t26 = load { i64, [15 x i64] }, ptr %t25
  store { i64, [15 x i64] } %t26, ptr %l7
  br label %bb5
bb4:
  br label %bb224
bb5:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/eval:cfn", ptr %t28, i32 0, i32 18
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l60, !tbaa !27
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load %"compiler/source:Span", ptr %l5
  %t36 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/source:Span", ptr %t37, i64 %t32
  store %"compiler/source:Span" %t33, ptr %t38
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t43 = mul i64 %t39, %t40
  store i64 %t43, ptr %l8, !tbaa !24
  %t45 = getelementptr %"compiler/mir:Lvalue", ptr %l6, i32 0, i32 1
  %t46 = getelementptr %"compiler/mir:Range", ptr %t45, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = icmp eq i32 %t47, 0
  br i1 %t49, label %bb6, label %bb7
bb6:
  %t51 = load %"compiler/mir:Lvalue", ptr %l6
  %t53 = call i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %t51)
  store i64 %t53, ptr %l69
  br label %bb8
bb7:
  %t54 = getelementptr %"compiler/mir:Lvalue", ptr %l6, i32 0, i32 1
  %t55 = getelementptr %"compiler/mir:Range", ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55, !tbaa !23
  %t58 = icmp eq i32 %t56, 1
  br i1 %t58, label %bb159, label %bb160
bb8:
  %t60 = load i64, ptr %l69, !tbaa !24
  store i64 %t60, ptr %l9, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t63 = icmp slt i64 %t61, 0
  br i1 %t63, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb13
bb10:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l73, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/mir:Fn", ptr %t66, i32 0, i32 7
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t68, i64 %t69)
  store %"compiler/mir:Local" %t72, ptr %l77
  br label %bb11
bb11:
  %t73 = getelementptr %"compiler/mir:Local", ptr %l77, i32 0, i32 2
  %t74 = load i32, ptr %t73, !tbaa !23
  %t75 = load ptr, ptr %l73, !tbaa !29
  %t77 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t75, i32 %t74)
  store i1 %t77, ptr %l79
  br label %bb12
bb12:
  %t78 = load i1, ptr %l79, !tbaa !21
  %t79 = xor i1 %t78, true
  store i1 %t79, ptr %l72, !tbaa !21
  br label %bb13
bb13:
  %t81 = load i1, ptr %l72, !tbaa !21
  br i1 %t81, label %bb14, label %bb15
bb14:
  br label %ret
bb15:
  br label %bb16
bb16:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l81, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/mir:Fn", ptr %t83, i32 0, i32 7
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t85, i64 %t86)
  store %"compiler/mir:Local" %t89, ptr %l85
  br label %bb17
bb17:
  %t90 = getelementptr %"compiler/mir:Local", ptr %l85, i32 0, i32 2
  %t91 = load i32, ptr %t90, !tbaa !23
  %t92 = load ptr, ptr %l81, !tbaa !29
  %t94 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t92, i32 %t91)
  store i64 %t94, ptr %l87
  br label %bb18
bb18:
  %t95 = load i64, ptr %l87, !tbaa !24
  store i64 %t95, ptr %l10, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  store i64 %t96, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  store i64 %t98, ptr %l12, !tbaa !24
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/mir:Fn", ptr %t100, i32 0, i32 7
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t102, i64 %t103)
  store %"compiler/mir:Local" %t106, ptr %l93
  br label %bb19
bb19:
  %t107 = getelementptr %"compiler/mir:Local", ptr %l93, i32 0, i32 2
  %t108 = load i32, ptr %t107, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t114 = getelementptr %"compiler/eval:cfn", ptr %t112, i32 0, i32 13
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %l97, !tbaa !27
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = add i64 %t116, 1
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i64, ptr %t123, i64 %t118
  store i64 %t119, ptr %t124, !tbaa !34
  %t125 = load ptr, ptr %l3, !tbaa !29
  %t127 = getelementptr %"compiler/eval:cfn", ptr %t125, i32 0, i32 13
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l102, !tbaa !27
  %t129 = load i64, ptr %l8, !tbaa !24
  %t131 = add i64 %t129, 2
  %t132 = load i64, ptr %l12, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i64, ptr %t136, i64 %t131
  store i64 %t132, ptr %t137, !tbaa !34
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = getelementptr %"compiler/eval:cfn", ptr %t138, i32 0, i32 13
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l107, !tbaa !27
  %t142 = load i64, ptr %l8, !tbaa !24
  %t144 = add i64 %t142, 9
  %t148 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i64, ptr %t149, i64 %t144
  store i64 %t110, ptr %t150, !tbaa !34
  %t151 = load { i64, [15 x i64] }, ptr %l7
  %t153 = extractvalue { i64, [15 x i64] } %t151, 0
  %t154 = icmp eq i64 %t153, 0
  br i1 %t154, label %bb20, label %bb21
bb20:
  %t156 = getelementptr { i64, [15 x i64] }, ptr %l7, i32 0, i32 1
  %t157 = getelementptr { { i64, [4 x i64] } }, ptr %t156, i32 0, i32 0
  %t158 = load { i64, [4 x i64] }, ptr %t157
  store { i64, [4 x i64] } %t158, ptr %l14
  br label %bb22
bb21:
  br label %bb100
bb22:
  %t160 = load { i64, [4 x i64] }, ptr %l14
  %t162 = extractvalue { i64, [4 x i64] } %t160, 0
  %t163 = icmp eq i64 %t162, 2
  br i1 %t163, label %bb23, label %bb24
bb23:
  %t165 = getelementptr { i64, [4 x i64] }, ptr %l14, i32 0, i32 1
  %t166 = getelementptr { i32, i64 }, ptr %t165, i32 0, i32 0
  %t167 = load i32, ptr %t166
  store i32 %t167, ptr %l15, !tbaa !23
  %t169 = getelementptr { i64, [4 x i64] }, ptr %l14, i32 0, i32 1
  %t170 = getelementptr { i32, i64 }, ptr %t169, i32 0, i32 1
  %t171 = load i64, ptr %t170
  store i64 %t171, ptr %l16, !tbaa !24
  br label %bb25
bb24:
  br label %bb35
bb25:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l15, !tbaa !23
  %t177 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t173, i32 %t174)
  store i1 %t177, ptr %l120
  br label %bb26
bb26:
  %t178 = load i1, ptr %l120, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb30
bb28:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l15, !tbaa !23
  %t185 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t181, i32 %t182)
  store i64 %t185, ptr %l125
  br label %bb29
bb29:
  %t186 = load i64, ptr %l10, !tbaa !24
  %t187 = load i64, ptr %l125, !tbaa !24
  %t189 = icmp ne i64 %t187, %t186
  store i1 %t189, ptr %l122, !tbaa !21
  br label %bb30
bb30:
  %t191 = load i1, ptr %l122, !tbaa !21
  br i1 %t191, label %bb31, label %bb32
bb31:
  br label %ret
bb32:
  br label %bb33
bb33:
  %t192 = load i64, ptr @G_2ecompiler_2feval_2efConst, !tbaa !24
  store i64 %t192, ptr %l17, !tbaa !24
  store i64 -1, ptr %l18, !tbaa !24
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l15, !tbaa !23
  %t196 = load i64, ptr %l16, !tbaa !24
  %t200 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecanonBits(ptr %v0, ptr %t194, i32 %t195, i64 %t196)
  store i64 %t200, ptr %l132
  br label %bb34
bb34:
  %t201 = load i64, ptr %l132, !tbaa !24
  %t202 = load ptr, ptr %l3, !tbaa !29
  %t204 = getelementptr %"compiler/eval:cfn", ptr %t202, i32 0, i32 13
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  store { i64, ptr } %t205, ptr %l134, !tbaa !27
  %t206 = load i64, ptr %l8, !tbaa !24
  %t207 = load i64, ptr %l17, !tbaa !24
  %t210 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr i64, ptr %t211, i64 %t206
  store i64 %t207, ptr %t212, !tbaa !34
  %t213 = load ptr, ptr %l3, !tbaa !29
  %t215 = getelementptr %"compiler/eval:cfn", ptr %t213, i32 0, i32 13
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  store { i64, ptr } %t216, ptr %l138, !tbaa !27
  %t217 = load i64, ptr %l8, !tbaa !24
  %t219 = add i64 %t217, 3
  %t220 = load i64, ptr %l18, !tbaa !24
  %t223 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr i64, ptr %t224, i64 %t219
  store i64 %t220, ptr %t225, !tbaa !34
  %t226 = load ptr, ptr %l3, !tbaa !29
  %t228 = getelementptr %"compiler/eval:cfn", ptr %t226, i32 0, i32 13
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !27
  store { i64, ptr } %t229, ptr %l143, !tbaa !27
  %t230 = load i64, ptr %l8, !tbaa !24
  %t232 = add i64 %t230, 4
  %t236 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr i64, ptr %t237, i64 %t232
  store i64 %t201, ptr %t238, !tbaa !34
  br label %bb99
bb35:
  %t239 = load { i64, [4 x i64] }, ptr %l14
  %t241 = extractvalue { i64, [4 x i64] } %t239, 0
  %t242 = icmp eq i64 %t241, 1
  br i1 %t242, label %bb36, label %bb37
bb36:
  %t244 = getelementptr { i64, [4 x i64] }, ptr %l14, i32 0, i32 1
  %t245 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t244, i32 0, i32 0
  %t246 = load %"compiler/mir:Lvalue", ptr %t245
  store %"compiler/mir:Lvalue" %t246, ptr %l20
  br label %bb38
bb37:
  br label %bb94
bb38:
  %t248 = getelementptr %"compiler/mir:Lvalue", ptr %l20, i32 0, i32 1
  %t249 = getelementptr %"compiler/mir:Range", ptr %t248, i32 0, i32 1
  %t250 = load i32, ptr %t249, !tbaa !23
  %t252 = icmp eq i32 %t250, 0
  br i1 %t252, label %bb39, label %bb40
bb39:
  %t254 = load %"compiler/mir:Lvalue", ptr %l20
  %t256 = call i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %t254)
  store i64 %t256, ptr %l153
  br label %bb41
bb40:
  %t257 = getelementptr %"compiler/mir:Lvalue", ptr %l20, i32 0, i32 1
  %t258 = getelementptr %"compiler/mir:Range", ptr %t257, i32 0, i32 1
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = icmp eq i32 %t259, 1
  br i1 %t261, label %bb55, label %bb56
bb41:
  %t263 = load i64, ptr %l153, !tbaa !24
  store i64 %t263, ptr %l21, !tbaa !24
  %t264 = load i64, ptr %l21, !tbaa !24
  %t266 = icmp slt i64 %t264, 0
  br i1 %t266, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb46
bb43:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l157, !tbaa !29
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr %"compiler/mir:Fn", ptr %t269, i32 0, i32 7
  %t272 = load i64, ptr %l21, !tbaa !24
  %t275 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t271, i64 %t272)
  store %"compiler/mir:Local" %t275, ptr %l161
  br label %bb44
bb44:
  %t276 = getelementptr %"compiler/mir:Local", ptr %l161, i32 0, i32 2
  %t277 = load i32, ptr %t276, !tbaa !23
  %t278 = load ptr, ptr %l157, !tbaa !29
  %t280 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t278, i32 %t277)
  store i1 %t280, ptr %l163
  br label %bb45
bb45:
  %t281 = load i1, ptr %l163, !tbaa !21
  %t282 = xor i1 %t281, true
  store i1 %t282, ptr %l156, !tbaa !21
  br label %bb46
bb46:
  %t284 = load i1, ptr %l156, !tbaa !21
  br i1 %t284, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l165, !tbaa !21
  br label %bb51
bb48:
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l166, !tbaa !29
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr %"compiler/mir:Fn", ptr %t286, i32 0, i32 7
  %t289 = load i64, ptr %l21, !tbaa !24
  %t292 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t288, i64 %t289)
  store %"compiler/mir:Local" %t292, ptr %l170
  br label %bb49
bb49:
  %t293 = getelementptr %"compiler/mir:Local", ptr %l170, i32 0, i32 2
  %t294 = load i32, ptr %t293, !tbaa !23
  %t295 = load ptr, ptr %l166, !tbaa !29
  %t297 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t295, i32 %t294)
  store i64 %t297, ptr %l172
  br label %bb50
bb50:
  %t298 = load i64, ptr %l10, !tbaa !24
  %t299 = load i64, ptr %l172, !tbaa !24
  %t301 = icmp ne i64 %t299, %t298
  store i1 %t301, ptr %l165, !tbaa !21
  br label %bb51
bb51:
  %t303 = load i1, ptr %l165, !tbaa !21
  br i1 %t303, label %bb52, label %bb53
bb52:
  br label %ret
bb53:
  br label %bb54
bb54:
  %t304 = load i64, ptr @G_2ecompiler_2feval_2efCopy, !tbaa !24
  %t306 = load i64, ptr %l21, !tbaa !24
  %t308 = load i64, ptr %l10, !tbaa !24
  %t310 = load ptr, ptr %l3, !tbaa !29
  %t312 = getelementptr %"compiler/eval:cfn", ptr %t310, i32 0, i32 13
  %t313 = load { i64, ptr }, ptr %t312, !tbaa !27
  store { i64, ptr } %t313, ptr %l179, !tbaa !27
  %t314 = load i64, ptr %l8, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr i64, ptr %t319, i64 %t314
  store i64 %t304, ptr %t320, !tbaa !34
  %t321 = load ptr, ptr %l3, !tbaa !29
  %t323 = getelementptr %"compiler/eval:cfn", ptr %t321, i32 0, i32 13
  %t324 = load { i64, ptr }, ptr %t323, !tbaa !27
  store { i64, ptr } %t324, ptr %l183, !tbaa !27
  %t325 = load i64, ptr %l8, !tbaa !24
  %t327 = add i64 %t325, 3
  %t331 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr i64, ptr %t332, i64 %t327
  store i64 %t306, ptr %t333, !tbaa !34
  %t334 = load ptr, ptr %l3, !tbaa !29
  %t336 = getelementptr %"compiler/eval:cfn", ptr %t334, i32 0, i32 13
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l188, !tbaa !27
  %t338 = load i64, ptr %l8, !tbaa !24
  %t340 = add i64 %t338, 4
  %t344 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = getelementptr i64, ptr %t345, i64 %t340
  store i64 %t308, ptr %t346, !tbaa !34
  br label %bb93
bb55:
  %t347 = load %"compiler/mir:Lvalue", ptr %l20
  %t349 = call i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %t347)
  store i64 %t349, ptr %l195
  br label %bb57
bb56:
  br label %bb92
bb57:
  %t350 = load i64, ptr %l195, !tbaa !24
  store i64 %t350, ptr %l25, !tbaa !24
  %t351 = load i64, ptr %l25, !tbaa !24
  %t353 = icmp slt i64 %t351, 0
  br i1 %t353, label %bb58, label %bb59
bb58:
  br label %ret
bb59:
  br label %bb60
bb60:
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr %"compiler/mir:Fn", ptr %t355, i32 0, i32 10
  %t358 = getelementptr %"compiler/mir:Lvalue", ptr %l20, i32 0, i32 1
  %t359 = getelementptr %"compiler/mir:Range", ptr %t358, i32 0, i32 0
  %t360 = load i32, ptr %t359, !tbaa !23
  %t362 = sext i32 %t360 to i64
  %t365 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %t357, i64 %t362)
  store { i64, [1 x i64] } %t365, ptr %l202
  br label %bb61
bb61:
  %t366 = load { i64, [1 x i64] }, ptr %l202
  store { i64, [1 x i64] } %t366, ptr %l26
  %t367 = load { i64, [1 x i64] }, ptr %l26
  %t369 = extractvalue { i64, [1 x i64] } %t367, 0
  %t370 = icmp eq i64 %t369, 1
  br i1 %t370, label %bb62, label %bb63
bb62:
  %t372 = getelementptr { i64, [1 x i64] }, ptr %l26, i32 0, i32 1
  %t373 = getelementptr { i32 }, ptr %t372, i32 0, i32 0
  %t374 = load i32, ptr %t373
  store i32 %t374, ptr %l27, !tbaa !23
  br label %bb64
bb63:
  br label %bb86
bb64:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l206, !tbaa !29
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr %"compiler/mir:Fn", ptr %t377, i32 0, i32 7
  %t380 = load i64, ptr %l25, !tbaa !24
  %t383 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t379, i64 %t380)
  store %"compiler/mir:Local" %t383, ptr %l210
  br label %bb65
bb65:
  %t384 = getelementptr %"compiler/mir:Local", ptr %l210, i32 0, i32 2
  %t385 = load i32, ptr %t384, !tbaa !23
  %t386 = load ptr, ptr %l206, !tbaa !29
  %t388 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t386, i32 %t385)
  store i32 %t388, ptr %l212
  br label %bb66
bb66:
  %t389 = load i32, ptr %l212, !tbaa !23
  store i32 %t389, ptr %l28, !tbaa !23
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i32, ptr %l28, !tbaa !23
  %t394 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t390, i32 %t391)
  store i1 %t394, ptr %l215
  br label %bb67
bb67:
  %t395 = load i1, ptr %l215, !tbaa !21
  %t396 = xor i1 %t395, true
  br i1 %t396, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb71
bb69:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load i32, ptr %l28, !tbaa !23
  %t402 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t398, i32 %t399)
  store i64 %t402, ptr %l220
  br label %bb70
bb70:
  %t403 = load i64, ptr %l10, !tbaa !24
  %t404 = load i64, ptr %l220, !tbaa !24
  %t406 = icmp ne i64 %t404, %t403
  store i1 %t406, ptr %l217, !tbaa !21
  br label %bb71
bb71:
  %t408 = load i1, ptr %l217, !tbaa !21
  br i1 %t408, label %bb72, label %bb73
bb72:
  store i1 true, ptr %l223, !tbaa !21
  br label %bb75
bb73:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load i32, ptr %l28, !tbaa !23
  %t413 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t409, i32 %t410)
  store i64 %t413, ptr %l226
  br label %bb74
bb74:
  %t414 = load i64, ptr %l10, !tbaa !24
  %t415 = load i64, ptr %l226, !tbaa !24
  %t417 = icmp ne i64 %t415, %t414
  store i1 %t417, ptr %l223, !tbaa !21
  br label %bb75
bb75:
  %t419 = load i1, ptr %l223, !tbaa !21
  br i1 %t419, label %bb76, label %bb77
bb76:
  br label %ret
bb77:
  br label %bb78
bb78:
  %t420 = load ptr, ptr %l0, !tbaa !29
  store ptr %t420, ptr %l229, !tbaa !29
  %t421 = load ptr, ptr %l1, !tbaa !29
  %t423 = getelementptr %"compiler/mir:Fn", ptr %t421, i32 0, i32 7
  %t424 = load i32, ptr %l27, !tbaa !23
  %t426 = sext i32 %t424 to i64
  %t429 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t423, i64 %t426)
  store %"compiler/mir:Local" %t429, ptr %l234
  br label %bb79
bb79:
  %t430 = getelementptr %"compiler/mir:Local", ptr %l234, i32 0, i32 2
  %t431 = load i32, ptr %t430, !tbaa !23
  %t432 = load ptr, ptr %l229, !tbaa !29
  %t434 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t432, i32 %t431)
  store i1 %t434, ptr %l236
  br label %bb80
bb80:
  %t435 = load i1, ptr %l236, !tbaa !21
  %t436 = xor i1 %t435, true
  br i1 %t436, label %bb81, label %bb82
bb81:
  br label %ret
bb82:
  br label %bb83
bb83:
  %t438 = load i64, ptr @G_2ecompiler_2feval_2efLoad, !tbaa !24
  %t440 = load i64, ptr %l25, !tbaa !24
  %t442 = load i32, ptr %l27, !tbaa !23
  %t444 = sext i32 %t442 to i64
  %t446 = load ptr, ptr %l3, !tbaa !29
  %t448 = getelementptr %"compiler/eval:cfn", ptr %t446, i32 0, i32 13
  %t449 = load { i64, ptr }, ptr %t448, !tbaa !27
  store { i64, ptr } %t449, ptr %l243, !tbaa !27
  %t450 = load i64, ptr %l8, !tbaa !24
  %t454 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = getelementptr i64, ptr %t455, i64 %t450
  store i64 %t438, ptr %t456, !tbaa !34
  %t457 = load ptr, ptr %l3, !tbaa !29
  %t459 = getelementptr %"compiler/eval:cfn", ptr %t457, i32 0, i32 13
  %t460 = load { i64, ptr }, ptr %t459, !tbaa !27
  store { i64, ptr } %t460, ptr %l247, !tbaa !27
  %t461 = load i64, ptr %l8, !tbaa !24
  %t463 = add i64 %t461, 3
  %t467 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr i64, ptr %t468, i64 %t463
  store i64 %t440, ptr %t469, !tbaa !34
  %t470 = load ptr, ptr %l3, !tbaa !29
  %t472 = getelementptr %"compiler/eval:cfn", ptr %t470, i32 0, i32 13
  %t473 = load { i64, ptr }, ptr %t472, !tbaa !27
  store { i64, ptr } %t473, ptr %l252, !tbaa !27
  %t474 = load i64, ptr %l8, !tbaa !24
  %t476 = add i64 %t474, 5
  %t480 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = getelementptr i64, ptr %t481, i64 %t476
  store i64 %t444, ptr %t482, !tbaa !34
  %t483 = load ptr, ptr %l1, !tbaa !29
  %t485 = getelementptr %"compiler/mir:Fn", ptr %t483, i32 0, i32 7
  %t486 = load i64, ptr %l25, !tbaa !24
  %t489 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t485, i64 %t486)
  store %"compiler/mir:Local" %t489, ptr %l259
  br label %bb84
bb84:
  %t490 = getelementptr %"compiler/mir:Local", ptr %l259, i32 0, i32 2
  %t491 = load i32, ptr %t490, !tbaa !23
  %t493 = sext i32 %t491 to i64
  store i64 %t493, ptr %l32, !tbaa !24
  %t495 = load ptr, ptr %l1, !tbaa !29
  %t497 = getelementptr %"compiler/mir:Fn", ptr %t495, i32 0, i32 7
  %t498 = load i32, ptr %l27, !tbaa !23
  %t500 = sext i32 %t498 to i64
  %t503 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t497, i64 %t500)
  store %"compiler/mir:Local" %t503, ptr %l266
  br label %bb85
bb85:
  %t504 = getelementptr %"compiler/mir:Local", ptr %l266, i32 0, i32 2
  %t505 = load i32, ptr %t504, !tbaa !23
  %t507 = sext i32 %t505 to i64
  %t509 = load ptr, ptr %l3, !tbaa !29
  %t511 = getelementptr %"compiler/eval:cfn", ptr %t509, i32 0, i32 13
  %t512 = load { i64, ptr }, ptr %t511, !tbaa !27
  store { i64, ptr } %t512, ptr %l270, !tbaa !27
  %t513 = load i64, ptr %l8, !tbaa !24
  %t515 = add i64 %t513, 7
  %t516 = load i64, ptr %l32, !tbaa !24
  %t519 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t520 = load ptr, ptr %t519, !tbaa !27
  %t521 = getelementptr i64, ptr %t520, i64 %t515
  store i64 %t516, ptr %t521, !tbaa !34
  %t522 = load ptr, ptr %l3, !tbaa !29
  %t524 = getelementptr %"compiler/eval:cfn", ptr %t522, i32 0, i32 13
  %t525 = load { i64, ptr }, ptr %t524, !tbaa !27
  store { i64, ptr } %t525, ptr %l275, !tbaa !27
  %t526 = load i64, ptr %l8, !tbaa !24
  %t528 = add i64 %t526, 8
  %t532 = getelementptr { i64, ptr }, ptr %l275, i32 0, i32 1
  %t533 = load ptr, ptr %t532, !tbaa !27
  %t534 = getelementptr i64, ptr %t533, i64 %t528
  store i64 %t507, ptr %t534, !tbaa !34
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_2c3649ec7760d571_b360c53de5a7362d)
  unreachable
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  br label %bb99
bb94:
  br i1 true, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_2911fcc0ca845160_1e3fd4941e69567c)
  unreachable
bb99:
  br label %bb158
bb100:
  %t535 = load { i64, [15 x i64] }, ptr %l7
  %t537 = extractvalue { i64, [15 x i64] } %t535, 0
  %t538 = icmp eq i64 %t537, 3
  br i1 %t538, label %bb101, label %bb102
bb101:
  %t540 = getelementptr { i64, [15 x i64] }, ptr %l7, i32 0, i32 1
  %t541 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t540, i32 0, i32 0
  %t542 = load i32, ptr %t541
  store i32 %t542, ptr %l34
  %t544 = getelementptr { i64, [15 x i64] }, ptr %l7, i32 0, i32 1
  %t545 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t544, i32 0, i32 1
  %t546 = load i32, ptr %t545
  store i32 %t546, ptr %l35, !tbaa !23
  %t548 = getelementptr { i64, [15 x i64] }, ptr %l7, i32 0, i32 1
  %t549 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t548, i32 0, i32 2
  %t550 = load %"compiler/mir:Range", ptr %t549
  store %"compiler/mir:Range" %t550, ptr %l36
  br label %bb103
bb102:
  br label %bb153
bb103:
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load i32, ptr %l35, !tbaa !23
  %t556 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t552, i32 %t553)
  store i1 %t556, ptr %l286
  br label %bb104
bb104:
  %t557 = load i1, ptr %l286, !tbaa !21
  %t558 = xor i1 %t557, true
  br i1 %t558, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l288, !tbaa !21
  br label %bb108
bb106:
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t561 = load i32, ptr %l35, !tbaa !23
  %t564 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t560, i32 %t561)
  store i64 %t564, ptr %l291
  br label %bb107
bb107:
  %t565 = load i64, ptr %l10, !tbaa !24
  %t566 = load i64, ptr %l291, !tbaa !24
  %t568 = icmp ne i64 %t566, %t565
  store i1 %t568, ptr %l288, !tbaa !21
  br label %bb108
bb108:
  %t570 = load i1, ptr %l288, !tbaa !21
  br i1 %t570, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l294, !tbaa !21
  br label %bb112
bb110:
  %t571 = load i32, ptr %l34
  %t573 = call i1 @compiler_2feval_2eflatOp(i32 %t571)
  store i1 %t573, ptr %l296
  br label %bb111
bb111:
  %t574 = load i1, ptr %l296, !tbaa !21
  %t575 = xor i1 %t574, true
  store i1 %t575, ptr %l294, !tbaa !21
  br label %bb112
bb112:
  %t577 = load i1, ptr %l294, !tbaa !21
  br i1 %t577, label %bb113, label %bb114
bb113:
  br label %ret
bb114:
  br label %bb115
bb115:
  %t578 = load ptr, ptr %l0, !tbaa !29
  store ptr %t578, ptr %l298, !tbaa !29
  %t579 = load ptr, ptr %l1, !tbaa !29
  store ptr %t579, ptr %l299, !tbaa !29
  %t580 = load ptr, ptr %l1, !tbaa !29
  %t582 = getelementptr %"compiler/mir:Fn", ptr %t580, i32 0, i32 11
  %t583 = getelementptr %"compiler/mir:Range", ptr %l36, i32 0, i32 0
  %t584 = load i32, ptr %t583, !tbaa !23
  %t586 = sext i32 %t584 to i64
  %t589 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v1, ptr %t582, i64 %t586)
  store { i64, [4 x i64] } %t589, ptr %l304
  br label %bb116
bb116:
  %t590 = load ptr, ptr %l3, !tbaa !29
  %t591 = load i64, ptr %l8, !tbaa !24
  %t593 = add i64 %t591, 3
  %t594 = load i64, ptr %l8, !tbaa !24
  %t596 = add i64 %t594, 7
  %t597 = load ptr, ptr %l298, !tbaa !29
  %t598 = load ptr, ptr %l299, !tbaa !29
  %t599 = load { i64, [4 x i64] }, ptr %l304
  %t603 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatOperand(ptr %v0, ptr %v1, ptr %v3, ptr %t597, ptr %t598, { i64, [4 x i64] } %t599, ptr %t590, i64 %t593, i64 %t596)
  store i1 %t603, ptr %l310
  br label %bb117
bb117:
  %t604 = load i1, ptr %l310, !tbaa !21
  %t605 = xor i1 %t604, true
  br i1 %t605, label %bb118, label %bb119
bb118:
  br label %ret
bb119:
  br label %bb120
bb120:
  %t607 = load i32, ptr %l34
  %t609 = trunc i64 0 to i32
  %t610 = icmp eq i32 %t607, %t609
  br i1 %t610, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l314, !tbaa !21
  br label %bb123
bb122:
  %t612 = load i32, ptr %l34
  %t614 = trunc i64 1 to i32
  %t615 = icmp eq i32 %t612, %t614
  store i1 %t615, ptr %l314, !tbaa !21
  br label %bb123
bb123:
  %t617 = load i1, ptr %l314, !tbaa !21
  br i1 %t617, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l317, !tbaa !21
  br label %bb126
bb125:
  %t618 = load i32, ptr %l34
  %t620 = trunc i64 2 to i32
  %t621 = icmp eq i32 %t618, %t620
  store i1 %t621, ptr %l317, !tbaa !21
  br label %bb126
bb126:
  %t623 = load i1, ptr %l317, !tbaa !21
  br i1 %t623, label %bb127, label %bb128
bb127:
  %t624 = getelementptr %"compiler/mir:Range", ptr %l36, i32 0, i32 1
  %t625 = load i32, ptr %t624, !tbaa !23
  %t627 = icmp ne i32 %t625, 1
  br i1 %t627, label %bb129, label %bb130
bb128:
  %t629 = getelementptr %"compiler/mir:Range", ptr %l36, i32 0, i32 1
  %t630 = load i32, ptr %t629, !tbaa !23
  %t632 = icmp ne i32 %t630, 2
  br i1 %t632, label %bb132, label %bb133
bb129:
  br label %ret
bb130:
  br label %bb131
bb131:
  %t634 = load ptr, ptr %l3, !tbaa !29
  %t636 = getelementptr %"compiler/eval:cfn", ptr %t634, i32 0, i32 13
  %t637 = load { i64, ptr }, ptr %t636, !tbaa !27
  store { i64, ptr } %t637, ptr %l323, !tbaa !27
  %t638 = load i64, ptr %l8, !tbaa !24
  %t639 = load i64, ptr @G_2ecompiler_2feval_2efUn, !tbaa !24
  %t642 = getelementptr { i64, ptr }, ptr %l323, i32 0, i32 1
  %t643 = load ptr, ptr %t642, !tbaa !27
  %t644 = getelementptr i64, ptr %t643, i64 %t638
  store i64 %t639, ptr %t644, !tbaa !34
  br label %bb152
bb132:
  store i1 true, ptr %l328, !tbaa !21
  br label %bb136
bb133:
  %t645 = load ptr, ptr %l0, !tbaa !29
  store ptr %t645, ptr %l329, !tbaa !29
  %t646 = load ptr, ptr %l1, !tbaa !29
  store ptr %t646, ptr %l330, !tbaa !29
  %t647 = load ptr, ptr %l1, !tbaa !29
  %t649 = getelementptr %"compiler/mir:Fn", ptr %t647, i32 0, i32 11
  %t650 = getelementptr %"compiler/mir:Range", ptr %l36, i32 0, i32 0
  %t651 = load i32, ptr %t650, !tbaa !23
  %t653 = sext i32 %t651 to i64
  %t655 = add i64 %t653, 1
  %t658 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v1, ptr %t649, i64 %t655)
  store { i64, [4 x i64] } %t658, ptr %l336
  br label %bb134
bb134:
  %t659 = load ptr, ptr %l3, !tbaa !29
  %t660 = load i64, ptr %l8, !tbaa !24
  %t662 = add i64 %t660, 5
  %t663 = load i64, ptr %l8, !tbaa !24
  %t665 = add i64 %t663, 8
  %t666 = load ptr, ptr %l329, !tbaa !29
  %t667 = load ptr, ptr %l330, !tbaa !29
  %t668 = load { i64, [4 x i64] }, ptr %l336
  %t672 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatOperand(ptr %v0, ptr %v1, ptr %v3, ptr %t666, ptr %t667, { i64, [4 x i64] } %t668, ptr %t659, i64 %t662, i64 %t665)
  store i1 %t672, ptr %l342
  br label %bb135
bb135:
  %t673 = load i1, ptr %l342, !tbaa !21
  %t674 = xor i1 %t673, true
  store i1 %t674, ptr %l328, !tbaa !21
  br label %bb136
bb136:
  %t676 = load i1, ptr %l328, !tbaa !21
  br i1 %t676, label %bb137, label %bb138
bb137:
  br label %ret
bb138:
  br label %bb139
bb139:
  %t677 = load ptr, ptr %l3, !tbaa !29
  %t679 = getelementptr %"compiler/eval:cfn", ptr %t677, i32 0, i32 13
  %t680 = load { i64, ptr }, ptr %t679, !tbaa !27
  store { i64, ptr } %t680, ptr %l345, !tbaa !27
  %t681 = load i64, ptr %l8, !tbaa !24
  %t682 = load i64, ptr @G_2ecompiler_2feval_2efBin, !tbaa !24
  %t685 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t686 = load ptr, ptr %t685, !tbaa !27
  %t687 = getelementptr i64, ptr %t686, i64 %t681
  store i64 %t682, ptr %t687, !tbaa !34
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t689 = load ptr, ptr %l3, !tbaa !29
  %t691 = getelementptr %"compiler/eval:cfn", ptr %t689, i32 0, i32 13
  %t692 = load { i64, ptr }, ptr %t691, !tbaa !27
  store { i64, ptr } %t692, ptr %l350, !tbaa !27
  %t693 = load i64, ptr %l8, !tbaa !24
  %t695 = add i64 %t693, 7
  %t697 = getelementptr { i64, ptr }, ptr %l350, i32 0, i32 1
  %t698 = load ptr, ptr %t697, !tbaa !27
  %t699 = getelementptr i64, ptr %t698, i64 %t695
  %t700 = load i64, ptr %t699, !tbaa !34
  %t702 = trunc i64 %t700 to i32
  %t706 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ei64(ptr %v0, ptr %t688, i32 %t702)
  store i1 %t706, ptr %l356
  br label %bb140
bb140:
  %t707 = load i1, ptr %l356, !tbaa !21
  br i1 %t707, label %bb141, label %bb142
bb141:
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t709 = load ptr, ptr %l3, !tbaa !29
  %t711 = getelementptr %"compiler/eval:cfn", ptr %t709, i32 0, i32 13
  %t712 = load { i64, ptr }, ptr %t711, !tbaa !27
  store { i64, ptr } %t712, ptr %l360, !tbaa !27
  %t713 = load i64, ptr %l8, !tbaa !24
  %t715 = add i64 %t713, 8
  %t717 = getelementptr { i64, ptr }, ptr %l360, i32 0, i32 1
  %t718 = load ptr, ptr %t717, !tbaa !27
  %t719 = getelementptr i64, ptr %t718, i64 %t715
  %t720 = load i64, ptr %t719, !tbaa !34
  %t722 = trunc i64 %t720 to i32
  %t726 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ei64(ptr %v0, ptr %t708, i32 %t722)
  store i1 %t726, ptr %l366
  br label %bb143
bb142:
  store i1 false, ptr %l357, !tbaa !21
  br label %bb144
bb143:
  %t727 = load i1, ptr %l366, !tbaa !21
  store i1 %t727, ptr %l357, !tbaa !21
  br label %bb144
bb144:
  %t728 = load i1, ptr %l357, !tbaa !21
  br i1 %t728, label %bb145, label %bb146
bb145:
  %t729 = load i32, ptr %l34
  %t731 = call i1 @compiler_2feval_2ewordOp(i32 %t729)
  store i1 %t731, ptr %l369
  br label %bb147
bb146:
  store i1 false, ptr %l367, !tbaa !21
  br label %bb148
bb147:
  %t732 = load i1, ptr %l369, !tbaa !21
  store i1 %t732, ptr %l367, !tbaa !21
  br label %bb148
bb148:
  %t733 = load i1, ptr %l367, !tbaa !21
  br i1 %t733, label %bb149, label %bb150
bb149:
  %t734 = load ptr, ptr %l3, !tbaa !29
  %t736 = getelementptr %"compiler/eval:cfn", ptr %t734, i32 0, i32 13
  %t737 = load { i64, ptr }, ptr %t736, !tbaa !27
  store { i64, ptr } %t737, ptr %l371, !tbaa !27
  %t738 = load i64, ptr %l8, !tbaa !24
  %t740 = add i64 %t738, 10
  %t742 = getelementptr { i64, ptr }, ptr %l371, i32 0, i32 1
  %t743 = load ptr, ptr %t742, !tbaa !27
  %t744 = getelementptr i64, ptr %t743, i64 %t740
  store i64 1, ptr %t744, !tbaa !34
  br label %bb151
bb150:
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t745 = load ptr, ptr %l3, !tbaa !29
  %t747 = getelementptr %"compiler/eval:cfn", ptr %t745, i32 0, i32 14
  %t748 = load { i64, ptr }, ptr %t747, !tbaa !27
  store { i64, ptr } %t748, ptr %l375, !tbaa !27
  %t749 = load i64, ptr %l4, !tbaa !24
  %t750 = load i32, ptr %l34
  %t753 = getelementptr { i64, ptr }, ptr %l375, i32 0, i32 1
  %t754 = load ptr, ptr %t753, !tbaa !27
  %t755 = getelementptr i32, ptr %t754, i64 %t749
  store i32 %t750, ptr %t755
  br label %bb158
bb153:
  br i1 true, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb157
bb156:
  br label %bb158
bb157:
  call void @__olang_check_failed(ptr @olang_loc_d5c2e2db698a665b_3103939d027c3c37)
  unreachable
bb158:
  br label %bb223
bb159:
  %t756 = load %"compiler/mir:Lvalue", ptr %l6
  %t758 = call i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %t756)
  store i64 %t758, ptr %l381
  br label %bb161
bb160:
  br label %bb222
bb161:
  %t759 = load i64, ptr %l381, !tbaa !24
  store i64 %t759, ptr %l37, !tbaa !24
  %t760 = load i64, ptr %l37, !tbaa !24
  %t762 = icmp slt i64 %t760, 0
  br i1 %t762, label %bb162, label %bb163
bb162:
  br label %ret
bb163:
  br label %bb164
bb164:
  %t764 = load ptr, ptr %l1, !tbaa !29
  %t766 = getelementptr %"compiler/mir:Fn", ptr %t764, i32 0, i32 10
  %t767 = getelementptr %"compiler/mir:Lvalue", ptr %l6, i32 0, i32 1
  %t768 = getelementptr %"compiler/mir:Range", ptr %t767, i32 0, i32 0
  %t769 = load i32, ptr %t768, !tbaa !23
  %t771 = sext i32 %t769 to i64
  %t774 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v1, ptr %t766, i64 %t771)
  store { i64, [1 x i64] } %t774, ptr %l388
  br label %bb165
bb165:
  %t775 = load { i64, [1 x i64] }, ptr %l388
  store { i64, [1 x i64] } %t775, ptr %l38
  %t776 = load { i64, [1 x i64] }, ptr %l38
  %t778 = extractvalue { i64, [1 x i64] } %t776, 0
  %t779 = icmp eq i64 %t778, 1
  br i1 %t779, label %bb166, label %bb167
bb166:
  %t781 = getelementptr { i64, [1 x i64] }, ptr %l38, i32 0, i32 1
  %t782 = getelementptr { i32 }, ptr %t781, i32 0, i32 0
  %t783 = load i32, ptr %t782
  store i32 %t783, ptr %l39, !tbaa !23
  br label %bb168
bb167:
  br label %bb216
bb168:
  %t785 = load ptr, ptr %l0, !tbaa !29
  store ptr %t785, ptr %l392, !tbaa !29
  %t786 = load ptr, ptr %l1, !tbaa !29
  %t788 = getelementptr %"compiler/mir:Fn", ptr %t786, i32 0, i32 7
  %t789 = load i64, ptr %l37, !tbaa !24
  %t792 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t788, i64 %t789)
  store %"compiler/mir:Local" %t792, ptr %l396
  br label %bb169
bb169:
  %t793 = getelementptr %"compiler/mir:Local", ptr %l396, i32 0, i32 2
  %t794 = load i32, ptr %t793, !tbaa !23
  %t795 = load ptr, ptr %l392, !tbaa !29
  %t797 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t795, i32 %t794)
  store i32 %t797, ptr %l398
  br label %bb170
bb170:
  %t798 = load i32, ptr %l398, !tbaa !23
  store i32 %t798, ptr %l40, !tbaa !23
  %t799 = load ptr, ptr %l0, !tbaa !29
  %t800 = load i32, ptr %l40, !tbaa !23
  %t803 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t799, i32 %t800)
  store i1 %t803, ptr %l401
  br label %bb171
bb171:
  %t804 = load i1, ptr %l401, !tbaa !21
  %t805 = xor i1 %t804, true
  br i1 %t805, label %bb172, label %bb173
bb172:
  store i1 true, ptr %l403, !tbaa !21
  br label %bb176
bb173:
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t808 = load i32, ptr %l40, !tbaa !23
  %t811 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t807, i32 %t808)
  store i64 %t811, ptr %l406
  br label %bb174
bb174:
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t813 = load i32, ptr %l40, !tbaa !23
  %t816 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t812, i32 %t813)
  store i64 %t816, ptr %l409
  br label %bb175
bb175:
  %t817 = load i64, ptr %l406, !tbaa !24
  %t818 = load i64, ptr %l409, !tbaa !24
  %t819 = icmp ne i64 %t817, %t818
  store i1 %t819, ptr %l403, !tbaa !21
  br label %bb176
bb176:
  %t821 = load i1, ptr %l403, !tbaa !21
  br i1 %t821, label %bb177, label %bb178
bb177:
  br label %ret
bb178:
  br label %bb179
bb179:
  %t822 = load ptr, ptr %l0, !tbaa !29
  %t823 = load i32, ptr %l40, !tbaa !23
  %t826 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t822, i32 %t823)
  store i64 %t826, ptr %l413
  br label %bb180
bb180:
  %t827 = load i64, ptr %l413, !tbaa !24
  store i64 %t827, ptr %l41, !tbaa !24
  %t828 = load { i64, [15 x i64] }, ptr %l7
  %t830 = extractvalue { i64, [15 x i64] } %t828, 0
  %t831 = icmp eq i64 %t830, 0
  br i1 %t831, label %bb181, label %bb182
bb181:
  %t833 = getelementptr { i64, [15 x i64] }, ptr %l7, i32 0, i32 1
  %t834 = getelementptr { { i64, [4 x i64] } }, ptr %t833, i32 0, i32 0
  %t835 = load { i64, [4 x i64] }, ptr %t834
  store { i64, [4 x i64] } %t835, ptr %l42
  br label %bb183
bb182:
  br label %bb203
bb183:
  %t837 = load { i64, [4 x i64] }, ptr %l42
  %t839 = extractvalue { i64, [4 x i64] } %t837, 0
  %t840 = icmp eq i64 %t839, 2
  br i1 %t840, label %bb184, label %bb185
bb184:
  br label %bb188
bb185:
  %t842 = load { i64, [4 x i64] }, ptr %l42
  %t844 = extractvalue { i64, [4 x i64] } %t842, 0
  %t845 = icmp eq i64 %t844, 1
  br i1 %t845, label %bb186, label %bb187
bb186:
  br label %bb188
bb187:
  br label %bb197
bb188:
  %t847 = load ptr, ptr %l0, !tbaa !29
  %t848 = load ptr, ptr %l1, !tbaa !29
  %t849 = load { i64, [4 x i64] }, ptr %l42
  %t850 = load ptr, ptr %l3, !tbaa !29
  %t851 = load i64, ptr %l8, !tbaa !24
  %t853 = add i64 %t851, 3
  %t854 = load i64, ptr %l8, !tbaa !24
  %t856 = add i64 %t854, 9
  %t863 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatOperand(ptr %v0, ptr %v1, ptr %v3, ptr %t847, ptr %t848, { i64, [4 x i64] } %t849, ptr %t850, i64 %t853, i64 %t856)
  store i1 %t863, ptr %l429
  br label %bb189
bb189:
  %t864 = load i1, ptr %l429, !tbaa !21
  %t865 = xor i1 %t864, true
  br i1 %t865, label %bb190, label %bb191
bb190:
  br label %ret
bb191:
  br label %bb192
bb192:
  %t867 = load ptr, ptr %l0, !tbaa !29
  %t868 = load ptr, ptr %l3, !tbaa !29
  %t870 = getelementptr %"compiler/eval:cfn", ptr %t868, i32 0, i32 13
  %t871 = load { i64, ptr }, ptr %t870, !tbaa !27
  store { i64, ptr } %t871, ptr %l433, !tbaa !27
  %t872 = load i64, ptr %l8, !tbaa !24
  %t874 = add i64 %t872, 9
  %t876 = getelementptr { i64, ptr }, ptr %l433, i32 0, i32 1
  %t877 = load ptr, ptr %t876, !tbaa !27
  %t878 = getelementptr i64, ptr %t877, i64 %t874
  %t879 = load i64, ptr %t878, !tbaa !34
  %t881 = trunc i64 %t879 to i32
  %t885 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t867, i32 %t881)
  store i64 %t885, ptr %l439
  br label %bb193
bb193:
  %t886 = load i64, ptr %l41, !tbaa !24
  %t887 = load i64, ptr %l439, !tbaa !24
  %t889 = icmp ne i64 %t887, %t886
  br i1 %t889, label %bb194, label %bb195
bb194:
  br label %ret
bb195:
  br label %bb196
bb196:
  br label %bb202
bb197:
  br i1 true, label %bb198, label %bb199
bb198:
  br label %bb200
bb199:
  br label %bb201
bb200:
  br label %ret
bb201:
  call void @__olang_check_failed(ptr @olang_loc_dc43aa71d8d9c75a_2151ed02c3c5ad16)
  unreachable
bb202:
  br label %bb208
bb203:
  br i1 true, label %bb204, label %bb205
bb204:
  br label %bb206
bb205:
  br label %bb207
bb206:
  br label %ret
bb207:
  call void @__olang_check_failed(ptr @olang_loc_e714ed8eb9bc4bed_d75d9a728369dbb1)
  unreachable
bb208:
  %t891 = load ptr, ptr %l0, !tbaa !29
  store ptr %t891, ptr %l442, !tbaa !29
  %t892 = load ptr, ptr %l1, !tbaa !29
  %t894 = getelementptr %"compiler/mir:Fn", ptr %t892, i32 0, i32 7
  %t895 = load i32, ptr %l39, !tbaa !23
  %t897 = sext i32 %t895 to i64
  %t900 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t894, i64 %t897)
  store %"compiler/mir:Local" %t900, ptr %l447
  br label %bb209
bb209:
  %t901 = getelementptr %"compiler/mir:Local", ptr %l447, i32 0, i32 2
  %t902 = load i32, ptr %t901, !tbaa !23
  %t903 = load ptr, ptr %l442, !tbaa !29
  %t905 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t903, i32 %t902)
  store i1 %t905, ptr %l449
  br label %bb210
bb210:
  %t906 = load i1, ptr %l449, !tbaa !21
  %t907 = xor i1 %t906, true
  br i1 %t907, label %bb211, label %bb212
bb211:
  br label %ret
bb212:
  br label %bb213
bb213:
  %t909 = load i64, ptr @G_2ecompiler_2feval_2efStore, !tbaa !24
  %t911 = load i64, ptr %l37, !tbaa !24
  %t913 = load i64, ptr %l41, !tbaa !24
  %t915 = load i32, ptr %l39, !tbaa !23
  %t917 = sext i32 %t915 to i64
  %t919 = load ptr, ptr %l3, !tbaa !29
  %t921 = getelementptr %"compiler/eval:cfn", ptr %t919, i32 0, i32 13
  %t922 = load { i64, ptr }, ptr %t921, !tbaa !27
  store { i64, ptr } %t922, ptr %l457, !tbaa !27
  %t923 = load i64, ptr %l8, !tbaa !24
  %t927 = getelementptr { i64, ptr }, ptr %l457, i32 0, i32 1
  %t928 = load ptr, ptr %t927, !tbaa !27
  %t929 = getelementptr i64, ptr %t928, i64 %t923
  store i64 %t909, ptr %t929, !tbaa !34
  %t930 = load ptr, ptr %l3, !tbaa !29
  %t932 = getelementptr %"compiler/eval:cfn", ptr %t930, i32 0, i32 13
  %t933 = load { i64, ptr }, ptr %t932, !tbaa !27
  store { i64, ptr } %t933, ptr %l461, !tbaa !27
  %t934 = load i64, ptr %l8, !tbaa !24
  %t936 = add i64 %t934, 1
  %t940 = getelementptr { i64, ptr }, ptr %l461, i32 0, i32 1
  %t941 = load ptr, ptr %t940, !tbaa !27
  %t942 = getelementptr i64, ptr %t941, i64 %t936
  store i64 %t911, ptr %t942, !tbaa !34
  %t943 = load ptr, ptr %l3, !tbaa !29
  %t945 = getelementptr %"compiler/eval:cfn", ptr %t943, i32 0, i32 13
  %t946 = load { i64, ptr }, ptr %t945, !tbaa !27
  store { i64, ptr } %t946, ptr %l466, !tbaa !27
  %t947 = load i64, ptr %l8, !tbaa !24
  %t949 = add i64 %t947, 2
  %t953 = getelementptr { i64, ptr }, ptr %l466, i32 0, i32 1
  %t954 = load ptr, ptr %t953, !tbaa !27
  %t955 = getelementptr i64, ptr %t954, i64 %t949
  store i64 %t913, ptr %t955, !tbaa !34
  %t956 = load ptr, ptr %l3, !tbaa !29
  %t958 = getelementptr %"compiler/eval:cfn", ptr %t956, i32 0, i32 13
  %t959 = load { i64, ptr }, ptr %t958, !tbaa !27
  store { i64, ptr } %t959, ptr %l471, !tbaa !27
  %t960 = load i64, ptr %l8, !tbaa !24
  %t962 = add i64 %t960, 5
  %t966 = getelementptr { i64, ptr }, ptr %l471, i32 0, i32 1
  %t967 = load ptr, ptr %t966, !tbaa !27
  %t968 = getelementptr i64, ptr %t967, i64 %t962
  store i64 %t917, ptr %t968, !tbaa !34
  %t969 = load ptr, ptr %l1, !tbaa !29
  %t971 = getelementptr %"compiler/mir:Fn", ptr %t969, i32 0, i32 7
  %t972 = load i64, ptr %l37, !tbaa !24
  %t975 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t971, i64 %t972)
  store %"compiler/mir:Local" %t975, ptr %l478
  br label %bb214
bb214:
  %t976 = getelementptr %"compiler/mir:Local", ptr %l478, i32 0, i32 2
  %t977 = load i32, ptr %t976, !tbaa !23
  %t979 = sext i32 %t977 to i64
  store i64 %t979, ptr %l47, !tbaa !24
  %t981 = load ptr, ptr %l1, !tbaa !29
  %t983 = getelementptr %"compiler/mir:Fn", ptr %t981, i32 0, i32 7
  %t984 = load i32, ptr %l39, !tbaa !23
  %t986 = sext i32 %t984 to i64
  %t989 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t983, i64 %t986)
  store %"compiler/mir:Local" %t989, ptr %l485
  br label %bb215
bb215:
  %t990 = getelementptr %"compiler/mir:Local", ptr %l485, i32 0, i32 2
  %t991 = load i32, ptr %t990, !tbaa !23
  %t993 = sext i32 %t991 to i64
  %t995 = load ptr, ptr %l3, !tbaa !29
  %t997 = getelementptr %"compiler/eval:cfn", ptr %t995, i32 0, i32 13
  %t998 = load { i64, ptr }, ptr %t997, !tbaa !27
  store { i64, ptr } %t998, ptr %l489, !tbaa !27
  %t999 = load i64, ptr %l8, !tbaa !24
  %t1001 = add i64 %t999, 7
  %t1002 = load i64, ptr %l47, !tbaa !24
  %t1005 = getelementptr { i64, ptr }, ptr %l489, i32 0, i32 1
  %t1006 = load ptr, ptr %t1005, !tbaa !27
  %t1007 = getelementptr i64, ptr %t1006, i64 %t1001
  store i64 %t1002, ptr %t1007, !tbaa !34
  %t1008 = load ptr, ptr %l3, !tbaa !29
  %t1010 = getelementptr %"compiler/eval:cfn", ptr %t1008, i32 0, i32 13
  %t1011 = load { i64, ptr }, ptr %t1010, !tbaa !27
  store { i64, ptr } %t1011, ptr %l494, !tbaa !27
  %t1012 = load i64, ptr %l8, !tbaa !24
  %t1014 = add i64 %t1012, 8
  %t1018 = getelementptr { i64, ptr }, ptr %l494, i32 0, i32 1
  %t1019 = load ptr, ptr %t1018, !tbaa !27
  %t1020 = getelementptr i64, ptr %t1019, i64 %t1014
  store i64 %t993, ptr %t1020, !tbaa !34
  br label %bb221
bb216:
  br i1 true, label %bb217, label %bb218
bb217:
  br label %bb219
bb218:
  br label %bb220
bb219:
  br label %bb221
bb220:
  call void @__olang_check_failed(ptr @olang_loc_be4b7d7361ea403c_360f852de4aa57a0)
  unreachable
bb221:
  br label %bb222
bb222:
  br label %bb223
bb223:
  br label %bb229
bb224:
  br i1 true, label %bb225, label %bb226
bb225:
  br label %bb227
bb226:
  br label %bb228
bb227:
  br label %bb229
bb228:
  call void @__olang_check_failed(ptr @olang_loc_c543a46c12bf3f7_90f0fb430875159b)
  unreachable
bb229:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca double
  %l7 = alloca double
  %l8 = alloca float
  %l9 = alloca float
  %l10 = alloca float
  %l14 = alloca i32
  %l23 = alloca i64
  %l56 = alloca i64
  %l60 = alloca double
  %l65 = alloca double
  %l67 = alloca float
  %l102 = alloca i64
  %l112 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l4, !tbaa !23
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load i32, ptr %l14, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  %t10 = load i32, ptr %l5, !tbaa !23
  %t12 = icmp eq i32 %t10, 14
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = bitcast i64 %t14 to double
  store double %t17, ptr %l6, !tbaa !26
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = bitcast i64 %t19 to double
  store double %t22, ptr %l7, !tbaa !26
  %t24 = load i32, ptr %l1
  %t26 = trunc i64 3 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb4, label %bb5
bb3:
  br label %bb26
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t29 = load double, ptr %l6, !tbaa !26
  %t30 = load double, ptr %l7, !tbaa !26
  %t33 = fadd double %t29, %t30
  %t35 = bitcast double %t33 to i64
  store i64 %t35, ptr %l23, !tbaa !24
  br label %bb25
bb7:
  %t38 = load i32, ptr %l1
  %t40 = trunc i64 4 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t43 = load double, ptr %l6, !tbaa !26
  %t44 = load double, ptr %l7, !tbaa !26
  %t47 = fsub double %t43, %t44
  %t49 = bitcast double %t47 to i64
  store i64 %t49, ptr %l23, !tbaa !24
  br label %bb25
bb11:
  %t52 = load i32, ptr %l1
  %t54 = trunc i64 5 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t57 = load double, ptr %l6, !tbaa !26
  %t58 = load double, ptr %l7, !tbaa !26
  %t61 = fmul double %t57, %t58
  %t63 = bitcast double %t61 to i64
  store i64 %t63, ptr %l23, !tbaa !24
  br label %bb25
bb15:
  %t66 = load i32, ptr %l1
  %t68 = trunc i64 6 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t71 = load double, ptr %l6, !tbaa !26
  %t72 = load double, ptr %l7, !tbaa !26
  %t75 = fdiv double %t71, %t72
  %t77 = bitcast double %t75 to i64
  store i64 %t77, ptr %l23, !tbaa !24
  br label %bb25
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1
  %t82 = load double, ptr %l6, !tbaa !26
  %t83 = load double, ptr %l7, !tbaa !26
  %t88 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatCompare(ptr %v0, ptr %t80, i32 %t81, double %t82, double %t83)
  store i64 %t88, ptr %l56
  br label %bb23
bb23:
  %t89 = load i64, ptr %l56, !tbaa !24
  store i64 %t89, ptr %l23, !tbaa !24
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_d784dcd9713515f8_b9d041eddaa630c)
  unreachable
bb25:
  %t90 = load i64, ptr %l23, !tbaa !24
  store i64 %t90, ptr %rv
  br label %ret
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l2, !tbaa !24
  %t93 = load i32, ptr %l4, !tbaa !23
  %t97 = call double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %t91, i64 %t92, i32 %t93)
  store double %t97, ptr %l60
  br label %bb27
bb27:
  %t98 = load double, ptr %l60, !tbaa !26
  %t99 = fptrunc double %t98 to float
  store float %t99, ptr %l8, !tbaa !25
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i64, ptr %l3, !tbaa !24
  %t103 = load i32, ptr %l4, !tbaa !23
  %t107 = call double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %t101, i64 %t102, i32 %t103)
  store double %t107, ptr %l65
  br label %bb28
bb28:
  %t108 = load double, ptr %l65, !tbaa !26
  %t109 = fptrunc double %t108 to float
  store float %t109, ptr %l9, !tbaa !25
  %t111 = load i32, ptr %l1
  %t113 = trunc i64 3 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t116 = load float, ptr %l8, !tbaa !25
  %t117 = load float, ptr %l9, !tbaa !25
  %t120 = fadd float %t116, %t117
  store float %t120, ptr %l67, !tbaa !25
  br label %bb49
bb32:
  %t122 = load i32, ptr %l1
  %t124 = trunc i64 4 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t127 = load float, ptr %l8, !tbaa !25
  %t128 = load float, ptr %l9, !tbaa !25
  %t131 = fsub float %t127, %t128
  store float %t131, ptr %l67, !tbaa !25
  br label %bb49
bb36:
  %t133 = load i32, ptr %l1
  %t135 = trunc i64 5 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t138 = load float, ptr %l8, !tbaa !25
  %t139 = load float, ptr %l9, !tbaa !25
  %t142 = fmul float %t138, %t139
  store float %t142, ptr %l67, !tbaa !25
  br label %bb49
bb40:
  %t144 = load i32, ptr %l1
  %t146 = trunc i64 6 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  %t149 = load float, ptr %l8, !tbaa !25
  %t150 = load float, ptr %l9, !tbaa !25
  %t153 = fdiv float %t149, %t150
  store float %t153, ptr %l67, !tbaa !25
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store float 0x0000000000000000, ptr %l67, !tbaa !25
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_d2031ca5bdc3c0c9_c1504039d0cd1a3d)
  unreachable
bb49:
  %t155 = load float, ptr %l67, !tbaa !25
  store float %t155, ptr %l10, !tbaa !25
  %t156 = load i32, ptr %l1
  %t158 = trunc i64 3 to i32
  %t159 = icmp eq i32 %t156, %t158
  br i1 %t159, label %bb50, label %bb51
bb50:
  br label %bb58
bb51:
  %t161 = load i32, ptr %l1
  %t163 = trunc i64 4 to i32
  %t164 = icmp eq i32 %t161, %t163
  br i1 %t164, label %bb52, label %bb53
bb52:
  br label %bb58
bb53:
  %t166 = load i32, ptr %l1
  %t168 = trunc i64 5 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb54, label %bb55
bb54:
  br label %bb58
bb55:
  %t171 = load i32, ptr %l1
  %t173 = trunc i64 6 to i32
  %t174 = icmp eq i32 %t171, %t173
  br i1 %t174, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb65
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l1
  %t178 = load float, ptr %l8, !tbaa !25
  %t180 = fpext float %t178 to double
  %t181 = load float, ptr %l9, !tbaa !25
  %t183 = fpext float %t181 to double
  %t188 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatCompare(ptr %v0, ptr %t176, i32 %t177, double %t180, double %t183)
  store i64 %t188, ptr %l102
  br label %bb63
bb63:
  %t189 = load i64, ptr %l102, !tbaa !24
  store i64 %t189, ptr %rv
  br label %ret
bb64:
  call void @__olang_check_failed(ptr @olang_loc_82c834935ab97012_8fe8672257be0a6)
  unreachable
bb65:
  %t190 = load i32, ptr %l5, !tbaa !23
  %t192 = icmp eq i32 %t190, 13
  br i1 %t192, label %bb66, label %bb67
bb66:
  %t194 = load float, ptr %l10, !tbaa !25
  %t196 = bitcast float %t194 to i32
  %t198 = zext i32 %t196 to i64
  store i64 %t198, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load float, ptr %l10, !tbaa !25
  %t203 = fpext float %t201 to double
  %t204 = load i32, ptr %l4, !tbaa !23
  %t208 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efromF64(ptr %v0, ptr %t200, double %t203, i32 %t204)
  store i64 %t208, ptr %l112
  br label %bb69
bb69:
  %t209 = load i64, ptr %l112, !tbaa !24
  store i64 %t209, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efromF64(ptr %v0, ptr %a0, double %a1, i32 %a2) #0 {
entry:
  %l1 = alloca double
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %rv = alloca i64
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a2)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load i32, ptr %l3, !tbaa !23
  %t12 = icmp eq i32 %t10, 11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load double, ptr %l1, !tbaa !26
  %t16 = fptrunc double %t14 to half
  %t18 = bitcast half %t16 to i16
  %t19 = call i16 asm "", "=r,0"(i16 %t18)
  %t21 = zext i16 %t19 to i64
  store i64 %t21, ptr %l8, !tbaa !24
  br label %bb18
bb5:
  %t23 = load i32, ptr %l3, !tbaa !23
  %t25 = icmp eq i32 %t23, 12
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t27 = load double, ptr %l1, !tbaa !26
  %t29 = fptrunc double %t27 to bfloat
  %t31 = bitcast bfloat %t29 to i16
  %t32 = call i16 asm "", "=r,0"(i16 %t31)
  %t34 = zext i16 %t32 to i64
  store i64 %t34, ptr %l8, !tbaa !24
  br label %bb18
bb9:
  %t36 = load i32, ptr %l3, !tbaa !23
  %t38 = icmp eq i32 %t36, 13
  br i1 %t38, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t40 = load double, ptr %l1, !tbaa !26
  %t42 = fptrunc double %t40 to float
  %t44 = bitcast float %t42 to i32
  %t46 = zext i32 %t44 to i64
  store i64 %t46, ptr %l8, !tbaa !24
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t48 = load double, ptr %l1, !tbaa !26
  %t50 = bitcast double %t48 to i64
  store i64 %t50, ptr %l8, !tbaa !24
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_463be9bfcfc802eb_383f1498b2d4337)
  unreachable
bb18:
  %t53 = load i64, ptr %l8, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenOver(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [7 x i64] } %a3, i64 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l6 = alloca %"compiler/mir:Call"
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i64
  %l17 = alloca %"compiler/mir:Fn"
  %l20 = alloca %"compiler/mir:Call"
  %l25 = alloca i64
  %l29 = alloca %"compiler/mir:Fn"
  %l32 = alloca ptr
  %l36 = alloca %"compiler/mir:Fn"
  %l38 = alloca i32
  %l40 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l53 = alloca i64
  %l54 = alloca ptr
  %l58 = alloca %"compiler/eval:Ptr"
  %t12 = alloca %"compiler/mir:Fn", align 8
  %t35 = alloca %"compiler/mir:Fn", align 8
  %t49 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr @G_2ecompiler_2feval_2erCall, !tbaa !24
  %t5 = icmp ne i64 %a4, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l14
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %ret
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %t12, ptr %v0, ptr %v0, ptr %t10, i64 %t11)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t12, i64 248, i1 false)
  br label %bb5
bb5:
  %t15 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 14
  %t19 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t15, i64 %a5)
  store %"compiler/mir:Call" %t19, ptr %l20
  br label %bb6
bb6:
  %t20 = load %"compiler/mir:Call", ptr %l20
  store %"compiler/mir:Call" %t20, ptr %l6
  %t21 = getelementptr %"compiler/mir:Call", ptr %l6, i32 0, i32 7
  %t22 = load i32, ptr %t21, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t26 = icmp eq i32 %t22, %t23
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l25
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %ret
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/eval:Machine", ptr %t31, i32 0, i32 16
  %t34 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t35, ptr %v0, ptr %v0, ptr %t33, i64 %t34)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t35, i64 248, i1 false)
  br label %bb11
bb11:
  %t38 = getelementptr %"compiler/mir:Fn", ptr %l29, i32 0, i32 26
  %t39 = load i64, ptr %t38, !tbaa !24
  store i64 %t39, ptr %l7, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/eval:Machine", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l32, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/eval:Machine", ptr %t45, i32 0, i32 16
  %t48 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t49, ptr %v0, ptr %v0, ptr %t47, i64 %t48)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t49, i64 248, i1 false)
  br label %bb12
bb12:
  %t52 = getelementptr %"compiler/mir:Fn", ptr %l36, i32 0, i32 1
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t54, i32 %t53)
  store i32 %t56, ptr %l38
  br label %bb13
bb13:
  %t57 = load i32, ptr %l38, !tbaa !23
  store i32 %t57, ptr %l8, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/eval:Machine", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l40, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l1, !tbaa !24
  %t68 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecalleeType(ptr %v0, ptr %t62, i64 %t63, { i64, [7 x i64] } %a3)
  store i32 %t68, ptr %l44
  br label %bb14
bb14:
  %t69 = load ptr, ptr %l40, !tbaa !29
  %t70 = load i32, ptr %l44, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t71, ptr %l45
  br label %bb15
bb15:
  %t72 = load i32, ptr %l45, !tbaa !23
  store i32 %t72, ptr %l9, !tbaa !23
  %t73 = load i32, ptr %l8, !tbaa !23
  %t74 = load i32, ptr %l9, !tbaa !23
  %t77 = icmp ne i32 %t73, %t74
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i64, ptr %l7, !tbaa !24
  %t81 = load i32, ptr %l8, !tbaa !23
  %t82 = load i32, ptr %l9, !tbaa !23
  %t87 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erecode(ptr %v0, ptr %t79, i64 %t80, i32 %t81, i32 %t82)
  store i64 %t87, ptr %l53
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t88 = load i64, ptr %l53, !tbaa !24
  store i64 %t88, ptr %l7, !tbaa !24
  br label %bb19
bb19:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l54, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l1, !tbaa !24
  %t92 = getelementptr %"compiler/mir:Call", ptr %l6, i32 0, i32 6
  %t93 = load i32, ptr %t92, !tbaa !23
  %t97 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t90, i64 %t91, i32 %t93)
  store %"compiler/eval:Ptr" %t97, ptr %l58
  br label %bb20
bb20:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t99 = load ptr, ptr %l54, !tbaa !29
  %t100 = load %"compiler/eval:Ptr", ptr %l58
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t99, %"compiler/eval:Ptr" %t100, i64 4, i64 %t98)
  br label %bb21
bb21:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l1, !tbaa !24
  %t104 = getelementptr %"compiler/mir:Call", ptr %l6, i32 0, i32 7
  %t105 = load i32, ptr %t104, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %t102, i64 %t103, i32 %t105)
  br label %bb22
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2egrow(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l35 = alloca ptr
  %l37 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l81 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i64
  %l114 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/eval:Machine", ptr %t2, i32 0, i32 36
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = mul i64 8, %t7
  %t12 = icmp sle i64 %t1, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 36
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = mul i64 8, %t19
  store i64 %t21, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t23 = load i64, ptr %l2, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = mul i64 %t31, 2
  store i64 %t33, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb4
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/eval:Machine", ptr %t35, i32 0, i32 36
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l3, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l35, !tbaa !29
  %t41 = load i64, ptr %l2, !tbaa !24
  %t43 = sdiv i64 %t41, 8
  store i64 %t43, ptr %l37, !tbaa !24
  %t44 = load i64, ptr %l37, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load i64, ptr %l37, !tbaa !24
  %t48 = icmp sle i64 %t47, 1152921504606846975
  br i1 %t48, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8ee299e344af3927_1a30263e89afea2b)
  unreachable
bb12:
  %t50 = load i64, ptr %l37, !tbaa !24
  %t51 = mul i64 %t50, 8
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t56 = load ptr, ptr %l35, !tbaa !29
  %t57 = getelementptr %"compiler/eval:Machine", ptr %t56, i32 0, i32 36
  store { i64, ptr } %t54, ptr %t57, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/eval:Machine", ptr %t58, i32 0, i32 38
  %t61 = load i64, ptr %t60, !tbaa !24
  %t63 = add i64 %t61, 7
  %t65 = sdiv i64 %t63, 8
  store i64 %t65, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8ee299e344af3927_1a30263e89afea2b)
  unreachable
bb14:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb19
bb16:
  %t77 = load i64, ptr %l5, !tbaa !24
  %t78 = load i64, ptr %l4, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l51, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb18
bb18:
  %t93 = load i64, ptr %l51, !tbaa !24
  store i64 %t93, ptr %l48, !tbaa !24
  br label %bb19
bb19:
  %t94 = load i64, ptr %l48, !tbaa !24
  store i64 %t94, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  %t95 = load i64, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  br label %bb23
bb23:
  %t103 = load i64, ptr %l4, !tbaa !24
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  store i64 %t111, ptr %l9, !tbaa !24
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/eval:Machine", ptr %t113, i32 0, i32 36
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l70, !tbaa !27
  %t117 = load i64, ptr %l9, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t118, ptr %l72, !tbaa !27
  %t119 = load i64, ptr %l9, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i64, ptr %t122, i64 %t119
  %t124 = load i64, ptr %t123, !tbaa !34
  %t127 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i64, ptr %t128, i64 %t117
  store i64 %t124, ptr %t129, !tbaa !34
  br label %bb24
bb24:
  %t130 = load i64, ptr %l8, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l8, !tbaa !24
  br label %bb20
bb25:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/eval:Machine", ptr %t134, i32 0, i32 37
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l10, !tbaa !27
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l79, !tbaa !29
  %t140 = load i64, ptr %l2, !tbaa !24
  %t142 = sdiv i64 %t140, 8
  store i64 %t142, ptr %l81, !tbaa !24
  %t143 = load i64, ptr %l81, !tbaa !24
  %t144 = icmp sge i64 %t143, 0
  br i1 %t144, label %bb26, label %bb27
bb26:
  %t146 = load i64, ptr %l81, !tbaa !24
  %t147 = icmp sle i64 %t146, 1152921504606846975
  br i1 %t147, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_9d9a614f49301d32_780986365d0a3a16)
  unreachable
bb28:
  %t149 = load i64, ptr %l81, !tbaa !24
  %t150 = mul i64 %t149, 8
  %t151 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  %t155 = load ptr, ptr %l79, !tbaa !29
  %t156 = getelementptr %"compiler/eval:Machine", ptr %t155, i32 0, i32 37
  store { i64, ptr } %t153, ptr %t156, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/eval:Machine", ptr %t157, i32 0, i32 38
  %t160 = load i64, ptr %t159, !tbaa !24
  %t162 = add i64 %t160, 7
  %t164 = sdiv i64 %t162, 8
  store i64 %t164, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t166 = load i64, ptr %l12, !tbaa !24
  %t167 = load i64, ptr %l11, !tbaa !24
  %t170 = icmp sgt i64 %t166, %t167
  br i1 %t170, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_9d9a614f49301d32_780986365d0a3a16)
  unreachable
bb30:
  %t172 = load i64, ptr %l13, !tbaa !24
  %t174 = icmp sgt i64 %t172, 0
  br i1 %t174, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb35
bb32:
  %t176 = load i64, ptr %l12, !tbaa !24
  %t177 = load i64, ptr %l11, !tbaa !24
  %t180 = sub i64 %t176, %t177
  %t181 = load i64, ptr %l13, !tbaa !24
  %t184 = add i64 %t180, %t181
  %t186 = sub i64 %t184, 1
  %t187 = load i64, ptr %l13, !tbaa !24
  %t190 = sdiv i64 %t186, %t187
  store i64 %t190, ptr %l95, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb34
bb34:
  %t192 = load i64, ptr %l95, !tbaa !24
  store i64 %t192, ptr %l92, !tbaa !24
  br label %bb35
bb35:
  %t193 = load i64, ptr %l92, !tbaa !24
  store i64 %t193, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb36
bb36:
  %t194 = load i64, ptr %l15, !tbaa !24
  %t195 = load i64, ptr %l14, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  br label %bb39
bb39:
  %t202 = load i64, ptr %l11, !tbaa !24
  %t203 = load i64, ptr %l15, !tbaa !24
  %t204 = load i64, ptr %l13, !tbaa !24
  %t207 = mul i64 %t203, %t204
  %t210 = add i64 %t202, %t207
  store i64 %t210, ptr %l16, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/eval:Machine", ptr %t212, i32 0, i32 37
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l114, !tbaa !27
  %t216 = load i64, ptr %l16, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t217, ptr %l116, !tbaa !27
  %t218 = load i64, ptr %l16, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr i64, ptr %t221, i64 %t218
  %t223 = load i64, ptr %t222, !tbaa !34
  %t226 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i64, ptr %t227, i64 %t216
  store i64 %t223, ptr %t228, !tbaa !34
  br label %bb40
bb40:
  %t229 = load i64, ptr %l15, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l15, !tbaa !24
  br label %bb36
bb41:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eheldScope(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca %"compiler/eval:Ptr"
  %l9 = alloca i64
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l4, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t9 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t3, i64 %a1, i32 %a2)
  store %"compiler/eval:Ptr" %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t11 = load %"compiler/eval:Ptr", ptr %l8
  %t12 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t10, %"compiler/eval:Ptr" %t11, i64 8)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i32, ptr @G_2ecompiler_2fmir_2eI64T, !tbaa !23
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i64, ptr %l9, !tbaa !24
  %t17 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t14, i64 %t15, i32 %t13)
  store i64 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i64, ptr %l11, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ei64(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i64
  %l7 = alloca i1
  %l10 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = icmp eq i64 %t16, 64
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l7, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloadCaptures(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/eval:Ptr" %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/eval:Ptr"
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { { i64, ptr }, i64 }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l31 = alloca i64
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l62 = alloca i64
  %l64 = alloca ptr
  %l68 = alloca i32
  %l70 = alloca %"compiler/mir:Local"
  %l76 = alloca { { i64, ptr }, i64 }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l83 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca i64
  %l114 = alloca i32
  %l115 = alloca %"compiler/eval:Ptr"
  %l121 = alloca %"compiler/eval:Ptr"
  %l125 = alloca i64
  %l128 = alloca i64
  %l131 = alloca i64
  %l134 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca ptr
  %l151 = alloca %"compiler/eval:Ptr"
  %l152 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/eval:Ptr" %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/mir:Fn", ptr %t1, i32 0, i32 5
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t3)
  store i64 %t5, ptr %l23
  br label %bb1
bb1:
  %t6 = load i64, ptr %l23, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 0
  %t10 = load i64, ptr %t9, !tbaa !24
  %t12 = icmp eq i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNullCall, !tbaa !27
  %t16 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t16, ptr %t14, { i64, ptr } %t15)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/mir:Fn", ptr %t19, i32 0, i32 5
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t21)
  store i64 %t23, ptr %l31
  br label %bb9
bb9:
  %t24 = load i64, ptr %l31, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = load i64, ptr %l31, !tbaa !24
  %t28 = icmp sle i64 %t27, 2305843009213693951
  br i1 %t28, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_d3df02eef027536f_dc15be465081b3fb)
  unreachable
bb12:
  %t30 = load i64, ptr %l31, !tbaa !24
  %t31 = mul i64 %t30, 4
  %t32 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/mir:Fn", ptr %t36, i32 0, i32 5
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t38)
  store i64 %t40, ptr %l37
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_d3df02eef027536f_dc15be465081b3fb)
  unreachable
bb14:
  %t41 = load i64, ptr %l37, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb20
bb17:
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l44, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb19
bb19:
  %t68 = load i64, ptr %l44, !tbaa !24
  store i64 %t68, ptr %l41, !tbaa !24
  br label %bb20
bb20:
  %t69 = load i64, ptr %l41, !tbaa !24
  store i64 %t69, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  %t70 = load i64, ptr %l10, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb22, label %bb23
bb22:
  br label %bb28
bb23:
  br label %bb24
bb24:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  store i64 %t86, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l11, !tbaa !24
  store i64 %t88, ptr %l62, !tbaa !24
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t91 = getelementptr %"compiler/mir:Fn", ptr %t89, i32 0, i32 7
  store ptr %t91, ptr %l64, !tbaa !29
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t94 = getelementptr %"compiler/mir:Fn", ptr %t92, i32 0, i32 5
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t94, i64 %t95)
  store i32 %t98, ptr %l68
  br label %bb25
bb25:
  %t99 = load i32, ptr %l68, !tbaa !23
  %t100 = sext i32 %t99 to i64
  %t101 = load ptr, ptr %l64, !tbaa !29
  %t103 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t101, i64 %t100)
  store %"compiler/mir:Local" %t103, ptr %l70
  br label %bb26
bb26:
  %t104 = getelementptr %"compiler/mir:Local", ptr %l70, i32 0, i32 2
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = load i64, ptr %l62, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 %t107
  store i32 %t105, ptr %t110, !tbaa !33
  br label %bb27
bb27:
  %t111 = load i64, ptr %l10, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l10, !tbaa !24
  br label %bb21
bb28:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t119 = call { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2epack(ptr %v0, ptr %s0, ptr %s0, ptr %t115, { i64, ptr } %t116)
  store { { i64, ptr }, i64 } %t119, ptr %l76
  br label %bb29
bb29:
  %t120 = load { { i64, ptr }, i64 }, ptr %l76
  store { { i64, ptr }, i64 } %t120, ptr %l12
  %t121 = getelementptr { { i64, ptr }, i64 }, ptr %l12, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l77, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l78, !tbaa !24
  %t125 = load i64, ptr %l78, !tbaa !24
  %t126 = mul i64 %t125, 8
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l79, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l78, !tbaa !24
  %t135 = mul i64 %t134, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t136, ptr %l13, !tbaa !27
  %t137 = getelementptr { { i64, ptr }, i64 }, ptr %l12, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  store i64 %t138, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t142 = getelementptr %"compiler/mir:Fn", ptr %t140, i32 0, i32 5
  %t144 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t142)
  store i64 %t144, ptr %l83
  br label %bb30
bb30:
  %t145 = load i64, ptr %l83, !tbaa !24
  store i64 %t145, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t146 = load i64, ptr %l16, !tbaa !24
  %t147 = load i64, ptr %l15, !tbaa !24
  %t150 = icmp sgt i64 %t146, %t147
  br i1 %t150, label %bb31, label %bb32
bb31:
  %t152 = load i64, ptr %l17, !tbaa !24
  %t154 = icmp sgt i64 %t152, 0
  br i1 %t154, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb36
bb33:
  %t156 = load i64, ptr %l16, !tbaa !24
  %t157 = load i64, ptr %l15, !tbaa !24
  %t160 = sub i64 %t156, %t157
  %t161 = load i64, ptr %l17, !tbaa !24
  %t164 = add i64 %t160, %t161
  %t166 = sub i64 %t164, 1
  %t167 = load i64, ptr %l17, !tbaa !24
  %t170 = sdiv i64 %t166, %t167
  store i64 %t170, ptr %l90, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb35
bb35:
  %t172 = load i64, ptr %l90, !tbaa !24
  store i64 %t172, ptr %l87, !tbaa !24
  br label %bb36
bb36:
  %t173 = load i64, ptr %l87, !tbaa !24
  store i64 %t173, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t174 = load i64, ptr %l19, !tbaa !24
  %t175 = load i64, ptr %l18, !tbaa !24
  %t178 = icmp slt i64 %t174, %t175
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb39:
  br label %bb40
bb40:
  %t182 = load i64, ptr %l15, !tbaa !24
  %t183 = load i64, ptr %l19, !tbaa !24
  %t184 = load i64, ptr %l17, !tbaa !24
  %t187 = mul i64 %t183, %t184
  %t190 = add i64 %t182, %t187
  store i64 %t190, ptr %l20, !tbaa !24
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l108, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l109, !tbaa !29
  %t194 = load i64, ptr %l1, !tbaa !24
  store i64 %t194, ptr %l110, !tbaa !24
  %t195 = load ptr, ptr %l2, !tbaa !29
  %t197 = getelementptr %"compiler/mir:Fn", ptr %t195, i32 0, i32 5
  %t198 = load i64, ptr %l20, !tbaa !24
  %t201 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v1, ptr %t197, i64 %t198)
  store i32 %t201, ptr %l114
  br label %bb41
bb41:
  %t202 = load ptr, ptr %l109, !tbaa !29
  %t203 = load i64, ptr %l110, !tbaa !24
  %t204 = load i32, ptr %l114, !tbaa !23
  %t205 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t202, i64 %t203, i32 %t204)
  store %"compiler/eval:Ptr" %t205, ptr %l115
  br label %bb42
bb42:
  %t206 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 0
  %t207 = load i64, ptr %t206, !tbaa !24
  %t208 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 1
  %t209 = load i64, ptr %t208, !tbaa !24
  %t210 = load i64, ptr %l20, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i64, ptr %t213, i64 %t210
  %t215 = load i64, ptr %t214, !tbaa !34
  %t218 = add i64 %t209, %t215
  %t221 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s7, i64 %t207, i64 %t218)
  store %"compiler/eval:Ptr" %t221, ptr %l121
  br label %bb43
bb43:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i64, ptr %l20, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i32, ptr %t226, i64 %t223
  %t228 = load i32, ptr %t227, !tbaa !33
  %t231 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t222, i32 %t228)
  store i64 %t231, ptr %l125
  br label %bb44
bb44:
  %t232 = load ptr, ptr %l108, !tbaa !29
  %t233 = load %"compiler/eval:Ptr", ptr %l115
  %t234 = load %"compiler/eval:Ptr", ptr %l121
  %t235 = load i64, ptr %l125, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t232, %"compiler/eval:Ptr" %t233, %"compiler/eval:Ptr" %t234, i64 %t235)
  br label %bb45
bb45:
  %t236 = load i64, ptr %l4, !tbaa !24
  %t237 = load i64, ptr %l20, !tbaa !24
  %t240 = add i64 %t236, %t237
  store i64 %t240, ptr %l128, !tbaa !24
  %t241 = load ptr, ptr %l2, !tbaa !29
  %t243 = getelementptr %"compiler/mir:Fn", ptr %t241, i32 0, i32 6
  %t245 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v1, ptr %t243)
  store i64 %t245, ptr %l131
  br label %bb46
bb46:
  %t246 = load i64, ptr %l128, !tbaa !24
  %t247 = load i64, ptr %l131, !tbaa !24
  %t248 = icmp slt i64 %t246, %t247
  br i1 %t248, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s8
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/eval:Machine", ptr %t250, i32 0, i32 51
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  store { i64, ptr } %t253, ptr %l134, !tbaa !27
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/eval:Machine", ptr %t254, i32 0, i32 49
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  store { i64, ptr } %t257, ptr %l136, !tbaa !27
  %t258 = load i64, ptr %l1, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr %"compiler/eval:frame", ptr %t261, i64 %t258
  %t263 = getelementptr %"compiler/eval:frame", ptr %t262, i32 0, i32 5
  %t264 = load i64, ptr %t263, !tbaa !24
  %t265 = load i64, ptr %l4, !tbaa !24
  %t268 = add i64 %t264, %t265
  %t269 = load i64, ptr %l20, !tbaa !24
  %t272 = add i64 %t268, %t269
  store i64 %t272, ptr %l142, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l143, !tbaa !29
  %t274 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 0
  %t275 = load i64, ptr %t274, !tbaa !24
  %t276 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 1
  %t277 = load i64, ptr %t276, !tbaa !24
  %t278 = load i64, ptr %l14, !tbaa !24
  %t281 = add i64 %t277, %t278
  %t282 = load i64, ptr %l20, !tbaa !24
  %t284 = mul i64 8, %t282
  %t287 = add i64 %t281, %t284
  %t290 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s8, i64 %t275, i64 %t287)
  store %"compiler/eval:Ptr" %t290, ptr %l151
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t291 = load ptr, ptr %l143, !tbaa !29
  %t292 = load %"compiler/eval:Ptr", ptr %l151
  %t293 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t291, %"compiler/eval:Ptr" %t292, i64 8)
  store i64 %t293, ptr %l152
  br label %bb50
bb50:
  %t294 = load i64, ptr %l152, !tbaa !24
  %t295 = load i64, ptr %l142, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr i64, ptr %t297, i64 %t295
  store i64 %t294, ptr %t298, !tbaa !34
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb52:
  %t299 = load i64, ptr %l19, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l19, !tbaa !24
  br label %bb37
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/eval:alloc"
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l27 = alloca i1
  %l32 = alloca ptr
  %l34 = alloca %"compiler/eval:Ptr"
  %l37 = alloca i64
  %l39 = alloca { i64, ptr }
  %l45 = alloca i1
  %l48 = alloca i64
  %l51 = alloca i1
  %l55 = alloca ptr
  %l57 = alloca %"compiler/eval:Ptr"
  %l60 = alloca i64
  %l62 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i1
  %l80 = alloca %"compiler/eval:global"
  %l83 = alloca ptr
  %l85 = alloca %"compiler/eval:Ptr"
  %l88 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 51
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l9, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 49
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l11, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i64 %a1
  %t14 = getelementptr %"compiler/eval:frame", ptr %t13, i32 0, i32 3
  %t15 = load i64, ptr %t14, !tbaa !24
  %t19 = add i64 %t15, %a2
  %t21 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i64, ptr %t22, i64 %t19
  %t24 = load i64, ptr %t23, !tbaa !34
  store i64 %t24, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp eq i64 %t26, 0
  br i1 %t28, label %bb1, label %bb2
bb1:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  %t32 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t32, ptr %t30, { i64, ptr } %t31)
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i64 -1, ptr %rv
  br label %ret
bb4:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t40 = and i64 %t36, %t37
  store i64 %t40, ptr %l6, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 13
  %t45 = load i1, ptr %t44, !tbaa !21
  br i1 %t45, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb7
bb6:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/eval:Machine", ptr %t48, i32 0, i32 41
  %t51 = load i64, ptr %t50, !tbaa !24
  %t54 = icmp sge i64 %t47, %t51
  store i1 %t54, ptr %l27, !tbaa !21
  br label %bb7
bb7:
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t58, i64 0)
  store %"compiler/eval:Ptr" %t60, ptr %l34
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i1, ptr %l4, !tbaa !21
  %t63 = load ptr, ptr %l32, !tbaa !29
  %t64 = load %"compiler/eval:Ptr", ptr %l34
  %t67 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t63, %"compiler/eval:Ptr" %t64, i64 %t61, i1 %t62)
  store i64 %t67, ptr %l37
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  %t68 = load i64, ptr %l37, !tbaa !24
  store i64 %t68, ptr %rv
  br label %ret
bb12:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/eval:Machine", ptr %t69, i32 0, i32 40
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l39, !tbaa !27
  %t73 = load i64, ptr %l6, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"compiler/eval:alloc", ptr %t76, i64 %t73
  %t78 = load %"compiler/eval:alloc", ptr %t77
  store %"compiler/eval:alloc" %t78, ptr %l7
  %t80 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 4
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t85 = icmp eq i64 %t81, %t82
  br i1 %t85, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb15
bb14:
  %t87 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load i64, ptr %l5, !tbaa !24
  %t90 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t90, ptr %l48, !tbaa !24
  %t92 = load i64, ptr %l48, !tbaa !24
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = ashr i64 %t89, %t93
  %t97 = icmp ne i64 %t88, %t94
  store i1 %t97, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t99 = load i1, ptr %l45, !tbaa !21
  br i1 %t99, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb18
bb17:
  %t100 = load i64, ptr %l3, !tbaa !24
  %t101 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 1
  %t102 = load i64, ptr %t101, !tbaa !24
  %t105 = icmp sgt i64 %t100, %t102
  store i1 %t105, ptr %l51, !tbaa !21
  br label %bb18
bb18:
  %t107 = load i1, ptr %l51, !tbaa !21
  br i1 %t107, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l55, !tbaa !29
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t109, i64 0)
  store %"compiler/eval:Ptr" %t111, ptr %l57
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t113 = load i1, ptr %l4, !tbaa !21
  %t114 = load ptr, ptr %l55, !tbaa !29
  %t115 = load %"compiler/eval:Ptr", ptr %l57
  %t118 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t114, %"compiler/eval:Ptr" %t115, i64 %t112, i1 %t113)
  store i64 %t118, ptr %l60
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  %t119 = load i64, ptr %l60, !tbaa !24
  store i64 %t119, ptr %rv
  br label %ret
bb23:
  %t120 = load i1, ptr %l4, !tbaa !21
  br i1 %t120, label %bb24, label %bb25
bb24:
  %t122 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 10
  %t123 = load i1, ptr %t122, !tbaa !21
  br i1 %t123, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb39
bb26:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb38
bb27:
  %t125 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 8
  %t126 = load i64, ptr %t125, !tbaa !24
  %t128 = icmp sge i64 %t126, 0
  br i1 %t128, label %bb28, label %bb29
bb28:
  %t130 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 8
  %t131 = load i64, ptr %t130, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/eval:Machine", ptr %t132, i32 0, i32 64
  %t135 = load i64, ptr %t134, !tbaa !24
  %t138 = icmp ne i64 %t131, %t135
  store i1 %t138, ptr %l67, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb30
bb30:
  %t140 = load i1, ptr %l67, !tbaa !21
  br i1 %t140, label %bb31, label %bb32
bb31:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/eval:Machine", ptr %t141, i32 0, i32 1
  %t144 = load i32, ptr %t143
  %t146 = trunc i64 0 to i32
  %t147 = icmp eq i32 %t144, %t146
  br i1 %t147, label %bb33, label %bb34
bb32:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb37
bb33:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb36
bb34:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/eval:Machine", ptr %t149, i32 0, i32 33
  %t152 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 8
  %t153 = load i64, ptr %t152, !tbaa !24
  %t156 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t151, i64 %t153)
  store %"compiler/eval:global" %t156, ptr %l80
  br label %bb35
bb35:
  %t157 = getelementptr %"compiler/eval:global", ptr %l80, i32 0, i32 1
  %t158 = load i1, ptr %t157, !tbaa !21
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l76, !tbaa !21
  br label %bb36
bb36:
  %t162 = load i1, ptr %l76, !tbaa !21
  store i1 %t162, ptr %l72, !tbaa !21
  br label %bb37
bb37:
  %t163 = load i1, ptr %l72, !tbaa !21
  store i1 %t163, ptr %l64, !tbaa !21
  br label %bb38
bb38:
  %t164 = load i1, ptr %l64, !tbaa !21
  store i1 %t164, ptr %l62, !tbaa !21
  br label %bb39
bb39:
  %t165 = load i1, ptr %l62, !tbaa !21
  br i1 %t165, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l83, !tbaa !29
  %t167 = load i64, ptr %l5, !tbaa !24
  %t169 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t167, i64 0)
  store %"compiler/eval:Ptr" %t169, ptr %l85
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t170 = load i64, ptr %l3, !tbaa !24
  %t171 = load i1, ptr %l4, !tbaa !21
  %t172 = load ptr, ptr %l83, !tbaa !29
  %t173 = load %"compiler/eval:Ptr", ptr %l85
  %t176 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t172, %"compiler/eval:Ptr" %t173, i64 %t170, i1 %t171)
  store i64 %t176, ptr %l88
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  %t177 = load i64, ptr %l88, !tbaa !24
  store i64 %t177, ptr %rv
  br label %ret
bb44:
  %t178 = getelementptr %"compiler/eval:alloc", ptr %l7, i32 0, i32 0
  %t179 = load i64, ptr %t178, !tbaa !24
  store i64 %t179, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2emutableGlobal(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca %"compiler/eval:gkey"
  %l17 = alloca i64
  %l18 = alloca i32
  %l21 = alloca i1
  %l25 = alloca %"compiler/eval:global"
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i64, i32, i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t14 = getelementptr { i64, i32, i32 }, ptr %t13, i32 0, i32 1
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb13
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 34
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i32, ptr %l4, !tbaa !23
  %t24 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s1, i64 %t20, i32 %t21)
  store %"compiler/eval:gkey" %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load %"compiler/eval:gkey", ptr %l16
  %t27 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t25, %"compiler/eval:gkey" %t26)
  %t28 = extractvalue { i32, i64 } %t27, 1
  %t29 = extractvalue { i32, i64 } %t27, 0
  store i32 %t29, ptr %l18
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31, !prof !99
ok.31:
  store i64 %t28, ptr %l17
  br label %bb5
bb5:
  %t32 = load i64, ptr %l17, !tbaa !24
  store i64 %t32, ptr %l11, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l11, !tbaa !24
  store i64 %t33, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sge i64 %t34, 0
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 33
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t40, i64 %t41)
  store %"compiler/eval:global" %t44, ptr %l25
  br label %bb11
bb10:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb12
bb11:
  %t45 = getelementptr %"compiler/eval:global", ptr %l25, i32 0, i32 1
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t48 = load i1, ptr %l21, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b24244fd0a11c914_466201095dcd7a18)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2enewArray(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, { i64, [1 x i64] } %a3, i32 %a4, { i64, [4 x i64] } %a5, { i64, [4 x i64] } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i1
  %l39 = alloca i1
  %l49 = alloca i64
  %l58 = alloca %"compiler/eval:Ptr"
  %l64 = alloca i1
  %l76 = alloca i64
  %l79 = alloca i64
  %l97 = alloca ptr
  %l102 = alloca %"compiler/eval:Ptr"
  %l110 = alloca ptr
  %l114 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store { i64, [4 x i64] } %a5, ptr %l5
  store { i64, [4 x i64] } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t1, i32 %a4)
  store i32 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i32, ptr %l20, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l21, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load { i64, [4 x i64] }, ptr %l5
  %t14 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t8, i64 %t9, { i64, [4 x i64] } %t10)
  store i64 %t14, ptr %l25
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l1, !tbaa !24
  %t17 = load { i64, [4 x i64] }, ptr %l5
  %t21 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t15, i64 %t16, { i64, [4 x i64] } %t17)
  store i32 %t21, ptr %l29
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l21, !tbaa !29
  %t23 = load i64, ptr %l25, !tbaa !24
  %t24 = load i32, ptr %l29, !tbaa !23
  %t25 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t22, i64 %t23, i32 %t24)
  store i64 %t25, ptr %l30
  br label %bb4
bb4:
  %t26 = load i64, ptr %l30, !tbaa !24
  store i64 %t26, ptr %l8, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l7, !tbaa !23
  %t31 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t27, i32 %t28)
  store i64 %t31, ptr %l33
  br label %bb5
bb5:
  %t32 = load i64, ptr %l33, !tbaa !24
  store i64 %t32, ptr %l9, !tbaa !24
  %t33 = load i64, ptr %l8, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  br i1 %t35, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb11
bb7:
  %t37 = load i64, ptr %l9, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t44 = sdiv i64 1099511627776, %t42
  %t47 = icmp sgt i64 %t41, %t44
  store i1 %t47, ptr %l39, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb10
bb10:
  %t49 = load i1, ptr %l39, !tbaa !21
  store i1 %t49, ptr %l36, !tbaa !21
  br label %bb11
bb11:
  %t50 = load i1, ptr %l36, !tbaa !21
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyLong, !tbaa !27
  %t53 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t53, ptr %t51, { i64, ptr } %t52)
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l1, !tbaa !24
  %t62 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %t56, i64 %t57, { i64, [1 x i64] } %a3)
  store i64 %t62, ptr %l49
  br label %bb16
bb16:
  %t63 = load i64, ptr %l49, !tbaa !24
  store i64 %t63, ptr %l10, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 13
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  br label %bb19
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t75 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t76 = load i64, ptr %l10, !tbaa !24
  %t81 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t69, i64 %t74, i64 %t75, i64 %t76)
  store %"compiler/eval:Ptr" %t81, ptr %l58
  br label %bb20
bb20:
  %t82 = load %"compiler/eval:Ptr", ptr %l58
  store %"compiler/eval:Ptr" %t82, ptr %l11
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/eval:Machine", ptr %t83, i32 0, i32 13
  %t86 = load i1, ptr %t85, !tbaa !21
  br i1 %t86, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t88 = load { i64, [4 x i64] }, ptr %l6
  %t90 = extractvalue { i64, [4 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 0
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb24, label %bb25
bb24:
  %t95 = load i64, ptr %l8, !tbaa !24
  %t97 = icmp sgt i64 %t95, 0
  store i1 %t97, ptr %l64, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb26
bb26:
  %t99 = load i1, ptr %l64, !tbaa !21
  br i1 %t99, label %bb27, label %bb28
bb27:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  %t102 = load %"compiler/eval:Ptr", ptr %l11
  %t103 = load i32, ptr %l7, !tbaa !23
  %t104 = load { i64, [4 x i64] }, ptr %l6
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t100, i64 %t101, %"compiler/eval:Ptr" %t102, i32 %t103, { i64, [4 x i64] } %t104)
  br label %bb29
bb28:
  br label %bb44
bb29:
  store i64 1, ptr %l12, !tbaa !24
  %t110 = load i64, ptr %l8, !tbaa !24
  store i64 %t110, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t112 = load i64, ptr %l13, !tbaa !24
  %t113 = load i64, ptr %l12, !tbaa !24
  %t116 = icmp sgt i64 %t112, %t113
  br i1 %t116, label %bb30, label %bb31
bb30:
  %t118 = load i64, ptr %l14, !tbaa !24
  %t120 = icmp sgt i64 %t118, 0
  br i1 %t120, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb35
bb32:
  %t122 = load i64, ptr %l13, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t126 = sub i64 %t122, %t123
  %t127 = load i64, ptr %l14, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t132 = sub i64 %t130, 1
  %t133 = load i64, ptr %l14, !tbaa !24
  %t136 = sdiv i64 %t132, %t133
  store i64 %t136, ptr %l79, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb34
bb34:
  %t138 = load i64, ptr %l79, !tbaa !24
  store i64 %t138, ptr %l76, !tbaa !24
  br label %bb35
bb35:
  %t139 = load i64, ptr %l76, !tbaa !24
  store i64 %t139, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t140 = load i64, ptr %l16, !tbaa !24
  %t141 = load i64, ptr %l15, !tbaa !24
  %t144 = icmp slt i64 %t140, %t141
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb38:
  br label %bb39
bb39:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t149 = load i64, ptr %l16, !tbaa !24
  %t150 = load i64, ptr %l14, !tbaa !24
  %t153 = mul i64 %t149, %t150
  %t156 = add i64 %t148, %t153
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l97, !tbaa !29
  %t159 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 0
  %t160 = load i64, ptr %t159, !tbaa !24
  %t162 = load i64, ptr %l9, !tbaa !24
  %t165 = mul i64 %t156, %t162
  %t168 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s6, i64 %t160, i64 %t165)
  store %"compiler/eval:Ptr" %t168, ptr %l102
  br label %bb40
bb40:
  %t169 = load %"compiler/eval:Ptr", ptr %l11
  %t170 = load i64, ptr %l9, !tbaa !24
  %t171 = load ptr, ptr %l97, !tbaa !29
  %t172 = load %"compiler/eval:Ptr", ptr %l102
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t171, %"compiler/eval:Ptr" %t172, %"compiler/eval:Ptr" %t169, i64 %t170)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb42:
  %t175 = load i64, ptr %l16, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l16, !tbaa !24
  br label %bb36
bb43:
  br label %bb44
bb44:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load %"compiler/eval:Ptr", ptr %l2
  %t181 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t179, %"compiler/eval:Ptr" %t180, i64 8, i64 %t181)
  br label %bb45
bb45:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l110, !tbaa !29
  %t186 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t187 = load i64, ptr %t186, !tbaa !24
  %t188 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t189 = load i64, ptr %t188, !tbaa !24
  %t191 = add i64 %t189, 8
  %t194 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t187, i64 %t191)
  store %"compiler/eval:Ptr" %t194, ptr %l114
  br label %bb46
bb46:
  %t195 = load %"compiler/eval:Ptr", ptr %l11
  %t196 = load ptr, ptr %l110, !tbaa !29
  %t197 = load %"compiler/eval:Ptr", ptr %l114
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t196, %"compiler/eval:Ptr" %t197, %"compiler/eval:Ptr" %t195)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2enewRef(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, { i64, [1 x i64] } %a3, { i64, [4 x i64] } %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca { i64, [1 x i64] }
  %l4 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca { %"compiler/eval:Ptr", i64 }
  %l9 = alloca %"compiler/eval:Ptr"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/eval:Ptr"
  %l14 = alloca i64
  %l15 = alloca %"compiler/eval:Ptr"
  %l17 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i1
  %l29 = alloca %"compiler/eval:Ptr"
  %l35 = alloca { %"compiler/eval:Ptr", i64 }
  %l43 = alloca i64
  %l46 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca i64
  %l57 = alloca %"compiler/eval:Ptr"
  %l67 = alloca ptr
  %l71 = alloca %"compiler/eval:Ptr"
  %l76 = alloca i64
  %l79 = alloca ptr
  %l82 = alloca i64
  %l85 = alloca %"compiler/eval:Ptr"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store { i64, [1 x i64] } %a3, ptr %l3
  store { i64, [4 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l17, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t8, i32 %a5)
  store i32 %t12, ptr %l21
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t14 = load i32, ptr %l21, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t15, ptr %l22
  br label %bb2
bb2:
  %t16 = load i32, ptr %l22, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l6, !tbaa !23
  %t21 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ertArray(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l25
  br label %bb3
bb3:
  %t22 = load i1, ptr %l25, !tbaa !21
  br i1 %t22, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t25 = load { i64, [4 x i64] }, ptr %l4
  %t29 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t23, i64 %t24, { i64, [4 x i64] } %t25, i64 1)
  store %"compiler/eval:Ptr" %t29, ptr %l29
  br label %bb6
bb5:
  br label %bb28
bb6:
  %t30 = load %"compiler/eval:Ptr", ptr %l29
  store %"compiler/eval:Ptr" %t30, ptr %l7
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/eval:Machine", ptr %t31, i32 0, i32 13
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/eval:Ptr", ptr %l7
  %t38 = load i32, ptr %l6, !tbaa !23
  %t42 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t36, %"compiler/eval:Ptr" %t37, i32 %t38)
  store { %"compiler/eval:Ptr", i64 } %t42, ptr %l35
  br label %bb10
bb10:
  %t43 = load { %"compiler/eval:Ptr", i64 }, ptr %l35
  store { %"compiler/eval:Ptr", i64 } %t43, ptr %l8
  %t44 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 0
  %t45 = load %"compiler/eval:Ptr", ptr %t44
  store %"compiler/eval:Ptr" %t45, ptr %l9
  %t47 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l8, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  store i64 %t48, ptr %l10, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/eval:Machine", ptr %t50, i32 0, i32 13
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load { i64, [1 x i64] }, ptr %l3
  %t61 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %t55, i64 %t56, { i64, [1 x i64] } %t57)
  store i64 %t61, ptr %l43
  br label %bb14
bb14:
  %t62 = load i64, ptr %l43, !tbaa !24
  store i64 %t62, ptr %l11, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/eval:Machine", ptr %t63, i32 0, i32 13
  %t66 = load i1, ptr %t65, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb16:
  br label %bb17
bb17:
  %t68 = load i64, ptr %l10, !tbaa !24
  store i64 %t68, ptr %l46, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l47, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l6, !tbaa !23
  %t74 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l50
  br label %bb18
bb18:
  %t75 = load ptr, ptr %l47, !tbaa !29
  %t76 = load i32, ptr %l50, !tbaa !23
  %t77 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t77, ptr %l51
  br label %bb19
bb19:
  %t78 = load i64, ptr %l46, !tbaa !24
  %t79 = load i64, ptr %l51, !tbaa !24
  %t80 = mul i64 %t78, %t79
  store i64 %t80, ptr %l12, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l12, !tbaa !24
  %t84 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t85 = load i64, ptr %l11, !tbaa !24
  %t90 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t82, i64 %t83, i64 %t84, i64 %t85)
  store %"compiler/eval:Ptr" %t90, ptr %l57
  br label %bb20
bb20:
  %t91 = load %"compiler/eval:Ptr", ptr %l57
  store %"compiler/eval:Ptr" %t91, ptr %l13
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/eval:Machine", ptr %t92, i32 0, i32 13
  %t95 = load i1, ptr %t94, !tbaa !21
  br i1 %t95, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load %"compiler/eval:Ptr", ptr %l13
  %t99 = load %"compiler/eval:Ptr", ptr %l9
  %t100 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t97, %"compiler/eval:Ptr" %t98, %"compiler/eval:Ptr" %t99, i64 %t100)
  br label %bb24
bb24:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load %"compiler/eval:Ptr", ptr %l2
  %t107 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t105, %"compiler/eval:Ptr" %t106, i64 8, i64 %t107)
  br label %bb25
bb25:
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l67, !tbaa !29
  %t112 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t113 = load i64, ptr %t112, !tbaa !24
  %t114 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t115 = load i64, ptr %t114, !tbaa !24
  %t117 = add i64 %t115, 8
  %t120 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s1, i64 %t113, i64 %t117)
  store %"compiler/eval:Ptr" %t120, ptr %l71
  br label %bb26
bb26:
  %t121 = load %"compiler/eval:Ptr", ptr %l13
  %t122 = load ptr, ptr %l67, !tbaa !29
  %t123 = load %"compiler/eval:Ptr", ptr %l71
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t122, %"compiler/eval:Ptr" %t123, %"compiler/eval:Ptr" %t121)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i64, ptr %l1, !tbaa !24
  %t127 = load { i64, [1 x i64] }, ptr %l3
  %t131 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %t125, i64 %t126, { i64, [1 x i64] } %t127)
  store i64 %t131, ptr %l76
  br label %bb29
bb29:
  %t132 = load i64, ptr %l76, !tbaa !24
  store i64 %t132, ptr %l14, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 13
  %t136 = load i1, ptr %t135, !tbaa !21
  br i1 %t136, label %bb30, label %bb31
bb30:
  br label %ret
bb31:
  br label %bb32
bb32:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l79, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l6, !tbaa !23
  %t143 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t139, i32 %t140)
  store i64 %t143, ptr %l82
  br label %bb33
bb33:
  %t144 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t145 = load i64, ptr %l14, !tbaa !24
  %t146 = load ptr, ptr %l79, !tbaa !29
  %t147 = load i64, ptr %l82, !tbaa !24
  %t150 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t146, i64 %t147, i64 %t144, i64 %t145)
  store %"compiler/eval:Ptr" %t150, ptr %l85
  br label %bb34
bb34:
  %t151 = load %"compiler/eval:Ptr", ptr %l85
  store %"compiler/eval:Ptr" %t151, ptr %l15
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  %t154 = load %"compiler/eval:Ptr", ptr %l15
  %t155 = load i32, ptr %l6, !tbaa !23
  %t156 = load { i64, [4 x i64] }, ptr %l4
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t152, i64 %t153, %"compiler/eval:Ptr" %t154, i32 %t155, { i64, [4 x i64] } %t156)
  br label %bb35
bb35:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load %"compiler/eval:Ptr", ptr %l2
  %t164 = load %"compiler/eval:Ptr", ptr %l15
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t162, %"compiler/eval:Ptr" %t163, %"compiler/eval:Ptr" %t164)
  br label %bb36
bb36:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t3 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t3, ptr %a0, { i64, ptr } %t2)
  br label %bb1
bb1:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i32 %a4, i32 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l6 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i1
  %l29 = alloca i64
  %l33 = alloca i64
  %l56 = alloca i64
  %l62 = alloca i64
  %l68 = alloca i64
  %l74 = alloca i64
  %l80 = alloca i64
  %l82 = alloca i64
  %l84 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store i64 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l6, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i32, ptr %l4, !tbaa !23
  %t17 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatOp(ptr %v0, ptr %t7, i32 %t8, i64 %t9, i64 %t10, i32 %t11)
  store i64 %t17, ptr %l15
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t18 = load i64, ptr %l15, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t23 = icmp eq i64 %t19, %t20
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb7
bb6:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t29 = icmp eq i64 %t25, %t26
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l1
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = load i32, ptr %l4, !tbaa !23
  %t44 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintOp(ptr %v0, ptr %t32, i32 %t33, i64 %t34, i64 %t35, i32 %t36, i32 %a5)
  store i64 %t44, ptr %l29
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t45 = load i64, ptr %l29, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
bb11:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t50 = icmp eq i64 %t46, %t47
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load i32, ptr %l1
  %t54 = trunc i64 10 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb14, label %bb15
bb13:
  br label %bb69
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l3, !tbaa !24
  %t61 = and i64 %t57, %t58
  store i64 %t61, ptr %l33, !tbaa !24
  br label %bb68
bb17:
  %t63 = load i32, ptr %l1
  %t65 = trunc i64 11 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t68 = load i64, ptr %l2, !tbaa !24
  %t69 = load i64, ptr %l3, !tbaa !24
  %t72 = or i64 %t68, %t69
  store i64 %t72, ptr %l33, !tbaa !24
  br label %bb68
bb21:
  %t74 = load i32, ptr %l1
  %t76 = trunc i64 12 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  %t79 = load i32, ptr %l1
  %t81 = trunc i64 14 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t84 = load i64, ptr %l2, !tbaa !24
  %t85 = load i64, ptr %l3, !tbaa !24
  %t88 = xor i64 %t84, %t85
  store i64 %t88, ptr %l33, !tbaa !24
  br label %bb68
bb27:
  %t90 = load i32, ptr %l1
  %t92 = trunc i64 13 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t96 = load i64, ptr %l3, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  br i1 %t99, label %bb31, label %bb32
bb31:
  store i64 1, ptr %l56, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb33
bb33:
  %t101 = load i64, ptr %l56, !tbaa !24
  store i64 %t101, ptr %l33, !tbaa !24
  br label %bb68
bb34:
  %t102 = load i32, ptr %l1
  %t104 = trunc i64 15 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t107 = load i64, ptr %l2, !tbaa !24
  %t108 = load i64, ptr %l3, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  br i1 %t111, label %bb38, label %bb39
bb38:
  store i64 1, ptr %l62, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb40
bb40:
  %t113 = load i64, ptr %l62, !tbaa !24
  store i64 %t113, ptr %l33, !tbaa !24
  br label %bb68
bb41:
  %t114 = load i32, ptr %l1
  %t116 = trunc i64 16 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb48
bb44:
  %t119 = load i64, ptr %l2, !tbaa !24
  %t120 = load i64, ptr %l3, !tbaa !24
  %t123 = icmp sle i64 %t119, %t120
  br i1 %t123, label %bb45, label %bb46
bb45:
  store i64 1, ptr %l68, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb47
bb47:
  %t125 = load i64, ptr %l68, !tbaa !24
  store i64 %t125, ptr %l33, !tbaa !24
  br label %bb68
bb48:
  %t126 = load i32, ptr %l1
  %t128 = trunc i64 17 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb55
bb51:
  %t131 = load i64, ptr %l2, !tbaa !24
  %t132 = load i64, ptr %l3, !tbaa !24
  %t135 = icmp sgt i64 %t131, %t132
  br i1 %t135, label %bb52, label %bb53
bb52:
  store i64 1, ptr %l74, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb54
bb54:
  %t137 = load i64, ptr %l74, !tbaa !24
  store i64 %t137, ptr %l33, !tbaa !24
  br label %bb68
bb55:
  %t138 = load i32, ptr %l1
  %t140 = trunc i64 18 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb62
bb58:
  %t143 = load i64, ptr %l2, !tbaa !24
  %t144 = load i64, ptr %l3, !tbaa !24
  %t147 = icmp sge i64 %t143, %t144
  br i1 %t147, label %bb59, label %bb60
bb59:
  store i64 1, ptr %l80, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb61
bb61:
  %t149 = load i64, ptr %l80, !tbaa !24
  store i64 %t149, ptr %l33, !tbaa !24
  br label %bb68
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t150)
  store i64 %t152, ptr %l82
  br label %bb66
bb66:
  %t153 = load i64, ptr %l82, !tbaa !24
  store i64 %t153, ptr %l33, !tbaa !24
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_590198b1bba6f342_437268d8e9153c4e)
  unreachable
bb68:
  %t154 = load i64, ptr %l33, !tbaa !24
  store i64 %t154, ptr %rv
  br label %ret
bb69:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t155)
  store i64 %t157, ptr %l84
  br label %bb70
bb70:
  %t158 = load i64, ptr %l84, !tbaa !24
  store i64 %t158, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %a0, i32 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t24 = icmp eq i64 %t20, %t21
  store i1 %t24, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l13, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb10
bb9:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t31 = icmp eq i64 %t27, %t28
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l17, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eobjectOf(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca ptr
  %l9 = alloca %"compiler/eval:Ptr"
  %l13 = alloca i32
  %l14 = alloca %"compiler/eval:Ptr"
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load { i64, [4 x i64] }, ptr %l2
  %t7 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t1, i64 %t2, { i64, [4 x i64] } %t3, i64 1)
  store %"compiler/eval:Ptr" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/eval:Ptr", ptr %l7
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  store %"compiler/eval:Ptr" %t8, ptr %l9
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l1, !tbaa !24
  %t13 = load { i64, [4 x i64] }, ptr %l2
  %t17 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t11, i64 %t12, { i64, [4 x i64] } %t13)
  store i32 %t17, ptr %l13
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l8, !tbaa !29
  %t19 = load %"compiler/eval:Ptr", ptr %l9
  %t20 = load i32, ptr %l13, !tbaa !23
  %t21 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eobjectAt(ptr %v0, ptr %t18, %"compiler/eval:Ptr" %t19, i32 %t20)
  store %"compiler/eval:Ptr" %t21, ptr %l14
  br label %bb3
bb3:
  %t22 = load %"compiler/eval:Ptr", ptr %l14
  store %"compiler/eval:Ptr" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eownParams(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i64
  %l13 = alloca %"compiler/eval:Ptr"
  %l14 = alloca i64
  %l15 = alloca %"compiler/eval:Ptr"
  %l17 = alloca { i64, ptr }
  %l25 = alloca i64
  %l28 = alloca i64
  %l46 = alloca { i64, ptr }
  %l53 = alloca %"compiler/mir:Fn"
  %l56 = alloca i32
  %l60 = alloca %"compiler/eval:Ptr"
  %l63 = alloca i64
  %l66 = alloca i1
  %l69 = alloca ptr
  %l73 = alloca %"compiler/eval:Ptr"
  %l74 = alloca %"compiler/eval:Ptr"
  %l75 = alloca i64
  %l76 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l85 = alloca i32
  %l86 = alloca i64
  %l93 = alloca %"compiler/eval:Ptr"
  %l98 = alloca ptr
  %l102 = alloca %"compiler/eval:Ptr"
  %s2 = alloca %olang.scope
  %t77 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 17
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l17, !tbaa !27
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:cfn", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:cfn", ptr %t9, i32 0, i32 12
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb1, label %bb2
bb1:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb3:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l28, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb5
bb5:
  %t43 = load i64, ptr %l28, !tbaa !24
  store i64 %t43, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t53 = load i64, ptr %l4, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l9, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t63, ptr %l46, !tbaa !27
  %t64 = load i64, ptr %l9, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i1, ptr %t67, i64 %t64
  %t69 = load i1, ptr %t68, !tbaa !31
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb12:
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/eval:Machine", ptr %t73, i32 0, i32 16
  %t76 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t77, ptr %v0, ptr %v0, ptr %t75, i64 %t76)
  call void @llvm.memmove.p0.p0.i64(ptr %l53, ptr %t77, i64 248, i1 false)
  br label %bb14
bb14:
  %t80 = getelementptr %"compiler/mir:Fn", ptr %l53, i32 0, i32 4
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t80, i64 %t81)
  store i32 %t84, ptr %l56
  br label %bb15
bb15:
  %t85 = load i32, ptr %l56, !tbaa !23
  store i32 %t85, ptr %l10, !tbaa !23
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l10, !tbaa !23
  %t92 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t86, i64 %a1, i32 %t88)
  store %"compiler/eval:Ptr" %t92, ptr %l60
  br label %bb16
bb16:
  %t93 = load %"compiler/eval:Ptr", ptr %l60
  store %"compiler/eval:Ptr" %t93, ptr %l11
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load %"compiler/eval:Ptr", ptr %l11
  %t98 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t94, %"compiler/eval:Ptr" %t95, i64 8)
  store i64 %t98, ptr %l63
  br label %bb17
bb17:
  %t99 = load i64, ptr %l63, !tbaa !24
  store i64 %t99, ptr %l12, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t102 = icmp sle i64 %t100, 0
  br i1 %t102, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb20
bb19:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/eval:Machine", ptr %t104, i32 0, i32 13
  %t107 = load i1, ptr %t106, !tbaa !21
  store i1 %t107, ptr %l66, !tbaa !21
  br label %bb20
bb20:
  %t109 = load i1, ptr %l66, !tbaa !21
  br i1 %t109, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb22:
  br label %bb23
bb23:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l69, !tbaa !29
  %t111 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 0
  %t112 = load i64, ptr %t111, !tbaa !24
  %t113 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t116 = add i64 %t114, 8
  %t119 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t112, i64 %t116)
  store %"compiler/eval:Ptr" %t119, ptr %l73
  br label %bb24
bb24:
  %t120 = load ptr, ptr %l69, !tbaa !29
  %t121 = load %"compiler/eval:Ptr", ptr %l73
  %t122 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t120, %"compiler/eval:Ptr" %t121)
  store %"compiler/eval:Ptr" %t122, ptr %l74
  br label %bb25
bb25:
  %t123 = load %"compiler/eval:Ptr", ptr %l74
  store %"compiler/eval:Ptr" %t123, ptr %l13
  %t124 = load i64, ptr %l12, !tbaa !24
  store i64 %t124, ptr %l75, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l76, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/eval:Machine", ptr %t127, i32 0, i32 17
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l79, !tbaa !27
  %t131 = load i64, ptr %l2, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr %"compiler/eval:cfn", ptr %t134, i64 %t131
  %t136 = getelementptr %"compiler/eval:cfn", ptr %t135, i32 0, i32 1
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l81, !tbaa !27
  %t138 = load i32, ptr %l10, !tbaa !23
  %t140 = sext i32 %t138 to i64
  %t142 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr %"compiler/mir:Local", ptr %t143, i64 %t140
  %t145 = getelementptr %"compiler/mir:Local", ptr %t144, i32 0, i32 2
  %t146 = load i32, ptr %t145, !tbaa !23
  %t149 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t126, i32 %t146)
  store i32 %t149, ptr %l85
  br label %bb26
bb26:
  %t150 = load ptr, ptr %l76, !tbaa !29
  %t151 = load i32, ptr %l85, !tbaa !23
  %t152 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t150, i32 %t151)
  store i64 %t152, ptr %l86
  br label %bb27
bb27:
  %t153 = load i64, ptr %l75, !tbaa !24
  %t154 = load i64, ptr %l86, !tbaa !24
  %t155 = mul i64 %t153, %t154
  store i64 %t155, ptr %l14, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i64, ptr %l14, !tbaa !24
  %t159 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/eval:Machine", ptr %t160, i32 0, i32 61
  %t163 = load i64, ptr %t162, !tbaa !24
  %t168 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t157, i64 %t158, i64 %t159, i64 %t163)
  store %"compiler/eval:Ptr" %t168, ptr %l93
  br label %bb28
bb28:
  %t169 = load %"compiler/eval:Ptr", ptr %l93
  store %"compiler/eval:Ptr" %t169, ptr %l15
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load %"compiler/eval:Ptr", ptr %l15
  %t172 = load %"compiler/eval:Ptr", ptr %l13
  %t173 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t170, %"compiler/eval:Ptr" %t171, %"compiler/eval:Ptr" %t172, i64 %t173)
  br label %bb29
bb29:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l98, !tbaa !29
  %t179 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 0
  %t180 = load i64, ptr %t179, !tbaa !24
  %t181 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 1
  %t182 = load i64, ptr %t181, !tbaa !24
  %t184 = add i64 %t182, 8
  %t187 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t180, i64 %t184)
  store %"compiler/eval:Ptr" %t187, ptr %l102
  br label %bb30
bb30:
  %t188 = load %"compiler/eval:Ptr", ptr %l15
  %t189 = load ptr, ptr %l98, !tbaa !29
  %t190 = load %"compiler/eval:Ptr", ptr %l102
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t189, %"compiler/eval:Ptr" %t190, %"compiler/eval:Ptr" %t188)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t192 = load i64, ptr %l8, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l8, !tbaa !24
  br label %bb7
bb33:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartList(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l20 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load i32, ptr %l12
  store i32 %t17, ptr %l4
  %t18 = load i32, ptr %l4
  %t20 = trunc i64 22 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t23 = load i32, ptr %l4
  %t25 = trunc i64 23 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l20
  br label %bb8
bb8:
  %t33 = load i32, ptr %l20, !tbaa !23
  store i32 %t33, ptr %l13, !tbaa !23
  br label %bb19
bb9:
  %t34 = load i32, ptr %l4
  %t36 = trunc i64 18 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l25
  br label %bb13
bb13:
  %t44 = load i32, ptr %l25, !tbaa !23
  store i32 %t44, ptr %l13, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i32 0, ptr %l13, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d4aeb51afef739b6_d573fd1fa5ffe912)
  unreachable
bb19:
  %t45 = load i32, ptr %l13, !tbaa !23
  store i32 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, { i64, [4 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca %"compiler/mir:Lvalue"
  %l6 = alloca { %"compiler/eval:Ptr", i32 }
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, i64 }
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l27 = alloca { %"compiler/eval:Ptr", i32 }
  %l30 = alloca ptr
  %l31 = alloca %"compiler/eval:Ptr"
  %l32 = alloca %"compiler/eval:Ptr"
  %l35 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i1
  %l48 = alloca i64
  %l51 = alloca i1
  %l54 = alloca i64
  %l62 = alloca i64
  %l68 = alloca { i64, i64 }
  %l76 = alloca ptr
  %l77 = alloca %"compiler/eval:Ptr"
  %l80 = alloca i64
  %l84 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store { i64, [4 x i64] } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l4
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb43
bb4:
  %t6 = load { i64, [4 x i64] }, ptr %l4
  %t8 = extractvalue { i64, [4 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t12 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t11, i32 0, i32 0
  %t13 = load %"compiler/mir:Lvalue", ptr %t12
  store %"compiler/mir:Lvalue" %t13, ptr %l5
  br label %bb7
bb6:
  br label %bb11
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l1, !tbaa !24
  %t17 = load %"compiler/mir:Lvalue", ptr %l5
  %t21 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t15, i64 %t16, %"compiler/mir:Lvalue" %t17)
  store { %"compiler/eval:Ptr", i32 } %t21, ptr %l27
  br label %bb8
bb8:
  %t22 = load { %"compiler/eval:Ptr", i32 }, ptr %l27
  store { %"compiler/eval:Ptr", i32 } %t22, ptr %l6
  %t23 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l6, i32 0, i32 0
  %t24 = load %"compiler/eval:Ptr", ptr %t23
  %t26 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l6, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l30, !tbaa !29
  %t30 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t30, ptr %l31
  store %"compiler/eval:Ptr" %t24, ptr %l32
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t36 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t32, i32 %t27)
  store i64 %t36, ptr %l35
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l30, !tbaa !29
  %t38 = load %"compiler/eval:Ptr", ptr %l31
  %t39 = load %"compiler/eval:Ptr", ptr %l32
  %t40 = load i64, ptr %l35, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t37, %"compiler/eval:Ptr" %t38, %"compiler/eval:Ptr" %t39, i64 %t40)
  br label %bb10
bb10:
  br label %bb43
bb11:
  %t41 = load { i64, [4 x i64] }, ptr %l4
  %t43 = extractvalue { i64, [4 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 2
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t47 = getelementptr { i32, i64 }, ptr %t46, i32 0, i32 0
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l9, !tbaa !23
  %t50 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t51 = getelementptr { i32, i64 }, ptr %t50, i32 0, i32 1
  %t52 = load i64, ptr %t51
  store i64 %t52, ptr %l10, !tbaa !24
  br label %bb14
bb13:
  br label %bb37
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t58 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t54, i32 %a3)
  store i64 %t58, ptr %l42
  br label %bb15
bb15:
  %t59 = load i64, ptr %l42, !tbaa !24
  store i64 %t59, ptr %l11, !tbaa !24
  %t60 = load i64, ptr %l10, !tbaa !24
  %t62 = icmp eq i64 %t60, 0
  br i1 %t62, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb19
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l9, !tbaa !23
  %t68 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t64, i32 %t65)
  store i64 %t68, ptr %l48
  br label %bb18
bb18:
  %t69 = load i64, ptr @G_2ecompiler_2feval_2evAgg, !tbaa !24
  %t70 = load i64, ptr %l48, !tbaa !24
  %t72 = icmp eq i64 %t70, %t69
  store i1 %t72, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t74 = load i1, ptr %l45, !tbaa !21
  br i1 %t74, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb21:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l9, !tbaa !23
  %t79 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l54
  br label %bb22
bb22:
  %t80 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  %t81 = load i64, ptr %l54, !tbaa !24
  %t83 = icmp eq i64 %t81, %t80
  store i1 %t83, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t85 = load i1, ptr %l51, !tbaa !21
  br i1 %t85, label %bb24, label %bb25
bb24:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load %"compiler/eval:Ptr", ptr %l2
  %t88 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ezero(ptr %v0, ptr %t86, %"compiler/eval:Ptr" %t87, i64 %t88)
  br label %bb26
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l9, !tbaa !23
  %t96 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t92, i32 %t93)
  store i64 %t96, ptr %l62
  br label %bb27
bb26:
  br label %bb36
bb27:
  %t97 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t98 = load i64, ptr %l62, !tbaa !24
  %t100 = icmp eq i64 %t98, %t97
  br i1 %t100, label %bb28, label %bb29
bb28:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l9, !tbaa !23
  %t104 = load i64, ptr %l10, !tbaa !24
  %t108 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideConst(ptr %v0, ptr %t102, i32 %t103, i64 %t104)
  store { i64, i64 } %t108, ptr %l68
  br label %bb30
bb29:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l76, !tbaa !29
  %t110 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t110, ptr %l77
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l9, !tbaa !23
  %t115 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t111, i32 %t112)
  store i64 %t115, ptr %l80
  br label %bb32
bb30:
  %t116 = load { i64, i64 }, ptr %l68
  store { i64, i64 } %t116, ptr %l12
  %t117 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 0
  %t118 = load i64, ptr %t117, !tbaa !24
  %t120 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/eval:Ptr", ptr %l2
  %t125 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrWide(ptr %v0, ptr %t123, %"compiler/eval:Ptr" %t124, i32 %t125, i64 %t118, i64 %t121)
  br label %bb31
bb31:
  br label %bb35
bb32:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l9, !tbaa !23
  %t135 = load i64, ptr %l10, !tbaa !24
  %t139 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecanonBits(ptr %v0, ptr %t133, i32 %t134, i64 %t135)
  store i64 %t139, ptr %l84
  br label %bb33
bb33:
  %t140 = load ptr, ptr %l76, !tbaa !29
  %t141 = load %"compiler/eval:Ptr", ptr %l77
  %t142 = load i64, ptr %l80, !tbaa !24
  %t143 = load i64, ptr %l84, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t140, %"compiler/eval:Ptr" %t141, i64 %t142, i64 %t143)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb43
bb37:
  %t144 = load { i64, [4 x i64] }, ptr %l4
  %t146 = extractvalue { i64, [4 x i64] } %t144, 0
  %t147 = icmp eq i64 %t146, 3
  br i1 %t147, label %bb38, label %bb39
bb38:
  %t149 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t150 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t149, i32 0, i32 0
  %t151 = load i32, ptr %t150
  store i32 %t151, ptr %l15, !tbaa !23
  %t153 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t154 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t153, i32 0, i32 1
  %t155 = load i32, ptr %t154
  store i32 %t155, ptr %l16, !tbaa !23
  %t157 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t158 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t157, i32 0, i32 2
  %t159 = load i64, ptr %t158
  store i64 %t159, ptr %l17, !tbaa !24
  %t161 = getelementptr { i64, [4 x i64] }, ptr %l4, i32 0, i32 1
  %t162 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t161, i32 0, i32 3
  %t163 = load %"compiler/source:Span", ptr %t162
  store %"compiler/source:Span" %t163, ptr %l18
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i64, ptr %l1, !tbaa !24
  %t167 = load %"compiler/eval:Ptr", ptr %l2
  %t168 = load i32, ptr %l15, !tbaa !23
  %t169 = load i32, ptr %l16, !tbaa !23
  %t170 = load i64, ptr %l17, !tbaa !24
  %t171 = load %"compiler/source:Span", ptr %l18
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputData(ptr %v0, ptr %t165, i64 %t166, %"compiler/eval:Ptr" %t167, i32 %t168, i32 %t169, i64 %t170, %"compiler/source:Span" %t171)
  br label %bb41
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_af1f9cfaa1609478_d5c4fc0e8d836404)
  unreachable
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { %"compiler/eval:Ptr", i64 }
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca %"compiler/eval:Ptr"
  %l27 = alloca { %"compiler/eval:Ptr", i64 }
  %l32 = alloca i1
  %l34 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l81 = alloca ptr
  %l86 = alloca %"compiler/eval:Ptr"
  %l87 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load { i64, [4 x i64] }, ptr %l2
  %t7 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t1, i64 %t2, { i64, [4 x i64] } %t3)
  store i32 %t7, ptr %l20
  br label %bb1
bb1:
  %t8 = load i32, ptr %l20, !tbaa !23
  store i32 %t8, ptr %l5, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l21, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = load { i64, [4 x i64] }, ptr %l2
  %t16 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t10, i64 %t11, { i64, [4 x i64] } %t12, i64 1)
  store %"compiler/eval:Ptr" %t16, ptr %l25
  br label %bb2
bb2:
  %t17 = load i32, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l21, !tbaa !29
  %t19 = load %"compiler/eval:Ptr", ptr %l25
  %t21 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t18, %"compiler/eval:Ptr" %t19, i32 %t17)
  store { %"compiler/eval:Ptr", i64 } %t21, ptr %l27
  br label %bb3
bb3:
  %t22 = load { %"compiler/eval:Ptr", i64 }, ptr %l27
  store { %"compiler/eval:Ptr", i64 } %t22, ptr %l6
  %t23 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l6, i32 0, i32 0
  %t24 = load %"compiler/eval:Ptr", ptr %t23
  store %"compiler/eval:Ptr" %t24, ptr %l7
  %t26 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l6, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l8, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t29, i32 0, i32 13
  %t32 = load i1, ptr %t31, !tbaa !21
  br i1 %t32, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb6
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/eval:Machine", ptr %t34, i32 0, i32 40
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l34, !tbaa !27
  %t38 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t43 = and i64 %t39, %t40
  %t45 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr %"compiler/eval:alloc", ptr %t46, i64 %t43
  %t48 = getelementptr %"compiler/eval:alloc", ptr %t47, i32 0, i32 10
  %t49 = load i1, ptr %t48, !tbaa !21
  store i1 %t49, ptr %l32, !tbaa !21
  br label %bb6
bb6:
  %t51 = load i1, ptr %l32, !tbaa !21
  br i1 %t51, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t52 = load i64, ptr %l8, !tbaa !24
  store i64 %t52, ptr %l39, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l40, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l5, !tbaa !23
  %t58 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l43
  br label %bb10
bb10:
  %t59 = load ptr, ptr %l40, !tbaa !29
  %t60 = load i32, ptr %l43, !tbaa !23
  %t61 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t61, ptr %l44
  br label %bb11
bb11:
  %t62 = load i64, ptr %l39, !tbaa !24
  %t63 = load i64, ptr %l44, !tbaa !24
  %t64 = mul i64 %t62, %t63
  store i64 %t64, ptr %l9, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  br i1 %t74, label %bb12, label %bb13
bb12:
  %t76 = load i64, ptr %l4, !tbaa !24
  store i64 %t76, ptr %l10, !tbaa !24
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t78 = load i64, ptr %l9, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  br i1 %t82, label %bb15, label %bb16
bb15:
  %t84 = load i64, ptr %l9, !tbaa !24
  store i64 %t84, ptr %l10, !tbaa !24
  br label %bb17
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l11, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  store i64 %t86, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t88 = load i64, ptr %l12, !tbaa !24
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = load i64, ptr %l13, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb23
bb20:
  %t98 = load i64, ptr %l12, !tbaa !24
  %t99 = load i64, ptr %l11, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l13, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l63, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb22
bb22:
  %t114 = load i64, ptr %l63, !tbaa !24
  store i64 %t114, ptr %l60, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l60, !tbaa !24
  store i64 %t115, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t116 = load i64, ptr %l15, !tbaa !24
  %t117 = load i64, ptr %l14, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l16, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l81, !tbaa !29
  %t135 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t136 = load i64, ptr %t135, !tbaa !24
  %t137 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  %t139 = load i64, ptr %l16, !tbaa !24
  %t142 = add i64 %t138, %t139
  %t145 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t136, i64 %t142)
  store %"compiler/eval:Ptr" %t145, ptr %l86
  br label %bb28
bb28:
  %t146 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t146, ptr %l87, !tbaa !27
  %t147 = load i64, ptr %l16, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i8, ptr %t150, i64 %t147
  %t152 = load i8, ptr %t151, !tbaa !32
  %t154 = zext i8 %t152 to i64
  %t155 = load ptr, ptr %l81, !tbaa !29
  %t156 = load %"compiler/eval:Ptr", ptr %l86
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t155, %"compiler/eval:Ptr" %t156, i64 1, i64 %t154)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  %t158 = load i64, ptr %l15, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l15, !tbaa !24
  br label %bb24
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputInt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca i32
  %l3 = alloca i64
  %l7 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"compiler/eval:Ptr"
  %l19 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t7 = load i64, ptr %l7, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load %"compiler/eval:Ptr", ptr %l1
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrWide(ptr %v0, ptr %t11, %"compiler/eval:Ptr" %t12, i32 %t13, i64 %t14, i64 %a4)
  br label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l15, !tbaa !29
  %t22 = load %"compiler/eval:Ptr", ptr %l1
  store %"compiler/eval:Ptr" %t22, ptr %l16
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l2, !tbaa !23
  %t27 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t23, i32 %t24)
  store i64 %t27, ptr %l19
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t28 = load i64, ptr %l3, !tbaa !24
  store i64 %t28, ptr %l20, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l23
  br label %bb6
bb6:
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = call i64 @compiler_2feval_2ebmask(i64 %t34)
  store i64 %t35, ptr %l24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = and i64 %t36, %t37
  %t39 = load ptr, ptr %l15, !tbaa !29
  %t40 = load %"compiler/eval:Ptr", ptr %l16
  %t41 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t39, %"compiler/eval:Ptr" %t40, i64 %t41, i64 %t38)
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l25 = alloca i1
  %l33 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i64 8, i1 false)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/eval:Ptr" %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t13, i64 %t14, i64 8)
  store i64 %t17, ptr %l13
  br label %bb5
bb5:
  %t18 = load i64, ptr %l13, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = srem i64 %t19, 8
  %t23 = icmp eq i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 37
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = sdiv i64 %t29, 8
  %t33 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i64, ptr %t34, i64 %t31
  %t36 = load i64, ptr %t35, !tbaa !34
  store i64 %t36, ptr %l17, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l17, !tbaa !24
  store i64 %t38, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp eq i64 %t39, 0
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp ne i64 %t43, 0
  store i1 %t45, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l25, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t50 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t50, ptr %t48, { i64, ptr } %t49)
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t53 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/eval:Ptr" %t53, ptr %rv
  br label %ret
bb15:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t56 = load i64, ptr %l3, !tbaa !24
  %t59 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t55, i64 %t56)
  store %"compiler/eval:Ptr" %t59, ptr %l33
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load %"compiler/eval:Ptr", ptr %l33
  store %"compiler/eval:Ptr" %t60, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i64 8, i1 false)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/eval:Ptr" %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = srem i64 %t13, 8
  %t17 = icmp eq i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 37
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l14, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = sdiv i64 %t23, 8
  %t27 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  store i64 %t30, ptr %l12, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %t32, i64 %t33, i64 8)
  store i64 %t36, ptr %l20
  br label %bb8
bb8:
  %t37 = load i64, ptr %l12, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t37, i64 %t38)
  store %"compiler/eval:Ptr" %t39, ptr %l21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load %"compiler/eval:Ptr", ptr %l21
  store %"compiler/eval:Ptr" %t40, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erdRaw(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l12 = alloca i1
  %l16 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l37 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l48 = alloca { i64, ptr }
  %l51 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = ashr i64 %t1, 3
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = and i64 %t5, 7
  store i64 %t7, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp eq i64 %t13, 8
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l12, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/eval:Machine", ptr %t18, i32 0, i32 36
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i64, ptr %t25, i64 %t22
  %t27 = load i64, ptr %t26, !tbaa !34
  store i64 %t27, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = icmp sle i64 %t33, 8
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/eval:Machine", ptr %t37, i32 0, i32 36
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l24, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i64, ptr %t44, i64 %t41
  %t46 = load i64, ptr %t45, !tbaa !34
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 8, %t47
  store i64 %t49, ptr %l28, !tbaa !24
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = ashr i64 %t46, %t52
  store i64 %t53, ptr %l29, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i64, ptr %l2, !tbaa !24
  %t58 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t54, i64 %t55)
  store i64 %t58, ptr %l32
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t59 = load i64, ptr %l29, !tbaa !24
  %t60 = load i64, ptr %l32, !tbaa !24
  %t61 = and i64 %t59, %t60
  store i64 %t61, ptr %rv
  br label %ret
bb10:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = sub i64 8, %t63
  store i64 %t65, ptr %l5, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/eval:Machine", ptr %t67, i32 0, i32 36
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l37, !tbaa !27
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i64, ptr %t74, i64 %t71
  %t76 = load i64, ptr %t75, !tbaa !34
  %t77 = load i64, ptr %l4, !tbaa !24
  %t79 = mul i64 8, %t77
  store i64 %t79, ptr %l41, !tbaa !24
  %t81 = load i64, ptr %l41, !tbaa !24
  %t82 = load i64, ptr %l41, !tbaa !24
  %t83 = ashr i64 %t76, %t82
  store i64 %t83, ptr %l42, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t84, i64 %t85)
  store i64 %t88, ptr %l45
  br label %bb11
bb11:
  %t89 = load i64, ptr %l42, !tbaa !24
  %t90 = load i64, ptr %l45, !tbaa !24
  %t91 = and i64 %t89, %t90
  store i64 %t91, ptr %l46, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/eval:Machine", ptr %t92, i32 0, i32 36
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l48, !tbaa !27
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = add i64 %t96, 1
  %t100 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i64, ptr %t101, i64 %t98
  %t103 = load i64, ptr %t102, !tbaa !34
  store i64 %t103, ptr %l51, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i64, ptr %l2, !tbaa !24
  %t106 = load i64, ptr %l5, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t112 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t104, i64 %t109)
  store i64 %t112, ptr %l56
  br label %bb12
bb12:
  %t113 = load i64, ptr %l51, !tbaa !24
  %t114 = load i64, ptr %l56, !tbaa !24
  %t115 = and i64 %t113, %t114
  %t116 = load i64, ptr %l5, !tbaa !24
  %t118 = mul i64 8, %t116
  store i64 %t118, ptr %l59, !tbaa !24
  %t120 = load i64, ptr %l59, !tbaa !24
  %t121 = load i64, ptr %l59, !tbaa !24
  %t122 = shl i64 %t115, %t121
  %t123 = load i64, ptr %l46, !tbaa !24
  %t125 = or i64 %t123, %t122
  store i64 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2erdWide(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca i32
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l12 = alloca %"compiler/eval:Ptr"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i1
  %l26 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i1
  %l33 = alloca { i64, i64 }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/eval:Ptr", ptr %l1
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %t2, i64 8)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l8, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = add i64 %t11, 8
  %t16 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t9, i64 %t13)
  store %"compiler/eval:Ptr" %t16, ptr %l12
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = load %"compiler/eval:Ptr", ptr %l12
  %t19 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t17, %"compiler/eval:Ptr" %t18, i64 8)
  store i64 %t19, ptr %l13
  br label %bb3
bb3:
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  store i64 %t21, ptr %l14, !tbaa !24
  store i64 %t20, ptr %l15, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l2, !tbaa !23
  %t27 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t23, i32 %t24)
  store i64 %t27, ptr %l18
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t28, i32 %t29)
  store i64 %t32, ptr %l21
  br label %bb5
bb5:
  %t33 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t34 = load i64, ptr %l21, !tbaa !24
  %t36 = icmp ne i64 %t34, %t33
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l26, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i32, ptr %l2, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l30
  br label %bb8
bb7:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb10
bb8:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i32, ptr %l30, !tbaa !23
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t52, ptr %l31
  br label %bb9
bb9:
  %t53 = load i1, ptr %l31, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l24, !tbaa !21
  br label %bb10
bb10:
  %t56 = load i64, ptr %l14, !tbaa !24
  %t57 = load i64, ptr %l15, !tbaa !24
  %t58 = load i64, ptr %l18, !tbaa !24
  %t59 = load i1, ptr %l24, !tbaa !21
  %t60 = call { i64, i64 } @compiler_2feval_2eextend128(i64 %t56, i64 %t57, i64 %t58, i1 %t59)
  store { i64, i64 } %t60, ptr %l33
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load { i64, i64 }, ptr %l33
  store { i64, i64 } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereadsMutable(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [15 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [15 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca i1
  %l8 = alloca i1
  %l14 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [15 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [15 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [15 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [15 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  %t10 = extractvalue { i64, [4 x i64] } %t8, 0
  %t11 = icmp eq i64 %t10, 1
  store i1 %t11, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = getelementptr { i64, [15 x i64] }, ptr %l2, i32 0, i32 1
  %t15 = getelementptr { { i64, [4 x i64] } }, ptr %t14, i32 0, i32 0
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t17 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/mir:Lvalue", ptr %t17
  store %"compiler/mir:Lvalue" %t18, ptr %l3
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/mir:Lvalue", ptr %l3
  %t24 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2emutableGlobal(ptr %v0, ptr %t20, %"compiler/mir:Lvalue" %t21)
  store i1 %t24, ptr %l14
  br label %bb7
bb7:
  %t25 = load i1, ptr %l14, !tbaa !21
  store i1 %t25, ptr %l5, !tbaa !21
  br label %bb18
bb8:
  %t26 = load { i64, [15 x i64] }, ptr %l2
  %t28 = extractvalue { i64, [15 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 3
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = getelementptr { i64, [15 x i64] }, ptr %l2, i32 0, i32 1
  %t32 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t31, i32 0, i32 2
  %t33 = load %"compiler/mir:Range", ptr %t32
  store %"compiler/mir:Range" %t33, ptr %l4
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/mir:Range", ptr %l4
  %t41 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeMutable(ptr %v0, ptr %v1, ptr %t35, ptr %a1, %"compiler/mir:Range" %t37)
  store i1 %t41, ptr %l21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l21, !tbaa !21
  store i1 %t42, ptr %l5, !tbaa !21
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_5132488ea4d5a24a_c872bd4e98b932a6)
  unreachable
bb18:
  %t43 = load i1, ptr %l5, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erecode(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l13 = alloca { i64, ptr }
  %l19 = alloca i1
  %l30 = alloca { i64, ptr }
  %l35 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t9, i32 %a2)
  store { i64, ptr } %t13, ptr %l13
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = ashr i64 %t15, 16
  %t19 = sub i64 %t17, 1
  store i64 %t19, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb7
bb6:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp sge i64 %t25, %t28
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t36 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t36, ptr %t34, { i64, ptr } %t35)
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i64 0, ptr %rv
  br label %ret
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/eval:Machine", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l30, !tbaa !27
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i32, ptr %t49, i64 %t46
  %t51 = load i32, ptr %t50, !tbaa !33
  %t52 = load i64, ptr %l1, !tbaa !24
  %t54 = and i64 %t52, 65535
  %t59 = call i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %t43, i32 %a3, i32 %t51, i64 %t54)
  store i64 %t59, ptr %l35
  br label %bb12
bb12:
  %t60 = load i64, ptr %l35, !tbaa !24
  store i64 %t60, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp slt i64 %t61, 0
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t67 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t67, ptr %t65, { i64, ptr } %t66)
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i64 0, ptr %rv
  br label %ret
bb16:
  %t71 = load i64, ptr %l6, !tbaa !24
  store i64 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eref(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, %"compiler/mir:Lvalue" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/eval:Ptr"
  %l5 = alloca { %"compiler/eval:Ptr", i32 }
  %l6 = alloca %"compiler/eval:Ptr"
  %l7 = alloca i32
  %l11 = alloca { %"compiler/eval:Ptr", i32 }
  %l18 = alloca i64
  %l26 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca %"compiler/eval:Ptr"
  %l36 = alloca i64
  %l37 = alloca ptr
  %l41 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t1, i64 %a1, %"compiler/mir:Lvalue" %a3)
  store { %"compiler/eval:Ptr", i32 } %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load { %"compiler/eval:Ptr", i32 }, ptr %l11
  store { %"compiler/eval:Ptr", i32 } %t8, ptr %l5
  %t9 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l5, i32 0, i32 0
  %t10 = load %"compiler/eval:Ptr", ptr %t9
  store %"compiler/eval:Ptr" %t10, ptr %l6
  %t12 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l5, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l7, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:Machine", ptr %t15, i32 0, i32 13
  %t18 = load i1, ptr %t17, !tbaa !21
  br i1 %t18, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t20, i32 %a4)
  store i64 %t24, ptr %l18
  br label %bb5
bb5:
  %t25 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t28 = icmp ne i64 %t26, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load %"compiler/eval:Ptr", ptr %l2
  %t32 = load %"compiler/eval:Ptr", ptr %l6
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t30, %"compiler/eval:Ptr" %t31, %"compiler/eval:Ptr" %t32)
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l7, !tbaa !23
  %t40 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t36, i32 %t37)
  store i64 %t40, ptr %l26
  br label %bb10
bb10:
  %t41 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t42 = load i64, ptr %l26, !tbaa !24
  %t44 = icmp eq i64 %t42, %t41
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load %"compiler/eval:Ptr", ptr %l2
  %t48 = load %"compiler/eval:Ptr", ptr %l6
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t46, %"compiler/eval:Ptr" %t47, %"compiler/eval:Ptr" %t48, i64 16)
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  %t53 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t53, ptr %l33
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l7, !tbaa !23
  %t58 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %t54, i32 %t55)
  store i64 %t58, ptr %l36
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load %"compiler/eval:Ptr", ptr %l33
  %t61 = load i64, ptr %l36, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t59, %"compiler/eval:Ptr" %t60, i64 8, i64 %t61)
  br label %bb16
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l37, !tbaa !29
  %t63 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t66 = load i64, ptr %t65, !tbaa !24
  %t68 = add i64 %t66, 8
  %t71 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t64, i64 %t68)
  store %"compiler/eval:Ptr" %t71, ptr %l41
  br label %bb17
bb17:
  %t72 = load %"compiler/eval:Ptr", ptr %l6
  %t73 = load ptr, ptr %l37, !tbaa !29
  %t74 = load %"compiler/eval:Ptr", ptr %l41
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t73, %"compiler/eval:Ptr" %t74, %"compiler/eval:Ptr" %t72)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eregionOfObject(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l2 = alloca i64
  %l3 = alloca i64
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l20 = alloca i64
  %l25 = alloca { i64, ptr }
  %l30 = alloca i1
  %l32 = alloca i1
  %l38 = alloca %"compiler/eval:scope"
  %rv = alloca i64
  %t75 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t4 = icmp eq i64 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t12 = and i64 %t8, %t9
  store i64 %t12, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:Machine", ptr %t15, i32 0, i32 41
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = icmp sge i64 %t14, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 40
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l16, !tbaa !27
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr %"compiler/eval:alloc", ptr %t30, i64 %t27
  %t32 = getelementptr %"compiler/eval:alloc", ptr %t31, i32 0, i32 3
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t36, ptr %l20, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = load i64, ptr %l20, !tbaa !24
  %t40 = ashr i64 %t35, %t39
  %t43 = icmp ne i64 %t33, %t40
  store i1 %t43, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t45 = load i1, ptr %l14, !tbaa !21
  br i1 %t45, label %bb7, label %bb8
bb7:
  store i64 0, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t47, i32 0, i32 40
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l25, !tbaa !27
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr %"compiler/eval:alloc", ptr %t54, i64 %t51
  %t56 = getelementptr %"compiler/eval:alloc", ptr %t55, i32 0, i32 5
  %t57 = load i64, ptr %t56, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i64, ptr %l3, !tbaa !24
  %t63 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t59, i64 %t60)
  store i1 %t63, ptr %l30
  br label %bb10
bb10:
  %t64 = load i1, ptr %l30, !tbaa !21
  %t65 = xor i1 %t64, true
  br i1 %t65, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb14
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/eval:Machine", ptr %t67, i32 0, i32 43
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t74 = and i64 %t70, %t71
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t75, ptr %v0, ptr %t69, i64 %t74)
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t75, i64 136, i1 false)
  br label %bb13
bb13:
  %t78 = getelementptr %"compiler/eval:scope", ptr %l38, i32 0, i32 2
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  %t83 = icmp ne i64 %t79, %t80
  store i1 %t83, ptr %l32, !tbaa !21
  br label %bb14
bb14:
  %t85 = load i1, ptr %l32, !tbaa !21
  br i1 %t85, label %bb15, label %bb16
bb15:
  store i64 0, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t87 = load i64, ptr %l3, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ertArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i1
  %l17 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i32, ptr %l6, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l10
  br label %bb2
bb2:
  %t18 = load i32, ptr %l10
  %t20 = trunc i64 19 to i32
  %t21 = icmp eq i32 %t18, %t20
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l17
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t31 = load i32, ptr %l17, !tbaa !23
  %t32 = icmp eq i32 %t31, 0
  store i1 %t32, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l13, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2esettled(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l21 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l91 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %rv = alloca i1
  %t86 = alloca i64
  %t110 = alloca i64
  %t134 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %t4, i32 %t5)
  store i64 %t8, ptr %l17
  br label %bb1
bb1:
  %t9 = load i64, ptr %l17, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr @G_2ecompiler_2ftypes_2eLaidOut, !tbaa !24
  %t14 = icmp ne i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr @G_2ecompiler_2ftypes_2eNoLayout, !tbaa !24
  %t20 = icmp ne i64 %t16, %t17
  store i1 %t20, ptr %l21, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l21, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t24 = load i32, ptr %l1, !tbaa !23
  %t26 = sext i32 %t24 to i64
  store i64 %t26, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t29, i32 0, i32 18
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t37 = icmp sge i64 %t28, %t34
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 18
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = mul i64 2, %t44
  store i64 %t46, ptr %l4, !tbaa !24
  br label %bb10
bb9:
  br label %bb40
bb10:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  %t52 = icmp sle i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = mul i64 %t56, 2
  store i64 %t58, ptr %l4, !tbaa !24
  br label %bb14
bb14:
  br label %bb10
bb15:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Machine", ptr %t60, i32 0, i32 18
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l5, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/eval:Machine", ptr %t65, i32 0, i32 19
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l6, !tbaa !27
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t70, i32 0, i32 20
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l7, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l49, !tbaa !29
  %t76 = load i64, ptr %l4, !tbaa !24
  store i64 %t76, ptr %l50, !tbaa !24
  %t77 = load i64, ptr %l50, !tbaa !24
  %t78 = icmp sge i64 %t77, 0
  br i1 %t78, label %bb16, label %bb17
bb16:
  %t80 = load i64, ptr %l50, !tbaa !24
  %t81 = icmp sle i64 %t80, 1152921504606846975
  br i1 %t81, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_a19345797ce3092f_df897154cd0b0613)
  unreachable
bb18:
  %t83 = load i64, ptr %l50, !tbaa !24
  %t84 = mul i64 %t83, 8
  %t85 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t84)
  store i64 0, ptr %t86
  br label %fill.87
fill.87:
  %t90 = load i64, ptr %t86
  %t91 = icmp slt i64 %t90, %t83
  br i1 %t91, label %fillb.88, label %filld.89
fillb.88:
  %t92 = getelementptr i64, ptr %t85, i64 %t90
  store i64 -1, ptr %t92
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %t86
  br label %fill.87
filld.89:
  %t94 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t85, 1
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = getelementptr %"compiler/eval:Machine", ptr %t97, i32 0, i32 18
  store { i64, ptr } %t95, ptr %t98, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l54, !tbaa !29
  %t100 = load i64, ptr %l4, !tbaa !24
  store i64 %t100, ptr %l55, !tbaa !24
  %t101 = load i64, ptr %l55, !tbaa !24
  %t102 = icmp sge i64 %t101, 0
  br i1 %t102, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_a19345797ce3092f_df897154cd0b0613)
  unreachable
bb20:
  %t104 = load i64, ptr %l55, !tbaa !24
  %t105 = icmp sle i64 %t104, 1152921504606846975
  br i1 %t105, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_8629e3295afcf15a_58f771f6fdbc30de)
  unreachable
bb22:
  %t107 = load i64, ptr %l55, !tbaa !24
  %t108 = mul i64 %t107, 8
  %t109 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t108)
  store i64 0, ptr %t110
  br label %fill.111
fill.111:
  %t114 = load i64, ptr %t110
  %t115 = icmp slt i64 %t114, %t107
  br i1 %t115, label %fillb.112, label %filld.113
fillb.112:
  %t116 = getelementptr i64, ptr %t109, i64 %t114
  store i64 -1, ptr %t116
  %t117 = add i64 %t114, 1
  store i64 %t117, ptr %t110
  br label %fill.111
filld.113:
  %t118 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t109, 1
  %t121 = load ptr, ptr %l54, !tbaa !29
  %t122 = getelementptr %"compiler/eval:Machine", ptr %t121, i32 0, i32 19
  store { i64, ptr } %t119, ptr %t122, !tbaa !27
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l59, !tbaa !29
  %t124 = load i64, ptr %l4, !tbaa !24
  store i64 %t124, ptr %l60, !tbaa !24
  %t125 = load i64, ptr %l60, !tbaa !24
  %t126 = icmp sge i64 %t125, 0
  br i1 %t126, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_8629e3295afcf15a_58f771f6fdbc30de)
  unreachable
bb24:
  %t128 = load i64, ptr %l60, !tbaa !24
  %t129 = icmp sle i64 %t128, 1152921504606846975
  br i1 %t129, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_985556dab320f6d9_efe4e1681fb7461d)
  unreachable
bb26:
  %t131 = load i64, ptr %l60, !tbaa !24
  %t132 = mul i64 %t131, 8
  %t133 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t132)
  store i64 0, ptr %t134
  br label %fill.135
fill.135:
  %t138 = load i64, ptr %t134
  %t139 = icmp slt i64 %t138, %t131
  br i1 %t139, label %fillb.136, label %filld.137
fillb.136:
  %t140 = getelementptr i64, ptr %t133, i64 %t138
  store i64 -1, ptr %t140
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %t134
  br label %fill.135
filld.137:
  %t142 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t133, 1
  %t145 = load ptr, ptr %l59, !tbaa !29
  %t146 = getelementptr %"compiler/eval:Machine", ptr %t145, i32 0, i32 20
  store { i64, ptr } %t143, ptr %t146, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  store i64 %t149, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t151 = load i64, ptr %l9, !tbaa !24
  %t152 = load i64, ptr %l8, !tbaa !24
  %t155 = icmp sgt i64 %t151, %t152
  br i1 %t155, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_985556dab320f6d9_efe4e1681fb7461d)
  unreachable
bb28:
  %t157 = load i64, ptr %l10, !tbaa !24
  %t159 = icmp sgt i64 %t157, 0
  br i1 %t159, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb33
bb30:
  %t161 = load i64, ptr %l9, !tbaa !24
  %t162 = load i64, ptr %l8, !tbaa !24
  %t165 = sub i64 %t161, %t162
  %t166 = load i64, ptr %l10, !tbaa !24
  %t169 = add i64 %t165, %t166
  %t171 = sub i64 %t169, 1
  %t172 = load i64, ptr %l10, !tbaa !24
  %t175 = sdiv i64 %t171, %t172
  store i64 %t175, ptr %l72, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb32
bb32:
  %t177 = load i64, ptr %l72, !tbaa !24
  store i64 %t177, ptr %l69, !tbaa !24
  br label %bb33
bb33:
  %t178 = load i64, ptr %l69, !tbaa !24
  store i64 %t178, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb34
bb34:
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = load i64, ptr %l11, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb35, label %bb36
bb35:
  br label %bb39
bb36:
  br label %bb37
bb37:
  %t187 = load i64, ptr %l8, !tbaa !24
  %t188 = load i64, ptr %l12, !tbaa !24
  %t189 = load i64, ptr %l10, !tbaa !24
  %t192 = mul i64 %t188, %t189
  %t195 = add i64 %t187, %t192
  store i64 %t195, ptr %l13, !tbaa !24
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/eval:Machine", ptr %t197, i32 0, i32 18
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  store { i64, ptr } %t200, ptr %l91, !tbaa !27
  %t201 = load i64, ptr %l13, !tbaa !24
  %t202 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t202, ptr %l93, !tbaa !27
  %t203 = load i64, ptr %l13, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i64, ptr %t206, i64 %t203
  %t208 = load i64, ptr %t207, !tbaa !34
  %t211 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i64, ptr %t212, i64 %t201
  store i64 %t208, ptr %t213, !tbaa !34
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/eval:Machine", ptr %t214, i32 0, i32 19
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l97, !tbaa !27
  %t218 = load i64, ptr %l13, !tbaa !24
  %t219 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t219, ptr %l99, !tbaa !27
  %t220 = load i64, ptr %l13, !tbaa !24
  %t222 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr i64, ptr %t223, i64 %t220
  %t225 = load i64, ptr %t224, !tbaa !34
  %t228 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i64, ptr %t229, i64 %t218
  store i64 %t225, ptr %t230, !tbaa !34
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/eval:Machine", ptr %t231, i32 0, i32 20
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  store { i64, ptr } %t234, ptr %l103, !tbaa !27
  %t235 = load i64, ptr %l13, !tbaa !24
  %t236 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t236, ptr %l105, !tbaa !27
  %t237 = load i64, ptr %l13, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr i64, ptr %t240, i64 %t237
  %t242 = load i64, ptr %t241, !tbaa !34
  %t245 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr i64, ptr %t246, i64 %t235
  store i64 %t242, ptr %t247, !tbaa !34
  br label %bb38
bb38:
  %t248 = load i64, ptr %l12, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l12, !tbaa !24
  br label %bb34
bb39:
  br label %bb40
bb40:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i1
  %l28 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 19
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp slt i64 %t5, %t11
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 19
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 %t20
  %t25 = load i64, ptr %t24, !tbaa !34
  %t27 = icmp sge i64 %t25, 0
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t29 = load i1, ptr %l11, !tbaa !21
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 19
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l18, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i64, ptr %t37, i64 %t34
  %t39 = load i64, ptr %t38, !tbaa !34
  store i64 %t39, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshapeOf(ptr %v0, ptr %t41, i32 %t42)
  store i64 %t45, ptr %l23
  br label %bb7
bb7:
  %t46 = load i64, ptr %l23, !tbaa !24
  store i64 %t46, ptr %l3, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2esettled(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l26
  br label %bb8
bb8:
  %t52 = load i1, ptr %l26, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/eval:Machine", ptr %t53, i32 0, i32 19
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l28, !tbaa !27
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t57
  store i64 %t58, ptr %t63, !tbaa !34
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t64 = load i64, ptr %l3, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l24 = alloca i64
  %l28 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i1
  %l42 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 18
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t14 = icmp slt i64 %t5, %t11
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 18
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 %t20
  %t25 = load i64, ptr %t24, !tbaa !34
  %t27 = icmp sge i64 %t25, 0
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t29 = load i1, ptr %l11, !tbaa !21
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 18
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l18, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i64, ptr %t37, i64 %t34
  %t39 = load i64, ptr %t38, !tbaa !34
  store i64 %t39, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load i32, ptr %l1, !tbaa !23
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t45 = icmp eq i32 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  store i64 8, ptr %l24, !tbaa !24
  br label %bb17
bb8:
  %t47 = load i32, ptr %l1, !tbaa !23
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t51 = icmp eq i32 %t47, %t48
  br i1 %t51, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb12
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l1, !tbaa !23
  %t57 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l31
  br label %bb11
bb11:
  %t58 = load i1, ptr %l31, !tbaa !21
  %t59 = xor i1 %t58, true
  store i1 %t59, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t61 = load i1, ptr %l28, !tbaa !21
  br i1 %t61, label %bb13, label %bb14
bb13:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb16
bb14:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/eval:Machine", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l37
  br label %bb15
bb15:
  %t70 = load i64, ptr %l37, !tbaa !24
  store i64 %t70, ptr %l33, !tbaa !24
  br label %bb16
bb16:
  %t71 = load i64, ptr %l33, !tbaa !24
  store i64 %t71, ptr %l24, !tbaa !24
  br label %bb17
bb17:
  %t72 = load i64, ptr %l24, !tbaa !24
  store i64 %t72, ptr %l3, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2esettled(ptr %v0, ptr %t73, i32 %t74)
  store i1 %t77, ptr %l40
  br label %bb18
bb18:
  %t78 = load i1, ptr %l40, !tbaa !21
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/eval:Machine", ptr %t79, i32 0, i32 18
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l42, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load i64, ptr %l3, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i64, ptr %t88, i64 %t83
  store i64 %t84, ptr %t89, !tbaa !34
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t90 = load i64, ptr %l3, !tbaa !24
  store i64 %t90, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eslice(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, %"compiler/mir:Lvalue" %a3, { i64, [4 x i64] } %a4, { i64, [4 x i64] } %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca { i64, [4 x i64] }
  %l7 = alloca { %"compiler/eval:Ptr", i32 }
  %l8 = alloca %"compiler/eval:Ptr"
  %l9 = alloca i32
  %l10 = alloca { %"compiler/eval:Ptr", i64 }
  %l11 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca i32
  %l21 = alloca { %"compiler/eval:Ptr", i32 }
  %l29 = alloca { %"compiler/eval:Ptr", i64 }
  %l32 = alloca ptr
  %l36 = alloca i64
  %l40 = alloca i32
  %l41 = alloca i64
  %l42 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca i32
  %l51 = alloca i64
  %l56 = alloca i1
  %l60 = alloca i1
  %l66 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca i64
  %l74 = alloca i1
  %l77 = alloca %"compiler/eval:Ptr"
  %l84 = alloca %"compiler/eval:Ptr"
  %l89 = alloca i32
  %l93 = alloca i32
  %l96 = alloca i1
  %l98 = alloca ptr
  %l100 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca i32
  %l106 = alloca i32
  %l116 = alloca ptr
  %l120 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store { i64, [4 x i64] } %a4, ptr %l4
  store { i64, [4 x i64] } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t7 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t1, i64 %t2, %"compiler/mir:Lvalue" %a3)
  store { %"compiler/eval:Ptr", i32 } %t7, ptr %l21
  br label %bb1
bb1:
  %t8 = load { %"compiler/eval:Ptr", i32 }, ptr %l21
  store { %"compiler/eval:Ptr", i32 } %t8, ptr %l7
  %t9 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l7, i32 0, i32 0
  %t10 = load %"compiler/eval:Ptr", ptr %t9
  store %"compiler/eval:Ptr" %t10, ptr %l8
  %t12 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l7, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l9, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:Machine", ptr %t15, i32 0, i32 13
  %t18 = load i1, ptr %t17, !tbaa !21
  br i1 %t18, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/eval:Ptr", ptr %l8
  %t22 = load i32, ptr %l9, !tbaa !23
  %t26 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t20, %"compiler/eval:Ptr" %t21, i32 %t22)
  store { %"compiler/eval:Ptr", i64 } %t26, ptr %l29
  br label %bb5
bb5:
  %t27 = load { %"compiler/eval:Ptr", i64 }, ptr %l29
  store { %"compiler/eval:Ptr", i64 } %t27, ptr %l10
  %t28 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l10, i32 0, i32 0
  %t29 = load %"compiler/eval:Ptr", ptr %t28
  store %"compiler/eval:Ptr" %t29, ptr %l11
  %t31 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l10, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l12, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l32, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  %t37 = load { i64, [4 x i64] }, ptr %l4
  %t41 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t35, i64 %t36, { i64, [4 x i64] } %t37)
  store i64 %t41, ptr %l36
  br label %bb6
bb6:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load { i64, [4 x i64] }, ptr %l4
  %t48 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t42, i64 %t43, { i64, [4 x i64] } %t44)
  store i32 %t48, ptr %l40
  br label %bb7
bb7:
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t50 = load i64, ptr %l36, !tbaa !24
  %t51 = load i32, ptr %l40, !tbaa !23
  %t52 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t49, i64 %t50, i32 %t51)
  store i64 %t52, ptr %l41
  br label %bb8
bb8:
  %t53 = load i64, ptr %l41, !tbaa !24
  store i64 %t53, ptr %l13, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l42, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load { i64, [4 x i64] }, ptr %l5
  %t61 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t55, i64 %t56, { i64, [4 x i64] } %t57)
  store i64 %t61, ptr %l46
  br label %bb9
bb9:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i64, ptr %l1, !tbaa !24
  %t64 = load { i64, [4 x i64] }, ptr %l5
  %t68 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t62, i64 %t63, { i64, [4 x i64] } %t64)
  store i32 %t68, ptr %l50
  br label %bb10
bb10:
  %t69 = load ptr, ptr %l42, !tbaa !29
  %t70 = load i64, ptr %l46, !tbaa !24
  %t71 = load i32, ptr %l50, !tbaa !23
  %t72 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t69, i64 %t70, i32 %t71)
  store i64 %t72, ptr %l51
  br label %bb11
bb11:
  %t73 = load i64, ptr %l51, !tbaa !24
  store i64 %t73, ptr %l14, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/eval:Machine", ptr %t74, i32 0, i32 13
  %t77 = load i1, ptr %t76, !tbaa !21
  br i1 %t77, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t79 = load i64, ptr %l13, !tbaa !24
  %t81 = icmp slt i64 %t79, 0
  br i1 %t81, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb17
bb16:
  %t83 = load i64, ptr %l13, !tbaa !24
  %t84 = load i64, ptr %l14, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  store i1 %t87, ptr %l56, !tbaa !21
  br label %bb17
bb17:
  %t89 = load i1, ptr %l56, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb20
bb19:
  %t90 = load i64, ptr %l14, !tbaa !24
  %t91 = load i64, ptr %l12, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  store i1 %t94, ptr %l60, !tbaa !21
  br label %bb20
bb20:
  %t96 = load i1, ptr %l60, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyOutside, !tbaa !27
  %t99 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t99, ptr %t97, { i64, ptr } %t98)
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l66, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l9, !tbaa !23
  %t107 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l69
  br label %bb25
bb25:
  %t108 = load ptr, ptr %l66, !tbaa !29
  %t109 = load i32, ptr %l69, !tbaa !23
  %t110 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t108, i32 %t109)
  store i64 %t110, ptr %l70
  br label %bb26
bb26:
  %t111 = load i64, ptr %l70, !tbaa !24
  store i64 %t111, ptr %l15, !tbaa !24
  %t112 = load i64, ptr %l14, !tbaa !24
  %t113 = load i64, ptr %l13, !tbaa !24
  %t116 = icmp sgt i64 %t112, %t113
  br i1 %t116, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb29
bb28:
  %t118 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 0
  %t119 = load i64, ptr %t118, !tbaa !24
  %t121 = icmp ne i64 %t119, 0
  store i1 %t121, ptr %l74, !tbaa !21
  br label %bb29
bb29:
  %t123 = load i1, ptr %l74, !tbaa !21
  br i1 %t123, label %bb30, label %bb31
bb30:
  %t124 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 0
  %t125 = load i64, ptr %t124, !tbaa !24
  %t126 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 1
  %t127 = load i64, ptr %t126, !tbaa !24
  %t128 = load i64, ptr %l13, !tbaa !24
  %t129 = load i64, ptr %l15, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t135 = add i64 %t127, %t132
  %t138 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t125, i64 %t135)
  store %"compiler/eval:Ptr" %t138, ptr %l84
  br label %bb32
bb31:
  %t139 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t139, ptr %l77
  br label %bb33
bb32:
  %t141 = load %"compiler/eval:Ptr", ptr %l84
  store %"compiler/eval:Ptr" %t141, ptr %l77
  br label %bb33
bb33:
  %t142 = load %"compiler/eval:Ptr", ptr %l77
  store %"compiler/eval:Ptr" %t142, ptr %l16
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/eval:Machine", ptr %t143, i32 0, i32 0
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t146, i32 %a6)
  store i32 %t150, ptr %l89
  br label %bb34
bb34:
  %t151 = load i32, ptr %l89, !tbaa !23
  store i32 %t151, ptr %l17, !tbaa !23
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/eval:Machine", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t156 = load i32, ptr %l17, !tbaa !23
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t155, i32 %t156)
  store i32 %t159, ptr %l93
  br label %bb35
bb35:
  %t160 = load i32, ptr %l93
  %t162 = trunc i64 20 to i32
  %t163 = icmp eq i32 %t160, %t162
  br i1 %t163, label %bb36, label %bb37
bb36:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/eval:Machine", ptr %t165, i32 0, i32 0
  %t168 = load ptr, ptr %t167, !tbaa !29
  store ptr %t168, ptr %l98, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/eval:Machine", ptr %t169, i32 0, i32 0
  %t172 = load ptr, ptr %t171, !tbaa !29
  store ptr %t172, ptr %l100, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/eval:Machine", ptr %t173, i32 0, i32 0
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t177 = load i32, ptr %l17, !tbaa !23
  %t180 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t176, i32 %t177)
  store i32 %t180, ptr %l104
  br label %bb38
bb37:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb41
bb38:
  %t181 = load ptr, ptr %l100, !tbaa !29
  %t182 = load i32, ptr %l104, !tbaa !23
  %t183 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t181, i32 %t182)
  store i32 %t183, ptr %l105
  br label %bb39
bb39:
  %t184 = load ptr, ptr %l98, !tbaa !29
  %t185 = load i32, ptr %l105, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t184, i32 %t185)
  store i32 %t186, ptr %l106
  br label %bb40
bb40:
  %t187 = load i32, ptr %l106, !tbaa !23
  %t188 = icmp ne i32 %t187, 0
  store i1 %t188, ptr %l96, !tbaa !21
  br label %bb41
bb41:
  %t190 = load i1, ptr %l96, !tbaa !21
  br i1 %t190, label %bb42, label %bb43
bb42:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load %"compiler/eval:Ptr", ptr %l2
  %t193 = load %"compiler/eval:Ptr", ptr %l16
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t191, %"compiler/eval:Ptr" %t192, %"compiler/eval:Ptr" %t193)
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load %"compiler/eval:Ptr", ptr %l2
  %t199 = load i64, ptr %l14, !tbaa !24
  %t200 = load i64, ptr %l13, !tbaa !24
  %t203 = sub i64 %t199, %t200
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t197, %"compiler/eval:Ptr" %t198, i64 8, i64 %t203)
  br label %bb46
bb46:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l116, !tbaa !29
  %t208 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t209 = load i64, ptr %t208, !tbaa !24
  %t210 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t211 = load i64, ptr %t210, !tbaa !24
  %t213 = add i64 %t211, 8
  %t216 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t209, i64 %t213)
  store %"compiler/eval:Ptr" %t216, ptr %l120
  br label %bb47
bb47:
  %t217 = load %"compiler/eval:Ptr", ptr %l16
  %t218 = load ptr, ptr %l116, !tbaa !29
  %t219 = load %"compiler/eval:Ptr", ptr %l120
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t218, %"compiler/eval:Ptr" %t219, %"compiler/eval:Ptr" %t217)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2etable(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l21 = alloca %"compiler/eval:Ptr"
  %l22 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l31 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l46 = alloca %"compiler/eval:Ptr"
  %l47 = alloca ptr
  %l48 = alloca %"compiler/eval:Ptr"
  %l51 = alloca %"compiler/eval:Ptr"
  %l57 = alloca i64
  %l60 = alloca i64
  %l78 = alloca ptr
  %l83 = alloca %"compiler/eval:Ptr"
  %l85 = alloca { i64, ptr }
  %l88 = alloca %"compiler/eval:Ptr"
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 31
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l17
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l16
  br label %bb1
bb1:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l12, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l12, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp ne i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s1, i64 %t18, i64 0)
  store %"compiler/eval:Ptr" %t20, ptr %l21
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  %t21 = load %"compiler/eval:Ptr", ptr %l21
  store %"compiler/eval:Ptr" %t21, ptr %rv
  br label %ret
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/eval:Machine", ptr %t22, i32 0, i32 30
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_H6a636ae5a18dc9bdacf7dd1692df3f31(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l27
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb10, label %ok.32, !prof !99
ok.32:
  store { i64, ptr } %t29, ptr %l26
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  br label %bb13
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t36 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t36, ptr %t34, { i64, ptr } %t35)
  br label %bb12
bb12:
  %t39 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t39, ptr %rv
  br label %ret
bb13:
  %t41 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t41, ptr %l3, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 29
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__H9861f6f09602cf23d49075e82ac9429b(ptr %v0, ptr %t44, i64 %t45)
  %t49 = extractvalue { i32, i32 } %t48, 1
  %t50 = extractvalue { i32, i32 } %t48, 0
  store i32 %t50, ptr %l36
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb15, label %ok.52, !prof !99
ok.52:
  store i32 %t49, ptr %l35
  br label %bb14
bb14:
  %t53 = load i32, ptr %l35, !tbaa !23
  store i32 %t53, ptr %l31, !tbaa !23
  br label %bb17
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t54, ptr %l31, !tbaa !23
  br label %bb17
bb17:
  %t56 = load i32, ptr %l31, !tbaa !23
  store i32 %t56, ptr %l4, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t62 = add i64 %t60, 1
  %t64 = mul i64 8, %t62
  %t65 = load i64, ptr @G_2ecompiler_2feval_2eaData, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/eval:Machine", ptr %t66, i32 0, i32 61
  %t69 = load i64, ptr %t68, !tbaa !24
  %t74 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t57, i64 %t64, i64 %t65, i64 %t69)
  store %"compiler/eval:Ptr" %t74, ptr %l46
  br label %bb18
bb18:
  %t75 = load %"compiler/eval:Ptr", ptr %l46
  store %"compiler/eval:Ptr" %t75, ptr %l5
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l47, !tbaa !29
  %t77 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t77, ptr %l48
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l4, !tbaa !23
  %t82 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2etypeid(ptr %v0, ptr %t78, i32 %t79)
  store %"compiler/eval:Ptr" %t82, ptr %l51
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t84 = load %"compiler/eval:Ptr", ptr %l48
  %t85 = load %"compiler/eval:Ptr", ptr %l51
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t83, %"compiler/eval:Ptr" %t84, %"compiler/eval:Ptr" %t85)
  br label %bb20
bb20:
  store i64 0, ptr %l6, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t91 = load i64, ptr %l6, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb21, label %bb22
bb21:
  %t96 = load i64, ptr %l8, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb26
bb23:
  %t100 = load i64, ptr %l7, !tbaa !24
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l8, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l60, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb25
bb25:
  %t116 = load i64, ptr %l60, !tbaa !24
  store i64 %t116, ptr %l57, !tbaa !24
  br label %bb26
bb26:
  %t117 = load i64, ptr %l57, !tbaa !24
  store i64 %t117, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb29:
  br label %bb30
bb30:
  %t126 = load i64, ptr %l6, !tbaa !24
  %t127 = load i64, ptr %l10, !tbaa !24
  %t128 = load i64, ptr %l8, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l11, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l78, !tbaa !29
  %t137 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = add i64 %t139, 1
  %t143 = mul i64 8, %t141
  %t146 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t138, i64 %t143)
  store %"compiler/eval:Ptr" %t146, ptr %l83
  br label %bb31
bb31:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t148, ptr %l85, !tbaa !27
  %t149 = load i64, ptr %l11, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, [2 x i64] }, ptr %t152, i64 %t149
  %t154 = load { i64, [2 x i64] }, ptr %t153
  %t157 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodePtr(ptr %v0, ptr %t147, { i64, [2 x i64] } %t154)
  store %"compiler/eval:Ptr" %t157, ptr %l88
  br label %bb32
bb32:
  %t158 = load ptr, ptr %l78, !tbaa !29
  %t159 = load %"compiler/eval:Ptr", ptr %l83
  %t160 = load %"compiler/eval:Ptr", ptr %l88
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t158, %"compiler/eval:Ptr" %t159, %"compiler/eval:Ptr" %t160)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb34:
  %t161 = load i64, ptr %l10, !tbaa !24
  %t163 = add i64 %t161, 1
  store i64 %t163, ptr %l10, !tbaa !24
  br label %bb27
bb35:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/eval:Machine", ptr %t165, i32 0, i32 31
  %t168 = load i64, ptr %l1, !tbaa !24
  %t169 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t170 = load i64, ptr %t169, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t167, i64 %t168, i64 %t170)
  br label %bb36
bb36:
  %t174 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t174, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2etail(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Call" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/mir:Call"
  %l3 = alloca %"compiler/eval:frame"
  %l4 = alloca i64
  %l5 = alloca %"compiler/eval:frame"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l24 = alloca i64
  %l30 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l94 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l107 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/mir:Call" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 49
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l14, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  %t10 = load %"compiler/eval:frame", ptr %t9
  store %"compiler/eval:frame" %t10, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = getelementptr %"compiler/mir:Call", ptr %l2, i32 0, i32 0
  %t15 = load { i64, [7 x i64] }, ptr %t14
  %t16 = getelementptr %"compiler/mir:Call", ptr %l2, i32 0, i32 1
  %t17 = load %"compiler/mir:Range", ptr %t16
  %t18 = getelementptr %"compiler/mir:Call", ptr %l2, i32 0, i32 2
  %t19 = load %"compiler/mir:Range", ptr %t18
  %t20 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 7
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 8
  %t23 = load i64, ptr %t22, !tbaa !24
  %t31 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eenter(ptr %v0, ptr %t12, i64 %t13, { i64, [7 x i64] } %t15, %"compiler/mir:Range" %t17, %"compiler/mir:Range" %t19, i64 %t21, i64 %t23)
  store i64 %t31, ptr %l24
  br label %bb1
bb1:
  %t32 = load i64, ptr %l24, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  br i1 %t35, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropOwnDefers(ptr %v0, ptr %t37, i64 %t38)
  br label %bb5
bb5:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/eval:Machine", ptr %t41, i32 0, i32 49
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l30, !tbaa !27
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr %"compiler/eval:frame", ptr %t48, i64 %t45
  %t50 = load %"compiler/eval:frame", ptr %t49
  store %"compiler/eval:frame" %t50, ptr %l5
  %t52 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 3
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 3
  %t55 = load i64, ptr %t54, !tbaa !24
  %t58 = sub i64 %t53, %t55
  store i64 %t58, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Machine", ptr %t60, i32 0, i32 52
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 3
  %t65 = load i64, ptr %t64, !tbaa !24
  %t68 = sub i64 %t63, %t65
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb6, label %bb7
bb6:
  %t76 = load i64, ptr %l9, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb11
bb8:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l46, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb10
bb10:
  %t96 = load i64, ptr %l46, !tbaa !24
  store i64 %t96, ptr %l43, !tbaa !24
  br label %bb11
bb11:
  %t97 = load i64, ptr %l43, !tbaa !24
  store i64 %t97, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  %t98 = load i64, ptr %l11, !tbaa !24
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t106 = load i64, ptr %l7, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l12, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/eval:Machine", ptr %t116, i32 0, i32 51
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l65, !tbaa !27
  %t120 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 3
  %t121 = load i64, ptr %t120, !tbaa !24
  %t122 = load i64, ptr %l12, !tbaa !24
  %t125 = add i64 %t121, %t122
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/eval:Machine", ptr %t126, i32 0, i32 51
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l70, !tbaa !27
  %t130 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 3
  %t131 = load i64, ptr %t130, !tbaa !24
  %t132 = load i64, ptr %l12, !tbaa !24
  %t135 = add i64 %t131, %t132
  %t137 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i64, ptr %t138, i64 %t135
  %t140 = load i64, ptr %t139, !tbaa !34
  %t143 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i64, ptr %t144, i64 %t125
  store i64 %t140, ptr %t145, !tbaa !34
  br label %bb16
bb16:
  %t146 = load i64, ptr %l11, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l11, !tbaa !24
  br label %bb12
bb17:
  %t150 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load i64, ptr %l6, !tbaa !24
  %t155 = sub i64 %t151, %t152
  %t157 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 3
  store i64 %t155, ptr %t157, !tbaa !24
  %t158 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 4
  %t159 = load i64, ptr %t158, !tbaa !24
  %t160 = load i64, ptr %l6, !tbaa !24
  %t163 = sub i64 %t159, %t160
  %t165 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 4
  store i64 %t163, ptr %t165, !tbaa !24
  %t166 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 5
  %t167 = load i64, ptr %t166, !tbaa !24
  %t168 = load i64, ptr %l6, !tbaa !24
  %t171 = sub i64 %t167, %t168
  %t173 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 5
  store i64 %t171, ptr %t173, !tbaa !24
  %t174 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 9
  %t175 = load i64, ptr %t174, !tbaa !24
  %t177 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 9
  store i64 %t175, ptr %t177, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/eval:Machine", ptr %t178, i32 0, i32 49
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l88, !tbaa !27
  %t182 = load i64, ptr %l1, !tbaa !24
  %t183 = load %"compiler/eval:frame", ptr %l5
  %t186 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr %"compiler/eval:frame", ptr %t187, i64 %t182
  store %"compiler/eval:frame" %t183, ptr %t188
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l91, !tbaa !29
  %t190 = load ptr, ptr %l91, !tbaa !29
  %t191 = getelementptr %"compiler/eval:Machine", ptr %t190, i32 0, i32 50
  %t192 = load i64, ptr %t191, !tbaa !24
  %t194 = sub i64 %t192, 1
  %t196 = load ptr, ptr %l91, !tbaa !29
  %t197 = getelementptr %"compiler/eval:Machine", ptr %t196, i32 0, i32 50
  store i64 %t194, ptr %t197, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l94, !tbaa !29
  %t199 = load ptr, ptr %l94, !tbaa !29
  %t200 = getelementptr %"compiler/eval:Machine", ptr %t199, i32 0, i32 52
  %t201 = load i64, ptr %t200, !tbaa !24
  %t202 = load i64, ptr %l6, !tbaa !24
  %t205 = sub i64 %t201, %t202
  %t207 = load ptr, ptr %l94, !tbaa !29
  %t208 = getelementptr %"compiler/eval:Machine", ptr %t207, i32 0, i32 52
  store i64 %t205, ptr %t208, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/eval:Machine", ptr %t209, i32 0, i32 17
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l99, !tbaa !27
  %t213 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 0
  %t214 = load i64, ptr %t213, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr %"compiler/eval:cfn", ptr %t217, i64 %t214
  %t219 = getelementptr %"compiler/eval:cfn", ptr %t218, i32 0, i32 17
  %t220 = load i1, ptr %t219, !tbaa !21
  br i1 %t220, label %bb18, label %bb19
bb18:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l102, !tbaa !29
  %t223 = load ptr, ptr %l102, !tbaa !29
  %t224 = getelementptr %"compiler/eval:Machine", ptr %t223, i32 0, i32 5
  %t225 = load i64, ptr %t224, !tbaa !24
  %t227 = sub i64 %t225, 1
  %t229 = load ptr, ptr %l102, !tbaa !29
  %t230 = getelementptr %"compiler/eval:Machine", ptr %t229, i32 0, i32 5
  store i64 %t227, ptr %t230, !tbaa !24
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 6
  %t233 = load i64, ptr %t232, !tbaa !24
  %t236 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t231, i64 %t233)
  store i1 %t236, ptr %l107
  br label %bb21
bb21:
  %t237 = load i1, ptr %l107, !tbaa !21
  br i1 %t237, label %bb22, label %bb23
bb22:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/eval:Machine", ptr %t238, i32 0, i32 53
  %t241 = getelementptr %"compiler/eval:frame", ptr %l3, i32 0, i32 6
  %t242 = load i64, ptr %t241, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t240, i64 %t242)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskEnded(ptr %v0, ptr %a0, %"compiler/eval:frame" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:frame"
  %l2 = alloca i64
  %l3 = alloca %"compiler/eval:task"
  %l4 = alloca %"compiler/mir:Fn"
  %l5 = alloca %"compiler/mir:Task"
  %l6 = alloca i64
  %l7 = alloca { i64, [7 x i64] }
  %l8 = alloca i32
  %l9 = alloca { i64, [4 x i64] }
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca { { i64, ptr }, i64 }
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca %"compiler/mir:TaskClause"
  %l25 = alloca i1
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l32 = alloca %"compiler/typed:Item"
  %l33 = alloca %"compiler/eval:Ptr"
  %l34 = alloca %"compiler/eval:Ptr"
  %l35 = alloca %"compiler/eval:Ptr"
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"compiler/mir:Fn"
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l49 = alloca { i64, [4 x i64] }
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca { i64, [4 x i64] }
  %l57 = alloca i64
  %l58 = alloca %"compiler/mir:Fn"
  %l59 = alloca { i64, [8 x i64] }
  %l60 = alloca i32
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca %"compiler/eval:scope"
  %l74 = alloca %"compiler/eval:task"
  %l78 = alloca %"compiler/mir:Fn"
  %l81 = alloca %"compiler/mir:Task"
  %l86 = alloca i32
  %l101 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca i32
  %l110 = alloca i32
  %l114 = alloca { i64, ptr }
  %l122 = alloca i1
  %l127 = alloca i32
  %l128 = alloca { i64, ptr }
  %l136 = alloca { { i64, ptr }, i64 }
  %l142 = alloca i32
  %l145 = alloca i32
  %l169 = alloca %"compiler/mir:TaskClause"
  %l175 = alloca i32
  %l178 = alloca i32
  %l202 = alloca %"compiler/typed:Item"
  %l207 = alloca i1
  %l208 = alloca i1
  %l211 = alloca i1
  %l233 = alloca %"compiler/eval:Ptr"
  %l236 = alloca %"compiler/eval:Ptr"
  %l237 = alloca ptr
  %l241 = alloca %"compiler/eval:Ptr"
  %l242 = alloca %"compiler/eval:Ptr"
  %l245 = alloca i1
  %l247 = alloca { i64, ptr }
  %l256 = alloca i64
  %l258 = alloca ptr
  %l262 = alloca { i64, ptr }
  %l267 = alloca { i64, [2 x i64] }
  %l268 = alloca i64
  %l269 = alloca i32
  %l276 = alloca i64
  %l282 = alloca %"compiler/mir:Fn"
  %l284 = alloca i64
  %l286 = alloca i64
  %l291 = alloca { i64, [1 x i64] }
  %l302 = alloca i64
  %l305 = alloca i64
  %l324 = alloca { i64, ptr }
  %l326 = alloca { i64, ptr }
  %l350 = alloca i64
  %l353 = alloca i64
  %l376 = alloca { i64, [4 x i64] }
  %l389 = alloca { i64, [4 x i64] }
  %l407 = alloca %"compiler/mir:Fn"
  %l410 = alloca { i64, ptr }
  %l413 = alloca %"compiler/mir:BasicBlock"
  %l419 = alloca { i64, ptr }
  %l421 = alloca { i64, ptr }
  %l434 = alloca %"compiler/eval:scope"
  %l438 = alloca ptr
  %l439 = alloca i64
  %l440 = alloca i32
  %l444 = alloca %"compiler/eval:scope"
  %l448 = alloca i64
  %l452 = alloca %"compiler/eval:scope"
  %l457 = alloca %"compiler/eval:scope"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t27 = alloca %"compiler/mir:Fn", align 8
  %t480 = alloca %"compiler/mir:Fn", align 8
  %t613 = alloca { i64, [4 x i64] }, align 8
  %t729 = alloca { i64, [5 x i64] }, align 8
  %t757 = alloca %"compiler/mir:Fn", align 8
  %t824 = alloca %"compiler/eval:scope", align 8
  %t842 = alloca %"compiler/eval:scope", align 8
  %t860 = alloca %"compiler/eval:scope", align 8
  %t872 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store %"compiler/eval:frame" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 12
  %t2 = load i1, ptr %t1, !tbaa !21
  %t4 = xor i1 %t2, true
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 8
  %t8 = load i64, ptr %t7, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreeTask(ptr %v0, ptr %t6, i64 %t8)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t11 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 8
  %t12 = load i64, ptr %t11, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 47
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = call %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/eval:task" %t20, ptr %l74
  br label %bb5
bb5:
  %t21 = load %"compiler/eval:task", ptr %l74
  store %"compiler/eval:task" %t21, ptr %l3
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/eval:Machine", ptr %t22, i32 0, i32 16
  %t25 = getelementptr %"compiler/eval:task", ptr %l3, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t27, ptr %v0, ptr %v0, ptr %t24, i64 %t26)
  call void @llvm.memmove.p0.p0.i64(ptr %l78, ptr %t27, i64 248, i1 false)
  br label %bb6
bb6:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l78, i64 248, i1 false)
  %t30 = getelementptr %"compiler/mir:Fn", ptr %l4, i32 0, i32 16
  %t31 = getelementptr %"compiler/eval:task", ptr %l3, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t35 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t30, i64 %t32)
  store %"compiler/mir:Task" %t35, ptr %l81
  br label %bb7
bb7:
  %t36 = load %"compiler/mir:Task", ptr %l81
  store %"compiler/mir:Task" %t36, ptr %l5
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/eval:Machine", ptr %t37, i32 0, i32 50
  %t40 = load i64, ptr %t39, !tbaa !24
  %t42 = sub i64 %t40, 1
  store i64 %t42, ptr %l6, !tbaa !24
  %t44 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 0
  %t45 = load { i64, [7 x i64] }, ptr %t44
  store { i64, [7 x i64] } %t45, ptr %l7
  %t47 = load { i64, [7 x i64] }, ptr %l7
  %t49 = extractvalue { i64, [7 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 0
  br i1 %t50, label %bb8, label %bb9
bb8:
  %t52 = getelementptr { i64, [7 x i64] }, ptr %l7, i32 0, i32 1
  %t53 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t52, i32 0, i32 1
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l8, !tbaa !23
  br label %bb14
bb9:
  %t56 = load { i64, [7 x i64] }, ptr %l7
  %t58 = extractvalue { i64, [7 x i64] } %t56, 0
  %t59 = icmp eq i64 %t58, 1
  br i1 %t59, label %bb10, label %bb11
bb10:
  %t61 = getelementptr { i64, [7 x i64] }, ptr %l7, i32 0, i32 1
  %t62 = getelementptr { i64, i32 }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l8, !tbaa !23
  br label %bb14
bb11:
  %t65 = load { i64, [7 x i64] }, ptr %l7
  %t67 = extractvalue { i64, [7 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 3
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = getelementptr { i64, [7 x i64] }, ptr %l7, i32 0, i32 1
  %t71 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t70, i32 0, i32 2
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l8, !tbaa !23
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t74 = load i32, ptr %l8, !tbaa !23
  store i32 %t74, ptr %l86, !tbaa !23
  br label %bb22
bb15:
  %t76 = load { i64, [7 x i64] }, ptr %l7
  %t78 = extractvalue { i64, [7 x i64] } %t76, 0
  %t79 = icmp eq i64 %t78, 2
  br i1 %t79, label %bb16, label %bb17
bb16:
  %t81 = getelementptr { i64, [7 x i64] }, ptr %l7, i32 0, i32 1
  %t82 = getelementptr { { i64, [4 x i64] } }, ptr %t81, i32 0, i32 0
  %t83 = load { i64, [4 x i64] }, ptr %t82
  store { i64, [4 x i64] } %t83, ptr %l9
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/eval:Machine", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l101, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l6, !tbaa !24
  %t91 = load { i64, [4 x i64] }, ptr %l9
  %t95 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t89, i64 %t90, { i64, [4 x i64] } %t91)
  store i32 %t95, ptr %l105
  br label %bb19
bb19:
  %t96 = load ptr, ptr %l101, !tbaa !29
  %t97 = load i32, ptr %l105, !tbaa !23
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t98, ptr %l106
  br label %bb20
bb20:
  %t99 = load i32, ptr %l106, !tbaa !23
  store i32 %t99, ptr %l86, !tbaa !23
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_da2497658df77092_f2a1f3138ef6e43e)
  unreachable
bb22:
  %t100 = load i32, ptr %l86, !tbaa !23
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/eval:Machine", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t104, i32 %t100)
  store i32 %t108, ptr %l110
  br label %bb23
bb23:
  %t109 = load i32, ptr %l110, !tbaa !23
  store i32 %t109, ptr %l11, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/eval:Machine", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t114 = load i32, ptr %l11, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t113, i32 %t114)
  store { i64, ptr } %t117, ptr %l114
  br label %bb24
bb24:
  %t118 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t118, ptr %l12, !tbaa !27
  %t119 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 13
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = ashr i64 %t120, 16
  %t124 = sub i64 %t122, 1
  store i64 %t124, ptr %l13, !tbaa !24
  %t126 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 13
  %t127 = load i64, ptr %t126, !tbaa !24
  %t129 = and i64 %t127, 65535
  store i64 %t129, ptr %l14, !tbaa !24
  %t131 = load i64, ptr %l13, !tbaa !24
  %t133 = icmp sge i64 %t131, 0
  br i1 %t133, label %bb25, label %bb26
bb25:
  %t135 = load i64, ptr %l13, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t141 = icmp slt i64 %t135, %t138
  store i1 %t141, ptr %l122, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb27
bb27:
  %t143 = load i1, ptr %l122, !tbaa !21
  br i1 %t143, label %bb28, label %bb29
bb28:
  %t144 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t144, ptr %l128, !tbaa !27
  %t145 = load i64, ptr %l13, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i32, ptr %t148, i64 %t145
  %t150 = load i32, ptr %t149, !tbaa !33
  store i32 %t150, ptr %l127, !tbaa !23
  br label %bb30
bb29:
  %t152 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  store i32 %t152, ptr %l127, !tbaa !23
  br label %bb30
bb30:
  %t154 = load i32, ptr %l127, !tbaa !23
  store i32 %t154, ptr %l15, !tbaa !23
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/mir:Task", ptr %l5
  %t157 = load i64, ptr %l6, !tbaa !24
  %t162 = call { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskLayout(ptr %v0, ptr %v0, ptr %s0, ptr %t155, ptr %l4, %"compiler/mir:Task" %t156, i64 %t157)
  store { { i64, ptr }, i64 } %t162, ptr %l136
  br label %bb31
bb31:
  %t163 = load { { i64, ptr }, i64 }, ptr %l136
  store { { i64, ptr }, i64 } %t163, ptr %l16
  %t164 = getelementptr { { i64, ptr }, i64 }, ptr %l16, i32 0, i32 1
  %t165 = load i64, ptr %t164, !tbaa !24
  store i64 %t165, ptr %l17, !tbaa !24
  store i32 0, ptr %l18, !tbaa !23
  %t167 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 4
  %t168 = getelementptr %"compiler/mir:Range", ptr %t167, i32 0, i32 1
  %t169 = load i32, ptr %t168, !tbaa !23
  store i32 %t169, ptr %l19, !tbaa !23
  store i32 1, ptr %l20, !tbaa !23
  %t171 = load i32, ptr %l19, !tbaa !23
  %t172 = load i32, ptr %l18, !tbaa !23
  %t175 = icmp sgt i32 %t171, %t172
  br i1 %t175, label %bb32, label %bb33
bb32:
  %t177 = load i32, ptr %l20, !tbaa !23
  %t179 = icmp sgt i32 %t177, 0
  br i1 %t179, label %bb34, label %bb35
bb33:
  store i32 0, ptr %l142, !tbaa !23
  br label %bb37
bb34:
  %t181 = load i32, ptr %l19, !tbaa !23
  %t182 = load i32, ptr %l18, !tbaa !23
  %t185 = sub i32 %t181, %t182
  %t186 = load i32, ptr %l20, !tbaa !23
  %t189 = add i32 %t185, %t186
  %t191 = sub i32 %t189, 1
  %t192 = load i32, ptr %l20, !tbaa !23
  %t195 = sdiv i32 %t191, %t192
  store i32 %t195, ptr %l145, !tbaa !23
  br label %bb36
bb35:
  store i32 0, ptr %l145, !tbaa !23
  br label %bb36
bb36:
  %t197 = load i32, ptr %l145, !tbaa !23
  store i32 %t197, ptr %l142, !tbaa !23
  br label %bb37
bb37:
  %t198 = load i32, ptr %l142, !tbaa !23
  store i32 %t198, ptr %l21, !tbaa !23
  store i32 0, ptr %l22, !tbaa !23
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t199 = load i32, ptr %l22, !tbaa !23
  %t200 = load i32, ptr %l21, !tbaa !23
  %t203 = icmp slt i32 %t199, %t200
  %t205 = xor i1 %t203, true
  br i1 %t205, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb126
bb40:
  br label %bb41
bb41:
  %t207 = load i32, ptr %l18, !tbaa !23
  %t208 = load i32, ptr %l22, !tbaa !23
  %t209 = load i32, ptr %l20, !tbaa !23
  %t212 = mul i32 %t208, %t209
  %t215 = add i32 %t207, %t212
  store i32 %t215, ptr %l23, !tbaa !23
  %t217 = getelementptr %"compiler/mir:Fn", ptr %l4, i32 0, i32 17
  %t218 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 4
  %t219 = getelementptr %"compiler/mir:Range", ptr %t218, i32 0, i32 0
  %t220 = load i32, ptr %t219, !tbaa !23
  %t222 = sext i32 %t220 to i64
  %t223 = load i32, ptr %l23, !tbaa !23
  %t225 = sext i32 %t223 to i64
  %t228 = add i64 %t222, %t225
  %t231 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %t217, i64 %t228)
  store %"compiler/mir:TaskClause" %t231, ptr %l169
  br label %bb42
bb42:
  %t232 = load %"compiler/mir:TaskClause", ptr %l169
  store %"compiler/mir:TaskClause" %t232, ptr %l24
  %t233 = getelementptr %"compiler/mir:TaskClause", ptr %l24, i32 0, i32 1
  %t234 = load i1, ptr %t233, !tbaa !21
  store i1 %t234, ptr %l25, !tbaa !21
  store i32 0, ptr %l26, !tbaa !23
  %t236 = getelementptr %"compiler/mir:TaskClause", ptr %l24, i32 0, i32 0
  %t237 = getelementptr %"compiler/mir:Range", ptr %t236, i32 0, i32 1
  %t238 = load i32, ptr %t237, !tbaa !23
  store i32 %t238, ptr %l27, !tbaa !23
  store i32 1, ptr %l28, !tbaa !23
  %t240 = load i32, ptr %l27, !tbaa !23
  %t241 = load i32, ptr %l26, !tbaa !23
  %t244 = icmp sgt i32 %t240, %t241
  br i1 %t244, label %bb43, label %bb44
bb43:
  %t246 = load i32, ptr %l28, !tbaa !23
  %t248 = icmp sgt i32 %t246, 0
  br i1 %t248, label %bb45, label %bb46
bb44:
  store i32 0, ptr %l175, !tbaa !23
  br label %bb48
bb45:
  %t250 = load i32, ptr %l27, !tbaa !23
  %t251 = load i32, ptr %l26, !tbaa !23
  %t254 = sub i32 %t250, %t251
  %t255 = load i32, ptr %l28, !tbaa !23
  %t258 = add i32 %t254, %t255
  %t260 = sub i32 %t258, 1
  %t261 = load i32, ptr %l28, !tbaa !23
  %t264 = sdiv i32 %t260, %t261
  store i32 %t264, ptr %l178, !tbaa !23
  br label %bb47
bb46:
  store i32 0, ptr %l178, !tbaa !23
  br label %bb47
bb47:
  %t266 = load i32, ptr %l178, !tbaa !23
  store i32 %t266, ptr %l175, !tbaa !23
  br label %bb48
bb48:
  %t267 = load i32, ptr %l175, !tbaa !23
  store i32 %t267, ptr %l29, !tbaa !23
  store i32 0, ptr %l30, !tbaa !23
  br label %bb49
bb49:
  %t268 = load i32, ptr %l30, !tbaa !23
  %t269 = load i32, ptr %l29, !tbaa !23
  %t272 = icmp slt i32 %t268, %t269
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb50, label %bb51
bb50:
  br label %bb65
bb51:
  br label %bb52
bb52:
  %t276 = load i32, ptr %l26, !tbaa !23
  %t277 = load i32, ptr %l30, !tbaa !23
  %t278 = load i32, ptr %l28, !tbaa !23
  %t281 = mul i32 %t277, %t278
  %t284 = add i32 %t276, %t281
  %t286 = getelementptr %"compiler/mir:Fn", ptr %l4, i32 0, i32 18
  %t287 = getelementptr %"compiler/mir:TaskClause", ptr %l24, i32 0, i32 0
  %t288 = getelementptr %"compiler/mir:Range", ptr %t287, i32 0, i32 0
  %t289 = load i32, ptr %t288, !tbaa !23
  %t291 = sext i32 %t289 to i64
  %t294 = sext i32 %t284 to i64
  %t297 = add i64 %t291, %t294
  %t300 = call %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %t286, i64 %t297)
  store %"compiler/typed:Item" %t300, ptr %l202
  br label %bb53
bb53:
  %t301 = load %"compiler/typed:Item", ptr %l202
  store %"compiler/typed:Item" %t301, ptr %l32
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/eval:Machine", ptr %t302, i32 0, i32 0
  %t305 = load ptr, ptr %t304, !tbaa !29
  %t306 = getelementptr %"compiler/typed:Item", ptr %l32, i32 0, i32 0
  %t307 = load i32, ptr %t306, !tbaa !23
  %t308 = load i32, ptr %l15, !tbaa !23
  %t312 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t305, i32 %t307, i32 %t308)
  store i1 %t312, ptr %l207
  br label %bb54
bb54:
  %t313 = load i1, ptr %l207, !tbaa !21
  br i1 %t313, label %bb55, label %bb56
bb55:
  %t314 = getelementptr %"compiler/typed:Item", ptr %l32, i32 0, i32 1
  %t315 = load i64, ptr %t314, !tbaa !24
  %t317 = icmp slt i64 %t315, 0
  br i1 %t317, label %bb57, label %bb58
bb56:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb60
bb57:
  store i1 true, ptr %l211, !tbaa !21
  br label %bb59
bb58:
  %t319 = getelementptr %"compiler/typed:Item", ptr %l32, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  %t321 = load i64, ptr %l14, !tbaa !24
  %t324 = icmp eq i64 %t320, %t321
  store i1 %t324, ptr %l211, !tbaa !21
  br label %bb59
bb59:
  %t326 = load i1, ptr %l211, !tbaa !21
  store i1 %t326, ptr %l208, !tbaa !21
  br label %bb60
bb60:
  %t327 = load i1, ptr %l208, !tbaa !21
  br i1 %t327, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t328 = load i32, ptr %l30, !tbaa !23
  %t330 = add i32 %t328, 1
  store i32 %t330, ptr %l30, !tbaa !23
  br label %bb49
bb65:
  %t332 = load i1, ptr %l25, !tbaa !21
  %t334 = xor i1 %t332, true
  br i1 %t334, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s5)
  br label %bb125
bb67:
  br label %bb68
bb68:
  %t336 = getelementptr %"compiler/mir:TaskClause", ptr %l24, i32 0, i32 2
  %t337 = load { i64, [4 x i64] }, ptr %t336
  %t339 = extractvalue { i64, [4 x i64] } %t337, 0
  %t340 = icmp eq i64 %t339, 0
  br i1 %t340, label %bb69, label %bb70
bb69:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreeTask(ptr %v0, ptr %t342, i64 %t343)
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb72:
  %t346 = getelementptr %"compiler/eval:task", ptr %l3, i32 0, i32 2
  %t347 = load i64, ptr %t346, !tbaa !24
  %t348 = load i64, ptr %l17, !tbaa !24
  %t349 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 3
  %t350 = getelementptr %"compiler/mir:Range", ptr %t349, i32 0, i32 1
  %t351 = load i32, ptr %t350, !tbaa !23
  %t353 = sext i32 %t351 to i64
  %t355 = mul i64 8, %t353
  %t358 = add i64 %t348, %t355
  %t359 = load i32, ptr %l23, !tbaa !23
  %t361 = mul i32 16, %t359
  %t363 = sext i32 %t361 to i64
  %t366 = add i64 %t358, %t363
  %t369 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t347, i64 %t366)
  store %"compiler/eval:Ptr" %t369, ptr %l233
  br label %bb73
bb73:
  %t370 = load %"compiler/eval:Ptr", ptr %l233
  store %"compiler/eval:Ptr" %t370, ptr %l33
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load %"compiler/eval:Ptr", ptr %l33
  %t375 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t371, %"compiler/eval:Ptr" %t372)
  store %"compiler/eval:Ptr" %t375, ptr %l236
  br label %bb74
bb74:
  %t376 = load %"compiler/eval:Ptr", ptr %l236
  store %"compiler/eval:Ptr" %t376, ptr %l34
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l237, !tbaa !29
  %t378 = getelementptr %"compiler/eval:Ptr", ptr %l33, i32 0, i32 0
  %t379 = load i64, ptr %t378, !tbaa !24
  %t380 = getelementptr %"compiler/eval:Ptr", ptr %l33, i32 0, i32 1
  %t381 = load i64, ptr %t380, !tbaa !24
  %t383 = add i64 %t381, 8
  %t386 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t379, i64 %t383)
  store %"compiler/eval:Ptr" %t386, ptr %l241
  br label %bb75
bb75:
  %t387 = load ptr, ptr %l237, !tbaa !29
  %t388 = load %"compiler/eval:Ptr", ptr %l241
  %t389 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t387, %"compiler/eval:Ptr" %t388)
  store %"compiler/eval:Ptr" %t389, ptr %l242
  br label %bb76
bb76:
  %t390 = load %"compiler/eval:Ptr", ptr %l242
  store %"compiler/eval:Ptr" %t390, ptr %l35
  %t391 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 0
  %t392 = load i64, ptr %t391, !tbaa !24
  %t394 = icmp eq i64 %t392, 0
  br i1 %t394, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l245, !tbaa !21
  br label %bb79
bb78:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/eval:Machine", ptr %t396, i32 0, i32 40
  %t399 = load { i64, ptr }, ptr %t398, !tbaa !27
  store { i64, ptr } %t399, ptr %l247, !tbaa !27
  %t400 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 0
  %t401 = load i64, ptr %t400, !tbaa !24
  %t402 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t405 = and i64 %t401, %t402
  %t407 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr %"compiler/eval:alloc", ptr %t408, i64 %t405
  %t410 = getelementptr %"compiler/eval:alloc", ptr %t409, i32 0, i32 4
  %t411 = load i64, ptr %t410, !tbaa !24
  %t412 = load i64, ptr @G_2ecompiler_2feval_2eaCode, !tbaa !24
  %t415 = icmp ne i64 %t411, %t412
  store i1 %t415, ptr %l245, !tbaa !21
  br label %bb79
bb79:
  %t417 = load i1, ptr %l245, !tbaa !21
  br i1 %t417, label %bb80, label %bb81
bb80:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNullCall, !tbaa !27
  %t420 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t420, ptr %t418, { i64, ptr } %t419)
  br label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb83:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/eval:Machine", ptr %t423, i32 0, i32 21
  store ptr %t425, ptr %l258, !tbaa !29
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/eval:Machine", ptr %t426, i32 0, i32 22
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/eval:Machine", ptr %t429, i32 0, i32 40
  %t432 = load { i64, ptr }, ptr %t431, !tbaa !27
  store { i64, ptr } %t432, ptr %l262, !tbaa !27
  %t433 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 0
  %t434 = load i64, ptr %t433, !tbaa !24
  %t435 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t438 = and i64 %t434, %t435
  %t440 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !27
  %t442 = getelementptr %"compiler/eval:alloc", ptr %t441, i64 %t438
  %t443 = getelementptr %"compiler/eval:alloc", ptr %t442, i32 0, i32 11
  %t444 = load i64, ptr %t443, !tbaa !24
  %t447 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t428, i64 %t444)
  store { i64, [2 x i64] } %t447, ptr %l267
  br label %bb84
bb84:
  %t448 = load ptr, ptr %l258, !tbaa !29
  %t449 = load { i64, [2 x i64] }, ptr %l267
  %t450 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t448, { i64, [2 x i64] } %t449)
  %t451 = extractvalue { i32, i64 } %t450, 1
  %t452 = extractvalue { i32, i64 } %t450, 0
  store i32 %t452, ptr %l269
  %t453 = icmp ne i32 %t452, 0
  br i1 %t453, label %bb86, label %ok.454, !prof !99
ok.454:
  store i64 %t451, ptr %l268
  br label %bb85
bb85:
  %t455 = load i64, ptr %l268, !tbaa !24
  store i64 %t455, ptr %l256, !tbaa !24
  br label %bb89
bb86:
  br label %bb87
bb87:
  call void @__olang_ert_req_clear()
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t458 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t458, ptr %t456, { i64, ptr } %t457)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb89:
  %t461 = load i64, ptr %l256, !tbaa !24
  store i64 %t461, ptr %l36, !tbaa !24
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load i64, ptr %l36, !tbaa !24
  %t464 = load i64, ptr @G_2ecompiler_2feval_2erClause, !tbaa !24
  %t465 = load i64, ptr %l2, !tbaa !24
  %t470 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %t462, i64 %t463, i64 %t464, i64 %t465)
  store i64 %t470, ptr %l276
  br label %bb90
bb90:
  %t471 = load i64, ptr %l276, !tbaa !24
  store i64 %t471, ptr %l37, !tbaa !24
  %t472 = load i64, ptr %l37, !tbaa !24
  %t474 = icmp slt i64 %t472, 0
  br i1 %t474, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb92:
  br label %bb93
bb93:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = getelementptr %"compiler/eval:Machine", ptr %t476, i32 0, i32 16
  %t479 = load i64, ptr %l36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t480, ptr %v0, ptr %v0, ptr %t478, i64 %t479)
  call void @llvm.memmove.p0.p0.i64(ptr %l282, ptr %t480, i64 248, i1 false)
  br label %bb94
bb94:
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %l282, i64 248, i1 false)
  store i64 0, ptr %l39, !tbaa !24
  %t483 = getelementptr %"compiler/mir:Fn", ptr %l38, i32 0, i32 6
  store ptr %t483, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb95
bb95:
  %t485 = load i64, ptr %l41, !tbaa !24
  store i64 %t485, ptr %l284, !tbaa !24
  %t486 = load ptr, ptr %l40, !tbaa !29
  %t488 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t486)
  store i64 %t488, ptr %l286
  br label %bb96
bb96:
  %t489 = load i64, ptr %l284, !tbaa !24
  %t490 = load i64, ptr %l286, !tbaa !24
  %t491 = icmp slt i64 %t489, %t490
  %t493 = xor i1 %t491, true
  br i1 %t493, label %bb97, label %bb98
bb97:
  br label %bb111
bb98:
  br label %bb99
bb99:
  %t495 = load ptr, ptr %l40, !tbaa !29
  %t496 = load i64, ptr %l41, !tbaa !24
  %t499 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t495, i64 %t496)
  store { i64, [1 x i64] } %t499, ptr %l291
  br label %bb100
bb100:
  %t500 = load { i64, [1 x i64] }, ptr %l291
  %t503 = extractvalue { i64, [1 x i64] } %t500, 0
  %t504 = icmp eq i64 %t503, 4
  br i1 %t504, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb109
bb104:
  br i1 true, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb108
bb107:
  %t506 = load i64, ptr %l39, !tbaa !24
  %t508 = add i64 %t506, 1
  store i64 %t508, ptr %l39, !tbaa !24
  br label %bb109
bb108:
  call void @__olang_check_failed(ptr @olang_loc_1763d3aa4dbf9a93_91ae1790a76dd73f)
  unreachable
bb109:
  br label %bb110
bb110:
  %t510 = load i64, ptr %l41, !tbaa !24
  %t512 = add i64 %t510, 1
  store i64 %t512, ptr %l41, !tbaa !24
  br label %bb95
bb111:
  store i64 0, ptr %l43, !tbaa !24
  %t514 = load i64, ptr %l39, !tbaa !24
  store i64 %t514, ptr %l44, !tbaa !24
  store i64 1, ptr %l45, !tbaa !24
  %t516 = load i64, ptr %l44, !tbaa !24
  %t517 = load i64, ptr %l43, !tbaa !24
  %t520 = icmp sgt i64 %t516, %t517
  br i1 %t520, label %bb112, label %bb113
bb112:
  %t522 = load i64, ptr %l45, !tbaa !24
  %t524 = icmp sgt i64 %t522, 0
  br i1 %t524, label %bb114, label %bb115
bb113:
  store i64 0, ptr %l302, !tbaa !24
  br label %bb117
bb114:
  %t526 = load i64, ptr %l44, !tbaa !24
  %t527 = load i64, ptr %l43, !tbaa !24
  %t530 = sub i64 %t526, %t527
  %t531 = load i64, ptr %l45, !tbaa !24
  %t534 = add i64 %t530, %t531
  %t536 = sub i64 %t534, 1
  %t537 = load i64, ptr %l45, !tbaa !24
  %t540 = sdiv i64 %t536, %t537
  store i64 %t540, ptr %l305, !tbaa !24
  br label %bb116
bb115:
  store i64 0, ptr %l305, !tbaa !24
  br label %bb116
bb116:
  %t542 = load i64, ptr %l305, !tbaa !24
  store i64 %t542, ptr %l302, !tbaa !24
  br label %bb117
bb117:
  %t543 = load i64, ptr %l302, !tbaa !24
  store i64 %t543, ptr %l46, !tbaa !24
  store i64 0, ptr %l47, !tbaa !24
  br label %bb118
bb118:
  %t544 = load i64, ptr %l47, !tbaa !24
  %t545 = load i64, ptr %l46, !tbaa !24
  %t548 = icmp slt i64 %t544, %t545
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb119, label %bb120
bb119:
  br label %bb123
bb120:
  br label %bb121
bb121:
  %t552 = load i64, ptr %l43, !tbaa !24
  %t553 = load i64, ptr %l47, !tbaa !24
  %t554 = load i64, ptr %l45, !tbaa !24
  %t557 = mul i64 %t553, %t554
  %t560 = add i64 %t552, %t557
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/eval:Machine", ptr %t562, i32 0, i32 51
  %t565 = load { i64, ptr }, ptr %t564, !tbaa !27
  store { i64, ptr } %t565, ptr %l324, !tbaa !27
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = getelementptr %"compiler/eval:Machine", ptr %t566, i32 0, i32 49
  %t569 = load { i64, ptr }, ptr %t568, !tbaa !27
  store { i64, ptr } %t569, ptr %l326, !tbaa !27
  %t570 = load i64, ptr %l37, !tbaa !24
  %t572 = getelementptr { i64, ptr }, ptr %l326, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = getelementptr %"compiler/eval:frame", ptr %t573, i64 %t570
  %t575 = getelementptr %"compiler/eval:frame", ptr %t574, i32 0, i32 5
  %t576 = load i64, ptr %t575, !tbaa !24
  %t580 = add i64 %t576, %t560
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = getelementptr %"compiler/eval:Machine", ptr %t581, i32 0, i32 61
  %t584 = load i64, ptr %t583, !tbaa !24
  %t587 = getelementptr { i64, ptr }, ptr %l324, i32 0, i32 1
  %t588 = load ptr, ptr %t587, !tbaa !27
  %t589 = getelementptr i64, ptr %t588, i64 %t580
  store i64 %t584, ptr %t589, !tbaa !34
  br label %bb122
bb122:
  %t590 = load i64, ptr %l47, !tbaa !24
  %t592 = add i64 %t590, 1
  store i64 %t592, ptr %l47, !tbaa !24
  br label %bb118
bb123:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load i64, ptr %l37, !tbaa !24
  %t596 = load %"compiler/eval:Ptr", ptr %l35
  %t597 = load i64, ptr %l39, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloadCaptures(ptr %v0, ptr %v0, ptr %t594, i64 %t595, ptr %l38, %"compiler/eval:Ptr" %t596, i64 %t597)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb125:
  %t603 = load i32, ptr %l22, !tbaa !23
  %t605 = add i32 %t603, 1
  store i32 %t605, ptr %l22, !tbaa !23
  br label %bb38
bb126:
  %t607 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 5
  %t608 = getelementptr %"compiler/mir:Range", ptr %t607, i32 0, i32 1
  %t609 = load i32, ptr %t608, !tbaa !23
  %t611 = icmp sgt i32 %t609, 0
  br i1 %t611, label %bb127, label %bb128
bb127:
  store { i64, [4 x i64] } zeroinitializer, ptr %t613
  %t614 = getelementptr { i64, [4 x i64] }, ptr %t613, i32 0, i32 0
  store i64 0, ptr %t614
  %t615 = load { i64, [4 x i64] }, ptr %t613
  store { i64, [4 x i64] } %t615, ptr %l49
  store i64 0, ptr %l50, !tbaa !24
  %t617 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 5
  %t618 = getelementptr %"compiler/mir:Range", ptr %t617, i32 0, i32 1
  %t619 = load i32, ptr %t618, !tbaa !23
  %t621 = sext i32 %t619 to i64
  store i64 %t621, ptr %l51, !tbaa !24
  store i64 2, ptr %l52, !tbaa !24
  %t623 = load i64, ptr %l51, !tbaa !24
  %t624 = load i64, ptr %l50, !tbaa !24
  %t627 = icmp sgt i64 %t623, %t624
  br i1 %t627, label %bb129, label %bb130
bb128:
  br label %bb159
bb129:
  %t629 = load i64, ptr %l52, !tbaa !24
  %t631 = icmp sgt i64 %t629, 0
  br i1 %t631, label %bb131, label %bb132
bb130:
  store i64 0, ptr %l350, !tbaa !24
  br label %bb134
bb131:
  %t633 = load i64, ptr %l51, !tbaa !24
  %t634 = load i64, ptr %l50, !tbaa !24
  %t637 = sub i64 %t633, %t634
  %t638 = load i64, ptr %l52, !tbaa !24
  %t641 = add i64 %t637, %t638
  %t643 = sub i64 %t641, 1
  %t644 = load i64, ptr %l52, !tbaa !24
  %t647 = sdiv i64 %t643, %t644
  store i64 %t647, ptr %l353, !tbaa !24
  br label %bb133
bb132:
  store i64 0, ptr %l353, !tbaa !24
  br label %bb133
bb133:
  %t649 = load i64, ptr %l353, !tbaa !24
  store i64 %t649, ptr %l350, !tbaa !24
  br label %bb134
bb134:
  %t650 = load i64, ptr %l350, !tbaa !24
  store i64 %t650, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  br label %bb135
bb135:
  %t651 = load i64, ptr %l54, !tbaa !24
  %t652 = load i64, ptr %l53, !tbaa !24
  %t655 = icmp slt i64 %t651, %t652
  %t657 = xor i1 %t655, true
  br i1 %t657, label %bb136, label %bb137
bb136:
  br label %bb153
bb137:
  br label %bb138
bb138:
  %t659 = load i64, ptr %l50, !tbaa !24
  %t660 = load i64, ptr %l54, !tbaa !24
  %t661 = load i64, ptr %l52, !tbaa !24
  %t664 = mul i64 %t660, %t661
  %t667 = add i64 %t659, %t664
  store i64 %t667, ptr %l55, !tbaa !24
  %t669 = getelementptr %"compiler/mir:Fn", ptr %l4, i32 0, i32 11
  %t670 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 5
  %t671 = getelementptr %"compiler/mir:Range", ptr %t670, i32 0, i32 0
  %t672 = load i32, ptr %t671, !tbaa !23
  %t674 = sext i32 %t672 to i64
  %t675 = load i64, ptr %l55, !tbaa !24
  %t678 = add i64 %t674, %t675
  %t681 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t669, i64 %t678)
  store { i64, [4 x i64] } %t681, ptr %l376
  br label %bb139
bb139:
  %t682 = load { i64, [4 x i64] }, ptr %l376
  store { i64, [4 x i64] } %t682, ptr %l56
  %t683 = load { i64, [4 x i64] }, ptr %l56
  %t685 = extractvalue { i64, [4 x i64] } %t683, 0
  %t686 = icmp eq i64 %t685, 2
  br i1 %t686, label %bb140, label %bb141
bb140:
  %t688 = getelementptr { i64, [4 x i64] }, ptr %l56, i32 0, i32 1
  %t689 = getelementptr { i32, i64 }, ptr %t688, i32 0, i32 1
  %t690 = load i64, ptr %t689
  store i64 %t690, ptr %l57, !tbaa !24
  br label %bb142
bb141:
  br label %bb146
bb142:
  %t692 = load i64, ptr %l57, !tbaa !24
  %t693 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 13
  %t694 = load i64, ptr %t693, !tbaa !24
  %t697 = icmp eq i64 %t692, %t694
  br i1 %t697, label %bb143, label %bb144
bb143:
  %t699 = getelementptr %"compiler/mir:Fn", ptr %l4, i32 0, i32 11
  %t700 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 5
  %t701 = getelementptr %"compiler/mir:Range", ptr %t700, i32 0, i32 0
  %t702 = load i32, ptr %t701, !tbaa !23
  %t704 = sext i32 %t702 to i64
  %t705 = load i64, ptr %l55, !tbaa !24
  %t708 = add i64 %t704, %t705
  %t710 = add i64 %t708, 1
  %t713 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t699, i64 %t710)
  store { i64, [4 x i64] } %t713, ptr %l389
  br label %bb145
bb144:
  br label %bb146
bb145:
  %t714 = load { i64, [4 x i64] }, ptr %l389
  store { i64, [4 x i64] } %t714, ptr %l49
  br label %bb151
bb146:
  br i1 true, label %bb147, label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb150
bb149:
  br label %bb151
bb150:
  call void @__olang_check_failed(ptr @olang_loc_2ee13faba4731678_f9595c1938ce6204)
  unreachable
bb151:
  br label %bb152
bb152:
  %t715 = load i64, ptr %l54, !tbaa !24
  %t717 = add i64 %t715, 1
  store i64 %t717, ptr %l54, !tbaa !24
  br label %bb135
bb153:
  %t719 = load { i64, [4 x i64] }, ptr %l49
  %t721 = extractvalue { i64, [4 x i64] } %t719, 0
  %t722 = icmp eq i64 %t721, 0
  br i1 %t722, label %bb154, label %bb155
bb154:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = getelementptr %"compiler/mir:Fn", ptr %l4, i32 0, i32 2
  %t726 = load i64, ptr %t725, !tbaa !24
  %t727 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 6
  %t728 = load %"compiler/source:Span", ptr %t727
  store { i64, [5 x i64] } zeroinitializer, ptr %t729
  %t730 = getelementptr { i64, [5 x i64] }, ptr %t729, i32 0, i32 0
  store i64 2, ptr %t730
  %t732 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } undef, i32 13, 0
  %t734 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t732, i64 %t726, 1
  %t736 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t734, %"compiler/source:Span" %t728, 2
  %t737 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t736, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d17, i32 0, i32 1) }, 3
  %t738 = getelementptr { i64, [5 x i64] }, ptr %t729, i32 0, i32 1
  store { i32, i64, %"compiler/source:Span", { i64, ptr } } %t737, ptr %t738
  %t739 = load { i64, [5 x i64] }, ptr %t729
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estop(ptr %v0, ptr %v0, ptr %t724, { i64, [5 x i64] } %t739)
  br label %bb156
bb155:
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t743 = load i64, ptr %l6, !tbaa !24
  %t744 = getelementptr %"compiler/mir:Fn", ptr %l4, i32 0, i32 2
  %t745 = load i64, ptr %t744, !tbaa !24
  %t746 = getelementptr %"compiler/mir:Task", ptr %l5, i32 0, i32 6
  %t747 = load %"compiler/source:Span", ptr %t746
  %t748 = load { i64, [4 x i64] }, ptr %l49
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eexit(ptr %v0, ptr %t742, i64 %t743, i64 %t745, %"compiler/source:Span" %t747, i32 13, { i64, [4 x i64] } %t748)
  br label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb159:
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t756 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %t757, ptr %v0, ptr %v0, ptr %t755, i64 %t756)
  call void @llvm.memmove.p0.p0.i64(ptr %l407, ptr %t757, i64 248, i1 false)
  br label %bb160
bb160:
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %l407, i64 248, i1 false)
  %t760 = getelementptr %"compiler/mir:Fn", ptr %l58, i32 0, i32 9
  %t761 = load ptr, ptr %l0, !tbaa !29
  %t763 = getelementptr %"compiler/eval:Machine", ptr %t761, i32 0, i32 49
  %t764 = load { i64, ptr }, ptr %t763, !tbaa !27
  store { i64, ptr } %t764, ptr %l410, !tbaa !27
  %t765 = load i64, ptr %l6, !tbaa !24
  %t767 = getelementptr { i64, ptr }, ptr %l410, i32 0, i32 1
  %t768 = load ptr, ptr %t767, !tbaa !27
  %t769 = getelementptr %"compiler/eval:frame", ptr %t768, i64 %t765
  %t770 = getelementptr %"compiler/eval:frame", ptr %t769, i32 0, i32 1
  %t771 = load i64, ptr %t770, !tbaa !24
  %t774 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t760, i64 %t771)
  store %"compiler/mir:BasicBlock" %t774, ptr %l413
  br label %bb161
bb161:
  %t775 = getelementptr %"compiler/mir:BasicBlock", ptr %l413, i32 0, i32 1
  %t776 = load { i64, [8 x i64] }, ptr %t775
  store { i64, [8 x i64] } %t776, ptr %l59
  %t778 = load { i64, [8 x i64] }, ptr %l59
  %t780 = extractvalue { i64, [8 x i64] } %t778, 0
  %t781 = icmp eq i64 %t780, 8
  br i1 %t781, label %bb162, label %bb163
bb162:
  %t783 = getelementptr { i64, [8 x i64] }, ptr %l59, i32 0, i32 1
  %t784 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t783, i32 0, i32 1
  %t785 = load i32, ptr %t784
  store i32 %t785, ptr %l60, !tbaa !23
  br label %bb164
bb163:
  br label %bb173
bb164:
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t789 = getelementptr %"compiler/eval:Machine", ptr %t787, i32 0, i32 51
  %t790 = load { i64, ptr }, ptr %t789, !tbaa !27
  store { i64, ptr } %t790, ptr %l419, !tbaa !27
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t793 = getelementptr %"compiler/eval:Machine", ptr %t791, i32 0, i32 49
  %t794 = load { i64, ptr }, ptr %t793, !tbaa !27
  store { i64, ptr } %t794, ptr %l421, !tbaa !27
  %t795 = load i64, ptr %l6, !tbaa !24
  %t797 = getelementptr { i64, ptr }, ptr %l421, i32 0, i32 1
  %t798 = load ptr, ptr %t797, !tbaa !27
  %t799 = getelementptr %"compiler/eval:frame", ptr %t798, i64 %t795
  %t800 = getelementptr %"compiler/eval:frame", ptr %t799, i32 0, i32 4
  %t801 = load i64, ptr %t800, !tbaa !24
  %t802 = load i32, ptr %l60, !tbaa !23
  %t804 = sext i32 %t802 to i64
  %t807 = add i64 %t801, %t804
  %t809 = getelementptr { i64, ptr }, ptr %l419, i32 0, i32 1
  %t810 = load ptr, ptr %t809, !tbaa !27
  %t811 = getelementptr i64, ptr %t810, i64 %t807
  %t812 = load i64, ptr %t811, !tbaa !34
  %t815 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t818 = and i64 %t812, %t815
  store i64 %t818, ptr %l62, !tbaa !24
  %t820 = load ptr, ptr %l0, !tbaa !29
  %t822 = getelementptr %"compiler/eval:Machine", ptr %t820, i32 0, i32 43
  %t823 = load i64, ptr %l62, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t824, ptr %v0, ptr %t822, i64 %t823)
  call void @llvm.memmove.p0.p0.i64(ptr %l434, ptr %t824, i64 136, i1 false)
  br label %bb165
bb165:
  %t827 = getelementptr %"compiler/eval:scope", ptr %l434, i32 0, i32 12
  %t828 = load i64, ptr %t827, !tbaa !24
  %t830 = icmp eq i64 %t828, 0
  br i1 %t830, label %bb166, label %bb167
bb166:
  %t832 = load i64, ptr %l62, !tbaa !24
  store i64 %t832, ptr %l63, !tbaa !24
  %t834 = load ptr, ptr %l0, !tbaa !29
  store ptr %t834, ptr %l438, !tbaa !29
  %t835 = getelementptr %"compiler/eval:frame", ptr %l1, i32 0, i32 13
  %t836 = load i64, ptr %t835, !tbaa !24
  store i64 %t836, ptr %l439, !tbaa !24
  %t837 = load i32, ptr %l11, !tbaa !23
  store i32 %t837, ptr %l440, !tbaa !23
  %t838 = load ptr, ptr %l0, !tbaa !29
  %t840 = getelementptr %"compiler/eval:Machine", ptr %t838, i32 0, i32 43
  %t841 = load i64, ptr %l62, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t842, ptr %v0, ptr %t840, i64 %t841)
  call void @llvm.memmove.p0.p0.i64(ptr %l444, ptr %t842, i64 136, i1 false)
  br label %bb168
bb167:
  br label %bb172
bb168:
  %t845 = getelementptr %"compiler/eval:scope", ptr %l444, i32 0, i32 13
  %t846 = load i64, ptr %t845, !tbaa !24
  %t848 = trunc i64 %t846 to i32
  %t850 = load ptr, ptr %l438, !tbaa !29
  %t851 = load i64, ptr %l439, !tbaa !24
  %t852 = load i32, ptr %l440, !tbaa !23
  %t854 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erecode(ptr %v0, ptr %t850, i64 %t851, i32 %t852, i32 %t848)
  store i64 %t854, ptr %l448
  br label %bb169
bb169:
  %t855 = load i64, ptr %l448, !tbaa !24
  store i64 %t855, ptr %l64, !tbaa !24
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t858 = getelementptr %"compiler/eval:Machine", ptr %t856, i32 0, i32 43
  %t859 = load i64, ptr %l63, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t860, ptr %v0, ptr %t858, i64 %t859)
  call void @llvm.memmove.p0.p0.i64(ptr %l452, ptr %t860, i64 136, i1 false)
  br label %bb170
bb170:
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %l452, i64 136, i1 false)
  %t863 = load i64, ptr %l64, !tbaa !24
  %t865 = getelementptr %"compiler/eval:scope", ptr %l65, i32 0, i32 12
  store i64 %t863, ptr %t865, !tbaa !24
  %t866 = load ptr, ptr %l0, !tbaa !29
  %t868 = getelementptr %"compiler/eval:Machine", ptr %t866, i32 0, i32 43
  %t869 = load i64, ptr %l63, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l457, ptr %l65, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t872, ptr %l457, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t868, i64 %t869, ptr %t872)
  br label %bb171
bb171:
  br label %bb172
bb172:
  br label %bb179
bb173:
  br i1 true, label %bb174, label %bb175
bb174:
  br label %bb176
bb175:
  br label %bb178
bb176:
  %t873 = load ptr, ptr %l0, !tbaa !29
  %t874 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoClause, !tbaa !27
  %t875 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t875, ptr %t873, { i64, ptr } %t874)
  br label %bb177
bb177:
  br label %bb179
bb178:
  call void @__olang_check_failed(ptr @olang_loc_295f7f77f101c149_2aa6184739b6cdf5)
  unreachable
bb179:
  %t878 = load ptr, ptr %l0, !tbaa !29
  %t879 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreeTask(ptr %v0, ptr %t878, i64 %t879)
  br label %bb180
bb180:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eterm(ptr %v0, ptr %a0, i64 %a1, { i64, [8 x i64] } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [8 x i64] }
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Range"
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, i64 }
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca { i64, i64 }
  %l27 = alloca i64
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca i32
  %l30 = alloca %"compiler/mir:Call"
  %l31 = alloca { i64, [7 x i64] }
  %l32 = alloca i64
  %l33 = alloca i32
  %l34 = alloca { i64, %"compiler/eval:Ptr", i1, i64 }
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca { i64, [4 x i64] }
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca i32
  %l41 = alloca %"compiler/mir:Call"
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, [4 x i64] }
  %l44 = alloca i32
  %l45 = alloca %"compiler/mir:Range"
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca { i64, [4 x i64] }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca %"compiler/eval:genRec"
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i32
  %l56 = alloca i32
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca i32
  %l59 = alloca { i64, [4 x i64] }
  %l61 = alloca { i64, ptr }
  %l67 = alloca i64
  %l80 = alloca i1
  %l84 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i64
  %l91 = alloca i64
  %l93 = alloca i32
  %l102 = alloca i1
  %l106 = alloca i1
  %l111 = alloca i64
  %l116 = alloca i32
  %l119 = alloca i64
  %l122 = alloca i1
  %l125 = alloca i64
  %l128 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca ptr
  %l136 = alloca i64
  %l137 = alloca i64
  %l140 = alloca i64
  %l146 = alloca { i64, i64 }
  %l152 = alloca i32
  %l155 = alloca i32
  %l174 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l185 = alloca i64
  %l191 = alloca { i64, i64 }
  %l197 = alloca i1
  %l202 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l249 = alloca i1
  %l250 = alloca ptr
  %l251 = alloca i64
  %l255 = alloca %"compiler/mir:Fn"
  %l258 = alloca i1
  %l275 = alloca { i64, %"compiler/eval:Ptr", i1, i64 }
  %l281 = alloca ptr
  %l282 = alloca i64
  %l283 = alloca %"compiler/mir:Call"
  %l284 = alloca i64
  %l288 = alloca i32
  %l297 = alloca i64
  %l306 = alloca i64
  %l315 = alloca { i64, ptr }
  %l319 = alloca i1
  %l321 = alloca i1
  %l325 = alloca i1
  %l338 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l345 = alloca i1
  %l346 = alloca ptr
  %l347 = alloca i64
  %l351 = alloca %"compiler/mir:Fn"
  %l354 = alloca i1
  %l369 = alloca i1
  %l373 = alloca i1
  %l388 = alloca { i64, ptr }
  %l392 = alloca i1
  %l394 = alloca { i64, ptr }
  %l399 = alloca { i64, ptr }
  %l406 = alloca %"compiler/eval:genRec"
  %l411 = alloca %"compiler/eval:genRec"
  %l413 = alloca { i64, ptr }
  %l422 = alloca { i64, ptr }
  %l425 = alloca i64
  %l427 = alloca { i64, ptr }
  %l430 = alloca ptr
  %l434 = alloca i64
  %l436 = alloca i64
  %l468 = alloca { i64, ptr }
  %s16 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %t438 = alloca %"compiler/mir:Fn", align 8
  %t663 = alloca %"compiler/mir:Fn", align 8
  %t800 = alloca %"compiler/eval:genRec", align 8
  %t812 = alloca %"compiler/eval:genRec", align 8
  %t876 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [8 x i64] } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 49
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l61, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:frame", ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t13 = load { i64, [8 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [8 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l67
  br label %bb4
bb4:
  br label %bb207
bb5:
  %t21 = load { i64, [8 x i64] }, ptr %l2
  %t23 = extractvalue { i64, [8 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t27 = getelementptr { i32 }, ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  %t32 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %t30, i64 %t31, i32 %t32)
  br label %bb9
bb9:
  br label %bb207
bb10:
  %t36 = load { i64, [8 x i64] }, ptr %l2
  %t38 = extractvalue { i64, [8 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 2
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t41 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t42 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t41, i32 0, i32 0
  %t43 = load { i64, [4 x i64] }, ptr %t42
  store { i64, [4 x i64] } %t43, ptr %l6
  %t45 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t46 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t45, i32 0, i32 1
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l7, !tbaa !23
  %t49 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t50 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t49, i32 0, i32 2
  %t51 = load i32, ptr %t50
  store i32 %t51, ptr %l8, !tbaa !23
  br label %bb13
bb12:
  br label %bb26
bb13:
  %t53 = load i1, ptr %l3, !tbaa !21
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load { i64, [4 x i64] }, ptr %l6
  %t61 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t55, i64 %t56, { i64, [4 x i64] } %t57)
  store i1 %t61, ptr %l84
  br label %bb16
bb15:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb17
bb16:
  %t62 = load i1, ptr %l84, !tbaa !21
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l80, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l80, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  br label %ret
bb19:
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l86, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  store i64 %t67, ptr %l87, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  %t70 = load { i64, [4 x i64] }, ptr %l6
  %t74 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t68, i64 %t69, { i64, [4 x i64] } %t70)
  store i64 %t74, ptr %l91
  br label %bb21
bb21:
  %t75 = load i64, ptr %l91, !tbaa !24
  %t76 = icmp ne i64 %t75, 0
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t78 = load i32, ptr %l7, !tbaa !23
  store i32 %t78, ptr %l93, !tbaa !23
  br label %bb24
bb23:
  %t80 = load i32, ptr %l8, !tbaa !23
  store i32 %t80, ptr %l93, !tbaa !23
  br label %bb24
bb24:
  %t82 = load ptr, ptr %l86, !tbaa !29
  %t83 = load i64, ptr %l87, !tbaa !24
  %t84 = load i32, ptr %l93, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %t82, i64 %t83, i32 %t84)
  br label %bb25
bb25:
  br label %bb207
bb26:
  %t85 = load { i64, [8 x i64] }, ptr %l2
  %t87 = extractvalue { i64, [8 x i64] } %t85, 0
  %t88 = icmp eq i64 %t87, 3
  br i1 %t88, label %bb27, label %bb28
bb27:
  %t90 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t91 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t90, i32 0, i32 0
  %t92 = load { i64, [4 x i64] }, ptr %t91
  store { i64, [4 x i64] } %t92, ptr %l9
  %t94 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t95 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t94, i32 0, i32 1
  %t96 = load %"compiler/mir:Range", ptr %t95
  store %"compiler/mir:Range" %t96, ptr %l10
  %t98 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t99 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t98, i32 0, i32 2
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l11, !tbaa !23
  br label %bb29
bb28:
  br label %bb86
bb29:
  %t102 = load i1, ptr %l3, !tbaa !21
  br i1 %t102, label %bb30, label %bb31
bb30:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i64, ptr %l1, !tbaa !24
  %t106 = load { i64, [4 x i64] }, ptr %l9
  %t110 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t104, i64 %t105, { i64, [4 x i64] } %t106)
  store i1 %t110, ptr %l106
  br label %bb32
bb31:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb33
bb32:
  %t111 = load i1, ptr %l106, !tbaa !21
  %t112 = xor i1 %t111, true
  store i1 %t112, ptr %l102, !tbaa !21
  br label %bb33
bb33:
  %t114 = load i1, ptr %l102, !tbaa !21
  br i1 %t114, label %bb34, label %bb35
bb34:
  br label %ret
bb35:
  br label %bb36
bb36:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i64, ptr %l1, !tbaa !24
  %t117 = load { i64, [4 x i64] }, ptr %l9
  %t121 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t115, i64 %t116, { i64, [4 x i64] } %t117)
  store i64 %t121, ptr %l111
  br label %bb37
bb37:
  %t122 = load i64, ptr %l111, !tbaa !24
  store i64 %t122, ptr %l12, !tbaa !24
  %t123 = load i32, ptr %l11, !tbaa !23
  store i32 %t123, ptr %l13, !tbaa !23
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i64, ptr %l1, !tbaa !24
  %t127 = load { i64, [4 x i64] }, ptr %l9
  %t131 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t125, i64 %t126, { i64, [4 x i64] } %t127)
  store i32 %t131, ptr %l116
  br label %bb38
bb38:
  %t132 = load i32, ptr %l116, !tbaa !23
  store i32 %t132, ptr %l14, !tbaa !23
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l14, !tbaa !23
  %t137 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t133, i32 %t134)
  store i64 %t137, ptr %l119
  br label %bb39
bb39:
  %t138 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t139 = load i64, ptr %l119, !tbaa !24
  %t141 = icmp eq i64 %t139, %t138
  br i1 %t141, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb43
bb41:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l14, !tbaa !23
  %t147 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t143, i32 %t144)
  store i64 %t147, ptr %l125
  br label %bb42
bb42:
  %t148 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t149 = load i64, ptr %l125, !tbaa !24
  %t151 = icmp eq i64 %t149, %t148
  store i1 %t151, ptr %l122, !tbaa !21
  br label %bb43
bb43:
  %t153 = load i1, ptr %l122, !tbaa !21
  br i1 %t153, label %bb44, label %bb45
bb44:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i32, ptr %l14, !tbaa !23
  %t158 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t154, i32 %t155)
  store i64 %t158, ptr %l131
  br label %bb46
bb45:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l133, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l14, !tbaa !23
  %t164 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t160, i32 %t161)
  store i64 %t164, ptr %l136
  br label %bb48
bb46:
  %t165 = load i64, ptr %l131, !tbaa !24
  %t166 = call i64 @compiler_2feval_2ebmask(i64 %t165)
  store i64 %t166, ptr %l132
  br label %bb47
bb47:
  %t167 = load i64, ptr %l132, !tbaa !24
  store i64 %t167, ptr %l128, !tbaa !24
  br label %bb50
bb48:
  %t168 = load ptr, ptr %l133, !tbaa !29
  %t169 = load i64, ptr %l136, !tbaa !24
  %t170 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t168, i64 %t169)
  store i64 %t170, ptr %l137
  br label %bb49
bb49:
  %t171 = load i64, ptr %l137, !tbaa !24
  store i64 %t171, ptr %l128, !tbaa !24
  br label %bb50
bb50:
  %t172 = load i64, ptr %l128, !tbaa !24
  store i64 %t172, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l14, !tbaa !23
  %t177 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t173, i32 %t174)
  store i64 %t177, ptr %l140
  br label %bb51
bb51:
  %t178 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t179 = load i64, ptr %l140, !tbaa !24
  %t181 = icmp eq i64 %t179, %t178
  br i1 %t181, label %bb52, label %bb53
bb52:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i64, ptr %l1, !tbaa !24
  %t185 = load { i64, [4 x i64] }, ptr %l9
  %t189 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t183, i64 %t184, { i64, [4 x i64] } %t185)
  store { i64, i64 } %t189, ptr %l146
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t190 = load { i64, i64 }, ptr %l146
  store { i64, i64 } %t190, ptr %l17
  %t191 = getelementptr { i64, i64 }, ptr %l17, i32 0, i32 1
  %t192 = load i64, ptr %t191, !tbaa !24
  store i64 %t192, ptr %l16, !tbaa !24
  br label %bb55
bb55:
  store i32 0, ptr %l18, !tbaa !23
  %t194 = getelementptr %"compiler/mir:Range", ptr %l10, i32 0, i32 1
  %t195 = load i32, ptr %t194, !tbaa !23
  store i32 %t195, ptr %l19, !tbaa !23
  store i32 1, ptr %l20, !tbaa !23
  %t197 = load i32, ptr %l19, !tbaa !23
  %t198 = load i32, ptr %l18, !tbaa !23
  %t201 = icmp sgt i32 %t197, %t198
  br i1 %t201, label %bb56, label %bb57
bb56:
  %t203 = load i32, ptr %l20, !tbaa !23
  %t205 = icmp sgt i32 %t203, 0
  br i1 %t205, label %bb58, label %bb59
bb57:
  store i32 0, ptr %l152, !tbaa !23
  br label %bb61
bb58:
  %t207 = load i32, ptr %l19, !tbaa !23
  %t208 = load i32, ptr %l18, !tbaa !23
  %t211 = sub i32 %t207, %t208
  %t212 = load i32, ptr %l20, !tbaa !23
  %t215 = add i32 %t211, %t212
  %t217 = sub i32 %t215, 1
  %t218 = load i32, ptr %l20, !tbaa !23
  %t221 = sdiv i32 %t217, %t218
  store i32 %t221, ptr %l155, !tbaa !23
  br label %bb60
bb59:
  store i32 0, ptr %l155, !tbaa !23
  br label %bb60
bb60:
  %t223 = load i32, ptr %l155, !tbaa !23
  store i32 %t223, ptr %l152, !tbaa !23
  br label %bb61
bb61:
  %t224 = load i32, ptr %l152, !tbaa !23
  store i32 %t224, ptr %l21, !tbaa !23
  store i32 0, ptr %l22, !tbaa !23
  br label %bb62
bb62:
  %t225 = load i32, ptr %l22, !tbaa !23
  %t226 = load i32, ptr %l21, !tbaa !23
  %t229 = icmp slt i32 %t225, %t226
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb63, label %bb64
bb63:
  br label %bb81
bb64:
  br label %bb65
bb65:
  %t233 = load i32, ptr %l18, !tbaa !23
  %t234 = load i32, ptr %l22, !tbaa !23
  %t235 = load i32, ptr %l20, !tbaa !23
  %t238 = mul i32 %t234, %t235
  %t241 = add i32 %t233, %t238
  store i32 %t241, ptr %l23, !tbaa !23
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/eval:Machine", ptr %t243, i32 0, i32 17
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  store { i64, ptr } %t246, ptr %l174, !tbaa !27
  %t247 = load i64, ptr %l4, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr %"compiler/eval:cfn", ptr %t250, i64 %t247
  %t252 = getelementptr %"compiler/eval:cfn", ptr %t251, i32 0, i32 6
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  store { i64, ptr } %t253, ptr %l176, !tbaa !27
  %t254 = getelementptr %"compiler/mir:Range", ptr %l10, i32 0, i32 0
  %t255 = load i32, ptr %t254, !tbaa !23
  %t257 = sext i32 %t255 to i64
  %t258 = load i32, ptr %l23, !tbaa !23
  %t260 = sext i32 %t258 to i64
  %t263 = add i64 %t257, %t260
  %t265 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr %"compiler/mir:Case", ptr %t266, i64 %t263
  %t268 = getelementptr %"compiler/mir:Case", ptr %t267, i32 0, i32 0
  %t269 = load i64, ptr %t268, !tbaa !24
  store i64 %t269, ptr %l24, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load i32, ptr %l14, !tbaa !23
  %t275 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t271, i32 %t272)
  store i64 %t275, ptr %l185
  br label %bb66
bb66:
  %t276 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t277 = load i64, ptr %l185, !tbaa !24
  %t279 = icmp eq i64 %t277, %t276
  br i1 %t279, label %bb67, label %bb68
bb67:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load i32, ptr %l14, !tbaa !23
  %t283 = load i64, ptr %l24, !tbaa !24
  %t287 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideConst(ptr %v0, ptr %t281, i32 %t282, i64 %t283)
  store { i64, i64 } %t287, ptr %l191
  br label %bb69
bb68:
  %t288 = load i64, ptr %l24, !tbaa !24
  %t289 = load i64, ptr %l15, !tbaa !24
  %t292 = and i64 %t288, %t289
  %t293 = load i64, ptr %l12, !tbaa !24
  %t296 = icmp eq i64 %t292, %t293
  br i1 %t296, label %bb76, label %bb77
bb69:
  %t298 = load { i64, i64 }, ptr %l191
  store { i64, i64 } %t298, ptr %l25
  %t299 = getelementptr { i64, i64 }, ptr %l25, i32 0, i32 0
  %t300 = load i64, ptr %t299, !tbaa !24
  %t302 = getelementptr { i64, i64 }, ptr %l25, i32 0, i32 1
  %t303 = load i64, ptr %t302, !tbaa !24
  store i64 %t303, ptr %l27, !tbaa !24
  %t306 = load i64, ptr %l12, !tbaa !24
  %t309 = icmp eq i64 %t300, %t306
  br i1 %t309, label %bb70, label %bb71
bb70:
  %t311 = load i64, ptr %l27, !tbaa !24
  %t312 = load i64, ptr %l16, !tbaa !24
  %t315 = icmp eq i64 %t311, %t312
  store i1 %t315, ptr %l197, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb72
bb72:
  %t317 = load i1, ptr %l197, !tbaa !21
  br i1 %t317, label %bb73, label %bb74
bb73:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/eval:Machine", ptr %t318, i32 0, i32 17
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !27
  store { i64, ptr } %t321, ptr %l202, !tbaa !27
  %t322 = load i64, ptr %l4, !tbaa !24
  %t324 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr %"compiler/eval:cfn", ptr %t325, i64 %t322
  %t327 = getelementptr %"compiler/eval:cfn", ptr %t326, i32 0, i32 6
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  store { i64, ptr } %t328, ptr %l204, !tbaa !27
  %t329 = getelementptr %"compiler/mir:Range", ptr %l10, i32 0, i32 0
  %t330 = load i32, ptr %t329, !tbaa !23
  %t332 = sext i32 %t330 to i64
  %t333 = load i32, ptr %l23, !tbaa !23
  %t335 = sext i32 %t333 to i64
  %t338 = add i64 %t332, %t335
  %t340 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr %"compiler/mir:Case", ptr %t341, i64 %t338
  %t343 = getelementptr %"compiler/mir:Case", ptr %t342, i32 0, i32 1
  %t344 = load i32, ptr %t343, !tbaa !23
  store i32 %t344, ptr %l13, !tbaa !23
  br label %bb75
bb74:
  br label %bb75
bb75:
  br label %bb79
bb76:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/eval:Machine", ptr %t346, i32 0, i32 17
  %t349 = load { i64, ptr }, ptr %t348, !tbaa !27
  store { i64, ptr } %t349, ptr %l217, !tbaa !27
  %t350 = load i64, ptr %l4, !tbaa !24
  %t352 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = getelementptr %"compiler/eval:cfn", ptr %t353, i64 %t350
  %t355 = getelementptr %"compiler/eval:cfn", ptr %t354, i32 0, i32 6
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  store { i64, ptr } %t356, ptr %l219, !tbaa !27
  %t357 = getelementptr %"compiler/mir:Range", ptr %l10, i32 0, i32 0
  %t358 = load i32, ptr %t357, !tbaa !23
  %t360 = sext i32 %t358 to i64
  %t361 = load i32, ptr %l23, !tbaa !23
  %t363 = sext i32 %t361 to i64
  %t366 = add i64 %t360, %t363
  %t368 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr %"compiler/mir:Case", ptr %t369, i64 %t366
  %t371 = getelementptr %"compiler/mir:Case", ptr %t370, i32 0, i32 1
  %t372 = load i32, ptr %t371, !tbaa !23
  store i32 %t372, ptr %l13, !tbaa !23
  br label %bb78
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t374 = load i32, ptr %l22, !tbaa !23
  %t376 = add i32 %t374, 1
  store i32 %t376, ptr %l22, !tbaa !23
  br label %bb62
bb81:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/eval:Machine", ptr %t378, i32 0, i32 13
  %t381 = load i1, ptr %t380, !tbaa !21
  %t383 = xor i1 %t381, true
  br i1 %t383, label %bb82, label %bb83
bb82:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load i64, ptr %l1, !tbaa !24
  %t387 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %t385, i64 %t386, i32 %t387)
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb85
bb85:
  br label %bb207
bb86:
  %t391 = load { i64, [8 x i64] }, ptr %l2
  %t393 = extractvalue { i64, [8 x i64] } %t391, 0
  %t394 = icmp eq i64 %t393, 4
  br i1 %t394, label %bb87, label %bb88
bb87:
  %t396 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t397 = getelementptr { %"compiler/source:Span", i32 }, ptr %t396, i32 0, i32 0
  %t398 = load %"compiler/source:Span", ptr %t397
  store %"compiler/source:Span" %t398, ptr %l28
  %t400 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", i32 }, ptr %t400, i32 0, i32 1
  %t402 = load i32, ptr %t401
  store i32 %t402, ptr %l29, !tbaa !23
  br label %bb89
bb88:
  br label %bb124
bb89:
  store %olang.scope zeroinitializer, ptr %s16
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load i64, ptr %l4, !tbaa !24
  %t406 = load %"compiler/source:Span", ptr %l28
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t404, i64 %t405, %"compiler/source:Span" %t406)
  br label %bb90
bb90:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/eval:Machine", ptr %t410, i32 0, i32 17
  %t413 = load { i64, ptr }, ptr %t412, !tbaa !27
  store { i64, ptr } %t413, ptr %l242, !tbaa !27
  %t414 = load i64, ptr %l4, !tbaa !24
  %t416 = getelementptr { i64, ptr }, ptr %l242, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !27
  %t418 = getelementptr %"compiler/eval:cfn", ptr %t417, i64 %t414
  %t419 = getelementptr %"compiler/eval:cfn", ptr %t418, i32 0, i32 5
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  store { i64, ptr } %t420, ptr %l244, !tbaa !27
  %t421 = load i32, ptr %l29, !tbaa !23
  %t423 = sext i32 %t421 to i64
  %t425 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !27
  %t427 = getelementptr %"compiler/mir:Call", ptr %t426, i64 %t423
  %t428 = load %"compiler/mir:Call", ptr %t427
  store %"compiler/mir:Call" %t428, ptr %l30
  %t430 = load i1, ptr %l3, !tbaa !21
  br i1 %t430, label %bb91, label %bb92
bb91:
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l250, !tbaa !29
  %t433 = load i64, ptr %l1, !tbaa !24
  store i64 %t433, ptr %l251, !tbaa !24
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/eval:Machine", ptr %t434, i32 0, i32 16
  %t437 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t438, ptr %v0, ptr %v0, ptr %t436, i64 %t437)
  call void @llvm.memmove.p0.p0.i64(ptr %l255, ptr %t438, i64 248, i1 false)
  br label %bb93
bb92:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb95
bb93:
  %t441 = call ptr @__olang_scope_alloc_a(ptr %s16, i64 248, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t441, ptr %l255, i64 248, i1 false)
  %t442 = getelementptr %"compiler/mir:Call", ptr %l30, i32 0, i32 1
  %t443 = load %"compiler/mir:Range", ptr %t442
  %t444 = load ptr, ptr %l250, !tbaa !29
  %t445 = load i64, ptr %l251, !tbaa !24
  %t448 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeReady(ptr %v0, ptr %v0, ptr %t444, i64 %t445, ptr %t441, %"compiler/mir:Range" %t443)
  store i1 %t448, ptr %l258
  br label %bb94
bb94:
  %t449 = load i1, ptr %l258, !tbaa !21
  %t450 = xor i1 %t449, true
  store i1 %t450, ptr %l249, !tbaa !21
  br label %bb95
bb95:
  %t452 = load i1, ptr %l249, !tbaa !21
  br i1 %t452, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s16)
  br label %ret
bb97:
  br label %bb98
bb98:
  %t453 = getelementptr %"compiler/mir:Call", ptr %l30, i32 0, i32 0
  %t454 = load { i64, [7 x i64] }, ptr %t453
  store { i64, [7 x i64] } %t454, ptr %l31
  %t456 = load { i64, [7 x i64] }, ptr %l31
  %t458 = extractvalue { i64, [7 x i64] } %t456, 0
  %t459 = icmp eq i64 %t458, 1
  br i1 %t459, label %bb99, label %bb100
bb99:
  %t461 = getelementptr { i64, [7 x i64] }, ptr %l31, i32 0, i32 1
  %t462 = getelementptr { i64, i32 }, ptr %t461, i32 0, i32 0
  %t463 = load i64, ptr %t462
  store i64 %t463, ptr %l32, !tbaa !24
  %t465 = getelementptr { i64, [7 x i64] }, ptr %l31, i32 0, i32 1
  %t466 = getelementptr { i64, i32 }, ptr %t465, i32 0, i32 1
  %t467 = load i32, ptr %t466
  store i32 %t467, ptr %l33, !tbaa !23
  br label %bb101
bb100:
  br label %bb103
bb101:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load i64, ptr %l1, !tbaa !24
  %t471 = load %"compiler/mir:Call", ptr %l30
  %t472 = load i64, ptr %l32, !tbaa !24
  %t473 = load i32, ptr %l33, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eexternCall(ptr %v0, ptr %t469, i64 %t470, %"compiler/mir:Call" %t471, i64 %t472, i32 %t473)
  br label %bb102
bb102:
  br label %bb123
bb103:
  %t479 = load { i64, [7 x i64] }, ptr %l31
  %t481 = extractvalue { i64, [7 x i64] } %t479, 0
  %t482 = icmp eq i64 %t481, 2
  br i1 %t482, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb117
bb106:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load i64, ptr %l1, !tbaa !24
  %t486 = getelementptr %"compiler/mir:Call", ptr %l30, i32 0, i32 0
  %t487 = load { i64, [7 x i64] }, ptr %t486
  %t491 = call { i64, %"compiler/eval:Ptr", i1, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallee(ptr %v0, ptr %t484, i64 %t485, { i64, [7 x i64] } %t487)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t491, ptr %l275
  br label %bb107
bb107:
  %t492 = load { i64, %"compiler/eval:Ptr", i1, i64 }, ptr %l275
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t492, ptr %l34
  %t493 = getelementptr { i64, %"compiler/eval:Ptr", i1, i64 }, ptr %l34, i32 0, i32 2
  %t494 = load i1, ptr %t493, !tbaa !21
  store i1 %t494, ptr %l35, !tbaa !21
  %t496 = getelementptr { i64, %"compiler/eval:Ptr", i1, i64 }, ptr %l34, i32 0, i32 3
  %t497 = load i64, ptr %t496, !tbaa !24
  store i64 %t497, ptr %l36, !tbaa !24
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t501 = getelementptr %"compiler/eval:Machine", ptr %t499, i32 0, i32 13
  %t502 = load i1, ptr %t501, !tbaa !21
  br i1 %t502, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s16)
  br label %ret
bb109:
  br label %bb110
bb110:
  %t504 = load i1, ptr %l35, !tbaa !21
  br i1 %t504, label %bb111, label %bb112
bb111:
  %t506 = load ptr, ptr %l0, !tbaa !29
  store ptr %t506, ptr %l281, !tbaa !29
  %t507 = load i64, ptr %l1, !tbaa !24
  store i64 %t507, ptr %l282, !tbaa !24
  %t508 = load %"compiler/mir:Call", ptr %l30
  store %"compiler/mir:Call" %t508, ptr %l283
  %t509 = load i64, ptr %l36, !tbaa !24
  store i64 %t509, ptr %l284, !tbaa !24
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t511 = load i64, ptr %l1, !tbaa !24
  %t512 = getelementptr %"compiler/mir:Call", ptr %l30, i32 0, i32 0
  %t513 = load { i64, [7 x i64] }, ptr %t512
  %t517 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecalleeType(ptr %v0, ptr %t510, i64 %t511, { i64, [7 x i64] } %t513)
  store i32 %t517, ptr %l288
  br label %bb113
bb112:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load i64, ptr %l1, !tbaa !24
  %t520 = getelementptr %"compiler/mir:Call", ptr %l30, i32 0, i32 0
  %t521 = load { i64, [7 x i64] }, ptr %t520
  %t522 = getelementptr %"compiler/mir:Call", ptr %l30, i32 0, i32 1
  %t523 = load %"compiler/mir:Range", ptr %t522
  %t524 = getelementptr %"compiler/mir:Call", ptr %l30, i32 0, i32 2
  %t525 = load %"compiler/mir:Range", ptr %t524
  %t526 = load i64, ptr @G_2ecompiler_2feval_2erCall, !tbaa !24
  %t527 = load i32, ptr %l29, !tbaa !23
  %t529 = sext i32 %t527 to i64
  %t537 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eenter(ptr %v0, ptr %t518, i64 %t519, { i64, [7 x i64] } %t521, %"compiler/mir:Range" %t523, %"compiler/mir:Range" %t525, i64 %t526, i64 %t529)
  store i64 %t537, ptr %l297
  br label %bb115
bb113:
  %t538 = load ptr, ptr %l281, !tbaa !29
  %t539 = load i64, ptr %l282, !tbaa !24
  %t540 = load %"compiler/mir:Call", ptr %l283
  %t541 = load i64, ptr %l284, !tbaa !24
  %t542 = load i32, ptr %l288, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eexternCall(ptr %v0, ptr %t538, i64 %t539, %"compiler/mir:Call" %t540, i64 %t541, i32 %t542)
  br label %bb114
bb114:
  br label %bb116
bb115:
  br label %bb116
bb116:
  br label %bb123
bb117:
  br i1 true, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb122
bb120:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load i64, ptr %l1, !tbaa !24
  %t545 = getelementptr %"compiler/mir:Call", ptr %l30, i32 0, i32 0
  %t546 = load { i64, [7 x i64] }, ptr %t545
  %t547 = getelementptr %"compiler/mir:Call", ptr %l30, i32 0, i32 1
  %t548 = load %"compiler/mir:Range", ptr %t547
  %t549 = getelementptr %"compiler/mir:Call", ptr %l30, i32 0, i32 2
  %t550 = load %"compiler/mir:Range", ptr %t549
  %t551 = load i64, ptr @G_2ecompiler_2feval_2erCall, !tbaa !24
  %t552 = load i32, ptr %l29, !tbaa !23
  %t554 = sext i32 %t552 to i64
  %t562 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eenter(ptr %v0, ptr %t543, i64 %t544, { i64, [7 x i64] } %t546, %"compiler/mir:Range" %t548, %"compiler/mir:Range" %t550, i64 %t551, i64 %t554)
  store i64 %t562, ptr %l306
  br label %bb121
bb121:
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_f83a50064779c123_fa52c016159405ff)
  unreachable
bb123:
  call void @__olang_scope_close(ptr %s16)
  br label %bb207
bb124:
  %t563 = load { i64, [8 x i64] }, ptr %l2
  %t565 = extractvalue { i64, [8 x i64] } %t563, 0
  %t566 = icmp eq i64 %t565, 5
  br i1 %t566, label %bb125, label %bb126
bb125:
  %t568 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t568, i32 0, i32 0
  %t570 = load %"compiler/source:Span", ptr %t569
  store %"compiler/source:Span" %t570, ptr %l37
  %t572 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t573 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t572, i32 0, i32 1
  %t574 = load { i64, [4 x i64] }, ptr %t573
  store { i64, [4 x i64] } %t574, ptr %l38
  br label %bb127
bb126:
  br label %bb140
bb127:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load i64, ptr %l4, !tbaa !24
  %t578 = load %"compiler/source:Span", ptr %l37
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t576, i64 %t577, %"compiler/source:Span" %t578)
  br label %bb128
bb128:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/eval:Machine", ptr %t582, i32 0, i32 49
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  store { i64, ptr } %t585, ptr %l315, !tbaa !27
  %t586 = load i64, ptr %l1, !tbaa !24
  %t588 = getelementptr { i64, ptr }, ptr %l315, i32 0, i32 1
  %t589 = load ptr, ptr %t588, !tbaa !27
  %t590 = getelementptr %"compiler/eval:frame", ptr %t589, i64 %t586
  %t591 = getelementptr %"compiler/eval:frame", ptr %t590, i32 0, i32 11
  %t592 = load i1, ptr %t591, !tbaa !21
  %t594 = xor i1 %t592, true
  br i1 %t594, label %bb129, label %bb130
bb129:
  %t596 = load i1, ptr %l3, !tbaa !21
  store i1 %t596, ptr %l319, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l319, !tbaa !21
  br label %bb131
bb131:
  %t598 = load i1, ptr %l319, !tbaa !21
  br i1 %t598, label %bb132, label %bb133
bb132:
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t600 = load i64, ptr %l1, !tbaa !24
  %t601 = load { i64, [4 x i64] }, ptr %l38
  %t605 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t599, i64 %t600, { i64, [4 x i64] } %t601)
  store i1 %t605, ptr %l325
  br label %bb134
bb133:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb135
bb134:
  %t606 = load i1, ptr %l325, !tbaa !21
  %t607 = xor i1 %t606, true
  store i1 %t607, ptr %l321, !tbaa !21
  br label %bb135
bb135:
  %t609 = load i1, ptr %l321, !tbaa !21
  br i1 %t609, label %bb136, label %bb137
bb136:
  br label %ret
bb137:
  br label %bb138
bb138:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t611 = load i64, ptr %l1, !tbaa !24
  %t612 = load { i64, [4 x i64] }, ptr %l38
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eleave(ptr %v0, ptr %t610, i64 %t611, i1 false, { i64, [4 x i64] } %t612, i64 0)
  br label %bb139
bb139:
  br label %bb207
bb140:
  %t616 = load { i64, [8 x i64] }, ptr %l2
  %t618 = extractvalue { i64, [8 x i64] } %t616, 0
  %t619 = icmp eq i64 %t618, 6
  br i1 %t619, label %bb141, label %bb142
bb141:
  %t621 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t622 = getelementptr { %"compiler/source:Span", i32 }, ptr %t621, i32 0, i32 0
  %t623 = load %"compiler/source:Span", ptr %t622
  store %"compiler/source:Span" %t623, ptr %l39
  %t625 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t626 = getelementptr { %"compiler/source:Span", i32 }, ptr %t625, i32 0, i32 1
  %t627 = load i32, ptr %t626
  store i32 %t627, ptr %l40, !tbaa !23
  br label %bb143
bb142:
  br label %bb154
bb143:
  store %olang.scope zeroinitializer, ptr %s26
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t630 = load i64, ptr %l4, !tbaa !24
  %t631 = load %"compiler/source:Span", ptr %l39
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t629, i64 %t630, %"compiler/source:Span" %t631)
  br label %bb144
bb144:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/eval:Machine", ptr %t635, i32 0, i32 17
  %t638 = load { i64, ptr }, ptr %t637, !tbaa !27
  store { i64, ptr } %t638, ptr %l338, !tbaa !27
  %t639 = load i64, ptr %l4, !tbaa !24
  %t641 = getelementptr { i64, ptr }, ptr %l338, i32 0, i32 1
  %t642 = load ptr, ptr %t641, !tbaa !27
  %t643 = getelementptr %"compiler/eval:cfn", ptr %t642, i64 %t639
  %t644 = getelementptr %"compiler/eval:cfn", ptr %t643, i32 0, i32 5
  %t645 = load { i64, ptr }, ptr %t644, !tbaa !27
  store { i64, ptr } %t645, ptr %l340, !tbaa !27
  %t646 = load i32, ptr %l40, !tbaa !23
  %t648 = sext i32 %t646 to i64
  %t650 = getelementptr { i64, ptr }, ptr %l340, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !27
  %t652 = getelementptr %"compiler/mir:Call", ptr %t651, i64 %t648
  %t653 = load %"compiler/mir:Call", ptr %t652
  store %"compiler/mir:Call" %t653, ptr %l41
  %t655 = load i1, ptr %l3, !tbaa !21
  br i1 %t655, label %bb145, label %bb146
bb145:
  %t657 = load ptr, ptr %l0, !tbaa !29
  store ptr %t657, ptr %l346, !tbaa !29
  %t658 = load i64, ptr %l1, !tbaa !24
  store i64 %t658, ptr %l347, !tbaa !24
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t661 = getelementptr %"compiler/eval:Machine", ptr %t659, i32 0, i32 16
  %t662 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t663, ptr %v0, ptr %v0, ptr %t661, i64 %t662)
  call void @llvm.memmove.p0.p0.i64(ptr %l351, ptr %t663, i64 248, i1 false)
  br label %bb147
bb146:
  store i1 false, ptr %l345, !tbaa !21
  br label %bb149
bb147:
  %t666 = call ptr @__olang_scope_alloc_a(ptr %s26, i64 248, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t666, ptr %l351, i64 248, i1 false)
  %t667 = getelementptr %"compiler/mir:Call", ptr %l41, i32 0, i32 1
  %t668 = load %"compiler/mir:Range", ptr %t667
  %t669 = load ptr, ptr %l346, !tbaa !29
  %t670 = load i64, ptr %l347, !tbaa !24
  %t673 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeReady(ptr %v0, ptr %v0, ptr %t669, i64 %t670, ptr %t666, %"compiler/mir:Range" %t668)
  store i1 %t673, ptr %l354
  br label %bb148
bb148:
  %t674 = load i1, ptr %l354, !tbaa !21
  %t675 = xor i1 %t674, true
  store i1 %t675, ptr %l345, !tbaa !21
  br label %bb149
bb149:
  %t677 = load i1, ptr %l345, !tbaa !21
  br i1 %t677, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s26)
  br label %ret
bb151:
  br label %bb152
bb152:
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t679 = load i64, ptr %l1, !tbaa !24
  %t680 = load %"compiler/mir:Call", ptr %l41
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2etail(ptr %v0, ptr %t678, i64 %t679, %"compiler/mir:Call" %t680)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s26)
  br label %bb207
bb154:
  %t684 = load { i64, [8 x i64] }, ptr %l2
  %t686 = extractvalue { i64, [8 x i64] } %t684, 0
  %t687 = icmp eq i64 %t686, 11
  br i1 %t687, label %bb155, label %bb156
bb155:
  %t689 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t690 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t689, i32 0, i32 0
  %t691 = load %"compiler/source:Span", ptr %t690
  store %"compiler/source:Span" %t691, ptr %l42
  %t693 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t694 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t693, i32 0, i32 1
  %t695 = load { i64, [4 x i64] }, ptr %t694
  store { i64, [4 x i64] } %t695, ptr %l43
  %t697 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t698 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t697, i32 0, i32 2
  %t699 = load i32, ptr %t698
  store i32 %t699, ptr %l44, !tbaa !23
  %t701 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t702 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t701, i32 0, i32 3
  %t703 = load %"compiler/mir:Range", ptr %t702
  store %"compiler/mir:Range" %t703, ptr %l45
  br label %bb157
bb156:
  br label %bb167
bb157:
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load i64, ptr %l4, !tbaa !24
  %t707 = load %"compiler/source:Span", ptr %l42
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t705, i64 %t706, %"compiler/source:Span" %t707)
  br label %bb158
bb158:
  %t711 = load i1, ptr %l3, !tbaa !21
  br i1 %t711, label %bb159, label %bb160
bb159:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load i64, ptr %l1, !tbaa !24
  %t715 = load { i64, [4 x i64] }, ptr %l43
  %t719 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t713, i64 %t714, { i64, [4 x i64] } %t715)
  store i1 %t719, ptr %l373
  br label %bb161
bb160:
  store i1 false, ptr %l369, !tbaa !21
  br label %bb162
bb161:
  %t720 = load i1, ptr %l373, !tbaa !21
  %t721 = xor i1 %t720, true
  store i1 %t721, ptr %l369, !tbaa !21
  br label %bb162
bb162:
  %t723 = load i1, ptr %l369, !tbaa !21
  br i1 %t723, label %bb163, label %bb164
bb163:
  br label %ret
bb164:
  br label %bb165
bb165:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t725 = load i64, ptr %l1, !tbaa !24
  %t726 = load { i64, [4 x i64] }, ptr %l43
  %t727 = load i32, ptr %l44, !tbaa !23
  %t728 = load %"compiler/mir:Range", ptr %l45
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2esuspend(ptr %v0, ptr %t724, i64 %t725, { i64, [4 x i64] } %t726, i32 %t727, %"compiler/mir:Range" %t728)
  br label %bb166
bb166:
  br label %bb207
bb167:
  %t734 = load { i64, [8 x i64] }, ptr %l2
  %t736 = extractvalue { i64, [8 x i64] } %t734, 0
  %t737 = icmp eq i64 %t736, 7
  br i1 %t737, label %bb168, label %bb169
bb168:
  %t739 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t740 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t739, i32 0, i32 0
  %t741 = load %"compiler/source:Span", ptr %t740
  store %"compiler/source:Span" %t741, ptr %l46
  %t743 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t744 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t743, i32 0, i32 1
  %t745 = load { i64, [4 x i64] }, ptr %t744
  store { i64, [4 x i64] } %t745, ptr %l47
  br label %bb170
bb169:
  br label %bb190
bb170:
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t748 = load i64, ptr %l4, !tbaa !24
  %t749 = load %"compiler/source:Span", ptr %l46
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t747, i64 %t748, %"compiler/source:Span" %t749)
  br label %bb171
bb171:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t755 = getelementptr %"compiler/eval:Machine", ptr %t753, i32 0, i32 49
  %t756 = load { i64, ptr }, ptr %t755, !tbaa !27
  store { i64, ptr } %t756, ptr %l388, !tbaa !27
  %t757 = load i64, ptr %l1, !tbaa !24
  %t759 = getelementptr { i64, ptr }, ptr %l388, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !27
  %t761 = getelementptr %"compiler/eval:frame", ptr %t760, i64 %t757
  %t762 = getelementptr %"compiler/eval:frame", ptr %t761, i32 0, i32 11
  %t763 = load i1, ptr %t762, !tbaa !21
  %t765 = xor i1 %t763, true
  br i1 %t765, label %bb172, label %bb173
bb172:
  %t767 = load ptr, ptr %l0, !tbaa !29
  %t769 = getelementptr %"compiler/eval:Machine", ptr %t767, i32 0, i32 49
  %t770 = load { i64, ptr }, ptr %t769, !tbaa !27
  store { i64, ptr } %t770, ptr %l394, !tbaa !27
  %t771 = load i64, ptr %l1, !tbaa !24
  %t773 = getelementptr { i64, ptr }, ptr %l394, i32 0, i32 1
  %t774 = load ptr, ptr %t773, !tbaa !27
  %t775 = getelementptr %"compiler/eval:frame", ptr %t774, i64 %t771
  %t776 = getelementptr %"compiler/eval:frame", ptr %t775, i32 0, i32 18
  %t777 = load i32, ptr %t776, !tbaa !23
  %t779 = icmp sge i32 %t777, 0
  store i1 %t779, ptr %l392, !tbaa !21
  br label %bb174
bb173:
  store i1 false, ptr %l392, !tbaa !21
  br label %bb174
bb174:
  %t781 = load i1, ptr %l392, !tbaa !21
  br i1 %t781, label %bb175, label %bb176
bb175:
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t784 = getelementptr %"compiler/eval:Machine", ptr %t782, i32 0, i32 49
  %t785 = load { i64, ptr }, ptr %t784, !tbaa !27
  store { i64, ptr } %t785, ptr %l399, !tbaa !27
  %t786 = load i64, ptr %l1, !tbaa !24
  %t788 = getelementptr { i64, ptr }, ptr %l399, i32 0, i32 1
  %t789 = load ptr, ptr %t788, !tbaa !27
  %t790 = getelementptr %"compiler/eval:frame", ptr %t789, i64 %t786
  %t791 = getelementptr %"compiler/eval:frame", ptr %t790, i32 0, i32 18
  %t792 = load i32, ptr %t791, !tbaa !23
  %t794 = sext i32 %t792 to i64
  store i64 %t794, ptr %l48, !tbaa !24
  store i64 3, ptr %l49, !tbaa !24
  %t796 = load ptr, ptr %l0, !tbaa !29
  %t798 = getelementptr %"compiler/eval:Machine", ptr %t796, i32 0, i32 54
  %t799 = load i64, ptr %l48, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %t800, ptr %v0, ptr %t798, i64 %t799)
  call void @llvm.memmove.p0.p0.i64(ptr %l406, ptr %t800, i64 176, i1 false)
  br label %bb177
bb176:
  br label %bb179
bb177:
  call void @llvm.memmove.p0.p0.i64(ptr %l50, ptr %l406, i64 176, i1 false)
  %t803 = load i64, ptr %l49, !tbaa !24
  %t805 = getelementptr %"compiler/eval:genRec", ptr %l50, i32 0, i32 0
  store i64 %t803, ptr %t805, !tbaa !24
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t808 = getelementptr %"compiler/eval:Machine", ptr %t806, i32 0, i32 54
  %t809 = load i64, ptr %l48, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l411, ptr %l50, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t812, ptr %l411, i64 176, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eSetAt_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %t808, i64 %t809, ptr %t812)
  br label %bb178
bb178:
  br label %bb179
bb179:
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t815 = getelementptr %"compiler/eval:Machine", ptr %t813, i32 0, i32 49
  %t816 = load { i64, ptr }, ptr %t815, !tbaa !27
  store { i64, ptr } %t816, ptr %l413, !tbaa !27
  %t817 = load i64, ptr %l1, !tbaa !24
  %t819 = getelementptr { i64, ptr }, ptr %l413, i32 0, i32 1
  %t820 = load ptr, ptr %t819, !tbaa !27
  %t821 = getelementptr %"compiler/eval:frame", ptr %t820, i64 %t817
  %t822 = getelementptr %"compiler/eval:frame", ptr %t821, i32 0, i32 11
  %t823 = load i1, ptr %t822, !tbaa !21
  %t825 = xor i1 %t823, true
  br i1 %t825, label %bb180, label %bb181
bb180:
  %t827 = load ptr, ptr %l0, !tbaa !29
  %t828 = load i64, ptr %l1, !tbaa !24
  %t829 = load i64, ptr %l4, !tbaa !24
  %t830 = load %"compiler/source:Span", ptr %l46
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2etraced(ptr %v0, ptr %t827, i64 %t828, i64 %t829, %"compiler/source:Span" %t830)
  br label %bb182
bb181:
  br label %bb183
bb182:
  br label %bb183
bb183:
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t837 = getelementptr %"compiler/eval:Machine", ptr %t835, i32 0, i32 49
  %t838 = load { i64, ptr }, ptr %t837, !tbaa !27
  store { i64, ptr } %t838, ptr %l422, !tbaa !27
  %t839 = load i64, ptr %l1, !tbaa !24
  %t841 = getelementptr { i64, ptr }, ptr %l422, i32 0, i32 1
  %t842 = load ptr, ptr %t841, !tbaa !27
  %t843 = getelementptr %"compiler/eval:frame", ptr %t842, i64 %t839
  %t844 = getelementptr %"compiler/eval:frame", ptr %t843, i32 0, i32 11
  %t845 = load i1, ptr %t844, !tbaa !21
  br i1 %t845, label %bb184, label %bb185
bb184:
  %t847 = load ptr, ptr %l0, !tbaa !29
  %t849 = getelementptr %"compiler/eval:Machine", ptr %t847, i32 0, i32 49
  %t850 = load { i64, ptr }, ptr %t849, !tbaa !27
  store { i64, ptr } %t850, ptr %l427, !tbaa !27
  %t851 = load i64, ptr %l1, !tbaa !24
  %t853 = getelementptr { i64, ptr }, ptr %l427, i32 0, i32 1
  %t854 = load ptr, ptr %t853, !tbaa !27
  %t855 = getelementptr %"compiler/eval:frame", ptr %t854, i64 %t851
  %t856 = getelementptr %"compiler/eval:frame", ptr %t855, i32 0, i32 13
  %t857 = load i64, ptr %t856, !tbaa !24
  store i64 %t857, ptr %l425, !tbaa !24
  br label %bb188
bb185:
  %t859 = load ptr, ptr %l0, !tbaa !29
  store ptr %t859, ptr %l430, !tbaa !29
  %t860 = load ptr, ptr %l0, !tbaa !29
  %t861 = load i64, ptr %l1, !tbaa !24
  %t862 = load { i64, [4 x i64] }, ptr %l47
  %t866 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t860, i64 %t861, { i64, [4 x i64] } %t862)
  store i64 %t866, ptr %l434
  br label %bb186
bb186:
  %t867 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t868 = load ptr, ptr %l430, !tbaa !29
  %t869 = load i64, ptr %l434, !tbaa !24
  %t871 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t868, i64 %t869, i32 %t867)
  store i64 %t871, ptr %l436
  br label %bb187
bb187:
  %t872 = load i64, ptr %l436, !tbaa !24
  store i64 %t872, ptr %l425, !tbaa !24
  br label %bb188
bb188:
  %t873 = load i64, ptr %l425, !tbaa !24
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t875 = load i64, ptr %l1, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t876
  %t877 = getelementptr { i64, [4 x i64] }, ptr %t876, i32 0, i32 0
  store i64 0, ptr %t877
  %t878 = load { i64, [4 x i64] }, ptr %t876
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eleave(ptr %v0, ptr %t874, i64 %t875, i1 true, { i64, [4 x i64] } %t878, i64 %t873)
  br label %bb189
bb189:
  br label %bb207
bb190:
  %t884 = load { i64, [8 x i64] }, ptr %l2
  %t886 = extractvalue { i64, [8 x i64] } %t884, 0
  %t887 = icmp eq i64 %t886, 8
  br i1 %t887, label %bb191, label %bb192
bb191:
  %t889 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t890 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t889, i32 0, i32 0
  %t891 = load %"compiler/source:Span", ptr %t890
  store %"compiler/source:Span" %t891, ptr %l52
  %t893 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t894 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t893, i32 0, i32 1
  %t895 = load i32, ptr %t894
  store i32 %t895, ptr %l53, !tbaa !23
  %t897 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t898 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t897, i32 0, i32 2
  %t899 = load i32, ptr %t898
  store i32 %t899, ptr %l54, !tbaa !23
  %t901 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t902 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t901, i32 0, i32 3
  %t903 = load i32, ptr %t902
  store i32 %t903, ptr %l55, !tbaa !23
  %t905 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t906 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t905, i32 0, i32 4
  %t907 = load i32, ptr %t906
  store i32 %t907, ptr %l56, !tbaa !23
  br label %bb193
bb192:
  br label %bb196
bb193:
  %t909 = load ptr, ptr %l0, !tbaa !29
  %t910 = load i64, ptr %l4, !tbaa !24
  %t911 = load %"compiler/source:Span", ptr %l52
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t909, i64 %t910, %"compiler/source:Span" %t911)
  br label %bb194
bb194:
  %t915 = load ptr, ptr %l0, !tbaa !29
  %t916 = load i64, ptr %l1, !tbaa !24
  %t917 = load i32, ptr %l53, !tbaa !23
  %t918 = load i32, ptr %l54, !tbaa !23
  %t919 = load i32, ptr %l55, !tbaa !23
  %t920 = load i32, ptr %l56, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewait(ptr %v0, ptr %t915, i64 %t916, i32 %t917, i32 %t918, i32 %t919, i32 %t920)
  br label %bb195
bb195:
  br label %bb207
bb196:
  %t927 = load { i64, [8 x i64] }, ptr %l2
  %t929 = extractvalue { i64, [8 x i64] } %t927, 0
  %t930 = icmp eq i64 %t929, 9
  br i1 %t930, label %bb197, label %bb198
bb197:
  %t932 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t933 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t932, i32 0, i32 0
  %t934 = load %"compiler/source:Span", ptr %t933
  store %"compiler/source:Span" %t934, ptr %l57
  %t936 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t937 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t936, i32 0, i32 1
  %t938 = load i32, ptr %t937
  store i32 %t938, ptr %l58
  %t940 = getelementptr { i64, [8 x i64] }, ptr %l2, i32 0, i32 1
  %t941 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t940, i32 0, i32 2
  %t942 = load { i64, [4 x i64] }, ptr %t941
  store { i64, [4 x i64] } %t942, ptr %l59
  br label %bb199
bb198:
  br label %bb202
bb199:
  %t944 = load ptr, ptr %l0, !tbaa !29
  %t945 = load i64, ptr %l4, !tbaa !24
  %t946 = load %"compiler/source:Span", ptr %l57
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t944, i64 %t945, %"compiler/source:Span" %t946)
  br label %bb200
bb200:
  %t950 = load ptr, ptr %l0, !tbaa !29
  %t951 = load i64, ptr %l1, !tbaa !24
  %t952 = load ptr, ptr %l0, !tbaa !29
  %t954 = getelementptr %"compiler/eval:Machine", ptr %t952, i32 0, i32 17
  %t955 = load { i64, ptr }, ptr %t954, !tbaa !27
  store { i64, ptr } %t955, ptr %l468, !tbaa !27
  %t956 = load i64, ptr %l4, !tbaa !24
  %t958 = getelementptr { i64, ptr }, ptr %l468, i32 0, i32 1
  %t959 = load ptr, ptr %t958, !tbaa !27
  %t960 = getelementptr %"compiler/eval:cfn", ptr %t959, i64 %t956
  %t961 = getelementptr %"compiler/eval:cfn", ptr %t960, i32 0, i32 0
  %t962 = load i64, ptr %t961, !tbaa !24
  %t963 = load %"compiler/source:Span", ptr %l57
  %t964 = load i32, ptr %l58
  %t965 = load { i64, [4 x i64] }, ptr %l59
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eexit(ptr %v0, ptr %t950, i64 %t951, i64 %t962, %"compiler/source:Span" %t963, i32 %t964, { i64, [4 x i64] } %t965)
  br label %bb201
bb201:
  br label %bb207
bb202:
  %t972 = load { i64, [8 x i64] }, ptr %l2
  %t974 = extractvalue { i64, [8 x i64] } %t972, 0
  %t975 = icmp eq i64 %t974, 10
  br i1 %t975, label %bb203, label %bb204
bb203:
  br label %bb205
bb204:
  br label %bb206
bb205:
  %t977 = load ptr, ptr %l0, !tbaa !29
  %t979 = getelementptr %"compiler/eval:Machine", ptr %t977, i32 0, i32 60
  store i1 true, ptr %t979, !tbaa !21
  %t980 = load ptr, ptr %l0, !tbaa !29
  %t982 = getelementptr %"compiler/eval:Machine", ptr %t980, i32 0, i32 13
  store i1 true, ptr %t982, !tbaa !21
  br label %bb207
bb206:
  call void @__olang_check_failed(ptr @olang_loc_44d04288ad1da022_22f50395241cffe)
  unreachable
bb207:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2etext(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, { i64, [1 x i64] } %a3, { i64, [1 x i64] } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i1
  %l22 = alloca i1
  %l29 = alloca %"compiler/eval:scope"
  %l35 = alloca %"compiler/eval:Ptr"
  %l40 = alloca ptr
  %l41 = alloca %"compiler/eval:Ptr"
  %l47 = alloca %"compiler/eval:scope"
  %l49 = alloca %"compiler/eval:Ptr"
  %l54 = alloca ptr
  %l58 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %t39 = alloca %"compiler/eval:scope", align 8
  %t74 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t1, i64 %t2, { i64, [1 x i64] } %a3)
  store i64 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i64, ptr %l12, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t15 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %t9, i64 %t10, { i64, [1 x i64] } %a4)
  store i64 %t15, ptr %l16
  br label %bb2
bb2:
  %t16 = load i64, ptr %l16, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 13
  %t20 = load i1, ptr %t19, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb6
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t26, ptr %l22
  br label %bb5
bb5:
  %t27 = load i1, ptr %l22, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/eval:Machine", ptr %t31, i32 0, i32 43
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t38 = and i64 %t34, %t35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t39, ptr %v0, ptr %t33, i64 %t38)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t39, i64 136, i1 false)
  br label %bb10
bb10:
  %t42 = getelementptr %"compiler/eval:scope", ptr %l29, i32 0, i32 9
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t53 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t45, i64 %t46, i64 %t47, i64 %t48)
  store %"compiler/eval:Ptr" %t53, ptr %l35
  br label %bb11
bb11:
  %t54 = load %"compiler/eval:Ptr", ptr %l35
  store %"compiler/eval:Ptr" %t54, ptr %l8
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/eval:Machine", ptr %t55, i32 0, i32 13
  %t58 = load i1, ptr %t57, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l40, !tbaa !29
  %t65 = load %"compiler/eval:Ptr", ptr %l8
  store %"compiler/eval:Ptr" %t65, ptr %l41
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/eval:Machine", ptr %t66, i32 0, i32 43
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t73 = and i64 %t69, %t70
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t74, ptr %v0, ptr %t68, i64 %t73)
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t74, i64 136, i1 false)
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t77 = getelementptr %"compiler/eval:scope", ptr %l47, i32 0, i32 8
  %t78 = load i64, ptr %t77, !tbaa !24
  %t80 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t78, i64 0)
  store %"compiler/eval:Ptr" %t80, ptr %l49
  br label %bb18
bb18:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = load %"compiler/eval:Ptr", ptr %l41
  %t84 = load %"compiler/eval:Ptr", ptr %l49
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t82, %"compiler/eval:Ptr" %t83, %"compiler/eval:Ptr" %t84, i64 %t81)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load %"compiler/eval:Ptr", ptr %l2
  %t88 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t86, %"compiler/eval:Ptr" %t87, i64 8, i64 %t88)
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l54, !tbaa !29
  %t93 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t96 = load i64, ptr %t95, !tbaa !24
  %t98 = add i64 %t96, 8
  %t101 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t94, i64 %t98)
  store %"compiler/eval:Ptr" %t101, ptr %l58
  br label %bb22
bb22:
  %t102 = load %"compiler/eval:Ptr", ptr %l8
  %t103 = load ptr, ptr %l54, !tbaa !29
  %t104 = load %"compiler/eval:Ptr", ptr %l58
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t103, %"compiler/eval:Ptr" %t104, %"compiler/eval:Ptr" %t102)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca double
  %rv = alloca double
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a2)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load i32, ptr %l3, !tbaa !23
  %t12 = icmp eq i32 %t10, 11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = and i64 %t14, 65535
  %t18 = trunc i64 %t16 to i16
  %t20 = call i16 asm "", "=r,0"(i16 %t18)
  %t21 = bitcast i16 %t20 to half
  %t23 = fpext half %t21 to double
  store double %t23, ptr %l8, !tbaa !26
  br label %bb18
bb5:
  %t25 = load i32, ptr %l3, !tbaa !23
  %t27 = icmp eq i32 %t25, 12
  br i1 %t27, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = and i64 %t29, 65535
  %t33 = trunc i64 %t31 to i16
  %t35 = bitcast i16 %t33 to bfloat
  %t37 = bitcast bfloat %t35 to i16
  %t38 = zext i16 %t37 to i32
  %t39 = shl i32 %t38, 16
  %t40 = bitcast i32 %t39 to float
  %t41 = fpext float %t40 to double
  store double %t41, ptr %l8, !tbaa !26
  br label %bb18
bb9:
  %t43 = load i32, ptr %l3, !tbaa !23
  %t45 = icmp eq i32 %t43, 13
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t47 = load i64, ptr %l1, !tbaa !24
  %t49 = and i64 %t47, 4294967295
  %t51 = trunc i64 %t49 to i32
  %t53 = bitcast i32 %t51 to float
  %t55 = fpext float %t53 to double
  store double %t55, ptr %l8, !tbaa !26
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t57 = load i64, ptr %l1, !tbaa !24
  %t60 = bitcast i64 %t57 to double
  store double %t60, ptr %l8, !tbaa !26
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_176c1f0c53cca04e_ded73198e701b2e2)
  unreachable
bb18:
  %t62 = load double, ptr %l8, !tbaa !26
  store double %t62, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2etraced(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l37 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l67 = alloca i32
  %l70 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l96 = alloca %"compiler/mir:Fn"
  %l99 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l107 = alloca i64
  %s0 = alloca %olang.scope
  %t189 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 49
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l13, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:frame", ptr %t9, i32 0, i32 16
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 49
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l20, !tbaa !27
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr %"compiler/eval:frame", ptr %t24, i64 %t21
  %t26 = getelementptr %"compiler/eval:frame", ptr %t25, i32 0, i32 17
  %t27 = load i32, ptr %t26, !tbaa !23
  %t28 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t32 = icmp ne i32 %t27, %t29
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr @G_2ecompiler_2feval_2etRaised, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr @G_2ecompiler_2feval_2etCall, !tbaa !24
  %t41 = icmp ne i64 %t37, %t38
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/eval:Machine", ptr %t43, i32 0, i32 75
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t45)
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t47, i32 0, i32 77
  store i64 0, ptr %t49, !tbaa !24
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/eval:Machine", ptr %t50, i32 0, i32 49
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l33, !tbaa !27
  %t54 = load i64, ptr %l1, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr %"compiler/eval:frame", ptr %t57, i64 %t54
  %t59 = getelementptr %"compiler/eval:frame", ptr %t58, i32 0, i32 16
  store i64 -1, ptr %t59, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Machine", ptr %t60, i32 0, i32 75
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l37
  br label %bb11
bb11:
  %t65 = load i64, ptr @G_2ecompiler_2feval_2etraceKept, !tbaa !24
  %t67 = mul i64 4, %t65
  %t68 = load i64, ptr %l37, !tbaa !24
  %t70 = icmp sge i64 %t68, %t67
  br i1 %t70, label %bb12, label %bb13
bb12:
  store i64 0, ptr %l5, !tbaa !24
  store i64 4, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t72 = load i64, ptr %l6, !tbaa !24
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb14, label %bb15
bb13:
  br label %bb30
bb14:
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb19
bb16:
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l7, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l47, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb18
bb18:
  %t98 = load i64, ptr %l47, !tbaa !24
  store i64 %t98, ptr %l44, !tbaa !24
  br label %bb19
bb19:
  %t99 = load i64, ptr %l44, !tbaa !24
  store i64 %t99, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb21, label %bb22
bb21:
  br label %bb29
bb22:
  br label %bb23
bb23:
  %t108 = load i64, ptr %l5, !tbaa !24
  %t109 = load i64, ptr %l9, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l10, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/eval:Machine", ptr %t118, i32 0, i32 75
  %t122 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %t120, i64 0)
  store i32 %t122, ptr %l67
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb25, label %ok.124, !prof !99
ok.124:
  br label %bb24
bb24:
  br label %bb27
bb25:
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t125 = load i64, ptr %l9, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l9, !tbaa !24
  br label %bb20
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l70, !tbaa !29
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = getelementptr %"compiler/eval:Machine", ptr %t130, i32 0, i32 77
  %t132 = load i64, ptr %t131, !tbaa !24
  %t134 = add i64 %t132, 1
  %t136 = load ptr, ptr %l70, !tbaa !29
  %t137 = getelementptr %"compiler/eval:Machine", ptr %t136, i32 0, i32 77
  store i64 %t134, ptr %t137, !tbaa !24
  br label %bb30
bb30:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/eval:Machine", ptr %t138, i32 0, i32 75
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/eval:Machine", ptr %t141, i32 0, i32 17
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %l76, !tbaa !27
  %t147 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr %"compiler/eval:cfn", ptr %t148, i64 %a2
  %t150 = getelementptr %"compiler/eval:cfn", ptr %t149, i32 0, i32 0
  %t151 = load i64, ptr %t150, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t140, i64 %t151)
  br label %bb31
bb31:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/eval:Machine", ptr %t154, i32 0, i32 75
  %t157 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t158 = load i32, ptr %t157, !tbaa !23
  %t160 = sext i32 %t158 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t156, i64 %t160)
  br label %bb32
bb32:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/eval:Machine", ptr %t163, i32 0, i32 75
  %t166 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t165, i64 %t166)
  br label %bb33
bb33:
  %t169 = load i64, ptr %l4, !tbaa !24
  %t170 = load i64, ptr @G_2ecompiler_2feval_2etRaised, !tbaa !24
  %t173 = icmp eq i64 %t169, %t170
  br i1 %t173, label %bb34, label %bb35
bb34:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/eval:Machine", ptr %t175, i32 0, i32 16
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/eval:Machine", ptr %t178, i32 0, i32 49
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l93, !tbaa !27
  %t182 = load i64, ptr %l1, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr %"compiler/eval:frame", ptr %t185, i64 %t182
  %t187 = getelementptr %"compiler/eval:frame", ptr %t186, i32 0, i32 0
  %t188 = load i64, ptr %t187, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t189, ptr %v0, ptr %v0, ptr %t177, i64 %t188)
  call void @llvm.memmove.p0.p0.i64(ptr %l96, ptr %t189, i64 248, i1 false)
  br label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l89, !tbaa !27
  br label %bb38
bb36:
  %t192 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 248, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t192, ptr %l96, i64 248, i1 false)
  %t193 = load %"compiler/source:Span", ptr %l3
  %t196 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %t192, %"compiler/source:Span" %t193)
  store { i64, ptr } %t196, ptr %l99
  br label %bb37
bb37:
  %t197 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t197, ptr %l89, !tbaa !27
  br label %bb38
bb38:
  %t198 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t198, ptr %l11, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t203 = icmp sgt i64 %t201, 0
  br i1 %t203, label %bb39, label %bb40
bb39:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/eval:Machine", ptr %t205, i32 0, i32 75
  store ptr %t207, ptr %l104, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/eval:Machine", ptr %t208, i32 0, i32 76
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t210)
  store i64 %t212, ptr %l107
  br label %bb41
bb40:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/eval:Machine", ptr %t213, i32 0, i32 75
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t215, i64 -1)
  br label %bb44
bb41:
  %t217 = load ptr, ptr %l104, !tbaa !29
  %t218 = load i64, ptr %l107, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t217, i64 %t218)
  br label %bb42
bb42:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/eval:Machine", ptr %t219, i32 0, i32 76
  %t222 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t221, { i64, ptr } %t222)
  br label %bb43
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2etypeid(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i32
  %l9 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l18 = alloca %"compiler/eval:Ptr"
  %l23 = alloca %"compiler/eval:Ptr"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t4, i32 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 32
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t12, i32 %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l14
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb3, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l13
  br label %bb2
bb2:
  %t21 = load i64, ptr %l13, !tbaa !24
  store i64 %t21, ptr %l9, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l9, !tbaa !24
  br label %bb5
bb5:
  %t22 = load i64, ptr %l9, !tbaa !24
  store i64 %t22, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp ne i64 %t23, 0
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s1, i64 %t27, i64 0)
  store %"compiler/eval:Ptr" %t29, ptr %l18
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  %t30 = load %"compiler/eval:Ptr", ptr %l18
  store %"compiler/eval:Ptr" %t30, ptr %rv
  br label %ret
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr @G_2ecompiler_2feval_2eaData, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t33, i32 0, i32 61
  %t36 = load i64, ptr %t35, !tbaa !24
  %t40 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t31, i64 8, i64 %t32, i64 %t36)
  store %"compiler/eval:Ptr" %t40, ptr %l23
  br label %bb10
bb10:
  %t41 = load %"compiler/eval:Ptr", ptr %l23
  store %"compiler/eval:Ptr" %t41, ptr %l4
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 32
  %t45 = load i32, ptr %l2, !tbaa !23
  %t46 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 0
  %t47 = load i64, ptr %t46, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t44, i32 %t45, i64 %t47)
  br label %bb11
bb11:
  %t51 = load %"compiler/eval:Ptr", ptr %l4
  store %"compiler/eval:Ptr" %t51, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eunary(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t7, i32 %t8)
  store i64 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = call i64 @compiler_2feval_2ebmask(i64 %t12)
  store i64 %t13, ptr %l13
  br label %bb3
bb3:
  %t14 = load i64, ptr %l13, !tbaa !24
  store i64 %t14, ptr %l6, !tbaa !24
  %t15 = load i32, ptr %l1
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = xor i64 %t20, 1
  store i64 %t22, ptr %l14, !tbaa !24
  br label %bb20
bb7:
  %t24 = load i32, ptr %l1
  %t26 = trunc i64 1 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = xor i64 %t29, -1
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = and i64 %t31, %t32
  store i64 %t35, ptr %l14, !tbaa !24
  br label %bb20
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t38 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t41 = icmp eq i64 %a4, %t38
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 8, %t44
  %t48 = sub i64 %t46, 1
  store i64 %t48, ptr %l32, !tbaa !24
  %t49 = load i64, ptr %l32, !tbaa !24
  %t50 = load i64, ptr %l32, !tbaa !24
  %t51 = shl i64 1, %t50
  %t54 = xor i64 %t43, %t51
  store i64 %t54, ptr %l34, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l37
  br label %bb17
bb16:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = sub i64 0, %t60
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = and i64 %t62, %t63
  store i64 %t66, ptr %l28, !tbaa !24
  br label %bb18
bb17:
  %t68 = load i64, ptr %l34, !tbaa !24
  %t69 = load i64, ptr %l37, !tbaa !24
  %t70 = and i64 %t68, %t69
  store i64 %t70, ptr %l28, !tbaa !24
  br label %bb18
bb18:
  %t72 = load i64, ptr %l28, !tbaa !24
  store i64 %t72, ptr %l14, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_bb58ffa16789d1e6_53f99027aa0e2dd2)
  unreachable
bb20:
  %t73 = load i64, ptr %l14, !tbaa !24
  store i64 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewait(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/eval:scope"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/eval:scope"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/eval:scope"
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l31 = alloca i1
  %l41 = alloca %"compiler/eval:scope"
  %l49 = alloca %"compiler/eval:task"
  %l54 = alloca %"compiler/eval:scope"
  %l59 = alloca %"compiler/eval:scope"
  %l63 = alloca %"compiler/eval:scope"
  %l70 = alloca %"compiler/eval:scope"
  %l75 = alloca %"compiler/eval:scope"
  %l82 = alloca %"compiler/eval:scope"
  %l88 = alloca %"compiler/eval:scope"
  %l93 = alloca %"compiler/eval:scope"
  %l96 = alloca i1
  %l100 = alloca ptr
  %l104 = alloca %"compiler/eval:Ptr"
  %t51 = alloca %"compiler/eval:scope", align 8
  %t77 = alloca %"compiler/eval:scope", align 8
  %t89 = alloca %"compiler/eval:scope", align 8
  %t94 = alloca %"compiler/eval:scope", align 8
  %t108 = alloca %"compiler/eval:scope", align 8
  %t120 = alloca %"compiler/eval:scope", align 8
  %t131 = alloca %"compiler/eval:scope", align 8
  %t143 = alloca %"compiler/eval:scope", align 8
  %t155 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 51
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l20, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 49
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l22, !tbaa !27
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i64 %t9
  %t14 = getelementptr %"compiler/eval:frame", ptr %t13, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = sext i32 %a2 to i64
  %t21 = add i64 %t15, %t18
  %t23 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i64, ptr %t24, i64 %t21
  %t26 = load i64, ptr %t25, !tbaa !34
  store i64 %t26, ptr %l6, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t28, i64 %t29)
  store i1 %t32, ptr %l31
  br label %bb1
bb1:
  %t33 = load i1, ptr %l31, !tbaa !21
  %t34 = xor i1 %t33, true
  br i1 %t34, label %bb2, label %bb3
bb2:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  %t38 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t38, ptr %t36, { i64, ptr } %t37)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %ret
bb5:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t45 = and i64 %t41, %t42
  store i64 %t45, ptr %l7, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/eval:Machine", ptr %t47, i32 0, i32 43
  %t50 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t51, ptr %v0, ptr %t49, i64 %t50)
  call void @llvm.memmove.p0.p0.i64(ptr %l41, ptr %t51, i64 136, i1 false)
  br label %bb6
bb6:
  %t54 = getelementptr %"compiler/eval:scope", ptr %l41, i32 0, i32 10
  %t55 = load i64, ptr %t54, !tbaa !24
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp sge i64 %t57, 0
  br i1 %t59, label %bb7, label %bb8
bb7:
  %t61 = load i64, ptr %l7, !tbaa !24
  store i64 %t61, ptr %l9, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/eval:Machine", ptr %t63, i32 0, i32 47
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = call %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t65, i64 %t66)
  store %"compiler/eval:task" %t69, ptr %l49
  br label %bb9
bb8:
  br label %bb19
bb9:
  %t70 = getelementptr %"compiler/eval:task", ptr %l49, i32 0, i32 3
  %t71 = load i64, ptr %t70, !tbaa !24
  store i64 %t71, ptr %l10, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/eval:Machine", ptr %t73, i32 0, i32 43
  %t76 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t77, ptr %v0, ptr %t75, i64 %t76)
  call void @llvm.memmove.p0.p0.i64(ptr %l54, ptr %t77, i64 136, i1 false)
  br label %bb10
bb10:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l54, i64 136, i1 false)
  %t80 = load i64, ptr %l10, !tbaa !24
  %t82 = getelementptr %"compiler/eval:scope", ptr %l11, i32 0, i32 10
  store i64 %t80, ptr %t82, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/eval:Machine", ptr %t83, i32 0, i32 43
  %t86 = load i64, ptr %l9, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l59, ptr %l11, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t89, ptr %l59, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t85, i64 %t86, ptr %t89)
  br label %bb11
bb11:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/eval:Machine", ptr %t90, i32 0, i32 43
  %t93 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t94, ptr %v0, ptr %t92, i64 %t93)
  call void @llvm.memmove.p0.p0.i64(ptr %l63, ptr %t94, i64 136, i1 false)
  br label %bb12
bb12:
  %t97 = getelementptr %"compiler/eval:scope", ptr %l63, i32 0, i32 10
  %t98 = load i64, ptr %t97, !tbaa !24
  %t100 = icmp slt i64 %t98, 0
  br i1 %t100, label %bb13, label %bb14
bb13:
  %t102 = load i64, ptr %l7, !tbaa !24
  store i64 %t102, ptr %l12, !tbaa !24
  store i64 -1, ptr %l13, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/eval:Machine", ptr %t104, i32 0, i32 43
  %t107 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t108, ptr %v0, ptr %t106, i64 %t107)
  call void @llvm.memmove.p0.p0.i64(ptr %l70, ptr %t108, i64 136, i1 false)
  br label %bb15
bb14:
  br label %bb17
bb15:
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l70, i64 136, i1 false)
  %t111 = load i64, ptr %l13, !tbaa !24
  %t113 = getelementptr %"compiler/eval:scope", ptr %l14, i32 0, i32 11
  store i64 %t111, ptr %t113, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/eval:Machine", ptr %t114, i32 0, i32 43
  %t117 = load i64, ptr %l12, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l75, ptr %l14, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t120, ptr %l75, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t116, i64 %t117, ptr %t120)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i64, ptr %l1, !tbaa !24
  %t123 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartTask(ptr %v0, ptr %t121, i64 %t122, i64 %t123)
  br label %bb18
bb18:
  br label %ret
bb19:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/eval:Machine", ptr %t127, i32 0, i32 43
  %t130 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t131, ptr %v0, ptr %t129, i64 %t130)
  call void @llvm.memmove.p0.p0.i64(ptr %l82, ptr %t131, i64 136, i1 false)
  br label %bb20
bb20:
  %t134 = getelementptr %"compiler/eval:scope", ptr %l82, i32 0, i32 12
  %t135 = load i64, ptr %t134, !tbaa !24
  store i64 %t135, ptr %l15, !tbaa !24
  %t137 = load i64, ptr %l7, !tbaa !24
  store i64 %t137, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/eval:Machine", ptr %t139, i32 0, i32 43
  %t142 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t143, ptr %v0, ptr %t141, i64 %t142)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %t143, i64 136, i1 false)
  br label %bb21
bb21:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l88, i64 136, i1 false)
  %t146 = load i64, ptr %l17, !tbaa !24
  %t148 = getelementptr %"compiler/eval:scope", ptr %l18, i32 0, i32 12
  store i64 %t146, ptr %t148, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/eval:Machine", ptr %t149, i32 0, i32 43
  %t152 = load i64, ptr %l16, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l93, ptr %l18, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %l93, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t151, i64 %t152, ptr %t155)
  br label %bb22
bb22:
  %t156 = load i64, ptr %l15, !tbaa !24
  %t158 = icmp ne i64 %t156, 0
  br i1 %t158, label %bb23, label %bb24
bb23:
  %t160 = load i32, ptr %l5, !tbaa !23
  %t161 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t164 = icmp ne i32 %t160, %t161
  store i1 %t164, ptr %l96, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb25
bb25:
  %t166 = load i1, ptr %l96, !tbaa !21
  br i1 %t166, label %bb26, label %bb27
bb26:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l100, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i64, ptr %l1, !tbaa !24
  %t174 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t168, i64 %t169, i32 %a4)
  store %"compiler/eval:Ptr" %t174, ptr %l104
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t175 = load i64, ptr %l15, !tbaa !24
  %t176 = load ptr, ptr %l100, !tbaa !29
  %t177 = load %"compiler/eval:Ptr", ptr %l104
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t176, %"compiler/eval:Ptr" %t177, i64 4, i64 %t175)
  br label %bb29
bb29:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l1, !tbaa !24
  %t181 = load i64, ptr @G_2ecompiler_2feval_2etJoin, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efailedHere(ptr %v0, ptr %t179, i64 %t180, i64 %t181)
  br label %bb30
bb30:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i64, ptr %l1, !tbaa !24
  %t187 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %t185, i64 %t186, i32 %t187)
  br label %bb31
bb31:
  br label %ret
bb32:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %t191, i64 %t192, i32 %a3)
  br label %bb33
bb33:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewaitsForTask(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/eval:task"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca { i64, [21 x i64] }
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca i32
  %l31 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l44 = alloca i64
  %l47 = alloca i64
  %l66 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l79 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i64
  %l107 = alloca %"compiler/eval:scope"
  %l109 = alloca i1
  %l113 = alloca %"compiler/eval:scope"
  %l120 = alloca i1
  %l123 = alloca i1
  %l133 = alloca %"compiler/eval:task"
  %l135 = alloca { i64, ptr }
  %l143 = alloca i64
  %l146 = alloca i64
  %l164 = alloca { i64, ptr }
  %l166 = alloca { i64, [21 x i64] }
  %l167 = alloca { i64, [21 x i64] }
  %l176 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t156 = alloca %"compiler/eval:scope", align 8
  %t166 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t3, ptr %l31
  br label %bb1
bb1:
  %t4 = load i1, ptr %l31, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t5 = load i1, ptr %l2, !tbaa !21
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t9, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t11, ptr %l36
  br label %bb4
bb3:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i1, ptr %l36, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l34, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l34, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store i64 -1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 50
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb14
bb11:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l47, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb13
bb13:
  %t48 = load i64, ptr %l47, !tbaa !24
  store i64 %t48, ptr %l44, !tbaa !24
  br label %bb14
bb14:
  %t49 = load i64, ptr %l44, !tbaa !24
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb23
bb17:
  br label %bb18
bb18:
  %t58 = load i64, ptr %l4, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l9, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/eval:Machine", ptr %t68, i32 0, i32 49
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l66, !tbaa !27
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr %"compiler/eval:frame", ptr %t75, i64 %t72
  %t77 = getelementptr %"compiler/eval:frame", ptr %t76, i32 0, i32 7
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = load i64, ptr @G_2ecompiler_2feval_2erTask, !tbaa !24
  %t82 = icmp eq i64 %t78, %t79
  br i1 %t82, label %bb19, label %bb20
bb19:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/eval:Machine", ptr %t84, i32 0, i32 49
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l72, !tbaa !27
  %t88 = load i64, ptr %l9, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr %"compiler/eval:frame", ptr %t91, i64 %t88
  %t93 = getelementptr %"compiler/eval:frame", ptr %t92, i32 0, i32 8
  %t94 = load i64, ptr %t93, !tbaa !24
  store i64 %t94, ptr %l3, !tbaa !24
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t96 = load i64, ptr %l8, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l8, !tbaa !24
  br label %bb15
bb23:
  store i1 false, ptr %l10, !tbaa !21
  store i64 1, ptr %l11, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/eval:Machine", ptr %t100, i32 0, i32 43
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eLen_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t102)
  store i64 %t104, ptr %l79
  br label %bb24
bb24:
  %t105 = load i64, ptr %l79, !tbaa !24
  store i64 %t105, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t106 = load i64, ptr %l12, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t110 = icmp sgt i64 %t106, %t107
  br i1 %t110, label %bb25, label %bb26
bb25:
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = icmp sgt i64 %t112, 0
  br i1 %t114, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb30
bb27:
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l11, !tbaa !24
  %t120 = sub i64 %t116, %t117
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = add i64 %t120, %t121
  %t126 = sub i64 %t124, 1
  %t127 = load i64, ptr %l13, !tbaa !24
  %t130 = sdiv i64 %t126, %t127
  store i64 %t130, ptr %l86, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb29
bb29:
  %t132 = load i64, ptr %l86, !tbaa !24
  store i64 %t132, ptr %l83, !tbaa !24
  br label %bb30
bb30:
  %t133 = load i64, ptr %l83, !tbaa !24
  store i64 %t133, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  %t134 = load i64, ptr %l15, !tbaa !24
  %t135 = load i64, ptr %l14, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb32, label %bb33
bb32:
  br label %bb44
bb33:
  br label %bb34
bb34:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t143 = load i64, ptr %l15, !tbaa !24
  %t144 = load i64, ptr %l13, !tbaa !24
  %t147 = mul i64 %t143, %t144
  %t150 = add i64 %t142, %t147
  store i64 %t150, ptr %l16, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/eval:Machine", ptr %t152, i32 0, i32 43
  %t155 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t156, ptr %v0, ptr %t154, i64 %t155)
  call void @llvm.memmove.p0.p0.i64(ptr %l107, ptr %t156, i64 136, i1 false)
  br label %bb35
bb35:
  %t159 = getelementptr %"compiler/eval:scope", ptr %l107, i32 0, i32 1
  %t160 = load i1, ptr %t159, !tbaa !21
  br i1 %t160, label %bb36, label %bb37
bb36:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/eval:Machine", ptr %t162, i32 0, i32 43
  %t165 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t166, ptr %v0, ptr %t164, i64 %t165)
  call void @llvm.memmove.p0.p0.i64(ptr %l113, ptr %t166, i64 136, i1 false)
  br label %bb38
bb37:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb39
bb38:
  %t169 = getelementptr %"compiler/eval:scope", ptr %l113, i32 0, i32 10
  %t170 = load i64, ptr %t169, !tbaa !24
  %t172 = icmp sge i64 %t170, 0
  store i1 %t172, ptr %l109, !tbaa !21
  br label %bb39
bb39:
  %t174 = load i1, ptr %l109, !tbaa !21
  br i1 %t174, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t175 = load i64, ptr %l15, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l15, !tbaa !24
  br label %bb31
bb44:
  %t179 = load i1, ptr %l2, !tbaa !21
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb45, label %bb46
bb45:
  %t183 = load i1, ptr %l10, !tbaa !21
  %t185 = xor i1 %t183, true
  store i1 %t185, ptr %l120, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb47
bb47:
  %t187 = load i1, ptr %l120, !tbaa !21
  br i1 %t187, label %bb48, label %bb49
bb48:
  %t188 = load i64, ptr %l3, !tbaa !24
  %t190 = icmp slt i64 %t188, 0
  store i1 %t190, ptr %l123, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb50
bb50:
  %t192 = load i1, ptr %l123, !tbaa !21
  br i1 %t192, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/eval:Machine", ptr %t194, i32 0, i32 79
  store i64 -1, ptr %t196, !tbaa !24
  %t197 = load i64, ptr %l3, !tbaa !24
  %t199 = icmp sge i64 %t197, 0
  br i1 %t199, label %bb54, label %bb55
bb54:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/eval:Machine", ptr %t201, i32 0, i32 47
  %t204 = load i64, ptr %l3, !tbaa !24
  %t207 = call %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t203, i64 %t204)
  store %"compiler/eval:task" %t207, ptr %l133
  br label %bb56
bb55:
  br label %bb81
bb56:
  %t208 = load %"compiler/eval:task", ptr %l133
  store %"compiler/eval:task" %t208, ptr %l17
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/eval:Machine", ptr %t209, i32 0, i32 17
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l135, !tbaa !27
  %t213 = getelementptr %"compiler/eval:task", ptr %l17, i32 0, i32 0
  %t214 = load i64, ptr %t213, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr %"compiler/eval:cfn", ptr %t217, i64 %t214
  %t219 = getelementptr %"compiler/eval:cfn", ptr %t218, i32 0, i32 7
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  store { i64, ptr } %t220, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t222 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t222, 0
  store i64 %t224, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t226 = load i64, ptr %l20, !tbaa !24
  %t227 = load i64, ptr %l19, !tbaa !24
  %t230 = icmp sgt i64 %t226, %t227
  br i1 %t230, label %bb57, label %bb58
bb57:
  %t232 = load i64, ptr %l21, !tbaa !24
  %t234 = icmp sgt i64 %t232, 0
  br i1 %t234, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb62
bb59:
  %t236 = load i64, ptr %l20, !tbaa !24
  %t237 = load i64, ptr %l19, !tbaa !24
  %t240 = sub i64 %t236, %t237
  %t241 = load i64, ptr %l21, !tbaa !24
  %t244 = add i64 %t240, %t241
  %t246 = sub i64 %t244, 1
  %t247 = load i64, ptr %l21, !tbaa !24
  %t250 = sdiv i64 %t246, %t247
  store i64 %t250, ptr %l146, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb61
bb61:
  %t252 = load i64, ptr %l146, !tbaa !24
  store i64 %t252, ptr %l143, !tbaa !24
  br label %bb62
bb62:
  %t253 = load i64, ptr %l143, !tbaa !24
  store i64 %t253, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb63
bb63:
  %t254 = load i64, ptr %l23, !tbaa !24
  %t255 = load i64, ptr %l22, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb64, label %bb65
bb64:
  br label %bb80
bb65:
  br label %bb66
bb66:
  %t262 = load i64, ptr %l19, !tbaa !24
  %t263 = load i64, ptr %l23, !tbaa !24
  %t264 = load i64, ptr %l21, !tbaa !24
  %t267 = mul i64 %t263, %t264
  %t270 = add i64 %t262, %t267
  %t272 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t272, ptr %l164, !tbaa !27
  %t275 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr { i64, [21 x i64] }, ptr %t276, i64 %t270
  call void @llvm.memmove.p0.p0.i64(ptr %l166, ptr %t277, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %l166, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l167, ptr %l25, i64 176, i1 false)
  %t278 = load { i64, [21 x i64] }, ptr %l167
  %t279 = extractvalue { i64, [21 x i64] } %t278, 0
  %t280 = icmp eq i64 %t279, 11
  br i1 %t280, label %bb67, label %bb68
bb67:
  %t282 = getelementptr { i64, [21 x i64] }, ptr %l25, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t282, i32 0, i32 0
  %t284 = load %"compiler/source:Span", ptr %t283
  store %"compiler/source:Span" %t284, ptr %l26
  %t286 = getelementptr { i64, [21 x i64] }, ptr %l25, i32 0, i32 1
  %t287 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t286, i32 0, i32 2
  %t288 = load i32, ptr %t287
  store i32 %t288, ptr %l27, !tbaa !23
  br label %bb69
bb68:
  br label %bb73
bb69:
  %t290 = load i32, ptr %l27, !tbaa !23
  %t292 = sext i32 %t290 to i64
  %t293 = getelementptr %"compiler/eval:task", ptr %l17, i32 0, i32 1
  %t294 = load i64, ptr %t293, !tbaa !24
  %t297 = icmp eq i64 %t292, %t294
  br i1 %t297, label %bb70, label %bb71
bb70:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/eval:Machine", ptr %t299, i32 0, i32 17
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  store { i64, ptr } %t302, ptr %l176, !tbaa !27
  %t303 = getelementptr %"compiler/eval:task", ptr %l17, i32 0, i32 0
  %t304 = load i64, ptr %t303, !tbaa !24
  %t306 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr %"compiler/eval:cfn", ptr %t307, i64 %t304
  %t309 = getelementptr %"compiler/eval:cfn", ptr %t308, i32 0, i32 0
  %t310 = load i64, ptr %t309, !tbaa !24
  %t312 = load %"compiler/source:Span", ptr %l26
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/eval:Machine", ptr %t314, i32 0, i32 79
  store i64 %t310, ptr %t318, !tbaa !24
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/eval:Machine", ptr %t319, i32 0, i32 80
  store %"compiler/source:Span" %t312, ptr %t323
  br label %bb72
bb71:
  br label %bb72
bb72:
  br label %bb78
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_20ebca0cc3ca1941_2aa025308f8b0e8d)
  unreachable
bb78:
  br label %bb79
bb79:
  %t324 = load i64, ptr %l23, !tbaa !24
  %t326 = add i64 %t324, 1
  store i64 %t326, ptr %l23, !tbaa !24
  br label %bb63
bb80:
  br label %bb81
bb81:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWaits, !tbaa !27
  %t330 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t330, ptr %t328, { i64, ptr } %t329)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i64
  %l23 = alloca { i64, i64 }
  %l24 = alloca ptr
  %l28 = alloca %"compiler/eval:Ptr"
  %l30 = alloca { i64, i64 }
  %l31 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load { i64, [4 x i64] }, ptr %l2
  %t7 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t1, i64 %t2, { i64, [4 x i64] } %t3)
  store i32 %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load i32, ptr %l10, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t9, i32 %t10)
  store i64 %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t15 = load i64, ptr %l13, !tbaa !24
  %t17 = icmp eq i64 %t15, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load { i64, [4 x i64] }, ptr %l2
  %t21 = extractvalue { i64, [4 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 2
  br i1 %t22, label %bb5, label %bb6
bb4:
  br label %bb16
bb5:
  %t24 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t25 = getelementptr { i32, i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  %t28 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t29 = getelementptr { i32, i64 }, ptr %t28, i32 0, i32 1
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l5, !tbaa !24
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l4, !tbaa !23
  %t34 = load i64, ptr %l5, !tbaa !24
  %t38 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideConst(ptr %v0, ptr %t32, i32 %t33, i64 %t34)
  store { i64, i64 } %t38, ptr %l23
  br label %bb8
bb8:
  %t39 = load { i64, i64 }, ptr %l23
  store { i64, i64 } %t39, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l24, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t43 = load { i64, [4 x i64] }, ptr %l2
  %t47 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t41, i64 %t42, { i64, [4 x i64] } %t43, i64 1)
  store %"compiler/eval:Ptr" %t47, ptr %l28
  br label %bb13
bb13:
  %t48 = load i32, ptr %l3, !tbaa !23
  %t49 = load ptr, ptr %l24, !tbaa !29
  %t50 = load %"compiler/eval:Ptr", ptr %l28
  %t52 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2erdWide(ptr %v0, ptr %t49, %"compiler/eval:Ptr" %t50, i32 %t48)
  store { i64, i64 } %t52, ptr %l30
  br label %bb14
bb14:
  %t53 = load { i64, i64 }, ptr %l30
  store { i64, i64 } %t53, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2742cef73dca1807_235d65ef4c242d83)
  unreachable
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load { i64, [4 x i64] }, ptr %l2
  %t61 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t55, i64 %t56, { i64, [4 x i64] } %t57)
  store i64 %t61, ptr %l35
  br label %bb17
bb17:
  %t62 = load i32, ptr %l3, !tbaa !23
  %t63 = load ptr, ptr %l31, !tbaa !29
  %t64 = load i64, ptr %l35, !tbaa !24
  %t66 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t63, i64 %t64, i32 %t62)
  store i64 %t66, ptr %l37
  br label %bb18
bb18:
  %t67 = load i64, ptr %l37, !tbaa !24
  store i64 %t67, ptr %l6, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t72, ptr %l40
  br label %bb19
bb19:
  %t73 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t74 = load i64, ptr %l40, !tbaa !24
  %t76 = icmp eq i64 %t74, %t73
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = and i64 %t78, 1
  %t82 = insertvalue { i64, i64 } undef, i64 %t80, 0
  %t83 = insertvalue { i64, i64 } %t82, i64 0, 1
  store { i64, i64 } %t83, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t85 = load i64, ptr %l6, !tbaa !24
  store i64 %t85, ptr %l46, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t86, i32 %t87)
  store i64 %t90, ptr %l49
  br label %bb23
bb23:
  %t91 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t92 = load i64, ptr %l49, !tbaa !24
  %t94 = icmp eq i64 %t92, %t91
  br i1 %t94, label %bb24, label %bb25
bb24:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb26
bb25:
  %t96 = load i64, ptr %l6, !tbaa !24
  %t98 = ashr i64 %t96, 63
  store i64 %t98, ptr %l52, !tbaa !24
  br label %bb26
bb26:
  %t100 = load i64, ptr %l46, !tbaa !24
  %t101 = insertvalue { i64, i64 } undef, i64 %t100, 0
  %t102 = load i64, ptr %l52, !tbaa !24
  %t103 = insertvalue { i64, i64 } %t101, i64 %t102, 1
  store { i64, i64 } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOp(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l12 = alloca i64
  %l20 = alloca i32
  %l23 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %l49 = alloca { i64, [4 x i64] }
  %l50 = alloca i32
  %l51 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %a2)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t7 = load i64, ptr %l12, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i32 0, ptr %l4, !tbaa !23
  %t12 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  store i32 %t13, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t15 = load i32, ptr %l5, !tbaa !23
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = icmp sgt i32 %t15, %t16
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i32, ptr %l6, !tbaa !23
  %t23 = icmp sgt i32 %t21, 0
  br i1 %t23, label %bb7, label %bb8
bb6:
  store i32 0, ptr %l20, !tbaa !23
  br label %bb10
bb7:
  %t25 = load i32, ptr %l5, !tbaa !23
  %t26 = load i32, ptr %l4, !tbaa !23
  %t29 = sub i32 %t25, %t26
  %t30 = load i32, ptr %l6, !tbaa !23
  %t33 = add i32 %t29, %t30
  %t35 = sub i32 %t33, 1
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = sdiv i32 %t35, %t36
  store i32 %t39, ptr %l23, !tbaa !23
  br label %bb9
bb8:
  store i32 0, ptr %l23, !tbaa !23
  br label %bb9
bb9:
  %t41 = load i32, ptr %l23, !tbaa !23
  store i32 %t41, ptr %l20, !tbaa !23
  br label %bb10
bb10:
  %t42 = load i32, ptr %l20, !tbaa !23
  store i32 %t42, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb11
bb11:
  %t43 = load i32, ptr %l8, !tbaa !23
  %t44 = load i32, ptr %l7, !tbaa !23
  %t47 = icmp slt i32 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb12, label %bb13
bb12:
  br label %bb22
bb13:
  br label %bb14
bb14:
  %t51 = load i32, ptr %l4, !tbaa !23
  %t52 = load i32, ptr %l8, !tbaa !23
  %t53 = load i32, ptr %l6, !tbaa !23
  %t56 = mul i32 %t52, %t53
  %t59 = add i32 %t51, %t56
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l41, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l42, !tbaa !29
  %t63 = load i64, ptr %l1, !tbaa !24
  store i64 %t63, ptr %l43, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l1, !tbaa !24
  %t66 = load %"compiler/mir:Range", ptr %l3
  %t69 = sext i32 %t59 to i64
  %t74 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t64, i64 %t65, %"compiler/mir:Range" %t66, i64 %t69)
  store { i64, [4 x i64] } %t74, ptr %l49
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = load i64, ptr %l43, !tbaa !24
  %t77 = load { i64, [4 x i64] }, ptr %l49
  %t78 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t75, i64 %t76, { i64, [4 x i64] } %t77)
  store i32 %t78, ptr %l50
  br label %bb16
bb16:
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = load i32, ptr %l50, !tbaa !23
  %t81 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t79, i32 %t80)
  store i64 %t81, ptr %l51
  br label %bb17
bb17:
  %t82 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t83 = load i64, ptr %l51, !tbaa !24
  %t85 = icmp eq i64 %t83, %t82
  br i1 %t85, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t88 = load i32, ptr %l8, !tbaa !23
  %t90 = add i32 %t88, 1
  store i32 %t90, ptr %l8, !tbaa !23
  br label %bb11
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca i64
  %l6 = alloca i64
  %l22 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i64 8, i1 true)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunmark(ptr %v0, ptr %t11, i64 %t12, i64 8)
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t15, i64 %t16, i64 8, i64 %t18)
  br label %bb6
bb6:
  %t22 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  %t25 = icmp ne i64 %t23, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = srem i64 %t27, 8
  %t31 = icmp ne i64 %t29, 0
  br i1 %t31, label %bb9, label %bb10
bb8:
  br label %bb13
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t35 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t35, ptr %t33, { i64, ptr } %t34)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %ret
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 37
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l22, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = sdiv i64 %t42, 8
  %t45 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t46 = load i64, ptr %t45, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i64, ptr %t50, i64 %t44
  store i64 %t46, ptr %t51, !tbaa !34
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrWide(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l5 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca i64
  %l20 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t1, i32 %a2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/eval:Ptr", ptr %l1
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t7, %"compiler/eval:Ptr" %t8, i64 8, i64 %a3)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l12, !tbaa !29
  %t14 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = add i64 %t17, 8
  %t22 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t15, i64 %t19)
  store %"compiler/eval:Ptr" %t22, ptr %l16
  br label %bb3
bb3:
  store i64 %a4, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t24, 64
  %t28 = call i64 @compiler_2feval_2ebmask(i64 %t26)
  store i64 %t28, ptr %l20
  br label %bb4
bb4:
  %t29 = load i64, ptr %l17, !tbaa !24
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = and i64 %t29, %t30
  %t32 = load ptr, ptr %l12, !tbaa !29
  %t33 = load %"compiler/eval:Ptr", ptr %l16
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t32, %"compiler/eval:Ptr" %t33, i64 8, i64 %t31)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewritesAfter(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca %"compiler/mir:Fn"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, [21 x i64] }
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, [21 x i64] }
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca %"compiler/mir:Lvalue"
  %l19 = alloca { i64, [2 x i64] }
  %l20 = alloca i64
  %l21 = alloca i32
  %l25 = alloca { i64, ptr }
  %l28 = alloca %"compiler/mir:Fn"
  %l31 = alloca { i64, ptr }
  %l34 = alloca %"compiler/mir:BasicBlock"
  %l37 = alloca { i64, ptr }
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca { i64, [21 x i64] }
  %l48 = alloca { i64, [21 x i64] }
  %l56 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l83 = alloca { i64, [21 x i64] }
  %l84 = alloca { i64, [21 x i64] }
  %l100 = alloca i1
  %rv = alloca i1
  %t15 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 16
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 49
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l25, !tbaa !27
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:frame", ptr %t11, i64 %t8
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t15, ptr %v0, ptr %v0, ptr %t3, i64 %t14)
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %t15, i64 248, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l28, i64 248, i1 false)
  %t18 = getelementptr %"compiler/mir:Fn", ptr %l4, i32 0, i32 9
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 49
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l31, !tbaa !27
  %t23 = load i64, ptr %l1, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr %"compiler/eval:frame", ptr %t26, i64 %t23
  %t28 = getelementptr %"compiler/eval:frame", ptr %t27, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t18, i64 %t29)
  store %"compiler/mir:BasicBlock" %t32, ptr %l34
  br label %bb2
bb2:
  %t33 = getelementptr %"compiler/mir:BasicBlock", ptr %l34, i32 0, i32 0
  %t34 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t33
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l5
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/eval:Machine", ptr %t36, i32 0, i32 49
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l37, !tbaa !27
  %t40 = load i64, ptr %l1, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/eval:frame", ptr %t43, i64 %t40
  %t45 = getelementptr %"compiler/eval:frame", ptr %t44, i32 0, i32 2
  %t46 = load i64, ptr %t45, !tbaa !24
  store i64 %t46, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  store i64 %t48, ptr %l40, !tbaa !24
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %l5)
  store i64 %t50, ptr %l42
  br label %bb3
bb3:
  %t51 = load i64, ptr %l40, !tbaa !24
  %t52 = load i64, ptr %l42, !tbaa !24
  %t53 = icmp sge i64 %t51, %t52
  br i1 %t53, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  store i32 -1, ptr %l7, !tbaa !23
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %l5, i64 %t56)
  store { i64, [21 x i64] } %t59, ptr %l47
  br label %bb7
bb7:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l47, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %l8, i64 176, i1 false)
  %t60 = load { i64, [21 x i64] }, ptr %l48
  %t61 = extractvalue { i64, [21 x i64] } %t60, 0
  %t62 = icmp eq i64 %t61, 0
  br i1 %t62, label %bb8, label %bb9
bb8:
  %t64 = getelementptr { i64, [21 x i64] }, ptr %l8, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t64, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  store %"compiler/source:Span" %t66, ptr %l9
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t68 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  store i32 %t69, ptr %l7, !tbaa !23
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4d14e07bfe4410cd_6dafb030c3a12d39)
  unreachable
bb16:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l10, !tbaa !24
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %l5)
  store i64 %t77, ptr %l56
  br label %bb17
bb17:
  %t78 = load i64, ptr %l56, !tbaa !24
  store i64 %t78, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t79 = load i64, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = icmp sgt i64 %t79, %t80
  br i1 %t83, label %bb18, label %bb19
bb18:
  %t85 = load i64, ptr %l12, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb23
bb20:
  %t89 = load i64, ptr %l11, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = sub i64 %t89, %t90
  %t94 = load i64, ptr %l12, !tbaa !24
  %t97 = add i64 %t93, %t94
  %t99 = sub i64 %t97, 1
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = sdiv i64 %t99, %t100
  store i64 %t103, ptr %l63, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb22
bb22:
  %t105 = load i64, ptr %l63, !tbaa !24
  store i64 %t105, ptr %l60, !tbaa !24
  br label %bb23
bb23:
  %t106 = load i64, ptr %l60, !tbaa !24
  store i64 %t106, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb24
bb24:
  %t107 = load i64, ptr %l14, !tbaa !24
  %t108 = load i64, ptr %l13, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb25, label %bb26
bb25:
  br label %bb57
bb26:
  br label %bb27
bb27:
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = mul i64 %t116, %t117
  %t123 = add i64 %t115, %t120
  %t128 = call { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %l5, i64 %t123)
  store { i64, [21 x i64] } %t128, ptr %l83
  br label %bb28
bb28:
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %l83, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l84, ptr %l16, i64 176, i1 false)
  %t129 = load { i64, [21 x i64] }, ptr %l84
  %t130 = extractvalue { i64, [21 x i64] } %t129, 0
  %t131 = icmp eq i64 %t130, 0
  br i1 %t131, label %bb29, label %bb30
bb29:
  %t133 = getelementptr { i64, [21 x i64] }, ptr %l16, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t133, i32 0, i32 0
  %t135 = load %"compiler/source:Span", ptr %t134
  store %"compiler/source:Span" %t135, ptr %l17
  %t137 = getelementptr { i64, [21 x i64] }, ptr %l16, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t137, i32 0, i32 1
  %t139 = load %"compiler/mir:Lvalue", ptr %t138
  store %"compiler/mir:Lvalue" %t139, ptr %l18
  br label %bb31
bb30:
  br label %bb50
bb31:
  %t141 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t142 = load i32, ptr %t141, !tbaa !23
  %t143 = load i32, ptr %l7, !tbaa !23
  %t146 = icmp ne i32 %t142, %t143
  br i1 %t146, label %bb32, label %bb33
bb32:
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t149 = getelementptr %"compiler/mir:Lvalue", ptr %l18, i32 0, i32 0
  %t150 = load { i64, [2 x i64] }, ptr %t149
  store { i64, [2 x i64] } %t150, ptr %l19
  %t152 = load { i64, [2 x i64] }, ptr %l19
  %t154 = extractvalue { i64, [2 x i64] } %t152, 0
  %t155 = icmp eq i64 %t154, 2
  br i1 %t155, label %bb35, label %bb36
bb35:
  %t157 = getelementptr { i64, [2 x i64] }, ptr %l19, i32 0, i32 1
  %t158 = getelementptr { i64, i32, i32 }, ptr %t157, i32 0, i32 0
  %t159 = load i64, ptr %t158
  store i64 %t159, ptr %l20, !tbaa !24
  %t161 = getelementptr { i64, [2 x i64] }, ptr %l19, i32 0, i32 1
  %t162 = getelementptr { i64, i32, i32 }, ptr %t161, i32 0, i32 1
  %t163 = load i32, ptr %t162
  store i32 %t163, ptr %l21, !tbaa !23
  br label %bb37
bb36:
  br label %bb44
bb37:
  %t165 = load i64, ptr %l20, !tbaa !24
  %t169 = icmp eq i64 %t165, %a2
  br i1 %t169, label %bb38, label %bb39
bb38:
  %t171 = load i32, ptr %l21, !tbaa !23
  %t175 = icmp eq i32 %t171, %a3
  store i1 %t175, ptr %l100, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb40
bb40:
  %t177 = load i1, ptr %l100, !tbaa !21
  br i1 %t177, label %bb41, label %bb42
bb41:
  store i1 true, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_9c829c68892d289c_3e4192d6cd213d68)
  unreachable
bb49:
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i1 false, ptr %rv
  br label %ret
bb54:
  call void @__olang_check_failed(ptr @olang_loc_ddb187b0a77b9dd7_fe6fb794d8e15443)
  unreachable
bb55:
  br label %bb56
bb56:
  %t180 = load i64, ptr %l14, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l14, !tbaa !24
  br label %bb24
bb57:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ezero(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l10 = alloca i64
  %l19 = alloca i1
  %l38 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i64, ptr %l2, !tbaa !24
  %t11 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t5, %"compiler/eval:Ptr" %a1, i64 %t7, i1 true)
  store i64 %t11, ptr %l10
  br label %bb4
bb4:
  %t12 = load i64, ptr %l10, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunmark(ptr %v0, ptr %t17, i64 %t18, i64 %t19)
  br label %bb8
bb8:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb9
bb9:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  br i1 %t27, label %bb10, label %bb11
bb10:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = srem i64 %t33, 8
  %t37 = icmp ne i64 %t35, 0
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l19, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t43, %t44
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t42, i64 %t47, i64 1, i64 0)
  br label %bb16
bb16:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l4, !tbaa !24
  br label %bb17
bb17:
  br label %bb9
bb18:
  br label %bb19
bb19:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t56 = add i64 %t54, 8
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = icmp sle i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 36
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l38, !tbaa !27
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = sdiv i64 %t72, 8
  %t76 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i64, ptr %t77, i64 %t74
  store i64 0, ptr %t78, !tbaa !34
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = add i64 %t79, 8
  store i64 %t81, ptr %l4, !tbaa !24
  br label %bb23
bb23:
  br label %bb19
bb24:
  %t83 = load i64, ptr %l4, !tbaa !24
  %t84 = load i64, ptr %l2, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  br i1 %t87, label %bb25, label %bb26
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l3, !tbaa !24
  %t91 = load i64, ptr %l4, !tbaa !24
  %t94 = add i64 %t90, %t91
  %t95 = load i64, ptr %l2, !tbaa !24
  %t96 = load i64, ptr %l4, !tbaa !24
  %t99 = sub i64 %t95, %t96
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %t89, i64 %t94, i64 %t99, i64 0)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2feval_2eextend128(i64 %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i1
  %l24 = alloca i64
  %l28 = alloca i64
  %l30 = alloca i64
  %l36 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i1
  %l44 = alloca i64
  %l48 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i64
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t1, 128
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = insertvalue { i64, i64 } undef, i64 %t5, 0
  %t10 = insertvalue { i64, i64 } %t8, i64 %t6, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t12, 64
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = sub i64 %t16, 64
  store i64 %t18, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l1, !tbaa !24
  store i64 %t20, ptr %l16, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = call i64 @compiler_2feval_2ebmask(i64 %t21)
  store i64 %t23, ptr %l18
  br label %bb6
bb5:
  br label %bb14
bb6:
  %t24 = load i64, ptr %l16, !tbaa !24
  %t25 = load i64, ptr %l18, !tbaa !24
  %t26 = and i64 %t24, %t25
  store i64 %t26, ptr %l5, !tbaa !24
  %t28 = load i1, ptr %l3, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = sub i64 %t31, 1
  store i64 %t33, ptr %l24, !tbaa !24
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = load i64, ptr %l24, !tbaa !24
  %t37 = ashr i64 %t30, %t36
  %t39 = and i64 %t37, 1
  %t41 = icmp eq i64 %t39, 1
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l21, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load i64, ptr %l5, !tbaa !24
  store i64 %t44, ptr %l28, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = call i64 @compiler_2feval_2ebmask(i64 %t45)
  store i64 %t47, ptr %l30
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t48 = load i64, ptr %l30, !tbaa !24
  %t49 = xor i64 %t48, -1
  %t50 = load i64, ptr %l28, !tbaa !24
  %t52 = or i64 %t50, %t49
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb13
bb13:
  %t54 = load i64, ptr %l0, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = insertvalue { i64, i64 } undef, i64 %t54, 0
  %t59 = insertvalue { i64, i64 } %t57, i64 %t55, 1
  store { i64, i64 } %t59, ptr %rv
  br label %ret
bb14:
  %t61 = load i64, ptr %l0, !tbaa !24
  store i64 %t61, ptr %l36, !tbaa !24
  %t62 = load i64, ptr %l2, !tbaa !24
  %t64 = call i64 @compiler_2feval_2ebmask(i64 %t62)
  store i64 %t64, ptr %l38
  br label %bb15
bb15:
  %t65 = load i64, ptr %l36, !tbaa !24
  %t66 = load i64, ptr %l38, !tbaa !24
  %t67 = and i64 %t65, %t66
  store i64 %t67, ptr %l6, !tbaa !24
  %t69 = load i1, ptr %l3, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t71 = load i64, ptr %l6, !tbaa !24
  %t72 = load i64, ptr %l2, !tbaa !24
  %t74 = sub i64 %t72, 1
  store i64 %t74, ptr %l44, !tbaa !24
  %t76 = load i64, ptr %l44, !tbaa !24
  %t77 = load i64, ptr %l44, !tbaa !24
  %t78 = ashr i64 %t71, %t77
  %t80 = and i64 %t78, 1
  %t82 = icmp eq i64 %t80, 1
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb18
bb18:
  %t84 = load i1, ptr %l41, !tbaa !21
  br i1 %t84, label %bb19, label %bb20
bb19:
  %t85 = load i64, ptr %l6, !tbaa !24
  store i64 %t85, ptr %l48, !tbaa !24
  %t86 = load i64, ptr %l2, !tbaa !24
  %t88 = call i64 @compiler_2feval_2ebmask(i64 %t86)
  store i64 %t88, ptr %l50
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t89 = load i64, ptr %l50, !tbaa !24
  %t90 = xor i64 %t89, -1
  %t91 = load i64, ptr %l48, !tbaa !24
  %t93 = or i64 %t91, %t90
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb22
bb22:
  %t95 = load i64, ptr %l6, !tbaa !24
  store i64 %t95, ptr %l53, !tbaa !24
  %t96 = load i1, ptr %l3, !tbaa !21
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb23, label %bb24
bb23:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb25
bb24:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = ashr i64 %t100, 63
  store i64 %t102, ptr %l56, !tbaa !24
  br label %bb25
bb25:
  %t104 = load i64, ptr %l53, !tbaa !24
  %t105 = insertvalue { i64, i64 } undef, i64 %t104, 0
  %t106 = load i64, ptr %l56, !tbaa !24
  %t107 = insertvalue { i64, i64 } %t105, i64 %t106, 1
  store { i64, i64 } %t107, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local void @compiler_2feval_2efLoad_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2feval_2efLoad, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2efStore_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 6, ptr @G_2ecompiler_2feval_2efStore, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2eflatOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb39
bb2:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 1 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb39
bb4:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 2 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb39
bb6:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 3 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb39
bb8:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 4 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  br label %bb39
bb10:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 5 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb11, label %bb12
bb11:
  br label %bb39
bb12:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 6 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb13, label %bb14
bb13:
  br label %bb39
bb14:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 7 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb15, label %bb16
bb15:
  br label %bb39
bb16:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 8 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb17, label %bb18
bb17:
  br label %bb39
bb18:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 9 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb19, label %bb20
bb19:
  br label %bb39
bb20:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 10 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb21, label %bb22
bb21:
  br label %bb39
bb22:
  %t56 = load i32, ptr %l0
  %t58 = trunc i64 11 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb23, label %bb24
bb23:
  br label %bb39
bb24:
  %t61 = load i32, ptr %l0
  %t63 = trunc i64 12 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb25, label %bb26
bb25:
  br label %bb39
bb26:
  %t66 = load i32, ptr %l0
  %t68 = trunc i64 13 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb27, label %bb28
bb27:
  br label %bb39
bb28:
  %t71 = load i32, ptr %l0
  %t73 = trunc i64 14 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb29, label %bb30
bb29:
  br label %bb39
bb30:
  %t76 = load i32, ptr %l0
  %t78 = trunc i64 15 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb31, label %bb32
bb31:
  br label %bb39
bb32:
  %t81 = load i32, ptr %l0
  %t83 = trunc i64 16 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb33, label %bb34
bb33:
  br label %bb39
bb34:
  %t86 = load i32, ptr %l0
  %t88 = trunc i64 17 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb35, label %bb36
bb35:
  br label %bb39
bb36:
  %t91 = load i32, ptr %l0
  %t93 = trunc i64 18 to i32
  %t94 = icmp eq i32 %t91, %t93
  br i1 %t94, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_67473c0be830e037_6373d6aa11f96063)
  unreachable
bb45:
  %t96 = load i1, ptr %l1, !tbaa !21
  store i1 %t96, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feval_2efloatFits(double %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca double
  %l1 = alloca i64
  %l3 = alloca double
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l48 = alloca i1
  %l55 = alloca i1
  %l65 = alloca i1
  %rv = alloca i1
  store double %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff0000000000000, ptr %l3, !tbaa !26
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = sub i64 %t1, 1
  store i64 %t3, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l18, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l15, !tbaa !24
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l9, !tbaa !24
  %t51 = load double, ptr %l3, !tbaa !26
  %t53 = fmul double %t51, 0x4000000000000000
  store double %t53, ptr %l3, !tbaa !26
  br label %bb11
bb11:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  %t59 = load double, ptr %l0, !tbaa !26
  %t60 = load double, ptr %l0, !tbaa !26
  %t63 = fcmp une double %t59, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t68 = xor i1 %a2, true
  br i1 %t68, label %bb16, label %bb17
bb16:
  %t70 = load double, ptr %l0, !tbaa !26
  %t72 = fcmp ogt double %t70, 0xbff0000000000000
  br i1 %t72, label %bb18, label %bb19
bb17:
  br label %bb21
bb18:
  %t74 = load double, ptr %l0, !tbaa !26
  %t75 = load double, ptr %l3, !tbaa !26
  %t77 = fmul double 0x4000000000000000, %t75
  %t80 = fcmp olt double %t74, %t77
  store i1 %t80, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t82 = load i1, ptr %l48, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
bb21:
  %t83 = load i64, ptr %l1, !tbaa !24
  %t85 = icmp sgt i64 %t83, 53
  br i1 %t85, label %bb22, label %bb23
bb22:
  %t87 = load double, ptr %l0, !tbaa !26
  %t88 = load double, ptr %l3, !tbaa !26
  %t90 = fneg double %t88
  %t93 = fcmp oge double %t87, %t90
  store i1 %t93, ptr %l55, !tbaa !21
  br label %bb24
bb23:
  %t95 = load double, ptr %l0, !tbaa !26
  %t96 = load double, ptr %l3, !tbaa !26
  %t98 = fneg double %t96
  %t100 = fsub double %t98, 0x3ff0000000000000
  %t103 = fcmp ogt double %t95, %t100
  store i1 %t103, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t105 = load i1, ptr %l55, !tbaa !21
  br i1 %t105, label %bb25, label %bb26
bb25:
  %t106 = load double, ptr %l0, !tbaa !26
  %t107 = load double, ptr %l3, !tbaa !26
  %t110 = fcmp olt double %t106, %t107
  store i1 %t110, ptr %l65, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb27
bb27:
  %t112 = load i1, ptr %l65, !tbaa !21
  store i1 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2egDtor_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2feval_2egDtor, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2elz128(i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l50 = alloca i64
  %rv = alloca i64
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l19, !tbaa !24
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb18
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = sub i64 %t49, 1
  %t55 = sub i64 %t51, %t47
  store i64 %t55, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = icmp sge i64 %t57, 64
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t62 = load i64, ptr %l10, !tbaa !24
  %t64 = sub i64 %t62, 64
  store i64 %t64, ptr %l46, !tbaa !24
  %t66 = load i64, ptr %l46, !tbaa !24
  %t67 = load i64, ptr %l46, !tbaa !24
  %t68 = ashr i64 %a1, %t67
  %t70 = and i64 %t68, 1
  store i64 %t70, ptr %l43, !tbaa !24
  br label %bb13
bb12:
  %t73 = load i64, ptr %l10, !tbaa !24
  store i64 %t73, ptr %l50, !tbaa !24
  %t75 = load i64, ptr %l50, !tbaa !24
  %t76 = load i64, ptr %l50, !tbaa !24
  %t77 = ashr i64 %a0, %t76
  %t79 = and i64 %t77, 1
  store i64 %t79, ptr %l43, !tbaa !24
  br label %bb13
bb13:
  %t81 = load i64, ptr %l43, !tbaa !24
  %t84 = icmp eq i64 %t81, 1
  br i1 %t84, label %bb14, label %bb15
bb14:
  %t86 = load i64, ptr %l3, !tbaa !24
  store i64 %t86, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t88 = load i64, ptr %l3, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l3, !tbaa !24
  br label %bb17
bb17:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l8, !tbaa !24
  br label %bb7
bb18:
  %t96 = load i64, ptr %l3, !tbaa !24
  store i64 %t96, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2enfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t10 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i64 %a1, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t4, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i32 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t7, i32 0, i32 %t8, i32 0, i32 0, i64 0)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2feval_2etfn(ptr %t10, ptr %v0, ptr %v1, ptr %t11, i64 %t12, i32 %t13)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t10, i64 248, i1 false)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l8, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [4 x i64] }
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca i1
  %l7 = alloca i1
  %rv = alloca i1
  store { i64, [4 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l0, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l1
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load %"compiler/mir:Lvalue", ptr %l1
  %t12 = call i1 @compiler_2feval_2eplaceNamesGlobal(%"compiler/mir:Lvalue" %t10)
  store i1 %t12, ptr %l7
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  store i1 %t13, ptr %l2, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_a1e0d3359bcb436b_ac2861f14772b5df)
  unreachable
bb10:
  %t14 = load i1, ptr %l2, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2epassFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %lp7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i32
  %l24 = alloca i32
  %l25 = alloca %"compiler/mir:Fn"
  %l29 = alloca i32
  %l33 = alloca i32
  %l37 = alloca i32
  %l39 = alloca i32
  %l41 = alloca i32
  %l42 = alloca ptr
  %l44 = alloca { i64, [2 x i64] }
  %l46 = alloca { i64, [7 x i64] }
  %l47 = alloca ptr
  %l48 = alloca { i64, [4 x i64] }
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"compiler/mir:Range"
  %l51 = alloca %"compiler/mir:Range"
  %l53 = alloca %"compiler/mir:Lvalue"
  %l57 = alloca %"compiler/mir:Call"
  %l58 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca %"compiler/source:Span"
  %l74 = alloca %"compiler/mir:Lvalue"
  %l77 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca %"compiler/source:Span"
  %l81 = alloca %"compiler/mir:Lvalue"
  %l83 = alloca %"compiler/mir:Lvalue"
  %l96 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca %"compiler/source:Span"
  %l100 = alloca %"compiler/mir:Lvalue"
  %l103 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t20 = alloca %"compiler/mir:Fn", align 8
  %t63 = alloca { i64, [7 x i64] }, align 8
  %t107 = alloca { i64, [8 x i64] }, align 8
  %t122 = alloca { i64, [21 x i64] }, align 8
  %t141 = alloca { i64, [4 x i64] }, align 8
  %t147 = alloca { i64, [8 x i64] }, align 8
  %t167 = alloca { i64, [4 x i64] }, align 8
  %t175 = alloca { i64, [15 x i64] }, align 8
  %t185 = alloca { i64, [21 x i64] }, align 8
  %t204 = alloca { i64, [21 x i64] }, align 8
  %t223 = alloca { i64, [4 x i64] }, align 8
  %t229 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i32 %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load i32, ptr %l15, !tbaa !23
  store i32 %t4, ptr %l6, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l16, !tbaa !29
  store i64 %a1, ptr %l17, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l18, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l6, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l21
  br label %bb2
bb2:
  %t13 = load i32, ptr %l6, !tbaa !23
  %t14 = load i32, ptr %l5, !tbaa !23
  %t15 = load ptr, ptr %l18, !tbaa !29
  %t16 = load i32, ptr %l21, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t15, i32 %t16, i32 %t13, i32 %t14, i32 0, i64 0)
  store i32 %t19, ptr %l24
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = load i32, ptr %l24, !tbaa !23
  call void @compiler_2feval_2etfn(ptr %t20, ptr %v0, ptr %v1, ptr %t21, i64 %t22, i32 %t23)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t20, i64 248, i1 false)
  br label %bb4
bb4:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 248, i64 8)
  store ptr %t24, ptr %lp7
  %t25 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %l25, i64 248, i1 false)
  %t26 = load ptr, ptr %lp7
  %t27 = load i32, ptr %l6, !tbaa !23
  %t28 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t32 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t26, i32 %t27, %"compiler/source:Span" %t28)
  store i32 %t32, ptr %l29
  br label %bb5
bb5:
  %t33 = load i32, ptr %l29, !tbaa !23
  store i32 %t33, ptr %l8, !tbaa !23
  %t34 = load ptr, ptr %lp7
  %t35 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t36 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t40 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t34, i32 %t35, %"compiler/source:Span" %t36)
  store i32 %t40, ptr %l33
  br label %bb6
bb6:
  %t41 = load i32, ptr %l33, !tbaa !23
  store i32 %t41, ptr %l9, !tbaa !23
  %t42 = load ptr, ptr %lp7
  %t43 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t44 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t48 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t42, i32 %t43, %"compiler/source:Span" %t44)
  store i32 %t48, ptr %l37
  br label %bb7
bb7:
  %t49 = load i32, ptr %l37, !tbaa !23
  store i32 %t49, ptr %l10, !tbaa !23
  %t50 = load ptr, ptr %lp7
  %t52 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t50)
  store i32 %t52, ptr %l39
  br label %bb8
bb8:
  %t53 = load i32, ptr %l39, !tbaa !23
  store i32 %t53, ptr %l11, !tbaa !23
  %t54 = load ptr, ptr %lp7
  %t56 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t54)
  store i32 %t56, ptr %l41
  br label %bb9
bb9:
  %t57 = load i32, ptr %l41, !tbaa !23
  store i32 %t57, ptr %l12, !tbaa !23
  %t58 = load ptr, ptr %lp7
  store ptr %t58, ptr %l42, !tbaa !29
  %t61 = call { i64, [2 x i64] } @compiler_2feval_2etkey(i64 %a2)
  store { i64, [2 x i64] } %t61, ptr %l44
  br label %bb10
bb10:
  store { i64, [7 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [7 x i64] }, ptr %t63, i32 0, i32 0
  store i64 0, ptr %t64
  %t65 = load { i64, [2 x i64] }, ptr %l44
  %t66 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t65, 0
  %t68 = insertvalue { { i64, [2 x i64] }, i32 } %t66, i32 %a3, 1
  %t69 = getelementptr { i64, [7 x i64] }, ptr %t63, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t68, ptr %t69
  %t70 = load { i64, [7 x i64] }, ptr %t63
  store { i64, [7 x i64] } %t70, ptr %l46
  %t71 = load ptr, ptr %lp7
  store ptr %t71, ptr %l47, !tbaa !29
  %t72 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t72, ptr %l48
  br label %bb11
bb11:
  %t73 = mul i64 1, 40
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 1, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l49, !tbaa !27
  %t77 = load { i64, [4 x i64] }, ptr %l48
  %t78 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t79, i64 0
  store { i64, [4 x i64] } %t77, ptr %t80
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t83 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t81, { i64, ptr } %t82)
  store %"compiler/mir:Range" %t83, ptr %l50
  br label %bb12
bb12:
  %t84 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t84, ptr %l51
  %t85 = load i32, ptr %l8, !tbaa !23
  %t87 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t85)
  store %"compiler/mir:Lvalue" %t87, ptr %l53
  br label %bb13
bb13:
  %t88 = load i32, ptr %l11, !tbaa !23
  %t89 = load i32, ptr %l9, !tbaa !23
  %t90 = load i32, ptr %l12, !tbaa !23
  %t91 = load { i64, [7 x i64] }, ptr %l46
  %t92 = load %"compiler/mir:Range", ptr %l50
  %t93 = load %"compiler/mir:Range", ptr %l51
  %t94 = load %"compiler/mir:Lvalue", ptr %l53
  %t98 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t91, %"compiler/mir:Range" %t92, %"compiler/mir:Range" %t93, %"compiler/mir:Lvalue" %t94, i1 true, i32 %t88, i32 %t89, i32 %t90)
  store %"compiler/mir:Call" %t98, ptr %l57
  br label %bb14
bb14:
  %t99 = load ptr, ptr %l42, !tbaa !29
  %t100 = load %"compiler/mir:Call", ptr %l57
  %t101 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v1, ptr %t99, %"compiler/mir:Call" %t100)
  store i32 %t101, ptr %l58
  br label %bb15
bb15:
  %t102 = load i32, ptr %l58, !tbaa !23
  %t103 = load ptr, ptr %lp7
  %t104 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  %t105 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [8 x i64] }, ptr %t107, i32 0, i32 0
  store i64 4, ptr %t108
  %t110 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t105, 0
  %t112 = insertvalue { %"compiler/source:Span", i32 } %t110, i32 %t102, 1
  %t113 = getelementptr { i64, [8 x i64] }, ptr %t107, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t112, ptr %t113
  %t114 = load { i64, [8 x i64] }, ptr %t107
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t103, i32 %t104, { i64, [8 x i64] } %t114)
  br label %bb16
bb16:
  %t118 = load ptr, ptr %lp7
  %t119 = load i32, ptr %l11, !tbaa !23
  %t120 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t121 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t122
  %t123 = getelementptr { i64, [21 x i64] }, ptr %t122, i32 0, i32 0
  store i64 4, ptr %t123
  %t125 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t120, 0
  %t127 = insertvalue { %"compiler/source:Span", i32 } %t125, i32 %t121, 1
  %t128 = getelementptr { i64, [21 x i64] }, ptr %t122, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t127, ptr %t128
  %t129 = load { i64, [21 x i64] }, ptr %t122
  %t131 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t129, ptr %t131
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t118, i32 %t119, ptr %t131)
  br label %bb17
bb17:
  %t135 = load ptr, ptr %lp7
  store ptr %t135, ptr %l70, !tbaa !29
  %t136 = load i32, ptr %l11, !tbaa !23
  store i32 %t136, ptr %l71, !tbaa !23
  %t137 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t137, ptr %l72
  %t138 = load i32, ptr %l8, !tbaa !23
  %t140 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t138)
  store %"compiler/mir:Lvalue" %t140, ptr %l74
  br label %bb18
bb18:
  store { i64, [4 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t141, i32 0, i32 0
  store i64 1, ptr %t142
  %t143 = load %"compiler/mir:Lvalue", ptr %l74
  %t144 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t143, 0
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t141, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t144, ptr %t145
  %t146 = load { i64, [4 x i64] }, ptr %t141
  store { i64, [8 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [8 x i64] }, ptr %t147, i32 0, i32 0
  store i64 5, ptr %t148
  %t149 = load %"compiler/source:Span", ptr %l72
  %t150 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t149, 0
  %t152 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t150, { i64, [4 x i64] } %t146, 1
  %t153 = getelementptr { i64, [8 x i64] }, ptr %t147, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t152, ptr %t153
  %t154 = load { i64, [8 x i64] }, ptr %t147
  %t155 = load ptr, ptr %l70, !tbaa !29
  %t156 = load i32, ptr %l71, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t155, i32 %t156, { i64, [8 x i64] } %t154)
  br label %bb19
bb19:
  %t158 = load ptr, ptr %lp7
  store ptr %t158, ptr %l77, !tbaa !29
  %t159 = load i32, ptr %l12, !tbaa !23
  store i32 %t159, ptr %l78, !tbaa !23
  %t160 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t160, ptr %l79
  %t161 = load i32, ptr %l10, !tbaa !23
  %t163 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t161)
  store %"compiler/mir:Lvalue" %t163, ptr %l81
  br label %bb20
bb20:
  %t164 = load i32, ptr %l9, !tbaa !23
  %t166 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t164)
  store %"compiler/mir:Lvalue" %t166, ptr %l83
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t167
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t167, i32 0, i32 0
  store i64 1, ptr %t168
  %t169 = load %"compiler/mir:Lvalue", ptr %l83
  %t170 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t169, 0
  %t171 = getelementptr { i64, [4 x i64] }, ptr %t167, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t170, ptr %t171
  %t172 = load { i64, [4 x i64] }, ptr %t167
  %t174 = load i32, ptr %l5, !tbaa !23
  store { i64, [15 x i64] } zeroinitializer, ptr %t175
  %t176 = getelementptr { i64, [15 x i64] }, ptr %t175, i32 0, i32 0
  store i64 11, ptr %t176
  %t178 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t172, 0
  %t180 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t178, i32 %a4, 1
  %t182 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t180, i32 %t174, 2
  %t183 = getelementptr { i64, [15 x i64] }, ptr %t175, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t182, ptr %t183
  %t184 = load { i64, [15 x i64] }, ptr %t175
  store { i64, [21 x i64] } zeroinitializer, ptr %t185
  %t186 = getelementptr { i64, [21 x i64] }, ptr %t185, i32 0, i32 0
  store i64 0, ptr %t186
  %t187 = load %"compiler/source:Span", ptr %l79
  %t188 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t187, 0
  %t189 = load %"compiler/mir:Lvalue", ptr %l81
  %t190 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t188, %"compiler/mir:Lvalue" %t189, 1
  %t192 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t190, { i64, [15 x i64] } %t184, 2
  %t193 = getelementptr { i64, [21 x i64] }, ptr %t185, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t192, ptr %t193
  %t194 = load { i64, [21 x i64] }, ptr %t185
  %t196 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t194, ptr %t196
  %t197 = load ptr, ptr %l77, !tbaa !29
  %t198 = load i32, ptr %l78, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t197, i32 %t198, ptr %t196)
  br label %bb22
bb22:
  %t200 = load ptr, ptr %lp7
  %t201 = load i32, ptr %l12, !tbaa !23
  %t202 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t203 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [21 x i64] }, ptr %t204, i32 0, i32 0
  store i64 4, ptr %t205
  %t207 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t202, 0
  %t209 = insertvalue { %"compiler/source:Span", i32 } %t207, i32 %t203, 1
  %t210 = getelementptr { i64, [21 x i64] }, ptr %t204, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t209, ptr %t210
  %t211 = load { i64, [21 x i64] }, ptr %t204
  %t213 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t211, ptr %t213
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t200, i32 %t201, ptr %t213)
  br label %bb23
bb23:
  %t217 = load ptr, ptr %lp7
  store ptr %t217, ptr %l96, !tbaa !29
  %t218 = load i32, ptr %l12, !tbaa !23
  store i32 %t218, ptr %l97, !tbaa !23
  %t219 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t219, ptr %l98
  %t220 = load i32, ptr %l10, !tbaa !23
  %t222 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t220)
  store %"compiler/mir:Lvalue" %t222, ptr %l100
  br label %bb24
bb24:
  store { i64, [4 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t223, i32 0, i32 0
  store i64 1, ptr %t224
  %t225 = load %"compiler/mir:Lvalue", ptr %l100
  %t226 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t225, 0
  %t227 = getelementptr { i64, [4 x i64] }, ptr %t223, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t226, ptr %t227
  %t228 = load { i64, [4 x i64] }, ptr %t223
  store { i64, [8 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [8 x i64] }, ptr %t229, i32 0, i32 0
  store i64 7, ptr %t230
  %t231 = load %"compiler/source:Span", ptr %l98
  %t232 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t231, 0
  %t234 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t232, { i64, [4 x i64] } %t228, 1
  %t235 = getelementptr { i64, [8 x i64] }, ptr %t229, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t234, ptr %t235
  %t236 = load { i64, [8 x i64] }, ptr %t229
  %t237 = load ptr, ptr %l96, !tbaa !29
  %t238 = load i32, ptr %l97, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t237, i32 %t238, { i64, [8 x i64] } %t236)
  br label %bb25
bb25:
  %t240 = load ptr, ptr %lp7
  call void @llvm.memmove.p0.p0.i64(ptr %l103, ptr %t240, i64 248, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l103, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %a0) #0 {
entry:
  %l0 = alloca %"compiler/mir:Lvalue"
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i32
  %l4 = alloca i64
  %rv = alloca i64
  store %"compiler/mir:Lvalue" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l0, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l1
  %t4 = load { i64, [2 x i64] }, ptr %l1
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t10 = getelementptr { i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i32, ptr %t10
  store i32 %t11, ptr %l2, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t13 = load i32, ptr %l2, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l4, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_c25b9553ef801192_ed4b8566966f1316)
  unreachable
bb9:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2erCall_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2feval_2erCall, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2erTask_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2feval_2erTask, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2esInert_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2feval_2esInert, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2esProgram_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2feval_2esProgram, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2esRegion_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2esStore_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2feval_2esStore, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2feval_2eshl128(i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l25 = alloca i64
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = insertvalue { i64, i64 } undef, i64 %t5, 0
  %t10 = insertvalue { i64, i64 } %t8, i64 %t6, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sge i64 %t12, 64
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l0, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t17, 64
  store i64 %t19, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = shl i64 %t16, %t22
  %t24 = insertvalue { i64, i64 } undef, i64 0, 0
  %t26 = insertvalue { i64, i64 } %t24, i64 %t23, 1
  store { i64, i64 } %t26, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l0, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  store i64 %t29, ptr %l16, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = shl i64 %t28, %t32
  %t34 = load i64, ptr %l1, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l19, !tbaa !24
  %t37 = load i64, ptr %l19, !tbaa !24
  %t38 = load i64, ptr %l19, !tbaa !24
  %t39 = shl i64 %t34, %t38
  %t40 = load i64, ptr %l0, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = sub i64 64, %t42
  store i64 %t44, ptr %l25, !tbaa !65
  %t47 = load i64, ptr %l25, !tbaa !65
  %t48 = load i64, ptr %l25, !tbaa !65
  %t49 = lshr i64 %t40, %t48
  %t53 = or i64 %t39, %t49
  %t55 = insertvalue { i64, i64 } undef, i64 %t33, 0
  %t57 = insertvalue { i64, i64 } %t55, i64 %t53, 1
  store { i64, i64 } %t57, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i1 @compiler_2feval_2estmtNamesGlobal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca %"compiler/mir:Lvalue"
  %l6 = alloca %"compiler/mir:Lvalue"
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca %"compiler/mir:Range"
  %l10 = alloca { i64, [4 x i64] }
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l35 = alloca i1
  %l46 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l59 = alloca i1
  %l74 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i1
  %l83 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [21 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t12, i32 0, i32 1
  %t14 = load %"compiler/mir:Lvalue", ptr %t13
  store %"compiler/mir:Lvalue" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [21 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, [15 x i64] }, ptr %t19
  store { i64, [15 x i64] } %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb66
bb5:
  %t22 = load %"compiler/mir:Lvalue", ptr %l2
  %t24 = call i1 @compiler_2feval_2eplaceNamesGlobal(%"compiler/mir:Lvalue" %t22)
  store i1 %t24, ptr %l22
  br label %bb6
bb6:
  %t25 = load i1, ptr %l22, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb65
bb8:
  %t26 = load { i64, [15 x i64] }, ptr %l3
  %t28 = extractvalue { i64, [15 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 0
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t32 = getelementptr { { i64, [4 x i64] } }, ptr %t31, i32 0, i32 0
  %t33 = load { i64, [4 x i64] }, ptr %t32
  store { i64, [4 x i64] } %t33, ptr %l4
  br label %bb15
bb10:
  %t35 = load { i64, [15 x i64] }, ptr %l3
  %t37 = extractvalue { i64, [15 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 7
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t41 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t40, i32 0, i32 1
  %t42 = load { i64, [4 x i64] }, ptr %t41
  store { i64, [4 x i64] } %t42, ptr %l4
  br label %bb15
bb12:
  %t44 = load { i64, [15 x i64] }, ptr %l3
  %t46 = extractvalue { i64, [15 x i64] } %t44, 0
  %t47 = icmp eq i64 %t46, 11
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t50 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t49, i32 0, i32 0
  %t51 = load { i64, [4 x i64] }, ptr %t50
  store { i64, [4 x i64] } %t51, ptr %l4
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t53 = load { i64, [4 x i64] }, ptr %l4
  %t55 = call i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %t53)
  store i1 %t55, ptr %l35
  br label %bb16
bb16:
  %t56 = load i1, ptr %l35, !tbaa !21
  store i1 %t56, ptr %l24, !tbaa !21
  br label %bb64
bb17:
  %t57 = load { i64, [15 x i64] }, ptr %l3
  %t59 = extractvalue { i64, [15 x i64] } %t57, 0
  %t60 = icmp eq i64 %t59, 1
  br i1 %t60, label %bb18, label %bb19
bb18:
  %t62 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t63 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t62, i32 0, i32 0
  %t64 = load %"compiler/mir:Lvalue", ptr %t63
  store %"compiler/mir:Lvalue" %t64, ptr %l5
  br label %bb24
bb19:
  %t66 = load { i64, [15 x i64] }, ptr %l3
  %t68 = extractvalue { i64, [15 x i64] } %t66, 0
  %t69 = icmp eq i64 %t68, 2
  br i1 %t69, label %bb20, label %bb21
bb20:
  %t71 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t72 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t71, i32 0, i32 0
  %t73 = load %"compiler/mir:Lvalue", ptr %t72
  store %"compiler/mir:Lvalue" %t73, ptr %l5
  br label %bb24
bb21:
  %t75 = load { i64, [15 x i64] }, ptr %l3
  %t77 = extractvalue { i64, [15 x i64] } %t75, 0
  %t78 = icmp eq i64 %t77, 5
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t80 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t81 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t80, i32 0, i32 0
  %t82 = load %"compiler/mir:Lvalue", ptr %t81
  store %"compiler/mir:Lvalue" %t82, ptr %l5
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t84 = load %"compiler/mir:Lvalue", ptr %l5
  %t86 = call i1 @compiler_2feval_2eplaceNamesGlobal(%"compiler/mir:Lvalue" %t84)
  store i1 %t86, ptr %l46
  br label %bb25
bb25:
  %t87 = load i1, ptr %l46, !tbaa !21
  store i1 %t87, ptr %l24, !tbaa !21
  br label %bb64
bb26:
  %t88 = load { i64, [15 x i64] }, ptr %l3
  %t90 = extractvalue { i64, [15 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 9
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t93 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t94 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t93, i32 0, i32 0
  %t95 = load %"compiler/mir:Lvalue", ptr %t94
  store %"compiler/mir:Lvalue" %t95, ptr %l6
  %t97 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t98 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t97, i32 0, i32 1
  %t99 = load { i64, [4 x i64] }, ptr %t98
  store { i64, [4 x i64] } %t99, ptr %l7
  %t101 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t102 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t101, i32 0, i32 2
  %t103 = load { i64, [4 x i64] }, ptr %t102
  store { i64, [4 x i64] } %t103, ptr %l8
  br label %bb29
bb28:
  br label %bb39
bb29:
  %t105 = load %"compiler/mir:Lvalue", ptr %l6
  %t107 = call i1 @compiler_2feval_2eplaceNamesGlobal(%"compiler/mir:Lvalue" %t105)
  store i1 %t107, ptr %l53
  br label %bb30
bb30:
  %t108 = load i1, ptr %l53, !tbaa !21
  br i1 %t108, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb34
bb32:
  %t109 = load { i64, [4 x i64] }, ptr %l7
  %t111 = call i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %t109)
  store i1 %t111, ptr %l56
  br label %bb33
bb33:
  %t112 = load i1, ptr %l56, !tbaa !21
  store i1 %t112, ptr %l54, !tbaa !21
  br label %bb34
bb34:
  %t113 = load i1, ptr %l54, !tbaa !21
  br i1 %t113, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb38
bb36:
  %t114 = load { i64, [4 x i64] }, ptr %l8
  %t116 = call i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %t114)
  store i1 %t116, ptr %l59
  br label %bb37
bb37:
  %t117 = load i1, ptr %l59, !tbaa !21
  store i1 %t117, ptr %l57, !tbaa !21
  br label %bb38
bb38:
  %t118 = load i1, ptr %l57, !tbaa !21
  store i1 %t118, ptr %l24, !tbaa !21
  br label %bb64
bb39:
  %t119 = load { i64, [15 x i64] }, ptr %l3
  %t121 = extractvalue { i64, [15 x i64] } %t119, 0
  %t122 = icmp eq i64 %t121, 3
  br i1 %t122, label %bb40, label %bb41
bb40:
  %t124 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t125 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t124, i32 0, i32 2
  %t126 = load %"compiler/mir:Range", ptr %t125
  store %"compiler/mir:Range" %t126, ptr %l9
  br label %bb48
bb41:
  %t128 = load { i64, [15 x i64] }, ptr %l3
  %t130 = extractvalue { i64, [15 x i64] } %t128, 0
  %t131 = icmp eq i64 %t130, 4
  br i1 %t131, label %bb42, label %bb43
bb42:
  %t133 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t134 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t133, i32 0, i32 2
  %t135 = load %"compiler/mir:Range", ptr %t134
  store %"compiler/mir:Range" %t135, ptr %l9
  br label %bb48
bb43:
  %t137 = load { i64, [15 x i64] }, ptr %l3
  %t139 = extractvalue { i64, [15 x i64] } %t137, 0
  %t140 = icmp eq i64 %t139, 6
  br i1 %t140, label %bb44, label %bb45
bb44:
  %t142 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t143 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t142, i32 0, i32 2
  %t144 = load %"compiler/mir:Range", ptr %t143
  store %"compiler/mir:Range" %t144, ptr %l9
  br label %bb48
bb45:
  %t146 = load { i64, [15 x i64] }, ptr %l3
  %t148 = extractvalue { i64, [15 x i64] } %t146, 0
  %t149 = icmp eq i64 %t148, 10
  br i1 %t149, label %bb46, label %bb47
bb46:
  %t151 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t152 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t151, i32 0, i32 3
  %t153 = load %"compiler/mir:Range", ptr %t152
  store %"compiler/mir:Range" %t153, ptr %l9
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t156 = load %"compiler/mir:Range", ptr %l9
  %t159 = call i1 @compiler_2feval_2erangeNamesGlobal(ptr %v0, ptr %a0, %"compiler/mir:Range" %t156)
  store i1 %t159, ptr %l74
  br label %bb49
bb49:
  %t160 = load i1, ptr %l74, !tbaa !21
  store i1 %t160, ptr %l24, !tbaa !21
  br label %bb64
bb50:
  %t161 = load { i64, [15 x i64] }, ptr %l3
  %t163 = extractvalue { i64, [15 x i64] } %t161, 0
  %t164 = icmp eq i64 %t163, 8
  br i1 %t164, label %bb51, label %bb52
bb51:
  %t166 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t167 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t166, i32 0, i32 2
  %t168 = load { i64, [4 x i64] }, ptr %t167
  store { i64, [4 x i64] } %t168, ptr %l10
  %t170 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t171 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t170, i32 0, i32 3
  %t172 = load { i64, [4 x i64] }, ptr %t171
  store { i64, [4 x i64] } %t172, ptr %l11
  br label %bb53
bb52:
  br label %bb59
bb53:
  %t174 = load { i64, [4 x i64] }, ptr %l10
  %t176 = call i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %t174)
  store i1 %t176, ptr %l80
  br label %bb54
bb54:
  %t177 = load i1, ptr %l80, !tbaa !21
  br i1 %t177, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb58
bb56:
  %t178 = load { i64, [4 x i64] }, ptr %l11
  %t180 = call i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %t178)
  store i1 %t180, ptr %l83
  br label %bb57
bb57:
  %t181 = load i1, ptr %l83, !tbaa !21
  store i1 %t181, ptr %l81, !tbaa !21
  br label %bb58
bb58:
  %t182 = load i1, ptr %l81, !tbaa !21
  store i1 %t182, ptr %l24, !tbaa !21
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_5c3972130c0b0906_e6fe5489c867bc1a)
  unreachable
bb64:
  %t183 = load i1, ptr %l24, !tbaa !21
  store i1 %t183, ptr %l23, !tbaa !21
  br label %bb65
bb65:
  %t184 = load i1, ptr %l23, !tbaa !21
  store i1 %t184, ptr %l12, !tbaa !21
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_108ebfb6784b13e7_2381776f1f64d61b)
  unreachable
bb71:
  %t185 = load i1, ptr %l12, !tbaa !21
  store i1 %t185, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2esumFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l15 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca i32
  %l26 = alloca i32
  %l27 = alloca %"compiler/mir:Fn"
  %l31 = alloca i32
  %l35 = alloca i32
  %l39 = alloca i32
  %l43 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i32
  %l52 = alloca i32
  %l54 = alloca i32
  %l55 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/mir:Lvalue"
  %l65 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca %"compiler/source:Span"
  %l69 = alloca %"compiler/mir:Lvalue"
  %l79 = alloca ptr
  %l80 = alloca i32
  %l82 = alloca i64
  %l83 = alloca i32
  %l84 = alloca i32
  %l86 = alloca %"compiler/mir:Lvalue"
  %l87 = alloca { i64, [4 x i64] }
  %l88 = alloca { i64, [4 x i64] }
  %l89 = alloca ptr
  %l90 = alloca i32
  %l92 = alloca %"compiler/mir:Lvalue"
  %l104 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/mir:Lvalue"
  %l119 = alloca ptr
  %l120 = alloca i32
  %l122 = alloca i64
  %l123 = alloca i32
  %l124 = alloca i32
  %l126 = alloca %"compiler/mir:Lvalue"
  %l127 = alloca { i64, [4 x i64] }
  %l129 = alloca %"compiler/mir:Lvalue"
  %l131 = alloca ptr
  %l132 = alloca i32
  %l134 = alloca i64
  %l135 = alloca i32
  %l136 = alloca i32
  %l138 = alloca %"compiler/mir:Lvalue"
  %l158 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca %"compiler/source:Span"
  %l162 = alloca %"compiler/mir:Lvalue"
  %l165 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t24 = alloca %"compiler/mir:Fn", align 8
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t97 = alloca { i64, [15 x i64] }, align 8
  %t103 = alloca { i64, [21 x i64] }, align 8
  %t125 = alloca { i64, [4 x i64] }, align 8
  %t132 = alloca { i64, [15 x i64] }, align 8
  %t138 = alloca { i64, [21 x i64] }, align 8
  %t156 = alloca { i64, [8 x i64] }, align 8
  %t174 = alloca { i64, [4 x i64] }, align 8
  %t193 = alloca { i64, [4 x i64] }, align 8
  %t201 = alloca { i64, [8 x i64] }, align 8
  %t218 = alloca { i64, [21 x i64] }, align 8
  %t240 = alloca { i64, [1 x i64] }, align 8
  %t248 = alloca { i64, [4 x i64] }, align 8
  %t256 = alloca { i64, [4 x i64] }, align 8
  %t263 = alloca { i64, [15 x i64] }, align 8
  %t275 = alloca { i64, [21 x i64] }, align 8
  %t299 = alloca { i64, [4 x i64] }, align 8
  %t308 = alloca { i64, [4 x i64] }, align 8
  %t330 = alloca { i64, [4 x i64] }, align 8
  %t337 = alloca { i64, [4 x i64] }, align 8
  %t355 = alloca { i64, [21 x i64] }, align 8
  %t371 = alloca { i64, [8 x i64] }, align 8
  %t384 = alloca { i64, [21 x i64] }, align 8
  %t403 = alloca { i64, [4 x i64] }, align 8
  %t409 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i32 %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load i32, ptr %l15, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l3, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t5, i32 %t6, i32 0)
  store i32 %t9, ptr %l18
  br label %bb2
bb2:
  %t10 = load i32, ptr %l18, !tbaa !23
  store i32 %t10, ptr %l4, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l19, !tbaa !29
  store i64 %a1, ptr %l20, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l21, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l24
  br label %bb3
bb3:
  %t19 = load i32, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l21, !tbaa !29
  %t21 = load i32, ptr %l24, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t20, i32 %t21, i32 %t19, i32 0, i32 0, i64 0)
  store i32 %t23, ptr %l26
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l19, !tbaa !29
  %t26 = load i64, ptr %l20, !tbaa !24
  %t27 = load i32, ptr %l26, !tbaa !23
  call void @compiler_2feval_2etfn(ptr %t24, ptr %v0, ptr %v1, ptr %t25, i64 %t26, i32 %t27)
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %t24, i64 248, i1 false)
  br label %bb5
bb5:
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 248, i64 8)
  store ptr %t28, ptr %lp5
  %t29 = load ptr, ptr %lp5
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %l27, i64 248, i1 false)
  %t30 = load ptr, ptr %lp5
  %t31 = load i32, ptr %l3, !tbaa !23
  %t32 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t36 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t30, i32 %t31, %"compiler/source:Span" %t32)
  store i32 %t36, ptr %l31
  br label %bb6
bb6:
  %t37 = load i32, ptr %l31, !tbaa !23
  store i32 %t37, ptr %l6, !tbaa !23
  %t38 = load ptr, ptr %lp5
  %t39 = load i32, ptr %l3, !tbaa !23
  %t40 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t44 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t38, i32 %t39, %"compiler/source:Span" %t40)
  store i32 %t44, ptr %l35
  br label %bb7
bb7:
  %t45 = load i32, ptr %l35, !tbaa !23
  store i32 %t45, ptr %l7, !tbaa !23
  %t46 = load ptr, ptr %lp5
  %t47 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t48 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t52 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t46, i32 %t47, %"compiler/source:Span" %t48)
  store i32 %t52, ptr %l39
  br label %bb8
bb8:
  %t53 = load i32, ptr %l39, !tbaa !23
  store i32 %t53, ptr %l8, !tbaa !23
  %t54 = load ptr, ptr %lp5
  %t55 = load i32, ptr %l4, !tbaa !23
  %t56 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t60 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t54, i32 %t55, %"compiler/source:Span" %t56)
  store i32 %t60, ptr %l43
  br label %bb9
bb9:
  %t61 = load i32, ptr %l43, !tbaa !23
  store i32 %t61, ptr %l9, !tbaa !23
  %t62 = load ptr, ptr %lp5
  %t63 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  %t64 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t69 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v1, ptr %t62, i32 2, i32 %t63, i32 1, %"compiler/source:Span" %t64, i32 0)
  store i32 %t69, ptr %l48
  br label %bb10
bb10:
  %t70 = load i32, ptr %l48, !tbaa !23
  store i32 %t70, ptr %l10, !tbaa !23
  %t71 = load ptr, ptr %lp5
  %t73 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t71)
  store i32 %t73, ptr %l50
  br label %bb11
bb11:
  %t74 = load i32, ptr %l50, !tbaa !23
  store i32 %t74, ptr %l11, !tbaa !23
  %t75 = load ptr, ptr %lp5
  %t77 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t75)
  store i32 %t77, ptr %l52
  br label %bb12
bb12:
  %t78 = load i32, ptr %l52, !tbaa !23
  store i32 %t78, ptr %l12, !tbaa !23
  %t79 = load ptr, ptr %lp5
  %t81 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t79)
  store i32 %t81, ptr %l54
  br label %bb13
bb13:
  %t82 = load i32, ptr %l54, !tbaa !23
  store i32 %t82, ptr %l13, !tbaa !23
  %t83 = load ptr, ptr %lp5
  store ptr %t83, ptr %l55, !tbaa !29
  %t84 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t84, ptr %l56, !tbaa !23
  %t85 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t85, ptr %l57
  %t86 = load i32, ptr %l6, !tbaa !23
  %t88 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t86)
  store %"compiler/mir:Lvalue" %t88, ptr %l59
  br label %bb14
bb14:
  %t89 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 2, ptr %t91
  %t93 = insertvalue { i32, i64 } undef, i32 %t89, 0
  %t94 = insertvalue { i32, i64 } %t93, i64 0, 1
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  store { i32, i64 } %t94, ptr %t95
  %t96 = load { i64, [4 x i64] }, ptr %t90
  store { i64, [15 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [15 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t100 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t96, 0
  %t101 = getelementptr { i64, [15 x i64] }, ptr %t97, i32 0, i32 1
  store { { i64, [4 x i64] } } %t100, ptr %t101
  %t102 = load { i64, [15 x i64] }, ptr %t97
  store { i64, [21 x i64] } zeroinitializer, ptr %t103
  %t104 = getelementptr { i64, [21 x i64] }, ptr %t103, i32 0, i32 0
  store i64 0, ptr %t104
  %t105 = load %"compiler/source:Span", ptr %l57
  %t106 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t105, 0
  %t107 = load %"compiler/mir:Lvalue", ptr %l59
  %t108 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t106, %"compiler/mir:Lvalue" %t107, 1
  %t110 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t108, { i64, [15 x i64] } %t102, 2
  %t111 = getelementptr { i64, [21 x i64] }, ptr %t103, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t110, ptr %t111
  %t112 = load { i64, [21 x i64] }, ptr %t103
  %t114 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t112, ptr %t114
  %t115 = load ptr, ptr %l55, !tbaa !29
  %t116 = load i32, ptr %l56, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t115, i32 %t116, ptr %t114)
  br label %bb15
bb15:
  %t118 = load ptr, ptr %lp5
  store ptr %t118, ptr %l65, !tbaa !29
  %t119 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t119, ptr %l66, !tbaa !23
  %t120 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t120, ptr %l67
  %t121 = load i32, ptr %l7, !tbaa !23
  %t123 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t121)
  store %"compiler/mir:Lvalue" %t123, ptr %l69
  br label %bb16
bb16:
  %t124 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 0
  store i64 2, ptr %t126
  %t128 = insertvalue { i32, i64 } undef, i32 %t124, 0
  %t129 = insertvalue { i32, i64 } %t128, i64 0, 1
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 1
  store { i32, i64 } %t129, ptr %t130
  %t131 = load { i64, [4 x i64] }, ptr %t125
  store { i64, [15 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [15 x i64] }, ptr %t132, i32 0, i32 0
  store i64 0, ptr %t133
  %t135 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t131, 0
  %t136 = getelementptr { i64, [15 x i64] }, ptr %t132, i32 0, i32 1
  store { { i64, [4 x i64] } } %t135, ptr %t136
  %t137 = load { i64, [15 x i64] }, ptr %t132
  store { i64, [21 x i64] } zeroinitializer, ptr %t138
  %t139 = getelementptr { i64, [21 x i64] }, ptr %t138, i32 0, i32 0
  store i64 0, ptr %t139
  %t140 = load %"compiler/source:Span", ptr %l67
  %t141 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t140, 0
  %t142 = load %"compiler/mir:Lvalue", ptr %l69
  %t143 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t141, %"compiler/mir:Lvalue" %t142, 1
  %t145 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t143, { i64, [15 x i64] } %t137, 2
  %t146 = getelementptr { i64, [21 x i64] }, ptr %t138, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t145, ptr %t146
  %t147 = load { i64, [21 x i64] }, ptr %t138
  %t149 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t147, ptr %t149
  %t150 = load ptr, ptr %l65, !tbaa !29
  %t151 = load i32, ptr %l66, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t150, i32 %t151, ptr %t149)
  br label %bb17
bb17:
  %t153 = load ptr, ptr %lp5
  %t154 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  %t155 = load i32, ptr %l11, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [8 x i64] }, ptr %t156, i32 0, i32 0
  store i64 1, ptr %t157
  %t159 = insertvalue { i32 } undef, i32 %t155, 0
  %t160 = getelementptr { i64, [8 x i64] }, ptr %t156, i32 0, i32 1
  store { i32 } %t159, ptr %t160
  %t161 = load { i64, [8 x i64] }, ptr %t156
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t153, i32 %t154, { i64, [8 x i64] } %t161)
  br label %bb18
bb18:
  %t165 = load ptr, ptr %lp5
  store ptr %t165, ptr %l79, !tbaa !29
  %t166 = load i32, ptr %l11, !tbaa !23
  store i32 %t166, ptr %l80, !tbaa !23
  %t167 = load i32, ptr %l8, !tbaa !23
  %t169 = sext i32 %t167 to i64
  store i64 %t169, ptr %l82, !tbaa !24
  store i32 15, ptr %l83
  %t170 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t170, ptr %l84, !tbaa !23
  %t171 = load i32, ptr %l6, !tbaa !23
  %t173 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t171)
  store %"compiler/mir:Lvalue" %t173, ptr %l86
  br label %bb19
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t174
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t174, i32 0, i32 0
  store i64 1, ptr %t175
  %t176 = load %"compiler/mir:Lvalue", ptr %l86
  %t177 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t176, 0
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t174, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t177, ptr %t178
  %t179 = load { i64, [4 x i64] }, ptr %t174
  store { i64, [4 x i64] } %t179, ptr %l87
  %t180 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t180, ptr %l88
  br label %bb20
bb20:
  %t181 = load ptr, ptr %l79, !tbaa !29
  %t182 = load i32, ptr %l80, !tbaa !23
  %t183 = load i64, ptr %l82, !tbaa !24
  %t184 = load i32, ptr %l83
  %t185 = load i32, ptr %l84, !tbaa !23
  %t186 = load { i64, [4 x i64] }, ptr %l87
  %t187 = load { i64, [4 x i64] }, ptr %l88
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t181, i32 %t182, i64 %t183, i32 %t184, i32 %t185, { i64, [4 x i64] } %t186, { i64, [4 x i64] } %t187)
  br label %bb21
bb21:
  %t188 = load ptr, ptr %lp5
  store ptr %t188, ptr %l89, !tbaa !29
  %t189 = load i32, ptr %l11, !tbaa !23
  store i32 %t189, ptr %l90, !tbaa !23
  %t190 = load i32, ptr %l8, !tbaa !23
  %t192 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t190)
  store %"compiler/mir:Lvalue" %t192, ptr %l92
  br label %bb22
bb22:
  store { i64, [4 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 0
  store i64 1, ptr %t194
  %t195 = load %"compiler/mir:Lvalue", ptr %l92
  %t196 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t195, 0
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t196, ptr %t197
  %t198 = load { i64, [4 x i64] }, ptr %t193
  %t199 = load i32, ptr %l12, !tbaa !23
  %t200 = load i32, ptr %l13, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t201
  %t202 = getelementptr { i64, [8 x i64] }, ptr %t201, i32 0, i32 0
  store i64 2, ptr %t202
  %t204 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t198, 0
  %t206 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t204, i32 %t199, 1
  %t208 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t206, i32 %t200, 2
  %t209 = getelementptr { i64, [8 x i64] }, ptr %t201, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t208, ptr %t209
  %t210 = load { i64, [8 x i64] }, ptr %t201
  %t211 = load ptr, ptr %l89, !tbaa !29
  %t212 = load i32, ptr %l90, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t211, i32 %t212, { i64, [8 x i64] } %t210)
  br label %bb23
bb23:
  %t214 = load ptr, ptr %lp5
  %t215 = load i32, ptr %l12, !tbaa !23
  %t216 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t217 = load i32, ptr %l10, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t218
  %t219 = getelementptr { i64, [21 x i64] }, ptr %t218, i32 0, i32 0
  store i64 3, ptr %t219
  %t221 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t216, 0
  %t223 = insertvalue { %"compiler/source:Span", i32 } %t221, i32 %t217, 1
  %t224 = getelementptr { i64, [21 x i64] }, ptr %t218, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t223, ptr %t224
  %t225 = load { i64, [21 x i64] }, ptr %t218
  %t227 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t225, ptr %t227
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t214, i32 %t215, ptr %t227)
  br label %bb24
bb24:
  br i1 %a2, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s1
  %t233 = load ptr, ptr %lp5
  store ptr %t233, ptr %l104, !tbaa !29
  %t234 = load i32, ptr %l12, !tbaa !23
  store i32 %t234, ptr %l105, !tbaa !23
  %t235 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t235, ptr %l106
  %t236 = load i32, ptr %l9, !tbaa !23
  %t238 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t236)
  store %"compiler/mir:Lvalue" %t238, ptr %l108
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t239 = load i32, ptr %l10, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t240
  %t241 = getelementptr { i64, [1 x i64] }, ptr %t240, i32 0, i32 0
  store i64 0, ptr %t241
  %t243 = insertvalue { i32 } undef, i32 %t239, 0
  %t244 = getelementptr { i64, [1 x i64] }, ptr %t240, i32 0, i32 1
  store { i32 } %t243, ptr %t244
  %t245 = load { i64, [1 x i64] }, ptr %t240
  %t246 = load i32, ptr %l4, !tbaa !23
  %t247 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [4 x i64] }, ptr %t248, i32 0, i32 0
  store i64 2, ptr %t249
  %t251 = insertvalue { i32, i64 } undef, i32 %t247, 0
  %t252 = insertvalue { i32, i64 } %t251, i64 4, 1
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t248, i32 0, i32 1
  store { i32, i64 } %t252, ptr %t253
  %t254 = load { i64, [4 x i64] }, ptr %t248
  %t255 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t256
  %t257 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 0
  store i64 2, ptr %t257
  %t259 = insertvalue { i32, i64 } undef, i32 %t255, 0
  %t260 = insertvalue { i32, i64 } %t259, i64 7, 1
  %t261 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 1
  store { i32, i64 } %t260, ptr %t261
  %t262 = load { i64, [4 x i64] }, ptr %t256
  store { i64, [15 x i64] } zeroinitializer, ptr %t263
  %t264 = getelementptr { i64, [15 x i64] }, ptr %t263, i32 0, i32 0
  store i64 8, ptr %t264
  %t266 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } undef, { i64, [1 x i64] } %t245, 0
  %t268 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t266, i32 %t246, 1
  %t270 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t268, { i64, [4 x i64] } %t254, 2
  %t272 = insertvalue { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t270, { i64, [4 x i64] } %t262, 3
  %t273 = getelementptr { i64, [15 x i64] }, ptr %t263, i32 0, i32 1
  store { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } } %t272, ptr %t273
  %t274 = load { i64, [15 x i64] }, ptr %t263
  store { i64, [21 x i64] } zeroinitializer, ptr %t275
  %t276 = getelementptr { i64, [21 x i64] }, ptr %t275, i32 0, i32 0
  store i64 0, ptr %t276
  %t277 = load %"compiler/source:Span", ptr %l106
  %t278 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t277, 0
  %t279 = load %"compiler/mir:Lvalue", ptr %l108
  %t280 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t278, %"compiler/mir:Lvalue" %t279, 1
  %t282 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t280, { i64, [15 x i64] } %t274, 2
  %t283 = getelementptr { i64, [21 x i64] }, ptr %t275, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t282, ptr %t283
  %t284 = load { i64, [21 x i64] }, ptr %t275
  %t286 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 176, i64 8)
  store { i64, [21 x i64] } %t284, ptr %t286
  %t287 = load ptr, ptr %l104, !tbaa !29
  %t288 = load i32, ptr %l105, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s1, ptr %t287, i32 %t288, ptr %t286)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s1)
  br label %bb29
bb29:
  %t290 = load ptr, ptr %lp5
  store ptr %t290, ptr %l119, !tbaa !29
  %t291 = load i32, ptr %l12, !tbaa !23
  store i32 %t291, ptr %l120, !tbaa !23
  %t292 = load i32, ptr %l7, !tbaa !23
  %t294 = sext i32 %t292 to i64
  store i64 %t294, ptr %l122, !tbaa !24
  store i32 3, ptr %l123
  %t295 = load i32, ptr %l3, !tbaa !23
  store i32 %t295, ptr %l124, !tbaa !23
  %t296 = load i32, ptr %l7, !tbaa !23
  %t298 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t296)
  store %"compiler/mir:Lvalue" %t298, ptr %l126
  br label %bb30
bb30:
  store { i64, [4 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [4 x i64] }, ptr %t299, i32 0, i32 0
  store i64 1, ptr %t300
  %t301 = load %"compiler/mir:Lvalue", ptr %l126
  %t302 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t301, 0
  %t303 = getelementptr { i64, [4 x i64] }, ptr %t299, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t302, ptr %t303
  %t304 = load { i64, [4 x i64] }, ptr %t299
  store { i64, [4 x i64] } %t304, ptr %l127
  %t305 = load i32, ptr %l6, !tbaa !23
  %t307 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t305)
  store %"compiler/mir:Lvalue" %t307, ptr %l129
  br label %bb31
bb31:
  store { i64, [4 x i64] } zeroinitializer, ptr %t308
  %t309 = getelementptr { i64, [4 x i64] }, ptr %t308, i32 0, i32 0
  store i64 1, ptr %t309
  %t310 = load %"compiler/mir:Lvalue", ptr %l129
  %t311 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t310, 0
  %t312 = getelementptr { i64, [4 x i64] }, ptr %t308, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t311, ptr %t312
  %t313 = load { i64, [4 x i64] }, ptr %t308
  %t314 = load ptr, ptr %l119, !tbaa !29
  %t315 = load i32, ptr %l120, !tbaa !23
  %t316 = load i64, ptr %l122, !tbaa !24
  %t317 = load i32, ptr %l123
  %t318 = load i32, ptr %l124, !tbaa !23
  %t319 = load { i64, [4 x i64] }, ptr %l127
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t314, i32 %t315, i64 %t316, i32 %t317, i32 %t318, { i64, [4 x i64] } %t319, { i64, [4 x i64] } %t313)
  br label %bb32
bb32:
  %t321 = load ptr, ptr %lp5
  store ptr %t321, ptr %l131, !tbaa !29
  %t322 = load i32, ptr %l12, !tbaa !23
  store i32 %t322, ptr %l132, !tbaa !23
  %t323 = load i32, ptr %l6, !tbaa !23
  %t325 = sext i32 %t323 to i64
  store i64 %t325, ptr %l134, !tbaa !24
  store i32 3, ptr %l135
  %t326 = load i32, ptr %l3, !tbaa !23
  store i32 %t326, ptr %l136, !tbaa !23
  %t327 = load i32, ptr %l6, !tbaa !23
  %t329 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t327)
  store %"compiler/mir:Lvalue" %t329, ptr %l138
  br label %bb33
bb33:
  store { i64, [4 x i64] } zeroinitializer, ptr %t330
  %t331 = getelementptr { i64, [4 x i64] }, ptr %t330, i32 0, i32 0
  store i64 1, ptr %t331
  %t332 = load %"compiler/mir:Lvalue", ptr %l138
  %t333 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t332, 0
  %t334 = getelementptr { i64, [4 x i64] }, ptr %t330, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t333, ptr %t334
  %t335 = load { i64, [4 x i64] }, ptr %t330
  %t336 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t337
  %t338 = getelementptr { i64, [4 x i64] }, ptr %t337, i32 0, i32 0
  store i64 2, ptr %t338
  %t340 = insertvalue { i32, i64 } undef, i32 %t336, 0
  %t341 = insertvalue { i32, i64 } %t340, i64 1, 1
  %t342 = getelementptr { i64, [4 x i64] }, ptr %t337, i32 0, i32 1
  store { i32, i64 } %t341, ptr %t342
  %t343 = load { i64, [4 x i64] }, ptr %t337
  %t344 = load ptr, ptr %l131, !tbaa !29
  %t345 = load i32, ptr %l132, !tbaa !23
  %t346 = load i64, ptr %l134, !tbaa !24
  %t347 = load i32, ptr %l135
  %t348 = load i32, ptr %l136, !tbaa !23
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t344, i32 %t345, i64 %t346, i32 %t347, i32 %t348, { i64, [4 x i64] } %t335, { i64, [4 x i64] } %t343)
  br label %bb34
bb34:
  %t351 = load ptr, ptr %lp5
  %t352 = load i32, ptr %l12, !tbaa !23
  %t353 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t354 = load i32, ptr %l10, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [21 x i64] }, ptr %t355, i32 0, i32 0
  store i64 4, ptr %t356
  %t358 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t353, 0
  %t360 = insertvalue { %"compiler/source:Span", i32 } %t358, i32 %t354, 1
  %t361 = getelementptr { i64, [21 x i64] }, ptr %t355, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t360, ptr %t361
  %t362 = load { i64, [21 x i64] }, ptr %t355
  %t364 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t362, ptr %t364
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t351, i32 %t352, ptr %t364)
  br label %bb35
bb35:
  %t368 = load ptr, ptr %lp5
  %t369 = load i32, ptr %l12, !tbaa !23
  %t370 = load i32, ptr %l11, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t371
  %t372 = getelementptr { i64, [8 x i64] }, ptr %t371, i32 0, i32 0
  store i64 1, ptr %t372
  %t374 = insertvalue { i32 } undef, i32 %t370, 0
  %t375 = getelementptr { i64, [8 x i64] }, ptr %t371, i32 0, i32 1
  store { i32 } %t374, ptr %t375
  %t376 = load { i64, [8 x i64] }, ptr %t371
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t368, i32 %t369, { i64, [8 x i64] } %t376)
  br label %bb36
bb36:
  %t380 = load ptr, ptr %lp5
  %t381 = load i32, ptr %l13, !tbaa !23
  %t382 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t383 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t384
  %t385 = getelementptr { i64, [21 x i64] }, ptr %t384, i32 0, i32 0
  store i64 4, ptr %t385
  %t387 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t382, 0
  %t389 = insertvalue { %"compiler/source:Span", i32 } %t387, i32 %t383, 1
  %t390 = getelementptr { i64, [21 x i64] }, ptr %t384, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t389, ptr %t390
  %t391 = load { i64, [21 x i64] }, ptr %t384
  %t393 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t391, ptr %t393
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t380, i32 %t381, ptr %t393)
  br label %bb37
bb37:
  %t397 = load ptr, ptr %lp5
  store ptr %t397, ptr %l158, !tbaa !29
  %t398 = load i32, ptr %l13, !tbaa !23
  store i32 %t398, ptr %l159, !tbaa !23
  %t399 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t399, ptr %l160
  %t400 = load i32, ptr %l7, !tbaa !23
  %t402 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t400)
  store %"compiler/mir:Lvalue" %t402, ptr %l162
  br label %bb38
bb38:
  store { i64, [4 x i64] } zeroinitializer, ptr %t403
  %t404 = getelementptr { i64, [4 x i64] }, ptr %t403, i32 0, i32 0
  store i64 1, ptr %t404
  %t405 = load %"compiler/mir:Lvalue", ptr %l162
  %t406 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t405, 0
  %t407 = getelementptr { i64, [4 x i64] }, ptr %t403, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t406, ptr %t407
  %t408 = load { i64, [4 x i64] }, ptr %t403
  store { i64, [8 x i64] } zeroinitializer, ptr %t409
  %t410 = getelementptr { i64, [8 x i64] }, ptr %t409, i32 0, i32 0
  store i64 5, ptr %t410
  %t411 = load %"compiler/source:Span", ptr %l160
  %t412 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t411, 0
  %t414 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t412, { i64, [4 x i64] } %t408, 1
  %t415 = getelementptr { i64, [8 x i64] }, ptr %t409, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t414, ptr %t415
  %t416 = load { i64, [8 x i64] }, ptr %t409
  %t417 = load ptr, ptr %l158, !tbaa !29
  %t418 = load i32, ptr %l159, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t417, i32 %t418, { i64, [8 x i64] } %t416)
  br label %bb39
bb39:
  %t420 = load ptr, ptr %lp5
  call void @llvm.memmove.p0.p0.i64(ptr %l165, ptr %t420, i64 248, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l165, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2etJoin_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2feval_2etJoin, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2etRaised_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2feval_2etRaised, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 %a0) #0 {
entry:
  %l2 = alloca %"compiler/mir:Lvalue"
  %rv = alloca { i64, [4 x i64] }
  %t4 = alloca { i64, [4 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/mir:Lvalue" @compiler_2feval_2etl(i64 %a0)
  store %"compiler/mir:Lvalue" %t3, ptr %l2
  br label %bb1
bb1:
  store { i64, [4 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 0
  store i64 1, ptr %t5
  %t6 = load %"compiler/mir:Lvalue", ptr %l2
  %t7 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t6, 0
  %t8 = getelementptr { i64, [4 x i64] }, ptr %t4, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t7, ptr %t8
  %t9 = load { i64, [4 x i64] }, ptr %t4
  store { i64, [4 x i64] } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

define dso_local i32 @compiler_2feval_2etdecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l15 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } %t2, 0
  %t8 = add i64 %t4, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t3, i64 %t4)
  %t10 = getelementptr i8, ptr %t9, i64 %t4
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } %t19)
  store i64 %t22, ptr %l9
  br label %bb1
bb1:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l10, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l11, !tbaa !29
  store i64 %t23, ptr %l12, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v2, ptr %a1, { i64, ptr } %t28)
  store i32 %t31, ptr %l15
  br label %bb2
bb2:
  %t33 = load ptr, ptr %l11, !tbaa !29
  %t34 = load i64, ptr %l12, !tbaa !24
  %t35 = load i32, ptr %l15, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %t33, i64 %t34, i32 %t35, i32 %a2, i32 0)
  store i32 %t37, ptr %l17
  br label %bb3
bb3:
  %t38 = load ptr, ptr %l10, !tbaa !29
  %t39 = load i32, ptr %l17, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t38, i32 %t39, i32 0)
  store i32 %t40, ptr %l18
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i32, ptr %l18, !tbaa !23
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2feval_2eterr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %t2, 1
  %t7 = extractvalue { i64, ptr } %t2, 0
  %t8 = add i64 %t4, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t3, i64 %t4)
  %t10 = getelementptr i8, ptr %t9, i64 %t4
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t22 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } %t19)
  store i64 %t22, ptr %l8
  br label %bb1
bb1:
  %t23 = load i64, ptr %l8, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l9, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l10, !tbaa !29
  store i64 %t23, ptr %l11, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v2, ptr %a1, { i64, ptr } %t28)
  store i32 %t31, ptr %l14
  br label %bb2
bb2:
  %t32 = load ptr, ptr %l10, !tbaa !29
  %t33 = load i64, ptr %l11, !tbaa !24
  %t34 = load i32, ptr %l14, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %t32, i64 %t33, i32 %t34, i32 2, i32 0)
  store i32 %t36, ptr %l16
  br label %bb3
bb3:
  %t37 = load ptr, ptr %l9, !tbaa !29
  %t38 = load i32, ptr %l16, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t37, i32 %t38, i32 0)
  store i32 %t39, ptr %l17
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i32, ptr %l17, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2feval_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l14 = alloca %"compiler/mir:Fn"
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l32 = alloca i32
  %l39 = alloca i32
  %l41 = alloca i32
  %l48 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t5 = alloca { i64, [2 x i64] }, align 8
  %t13 = alloca %"compiler/mir:Fn", align 8
  %t75 = alloca { i64, [21 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = trunc i64 %a1 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [2 x i64] }, ptr %t5
  %t11 = load i32, ptr %l2, !tbaa !23
  %t12 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  call void @compiler_2fmir_3aFn_2ector(ptr %t13, ptr %v1, { i64, [2 x i64] } %t10, i32 %t11, i64 0, %"compiler/source:Span" %t12)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %t13, i64 248, i1 false)
  br label %bb1
bb1:
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 248, i64 8)
  store ptr %t17, ptr %lp3
  %t18 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %l14, i64 248, i1 false)
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l18
  br label %bb2
bb2:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = load i32, ptr %l18, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t25, i32 %t26)
  store { i64, ptr } %t27, ptr %l19
  br label %bb3
bb3:
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t41, ptr %l26, !tbaa !27
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 %t42
  %t47 = load i32, ptr %t46, !tbaa !33
  %t49 = load ptr, ptr %lp3
  %t50 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t55 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v1, ptr %t49, i32 0, %"compiler/source:Span" %t50, i32 %t47)
  store i32 %t55, ptr %l32
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l5, !tbaa !24
  br label %bb4
bb10:
  %t60 = load ptr, ptr %lp3
  %t61 = load i32, ptr @G_2ecompiler_2fmir_2eNoScope, !tbaa !23
  %t62 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t67 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v1, ptr %t60, i32 0, i32 %t61, i32 0, %"compiler/source:Span" %t62, i32 0)
  store i32 %t67, ptr %l39
  br label %bb11
bb11:
  %t68 = load ptr, ptr %lp3
  %t70 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t68)
  store i32 %t70, ptr %l41
  br label %bb12
bb12:
  %t71 = load ptr, ptr %lp3
  %t72 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  %t73 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t74 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [21 x i64] }, ptr %t75, i32 0, i32 0
  store i64 3, ptr %t76
  %t78 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t73, 0
  %t80 = insertvalue { %"compiler/source:Span", i32 } %t78, i32 %t74, 1
  %t81 = getelementptr { i64, [21 x i64] }, ptr %t75, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t80, ptr %t81
  %t82 = load { i64, [21 x i64] }, ptr %t75
  %t84 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t82, ptr %t84
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t71, i32 %t72, ptr %t84)
  br label %bb13
bb13:
  %t88 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t88, i64 248, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l48, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2etraceKept_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 32, ptr @G_2ecompiler_2feval_2etraceKept, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64, i64, i64 } @compiler_2feval_2eudivmod128(i64 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, i64 }
  %l16 = alloca { i64, i64 }
  %l18 = alloca { i64, i64 }
  %l21 = alloca i1
  %l40 = alloca i64
  %l43 = alloca i64
  %l65 = alloca { i64, i64 }
  %l71 = alloca { i64, i64 }
  %l81 = alloca i64
  %l87 = alloca { i64, i64 }
  %l94 = alloca i64
  %l98 = alloca i64
  %rv = alloca { i64, i64, i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  store i1 %t7, ptr %l21, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l21, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load i64, ptr %l0, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t16 = udiv i64 %t10, %t12
  %t18 = load i64, ptr %l0, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t24 = urem i64 %t18, %t20
  %t27 = insertvalue { i64, i64, i64, i64 } undef, i64 %t16, 0
  %t28 = insertvalue { i64, i64, i64, i64 } %t27, i64 0, 1
  %t30 = insertvalue { i64, i64, i64, i64 } %t28, i64 %t24, 2
  %t31 = insertvalue { i64, i64, i64, i64 } %t30, i64 0, 3
  store { i64, i64, i64, i64 } %t31, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  store i64 128, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t33 = load i64, ptr %l9, !tbaa !24
  %t34 = load i64, ptr %l8, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load i64, ptr %l10, !tbaa !24
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb12
bb9:
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = sub i64 %t43, %t44
  %t48 = load i64, ptr %l10, !tbaa !24
  %t51 = add i64 %t47, %t48
  %t53 = sub i64 %t51, 1
  %t54 = load i64, ptr %l10, !tbaa !24
  %t57 = sdiv i64 %t53, %t54
  store i64 %t57, ptr %l43, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb11
bb11:
  %t59 = load i64, ptr %l43, !tbaa !24
  store i64 %t59, ptr %l40, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l40, !tbaa !24
  store i64 %t60, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l12, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb14, label %bb15
bb14:
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l12, !tbaa !24
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = mul i64 %t70, %t71
  %t77 = add i64 %t69, %t74
  %t81 = sub i64 127, %t77
  store i64 %t81, ptr %l14, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = call { i64, i64 } @compiler_2feval_2eshl128(i64 %t83, i64 %t84, i64 1)
  store { i64, i64 } %t87, ptr %l65
  br label %bb17
bb17:
  %t88 = load { i64, i64 }, ptr %l65
  store { i64, i64 } %t88, ptr %l15
  %t89 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 0
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t90, ptr %l6, !tbaa !24
  %t92 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  store i64 %t93, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l0, !tbaa !24
  %t96 = load i64, ptr %l1, !tbaa !24
  %t97 = load i64, ptr %l14, !tbaa !24
  %t101 = call { i64, i64 } @compiler_2feval_2eshr128(i64 %t95, i64 %t96, i64 %t97, i1 false)
  store { i64, i64 } %t101, ptr %l71
  br label %bb18
bb18:
  %t102 = load { i64, i64 }, ptr %l71
  store { i64, i64 } %t102, ptr %l16
  %t103 = getelementptr { i64, i64 }, ptr %l16, i32 0, i32 0
  %t104 = load i64, ptr %t103, !tbaa !24
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = and i64 %t104, 1
  %t112 = or i64 %t106, %t109
  store i64 %t112, ptr %l6, !tbaa !24
  %t114 = load i64, ptr %l6, !tbaa !24
  %t115 = load i64, ptr %l7, !tbaa !24
  %t116 = load i64, ptr %l2, !tbaa !24
  %t117 = load i64, ptr %l3, !tbaa !24
  %t122 = call i64 @compiler_2feval_2ecmp128(i64 %t114, i64 %t115, i64 %t116, i64 %t117, i1 false)
  store i64 %t122, ptr %l81
  br label %bb19
bb19:
  %t123 = load i64, ptr %l81, !tbaa !24
  %t124 = icmp sge i64 %t123, 0
  br i1 %t124, label %bb20, label %bb21
bb20:
  %t126 = load i64, ptr %l6, !tbaa !24
  %t127 = load i64, ptr %l7, !tbaa !24
  %t128 = load i64, ptr %l2, !tbaa !24
  %t129 = load i64, ptr %l3, !tbaa !24
  %t134 = call { i64, i64 } @compiler_2feval_2esub128(i64 %t126, i64 %t127, i64 %t128, i64 %t129)
  store { i64, i64 } %t134, ptr %l87
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t135 = load { i64, i64 }, ptr %l87
  store { i64, i64 } %t135, ptr %l18
  %t136 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 0
  %t137 = load i64, ptr %t136, !tbaa !24
  store i64 %t137, ptr %l6, !tbaa !24
  %t139 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 1
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l7, !tbaa !24
  %t142 = load i64, ptr %l14, !tbaa !24
  %t144 = icmp sge i64 %t142, 64
  br i1 %t144, label %bb23, label %bb24
bb23:
  %t146 = load i64, ptr %l5, !tbaa !24
  %t147 = load i64, ptr %l14, !tbaa !24
  %t149 = sub i64 %t147, 64
  store i64 %t149, ptr %l94, !tbaa !24
  %t150 = load i64, ptr %l94, !tbaa !24
  %t151 = load i64, ptr %l94, !tbaa !24
  %t152 = shl i64 1, %t151
  %t155 = or i64 %t146, %t152
  store i64 %t155, ptr %l5, !tbaa !24
  br label %bb25
bb24:
  %t157 = load i64, ptr %l4, !tbaa !24
  %t158 = load i64, ptr %l14, !tbaa !24
  store i64 %t158, ptr %l98, !tbaa !24
  %t159 = load i64, ptr %l98, !tbaa !24
  %t160 = load i64, ptr %l98, !tbaa !24
  %t161 = shl i64 1, %t160
  %t164 = or i64 %t157, %t161
  store i64 %t164, ptr %l4, !tbaa !24
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t166 = load i64, ptr %l12, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l12, !tbaa !24
  br label %bb13
bb28:
  %t170 = load i64, ptr %l4, !tbaa !24
  %t171 = load i64, ptr %l5, !tbaa !24
  %t172 = load i64, ptr %l6, !tbaa !24
  %t173 = load i64, ptr %l7, !tbaa !24
  %t175 = insertvalue { i64, i64, i64, i64 } undef, i64 %t170, 0
  %t177 = insertvalue { i64, i64, i64, i64 } %t175, i64 %t171, 1
  %t179 = insertvalue { i64, i64, i64, i64 } %t177, i64 %t172, 2
  %t181 = insertvalue { i64, i64, i64, i64 } %t179, i64 %t173, 3
  store { i64, i64, i64, i64 } %t181, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64, i64, i64 }, ptr %rv
  ret { i64, i64, i64, i64 } %rr
}

define dso_local void @compiler_2feval_2evBool_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2evFixed_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 11, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2evFloat_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2evFunc_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 7, ptr @G_2ecompiler_2feval_2evFunc, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2evInt_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2feval_2ewideMax(i64 %a0, i1 %a1) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, i64 }
  %l7 = alloca i64
  %l15 = alloca { i64, i64 }
  %l20 = alloca { i64, i64 }
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a1, label %bb1, label %bb2
bb1:
  %t3 = load i64, ptr %l0, !tbaa !24
  %t5 = sub i64 %t3, 1
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb3
bb2:
  %t7 = load i64, ptr %l0, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l7, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t10, 128
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = insertvalue { i64, i64 } undef, i64 -1, 0
  %t15 = insertvalue { i64, i64 } %t14, i64 -1, 1
  store { i64, i64 } %t15, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = call { i64, i64 } @compiler_2feval_2eshl128(i64 1, i64 0, i64 %t17)
  store { i64, i64 } %t19, ptr %l15
  br label %bb7
bb7:
  %t20 = load { i64, i64 }, ptr %l15
  store { i64, i64 } %t20, ptr %l3
  %t21 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 1
  %t25 = load i64, ptr %t24, !tbaa !24
  %t31 = call { i64, i64 } @compiler_2feval_2esub128(i64 %t22, i64 %t25, i64 1, i64 0)
  store { i64, i64 } %t31, ptr %l20
  br label %bb8
bb8:
  %t32 = load { i64, i64 }, ptr %l20
  store { i64, i64 } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2feval_2ewideText(ptr %v0, i64 %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, i64 }
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, i64, i64, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i1
  %l37 = alloca { i64, i64 }
  %l40 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca { i64, i64, i64, i64 }
  %l56 = alloca %"std/prelude/text:StringBuilder"
  %l65 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l90 = alloca ptr
  %l92 = alloca i64
  %l96 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i64
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br i1 %a2, label %bb1, label %bb2
bb1:
  %t3 = load i64, ptr %l1, !tbaa !24
  %t5 = icmp slt i64 %t3, 0
  store i1 %t5, ptr %l29, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb3
bb3:
  %t7 = load i1, ptr %l29, !tbaa !21
  store i1 %t7, ptr %l3, !tbaa !21
  %t8 = load i64, ptr %l0, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  %t12 = load i1, ptr %l3, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l0, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t14, i64 %t15)
  store { i64, i64 } %t18, ptr %l37
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t19 = load { i64, i64 }, ptr %l37
  store { i64, i64 } %t19, ptr %l6
  %t20 = getelementptr { i64, i64 }, ptr %l6, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t23 = getelementptr { i64, i64 }, ptr %l6, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t26 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l40
  br label %bb8
bb8:
  %t27 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l7
  br label %bb9
bb9:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp ne i64 %t28, 0
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = call { i64, i64, i64, i64 } @compiler_2feval_2eudivmod128(i64 %t34, i64 %t35, i64 1000000000000000000, i64 0)
  store { i64, i64, i64, i64 } %t38, ptr %l46
  br label %bb13
bb13:
  %t39 = load { i64, i64, i64, i64 }, ptr %l46
  store { i64, i64, i64, i64 } %t39, ptr %l8
  %t40 = getelementptr { i64, i64, i64, i64 }, ptr %l8, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  store i64 %t41, ptr %l9, !tbaa !24
  %t43 = getelementptr { i64, i64, i64, i64 }, ptr %l8, i32 0, i32 1
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l10, !tbaa !24
  %t46 = getelementptr { i64, i64, i64, i64 }, ptr %l8, i32 0, i32 2
  %t47 = load i64, ptr %t46, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l7, i64 %t47)
  br label %bb14
bb14:
  %t52 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l10, !tbaa !24
  store i64 %t52, ptr %l4, !tbaa !24
  store i64 %t54, ptr %l5, !tbaa !24
  br label %bb15
bb15:
  br label %bb9
bb16:
  %t60 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t60, ptr %l56
  br label %bb17
bb17:
  %t61 = load %"std/prelude/text:StringBuilder", ptr %l56
  store %"std/prelude/text:StringBuilder" %t61, ptr %l14
  %t62 = load i1, ptr %l3, !tbaa !21
  br i1 %t62, label %bb18, label %bb19
bb18:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l14, i8 45)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t68 = call i64 @__olang_fmt_u64(ptr null, i64 %t65)
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  %t70 = call i64 @__olang_fmt_u64(ptr %t69, i64 %t65)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = extractvalue { i64, ptr } %t72, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l14, { i64, ptr } %t79)
  br label %bb22
bb22:
  store i64 0, ptr %l15, !tbaa !24
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t83, ptr %l65
  br label %bb23
bb23:
  %t84 = load i64, ptr %l65, !tbaa !24
  store i64 %t84, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t85 = load i64, ptr %l16, !tbaa !24
  %t86 = load i64, ptr %l15, !tbaa !24
  %t89 = icmp sgt i64 %t85, %t86
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load i64, ptr %l17, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  br i1 %t93, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb29
bb26:
  %t95 = load i64, ptr %l16, !tbaa !24
  %t96 = load i64, ptr %l15, !tbaa !24
  %t99 = sub i64 %t95, %t96
  %t100 = load i64, ptr %l17, !tbaa !24
  %t103 = add i64 %t99, %t100
  %t105 = sub i64 %t103, 1
  %t106 = load i64, ptr %l17, !tbaa !24
  %t109 = sdiv i64 %t105, %t106
  store i64 %t109, ptr %l72, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb28
bb28:
  %t111 = load i64, ptr %l72, !tbaa !24
  store i64 %t111, ptr %l69, !tbaa !24
  br label %bb29
bb29:
  %t112 = load i64, ptr %l69, !tbaa !24
  store i64 %t112, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t113 = load i64, ptr %l19, !tbaa !24
  %t114 = load i64, ptr %l18, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb51
bb32:
  br label %bb33
bb33:
  %t121 = load i64, ptr %l15, !tbaa !24
  %t122 = load i64, ptr %l19, !tbaa !24
  %t123 = load i64, ptr %l17, !tbaa !24
  %t126 = mul i64 %t122, %t123
  %t129 = add i64 %t121, %t126
  store i64 %t129, ptr %l20, !tbaa !24
  store ptr %l7, ptr %l90, !tbaa !29
  %t132 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t132, ptr %l92
  br label %bb34
bb34:
  %t133 = load i64, ptr %l92, !tbaa !24
  %t134 = sub i64 %t133, 1
  %t135 = load i64, ptr %l20, !tbaa !24
  %t138 = sub i64 %t134, %t135
  %t139 = load ptr, ptr %l90, !tbaa !29
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t139, i64 %t138)
  store i64 %t141, ptr %l96
  br label %bb35
bb35:
  %t142 = load i64, ptr %l96, !tbaa !24
  %t144 = call i64 @__olang_fmt_u64(ptr null, i64 %t142)
  %t145 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t144)
  %t146 = call i64 @__olang_fmt_u64(ptr %t145, i64 %t142)
  %t147 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t145, 1
  store { i64, ptr } %t148, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t154 = sub i64 18, %t152
  store i64 %t154, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t156 = load i64, ptr %l23, !tbaa !24
  %t157 = load i64, ptr %l22, !tbaa !24
  %t160 = icmp sgt i64 %t156, %t157
  br i1 %t160, label %bb36, label %bb37
bb36:
  %t162 = load i64, ptr %l24, !tbaa !24
  %t164 = icmp sgt i64 %t162, 0
  br i1 %t164, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb41
bb38:
  %t166 = load i64, ptr %l23, !tbaa !24
  %t167 = load i64, ptr %l22, !tbaa !24
  %t170 = sub i64 %t166, %t167
  %t171 = load i64, ptr %l24, !tbaa !24
  %t174 = add i64 %t170, %t171
  %t176 = sub i64 %t174, 1
  %t177 = load i64, ptr %l24, !tbaa !24
  %t180 = sdiv i64 %t176, %t177
  store i64 %t180, ptr %l108, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb40
bb40:
  %t182 = load i64, ptr %l108, !tbaa !24
  store i64 %t182, ptr %l105, !tbaa !24
  br label %bb41
bb41:
  %t183 = load i64, ptr %l105, !tbaa !24
  store i64 %t183, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb42
bb42:
  %t184 = load i64, ptr %l26, !tbaa !24
  %t185 = load i64, ptr %l25, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb43, label %bb44
bb43:
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t192 = load i64, ptr %l22, !tbaa !24
  %t193 = load i64, ptr %l26, !tbaa !24
  %t194 = load i64, ptr %l24, !tbaa !24
  %t197 = mul i64 %t193, %t194
  %t200 = add i64 %t192, %t197
  store i64 %t200, ptr %l27, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l14, i8 48)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t203 = load i64, ptr %l26, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l26, !tbaa !24
  br label %bb42
bb48:
  %t207 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l14, { i64, ptr } %t207)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  %t210 = load i64, ptr %l19, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l19, !tbaa !24
  br label %bb30
bb51:
  %t215 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l14)
  store { i64, ptr } %t215, ptr %l134
  br label %bb52
bb52:
  %t216 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t216, ptr %l135, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 0
  store i64 %t218, ptr %l136, !tbaa !24
  %t219 = load i64, ptr %l136, !tbaa !24
  %t220 = mul i64 %t219, 1
  %t221 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t220)
  %t222 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  store { i64, ptr } %t223, ptr %l137, !tbaa !27
  %t224 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = load i64, ptr %l136, !tbaa !24
  %t229 = mul i64 %t228, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t225, ptr %t227, i64 %t229, i1 false)
  %t230 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t230, ptr %l135, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t231 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t231, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/eval:Blob" @compiler_2feval_3aBlob_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/eval:Blob"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  store i64 8, ptr %l1, !tbaa !24
  store i1 false, ptr %l2, !tbaa !21
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l11
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l3
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l12
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l4
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l13
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l5
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l14
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l6
  %t11 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l15
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l7
  %t13 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l16
  br label %bb7
bb7:
  %t14 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l8
  %t15 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l17
  br label %bb8
bb8:
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  %t17 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t18 = insertvalue %"compiler/eval:Blob" undef, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 0
  %t19 = load i64, ptr %l1, !tbaa !24
  %t20 = insertvalue %"compiler/eval:Blob" %t18, i64 %t19, 1
  %t21 = load i1, ptr %l2, !tbaa !21
  %t22 = insertvalue %"compiler/eval:Blob" %t20, i1 %t21, 2
  %t23 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t24 = insertvalue %"compiler/eval:Blob" %t22, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, 3
  %t25 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t26 = insertvalue %"compiler/eval:Blob" %t24, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, 4
  %t27 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t28 = insertvalue %"compiler/eval:Blob" %t26, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, 5
  %t29 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t30 = insertvalue %"compiler/eval:Blob" %t28, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, 6
  %t31 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t32 = insertvalue %"compiler/eval:Blob" %t30, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, 7
  %t33 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t34 = insertvalue %"compiler/eval:Blob" %t32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, 8
  %t36 = insertvalue %"compiler/eval:Blob" %t34, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, 9
  store %"compiler/eval:Blob" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Blob", ptr %rv
  ret %"compiler/eval:Blob" %rr
}

define dso_local void @compiler_2feval_3aMachine_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"compiler/eval:Ptr"
  %l13 = alloca i32
  %l14 = alloca { i64, [5 x i64] }
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca i1
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l70 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca i64
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l74 = alloca i64
  %l75 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca i64
  %l80 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca i64
  %l86 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l92 = alloca %"compiler/eval:cfn"
  %l94 = alloca %"compiler/eval:cfn"
  %l107 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l108 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l109 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l110 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l112 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l114 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l115 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l116 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l117 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l118 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l119 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l120 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l121 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l131 = alloca %"compiler/eval:alloc"
  %l133 = alloca %"compiler/eval:alloc"
  %l137 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l138 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l139 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l140 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l141 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l142 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l143 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l144 = alloca %"compiler/eval:frame"
  %l146 = alloca %"compiler/eval:frame"
  %l153 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l154 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l155 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l156 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l157 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l158 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l159 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l163 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l164 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l165 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l166 = alloca %"compiler/source:Span"
  %l167 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l168 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l169 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l170 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l171 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l172 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l173 = alloca %"compiler/source:Span"
  %l174 = alloca %"compiler/eval:Machine"
  %t11 = alloca { i64, [5 x i64] }, align 8
  %t21 = alloca %"compiler/eval:cfn", align 8
  %t28 = alloca i64
  %t45 = alloca i64
  %t62 = alloca i64
  %t79 = alloca i64
  %t158 = alloca i64
  %t194 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i32 %a1, ptr %l3
  store i64 20000000, ptr %l4, !tbaa !24
  store i64 268435456, ptr %l5, !tbaa !24
  store i64 2000, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  store i1 false, ptr %l10, !tbaa !21
  %t5 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l86
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l11
  %t7 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t7, ptr %l12
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t9, ptr %l13, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t11, i32 0, i32 0
  store i64 0, ptr %t12
  %t13 = load { i64, [5 x i64] }, ptr %t11
  store { i64, [5 x i64] } %t13, ptr %l14
  store i1 false, ptr %l15, !tbaa !21
  store i1 false, ptr %l16, !tbaa !21
  %t15 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l90
  br label %bb2
bb2:
  %t16 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l17
  %t17 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l91
  br label %bb3
bb3:
  %t18 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l91
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l18
  call void @llvm.memset.p0.i64(ptr %l92, i8 0, i64 264, i1 false)
  %t19 = icmp sgt i64 64, 0
  br i1 %t19, label %bb4, label %bb5
bb4:
  call void @olang_2eHelperKind_2eZero_2ecompiler_2feval_3acfn(ptr %t21, ptr %v1)
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr %t21, i64 264, i1 false)
  br label %bb6
bb5:
  %t22 = icmp sge i64 64, 0
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @llvm.memmove.p0.p0.i64(ptr %l92, ptr %l94, i64 264, i1 false)
  br label %bb5
bb7:
  %t24 = icmp sle i64 64, 34937015291116575
  br i1 %t24, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_cc08951c194f6b90_8a6bb4cf02ef6404)
  unreachable
bb9:
  %t26 = mul i64 64, 264
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, 64
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr %"compiler/eval:cfn", ptr %t27, i64 %t32
  call void @llvm.memmove.p0.p0.i64(ptr %t34, ptr %l92, i64 264, i1 false)
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 64, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t27, 1
  store { i64, ptr } %t37, ptr %l19, !tbaa !27
  %t39 = icmp sge i64 1024, 0
  br i1 %t39, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_cc08951c194f6b90_8a6bb4cf02ef6404)
  unreachable
bb11:
  %t41 = icmp sle i64 1024, 1152921504606846975
  br i1 %t41, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_dae68cb4e78893bd_9d05ee8fba2ee511)
  unreachable
bb13:
  %t43 = mul i64 1024, 8
  %t44 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t43)
  store i64 0, ptr %t45
  br label %fill.46
fill.46:
  %t49 = load i64, ptr %t45
  %t50 = icmp slt i64 %t49, 1024
  br i1 %t50, label %fillb.47, label %filld.48
fillb.47:
  %t51 = getelementptr i64, ptr %t44, i64 %t49
  store i64 -1, ptr %t51
  %t52 = add i64 %t49, 1
  store i64 %t52, ptr %t45
  br label %fill.46
filld.48:
  %t53 = insertvalue { i64, ptr } undef, i64 1024, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t44, 1
  store { i64, ptr } %t54, ptr %l20, !tbaa !27
  %t56 = icmp sge i64 1024, 0
  br i1 %t56, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_dae68cb4e78893bd_9d05ee8fba2ee511)
  unreachable
bb15:
  %t58 = icmp sle i64 1024, 1152921504606846975
  br i1 %t58, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_345703ed03c4ae7e_2d508d6edb3102f2)
  unreachable
bb17:
  %t60 = mul i64 1024, 8
  %t61 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t60)
  store i64 0, ptr %t62
  br label %fill.63
fill.63:
  %t66 = load i64, ptr %t62
  %t67 = icmp slt i64 %t66, 1024
  br i1 %t67, label %fillb.64, label %filld.65
fillb.64:
  %t68 = getelementptr i64, ptr %t61, i64 %t66
  store i64 -1, ptr %t68
  %t69 = add i64 %t66, 1
  store i64 %t69, ptr %t62
  br label %fill.63
filld.65:
  %t70 = insertvalue { i64, ptr } undef, i64 1024, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t61, 1
  store { i64, ptr } %t71, ptr %l21, !tbaa !27
  %t73 = icmp sge i64 1024, 0
  br i1 %t73, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_345703ed03c4ae7e_2d508d6edb3102f2)
  unreachable
bb19:
  %t75 = icmp sle i64 1024, 1152921504606846975
  br i1 %t75, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_956eea0cec0303b3_853c962c10b536e7)
  unreachable
bb21:
  %t77 = mul i64 1024, 8
  %t78 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t77)
  store i64 0, ptr %t79
  br label %fill.80
fill.80:
  %t83 = load i64, ptr %t79
  %t84 = icmp slt i64 %t83, 1024
  br i1 %t84, label %fillb.81, label %filld.82
fillb.81:
  %t85 = getelementptr i64, ptr %t78, i64 %t83
  store i64 -1, ptr %t85
  %t86 = add i64 %t83, 1
  store i64 %t86, ptr %t79
  br label %fill.80
filld.82:
  %t87 = insertvalue { i64, ptr } undef, i64 1024, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t78, 1
  store { i64, ptr } %t88, ptr %l22, !tbaa !27
  %t90 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %l107
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_956eea0cec0303b3_853c962c10b536e7)
  unreachable
bb23:
  %t91 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l107
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %l23
  %t92 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t92, ptr %l108
  br label %bb24
bb24:
  %t93 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l108
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t93, ptr %l24
  %t94 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %l109
  br label %bb25
bb25:
  %t95 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %l25
  %t96 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %l110
  br label %bb26
bb26:
  %t97 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %l26
  %t98 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %l111
  br label %bb27
bb27:
  %t99 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t99, ptr %l27
  %t100 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %l112
  br label %bb28
bb28:
  %t101 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l112
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t101, ptr %l28
  %t102 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %l113
  br label %bb29
bb29:
  %t103 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l113
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t103, ptr %l29
  %t104 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fmir_3aFnKey_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %l114
  br label %bb30
bb30:
  %t105 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l114
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l30
  %t106 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %l115
  br label %bb31
bb31:
  %t107 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l115
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t107, ptr %l31
  %t108 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKey_3e_26_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %l116
  br label %bb32
bb32:
  %t109 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l116
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t109, ptr %l32
  %t110 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %l117
  br label %bb33
bb33:
  %t111 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l117
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %l33
  %t112 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t112, ptr %l118
  br label %bb34
bb34:
  %t113 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l118
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t113, ptr %l34
  %t114 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %l119
  br label %bb35
bb35:
  %t115 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l119
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %l35
  %t116 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %l120
  br label %bb36
bb36:
  %t117 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l120
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t117, ptr %l36
  %t118 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3adkey_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t118, ptr %l121
  br label %bb37
bb37:
  %t119 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l121
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t119, ptr %l37
  %t120 = icmp sge i64 8192, 0
  br i1 %t120, label %bb38, label %bb39
bb38:
  %t122 = icmp sle i64 8192, 1152921504606846975
  br i1 %t122, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_f8d056d05e46945c_b066e8956734d578)
  unreachable
bb40:
  %t124 = mul i64 8192, 8
  %t125 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 8192, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l38, !tbaa !27
  %t129 = icmp sge i64 8192, 0
  br i1 %t129, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_f8d056d05e46945c_b066e8956734d578)
  unreachable
bb42:
  %t131 = icmp sle i64 8192, 1152921504606846975
  br i1 %t131, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_d51e19176d62df29_641578e9eb8755e5)
  unreachable
bb44:
  %t133 = mul i64 8192, 8
  %t134 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t133)
  %t135 = insertvalue { i64, ptr } undef, i64 8192, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l39, !tbaa !27
  store i64 8, ptr %l40, !tbaa !24
  %t138 = icmp sge i64 64, 0
  br i1 %t138, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_d51e19176d62df29_641578e9eb8755e5)
  unreachable
bb46:
  %t140 = icmp sle i64 64, 1152921504606846975
  br i1 %t140, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_311cf37c7f5d32ea_160682b5288055c6)
  unreachable
bb48:
  %t142 = mul i64 64, 8
  %t143 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 64, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  store { i64, ptr } %t145, ptr %l41, !tbaa !27
  store %"compiler/eval:alloc" zeroinitializer, ptr %l131
  %t147 = icmp sgt i64 1024, 0
  br i1 %t147, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_311cf37c7f5d32ea_160682b5288055c6)
  unreachable
bb50:
  %t149 = call %"compiler/eval:alloc" @olang_2eHelperKind_2eZero_2ecompiler_2feval_3aalloc()
  store %"compiler/eval:alloc" %t149, ptr %l133
  br label %bb52
bb51:
  %t150 = icmp sge i64 1024, 0
  br i1 %t150, label %bb53, label %bb54
bb52:
  %t152 = load %"compiler/eval:alloc", ptr %l133
  store %"compiler/eval:alloc" %t152, ptr %l131
  br label %bb51
bb53:
  %t153 = icmp sle i64 1024, 88686269585142075
  br i1 %t153, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_e738991863bfbdbf_25eece77a9bcd95b)
  unreachable
bb55:
  %t155 = mul i64 1024, 104
  %t156 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t155)
  %t157 = load %"compiler/eval:alloc", ptr %l131
  store i64 0, ptr %t158
  br label %fill.159
fill.159:
  %t162 = load i64, ptr %t158
  %t163 = icmp slt i64 %t162, 1024
  br i1 %t163, label %fillb.160, label %filld.161
fillb.160:
  %t164 = getelementptr %"compiler/eval:alloc", ptr %t156, i64 %t162
  store %"compiler/eval:alloc" %t157, ptr %t164
  %t165 = add i64 %t162, 1
  store i64 %t165, ptr %t158
  br label %fill.159
filld.161:
  %t166 = insertvalue { i64, ptr } undef, i64 1024, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t156, 1
  store { i64, ptr } %t167, ptr %l42, !tbaa !27
  store i64 1, ptr %l43, !tbaa !24
  %t169 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t169, ptr %l137
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_e738991863bfbdbf_25eece77a9bcd95b)
  unreachable
bb57:
  %t170 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l137
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, ptr %l44
  %t171 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t171, ptr %l138
  br label %bb58
bb58:
  %t172 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l138
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t172, ptr %l45
  %t173 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t173, ptr %l139
  br label %bb59
bb59:
  %t174 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l139
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t174, ptr %l46
  %t175 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t175, ptr %l140
  br label %bb60
bb60:
  %t176 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l140
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t176, ptr %l47
  %t177 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t177, ptr %l141
  br label %bb61
bb61:
  %t178 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l141
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t178, ptr %l48
  %t179 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t179, ptr %l142
  br label %bb62
bb62:
  %t180 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l142
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %l49
  %t181 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t181, ptr %l143
  br label %bb63
bb63:
  %t182 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l143
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %l50
  store %"compiler/eval:frame" zeroinitializer, ptr %l144
  %t183 = icmp sgt i64 64, 0
  br i1 %t183, label %bb64, label %bb65
bb64:
  %t185 = call %"compiler/eval:frame" @olang_2eHelperKind_2eZero_2ecompiler_2feval_3aframe()
  store %"compiler/eval:frame" %t185, ptr %l146
  br label %bb66
bb65:
  %t186 = icmp sge i64 64, 0
  br i1 %t186, label %bb67, label %bb68
bb66:
  %t188 = load %"compiler/eval:frame", ptr %l146
  store %"compiler/eval:frame" %t188, ptr %l144
  br label %bb65
bb67:
  %t189 = icmp sle i64 64, 72057594037927935
  br i1 %t189, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_64487eeb593bd358_be690252b210c97c)
  unreachable
bb69:
  %t191 = mul i64 64, 128
  %t192 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t191)
  %t193 = load %"compiler/eval:frame", ptr %l144
  store i64 0, ptr %t194
  br label %fill.195
fill.195:
  %t198 = load i64, ptr %t194
  %t199 = icmp slt i64 %t198, 64
  br i1 %t199, label %fillb.196, label %filld.197
fillb.196:
  %t200 = getelementptr %"compiler/eval:frame", ptr %t192, i64 %t198
  store %"compiler/eval:frame" %t193, ptr %t200
  %t201 = add i64 %t198, 1
  store i64 %t201, ptr %t194
  br label %fill.195
filld.197:
  %t202 = insertvalue { i64, ptr } undef, i64 64, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t192, 1
  store { i64, ptr } %t203, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t205 = icmp sge i64 1024, 0
  br i1 %t205, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_64487eeb593bd358_be690252b210c97c)
  unreachable
bb71:
  %t207 = icmp sle i64 1024, 1152921504606846975
  br i1 %t207, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_d6ff74f701ada4c5_c582616f4398d5c9)
  unreachable
bb73:
  %t209 = mul i64 1024, 8
  %t210 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t209)
  %t211 = insertvalue { i64, ptr } undef, i64 1024, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  store { i64, ptr } %t212, ptr %l53, !tbaa !27
  store i64 0, ptr %l54, !tbaa !24
  %t214 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t214, ptr %l153
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_d6ff74f701ada4c5_c582616f4398d5c9)
  unreachable
bb75:
  %t215 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l153
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t215, ptr %l55
  %t216 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t216, ptr %l154
  br label %bb76
bb76:
  %t217 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l154
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t217, ptr %l56
  %t218 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t218, ptr %l155
  br label %bb77
bb77:
  %t219 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l155
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %l57
  %t220 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t220, ptr %l156
  br label %bb78
bb78:
  %t221 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l156
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t221, ptr %l58
  %t222 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t222, ptr %l157
  br label %bb79
bb79:
  %t223 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l157
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t223, ptr %l59
  %t224 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t224, ptr %l158
  br label %bb80
bb80:
  %t225 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l158
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t225, ptr %l60
  %t226 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t226, ptr %l159
  br label %bb81
bb81:
  %t227 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l159
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t227, ptr %l61
  store i1 false, ptr %l62, !tbaa !21
  store i64 0, ptr %l63, !tbaa !24
  store i64 0, ptr %l64, !tbaa !24
  %t228 = icmp sge i64 3, 0
  br i1 %t228, label %bb82, label %bb83
bb82:
  %t230 = icmp sle i64 3, 1152921504606846975
  br i1 %t230, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @olang_loc_d7598e698fcd0229_1ca32a5a713fdca5)
  unreachable
bb84:
  %t232 = mul i64 3, 8
  %t233 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t232)
  %t234 = insertvalue { i64, ptr } undef, i64 3, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  store { i64, ptr } %t235, ptr %l65, !tbaa !27
  store i64 -1, ptr %l66, !tbaa !24
  store i64 0, ptr %l67, !tbaa !24
  %t237 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t237, ptr %l163
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_d7598e698fcd0229_1ca32a5a713fdca5)
  unreachable
bb86:
  %t238 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l163
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %l68
  %t239 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t239, ptr %l164
  br label %bb87
bb87:
  %t240 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l164
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t240, ptr %l69
  %t241 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t241, ptr %l165
  br label %bb88
bb88:
  %t242 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l165
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t242, ptr %l70
  store i64 0, ptr %l71, !tbaa !24
  %t243 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 0, i32 0)
  store %"compiler/source:Span" %t243, ptr %l166
  br label %bb89
bb89:
  %t244 = load %"compiler/source:Span", ptr %l166
  store %"compiler/source:Span" %t244, ptr %l72
  %t245 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t245, ptr %l167
  br label %bb90
bb90:
  %t246 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l167
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t246, ptr %l73
  store i64 -1, ptr %l74, !tbaa !24
  %t247 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t247, ptr %l168
  br label %bb91
bb91:
  %t248 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l168
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t248, ptr %l75
  %t249 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t249, ptr %l169
  br label %bb92
bb92:
  %t250 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l169
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t250, ptr %l76
  %t251 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t251, ptr %l170
  br label %bb93
bb93:
  %t252 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l170
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t252, ptr %l77
  %t253 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t253, ptr %l171
  br label %bb94
bb94:
  %t254 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l171
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t254, ptr %l78
  store i64 0, ptr %l79, !tbaa !24
  %t255 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t255, ptr %l172
  br label %bb95
bb95:
  %t256 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l172
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t256, ptr %l80
  store i64 -1, ptr %l81, !tbaa !24
  %t257 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 0, i32 0)
  store %"compiler/source:Span" %t257, ptr %l173
  br label %bb96
bb96:
  %t258 = load %"compiler/source:Span", ptr %l173
  %t259 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 0
  %t260 = load ptr, ptr %l2, !tbaa !29
  store ptr %t260, ptr %t259, !tbaa !29
  %t261 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 1
  %t262 = load i32, ptr %l3
  store i32 %t262, ptr %t261
  %t263 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 2
  %t264 = load i64, ptr %l4, !tbaa !24
  store i64 %t264, ptr %t263, !tbaa !24
  %t265 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 3
  %t266 = load i64, ptr %l5, !tbaa !24
  store i64 %t266, ptr %t265, !tbaa !24
  %t267 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 4
  %t268 = load i64, ptr %l6, !tbaa !24
  store i64 %t268, ptr %t267, !tbaa !24
  %t269 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 5
  %t270 = load i64, ptr %l7, !tbaa !24
  store i64 %t270, ptr %t269, !tbaa !24
  %t271 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 6
  %t272 = load i64, ptr %l8, !tbaa !24
  store i64 %t272, ptr %t271, !tbaa !24
  %t273 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 7
  %t274 = load i64, ptr %l9, !tbaa !24
  store i64 %t274, ptr %t273, !tbaa !24
  %t275 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 8
  %t276 = load i1, ptr %l10, !tbaa !21
  store i1 %t276, ptr %t275, !tbaa !21
  %t277 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 9
  %t278 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t278, ptr %t277
  %t279 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 10
  %t280 = load %"compiler/eval:Ptr", ptr %l12
  store %"compiler/eval:Ptr" %t280, ptr %t279
  %t281 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 11
  %t282 = load i32, ptr %l13, !tbaa !23
  store i32 %t282, ptr %t281, !tbaa !23
  %t283 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 12
  %t284 = load { i64, [5 x i64] }, ptr %l14
  store { i64, [5 x i64] } %t284, ptr %t283
  %t285 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 13
  %t286 = load i1, ptr %l15, !tbaa !21
  store i1 %t286, ptr %t285, !tbaa !21
  %t287 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 14
  %t288 = load i1, ptr %l16, !tbaa !21
  store i1 %t288, ptr %t287, !tbaa !21
  %t289 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 15
  %t290 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t290, ptr %t289
  %t291 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 16
  %t292 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t292, ptr %t291
  %t293 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 17
  %t294 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t294, ptr %t293, !tbaa !27
  %t295 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 18
  %t296 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t296, ptr %t295, !tbaa !27
  %t297 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 19
  %t298 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t298, ptr %t297, !tbaa !27
  %t299 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 20
  %t300 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t300, ptr %t299, !tbaa !27
  %t301 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 21
  %t302 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t302, ptr %t301
  %t303 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 22
  %t304 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t304, ptr %t303
  %t305 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 23
  %t306 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t306, ptr %t305
  %t307 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 24
  %t308 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t308, ptr %t307
  %t309 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 25
  %t310 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t310, ptr %t309
  %t311 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 26
  %t312 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t312, ptr %t311
  %t313 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 27
  %t314 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t314, ptr %t313
  %t315 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 28
  %t316 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t316, ptr %t315
  %t317 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 29
  %t318 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t318, ptr %t317
  %t319 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 30
  %t320 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t320, ptr %t319
  %t321 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 31
  %t322 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t322, ptr %t321
  %t323 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 32
  %t324 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t324, ptr %t323
  %t325 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 33
  %t326 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t326, ptr %t325
  %t327 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 34
  %t328 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t328, ptr %t327
  %t329 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 35
  %t330 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t330, ptr %t329
  %t331 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 36
  %t332 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t332, ptr %t331, !tbaa !27
  %t333 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 37
  %t334 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t334, ptr %t333, !tbaa !27
  %t335 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 38
  %t336 = load i64, ptr %l40, !tbaa !24
  store i64 %t336, ptr %t335, !tbaa !24
  %t337 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 39
  %t338 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t338, ptr %t337, !tbaa !27
  %t339 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 40
  %t340 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t340, ptr %t339, !tbaa !27
  %t341 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 41
  %t342 = load i64, ptr %l43, !tbaa !24
  store i64 %t342, ptr %t341, !tbaa !24
  %t343 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 42
  %t344 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t344, ptr %t343
  %t345 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 43
  %t346 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t346, ptr %t345
  %t347 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 44
  %t348 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t348, ptr %t347
  %t349 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 45
  %t350 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t350, ptr %t349
  %t351 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 46
  %t352 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t352, ptr %t351
  %t353 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 47
  %t354 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t354, ptr %t353
  %t355 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 48
  %t356 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t356, ptr %t355
  %t357 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 49
  %t358 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t358, ptr %t357, !tbaa !27
  %t359 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 50
  %t360 = load i64, ptr %l52, !tbaa !24
  store i64 %t360, ptr %t359, !tbaa !24
  %t361 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 51
  %t362 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t362, ptr %t361, !tbaa !27
  %t363 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 52
  %t364 = load i64, ptr %l54, !tbaa !24
  store i64 %t364, ptr %t363, !tbaa !24
  %t365 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 53
  %t366 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t366, ptr %t365
  %t367 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 54
  %t368 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t368, ptr %t367
  %t369 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 55
  %t370 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t370, ptr %t369
  %t371 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 56
  %t372 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t372, ptr %t371
  %t373 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 57
  %t374 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t374, ptr %t373
  %t375 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 58
  %t376 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t376, ptr %t375
  %t377 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 59
  %t378 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t378, ptr %t377
  %t379 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 60
  %t380 = load i1, ptr %l62, !tbaa !21
  store i1 %t380, ptr %t379, !tbaa !21
  %t381 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 61
  %t382 = load i64, ptr %l63, !tbaa !24
  store i64 %t382, ptr %t381, !tbaa !24
  %t383 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 62
  %t384 = load i64, ptr %l64, !tbaa !24
  store i64 %t384, ptr %t383, !tbaa !24
  %t385 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 63
  %t386 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t386, ptr %t385, !tbaa !27
  %t387 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 64
  %t388 = load i64, ptr %l66, !tbaa !24
  store i64 %t388, ptr %t387, !tbaa !24
  %t389 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 65
  %t390 = load i64, ptr %l67, !tbaa !24
  store i64 %t390, ptr %t389, !tbaa !24
  %t391 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 66
  %t392 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t392, ptr %t391
  %t393 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 67
  %t394 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l69
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t394, ptr %t393
  %t395 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 68
  %t396 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t396, ptr %t395
  %t397 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 69
  %t398 = load i64, ptr %l71, !tbaa !24
  store i64 %t398, ptr %t397, !tbaa !24
  %t399 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 70
  %t400 = load %"compiler/source:Span", ptr %l72
  store %"compiler/source:Span" %t400, ptr %t399
  %t401 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 71
  %t402 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l73
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t402, ptr %t401
  %t403 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 72
  %t404 = load i64, ptr %l74, !tbaa !24
  store i64 %t404, ptr %t403, !tbaa !24
  %t405 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 73
  %t406 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l75
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t406, ptr %t405
  %t407 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 74
  %t408 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t408, ptr %t407
  %t409 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 75
  %t410 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l77
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t410, ptr %t409
  %t411 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 76
  %t412 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t412, ptr %t411
  %t413 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 77
  %t414 = load i64, ptr %l79, !tbaa !24
  store i64 %t414, ptr %t413, !tbaa !24
  %t415 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 78
  %t416 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t416, ptr %t415
  %t417 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 79
  %t418 = load i64, ptr %l81, !tbaa !24
  store i64 %t418, ptr %t417, !tbaa !24
  %t419 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 80
  store %"compiler/source:Span" %t258, ptr %t419
  %t421 = getelementptr %"compiler/eval:Machine", ptr %l174, i32 0, i32 81
  store i32 0, ptr %t421, !tbaa !23
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l174, i64 784, i1 false)
  br label %ret
ret:
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d0 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"OLANG_DEADREGIONS" }>, align 8
declare void @__olang_ert_req_clear()
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d3 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"it divides the most negative value by -1, which overflows" }>, align 8
@.d4 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"the comparison recurses deeper than compile-time evaluation allows" }>, align 8
@.d5 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"it calls an external function" }>, align 8
@.d6 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"it uses storage early freeing reclaimed (O8d) - a place decided sole was not: a compiler bug" }>, align 8
@.d7 = private constant <{ i64, [84 x i8] }> <{ i64 0, [84 x i8] c"it reads the bits of a NaN an operation made, whose sign and payload are unspecified" }>, align 8
@.d8 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c"it reads a global whose initializer has not run - one with an error never does" }>, align 8
@.d9 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"it uses a value compile-time evaluation does not model" }>, align 8
@.d10 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"it calls through a null function value" }>, align 8
@.d11 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"it uses a view of a Vec's elements taken before the Vec grew, which shows the old elements" }>, align 8
@.d12 = private constant <{ i64, [103 x i8] }> <{ i64 0, [103 x i8] c"it waits for another task, and interpret runs a join's tasks one after another, never beside each other" }>, align 8
@.d13 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"it writes a global or what one holds, which the running program would then not see written" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"__olang_run_on_stack" }>, align 8
@.d17 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"unhandled error" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"pthread_cond_wait" }>, align 8
@.d20 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"pthread_cond_timedwait" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d24 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"eval_test_" }>, align 8
@.d25 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"eval_test_" }>, align 8
declare i64 @__olang_fmt_u64(ptr, i64)
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
define linkonce_odr void @olang_2eHelperKind_2eZero_2ecompiler_2feval_3acfn(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"compiler/eval:cfn"
  %t1 = alloca %"compiler/eval:cfn", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2feval_3acfn_2ector(ptr %t1, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %t1, i64 264, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l0, i64 264, i1 false)
  br label %ret
ret:
  ret void
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fmir_3aFnKey_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fmir_3aFnKey_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKey_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKey_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3adkey_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2feval_3adkey_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"compiler/eval:alloc" @olang_2eHelperKind_2eZero_2ecompiler_2feval_3aalloc() #0 {
entry:
  %l0 = alloca %"compiler/eval:alloc"
  %rv = alloca %"compiler/eval:alloc"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/eval:alloc" @compiler_2feval_3aalloc_2ector(ptr %t1)
  store %"compiler/eval:alloc" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/eval:alloc", ptr %l0
  store %"compiler/eval:alloc" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:alloc", ptr %rv
  ret %"compiler/eval:alloc" %rr
}

define linkonce_odr %"compiler/eval:frame" @olang_2eHelperKind_2eZero_2ecompiler_2feval_3aframe() #0 {
entry:
  %l0 = alloca %"compiler/eval:frame"
  %rv = alloca %"compiler/eval:frame"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/eval:frame" @compiler_2feval_3aframe_2ector(ptr %t1)
  store %"compiler/eval:frame" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/eval:frame", ptr %l0
  store %"compiler/eval:frame" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:frame", ptr %rv
  ret %"compiler/eval:frame" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2feval_2eB0 = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eslotMask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eForeignId = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_3ascope_2ector(ptr %out, ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2ePush_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0, ptr %a1)
@G_2ecompiler_2feval_2esProgram = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eaValue = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %v0, i64 %a0, i64 %a1)
@G_2ecompiler_2feval_2eNullPtr = available_externally constant <{ [16 x i8] }> <{ [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@G_2ecompiler_2feval_2eSp0 = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eWhyDivMin = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyEqDepth = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyExtern = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyFreedEarly = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyNaNOp = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyNoGlobal = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyNotModelled = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyNullCall = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyStale = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyWaits = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyWritesGlobal = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eaCode = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eaData = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eaFree = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2feval_2eult64(i64 %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
declare { i64, [2 x i64] } @compiler_2feval_2etkey(i64 %a0)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %a0)
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2)
@G_2ecompiler_2feval_2eS0 = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"compiler/mir:Case" @compiler_2fmir_3aCase_2ector(ptr %v0, i64 %a0, i32 %a1)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCases(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Haf69023555548e8239d9db5dde4c25f9(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Hc3dff1927e5c626a9d95abfdf4e9a462(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_H6f34e373626f6b99bb5e62c0fd8bd7a4(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__Hbdd7c5068e376aa260a62181a9f99429(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_Hd8d89e440939766a34c786789c5d3b97(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %v0, i64 %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %a0, %"compiler/eval:gkey" %a1)
@G_2ecompiler_2feval_2eWhyNoBody = external constant <{ [8 x i8], ptr }>
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartGlobal(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunwind(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H5ec116bb82f5a234bb19cb32db1efc81(ptr %v0, ptr %a0)
declare %"std/pair:Pair.9f40551e0d6019a8e678d8f53048b6ba" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H1a77801a5ab3ea58cbf0ff15b43ff2de(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2eWhyLong = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyMemory = external constant <{ [8 x i8], ptr }>
declare i64 @compiler_2feval_2eclassOf(i64 %a0)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewSlot(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0, i64 %a1, ptr %a2)
@G_2ecompiler_2feval_2eslotBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\18\00\00\00\00\00\00\00" }>, align 8
declare { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eOwning = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2escratchFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2, i64 %a3)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2econvertArray(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, { i64, [4 x i64] } %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i64 %a3)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eprimWide(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, i32 %a4, %"compiler/mir:Range" %a5)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eprim(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, %"compiler/mir:Range" %a4)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2, i64 %a3)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoverflowsWide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, %"compiler/mir:Range" %a4)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoverflows(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, %"compiler/mir:Range" %a4)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2etagOf(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaggregate(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, i64 %a4, %"compiler/mir:Range" %a5)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eclosure(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, { i64, [2 x i64] } %a3, { i64, [1 x i64] } %a4, %"compiler/mir:Range" %a5)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2)
@G_2ecompiler_2feval_2esRegion = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eadopt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2)
@olang_loc_140721f2aee0298e_beee5014d741f7d2 = external constant [0 x i8]
@olang_loc_40e1a1a182bd943_2fb0eb1e2dc82487 = external constant [0 x i8]
@G_2ecompiler_2feval_2evInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evUint = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evWide = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_3acfn_2ector(ptr %out, ptr %v0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eToArray_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eToArra_H6fd2d5f022de1d6918789edb46830007(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eToArray_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eToArray_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eToArray_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eToArray_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eLen_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0)
@olang_loc_241753625ba0fed0_6f3de102ac38e444 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
@olang_loc_dff38e562927abfd_2c5e94ab37a21251 = external constant [0 x i8]
@G_2ecompiler_2feval_2efastStride = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@olang_loc_f974da260d2147be_261330901ffea532 = external constant [0 x i8]
@olang_loc_d12e80ad37c716f3_175b69241b7dc127 = external constant [0 x i8]
@olang_loc_b7a31071d3fea69c_48dc013a177eb8 = external constant [0 x i8]
@olang_loc_3b5c2c57d838d869_14cf45850b137925 = external constant [0 x i8]
@olang_loc_8cc95a5d9353ea2a_915fe4a94e905706 = external constant [0 x i8]
@olang_loc_82df08a25f1b1bff_dd8fde79650f209b = external constant [0 x i8]
declare { i64, [21 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aStmt_3e_2eAt_3ccompiler_2fmir_3aStmt_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feval_2etermNamesGlobal(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
@olang_loc_1d233abf61feac98_d906727ad02ddbc = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ertArrayValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewritesInto(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
@G_2ecompiler_2feval_2erCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2erRequest = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2erGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2erTask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2erClause = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2etoTargets(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [4 x i64] } %a3, i32 %a4)
@olang_loc_17d12c125f58d820_35ade4b878109a14 = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eenter(ptr %v0, ptr %a0, i64 %a1, { i64, [7 x i64] } %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4, i64 %a5, i64 %a6)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallExtern(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, %"compiler/mir:Range" %a4, %"compiler/eval:Ptr" %a5, i1 %a6)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ejump(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@olang_loc_b477747d616f01f0_6d4a3c12dca1cf4c = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2)
@G_2ecompiler_2feval_2efConst = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efCopy = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2efLoad = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@olang_loc_2c3649ec7760d571_b360c53de5a7362d = external constant [0 x i8]
@olang_loc_2911fcc0ca845160_1e3fd4941e69567c = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatOperand(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [4 x i64] } %a2, ptr %a3, i64 %a4, i64 %a5)
@G_2ecompiler_2feval_2efUn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efBin = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2feval_2ewordOp(i32 %a0)
@olang_loc_d5c2e2db698a665b_3103939d027c3c37 = external constant [0 x i8]
@olang_loc_dc43aa71d8d9c75a_2151ed02c3c5ad16 = external constant [0 x i8]
@olang_loc_e714ed8eb9bc4bed_d75d9a728369dbb1 = external constant [0 x i8]
@G_2ecompiler_2feval_2efStore = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@olang_loc_be4b7d7361ea403c_360f852de4aa57a0 = external constant [0 x i8]
@olang_loc_c543a46c12bf3f7_90f0fb430875159b = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatCompare(ptr %v0, ptr %a0, i32 %a1, double %a2, double %a3)
@olang_loc_d784dcd9713515f8_b9d041eddaa630c = external constant [0 x i8]
@olang_loc_d2031ca5bdc3c0c9_c1504039d0cd1a3d = external constant [0 x i8]
@olang_loc_82c834935ab97012_8fe8672257be0a6 = external constant [0 x i8]
@olang_loc_463be9bfcfc802eb_383f1498b2d4337 = external constant [0 x i8]
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecalleeType(ptr %v0, ptr %a0, i64 %a1, { i64, [7 x i64] } %a2)
@olang_loc_8ee299e344af3927_1a30263e89afea2b = external constant [0 x i8]
@olang_loc_9d9a614f49301d32_780986365d0a3a16 = external constant [0 x i8]
@G_2ecompiler_2fmir_2eI64T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
@olang_loc_d3df02eef027536f_dc15be465081b3fb = external constant [0 x i8]
declare { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2epack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2feval_2eWhyClosed = external constant <{ [8 x i8], ptr }>
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2, i1 %a3)
@olang_loc_b24244fd0a11c914_466201095dcd7a18 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
@G_2ecompiler_2feval_2evFloat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i32 %a4, i32 %a5)
@G_2ecompiler_2feval_2evBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_590198b1bba6f342_437268d8e9153c4e = external constant [0 x i8]
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eobjectAt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d4aeb51afef739b6_d573fd1fa5ffe912 = external constant [0 x i8]
@G_2ecompiler_2feval_2evAgg = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evFixed = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputData(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, i32 %a4, i64 %a5, %"compiler/source:Span" %a6)
@olang_loc_af1f9cfaa1609478_d5c4fc0e8d836404 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeMutable(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/mir:Range" %a2)
@olang_loc_5132488ea4d5a24a_c872bd4e98b932a6 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2eErrorCode(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
@G_2ecompiler_2feval_2evPair = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLayoutState(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eLaidOut = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoLayout = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_a19345797ce3092f_df897154cd0b0613 = external constant [0 x i8]
@olang_loc_8629e3295afcf15a_58f771f6fdbc30de = external constant [0 x i8]
@olang_loc_985556dab320f6d9_efe4e1681fb7461d = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshapeOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2eWhyOutside = external constant <{ [8 x i8], ptr }>
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKe_H6a636ae5a18dc9bdacf7dd1692df3f31(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e__H9861f6f09602cf23d49075e82ac9429b(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodePtr(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreeTask(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_da2497658df77092_f2a1f3138ef6e43e = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskLayout(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/mir:Task" %a2, i64 %a3)
declare %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1763d3aa4dbf9a93_91ae1790a76dd73f = external constant [0 x i8]
@olang_loc_2ee13faba4731678_f9595c1938ce6204 = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2estop(ptr %v0, ptr %v1, ptr %a0, { i64, [5 x i64] } %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eexit(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i32 %a4, { i64, [4 x i64] } %a5)
@G_2ecompiler_2feval_2eWhyNoClause = external constant <{ [8 x i8], ptr }>
@olang_loc_295f7f77f101c149_2aa6184739b6cdf5 = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeReady(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/mir:Range" %a3)
declare { i64, %"compiler/eval:Ptr", i1, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallee(ptr %v0, ptr %a0, i64 %a1, { i64, [7 x i64] } %a2)
@olang_loc_f83a50064779c123_fa52c016159405ff = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eleave(ptr %v0, ptr %a0, i64 %a1, i1 %a2, { i64, [4 x i64] } %a3, i64 %a4)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2esuspend(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/mir:Range" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eSetAt_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_44d04288ad1da022_22f50395241cffe = external constant [0 x i8]
@olang_loc_176c1f0c53cca04e_ded73198e701b2e2 = external constant [0 x i8]
@G_2ecompiler_2feval_2etRaised = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2etCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2etraceKept = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\00\00\00\00\00\00\00" }>, align 8
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eRaiseText(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_bb58ffa16789d1e6_53f99027aa0e2dd2 = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartTask(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2feval_2etJoin = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2efailedHere(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eLen_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0)
@olang_loc_20ebca0cc3ca1941_2aa025308f8b0e8d = external constant [0 x i8]
@olang_loc_2742cef73dca1807_235d65ef4c242d83 = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunmark(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrRaw(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
@olang_loc_4d14e07bfe4410cd_6dafb030c3a12d39 = external constant [0 x i8]
@olang_loc_9c829c68892d289c_3e4192d6cd213d68 = external constant [0 x i8]
@olang_loc_ddb187b0a77b9dd7_fe6fb794d8e15443 = external constant [0 x i8]
@olang_loc_67473c0be830e037_6373d6aa11f96063 = external constant [0 x i8]
@G_2ecompiler_2feval_2egDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2feval_2eplaceNamesGlobal(%"compiler/mir:Lvalue" %a0)
@olang_loc_a1e0d3359bcb436b_ac2861f14772b5df = external constant [0 x i8]
@olang_loc_c25b9553ef801192_ed4b8566966f1316 = external constant [0 x i8]
@G_2ecompiler_2feval_2esInert = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esStore = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2feval_2erangeNamesGlobal(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
@olang_loc_5c3972130c0b0906_e6fe5489c867bc1a = external constant [0 x i8]
@olang_loc_108ebfb6784b13e7_2381776f1f64d61b = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddScope(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, %"compiler/source:Span" %a4, i32 %a5)
declare void @compiler_2feval_2etprim(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3, i32 %a4, { i64, [4 x i64] } %a5, { i64, [4 x i64] } %a6)
declare %"compiler/mir:Lvalue" @compiler_2feval_2etl(i64 %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddModule(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fmir_3aFn_2ector(ptr %out, ptr %v0, { i64, [2 x i64] } %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddParam(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3)
@G_2ecompiler_2fmir_2eNoScope = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare { i64, i64 } @compiler_2feval_2eshr128(i64 %a0, i64 %a1, i64 %a2, i1 %a3)
declare { i64, i64 } @compiler_2feval_2esub128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
@G_2ecompiler_2feval_2evFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare { i64, i64 } @compiler_2feval_2eneg128(i64 %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_cc08951c194f6b90_8a6bb4cf02ef6404 = external constant [0 x i8]
@olang_loc_dae68cb4e78893bd_9d05ee8fba2ee511 = external constant [0 x i8]
@olang_loc_345703ed03c4ae7e_2d508d6edb3102f2 = external constant [0 x i8]
@olang_loc_956eea0cec0303b3_853c962c10b536e7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_f8d056d05e46945c_b066e8956734d578 = external constant [0 x i8]
@olang_loc_d51e19176d62df29_641578e9eb8755e5 = external constant [0 x i8]
@olang_loc_311cf37c7f5d32ea_160682b5288055c6 = external constant [0 x i8]
@olang_loc_e738991863bfbdbf_25eece77a9bcd95b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_64487eeb593bd358_be690252b210c97c = external constant [0 x i8]
@olang_loc_d6ff74f701ada4c5_c582616f4398d5c9 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_d7598e698fcd0229_1ca32a5a713fdca5 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler_2fsource_3aSpan_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compiler_2fmir_3aFnKey_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3ccompiler_2fmir_3aFnKey_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2feval_3adkey_2c_20I64_3e_2ector(ptr %v0)
declare %"compiler/eval:alloc" @compiler_2feval_3aalloc_2ector(ptr %v0)
declare %"compiler/eval:frame" @compiler_2feval_3aframe_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
