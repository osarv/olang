; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:DerivedArg" = type { i64, i64, { i64, [2 x i64] } }
%"compiler/typed:LastUses" = type { i64, { i64, ptr }, { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i32, i1, i1 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:argRoot" = type { i64, i1 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:LostStores" = type { i32, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:wordReader" = type { { i64, ptr }, { ptr, ptr }, i64 }
%"compiler/typed:Nodes" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Versions" = type { ptr, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/typed:dropWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:holdWalk" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local i32 @compiler_2ftyped_2ePlan_2ereadHead(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l37 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l45 = alloca i64
  %l49 = alloca %"compiler/typed:Plan"
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i1
  %l58 = alloca i1
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i1
  %l67 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i1
  %l78 = alloca { i64, ptr }
  %l80 = alloca i32
  %l83 = alloca { i64, ptr }
  %l85 = alloca i32
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l93 = alloca i64
  %l97 = alloca { i64, ptr }
  %l99 = alloca i32
  %l102 = alloca { i64, ptr }
  %l104 = alloca i32
  %l107 = alloca { i64, ptr }
  %l109 = alloca i32
  %l112 = alloca { i64, ptr }
  %l114 = alloca i32
  %l117 = alloca { i64, ptr }
  %l118 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l120 = alloca i64
  %l122 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i32
  %l133 = alloca i64
  %l134 = alloca { i64, ptr }
  %l135 = alloca i64
  %l136 = alloca i64
  %l140 = alloca { i64, ptr }
  %l141 = alloca i64
  %l142 = alloca i32
  %l143 = alloca i64
  %l144 = alloca i32
  %l148 = alloca i1
  %l154 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l155 = alloca { i64, ptr }
  %l157 = alloca i64
  %l160 = alloca i64
  %l161 = alloca i64
  %l166 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l177 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca { i64, [2 x i64] }
  %l182 = alloca { i64, [2 x i64] }
  %l183 = alloca i32
  %l188 = alloca ptr
  %l191 = alloca i32
  %l193 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l199 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l201 = alloca i64
  %l203 = alloca i64
  %l208 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l213 = alloca i64
  %l216 = alloca ptr
  %l217 = alloca i64
  %l219 = alloca { i64, ptr }
  %l220 = alloca i64
  %l221 = alloca i32
  %l222 = alloca i64
  %l223 = alloca i32
  %l225 = alloca ptr
  %l226 = alloca i64
  %l228 = alloca { i64, ptr }
  %l229 = alloca i64
  %l230 = alloca i32
  %l231 = alloca i64
  %l232 = alloca i32
  %l238 = alloca { i64, ptr }
  %l239 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l241 = alloca i64
  %l243 = alloca i64
  %l248 = alloca { i64, ptr }
  %l249 = alloca i64
  %l251 = alloca i64
  %l252 = alloca i32
  %l254 = alloca i64
  %l255 = alloca { i64, ptr }
  %l256 = alloca i64
  %l257 = alloca i64
  %l261 = alloca { i64, ptr }
  %l262 = alloca i64
  %l263 = alloca i32
  %l264 = alloca i64
  %l265 = alloca i32
  %l267 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l268 = alloca { i64, ptr }
  %l270 = alloca i64
  %l273 = alloca i64
  %l274 = alloca i64
  %l279 = alloca { i64, ptr }
  %l286 = alloca { i64, ptr }
  %l290 = alloca i1
  %l292 = alloca { i64, ptr }
  %l293 = alloca ptr
  %l295 = alloca i64
  %l298 = alloca i64
  %l300 = alloca { i64, ptr }
  %l301 = alloca i64
  %l302 = alloca i32
  %l303 = alloca i64
  %l304 = alloca i32
  %l306 = alloca i64
  %l308 = alloca { i64, ptr }
  %l309 = alloca i64
  %l310 = alloca i32
  %l311 = alloca i64
  %l312 = alloca i32
  %l314 = alloca ptr
  %l315 = alloca i64
  %l316 = alloca i64
  %l317 = alloca { i64, [2 x i64] }
  %l318 = alloca { i64, ptr }
  %l320 = alloca { i64, ptr }
  %l321 = alloca i64
  %l323 = alloca { i64, ptr }
  %l326 = alloca i64
  %l329 = alloca i64
  %l330 = alloca i64
  %l335 = alloca { i64, [2 x i64] }
  %l336 = alloca i32
  %l338 = alloca %"compiler/typed:DerivedArg"
  %l350 = alloca %"compiler/typed:Plan"
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca i32
  %t30 = alloca %"compiler/typed:Plan", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %a1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l34
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t5 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v1, ptr %s0, { i64, ptr } %t4)
  store ptr %t5, ptr %l35
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l35, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t7)
  store i64 %t9, ptr %l37
  br label %bb3
bb3:
  %t10 = load i64, ptr %l37, !tbaa !24
  %t11 = icmp ne i64 %t10, 7
  br i1 %t11, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t14, i64 0)
  store { i64, ptr } %t16, ptr %l41
  br label %bb7
bb7:
  %t17 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t18 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store { i64, ptr } %t18, ptr %l42
  br label %bb8
bb8:
  %t19 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t20 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0, ptr %s0, { i64, ptr } %t19)
  store ptr %t20, ptr %l43
  br label %bb9
bb9:
  %t21 = load ptr, ptr %l43, !tbaa !29
  store ptr %t21, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t22)
  store i64 %t24, ptr %l45
  br label %bb10
bb10:
  %t25 = load i64, ptr %l45, !tbaa !24
  %t26 = icmp ne i64 %t25, 3
  br i1 %t26, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  call void @compiler_2ftyped_2ePlan_2eNew(ptr %t30, ptr %v0, ptr %v2, ptr %a0)
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t30, i64 584, i1 false)
  br label %bb14
bb14:
  %t32 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 584, i64 8)
  store ptr %t32, ptr %lp4
  %t33 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %l49, i64 584, i1 false)
  %t34 = load ptr, ptr %lp4
  %t35 = getelementptr %"compiler/typed:Plan", ptr %t34, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t40 = call i64 @__olang_fmt_i64(ptr null, i64 %t38)
  %t41 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t40)
  %t42 = call i64 @__olang_fmt_i64(ptr %t41, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  store { i64, ptr } %t44, ptr %l53, !tbaa !27
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t46, i64 0)
  store { i64, ptr } %t48, ptr %l55
  br label %bb15
bb15:
  %t49 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t49, { i64, ptr } %t50)
  store i1 %t51, ptr %l56
  br label %bb16
bb16:
  %t52 = load i1, ptr %l56, !tbaa !21
  %t53 = xor i1 %t52, true
  br i1 %t53, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb21
bb18:
  %t55 = load ptr, ptr %lp4
  %t56 = getelementptr %"compiler/typed:Plan", ptr %t55, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t61 = call i64 @__olang_fmt_i64(ptr null, i64 %t59)
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  %t63 = call i64 @__olang_fmt_i64(ptr %t62, i64 %t59)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  store { i64, ptr } %t65, ptr %l62, !tbaa !27
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t67, i64 1)
  store { i64, ptr } %t69, ptr %l64
  br label %bb19
bb19:
  %t70 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t70, { i64, ptr } %t71)
  store i1 %t72, ptr %l65
  br label %bb20
bb20:
  %t73 = load i1, ptr %l65, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l58, !tbaa !21
  br label %bb21
bb21:
  %t76 = load i1, ptr %l58, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb26
bb23:
  %t77 = load ptr, ptr %lp4
  %t78 = getelementptr %"compiler/typed:Plan", ptr %t77, i32 0, i32 2
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t83 = call i64 @__olang_fmt_i64(ptr null, i64 %t81)
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  %t85 = call i64 @__olang_fmt_i64(ptr %t84, i64 %t81)
  %t86 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t84, 1
  store { i64, ptr } %t87, ptr %l71, !tbaa !27
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t89, i64 2)
  store { i64, ptr } %t91, ptr %l73
  br label %bb24
bb24:
  %t92 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t94 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t92, { i64, ptr } %t93)
  store i1 %t94, ptr %l74
  br label %bb25
bb25:
  %t95 = load i1, ptr %l74, !tbaa !21
  %t96 = xor i1 %t95, true
  store i1 %t96, ptr %l67, !tbaa !21
  br label %bb26
bb26:
  %t98 = load i1, ptr %l67, !tbaa !21
  br i1 %t98, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t100, i64 1)
  store { i64, ptr } %t102, ptr %l78
  br label %bb30
bb30:
  %t103 = load ptr, ptr %lp4
  %t104 = getelementptr %"compiler/typed:Plan", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t108 = call i32 @compiler_2ftyped_2ereadScopes(ptr %s0, ptr %v2, { i64, ptr } %t106, { i64, ptr } %t105)
  store i32 %t108, ptr %l80
  %t109 = icmp ne i32 %t108, 0
  br i1 %t109, label %bb32, label %ok.110, !prof !99
ok.110:
  br label %bb31
bb31:
  br label %bb33
bb32:
  %t111 = load i32, ptr %l80, !tbaa !23
  %t112 = lshr i32 %t111, 16
  %t113 = and i32 %t111, 65535
  %t114 = icmp eq i32 %t112, 1
  %t115 = select i1 %t114, i32 1, i32 0
  %t116 = icmp eq i32 %t111, 0
  %t117 = shl i32 %t115, 16
  %t118 = or i32 %t117, %t113
  %t119 = select i1 %t116, i32 0, i32 %t118
  call void @__olang_scope_close(ptr %s0)
  store i32 %t119, ptr %rv
  br label %ret
bb33:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t121, i64 2)
  store { i64, ptr } %t123, ptr %l83
  br label %bb34
bb34:
  %t124 = load ptr, ptr %lp4
  %t125 = getelementptr %"compiler/typed:Plan", ptr %t124, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t129 = call i32 @compiler_2ftyped_2ereadScopes(ptr %s0, ptr %v2, { i64, ptr } %t127, { i64, ptr } %t126)
  store i32 %t129, ptr %l85
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb36, label %ok.131, !prof !99
ok.131:
  br label %bb35
bb35:
  br label %bb37
bb36:
  %t132 = load i32, ptr %l85, !tbaa !23
  %t133 = lshr i32 %t132, 16
  %t134 = and i32 %t132, 65535
  %t135 = icmp eq i32 %t133, 1
  %t136 = select i1 %t135, i32 1, i32 0
  %t137 = icmp eq i32 %t132, 0
  %t138 = shl i32 %t136, 16
  %t139 = or i32 %t138, %t134
  %t140 = select i1 %t137, i32 0, i32 %t139
  call void @__olang_scope_close(ptr %s0)
  store i32 %t140, ptr %rv
  br label %ret
bb37:
  %t142 = load ptr, ptr %l2, !tbaa !29
  %t144 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t142, i64 3)
  store { i64, ptr } %t144, ptr %l88
  br label %bb38
bb38:
  %t145 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t146 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s0, { i64, ptr } %t145)
  store { i64, ptr } %t146, ptr %l89
  br label %bb39
bb39:
  %t147 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t148 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t147, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store { i64, ptr } %t148, ptr %l90
  br label %bb40
bb40:
  %t149 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t150 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0, ptr %s0, { i64, ptr } %t149)
  store ptr %t150, ptr %l91
  br label %bb41
bb41:
  %t151 = load ptr, ptr %l91, !tbaa !29
  store ptr %t151, ptr %l5, !tbaa !29
  %t152 = load ptr, ptr %l5, !tbaa !29
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t152)
  store i64 %t154, ptr %l93
  br label %bb42
bb42:
  %t155 = load i64, ptr %l93, !tbaa !24
  %t156 = icmp ne i64 %t155, 4
  br i1 %t156, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t159 = load ptr, ptr %l5, !tbaa !29
  %t161 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t159, i64 0)
  store { i64, ptr } %t161, ptr %l97
  br label %bb46
bb46:
  %t162 = load ptr, ptr %lp4
  %t163 = getelementptr %"compiler/typed:Plan", ptr %t162, i32 0, i32 2
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t167 = call i32 @compiler_2ftyped_2ereadBits(ptr %s0, ptr %v2, { i64, ptr } %t165, { i64, ptr } %t164)
  store i32 %t167, ptr %l99
  %t168 = icmp ne i32 %t167, 0
  br i1 %t168, label %bb48, label %ok.169, !prof !99
ok.169:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t170 = load i32, ptr %l99, !tbaa !23
  %t171 = lshr i32 %t170, 16
  %t172 = and i32 %t170, 65535
  %t173 = icmp eq i32 %t171, 1
  %t174 = select i1 %t173, i32 1, i32 0
  %t175 = icmp eq i32 %t170, 0
  %t176 = shl i32 %t174, 16
  %t177 = or i32 %t176, %t172
  %t178 = select i1 %t175, i32 0, i32 %t177
  call void @__olang_scope_close(ptr %s0)
  store i32 %t178, ptr %rv
  br label %ret
bb49:
  %t180 = load ptr, ptr %l5, !tbaa !29
  %t182 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t180, i64 1)
  store { i64, ptr } %t182, ptr %l102
  br label %bb50
bb50:
  %t183 = load ptr, ptr %lp4
  %t184 = getelementptr %"compiler/typed:Plan", ptr %t183, i32 0, i32 3
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t188 = call i32 @compiler_2ftyped_2ereadBits(ptr %s0, ptr %v2, { i64, ptr } %t186, { i64, ptr } %t185)
  store i32 %t188, ptr %l104
  %t189 = icmp ne i32 %t188, 0
  br i1 %t189, label %bb52, label %ok.190, !prof !99
ok.190:
  br label %bb51
bb51:
  br label %bb53
bb52:
  %t191 = load i32, ptr %l104, !tbaa !23
  %t192 = lshr i32 %t191, 16
  %t193 = and i32 %t191, 65535
  %t194 = icmp eq i32 %t192, 1
  %t195 = select i1 %t194, i32 1, i32 0
  %t196 = icmp eq i32 %t191, 0
  %t197 = shl i32 %t195, 16
  %t198 = or i32 %t197, %t193
  %t199 = select i1 %t196, i32 0, i32 %t198
  call void @__olang_scope_close(ptr %s0)
  store i32 %t199, ptr %rv
  br label %ret
bb53:
  %t201 = load ptr, ptr %l5, !tbaa !29
  %t203 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t201, i64 2)
  store { i64, ptr } %t203, ptr %l107
  br label %bb54
bb54:
  %t204 = load ptr, ptr %lp4
  %t205 = getelementptr %"compiler/typed:Plan", ptr %t204, i32 0, i32 5
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t209 = call i32 @compiler_2ftyped_2ereadBits(ptr %s0, ptr %v2, { i64, ptr } %t207, { i64, ptr } %t206)
  store i32 %t209, ptr %l109
  %t210 = icmp ne i32 %t209, 0
  br i1 %t210, label %bb56, label %ok.211, !prof !99
ok.211:
  br label %bb55
bb55:
  br label %bb57
bb56:
  %t212 = load i32, ptr %l109, !tbaa !23
  %t213 = lshr i32 %t212, 16
  %t214 = and i32 %t212, 65535
  %t215 = icmp eq i32 %t213, 1
  %t216 = select i1 %t215, i32 1, i32 0
  %t217 = icmp eq i32 %t212, 0
  %t218 = shl i32 %t216, 16
  %t219 = or i32 %t218, %t214
  %t220 = select i1 %t217, i32 0, i32 %t219
  call void @__olang_scope_close(ptr %s0)
  store i32 %t220, ptr %rv
  br label %ret
bb57:
  %t222 = load ptr, ptr %l5, !tbaa !29
  %t224 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t222, i64 3)
  store { i64, ptr } %t224, ptr %l112
  br label %bb58
bb58:
  %t225 = load ptr, ptr %lp4
  %t226 = getelementptr %"compiler/typed:Plan", ptr %t225, i32 0, i32 4
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t230 = call i32 @compiler_2ftyped_2ereadBits(ptr %s0, ptr %v2, { i64, ptr } %t228, { i64, ptr } %t227)
  store i32 %t230, ptr %l114
  %t231 = icmp ne i32 %t230, 0
  br i1 %t231, label %bb60, label %ok.232, !prof !99
ok.232:
  br label %bb59
bb59:
  br label %bb61
bb60:
  %t233 = load i32, ptr %l114, !tbaa !23
  %t234 = lshr i32 %t233, 16
  %t235 = and i32 %t233, 65535
  %t236 = icmp eq i32 %t234, 1
  %t237 = select i1 %t236, i32 1, i32 0
  %t238 = icmp eq i32 %t233, 0
  %t239 = shl i32 %t237, 16
  %t240 = or i32 %t239, %t235
  %t241 = select i1 %t238, i32 0, i32 %t240
  call void @__olang_scope_close(ptr %s0)
  store i32 %t241, ptr %rv
  br label %ret
bb61:
  store %olang.scope zeroinitializer, ptr %s8
  %t243 = load ptr, ptr %l2, !tbaa !29
  %t245 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t243, i64 4)
  store { i64, ptr } %t245, ptr %l117
  br label %bb62
bb62:
  %t246 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t247 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ewordsOf(ptr %s0, ptr %s8, { i64, ptr } %t246)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t247, ptr %l118
  br label %bb63
bb63:
  %t248 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l118
  %t249 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t248, ptr %t249
  store ptr %t249, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s9
  %t251 = load i64, ptr %l7, !tbaa !24
  store i64 %t251, ptr %l120, !tbaa !24
  %t252 = load ptr, ptr %l6, !tbaa !29
  %t254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s8, ptr %t252)
  store i64 %t254, ptr %l122
  br label %bb65
bb65:
  %t255 = load i64, ptr %l120, !tbaa !24
  %t256 = load i64, ptr %l122, !tbaa !24
  %t257 = icmp slt i64 %t255, %t256
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s9)
  br label %bb117
bb67:
  br label %bb68
bb68:
  %t261 = load ptr, ptr %l6, !tbaa !29
  %t262 = load i64, ptr %l7, !tbaa !24
  %t265 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s8, ptr %s8, ptr %t261, i64 %t262)
  store { i64, ptr } %t265, ptr %l127
  br label %bb69
bb69:
  %t266 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t266, ptr %l8, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t269 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s8, ptr %s9, { i64, ptr } %t267, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) })
  %t270 = extractvalue { i32, i64 } %t269, 1
  %t271 = extractvalue { i32, i64 } %t269, 0
  store i32 %t271, ptr %l131
  %t272 = icmp ne i32 %t271, 0
  br i1 %t272, label %bb71, label %ok.273, !prof !99
ok.273:
  store i64 %t270, ptr %l130
  br label %bb70
bb70:
  %t274 = load i64, ptr %l130, !tbaa !24
  store i64 %t274, ptr %l128, !tbaa !24
  br label %bb73
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb73:
  %t276 = load i64, ptr %l128, !tbaa !24
  store i64 %t276, ptr %l9, !tbaa !24
  %t277 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t277, ptr %l134, !tbaa !27
  %t278 = load i64, ptr %l9, !tbaa !24
  store i64 %t278, ptr %l135, !tbaa !24
  %t279 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 0
  store i64 %t280, ptr %l136, !tbaa !24
  %t281 = icmp sge i64 0, 0
  br i1 %t281, label %bb74, label %bb75
bb74:
  %t283 = load i64, ptr %l135, !tbaa !24
  %t284 = icmp sle i64 0, %t283
  br i1 %t284, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_513fe42ccd619edb_f9eefb0210e3c837)
  unreachable
bb76:
  %t286 = load i64, ptr %l135, !tbaa !24
  %t287 = load i64, ptr %l136, !tbaa !24
  %t288 = icmp sle i64 %t286, %t287
  br i1 %t288, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_513fe42ccd619edb_f9eefb0210e3c837)
  unreachable
bb78:
  %t290 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = load i64, ptr %l135, !tbaa !24
  %t293 = getelementptr i8, ptr %t291, i64 0
  %t294 = sub i64 %t292, 0
  %t295 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t293, 1
  store { i64, ptr } %t296, ptr %l140, !tbaa !27
  %t297 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s9, i64 10)
  %t298 = extractvalue { i32, i64 } %t297, 1
  %t299 = extractvalue { i32, i64 } %t297, 0
  store i32 %t299, ptr %l142
  %t300 = icmp ne i32 %t299, 0
  br i1 %t300, label %bb81, label %ok.301, !prof !99
ok.301:
  store i64 %t298, ptr %l141
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_513fe42ccd619edb_f9eefb0210e3c837)
  unreachable
bb80:
  %t302 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t303 = load i64, ptr %l141, !tbaa !24
  %t304 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s8, { i64, ptr } %t302, i64 %t303)
  %t305 = extractvalue { i32, i64 } %t304, 1
  %t306 = extractvalue { i32, i64 } %t304, 0
  store i32 %t306, ptr %l144
  %t307 = icmp ne i32 %t306, 0
  br i1 %t307, label %bb84, label %ok.308, !prof !99
ok.308:
  store i64 %t305, ptr %l143
  br label %bb83
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb83:
  %t310 = load i64, ptr %l143, !tbaa !24
  store i64 %t310, ptr %l133, !tbaa !24
  br label %bb85
bb84:
  br label %bb82
bb85:
  %t311 = load i64, ptr %l133, !tbaa !24
  store i64 %t311, ptr %l10, !tbaa !24
  %t312 = load i64, ptr %l10, !tbaa !24
  %t314 = icmp slt i64 %t312, 0
  br i1 %t314, label %bb86, label %bb87
bb86:
  store i1 true, ptr %l148, !tbaa !21
  br label %bb88
bb87:
  %t316 = load i64, ptr %l10, !tbaa !24
  %t317 = load ptr, ptr %lp4
  %t318 = getelementptr %"compiler/typed:Plan", ptr %t317, i32 0, i32 0
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t324 = icmp sge i64 %t316, %t321
  store i1 %t324, ptr %l148, !tbaa !21
  br label %bb88
bb88:
  %t326 = load i1, ptr %l148, !tbaa !21
  br i1 %t326, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb90:
  br label %bb91
bb91:
  %t328 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %s9, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t328, ptr %l154
  br label %bb92
bb92:
  %t329 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l154
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t329, ptr %l11
  store %olang.scope zeroinitializer, ptr %s13
  %t330 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t330, ptr %l155, !tbaa !27
  %t331 = load i64, ptr %l9, !tbaa !24
  %t333 = add i64 %t331, 1
  store i64 %t333, ptr %l157, !tbaa !24
  %t334 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t334, 0
  store i64 %t337, ptr %l160, !tbaa !24
  %t338 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 0
  store i64 %t339, ptr %l161, !tbaa !24
  %t340 = load i64, ptr %l157, !tbaa !24
  %t341 = icmp sge i64 %t340, 0
  br i1 %t341, label %bb93, label %bb94
bb93:
  %t343 = load i64, ptr %l157, !tbaa !24
  %t344 = load i64, ptr %l160, !tbaa !24
  %t345 = icmp sle i64 %t343, %t344
  br i1 %t345, label %bb95, label %bb96
bb94:
  call void @__olang_check_failed(ptr @olang_loc_f54e407a1957a5de_bac5f2aedbd3a6da)
  unreachable
bb95:
  %t347 = load i64, ptr %l160, !tbaa !24
  %t348 = load i64, ptr %l161, !tbaa !24
  %t349 = icmp sle i64 %t347, %t348
  br i1 %t349, label %bb97, label %bb98
bb96:
  call void @__olang_check_failed(ptr @olang_loc_f54e407a1957a5de_bac5f2aedbd3a6da)
  unreachable
bb97:
  %t351 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = load i64, ptr %l157, !tbaa !24
  %t354 = load i64, ptr %l160, !tbaa !24
  %t355 = getelementptr i8, ptr %t352, i64 %t353
  %t356 = sub i64 %t354, %t353
  %t357 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t355, 1
  %t360 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s8, ptr %s13, ptr %s13, { i64, ptr } %t358, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store { i64, ptr } %t360, ptr %l166
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_f54e407a1957a5de_bac5f2aedbd3a6da)
  unreachable
bb99:
  %t361 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t361, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t362 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  store i64 %t364, ptr %l14, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s14
  %t366 = load i64, ptr %l13, !tbaa !24
  %t367 = load i64, ptr %l14, !tbaa !24
  %t370 = icmp slt i64 %t366, %t367
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s14)
  br label %bb113
bb102:
  br label %bb103
bb103:
  %t374 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t374, ptr %l173, !tbaa !27
  %t375 = load i64, ptr %l13, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr { i64, ptr }, ptr %t378, i64 %t375
  %t380 = load { i64, ptr }, ptr %t379, !tbaa !37
  store { i64, ptr } %t380, ptr %l15, !tbaa !27
  %t382 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t384 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s13, ptr %s14, { i64, ptr } %t382, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t384, ptr %l177
  br label %bb104
bb104:
  %t385 = load i1, ptr %l177, !tbaa !21
  %t386 = xor i1 %t385, true
  br i1 %t386, label %bb105, label %bb106
bb105:
  store ptr %l11, ptr %l179, !tbaa !29
  %t388 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t390 = call { i32, { i64, [2 x i64] } } @compiler_2ftyped_2eScope_2eOfText(ptr %s13, { i64, ptr } %t388)
  %t391 = extractvalue { i32, { i64, [2 x i64] } } %t390, 1
  %t392 = extractvalue { i32, { i64, [2 x i64] } } %t390, 0
  store i32 %t392, ptr %l183
  %t393 = icmp ne i32 %t392, 0
  br i1 %t393, label %bb108, label %ok.394, !prof !99
ok.394:
  store { i64, [2 x i64] } %t391, ptr %l182
  br label %bb107
bb106:
  br label %bb111
bb107:
  %t395 = load { i64, [2 x i64] }, ptr %l182
  store { i64, [2 x i64] } %t395, ptr %l180
  br label %bb109
bb108:
  %t396 = load i32, ptr %l183, !tbaa !23
  %t397 = lshr i32 %t396, 16
  %t398 = and i32 %t396, 65535
  %t399 = icmp eq i32 %t397, 1
  %t400 = select i1 %t399, i32 1, i32 0
  %t401 = icmp eq i32 %t396, 0
  %t402 = shl i32 %t400, 16
  %t403 = or i32 %t402, %t398
  %t404 = select i1 %t401, i32 0, i32 %t403
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t404, ptr %rv
  br label %ret
bb109:
  %t406 = load ptr, ptr %l179, !tbaa !29
  %t407 = load { i64, [2 x i64] }, ptr %l180
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %s9, ptr %t406, { i64, [2 x i64] } %t407)
  br label %bb110
bb110:
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s14)
  br label %bb112
bb112:
  %t408 = load i64, ptr %l13, !tbaa !24
  %t411 = add i64 %t408, 1
  store i64 %t411, ptr %l13, !tbaa !24
  br label %bb100
bb113:
  call void @__olang_scope_close(ptr %s13)
  %t413 = load ptr, ptr %lp4
  store ptr %t413, ptr %l188, !tbaa !29
  %t414 = load i64, ptr %l10, !tbaa !24
  %t416 = trunc i64 %t414 to i32
  store i32 %t416, ptr %l191, !tbaa !23
  %t419 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eToArray_3ccompiler_2ftyped_3aScope_3e(ptr %s9, ptr %s9, ptr %l11)
  store { i64, ptr } %t419, ptr %l193
  br label %bb114
bb114:
  %t420 = load ptr, ptr %l188, !tbaa !29
  %t421 = load i32, ptr %l191, !tbaa !23
  %t422 = load { i64, ptr }, ptr %l193, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v2, ptr %s9, ptr %t420, i32 %t421, { i64, ptr } %t422)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s9)
  br label %bb116
bb116:
  %t423 = load i64, ptr %l7, !tbaa !24
  %t426 = add i64 %t423, 1
  store i64 %t426, ptr %l7, !tbaa !24
  br label %bb64
bb117:
  call void @__olang_scope_close(ptr %s8)
  store %olang.scope zeroinitializer, ptr %s18
  %t428 = load ptr, ptr %l2, !tbaa !29
  %t430 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t428, i64 5)
  store { i64, ptr } %t430, ptr %l198
  br label %bb118
bb118:
  %t431 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t432 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ewordsOf(ptr %s0, ptr %s18, { i64, ptr } %t431)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t432, ptr %l199
  br label %bb119
bb119:
  %t433 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l199
  %t434 = call ptr @__olang_scope_alloc_a(ptr %s18, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t433, ptr %t434
  store ptr %t434, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s19
  %t436 = load i64, ptr %l17, !tbaa !24
  store i64 %t436, ptr %l201, !tbaa !24
  %t437 = load ptr, ptr %l16, !tbaa !29
  %t439 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s18, ptr %t437)
  store i64 %t439, ptr %l203
  br label %bb121
bb121:
  %t440 = load i64, ptr %l201, !tbaa !24
  %t441 = load i64, ptr %l203, !tbaa !24
  %t442 = icmp slt i64 %t440, %t441
  %t444 = xor i1 %t442, true
  br i1 %t444, label %bb122, label %bb123
bb122:
  call void @__olang_scope_close(ptr %s19)
  br label %bb149
bb123:
  br label %bb124
bb124:
  %t446 = load ptr, ptr %l16, !tbaa !29
  %t447 = load i64, ptr %l17, !tbaa !24
  %t450 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s18, ptr %s18, ptr %t446, i64 %t447)
  store { i64, ptr } %t450, ptr %l208
  br label %bb125
bb125:
  %t451 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t454 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s18, ptr %s19, ptr %s18, { i64, ptr } %t451, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store { i64, ptr } %t454, ptr %l210
  br label %bb126
bb126:
  %t455 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t456 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s18, ptr %s19, { i64, ptr } %t455)
  store ptr %t456, ptr %l211
  br label %bb127
bb127:
  %t457 = load ptr, ptr %l211, !tbaa !29
  store ptr %t457, ptr %l19, !tbaa !29
  %t458 = load ptr, ptr %l19, !tbaa !29
  %t460 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s19, ptr %t458)
  store i64 %t460, ptr %l213
  br label %bb128
bb128:
  %t461 = load i64, ptr %l213, !tbaa !24
  %t462 = icmp ne i64 %t461, 2
  br i1 %t462, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb130:
  br label %bb131
bb131:
  %t465 = load ptr, ptr %lp4
  %t466 = getelementptr %"compiler/typed:Plan", ptr %t465, i32 0, i32 17
  store ptr %t466, ptr %l216, !tbaa !29
  %t467 = load ptr, ptr %l19, !tbaa !29
  %t469 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s19, ptr %s19, ptr %t467, i64 0)
  store { i64, ptr } %t469, ptr %l219
  br label %bb132
bb132:
  %t470 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s19, i64 10)
  %t471 = extractvalue { i32, i64 } %t470, 1
  %t472 = extractvalue { i32, i64 } %t470, 0
  store i32 %t472, ptr %l221
  %t473 = icmp ne i32 %t472, 0
  br i1 %t473, label %bb134, label %ok.474, !prof !99
ok.474:
  store i64 %t471, ptr %l220
  br label %bb133
bb133:
  %t475 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t476 = load i64, ptr %l220, !tbaa !24
  %t477 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s19, { i64, ptr } %t475, i64 %t476)
  %t478 = extractvalue { i32, i64 } %t477, 1
  %t479 = extractvalue { i32, i64 } %t477, 0
  store i32 %t479, ptr %l223
  %t480 = icmp ne i32 %t479, 0
  br i1 %t480, label %bb137, label %ok.481, !prof !99
ok.481:
  store i64 %t478, ptr %l222
  br label %bb136
bb134:
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb136:
  %t483 = load i64, ptr %l222, !tbaa !24
  store i64 %t483, ptr %l217, !tbaa !24
  br label %bb138
bb137:
  br label %bb135
bb138:
  %t484 = load ptr, ptr %l216, !tbaa !29
  %t485 = load i64, ptr %l217, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t484, i64 %t485)
  br label %bb139
bb139:
  %t486 = load ptr, ptr %lp4
  %t487 = getelementptr %"compiler/typed:Plan", ptr %t486, i32 0, i32 18
  store ptr %t487, ptr %l225, !tbaa !29
  %t488 = load ptr, ptr %l19, !tbaa !29
  %t490 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s19, ptr %s19, ptr %t488, i64 1)
  store { i64, ptr } %t490, ptr %l228
  br label %bb140
bb140:
  %t491 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s19, i64 10)
  %t492 = extractvalue { i32, i64 } %t491, 1
  %t493 = extractvalue { i32, i64 } %t491, 0
  store i32 %t493, ptr %l230
  %t494 = icmp ne i32 %t493, 0
  br i1 %t494, label %bb142, label %ok.495, !prof !99
ok.495:
  store i64 %t492, ptr %l229
  br label %bb141
bb141:
  %t496 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t497 = load i64, ptr %l229, !tbaa !24
  %t498 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s19, { i64, ptr } %t496, i64 %t497)
  %t499 = extractvalue { i32, i64 } %t498, 1
  %t500 = extractvalue { i32, i64 } %t498, 0
  store i32 %t500, ptr %l232
  %t501 = icmp ne i32 %t500, 0
  br i1 %t501, label %bb145, label %ok.502, !prof !99
ok.502:
  store i64 %t499, ptr %l231
  br label %bb144
bb142:
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb144:
  %t504 = load i64, ptr %l231, !tbaa !24
  store i64 %t504, ptr %l226, !tbaa !24
  br label %bb146
bb145:
  br label %bb143
bb146:
  %t505 = load ptr, ptr %l225, !tbaa !29
  %t506 = load i64, ptr %l226, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t505, i64 %t506)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s19)
  br label %bb148
bb148:
  %t507 = load i64, ptr %l17, !tbaa !24
  %t510 = add i64 %t507, 1
  store i64 %t510, ptr %l17, !tbaa !24
  br label %bb120
bb149:
  call void @__olang_scope_close(ptr %s18)
  store %olang.scope zeroinitializer, ptr %s24
  %t512 = load ptr, ptr %l2, !tbaa !29
  %t514 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t512, i64 6)
  store { i64, ptr } %t514, ptr %l238
  br label %bb150
bb150:
  %t515 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t516 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ewordsOf(ptr %s0, ptr %s24, { i64, ptr } %t515)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t516, ptr %l239
  br label %bb151
bb151:
  %t517 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l239
  %t518 = call ptr @__olang_scope_alloc_a(ptr %s24, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t517, ptr %t518
  store ptr %t518, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb152
bb152:
  store %olang.scope zeroinitializer, ptr %s25
  %t520 = load i64, ptr %l21, !tbaa !24
  store i64 %t520, ptr %l241, !tbaa !24
  %t521 = load ptr, ptr %l20, !tbaa !29
  %t523 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s24, ptr %t521)
  store i64 %t523, ptr %l243
  br label %bb153
bb153:
  %t524 = load i64, ptr %l241, !tbaa !24
  %t525 = load i64, ptr %l243, !tbaa !24
  %t526 = icmp slt i64 %t524, %t525
  %t528 = xor i1 %t526, true
  br i1 %t528, label %bb154, label %bb155
bb154:
  call void @__olang_scope_close(ptr %s25)
  br label %bb227
bb155:
  br label %bb156
bb156:
  %t530 = load ptr, ptr %l20, !tbaa !29
  %t531 = load i64, ptr %l21, !tbaa !24
  %t534 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s24, ptr %s24, ptr %t530, i64 %t531)
  store { i64, ptr } %t534, ptr %l248
  br label %bb157
bb157:
  %t535 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t535, ptr %l22, !tbaa !27
  %t536 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t538 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s24, ptr %s25, { i64, ptr } %t536, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) })
  %t539 = extractvalue { i32, i64 } %t538, 1
  %t540 = extractvalue { i32, i64 } %t538, 0
  store i32 %t540, ptr %l252
  %t541 = icmp ne i32 %t540, 0
  br i1 %t541, label %bb159, label %ok.542, !prof !99
ok.542:
  store i64 %t539, ptr %l251
  br label %bb158
bb158:
  %t543 = load i64, ptr %l251, !tbaa !24
  store i64 %t543, ptr %l249, !tbaa !24
  br label %bb161
bb159:
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb161:
  %t545 = load i64, ptr %l249, !tbaa !24
  store i64 %t545, ptr %l23, !tbaa !24
  %t546 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t546, ptr %l255, !tbaa !27
  %t547 = load i64, ptr %l23, !tbaa !24
  store i64 %t547, ptr %l256, !tbaa !24
  %t548 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t548, 0
  store i64 %t549, ptr %l257, !tbaa !24
  %t550 = icmp sge i64 0, 0
  br i1 %t550, label %bb162, label %bb163
bb162:
  %t552 = load i64, ptr %l256, !tbaa !24
  %t553 = icmp sle i64 0, %t552
  br i1 %t553, label %bb164, label %bb165
bb163:
  call void @__olang_check_failed(ptr @olang_loc_a2b2db9c76964d3d_44f19efa61cd8f79)
  unreachable
bb164:
  %t555 = load i64, ptr %l256, !tbaa !24
  %t556 = load i64, ptr %l257, !tbaa !24
  %t557 = icmp sle i64 %t555, %t556
  br i1 %t557, label %bb166, label %bb167
bb165:
  call void @__olang_check_failed(ptr @olang_loc_a2b2db9c76964d3d_44f19efa61cd8f79)
  unreachable
bb166:
  %t559 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t560 = load ptr, ptr %t559, !tbaa !27
  %t561 = load i64, ptr %l256, !tbaa !24
  %t562 = getelementptr i8, ptr %t560, i64 0
  %t563 = sub i64 %t561, 0
  %t564 = insertvalue { i64, ptr } undef, i64 %t563, 0
  %t565 = insertvalue { i64, ptr } %t564, ptr %t562, 1
  store { i64, ptr } %t565, ptr %l261, !tbaa !27
  %t566 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s25, i64 10)
  %t567 = extractvalue { i32, i64 } %t566, 1
  %t568 = extractvalue { i32, i64 } %t566, 0
  store i32 %t568, ptr %l263
  %t569 = icmp ne i32 %t568, 0
  br i1 %t569, label %bb169, label %ok.570, !prof !99
ok.570:
  store i64 %t567, ptr %l262
  br label %bb168
bb167:
  call void @__olang_check_failed(ptr @olang_loc_a2b2db9c76964d3d_44f19efa61cd8f79)
  unreachable
bb168:
  %t571 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t572 = load i64, ptr %l262, !tbaa !24
  %t573 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s24, { i64, ptr } %t571, i64 %t572)
  %t574 = extractvalue { i32, i64 } %t573, 1
  %t575 = extractvalue { i32, i64 } %t573, 0
  store i32 %t575, ptr %l265
  %t576 = icmp ne i32 %t575, 0
  br i1 %t576, label %bb172, label %ok.577, !prof !99
ok.577:
  store i64 %t574, ptr %l264
  br label %bb171
bb169:
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb171:
  %t579 = load i64, ptr %l264, !tbaa !24
  store i64 %t579, ptr %l254, !tbaa !24
  br label %bb173
bb172:
  br label %bb170
bb173:
  %t580 = load i64, ptr %l254, !tbaa !24
  store i64 %t580, ptr %l24, !tbaa !24
  %t581 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2ector(ptr %s25, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t581, ptr %l267
  br label %bb174
bb174:
  %t582 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l267
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t582, ptr %l25
  store %olang.scope zeroinitializer, ptr %s28
  %t583 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t583, ptr %l268, !tbaa !27
  %t584 = load i64, ptr %l23, !tbaa !24
  %t586 = add i64 %t584, 1
  store i64 %t586, ptr %l270, !tbaa !24
  %t587 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t590 = extractvalue { i64, ptr } %t587, 0
  store i64 %t590, ptr %l273, !tbaa !24
  %t591 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t592 = extractvalue { i64, ptr } %t591, 0
  store i64 %t592, ptr %l274, !tbaa !24
  %t593 = load i64, ptr %l270, !tbaa !24
  %t594 = icmp sge i64 %t593, 0
  br i1 %t594, label %bb175, label %bb176
bb175:
  %t596 = load i64, ptr %l270, !tbaa !24
  %t597 = load i64, ptr %l273, !tbaa !24
  %t598 = icmp sle i64 %t596, %t597
  br i1 %t598, label %bb177, label %bb178
bb176:
  call void @__olang_check_failed(ptr @olang_loc_db138e9723fb9fe0_9822d1289854fb4c)
  unreachable
bb177:
  %t600 = load i64, ptr %l273, !tbaa !24
  %t601 = load i64, ptr %l274, !tbaa !24
  %t602 = icmp sle i64 %t600, %t601
  br i1 %t602, label %bb179, label %bb180
bb178:
  call void @__olang_check_failed(ptr @olang_loc_db138e9723fb9fe0_9822d1289854fb4c)
  unreachable
bb179:
  %t604 = getelementptr { i64, ptr }, ptr %l268, i32 0, i32 1
  %t605 = load ptr, ptr %t604, !tbaa !27
  %t606 = load i64, ptr %l270, !tbaa !24
  %t607 = load i64, ptr %l273, !tbaa !24
  %t608 = getelementptr i8, ptr %t605, i64 %t606
  %t609 = sub i64 %t607, %t606
  %t610 = insertvalue { i64, ptr } undef, i64 %t609, 0
  %t611 = insertvalue { i64, ptr } %t610, ptr %t608, 1
  %t613 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s24, ptr %s28, ptr %s28, { i64, ptr } %t611, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store { i64, ptr } %t613, ptr %l279
  br label %bb181
bb180:
  call void @__olang_check_failed(ptr @olang_loc_db138e9723fb9fe0_9822d1289854fb4c)
  unreachable
bb181:
  %t614 = load { i64, ptr }, ptr %l279, !tbaa !27
  store { i64, ptr } %t614, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t615 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t617 = extractvalue { i64, ptr } %t615, 0
  store i64 %t617, ptr %l28, !tbaa !24
  br label %bb182
bb182:
  store %olang.scope zeroinitializer, ptr %s29
  %t619 = load i64, ptr %l27, !tbaa !24
  %t620 = load i64, ptr %l28, !tbaa !24
  %t623 = icmp slt i64 %t619, %t620
  %t625 = xor i1 %t623, true
  br i1 %t625, label %bb183, label %bb184
bb183:
  call void @__olang_scope_close(ptr %s29)
  br label %bb224
bb184:
  br label %bb185
bb185:
  %t627 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t627, ptr %l286, !tbaa !27
  %t628 = load i64, ptr %l27, !tbaa !24
  %t630 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !27
  %t632 = getelementptr { i64, ptr }, ptr %t631, i64 %t628
  %t633 = load { i64, ptr }, ptr %t632, !tbaa !37
  store { i64, ptr } %t633, ptr %l29, !tbaa !27
  %t635 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t637 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s28, ptr %s29, { i64, ptr } %t635, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t637, ptr %l290
  br label %bb186
bb186:
  %t638 = load i1, ptr %l290, !tbaa !21
  br i1 %t638, label %bb187, label %bb188
bb187:
  call void @__olang_scope_close(ptr %s29)
  br label %bb223
bb188:
  br label %bb189
bb189:
  %t639 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t641 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s28, ptr %s29, ptr %s28, { i64, ptr } %t639, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store { i64, ptr } %t641, ptr %l292
  br label %bb190
bb190:
  %t642 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t643 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s28, ptr %s29, { i64, ptr } %t642)
  store ptr %t643, ptr %l293
  br label %bb191
bb191:
  %t644 = load ptr, ptr %l293, !tbaa !29
  store ptr %t644, ptr %l30, !tbaa !29
  %t645 = load ptr, ptr %l30, !tbaa !29
  %t647 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s29, ptr %t645)
  store i64 %t647, ptr %l295
  br label %bb192
bb192:
  %t648 = load i64, ptr %l295, !tbaa !24
  %t649 = icmp slt i64 %t648, 3
  br i1 %t649, label %bb193, label %bb194
bb193:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb194:
  br label %bb195
bb195:
  %t652 = load ptr, ptr %l30, !tbaa !29
  %t654 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s29, ptr %s29, ptr %t652, i64 0)
  store { i64, ptr } %t654, ptr %l300
  br label %bb196
bb196:
  %t655 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s29, i64 10)
  %t656 = extractvalue { i32, i64 } %t655, 1
  %t657 = extractvalue { i32, i64 } %t655, 0
  store i32 %t657, ptr %l302
  %t658 = icmp ne i32 %t657, 0
  br i1 %t658, label %bb198, label %ok.659, !prof !99
ok.659:
  store i64 %t656, ptr %l301
  br label %bb197
bb197:
  %t660 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t661 = load i64, ptr %l301, !tbaa !24
  %t662 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s29, { i64, ptr } %t660, i64 %t661)
  %t663 = extractvalue { i32, i64 } %t662, 1
  %t664 = extractvalue { i32, i64 } %t662, 0
  store i32 %t664, ptr %l304
  %t665 = icmp ne i32 %t664, 0
  br i1 %t665, label %bb201, label %ok.666, !prof !99
ok.666:
  store i64 %t663, ptr %l303
  br label %bb200
bb198:
  br label %bb199
bb199:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb200:
  %t668 = load i64, ptr %l303, !tbaa !24
  store i64 %t668, ptr %l298, !tbaa !24
  br label %bb202
bb201:
  br label %bb199
bb202:
  %t669 = load i64, ptr %l298, !tbaa !24
  store i64 %t669, ptr %l31, !tbaa !24
  %t670 = load ptr, ptr %l30, !tbaa !29
  %t672 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s29, ptr %s29, ptr %t670, i64 1)
  store { i64, ptr } %t672, ptr %l308
  br label %bb203
bb203:
  %t673 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s29, i64 10)
  %t674 = extractvalue { i32, i64 } %t673, 1
  %t675 = extractvalue { i32, i64 } %t673, 0
  store i32 %t675, ptr %l310
  %t676 = icmp ne i32 %t675, 0
  br i1 %t676, label %bb205, label %ok.677, !prof !99
ok.677:
  store i64 %t674, ptr %l309
  br label %bb204
bb204:
  %t678 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t679 = load i64, ptr %l309, !tbaa !24
  %t680 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s29, { i64, ptr } %t678, i64 %t679)
  %t681 = extractvalue { i32, i64 } %t680, 1
  %t682 = extractvalue { i32, i64 } %t680, 0
  store i32 %t682, ptr %l312
  %t683 = icmp ne i32 %t682, 0
  br i1 %t683, label %bb208, label %ok.684, !prof !99
ok.684:
  store i64 %t681, ptr %l311
  br label %bb207
bb205:
  br label %bb206
bb206:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb207:
  %t686 = load i64, ptr %l311, !tbaa !24
  store i64 %t686, ptr %l306, !tbaa !24
  br label %bb209
bb208:
  br label %bb206
bb209:
  %t687 = load i64, ptr %l306, !tbaa !24
  store ptr %l25, ptr %l314, !tbaa !29
  %t688 = load i64, ptr %l31, !tbaa !24
  store i64 %t688, ptr %l315, !tbaa !24
  store i64 %t687, ptr %l316, !tbaa !24
  %t690 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t690, ptr %l318, !tbaa !27
  %t691 = load ptr, ptr %l30, !tbaa !29
  %t693 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s29, ptr %s29, ptr %t691, i64 0)
  store { i64, ptr } %t693, ptr %l320
  br label %bb210
bb210:
  %t694 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t695 = extractvalue { i64, ptr } %t694, 0
  store i64 %t695, ptr %l321, !tbaa !24
  %t696 = load ptr, ptr %l30, !tbaa !29
  %t698 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s29, ptr %s29, ptr %t696, i64 1)
  store { i64, ptr } %t698, ptr %l323
  br label %bb211
bb211:
  %t699 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t700 = extractvalue { i64, ptr } %t699, 0
  %t701 = load i64, ptr %l321, !tbaa !24
  %t703 = add i64 %t701, %t700
  %t705 = add i64 %t703, 2
  store i64 %t705, ptr %l326, !tbaa !24
  %t706 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t709 = extractvalue { i64, ptr } %t706, 0
  store i64 %t709, ptr %l329, !tbaa !24
  %t710 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t711 = extractvalue { i64, ptr } %t710, 0
  store i64 %t711, ptr %l330, !tbaa !24
  %t712 = load i64, ptr %l326, !tbaa !24
  %t713 = icmp sge i64 %t712, 0
  br i1 %t713, label %bb212, label %bb213
bb212:
  %t715 = load i64, ptr %l326, !tbaa !24
  %t716 = load i64, ptr %l329, !tbaa !24
  %t717 = icmp sle i64 %t715, %t716
  br i1 %t717, label %bb214, label %bb215
bb213:
  call void @__olang_check_failed(ptr @olang_loc_850ab3b4cafc30bf_b865ab70d4df5d13)
  unreachable
bb214:
  %t719 = load i64, ptr %l329, !tbaa !24
  %t720 = load i64, ptr %l330, !tbaa !24
  %t721 = icmp sle i64 %t719, %t720
  br i1 %t721, label %bb216, label %bb217
bb215:
  call void @__olang_check_failed(ptr @olang_loc_850ab3b4cafc30bf_b865ab70d4df5d13)
  unreachable
bb216:
  %t723 = getelementptr { i64, ptr }, ptr %l318, i32 0, i32 1
  %t724 = load ptr, ptr %t723, !tbaa !27
  %t725 = load i64, ptr %l326, !tbaa !24
  %t726 = load i64, ptr %l329, !tbaa !24
  %t727 = getelementptr i8, ptr %t724, i64 %t725
  %t728 = sub i64 %t726, %t725
  %t729 = insertvalue { i64, ptr } undef, i64 %t728, 0
  %t730 = insertvalue { i64, ptr } %t729, ptr %t727, 1
  %t732 = call { i32, { i64, [2 x i64] } } @compiler_2ftyped_2eScope_2eOfText(ptr %s28, { i64, ptr } %t730)
  %t733 = extractvalue { i32, { i64, [2 x i64] } } %t732, 1
  %t734 = extractvalue { i32, { i64, [2 x i64] } } %t732, 0
  store i32 %t734, ptr %l336
  %t735 = icmp ne i32 %t734, 0
  br i1 %t735, label %bb219, label %ok.736, !prof !99
ok.736:
  store { i64, [2 x i64] } %t733, ptr %l335
  br label %bb218
bb217:
  call void @__olang_check_failed(ptr @olang_loc_850ab3b4cafc30bf_b865ab70d4df5d13)
  unreachable
bb218:
  %t737 = load { i64, [2 x i64] }, ptr %l335
  store { i64, [2 x i64] } %t737, ptr %l317
  br label %bb220
bb219:
  %t738 = load i32, ptr %l336, !tbaa !23
  %t739 = lshr i32 %t738, 16
  %t740 = and i32 %t738, 65535
  %t741 = icmp eq i32 %t739, 1
  %t742 = select i1 %t741, i32 1, i32 0
  %t743 = icmp eq i32 %t738, 0
  %t744 = shl i32 %t742, 16
  %t745 = or i32 %t744, %t740
  %t746 = select i1 %t743, i32 0, i32 %t745
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t746, ptr %rv
  br label %ret
bb220:
  %t748 = load i64, ptr %l315, !tbaa !24
  %t749 = load i64, ptr %l316, !tbaa !24
  %t750 = load { i64, [2 x i64] }, ptr %l317
  %t751 = call %"compiler/typed:DerivedArg" @compiler_2ftyped_3aDerivedArg_2ector(ptr %s29, i64 %t748, i64 %t749, { i64, [2 x i64] } %t750)
  store %"compiler/typed:DerivedArg" %t751, ptr %l338
  br label %bb221
bb221:
  %t752 = load ptr, ptr %l314, !tbaa !29
  %t753 = load %"compiler/typed:DerivedArg", ptr %l338
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2ePus_Hd9c60b9bc3eb0bc15b58bce924fabf2c(ptr %s25, ptr %t752, %"compiler/typed:DerivedArg" %t753)
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s29)
  br label %bb223
bb223:
  %t754 = load i64, ptr %l27, !tbaa !24
  %t757 = add i64 %t754, 1
  store i64 %t757, ptr %l27, !tbaa !24
  br label %bb182
bb224:
  call void @__olang_scope_close(ptr %s28)
  %t759 = load ptr, ptr %lp4
  %t760 = load i64, ptr %l24, !tbaa !24
  %t762 = trunc i64 %t760 to i32
  %t764 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassDerived(ptr %v2, ptr %s25, ptr %t759, i32 %t762, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t764)
  br label %bb225
bb225:
  call void @__olang_scope_close(ptr %s25)
  br label %bb226
bb226:
  %t768 = load i64, ptr %l21, !tbaa !24
  %t771 = add i64 %t768, 1
  store i64 %t771, ptr %l21, !tbaa !24
  br label %bb152
bb227:
  call void @__olang_scope_close(ptr %s24)
  %t773 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l350, ptr %t773, i64 584, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l350, i64 584, i1 false)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2elaterBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l8 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LastUses", ptr %t2, i32 0, i32 5
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = add i64 %t4, 1
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/typed:LastUses", ptr %t9, i32 0, i32 5
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t11, ptr %a1)
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"compiler/typed:LastUses", ptr %t16, i32 0, i32 5
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = sub i64 %t18, 1
  %t23 = load ptr, ptr %l8, !tbaa !29
  %t24 = getelementptr %"compiler/typed:LastUses", ptr %t23, i32 0, i32 5
  store i64 %t21, ptr %t24, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eliteralItems(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l27 = alloca i1
  %l31 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i1
  %l38 = alloca i1
  %l65 = alloca { i64, ptr }
  %l69 = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 54}
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb31
bb5:
  %t22 = load i32, ptr %l2, !range !{i32 0, i32 54}
  %t24 = trunc i64 20 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb8
bb7:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t33 = icmp ne i64 %t31, 1
  store i1 %t33, ptr %l27, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t36, ptr %l31, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 0
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %t40, ptr %l4, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  store ptr %t42, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t43 = load ptr, ptr %l33, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l33, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 18}
  %t49 = icmp eq i64 %t47, 7
  store i1 %t49, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t50 = load i1, ptr %l34, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb16
bb15:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l5
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l6, !tbaa !23
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  %t74 = getelementptr %"compiler/typed:Make", ptr %t69, i32 0, i32 0
  %t75 = load i32, ptr %t74, !range !{i32 0, i32 5}
  %t77 = trunc i64 2 to i32
  %t78 = icmp eq i32 %t75, %t77
  %t80 = xor i1 %t78, true
  store i1 %t80, ptr %l38, !tbaa !21
  br label %bb16
bb16:
  %t82 = load i1, ptr %l38, !tbaa !21
  br i1 %t82, label %bb17, label %bb18
bb17:
  br label %ret
bb18:
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l4, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 0
  %t87 = load %"compiler/source:Span", ptr %t86
  store %"compiler/source:Span" %t87, ptr %l8
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t91, i32 0, i32 1
  %t93 = load i32, ptr %t92
  store i32 %t93, ptr %l9, !tbaa !23
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  %t104 = getelementptr %"compiler/typed:Make", ptr %t99, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l13, !tbaa !24
  br label %bb20
bb20:
  %t111 = load i64, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb21, label %bb22
bb21:
  br label %bb30
bb22:
  br label %bb23
bb23:
  %t119 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t119, ptr %l65, !tbaa !27
  %t120 = load i64, ptr %l12, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr ptr, ptr %t123, i64 %t120
  %t125 = load ptr, ptr %t124, !tbaa !39
  %t129 = call i64 @compiler_2ftyped_2ecopySite(ptr %v1, ptr %t125)
  store i64 %t129, ptr %l69
  br label %bb24
bb24:
  %t130 = load i64, ptr %l69, !tbaa !24
  store i64 %t130, ptr %l15, !tbaa !24
  %t131 = load i64, ptr %l15, !tbaa !24
  %t133 = icmp sge i64 %t131, 0
  br i1 %t133, label %bb25, label %bb26
bb25:
  %t137 = getelementptr %"compiler/typed:LastUses", ptr %a0, i32 0, i32 11
  %t138 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t137, i64 %t138, i1 true)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t141 = load i64, ptr %l12, !tbaa !24
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %l12, !tbaa !24
  br label %bb20
bb30:
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_437e3b1aa2dfe07b_e7cef1b5dfa49877)
  unreachable
bb36:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l68 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l145 = alloca ptr
  %l154 = alloca ptr
  %l158 = alloca ptr
  %l159 = alloca i1
  %l171 = alloca ptr
  %l172 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca i1
  %l199 = alloca ptr
  %l206 = alloca ptr
  %l210 = alloca ptr
  %l211 = alloca i1
  %l216 = alloca ptr
  %l228 = alloca { i64, ptr }
  %l251 = alloca { i64, ptr }
  %l260 = alloca ptr
  %l264 = alloca ptr
  %l265 = alloca i1
  %l268 = alloca ptr
  %l269 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t2 = load ptr, ptr %l30, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l30, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l31, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l31, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2edeclare(ptr %v0, ptr %t22, i32 %t23)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %t31, i32 %t32)
  br label %bb8
bb8:
  br label %bb140
bb9:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t36 = load ptr, ptr %l45, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l45, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 17}
  %t42 = icmp eq i64 %t40, 1
  store i1 %t42, ptr %l46, !tbaa !21
  br label %bb11
bb11:
  %t43 = load i1, ptr %l46, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l5, !tbaa !29
  br label %bb14
bb13:
  br label %bb28
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t56, ptr %t57)
  br label %bb15
bb15:
  %t60 = load ptr, ptr %l4, !tbaa !29
  store ptr %t60, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t61 = load ptr, ptr %l55, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t64 = load ptr, ptr %l55, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 8}
  %t67 = icmp eq i64 %t65, 1
  store i1 %t67, ptr %l56, !tbaa !21
  br label %bb17
bb17:
  %t68 = load i1, ptr %l56, !tbaa !21
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t71, i32 0, i32 0
  %t73 = load %"compiler/source:Span", ptr %t72
  store %"compiler/source:Span" %t73, ptr %l6
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t77, i32 0, i32 1
  %t79 = load i32, ptr %t78
  store i32 %t79, ptr %l7, !tbaa !23
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t83, i32 0, i32 2
  %t85 = load i64, ptr %t84
  store i64 %t85, ptr %l8, !tbaa !24
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t89, i32 0, i32 3
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l9, !tbaa !23
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = call i64 @compiler_2ftyped_2ecopySite(ptr %v1, ptr %t93)
  store i64 %t95, ptr %l68
  br label %bb20
bb19:
  br label %bb25
bb20:
  %t96 = load i64, ptr %l68, !tbaa !24
  store i64 %t96, ptr %l10, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t99 = icmp sge i64 %t97, 0
  br i1 %t99, label %bb21, label %bb22
bb21:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/typed:LastUses", ptr %t101, i32 0, i32 10
  %t104 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t103, i64 %t104, i1 true)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eliteralItems(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  br label %bb26
bb26:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t111, ptr %t112)
  br label %bb27
bb27:
  br label %bb140
bb28:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t117 = load ptr, ptr %l79, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb29, label %bb30
bb29:
  %t120 = load ptr, ptr %l79, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 17}
  %t123 = icmp eq i64 %t121, 2
  store i1 %t123, ptr %l80, !tbaa !21
  br label %bb30
bb30:
  %t124 = load i1, ptr %l80, !tbaa !21
  br i1 %t124, label %bb31, label %bb32
bb31:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [3 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", ptr }, ptr %t127, i32 0, i32 1
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l11, !tbaa !29
  br label %bb41
bb32:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t132 = load ptr, ptr %l85, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb33, label %bb34
bb33:
  %t135 = load ptr, ptr %l85, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 17}
  %t138 = icmp eq i64 %t136, 15
  store i1 %t138, ptr %l86, !tbaa !21
  br label %bb34
bb34:
  %t139 = load i1, ptr %l86, !tbaa !21
  br i1 %t139, label %bb35, label %bb36
bb35:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [3 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", ptr }, ptr %t142, i32 0, i32 1
  %t144 = load ptr, ptr %t143
  store ptr %t144, ptr %l11, !tbaa !29
  br label %bb41
bb36:
  %t146 = load ptr, ptr %l1, !tbaa !29
  store ptr %t146, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t147 = load ptr, ptr %l91, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb37, label %bb38
bb37:
  %t150 = load ptr, ptr %l91, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 17}
  %t153 = icmp eq i64 %t151, 8
  store i1 %t153, ptr %l92, !tbaa !21
  br label %bb38
bb38:
  %t154 = load i1, ptr %l92, !tbaa !21
  br i1 %t154, label %bb39, label %bb40
bb39:
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t157 = getelementptr { i64, [3 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t157, i32 0, i32 1
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l11, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t161, ptr %t162)
  br label %bb42
bb42:
  br label %bb140
bb43:
  %t166 = load ptr, ptr %l1, !tbaa !29
  store ptr %t166, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t167 = load ptr, ptr %l100, !tbaa !29
  %t168 = icmp ne ptr %t167, null
  br i1 %t168, label %bb44, label %bb45
bb44:
  %t170 = load ptr, ptr %l100, !tbaa !29
  %t171 = load i64, ptr %t170, !range !{i64 0, i64 17}
  %t173 = icmp eq i64 %t171, 6
  store i1 %t173, ptr %l101, !tbaa !21
  br label %bb45
bb45:
  %t174 = load i1, ptr %l101, !tbaa !21
  br i1 %t174, label %bb46, label %bb47
bb46:
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [3 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", ptr }, ptr %t177, i32 0, i32 1
  %t179 = load ptr, ptr %t178
  store ptr %t179, ptr %l12, !tbaa !29
  br label %bb56
bb47:
  %t181 = load ptr, ptr %l1, !tbaa !29
  store ptr %t181, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t182 = load ptr, ptr %l106, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb48, label %bb49
bb48:
  %t185 = load ptr, ptr %l106, !tbaa !29
  %t186 = load i64, ptr %t185, !range !{i64 0, i64 17}
  %t188 = icmp eq i64 %t186, 16
  store i1 %t188, ptr %l107, !tbaa !21
  br label %bb49
bb49:
  %t189 = load i1, ptr %l107, !tbaa !21
  br i1 %t189, label %bb50, label %bb51
bb50:
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", ptr }, ptr %t192, i32 0, i32 1
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l12, !tbaa !29
  br label %bb56
bb51:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t197 = load ptr, ptr %l112, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb52, label %bb53
bb52:
  %t200 = load ptr, ptr %l112, !tbaa !29
  %t201 = load i64, ptr %t200, !range !{i64 0, i64 17}
  %t203 = icmp eq i64 %t201, 9
  store i1 %t203, ptr %l113, !tbaa !21
  br label %bb53
bb53:
  %t204 = load i1, ptr %l113, !tbaa !21
  br i1 %t204, label %bb54, label %bb55
bb54:
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t207 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t207, i32 0, i32 2
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l12, !tbaa !29
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t211, ptr %t212)
  br label %bb57
bb57:
  br label %bb140
bb58:
  %t215 = load ptr, ptr %l1, !tbaa !29
  store ptr %t215, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t216 = load ptr, ptr %l120, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb59, label %bb60
bb59:
  %t219 = load ptr, ptr %l120, !tbaa !29
  %t220 = load i64, ptr %t219, !range !{i64 0, i64 17}
  %t222 = icmp eq i64 %t220, 3
  store i1 %t222, ptr %l121, !tbaa !21
  br label %bb60
bb60:
  %t223 = load i1, ptr %l121, !tbaa !21
  br i1 %t223, label %bb61, label %bb62
bb61:
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [3 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", ptr }, ptr %t226, i32 0, i32 1
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l13, !tbaa !29
  br label %bb63
bb62:
  br label %bb67
bb63:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l13, !tbaa !29
  %t233 = getelementptr %"compiler/typed:If", ptr %t231, i32 0, i32 0
  %t234 = load ptr, ptr %t233, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t230, ptr %t234)
  br label %bb64
bb64:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l13, !tbaa !29
  %t241 = getelementptr %"compiler/typed:If", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t238, ptr %t242)
  br label %bb65
bb65:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %l13, !tbaa !29
  %t249 = getelementptr %"compiler/typed:If", ptr %t247, i32 0, i32 2
  %t250 = load ptr, ptr %t249, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t246, ptr %t250)
  br label %bb66
bb66:
  br label %bb140
bb67:
  %t253 = load ptr, ptr %l1, !tbaa !29
  store ptr %t253, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t254 = load ptr, ptr %l137, !tbaa !29
  %t255 = icmp ne ptr %t254, null
  br i1 %t255, label %bb68, label %bb69
bb68:
  %t257 = load ptr, ptr %l137, !tbaa !29
  %t258 = load i64, ptr %t257, !range !{i64 0, i64 17}
  %t260 = icmp eq i64 %t258, 4
  store i1 %t260, ptr %l138, !tbaa !21
  br label %bb69
bb69:
  %t261 = load i1, ptr %l138, !tbaa !21
  br i1 %t261, label %bb70, label %bb71
bb70:
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [3 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t264, i32 0, i32 1
  %t266 = load ptr, ptr %t265
  store ptr %t266, ptr %l14, !tbaa !29
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [3 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t270, i32 0, i32 2
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l15, !tbaa !29
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t274 = load ptr, ptr %l0, !tbaa !29
  store ptr %t274, ptr %l145, !tbaa !29
  %t275 = load ptr, ptr %l145, !tbaa !29
  %t276 = getelementptr %"compiler/typed:LastUses", ptr %t275, i32 0, i32 4
  %t277 = load i64, ptr %t276, !tbaa !24
  %t280 = add i64 %t277, 1
  %t282 = load ptr, ptr %l145, !tbaa !29
  %t283 = getelementptr %"compiler/typed:LastUses", ptr %t282, i32 0, i32 4
  store i64 %t280, ptr %t283, !tbaa !24
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t284, ptr %t285)
  br label %bb73
bb73:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t289, ptr %t290)
  br label %bb74
bb74:
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l154, !tbaa !29
  %t294 = load ptr, ptr %l154, !tbaa !29
  %t295 = getelementptr %"compiler/typed:LastUses", ptr %t294, i32 0, i32 4
  %t296 = load i64, ptr %t295, !tbaa !24
  %t299 = sub i64 %t296, 1
  %t301 = load ptr, ptr %l154, !tbaa !29
  %t302 = getelementptr %"compiler/typed:LastUses", ptr %t301, i32 0, i32 4
  store i64 %t299, ptr %t302, !tbaa !24
  br label %bb140
bb75:
  %t303 = load ptr, ptr %l1, !tbaa !29
  store ptr %t303, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t304 = load ptr, ptr %l158, !tbaa !29
  %t305 = icmp ne ptr %t304, null
  br i1 %t305, label %bb76, label %bb77
bb76:
  %t307 = load ptr, ptr %l158, !tbaa !29
  %t308 = load i64, ptr %t307, !range !{i64 0, i64 17}
  %t310 = icmp eq i64 %t308, 10
  store i1 %t310, ptr %l159, !tbaa !21
  br label %bb77
bb77:
  %t311 = load i1, ptr %l159, !tbaa !21
  br i1 %t311, label %bb78, label %bb79
bb78:
  %t312 = load ptr, ptr %l1, !tbaa !29
  %t314 = getelementptr { i64, [3 x i64] }, ptr %t312, i32 0, i32 1
  %t315 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t314, i32 0, i32 1
  %t316 = load ptr, ptr %t315
  store ptr %t316, ptr %l16, !tbaa !29
  %t318 = load ptr, ptr %l1, !tbaa !29
  %t320 = getelementptr { i64, [3 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t320, i32 0, i32 2
  %t322 = load ptr, ptr %t321
  store ptr %t322, ptr %l17, !tbaa !29
  br label %bb80
bb79:
  br label %bb83
bb80:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t324, ptr %t325)
  br label %bb81
bb81:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t329, ptr %t330)
  br label %bb82
bb82:
  br label %bb140
bb83:
  %t333 = load ptr, ptr %l1, !tbaa !29
  store ptr %t333, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t334 = load ptr, ptr %l171, !tbaa !29
  %t335 = icmp ne ptr %t334, null
  br i1 %t335, label %bb84, label %bb85
bb84:
  %t337 = load ptr, ptr %l171, !tbaa !29
  %t338 = load i64, ptr %t337, !range !{i64 0, i64 17}
  %t340 = icmp eq i64 %t338, 11
  store i1 %t340, ptr %l172, !tbaa !21
  br label %bb85
bb85:
  %t341 = load i1, ptr %l172, !tbaa !21
  br i1 %t341, label %bb86, label %bb87
bb86:
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t344 = getelementptr { i64, [3 x i64] }, ptr %t342, i32 0, i32 1
  %t345 = getelementptr { %"compiler/source:Span", ptr }, ptr %t344, i32 0, i32 1
  %t346 = load ptr, ptr %t345
  store ptr %t346, ptr %l18, !tbaa !29
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t348, ptr %t349)
  br label %bb89
bb89:
  br label %bb140
bb90:
  %t353 = load ptr, ptr %l1, !tbaa !29
  store ptr %t353, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t354 = load ptr, ptr %l180, !tbaa !29
  %t355 = icmp ne ptr %t354, null
  br i1 %t355, label %bb91, label %bb92
bb91:
  %t357 = load ptr, ptr %l180, !tbaa !29
  %t358 = load i64, ptr %t357, !range !{i64 0, i64 17}
  %t360 = icmp eq i64 %t358, 12
  store i1 %t360, ptr %l181, !tbaa !21
  br label %bb92
bb92:
  %t361 = load i1, ptr %l181, !tbaa !21
  br i1 %t361, label %bb93, label %bb94
bb93:
  %t362 = load ptr, ptr %l1, !tbaa !29
  %t364 = getelementptr { i64, [3 x i64] }, ptr %t362, i32 0, i32 1
  %t365 = getelementptr { %"compiler/source:Span", ptr }, ptr %t364, i32 0, i32 1
  %t366 = load ptr, ptr %t365
  store ptr %t366, ptr %l19, !tbaa !29
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2elaterBlock(ptr %v0, ptr %v1, ptr %t368, ptr %t369)
  br label %bb96
bb96:
  br label %bb140
bb97:
  %t373 = load ptr, ptr %l1, !tbaa !29
  store ptr %t373, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t374 = load ptr, ptr %l189, !tbaa !29
  %t375 = icmp ne ptr %t374, null
  br i1 %t375, label %bb98, label %bb99
bb98:
  %t377 = load ptr, ptr %l189, !tbaa !29
  %t378 = load i64, ptr %t377, !range !{i64 0, i64 17}
  %t380 = icmp eq i64 %t378, 13
  store i1 %t380, ptr %l190, !tbaa !21
  br label %bb99
bb99:
  %t381 = load i1, ptr %l190, !tbaa !21
  br i1 %t381, label %bb100, label %bb101
bb100:
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t384 = getelementptr { i64, [3 x i64] }, ptr %t382, i32 0, i32 1
  %t385 = getelementptr { %"compiler/source:Span", ptr }, ptr %t384, i32 0, i32 1
  %t386 = load ptr, ptr %t385
  store ptr %t386, ptr %l20, !tbaa !29
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load ptr, ptr %l20, !tbaa !29
  %t391 = getelementptr %"compiler/typed:Join", ptr %t389, i32 0, i32 0
  %t392 = load ptr, ptr %t391, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t388, ptr %t392)
  br label %bb103
bb103:
  %t396 = load ptr, ptr %l0, !tbaa !29
  store ptr %t396, ptr %l199, !tbaa !29
  %t397 = load ptr, ptr %l199, !tbaa !29
  %t398 = getelementptr %"compiler/typed:LastUses", ptr %t397, i32 0, i32 5
  %t399 = load i64, ptr %t398, !tbaa !24
  %t402 = add i64 %t399, 1
  %t404 = load ptr, ptr %l199, !tbaa !29
  %t405 = getelementptr %"compiler/typed:LastUses", ptr %t404, i32 0, i32 5
  store i64 %t402, ptr %t405, !tbaa !24
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load ptr, ptr %l20, !tbaa !29
  %t409 = getelementptr %"compiler/typed:Join", ptr %t407, i32 0, i32 2
  %t410 = load { i64, ptr }, ptr %t409, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %t406, { i64, ptr } %t410)
  br label %bb104
bb104:
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l206, !tbaa !29
  %t414 = load ptr, ptr %l206, !tbaa !29
  %t415 = getelementptr %"compiler/typed:LastUses", ptr %t414, i32 0, i32 5
  %t416 = load i64, ptr %t415, !tbaa !24
  %t419 = sub i64 %t416, 1
  %t421 = load ptr, ptr %l206, !tbaa !29
  %t422 = getelementptr %"compiler/typed:LastUses", ptr %t421, i32 0, i32 5
  store i64 %t419, ptr %t422, !tbaa !24
  br label %bb140
bb105:
  %t423 = load ptr, ptr %l1, !tbaa !29
  store ptr %t423, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t424 = load ptr, ptr %l210, !tbaa !29
  %t425 = icmp ne ptr %t424, null
  br i1 %t425, label %bb106, label %bb107
bb106:
  %t427 = load ptr, ptr %l210, !tbaa !29
  %t428 = load i64, ptr %t427, !range !{i64 0, i64 17}
  %t430 = icmp eq i64 %t428, 14
  store i1 %t430, ptr %l211, !tbaa !21
  br label %bb107
bb107:
  %t431 = load i1, ptr %l211, !tbaa !21
  br i1 %t431, label %bb108, label %bb109
bb108:
  %t432 = load ptr, ptr %l1, !tbaa !29
  %t434 = getelementptr { i64, [3 x i64] }, ptr %t432, i32 0, i32 1
  %t435 = getelementptr { %"compiler/source:Span", ptr }, ptr %t434, i32 0, i32 1
  %t436 = load ptr, ptr %t435
  store ptr %t436, ptr %l21, !tbaa !29
  br label %bb110
bb109:
  br label %bb129
bb110:
  %t438 = load ptr, ptr %l0, !tbaa !29
  store ptr %t438, ptr %l216, !tbaa !29
  %t439 = load ptr, ptr %l216, !tbaa !29
  %t440 = getelementptr %"compiler/typed:LastUses", ptr %t439, i32 0, i32 5
  %t441 = load i64, ptr %t440, !tbaa !24
  %t444 = add i64 %t441, 1
  %t446 = load ptr, ptr %l216, !tbaa !29
  %t447 = getelementptr %"compiler/typed:LastUses", ptr %t446, i32 0, i32 5
  store i64 %t444, ptr %t447, !tbaa !24
  %t448 = load ptr, ptr %l21, !tbaa !29
  %t450 = getelementptr %"compiler/typed:Spawn", ptr %t448, i32 0, i32 0
  %t451 = load { i64, ptr }, ptr %t450, !tbaa !27
  store { i64, ptr } %t451, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t453 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t453, 0
  store i64 %t455, ptr %l24, !tbaa !24
  br label %bb111
bb111:
  %t457 = load i64, ptr %l23, !tbaa !24
  %t458 = load i64, ptr %l24, !tbaa !24
  %t461 = icmp slt i64 %t457, %t458
  %t463 = xor i1 %t461, true
  br i1 %t463, label %bb112, label %bb113
bb112:
  br label %bb120
bb113:
  br label %bb114
bb114:
  %t465 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t465, ptr %l228, !tbaa !27
  %t466 = load i64, ptr %l23, !tbaa !24
  %t468 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t469 = load ptr, ptr %t468, !tbaa !27
  %t470 = getelementptr ptr, ptr %t469, i64 %t466
  %t471 = load ptr, ptr %t470, !tbaa !39
  store ptr %t471, ptr %l25, !tbaa !29
  %t473 = load ptr, ptr %l25, !tbaa !29
  %t475 = icmp eq ptr %t473, null
  %t477 = xor i1 %t475, true
  br i1 %t477, label %bb115, label %bb116
bb115:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t479, ptr %t480)
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t483 = load i64, ptr %l23, !tbaa !24
  %t486 = add i64 %t483, 1
  store i64 %t486, ptr %l23, !tbaa !24
  br label %bb111
bb120:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l21, !tbaa !29
  %t491 = getelementptr %"compiler/typed:Spawn", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t488, ptr %t492)
  br label %bb121
bb121:
  %t496 = load ptr, ptr %l21, !tbaa !29
  %t498 = getelementptr %"compiler/typed:Spawn", ptr %t496, i32 0, i32 2
  %t499 = load { i64, ptr }, ptr %t498, !tbaa !27
  store { i64, ptr } %t499, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t501 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t501, 0
  store i64 %t503, ptr %l28, !tbaa !24
  br label %bb122
bb122:
  %t505 = load i64, ptr %l27, !tbaa !24
  %t506 = load i64, ptr %l28, !tbaa !24
  %t509 = icmp slt i64 %t505, %t506
  %t511 = xor i1 %t509, true
  br i1 %t511, label %bb123, label %bb124
bb123:
  br label %bb128
bb124:
  br label %bb125
bb125:
  %t513 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t513, ptr %l251, !tbaa !27
  %t514 = load i64, ptr %l27, !tbaa !24
  %t516 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t517 = load ptr, ptr %t516, !tbaa !27
  %t518 = getelementptr ptr, ptr %t517, i64 %t514
  %t519 = load ptr, ptr %t518, !tbaa !39
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t524 = getelementptr %"compiler/typed:TaskClause", ptr %t519, i32 0, i32 3
  %t525 = load ptr, ptr %t524, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t521, ptr %t525)
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t528 = load i64, ptr %l27, !tbaa !24
  %t531 = add i64 %t528, 1
  store i64 %t531, ptr %l27, !tbaa !24
  br label %bb122
bb128:
  %t533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t533, ptr %l260, !tbaa !29
  %t534 = load ptr, ptr %l260, !tbaa !29
  %t535 = getelementptr %"compiler/typed:LastUses", ptr %t534, i32 0, i32 5
  %t536 = load i64, ptr %t535, !tbaa !24
  %t539 = sub i64 %t536, 1
  %t541 = load ptr, ptr %l260, !tbaa !29
  %t542 = getelementptr %"compiler/typed:LastUses", ptr %t541, i32 0, i32 5
  store i64 %t539, ptr %t542, !tbaa !24
  br label %bb140
bb129:
  %t543 = load ptr, ptr %l1, !tbaa !29
  store ptr %t543, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t544 = load ptr, ptr %l264, !tbaa !29
  %t545 = icmp ne ptr %t544, null
  br i1 %t545, label %bb130, label %bb131
bb130:
  %t547 = load ptr, ptr %l264, !tbaa !29
  %t548 = load i64, ptr %t547, !range !{i64 0, i64 17}
  %t550 = icmp eq i64 %t548, 5
  store i1 %t550, ptr %l265, !tbaa !21
  br label %bb131
bb131:
  %t551 = load i1, ptr %l265, !tbaa !21
  br i1 %t551, label %bb132, label %bb133
bb132:
  br label %bb138
bb133:
  %t552 = load ptr, ptr %l1, !tbaa !29
  store ptr %t552, ptr %l268, !tbaa !29
  store i1 false, ptr %l269, !tbaa !21
  %t553 = load ptr, ptr %l268, !tbaa !29
  %t554 = icmp ne ptr %t553, null
  br i1 %t554, label %bb134, label %bb135
bb134:
  %t556 = load ptr, ptr %l268, !tbaa !29
  %t557 = load i64, ptr %t556, !range !{i64 0, i64 17}
  %t559 = icmp eq i64 %t557, 7
  store i1 %t559, ptr %l269, !tbaa !21
  br label %bb135
bb135:
  %t560 = load i1, ptr %l269, !tbaa !21
  br i1 %t560, label %bb136, label %bb137
bb136:
  br label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb140
bb139:
  call void @__olang_check_failed(ptr @olang_loc_b7d0c4ef23cb16fa_bb49bf88955879a6)
  unreachable
bb140:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ealiasInto(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l45 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l57 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l69 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l81 = alloca i1
  %l87 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i64
  %l116 = alloca i64
  %l123 = alloca ptr
  %l127 = alloca i64
  %l129 = alloca ptr
  %l133 = alloca i64
  %l135 = alloca ptr
  %l139 = alloca i64
  %l144 = alloca ptr
  %l148 = alloca ptr
  %l150 = alloca i1
  %l154 = alloca i1
  %l155 = alloca i1
  %l159 = alloca i1
  %l160 = alloca i1
  %l172 = alloca i64
  %l176 = alloca i64
  %l179 = alloca i64
  %l200 = alloca i64
  %l207 = alloca ptr
  %l211 = alloca i64
  %l213 = alloca ptr
  %l217 = alloca i64
  %l219 = alloca ptr
  %l223 = alloca i1
  %l224 = alloca i1
  %l231 = alloca i64
  %l236 = alloca i64
  %l239 = alloca i64
  %l260 = alloca i64
  %l267 = alloca ptr
  %l271 = alloca i64
  %l273 = alloca ptr
  %l277 = alloca i64
  %l283 = alloca i64
  %l287 = alloca i64
  %l290 = alloca i64
  %l311 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l33
  br label %bb1
bb1:
  %t8 = load i1, ptr %l33, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:LocalUses", ptr %t9, i32 0, i32 4
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l38
  br label %bb4
bb4:
  %t16 = load i1, ptr %l38, !tbaa !21
  store i1 %t16, ptr %l34, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l34, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:LocalUses", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t20, i64 %t21, i1 true)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/typed:LocalUses", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t26, i64 %t27)
  store i1 %t30, ptr %l45
  br label %bb10
bb10:
  %t31 = load i1, ptr %l45, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/typed:LocalUses", ptr %t32, i32 0, i32 3
  %t35 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t34, i64 %t35, i1 true)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:LocalUses", ptr %t38, i32 0, i32 7
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t40, i64 %t41)
  store i1 %t44, ptr %l52
  br label %bb15
bb15:
  %t45 = load i1, ptr %l52, !tbaa !21
  br i1 %t45, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb19
bb17:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:LocalUses", ptr %t46, i32 0, i32 18
  %t49 = load i64, ptr %l1, !tbaa !24
  %t52 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t48, i64 %t49)
  store i1 %t52, ptr %l57
  br label %bb18
bb18:
  %t53 = load i1, ptr %l57, !tbaa !21
  store i1 %t53, ptr %l53, !tbaa !21
  br label %bb19
bb19:
  %t54 = load i1, ptr %l53, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:LocalUses", ptr %t55, i32 0, i32 7
  %t58 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58, i1 true)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/typed:LocalUses", ptr %t61, i32 0, i32 8
  %t64 = load i64, ptr %l1, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t63, i64 %t64)
  store i1 %t67, ptr %l64
  br label %bb24
bb24:
  %t68 = load i1, ptr %l64, !tbaa !21
  br i1 %t68, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb28
bb26:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:LocalUses", ptr %t69, i32 0, i32 18
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t71, i64 %t72)
  store i1 %t75, ptr %l69
  br label %bb27
bb27:
  %t76 = load i1, ptr %l69, !tbaa !21
  store i1 %t76, ptr %l65, !tbaa !21
  br label %bb28
bb28:
  %t77 = load i1, ptr %l65, !tbaa !21
  br i1 %t77, label %bb29, label %bb30
bb29:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 8
  %t81 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t80, i64 %t81, i1 true)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/typed:LocalUses", ptr %t84, i32 0, i32 9
  %t87 = load i64, ptr %l1, !tbaa !24
  %t90 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t86, i64 %t87)
  store i1 %t90, ptr %l76
  br label %bb33
bb33:
  %t91 = load i1, ptr %l76, !tbaa !21
  br i1 %t91, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb37
bb35:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:LocalUses", ptr %t92, i32 0, i32 18
  %t95 = load i64, ptr %l1, !tbaa !24
  %t98 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t94, i64 %t95)
  store i1 %t98, ptr %l81
  br label %bb36
bb36:
  %t99 = load i1, ptr %l81, !tbaa !21
  store i1 %t99, ptr %l77, !tbaa !21
  br label %bb37
bb37:
  %t100 = load i1, ptr %l77, !tbaa !21
  br i1 %t100, label %bb38, label %bb39
bb38:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/typed:LocalUses", ptr %t101, i32 0, i32 9
  %t104 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t103, i64 %t104, i1 true)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/typed:LocalUses", ptr %t107, i32 0, i32 10
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l87
  br label %bb42
bb42:
  %t112 = load i64, ptr %l87, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 %t112, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t115 = load i64, ptr %l5, !tbaa !24
  %t116 = load i64, ptr %l4, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb43, label %bb44
bb43:
  %t121 = load i64, ptr %l6, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb48
bb45:
  %t125 = load i64, ptr %l5, !tbaa !24
  %t126 = load i64, ptr %l4, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l6, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l6, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l95, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb47
bb47:
  %t141 = load i64, ptr %l95, !tbaa !24
  store i64 %t141, ptr %l92, !tbaa !24
  br label %bb48
bb48:
  %t142 = load i64, ptr %l92, !tbaa !24
  store i64 %t142, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb49
bb49:
  %t143 = load i64, ptr %l8, !tbaa !24
  %t144 = load i64, ptr %l7, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb50, label %bb51
bb50:
  br label %bb65
bb51:
  br label %bb52
bb52:
  %t151 = load i64, ptr %l4, !tbaa !24
  %t152 = load i64, ptr %l8, !tbaa !24
  %t153 = load i64, ptr %l6, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l9, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/typed:LocalUses", ptr %t161, i32 0, i32 10
  %t164 = load i64, ptr %l9, !tbaa !24
  %t167 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t163, i64 %t164)
  store i64 %t167, ptr %l116
  br label %bb53
bb53:
  %t168 = load i64, ptr %l1, !tbaa !24
  %t169 = load i64, ptr %l116, !tbaa !24
  %t171 = icmp ne i64 %t169, %t168
  br i1 %t171, label %bb54, label %bb55
bb54:
  br label %bb64
bb55:
  br label %bb56
bb56:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/typed:LocalUses", ptr %t173, i32 0, i32 10
  %t176 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t175, i64 %t176)
  br label %bb57
bb57:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/typed:LocalUses", ptr %t179, i32 0, i32 11
  store ptr %t181, ptr %l123, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/typed:LocalUses", ptr %t182, i32 0, i32 11
  %t185 = load i64, ptr %l9, !tbaa !24
  %t188 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t184, i64 %t185)
  store i64 %t188, ptr %l127
  br label %bb58
bb58:
  %t189 = load ptr, ptr %l123, !tbaa !29
  %t190 = load i64, ptr %l127, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t189, i64 %t190)
  br label %bb59
bb59:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/typed:LocalUses", ptr %t191, i32 0, i32 12
  store ptr %t193, ptr %l129, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/typed:LocalUses", ptr %t194, i32 0, i32 12
  %t197 = load i64, ptr %l9, !tbaa !24
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t196, i64 %t197)
  store i64 %t200, ptr %l133
  br label %bb60
bb60:
  %t201 = load ptr, ptr %l129, !tbaa !29
  %t202 = load i64, ptr %l133, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t201, i64 %t202)
  br label %bb61
bb61:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/typed:LocalUses", ptr %t203, i32 0, i32 13
  store ptr %t205, ptr %l135, !tbaa !29
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/typed:LocalUses", ptr %t206, i32 0, i32 13
  %t209 = load i64, ptr %l9, !tbaa !24
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t208, i64 %t209)
  store i64 %t212, ptr %l139
  br label %bb62
bb62:
  %t213 = load ptr, ptr %l135, !tbaa !29
  %t214 = load i64, ptr %l139, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t213, i64 %t214)
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t215 = load i64, ptr %l8, !tbaa !24
  %t218 = add i64 %t215, 1
  store i64 %t218, ptr %l8, !tbaa !24
  br label %bb49
bb65:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/typed:LocalUses", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  store ptr %t223, ptr %l144, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/typed:LocalUses", ptr %t224, i32 0, i32 20
  %t227 = load i64, ptr %l1, !tbaa !24
  %t230 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v0, ptr %t226, i64 %t227)
  store ptr %t230, ptr %l148
  br label %bb66
bb66:
  %t231 = load ptr, ptr %l144, !tbaa !29
  %t232 = call ptr @__olang_scope_or(ptr %v1, ptr %t231)
  %t233 = call ptr @__olang_scope_hold(ptr %t232)
  %t234 = ptrtoint ptr %t233 to i64
  %t236 = inttoptr i64 %t234 to ptr
  %t237 = load ptr, ptr %l144, !tbaa !29
  %t238 = load ptr, ptr %l148, !tbaa !29
  %t239 = call i1 @compiler_2ftyped_2eRefReadOut(ptr %t236, ptr %v0, ptr %t237, ptr %t238)
  store i1 %t239, ptr %l150
  br label %bb67
bb67:
  %t240 = load i1, ptr %l150, !tbaa !21
  store i1 %t240, ptr %l10, !tbaa !21
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/typed:LocalUses", ptr %t241, i32 0, i32 17
  %t244 = load i64, ptr %l1, !tbaa !24
  %t247 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t243, i64 %t244)
  store i1 %t247, ptr %l154
  br label %bb68
bb68:
  %t248 = load i1, ptr %l154, !tbaa !21
  br i1 %t248, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb72
bb70:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/typed:LocalUses", ptr %t249, i32 0, i32 18
  %t252 = load i64, ptr %l1, !tbaa !24
  %t255 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t251, i64 %t252)
  store i1 %t255, ptr %l159
  br label %bb71
bb71:
  %t256 = load i1, ptr %l159, !tbaa !21
  store i1 %t256, ptr %l155, !tbaa !21
  br label %bb72
bb72:
  %t257 = load i1, ptr %l155, !tbaa !21
  br i1 %t257, label %bb73, label %bb74
bb73:
  %t258 = load i1, ptr %l10, !tbaa !21
  %t260 = xor i1 %t258, true
  store i1 %t260, ptr %l160, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb75
bb75:
  %t262 = load i1, ptr %l160, !tbaa !21
  br i1 %t262, label %bb76, label %bb77
bb76:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/typed:LocalUses", ptr %t263, i32 0, i32 17
  %t266 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t265, i64 %t266, i1 true)
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb79
bb79:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i64, ptr %l1, !tbaa !24
  %t271 = load i64, ptr %l2, !tbaa !24
  %t272 = load i1, ptr %l10, !tbaa !21
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eviewInto(ptr %v0, ptr %t269, i64 %t270, i64 %t271, i1 %t272)
  br label %bb80
bb80:
  store i64 0, ptr %l11, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/typed:LocalUses", ptr %t277, i32 0, i32 27
  %t281 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t279)
  store i64 %t281, ptr %l172
  br label %bb81
bb81:
  %t282 = load i64, ptr %l172, !tbaa !24
  store i64 %t282, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t283 = load i64, ptr %l12, !tbaa !24
  %t284 = load i64, ptr %l11, !tbaa !24
  %t287 = icmp sgt i64 %t283, %t284
  br i1 %t287, label %bb82, label %bb83
bb82:
  %t289 = load i64, ptr %l13, !tbaa !24
  %t291 = icmp sgt i64 %t289, 0
  br i1 %t291, label %bb84, label %bb85
bb83:
  store i64 0, ptr %l176, !tbaa !24
  br label %bb87
bb84:
  %t293 = load i64, ptr %l12, !tbaa !24
  %t294 = load i64, ptr %l11, !tbaa !24
  %t297 = sub i64 %t293, %t294
  %t298 = load i64, ptr %l13, !tbaa !24
  %t301 = add i64 %t297, %t298
  %t303 = sub i64 %t301, 1
  %t304 = load i64, ptr %l13, !tbaa !24
  %t307 = sdiv i64 %t303, %t304
  store i64 %t307, ptr %l179, !tbaa !24
  br label %bb86
bb85:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb86
bb86:
  %t309 = load i64, ptr %l179, !tbaa !24
  store i64 %t309, ptr %l176, !tbaa !24
  br label %bb87
bb87:
  %t310 = load i64, ptr %l176, !tbaa !24
  store i64 %t310, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb88
bb88:
  %t311 = load i64, ptr %l15, !tbaa !24
  %t312 = load i64, ptr %l14, !tbaa !24
  %t315 = icmp slt i64 %t311, %t312
  %t317 = xor i1 %t315, true
  br i1 %t317, label %bb89, label %bb90
bb89:
  br label %bb107
bb90:
  br label %bb91
bb91:
  %t319 = load i64, ptr %l11, !tbaa !24
  %t320 = load i64, ptr %l15, !tbaa !24
  %t321 = load i64, ptr %l13, !tbaa !24
  %t324 = mul i64 %t320, %t321
  %t327 = add i64 %t319, %t324
  store i64 %t327, ptr %l16, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/typed:LocalUses", ptr %t329, i32 0, i32 27
  %t332 = load i64, ptr %l16, !tbaa !24
  %t335 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t331, i64 %t332)
  store i64 %t335, ptr %l200
  br label %bb92
bb92:
  %t336 = load i64, ptr %l1, !tbaa !24
  %t337 = load i64, ptr %l200, !tbaa !24
  %t339 = icmp ne i64 %t337, %t336
  br i1 %t339, label %bb93, label %bb94
bb93:
  br label %bb106
bb94:
  br label %bb95
bb95:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/typed:LocalUses", ptr %t341, i32 0, i32 27
  %t344 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t343, i64 %t344)
  br label %bb96
bb96:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/typed:LocalUses", ptr %t347, i32 0, i32 28
  store ptr %t349, ptr %l207, !tbaa !29
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/typed:LocalUses", ptr %t350, i32 0, i32 28
  %t353 = load i64, ptr %l16, !tbaa !24
  %t356 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t352, i64 %t353)
  store i64 %t356, ptr %l211
  br label %bb97
bb97:
  %t357 = load ptr, ptr %l207, !tbaa !29
  %t358 = load i64, ptr %l211, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t357, i64 %t358)
  br label %bb98
bb98:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/typed:LocalUses", ptr %t359, i32 0, i32 29
  store ptr %t361, ptr %l213, !tbaa !29
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/typed:LocalUses", ptr %t362, i32 0, i32 29
  %t365 = load i64, ptr %l16, !tbaa !24
  %t368 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t364, i64 %t365)
  store i64 %t368, ptr %l217
  br label %bb99
bb99:
  %t369 = load ptr, ptr %l213, !tbaa !29
  %t370 = load i64, ptr %l217, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t369, i64 %t370)
  br label %bb100
bb100:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/typed:LocalUses", ptr %t371, i32 0, i32 30
  store ptr %t373, ptr %l219, !tbaa !29
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/typed:LocalUses", ptr %t374, i32 0, i32 30
  %t377 = load i64, ptr %l16, !tbaa !24
  %t380 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t376, i64 %t377)
  store i1 %t380, ptr %l223
  br label %bb101
bb101:
  %t381 = load i1, ptr %l223, !tbaa !21
  br i1 %t381, label %bb102, label %bb103
bb102:
  store i1 true, ptr %l224, !tbaa !21
  br label %bb104
bb103:
  %t382 = load i1, ptr %l10, !tbaa !21
  store i1 %t382, ptr %l224, !tbaa !21
  br label %bb104
bb104:
  %t384 = load ptr, ptr %l219, !tbaa !29
  %t385 = load i1, ptr %l224, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t384, i1 %t385)
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t386 = load i64, ptr %l15, !tbaa !24
  %t389 = add i64 %t386, 1
  store i64 %t389, ptr %l15, !tbaa !24
  br label %bb88
bb107:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/typed:LocalUses", ptr %t391, i32 0, i32 24
  %t395 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t393)
  store i64 %t395, ptr %l231
  br label %bb108
bb108:
  %t396 = load i64, ptr %l231, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  store i64 %t396, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t399 = load i64, ptr %l19, !tbaa !24
  %t400 = load i64, ptr %l18, !tbaa !24
  %t403 = icmp sgt i64 %t399, %t400
  br i1 %t403, label %bb109, label %bb110
bb109:
  %t405 = load i64, ptr %l20, !tbaa !24
  %t407 = icmp sgt i64 %t405, 0
  br i1 %t407, label %bb111, label %bb112
bb110:
  store i64 0, ptr %l236, !tbaa !24
  br label %bb114
bb111:
  %t409 = load i64, ptr %l19, !tbaa !24
  %t410 = load i64, ptr %l18, !tbaa !24
  %t413 = sub i64 %t409, %t410
  %t414 = load i64, ptr %l20, !tbaa !24
  %t417 = add i64 %t413, %t414
  %t419 = sub i64 %t417, 1
  %t420 = load i64, ptr %l20, !tbaa !24
  %t423 = sdiv i64 %t419, %t420
  store i64 %t423, ptr %l239, !tbaa !24
  br label %bb113
bb112:
  store i64 0, ptr %l239, !tbaa !24
  br label %bb113
bb113:
  %t425 = load i64, ptr %l239, !tbaa !24
  store i64 %t425, ptr %l236, !tbaa !24
  br label %bb114
bb114:
  %t426 = load i64, ptr %l236, !tbaa !24
  store i64 %t426, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb115
bb115:
  %t427 = load i64, ptr %l22, !tbaa !24
  %t428 = load i64, ptr %l21, !tbaa !24
  %t431 = icmp slt i64 %t427, %t428
  %t433 = xor i1 %t431, true
  br i1 %t433, label %bb116, label %bb117
bb116:
  br label %bb129
bb117:
  br label %bb118
bb118:
  %t435 = load i64, ptr %l18, !tbaa !24
  %t436 = load i64, ptr %l22, !tbaa !24
  %t437 = load i64, ptr %l20, !tbaa !24
  %t440 = mul i64 %t436, %t437
  %t443 = add i64 %t435, %t440
  store i64 %t443, ptr %l23, !tbaa !24
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/typed:LocalUses", ptr %t445, i32 0, i32 24
  %t448 = load i64, ptr %l23, !tbaa !24
  %t451 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t447, i64 %t448)
  store i64 %t451, ptr %l260
  br label %bb119
bb119:
  %t452 = load i64, ptr %l1, !tbaa !24
  %t453 = load i64, ptr %l260, !tbaa !24
  %t455 = icmp ne i64 %t453, %t452
  br i1 %t455, label %bb120, label %bb121
bb120:
  br label %bb128
bb121:
  br label %bb122
bb122:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr %"compiler/typed:LocalUses", ptr %t457, i32 0, i32 24
  %t460 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t459, i64 %t460)
  br label %bb123
bb123:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = getelementptr %"compiler/typed:LocalUses", ptr %t463, i32 0, i32 25
  store ptr %t465, ptr %l267, !tbaa !29
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t468 = getelementptr %"compiler/typed:LocalUses", ptr %t466, i32 0, i32 25
  %t469 = load i64, ptr %l23, !tbaa !24
  %t472 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t468, i64 %t469)
  store i64 %t472, ptr %l271
  br label %bb124
bb124:
  %t473 = load ptr, ptr %l267, !tbaa !29
  %t474 = load i64, ptr %l271, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t473, i64 %t474)
  br label %bb125
bb125:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/typed:LocalUses", ptr %t475, i32 0, i32 26
  store ptr %t477, ptr %l273, !tbaa !29
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/typed:LocalUses", ptr %t478, i32 0, i32 26
  %t481 = load i64, ptr %l23, !tbaa !24
  %t484 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t480, i64 %t481)
  store i64 %t484, ptr %l277
  br label %bb126
bb126:
  %t485 = load ptr, ptr %l273, !tbaa !29
  %t486 = load i64, ptr %l277, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t485, i64 %t486)
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t487 = load i64, ptr %l22, !tbaa !24
  %t490 = add i64 %t487, 1
  store i64 %t490, ptr %l22, !tbaa !24
  br label %bb115
bb129:
  store i64 0, ptr %l24, !tbaa !24
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = getelementptr %"compiler/typed:LocalUses", ptr %t492, i32 0, i32 22
  %t496 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t494)
  store i64 %t496, ptr %l283
  br label %bb130
bb130:
  %t497 = load i64, ptr %l283, !tbaa !24
  store i64 %t497, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t498 = load i64, ptr %l25, !tbaa !24
  %t499 = load i64, ptr %l24, !tbaa !24
  %t502 = icmp sgt i64 %t498, %t499
  br i1 %t502, label %bb131, label %bb132
bb131:
  %t504 = load i64, ptr %l26, !tbaa !24
  %t506 = icmp sgt i64 %t504, 0
  br i1 %t506, label %bb133, label %bb134
bb132:
  store i64 0, ptr %l287, !tbaa !24
  br label %bb136
bb133:
  %t508 = load i64, ptr %l25, !tbaa !24
  %t509 = load i64, ptr %l24, !tbaa !24
  %t512 = sub i64 %t508, %t509
  %t513 = load i64, ptr %l26, !tbaa !24
  %t516 = add i64 %t512, %t513
  %t518 = sub i64 %t516, 1
  %t519 = load i64, ptr %l26, !tbaa !24
  %t522 = sdiv i64 %t518, %t519
  store i64 %t522, ptr %l290, !tbaa !24
  br label %bb135
bb134:
  store i64 0, ptr %l290, !tbaa !24
  br label %bb135
bb135:
  %t524 = load i64, ptr %l290, !tbaa !24
  store i64 %t524, ptr %l287, !tbaa !24
  br label %bb136
bb136:
  %t525 = load i64, ptr %l287, !tbaa !24
  store i64 %t525, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb137
bb137:
  %t526 = load i64, ptr %l28, !tbaa !24
  %t527 = load i64, ptr %l27, !tbaa !24
  %t530 = icmp slt i64 %t526, %t527
  %t532 = xor i1 %t530, true
  br i1 %t532, label %bb138, label %bb139
bb138:
  br label %bb147
bb139:
  br label %bb140
bb140:
  %t534 = load i64, ptr %l24, !tbaa !24
  %t535 = load i64, ptr %l28, !tbaa !24
  %t536 = load i64, ptr %l26, !tbaa !24
  %t539 = mul i64 %t535, %t536
  %t542 = add i64 %t534, %t539
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t546 = getelementptr %"compiler/typed:LocalUses", ptr %t544, i32 0, i32 22
  %t550 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t546, i64 %t542)
  store i64 %t550, ptr %l311
  br label %bb141
bb141:
  %t551 = load i64, ptr %l1, !tbaa !24
  %t552 = load i64, ptr %l311, !tbaa !24
  %t554 = icmp eq i64 %t552, %t551
  br i1 %t554, label %bb142, label %bb143
bb142:
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/typed:LocalUses", ptr %t556, i32 0, i32 2
  %t559 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t558, i64 %t559, i1 true)
  br label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb145
bb145:
  br label %bb146
bb146:
  %t562 = load i64, ptr %l28, !tbaa !24
  %t565 = add i64 %t562, 1
  store i64 %t565, ptr %l28, !tbaa !24
  br label %bb137
bb147:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i64
  %l35 = alloca i64
  %l44 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l57 = alloca i1
  %l59 = alloca ptr
  %l61 = alloca i32
  %l63 = alloca i1
  %l65 = alloca i1
  %l68 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  store i64 %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t16 = load ptr, ptr %l15, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l15, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 8}
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l16, !tbaa !21
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l4
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l5, !tbaa !23
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l6, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:LocalUses", ptr %t43, i32 0, i32 4
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t45, i64 %t46)
  store i1 %t49, ptr %l28
  br label %bb10
bb9:
  br label %bb25
bb10:
  %t50 = load i1, ptr %l28, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb14
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/typed:LocalUses", ptr %t51, i32 0, i32 57
  %t54 = load i64, ptr %t53, !tbaa !24
  store i64 %t54, ptr %l31, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:LocalUses", ptr %t55, i32 0, i32 56
  %t58 = load i64, ptr %l3, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l35
  br label %bb13
bb13:
  %t62 = load i64, ptr %l31, !tbaa !24
  %t63 = load i64, ptr %l35, !tbaa !24
  %t64 = icmp ne i64 %t62, %t63
  store i1 %t64, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t66 = load i1, ptr %l29, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/typed:LocalUses", ptr %t67, i32 0, i32 6
  %t70 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t69, i64 %t70, i1 true)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/typed:LocalUses", ptr %t73, i32 0, i32 4
  %t76 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t75, i64 %t76, i1 true)
  br label %bb19
bb19:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = call i1 @compiler_2ftyped_2ewholeCall(ptr %v2, ptr %t79)
  store i1 %t81, ptr %l44
  br label %bb20
bb20:
  %t82 = load i1, ptr %l44, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb21, label %bb22
bb21:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:LocalUses", ptr %t85, i32 0, i32 5
  %t88 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t87, i64 %t88, i1 true)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %ret
bb25:
  %t91 = load i64, ptr %l3, !tbaa !24
  %t93 = icmp sge i64 %t91, 0
  br i1 %t93, label %bb26, label %bb27
bb26:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t96 = load ptr, ptr %l52, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb28, label %bb29
bb27:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb30
bb28:
  %t99 = load ptr, ptr %l52, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 8}
  %t102 = icmp eq i64 %t100, 0
  store i1 %t102, ptr %l53, !tbaa !21
  br label %bb29
bb29:
  %t103 = load i1, ptr %l53, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l51, !tbaa !21
  br label %bb30
bb30:
  %t106 = load i1, ptr %l51, !tbaa !21
  br i1 %t106, label %bb31, label %bb32
bb31:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/typed:LocalUses", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  store ptr %t110, ptr %l59, !tbaa !29
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t111)
  store i32 %t113, ptr %l61
  br label %bb33
bb32:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb35
bb33:
  %t114 = load ptr, ptr %l59, !tbaa !29
  %t115 = call ptr @__olang_scope_or(ptr %v3, ptr %t114)
  %t116 = call ptr @__olang_scope_hold(ptr %t115)
  %t117 = ptrtoint ptr %t116 to i64
  %t119 = inttoptr i64 %t117 to ptr
  %t120 = load ptr, ptr %l59, !tbaa !29
  %t121 = load i32, ptr %l61, !tbaa !23
  %t122 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t119, ptr %t120, i32 %t121)
  store i1 %t122, ptr %l63
  br label %bb34
bb34:
  %t123 = load i1, ptr %l63, !tbaa !21
  %t124 = xor i1 %t123, true
  store i1 %t124, ptr %l57, !tbaa !21
  br label %bb35
bb35:
  %t126 = load i1, ptr %l57, !tbaa !21
  br i1 %t126, label %bb36, label %bb37
bb36:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t131 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %v3, ptr %t127, ptr %t128)
  store i1 %t131, ptr %l68
  br label %bb38
bb37:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb39
bb38:
  %t132 = load i1, ptr %l68, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l65, !tbaa !21
  br label %bb39
bb39:
  %t135 = load i1, ptr %l65, !tbaa !21
  br i1 %t135, label %bb40, label %bb41
bb40:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/typed:LocalUses", ptr %t136, i32 0, i32 22
  %t139 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t138, i64 %t139)
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/typed:LocalUses", ptr %t142, i32 0, i32 23
  %t145 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t144, ptr %t145)
  br label %bb43
bb43:
  br label %ret
bb44:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t148, ptr %t149, i1 false)
  br label %bb45
bb45:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l14 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca %"compiler/typed:Local"
  %l40 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca %"compiler/typed:Local"
  %l48 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l56 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l66 = alloca i1
  %l75 = alloca i1
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l97 = alloca { i64, [1 x i64] }
  %t200 = alloca { i64, [1 x i64] }, align 8
  %t207 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 20
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t7 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eSet_H54ebfdc15a9c097858a2e264494e7d5a(ptr %v0, ptr %v1, ptr %t3, i64 %t6, ptr %t7)
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:LocalUses", ptr %t12, i32 0, i32 55
  %t15 = load i32, ptr %l1, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:LocalUses", ptr %t18, i32 0, i32 54
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t14, i64 %t17, i64 %t21)
  br label %bb2
bb2:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/typed:LocalUses", ptr %t25, i32 0, i32 56
  %t28 = load i32, ptr %l1, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/typed:LocalUses", ptr %t31, i32 0, i32 57
  %t34 = load i64, ptr %t33, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t27, i64 %t30, i64 %t34)
  br label %bb3
bb3:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:LocalUses", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l34, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t43 = load ptr, ptr %l34, !tbaa !29
  %t44 = call ptr @__olang_scope_or(ptr %v2, ptr %t43)
  %t45 = call ptr @__olang_scope_hold(ptr %t44)
  %t46 = ptrtoint ptr %t45 to i64
  %t48 = inttoptr i64 %t46 to ptr
  %t49 = load ptr, ptr %l34, !tbaa !29
  %t51 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %t48, ptr %t49, i32 %t42)
  store %"compiler/typed:Local" %t51, ptr %l37
  br label %bb4
bb4:
  %t52 = getelementptr %"compiler/typed:Local", ptr %l37, i32 0, i32 4
  %t53 = load i32, ptr %t52, !range !{i32 0, i32 7}
  store i32 %t53, ptr %l3
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:LocalUses", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l40, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:LocalUses", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l42, !tbaa !29
  %t63 = load i32, ptr %l1, !tbaa !23
  %t64 = load ptr, ptr %l42, !tbaa !29
  %t65 = call ptr @__olang_scope_or(ptr %v2, ptr %t64)
  %t66 = call ptr @__olang_scope_hold(ptr %t65)
  %t67 = ptrtoint ptr %t66 to i64
  %t69 = inttoptr i64 %t67 to ptr
  %t70 = load ptr, ptr %l42, !tbaa !29
  %t72 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %t69, ptr %t70, i32 %t63)
  store %"compiler/typed:Local" %t72, ptr %l45
  br label %bb5
bb5:
  %t73 = getelementptr %"compiler/typed:Local", ptr %l45, i32 0, i32 2
  %t74 = load i32, ptr %t73, !tbaa !23
  %t75 = load ptr, ptr %l40, !tbaa !29
  %t76 = call ptr @__olang_scope_or(ptr %v3, ptr %t75)
  %t77 = call ptr @__olang_scope_hold(ptr %t76)
  %t78 = ptrtoint ptr %t77 to i64
  %t80 = inttoptr i64 %t78 to ptr
  %t81 = load ptr, ptr %l40, !tbaa !29
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t80, ptr %t81, i32 %t74)
  store i1 %t83, ptr %l48
  br label %bb6
bb6:
  %t84 = load i1, ptr %l48, !tbaa !21
  br i1 %t84, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb9
bb8:
  %t85 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t87 = trunc i64 2 to i32
  %t88 = icmp eq i32 %t85, %t87
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb9
bb9:
  %t90 = load i1, ptr %l49, !tbaa !21
  br i1 %t90, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb12
bb11:
  %t91 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t93 = trunc i64 4 to i32
  %t94 = icmp eq i32 %t91, %t93
  store i1 %t94, ptr %l52, !tbaa !21
  br label %bb12
bb12:
  %t96 = load i1, ptr %l52, !tbaa !21
  store i1 %t96, ptr %l4, !tbaa !21
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = call i1 @compiler_2ftyped_2emadeBy(ptr %v1, ptr %t97)
  store i1 %t99, ptr %l56
  br label %bb13
bb13:
  %t100 = load i1, ptr %l56, !tbaa !21
  br i1 %t100, label %bb14, label %bb15
bb14:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i32, ptr %l1, !tbaa !23
  %t104 = sext i32 %t102 to i64
  %t107 = getelementptr %"compiler/typed:LocalUses", ptr %t101, i32 0, i32 59
  store i64 %t104, ptr %t107, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/typed:LocalUses", ptr %t108, i32 0, i32 14
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l5, !tbaa !24
  %t113 = load ptr, ptr %l2, !tbaa !29
  store ptr %t113, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb17, label %bb18
bb17:
  %t117 = load ptr, ptr %l62, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 18}
  %t120 = icmp eq i64 %t118, 15
  store i1 %t120, ptr %l63, !tbaa !21
  br label %bb18
bb18:
  %t121 = load i1, ptr %l63, !tbaa !21
  br i1 %t121, label %bb19, label %bb20
bb19:
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 0
  %t126 = load %"compiler/source:Span", ptr %t125
  store %"compiler/source:Span" %t126, ptr %l6
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t130, i32 0, i32 1
  %t132 = load i32, ptr %t131
  store i32 %t132, ptr %l7, !tbaa !23
  %t134 = load ptr, ptr %l2, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l8, !tbaa !29
  %t140 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t142 = trunc i64 1 to i32
  %t143 = icmp eq i32 %t140, %t142
  store i1 %t143, ptr %l66, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb21
bb21:
  %t145 = load i1, ptr %l66, !tbaa !21
  br i1 %t145, label %bb22, label %bb23
bb22:
  %t146 = load ptr, ptr %l2, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 0
  %t150 = load %"compiler/source:Span", ptr %t149
  store %"compiler/source:Span" %t150, ptr %l9
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t154, i32 0, i32 1
  %t156 = load i32, ptr %t155
  store i32 %t156, ptr %l10, !tbaa !23
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t160, i32 0, i32 2
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l11, !tbaa !29
  %t164 = load i1, ptr %l4, !tbaa !21
  %t166 = xor i1 %t164, true
  store i1 %t166, ptr %l75, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb24
bb24:
  %t168 = load i1, ptr %l75, !tbaa !21
  br i1 %t168, label %bb25, label %bb26
bb25:
  %t169 = load ptr, ptr %l2, !tbaa !29
  %t171 = getelementptr { i64, [5 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t171, i32 0, i32 0
  %t173 = load %"compiler/source:Span", ptr %t172
  store %"compiler/source:Span" %t173, ptr %l12
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t177 = getelementptr { i64, [5 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t177, i32 0, i32 1
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l13, !tbaa !23
  %t181 = load ptr, ptr %l2, !tbaa !29
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t183, i32 0, i32 2
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l14, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l1, !tbaa !23
  %t190 = sext i32 %t188 to i64
  %t193 = getelementptr %"compiler/typed:LocalUses", ptr %t187, i32 0, i32 14
  store i64 %t190, ptr %t193, !tbaa !24
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l93, !tbaa !29
  %t195 = load ptr, ptr %l2, !tbaa !29
  store ptr %t195, ptr %l95, !tbaa !29
  %t197 = load i1, ptr %l4, !tbaa !21
  br i1 %t197, label %bb28, label %bb29
bb28:
  %t199 = load i32, ptr %l1, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t200
  %t201 = getelementptr { i64, [1 x i64] }, ptr %t200, i32 0, i32 0
  store i64 4, ptr %t201
  %t203 = insertvalue { i32 } undef, i32 %t199, 0
  %t204 = getelementptr { i64, [1 x i64] }, ptr %t200, i32 0, i32 1
  store { i32 } %t203, ptr %t204
  %t205 = load { i64, [1 x i64] }, ptr %t200
  store { i64, [1 x i64] } %t205, ptr %l97
  br label %bb30
bb29:
  store { i64, [1 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [1 x i64] }, ptr %t207, i32 0, i32 0
  store i64 2, ptr %t208
  %t209 = load { i64, [1 x i64] }, ptr %t207
  store { i64, [1 x i64] } %t209, ptr %l97
  br label %bb30
bb30:
  %t211 = load ptr, ptr %l93, !tbaa !29
  %t212 = load ptr, ptr %l95, !tbaa !29
  %t213 = load { i64, [1 x i64] }, ptr %l97
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t211, ptr %t212, { i64, [1 x i64] } %t213)
  br label %bb31
bb31:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i64, ptr %l5, !tbaa !24
  %t218 = getelementptr %"compiler/typed:LocalUses", ptr %t214, i32 0, i32 14
  store i64 %t215, ptr %t218, !tbaa !24
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/typed:LocalUses", ptr %t219, i32 0, i32 59
  store i64 -1, ptr %t221, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca i32
  %l55 = alloca i1
  %l56 = alloca { i64, [1 x i64] }
  %l59 = alloca ptr
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l135 = alloca ptr
  %l144 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l172 = alloca ptr
  %l173 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca i1
  %l187 = alloca ptr
  %l194 = alloca ptr
  %l198 = alloca ptr
  %l199 = alloca i1
  %l219 = alloca ptr
  %l220 = alloca i1
  %l228 = alloca ptr
  %l245 = alloca { i64, ptr }
  %l255 = alloca ptr
  %l259 = alloca ptr
  %l260 = alloca i1
  %l263 = alloca ptr
  %l264 = alloca i1
  %t75 = alloca { i64, [1 x i64] }, align 8
  %t79 = alloca { i64, [1 x i64] }, align 8
  %t119 = alloca { i64, [1 x i64] }, align 8
  %t154 = alloca { i64, [1 x i64] }, align 8
  %t178 = alloca { i64, [1 x i64] }, align 8
  %t201 = alloca { i64, [1 x i64] }, align 8
  %t228 = alloca { i64, [1 x i64] }, align 8
  %t316 = alloca { i64, [1 x i64] }, align 8
  %t346 = alloca { i64, [1 x i64] }, align 8
  %t354 = alloca { i64, [1 x i64] }, align 8
  %t466 = alloca { i64, [1 x i64] }, align 8
  %t510 = alloca { i64, [1 x i64] }, align 8
  %t546 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t2 = load ptr, ptr %l25, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l25, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l26, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l26, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t22, i32 %t23, ptr %t24)
  br label %bb6
bb6:
  br label %bb136
bb7:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t29 = load ptr, ptr %l36, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l36, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 17}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l37, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l37, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t39, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb20
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %v3, ptr %v2, ptr %t49, ptr %t50, ptr %t51)
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l47, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  store ptr %t56, ptr %l49, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:LocalUses", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l51, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t62)
  store i32 %t64, ptr %l53
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l51, !tbaa !29
  %t66 = call ptr @__olang_scope_or(ptr %v3, ptr %t65)
  %t67 = call ptr @__olang_scope_hold(ptr %t66)
  %t68 = ptrtoint ptr %t67 to i64
  %t70 = inttoptr i64 %t68 to ptr
  %t71 = load ptr, ptr %l51, !tbaa !29
  %t72 = load i32, ptr %l53, !tbaa !23
  %t73 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t70, ptr %t71, i32 %t72)
  store i1 %t73, ptr %l55
  br label %bb15
bb15:
  %t74 = load i1, ptr %l55, !tbaa !21
  br i1 %t74, label %bb16, label %bb17
bb16:
  store { i64, [1 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [1 x i64] }, ptr %t75, i32 0, i32 0
  store i64 5, ptr %t76
  %t77 = load { i64, [1 x i64] }, ptr %t75
  store { i64, [1 x i64] } %t77, ptr %l56
  br label %bb18
bb17:
  store { i64, [1 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [1 x i64] }, ptr %t79, i32 0, i32 0
  store i64 2, ptr %t80
  %t81 = load { i64, [1 x i64] }, ptr %t79
  store { i64, [1 x i64] } %t81, ptr %l56
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t84 = load ptr, ptr %l49, !tbaa !29
  %t85 = load { i64, [1 x i64] }, ptr %l56
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t83, ptr %t84, { i64, [1 x i64] } %t85)
  br label %bb19
bb19:
  br label %bb136
bb20:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t87 = load ptr, ptr %l59, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb21, label %bb22
bb21:
  %t90 = load ptr, ptr %l59, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 17}
  %t93 = icmp eq i64 %t91, 2
  store i1 %t93, ptr %l60, !tbaa !21
  br label %bb22
bb22:
  %t94 = load i1, ptr %l60, !tbaa !21
  br i1 %t94, label %bb23, label %bb24
bb23:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr }, ptr %t97, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb29
bb24:
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t102 = load ptr, ptr %l65, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb25, label %bb26
bb25:
  %t105 = load ptr, ptr %l65, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 17}
  %t108 = icmp eq i64 %t106, 8
  store i1 %t108, ptr %l66, !tbaa !21
  br label %bb26
bb26:
  %t109 = load i1, ptr %l66, !tbaa !21
  br i1 %t109, label %bb27, label %bb28
bb27:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr { i64, [3 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t112, i32 0, i32 1
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l6, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t119
  %t120 = getelementptr { i64, [1 x i64] }, ptr %t119, i32 0, i32 0
  store i64 0, ptr %t120
  %t121 = load { i64, [1 x i64] }, ptr %t119
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t116, ptr %t117, { i64, [1 x i64] } %t121)
  br label %bb30
bb30:
  br label %bb136
bb31:
  %t125 = load ptr, ptr %l1, !tbaa !29
  store ptr %t125, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t126 = load ptr, ptr %l75, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb32, label %bb33
bb32:
  %t129 = load ptr, ptr %l75, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 17}
  %t132 = icmp eq i64 %t130, 6
  store i1 %t132, ptr %l76, !tbaa !21
  br label %bb33
bb33:
  %t133 = load i1, ptr %l76, !tbaa !21
  br i1 %t133, label %bb34, label %bb35
bb34:
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", ptr }, ptr %t136, i32 0, i32 1
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t140 = load ptr, ptr %l7, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb37, label %bb38
bb37:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/typed:LocalUses", ptr %t146, i32 0, i32 31
  %t149 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t148, ptr %t149)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t154
  %t155 = getelementptr { i64, [1 x i64] }, ptr %t154, i32 0, i32 0
  store i64 3, ptr %t155
  %t156 = load { i64, [1 x i64] }, ptr %t154
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t152, ptr %t153, { i64, [1 x i64] } %t156)
  br label %bb41
bb41:
  br label %bb136
bb42:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t161 = load ptr, ptr %l90, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb43, label %bb44
bb43:
  %t164 = load ptr, ptr %l90, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 17}
  %t167 = icmp eq i64 %t165, 15
  store i1 %t167, ptr %l91, !tbaa !21
  br label %bb44
bb44:
  %t168 = load i1, ptr %l91, !tbaa !21
  br i1 %t168, label %bb45, label %bb46
bb45:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [3 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", ptr }, ptr %t171, i32 0, i32 1
  %t173 = load ptr, ptr %t172
  store ptr %t173, ptr %l8, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load ptr, ptr %l8, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [1 x i64] }, ptr %t178, i32 0, i32 0
  store i64 5, ptr %t179
  %t180 = load { i64, [1 x i64] }, ptr %t178
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t175, ptr %t176, { i64, [1 x i64] } %t180)
  br label %bb48
bb48:
  br label %bb136
bb49:
  %t184 = load ptr, ptr %l1, !tbaa !29
  store ptr %t184, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t185 = load ptr, ptr %l100, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb50, label %bb51
bb50:
  %t188 = load ptr, ptr %l100, !tbaa !29
  %t189 = load i64, ptr %t188, !range !{i64 0, i64 17}
  %t191 = icmp eq i64 %t189, 16
  store i1 %t191, ptr %l101, !tbaa !21
  br label %bb51
bb51:
  %t192 = load i1, ptr %l101, !tbaa !21
  br i1 %t192, label %bb52, label %bb53
bb52:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", ptr }, ptr %t195, i32 0, i32 1
  %t197 = load ptr, ptr %t196
  store ptr %t197, ptr %l9, !tbaa !29
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l9, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t201
  %t202 = getelementptr { i64, [1 x i64] }, ptr %t201, i32 0, i32 0
  store i64 5, ptr %t202
  %t203 = load { i64, [1 x i64] }, ptr %t201
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t199, ptr %t200, { i64, [1 x i64] } %t203)
  br label %bb55
bb55:
  br label %bb136
bb56:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t208 = load ptr, ptr %l109, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb57, label %bb58
bb57:
  %t211 = load ptr, ptr %l109, !tbaa !29
  %t212 = load i64, ptr %t211, !range !{i64 0, i64 17}
  %t214 = icmp eq i64 %t212, 3
  store i1 %t214, ptr %l110, !tbaa !21
  br label %bb58
bb58:
  %t215 = load i1, ptr %l110, !tbaa !21
  br i1 %t215, label %bb59, label %bb60
bb59:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [3 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr }, ptr %t218, i32 0, i32 1
  %t220 = load ptr, ptr %t219
  store ptr %t220, ptr %l10, !tbaa !29
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load ptr, ptr %l10, !tbaa !29
  %t225 = getelementptr %"compiler/typed:If", ptr %t223, i32 0, i32 0
  %t226 = load ptr, ptr %t225, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t228
  %t229 = getelementptr { i64, [1 x i64] }, ptr %t228, i32 0, i32 0
  store i64 0, ptr %t229
  %t230 = load { i64, [1 x i64] }, ptr %t228
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t222, ptr %t226, { i64, [1 x i64] } %t230)
  br label %bb62
bb62:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l10, !tbaa !29
  %t237 = getelementptr %"compiler/typed:If", ptr %t235, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t234, ptr %t238)
  br label %bb63
bb63:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l10, !tbaa !29
  %t245 = getelementptr %"compiler/typed:If", ptr %t243, i32 0, i32 2
  %t246 = load ptr, ptr %t245, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t242, ptr %t246)
  br label %bb64
bb64:
  br label %bb136
bb65:
  %t249 = load ptr, ptr %l1, !tbaa !29
  store ptr %t249, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t250 = load ptr, ptr %l127, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb66, label %bb67
bb66:
  %t253 = load ptr, ptr %l127, !tbaa !29
  %t254 = load i64, ptr %t253, !range !{i64 0, i64 17}
  %t256 = icmp eq i64 %t254, 4
  store i1 %t256, ptr %l128, !tbaa !21
  br label %bb67
bb67:
  %t257 = load i1, ptr %l128, !tbaa !21
  br i1 %t257, label %bb68, label %bb69
bb68:
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t260, i32 0, i32 1
  %t262 = load ptr, ptr %t261
  store ptr %t262, ptr %l11, !tbaa !29
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [3 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t266, i32 0, i32 2
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l12, !tbaa !29
  br label %bb70
bb69:
  br label %bb73
bb70:
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l135, !tbaa !29
  %t271 = load ptr, ptr %l135, !tbaa !29
  %t272 = getelementptr %"compiler/typed:LocalUses", ptr %t271, i32 0, i32 57
  %t273 = load i64, ptr %t272, !tbaa !24
  %t276 = add i64 %t273, 1
  %t278 = load ptr, ptr %l135, !tbaa !29
  %t279 = getelementptr %"compiler/typed:LocalUses", ptr %t278, i32 0, i32 57
  store i64 %t276, ptr %t279, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t280, ptr %t281)
  br label %bb71
bb71:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t285, ptr %t286)
  br label %bb72
bb72:
  %t289 = load ptr, ptr %l0, !tbaa !29
  store ptr %t289, ptr %l144, !tbaa !29
  %t290 = load ptr, ptr %l144, !tbaa !29
  %t291 = getelementptr %"compiler/typed:LocalUses", ptr %t290, i32 0, i32 57
  %t292 = load i64, ptr %t291, !tbaa !24
  %t295 = sub i64 %t292, 1
  %t297 = load ptr, ptr %l144, !tbaa !29
  %t298 = getelementptr %"compiler/typed:LocalUses", ptr %t297, i32 0, i32 57
  store i64 %t295, ptr %t298, !tbaa !24
  br label %bb136
bb73:
  %t299 = load ptr, ptr %l1, !tbaa !29
  store ptr %t299, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t300 = load ptr, ptr %l148, !tbaa !29
  %t301 = icmp ne ptr %t300, null
  br i1 %t301, label %bb74, label %bb75
bb74:
  %t303 = load ptr, ptr %l148, !tbaa !29
  %t304 = load i64, ptr %t303, !range !{i64 0, i64 17}
  %t306 = icmp eq i64 %t304, 9
  store i1 %t306, ptr %l149, !tbaa !21
  br label %bb75
bb75:
  %t307 = load i1, ptr %l149, !tbaa !21
  br i1 %t307, label %bb76, label %bb77
bb76:
  %t308 = load ptr, ptr %l1, !tbaa !29
  %t310 = getelementptr { i64, [3 x i64] }, ptr %t308, i32 0, i32 1
  %t311 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t310, i32 0, i32 2
  %t312 = load ptr, ptr %t311
  store ptr %t312, ptr %l13, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l13, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t316
  %t317 = getelementptr { i64, [1 x i64] }, ptr %t316, i32 0, i32 0
  store i64 0, ptr %t317
  %t318 = load { i64, [1 x i64] }, ptr %t316
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t314, ptr %t315, { i64, [1 x i64] } %t318)
  br label %bb79
bb79:
  br label %bb136
bb80:
  %t322 = load ptr, ptr %l1, !tbaa !29
  store ptr %t322, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t323 = load ptr, ptr %l157, !tbaa !29
  %t324 = icmp ne ptr %t323, null
  br i1 %t324, label %bb81, label %bb82
bb81:
  %t326 = load ptr, ptr %l157, !tbaa !29
  %t327 = load i64, ptr %t326, !range !{i64 0, i64 17}
  %t329 = icmp eq i64 %t327, 10
  store i1 %t329, ptr %l158, !tbaa !21
  br label %bb82
bb82:
  %t330 = load i1, ptr %l158, !tbaa !21
  br i1 %t330, label %bb83, label %bb84
bb83:
  %t331 = load ptr, ptr %l1, !tbaa !29
  %t333 = getelementptr { i64, [3 x i64] }, ptr %t331, i32 0, i32 1
  %t334 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t333, i32 0, i32 1
  %t335 = load ptr, ptr %t334
  store ptr %t335, ptr %l14, !tbaa !29
  %t337 = load ptr, ptr %l1, !tbaa !29
  %t339 = getelementptr { i64, [3 x i64] }, ptr %t337, i32 0, i32 1
  %t340 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t339, i32 0, i32 2
  %t341 = load ptr, ptr %t340
  store ptr %t341, ptr %l15, !tbaa !29
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l14, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t346
  %t347 = getelementptr { i64, [1 x i64] }, ptr %t346, i32 0, i32 0
  store i64 0, ptr %t347
  %t348 = load { i64, [1 x i64] }, ptr %t346
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t343, ptr %t344, { i64, [1 x i64] } %t348)
  br label %bb86
bb86:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l15, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t354
  %t355 = getelementptr { i64, [1 x i64] }, ptr %t354, i32 0, i32 0
  store i64 0, ptr %t355
  %t356 = load { i64, [1 x i64] }, ptr %t354
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t352, ptr %t353, { i64, [1 x i64] } %t356)
  br label %bb87
bb87:
  br label %bb136
bb88:
  %t360 = load ptr, ptr %l1, !tbaa !29
  store ptr %t360, ptr %l172, !tbaa !29
  store i1 false, ptr %l173, !tbaa !21
  %t361 = load ptr, ptr %l172, !tbaa !29
  %t362 = icmp ne ptr %t361, null
  br i1 %t362, label %bb89, label %bb90
bb89:
  %t364 = load ptr, ptr %l172, !tbaa !29
  %t365 = load i64, ptr %t364, !range !{i64 0, i64 17}
  %t367 = icmp eq i64 %t365, 11
  store i1 %t367, ptr %l173, !tbaa !21
  br label %bb90
bb90:
  %t368 = load i1, ptr %l173, !tbaa !21
  br i1 %t368, label %bb91, label %bb92
bb91:
  %t369 = load ptr, ptr %l1, !tbaa !29
  %t371 = getelementptr { i64, [3 x i64] }, ptr %t369, i32 0, i32 1
  %t372 = getelementptr { %"compiler/source:Span", ptr }, ptr %t371, i32 0, i32 1
  %t373 = load ptr, ptr %t372
  store ptr %t373, ptr %l16, !tbaa !29
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t375, ptr %t376)
  br label %bb94
bb94:
  br label %bb136
bb95:
  %t380 = load ptr, ptr %l1, !tbaa !29
  store ptr %t380, ptr %l181, !tbaa !29
  store i1 false, ptr %l182, !tbaa !21
  %t381 = load ptr, ptr %l181, !tbaa !29
  %t382 = icmp ne ptr %t381, null
  br i1 %t382, label %bb96, label %bb97
bb96:
  %t384 = load ptr, ptr %l181, !tbaa !29
  %t385 = load i64, ptr %t384, !range !{i64 0, i64 17}
  %t387 = icmp eq i64 %t385, 12
  store i1 %t387, ptr %l182, !tbaa !21
  br label %bb97
bb97:
  %t388 = load i1, ptr %l182, !tbaa !21
  br i1 %t388, label %bb98, label %bb99
bb98:
  %t389 = load ptr, ptr %l1, !tbaa !29
  %t391 = getelementptr { i64, [3 x i64] }, ptr %t389, i32 0, i32 1
  %t392 = getelementptr { %"compiler/source:Span", ptr }, ptr %t391, i32 0, i32 1
  %t393 = load ptr, ptr %t392
  store ptr %t393, ptr %l17, !tbaa !29
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t395 = load ptr, ptr %l0, !tbaa !29
  store ptr %t395, ptr %l187, !tbaa !29
  %t396 = load ptr, ptr %l187, !tbaa !29
  %t397 = getelementptr %"compiler/typed:LocalUses", ptr %t396, i32 0, i32 57
  %t398 = load i64, ptr %t397, !tbaa !24
  %t401 = add i64 %t398, 1
  %t403 = load ptr, ptr %l187, !tbaa !29
  %t404 = getelementptr %"compiler/typed:LocalUses", ptr %t403, i32 0, i32 57
  store i64 %t401, ptr %t404, !tbaa !24
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t405, ptr %t406)
  br label %bb101
bb101:
  %t410 = load ptr, ptr %l0, !tbaa !29
  store ptr %t410, ptr %l194, !tbaa !29
  %t411 = load ptr, ptr %l194, !tbaa !29
  %t412 = getelementptr %"compiler/typed:LocalUses", ptr %t411, i32 0, i32 57
  %t413 = load i64, ptr %t412, !tbaa !24
  %t416 = sub i64 %t413, 1
  %t418 = load ptr, ptr %l194, !tbaa !29
  %t419 = getelementptr %"compiler/typed:LocalUses", ptr %t418, i32 0, i32 57
  store i64 %t416, ptr %t419, !tbaa !24
  br label %bb136
bb102:
  %t420 = load ptr, ptr %l1, !tbaa !29
  store ptr %t420, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t421 = load ptr, ptr %l198, !tbaa !29
  %t422 = icmp ne ptr %t421, null
  br i1 %t422, label %bb103, label %bb104
bb103:
  %t424 = load ptr, ptr %l198, !tbaa !29
  %t425 = load i64, ptr %t424, !range !{i64 0, i64 17}
  %t427 = icmp eq i64 %t425, 13
  store i1 %t427, ptr %l199, !tbaa !21
  br label %bb104
bb104:
  %t428 = load i1, ptr %l199, !tbaa !21
  br i1 %t428, label %bb105, label %bb106
bb105:
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr { i64, [3 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", ptr }, ptr %t431, i32 0, i32 1
  %t433 = load ptr, ptr %t432
  store ptr %t433, ptr %l18, !tbaa !29
  br label %bb107
bb106:
  br label %bb110
bb107:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/typed:LocalUses", ptr %t435, i32 0, i32 58
  %t438 = load i64, ptr %t437, !tbaa !24
  store i64 %t438, ptr %l19, !tbaa !24
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/typed:LocalUses", ptr %t441, i32 0, i32 54
  %t444 = load i64, ptr %t443, !tbaa !24
  %t447 = getelementptr %"compiler/typed:LocalUses", ptr %t440, i32 0, i32 58
  store i64 %t444, ptr %t447, !tbaa !24
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load ptr, ptr %l18, !tbaa !29
  %t451 = getelementptr %"compiler/typed:Join", ptr %t449, i32 0, i32 0
  %t452 = load ptr, ptr %t451, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t448, ptr %t452)
  br label %bb108
bb108:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load i64, ptr %l19, !tbaa !24
  %t460 = getelementptr %"compiler/typed:LocalUses", ptr %t456, i32 0, i32 58
  store i64 %t457, ptr %t460, !tbaa !24
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load ptr, ptr %l18, !tbaa !29
  %t464 = getelementptr %"compiler/typed:Join", ptr %t462, i32 0, i32 2
  %t465 = load { i64, ptr }, ptr %t464, !tbaa !27
  store { i64, [1 x i64] } zeroinitializer, ptr %t466
  %t467 = getelementptr { i64, [1 x i64] }, ptr %t466, i32 0, i32 0
  store i64 5, ptr %t467
  %t468 = load { i64, [1 x i64] }, ptr %t466
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t461, { i64, ptr } %t465, { i64, [1 x i64] } %t468)
  br label %bb109
bb109:
  br label %bb136
bb110:
  %t472 = load ptr, ptr %l1, !tbaa !29
  store ptr %t472, ptr %l219, !tbaa !29
  store i1 false, ptr %l220, !tbaa !21
  %t473 = load ptr, ptr %l219, !tbaa !29
  %t474 = icmp ne ptr %t473, null
  br i1 %t474, label %bb111, label %bb112
bb111:
  %t476 = load ptr, ptr %l219, !tbaa !29
  %t477 = load i64, ptr %t476, !range !{i64 0, i64 17}
  %t479 = icmp eq i64 %t477, 14
  store i1 %t479, ptr %l220, !tbaa !21
  br label %bb112
bb112:
  %t480 = load i1, ptr %l220, !tbaa !21
  br i1 %t480, label %bb113, label %bb114
bb113:
  %t481 = load ptr, ptr %l1, !tbaa !29
  %t483 = getelementptr { i64, [3 x i64] }, ptr %t481, i32 0, i32 1
  %t484 = getelementptr { %"compiler/source:Span", ptr }, ptr %t483, i32 0, i32 1
  %t485 = load ptr, ptr %t484
  store ptr %t485, ptr %l20, !tbaa !29
  br label %bb115
bb114:
  br label %bb125
bb115:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load ptr, ptr %l20, !tbaa !29
  %t490 = getelementptr %"compiler/typed:Spawn", ptr %t488, i32 0, i32 0
  %t491 = load { i64, ptr }, ptr %t490, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etargets(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t487, { i64, ptr } %t491)
  br label %bb116
bb116:
  %t494 = load ptr, ptr %l0, !tbaa !29
  store ptr %t494, ptr %l228, !tbaa !29
  %t495 = load ptr, ptr %l228, !tbaa !29
  %t496 = getelementptr %"compiler/typed:LocalUses", ptr %t495, i32 0, i32 36
  %t497 = load i64, ptr %t496, !tbaa !24
  %t500 = add i64 %t497, 1
  %t502 = load ptr, ptr %l228, !tbaa !29
  %t503 = getelementptr %"compiler/typed:LocalUses", ptr %t502, i32 0, i32 36
  store i64 %t500, ptr %t503, !tbaa !24
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = load ptr, ptr %l20, !tbaa !29
  %t507 = getelementptr %"compiler/typed:Spawn", ptr %t505, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t510
  %t511 = getelementptr { i64, [1 x i64] }, ptr %t510, i32 0, i32 0
  store i64 5, ptr %t511
  %t512 = load { i64, [1 x i64] }, ptr %t510
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t504, ptr %t508, { i64, [1 x i64] } %t512)
  br label %bb117
bb117:
  %t516 = load ptr, ptr %l20, !tbaa !29
  %t518 = getelementptr %"compiler/typed:Spawn", ptr %t516, i32 0, i32 2
  %t519 = load { i64, ptr }, ptr %t518, !tbaa !27
  store { i64, ptr } %t519, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t521 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t521, 0
  store i64 %t523, ptr %l23, !tbaa !24
  br label %bb118
bb118:
  %t525 = load i64, ptr %l22, !tbaa !24
  %t526 = load i64, ptr %l23, !tbaa !24
  %t529 = icmp slt i64 %t525, %t526
  %t531 = xor i1 %t529, true
  br i1 %t531, label %bb119, label %bb120
bb119:
  br label %bb124
bb120:
  br label %bb121
bb121:
  %t533 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t533, ptr %l245, !tbaa !27
  %t534 = load i64, ptr %l22, !tbaa !24
  %t536 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t537 = load ptr, ptr %t536, !tbaa !27
  %t538 = getelementptr ptr, ptr %t537, i64 %t534
  %t539 = load ptr, ptr %t538, !tbaa !39
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t544 = getelementptr %"compiler/typed:TaskClause", ptr %t539, i32 0, i32 3
  %t545 = load ptr, ptr %t544, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t546
  %t547 = getelementptr { i64, [1 x i64] }, ptr %t546, i32 0, i32 0
  store i64 5, ptr %t547
  %t548 = load { i64, [1 x i64] }, ptr %t546
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t541, ptr %t545, { i64, [1 x i64] } %t548)
  br label %bb122
bb122:
  br label %bb123
bb123:
  %t552 = load i64, ptr %l22, !tbaa !24
  %t555 = add i64 %t552, 1
  store i64 %t555, ptr %l22, !tbaa !24
  br label %bb118
bb124:
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l255, !tbaa !29
  %t558 = load ptr, ptr %l255, !tbaa !29
  %t559 = getelementptr %"compiler/typed:LocalUses", ptr %t558, i32 0, i32 36
  %t560 = load i64, ptr %t559, !tbaa !24
  %t563 = sub i64 %t560, 1
  %t565 = load ptr, ptr %l255, !tbaa !29
  %t566 = getelementptr %"compiler/typed:LocalUses", ptr %t565, i32 0, i32 36
  store i64 %t563, ptr %t566, !tbaa !24
  br label %bb136
bb125:
  %t567 = load ptr, ptr %l1, !tbaa !29
  store ptr %t567, ptr %l259, !tbaa !29
  store i1 false, ptr %l260, !tbaa !21
  %t568 = load ptr, ptr %l259, !tbaa !29
  %t569 = icmp ne ptr %t568, null
  br i1 %t569, label %bb126, label %bb127
bb126:
  %t571 = load ptr, ptr %l259, !tbaa !29
  %t572 = load i64, ptr %t571, !range !{i64 0, i64 17}
  %t574 = icmp eq i64 %t572, 5
  store i1 %t574, ptr %l260, !tbaa !21
  br label %bb127
bb127:
  %t575 = load i1, ptr %l260, !tbaa !21
  br i1 %t575, label %bb128, label %bb129
bb128:
  br label %bb134
bb129:
  %t576 = load ptr, ptr %l1, !tbaa !29
  store ptr %t576, ptr %l263, !tbaa !29
  store i1 false, ptr %l264, !tbaa !21
  %t577 = load ptr, ptr %l263, !tbaa !29
  %t578 = icmp ne ptr %t577, null
  br i1 %t578, label %bb130, label %bb131
bb130:
  %t580 = load ptr, ptr %l263, !tbaa !29
  %t581 = load i64, ptr %t580, !range !{i64 0, i64 17}
  %t583 = icmp eq i64 %t581, 7
  store i1 %t583, ptr %l264, !tbaa !21
  br label %bb131
bb131:
  %t584 = load i1, ptr %l264, !tbaa !21
  br i1 %t584, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb136
bb135:
  call void @__olang_check_failed(ptr @olang_loc_9a2d2471d97215b1_125b5d47933e1fad)
  unreachable
bb136:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etargets(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %t30, i1 false)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t33, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eunkept(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l17 = alloca i1
  %l20 = alloca %"compiler/typed:argRoot"
  %l26 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i32
  %l42 = alloca %"compiler/typed:argRoot"
  %l47 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l63 = alloca i64
  %l66 = alloca i64
  %l75 = alloca i64
  %l78 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br i1 %a5, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:LocalUses", ptr %t3, i32 0, i32 36
  %t6 = load i64, ptr %t5, !tbaa !24
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t14 = call %"compiler/typed:argRoot" @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eargRoot(ptr %v0, ptr %v1, ptr %v2, ptr %t10, ptr %t11)
  store %"compiler/typed:argRoot" %t14, ptr %l20
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t15 = getelementptr %"compiler/typed:argRoot", ptr %l20, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp sge i64 %t16, 0
  store i1 %t18, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i1, ptr %l17, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
bb7:
  %t21 = load i32, ptr %l2, !tbaa !23
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t25 = icmp eq i32 %t21, %t22
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:LocalUses", ptr %t27, i32 0, i32 36
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  store i1 %t32, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l26, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/typed:LocalUses", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %l32, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = load ptr, ptr %l32, !tbaa !29
  %t41 = call ptr @__olang_scope_or(ptr %v2, ptr %t40)
  %t42 = call ptr @__olang_scope_hold(ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  %t45 = inttoptr i64 %t43 to ptr
  %t46 = load ptr, ptr %l32, !tbaa !29
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t45, ptr %t46, i32 %t39)
  store i32 %t48, ptr %l35
  br label %bb13
bb13:
  %t49 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t51 = trunc i64 21 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  store i1 %t54, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l30, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t62 = call %"compiler/typed:argRoot" @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eargRoot(ptr %v0, ptr %v1, ptr %v2, ptr %t58, ptr %t59)
  store %"compiler/typed:argRoot" %t62, ptr %l42
  br label %bb18
bb18:
  %t63 = getelementptr %"compiler/typed:argRoot", ptr %l42, i32 0, i32 0
  %t64 = load i64, ptr %t63, !tbaa !24
  %t66 = icmp slt i64 %t64, 0
  br i1 %t66, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:LocalUses", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  store ptr %t72, ptr %l47, !tbaa !29
  %t73 = load i32, ptr %l2, !tbaa !23
  %t74 = load ptr, ptr %l47, !tbaa !29
  %t75 = call ptr @__olang_scope_or(ptr %v2, ptr %t74)
  %t76 = call ptr @__olang_scope_hold(ptr %t75)
  %t77 = ptrtoint ptr %t76 to i64
  %t79 = inttoptr i64 %t77 to ptr
  %t80 = load ptr, ptr %l47, !tbaa !29
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsOf(ptr %t79, ptr %s0, ptr %t80, i32 %t73)
  store { i64, ptr } %t82, ptr %l50
  br label %bb22
bb22:
  %t83 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t83, ptr %l6, !tbaa !27
  br i1 %a4, label %bb23, label %bb24
bb23:
  %t86 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t90 = icmp sgt i64 %t88, 0
  store i1 %t90, ptr %l52, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t92 = load i1, ptr %l52, !tbaa !21
  br i1 %t92, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  store i64 0, ptr %l7, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t98 = sdiv i64 %t96, 3
  store i64 %t98, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t100 = load i64, ptr %l8, !tbaa !24
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb29, label %bb30
bb29:
  %t106 = load i64, ptr %l9, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb34
bb31:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l66, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb33
bb33:
  %t126 = load i64, ptr %l66, !tbaa !24
  store i64 %t126, ptr %l63, !tbaa !24
  br label %bb34
bb34:
  %t127 = load i64, ptr %l63, !tbaa !24
  store i64 %t127, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = sub i64 %t128, 1
  store i64 %t129, ptr %l75, !tbaa !24
  %t130 = load i64, ptr %l10, !tbaa !24
  %t131 = icmp slt i64 %t130, 2147483648
  %t132 = load i64, ptr %l11, !tbaa !24
  %t133 = icmp sge i64 %t132, 0
  %t136 = and i1 %t131, %t133
  store i1 %t136, ptr %l78, !tbaa !21
  br label %bb35
bb35:
  %t137 = load i64, ptr %l11, !tbaa !24
  %t138 = load i64, ptr %l10, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb36, label %bb37
bb36:
  br label %bb43
bb37:
  br label %bb38
bb38:
  %t145 = load i64, ptr %l7, !tbaa !24
  %t146 = load i64, ptr %l11, !tbaa !24
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = mul i64 %t146, %t147
  %t153 = add i64 %t145, %t150
  %t157 = mul i64 3, %t153
  %t159 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i64, ptr %t160, i64 %t157
  %t162 = load i64, ptr %t161, !tbaa !34
  %t166 = icmp eq i64 %t162, %a3
  br i1 %t166, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t169 = load i64, ptr %l11, !tbaa !24
  %t172 = add i64 %t169, 1
  store i64 %t172, ptr %l11, !tbaa !24
  br label %bb35
bb43:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l6, !tbaa !24
  br label %bb32
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t39 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store i64 %t39, ptr %l23
  br label %bb12
bb12:
  %t40 = load i64, ptr %l23, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  br label %bb32
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 8}
  %t48 = icmp eq i64 %t46, 4
  store i1 %t48, ptr %l25, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l25, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Elem", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  store i64 %t63, ptr %l33
  br label %bb19
bb19:
  %t64 = load i64, ptr %l33, !tbaa !24
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb32
bb20:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t66 = load ptr, ptr %l34, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l34, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t73 = load i1, ptr %l35, !tbaa !21
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Payload", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  store i64 %t87, ptr %l43
  br label %bb26
bb26:
  %t88 = load i64, ptr %l43, !tbaa !24
  store i64 %t88, ptr %l6, !tbaa !24
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_4086334666941342_2cd2470309ce51f6)
  unreachable
bb32:
  %t89 = load i64, ptr %l6, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eviewInto(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i1
  %l57 = alloca i1
  %l64 = alloca i1
  %l75 = alloca i1
  %l81 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i64
  %l110 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca i64
  %l118 = alloca i64
  %l122 = alloca i64
  %l126 = alloca i1
  %l127 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 39
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load i1, ptr %l16, !tbaa !21
  store i1 %t8, ptr %l4, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:LocalUses", ptr %t9, i32 0, i32 42
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l20
  br label %bb2
bb2:
  %t16 = load i1, ptr %l20, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb6
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:LocalUses", ptr %t17, i32 0, i32 18
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t19, i64 %t20)
  store i1 %t23, ptr %l25
  br label %bb5
bb5:
  %t24 = load i1, ptr %l25, !tbaa !21
  store i1 %t24, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l21, !tbaa !21
  store i1 %t25, ptr %l5, !tbaa !21
  %t26 = load i1, ptr %l3, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load i1, ptr %l4, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb8:
  %t30 = load i1, ptr %l4, !tbaa !21
  br i1 %t30, label %bb29, label %bb30
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb12
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/typed:LocalUses", ptr %t32, i32 0, i32 40
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t34, i64 %t35)
  store i1 %t38, ptr %l32
  br label %bb11
bb11:
  %t39 = load i1, ptr %l32, !tbaa !21
  store i1 %t39, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l28, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb16
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/typed:LocalUses", ptr %t41, i32 0, i32 41
  %t44 = load i64, ptr %l1, !tbaa !24
  %t47 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t43, i64 %t44)
  store i1 %t47, ptr %l37
  br label %bb15
bb15:
  %t48 = load i1, ptr %l37, !tbaa !21
  store i1 %t48, ptr %l33, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l33, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/typed:LocalUses", ptr %t50, i32 0, i32 40
  %t53 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t52, i64 %t53, i1 true)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t56 = load i1, ptr %l5, !tbaa !21
  br i1 %t56, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb24
bb22:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:LocalUses", ptr %t58, i32 0, i32 43
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t60, i64 %t61)
  store i1 %t64, ptr %l46
  br label %bb23
bb23:
  %t65 = load i1, ptr %l46, !tbaa !21
  store i1 %t65, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t66 = load i1, ptr %l42, !tbaa !21
  br i1 %t66, label %bb25, label %bb26
bb25:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/typed:LocalUses", ptr %t67, i32 0, i32 43
  %t70 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t69, i64 %t70, i1 true)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb52
bb29:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/typed:LocalUses", ptr %t73, i32 0, i32 39
  %t76 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t75, i64 %t76, i1 true)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:LocalUses", ptr %t79, i32 0, i32 40
  %t82 = load i64, ptr %l1, !tbaa !24
  %t85 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t81, i64 %t82)
  store i1 %t85, ptr %l57
  br label %bb33
bb33:
  %t86 = load i1, ptr %l57, !tbaa !21
  br i1 %t86, label %bb34, label %bb35
bb34:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:LocalUses", ptr %t87, i32 0, i32 40
  %t90 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t89, i64 %t90, i1 true)
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:LocalUses", ptr %t93, i32 0, i32 41
  %t96 = load i64, ptr %l1, !tbaa !24
  %t99 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t95, i64 %t96)
  store i1 %t99, ptr %l64
  br label %bb38
bb38:
  %t100 = load i1, ptr %l64, !tbaa !21
  br i1 %t100, label %bb39, label %bb40
bb39:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/typed:LocalUses", ptr %t101, i32 0, i32 41
  %t104 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t103, i64 %t104, i1 true)
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  %t107 = load i1, ptr %l5, !tbaa !21
  br i1 %t107, label %bb43, label %bb44
bb43:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/typed:LocalUses", ptr %t109, i32 0, i32 42
  %t112 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t111, i64 %t112, i1 true)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:LocalUses", ptr %t115, i32 0, i32 43
  %t118 = load i64, ptr %l1, !tbaa !24
  %t121 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t117, i64 %t118)
  store i1 %t121, ptr %l75
  br label %bb47
bb47:
  %t122 = load i1, ptr %l75, !tbaa !21
  br i1 %t122, label %bb48, label %bb49
bb48:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/typed:LocalUses", ptr %t123, i32 0, i32 43
  %t126 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t125, i64 %t126, i1 true)
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/typed:LocalUses", ptr %t129, i32 0, i32 45
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t131)
  store i64 %t133, ptr %l81
  br label %bb53
bb53:
  %t134 = load i64, ptr %l81, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t138 = load i64, ptr %l7, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb54, label %bb55
bb54:
  %t143 = load i64, ptr %l9, !tbaa !24
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb59
bb56:
  %t147 = load i64, ptr %l8, !tbaa !24
  %t148 = load i64, ptr %l7, !tbaa !24
  %t151 = sub i64 %t147, %t148
  %t152 = load i64, ptr %l9, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t157 = sub i64 %t155, 1
  %t158 = load i64, ptr %l9, !tbaa !24
  %t161 = sdiv i64 %t157, %t158
  store i64 %t161, ptr %l89, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb58
bb58:
  %t163 = load i64, ptr %l89, !tbaa !24
  store i64 %t163, ptr %l86, !tbaa !24
  br label %bb59
bb59:
  %t164 = load i64, ptr %l86, !tbaa !24
  store i64 %t164, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb60
bb60:
  %t165 = load i64, ptr %l11, !tbaa !24
  %t166 = load i64, ptr %l10, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb61, label %bb62
bb61:
  br label %bb76
bb62:
  br label %bb63
bb63:
  %t173 = load i64, ptr %l7, !tbaa !24
  %t174 = load i64, ptr %l11, !tbaa !24
  %t175 = load i64, ptr %l9, !tbaa !24
  %t178 = mul i64 %t174, %t175
  %t181 = add i64 %t173, %t178
  store i64 %t181, ptr %l12, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/typed:LocalUses", ptr %t183, i32 0, i32 45
  %t186 = load i64, ptr %l12, !tbaa !24
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t185, i64 %t186)
  store i64 %t189, ptr %l110
  br label %bb64
bb64:
  %t190 = load i64, ptr %l1, !tbaa !24
  %t191 = load i64, ptr %l110, !tbaa !24
  %t193 = icmp eq i64 %t191, %t190
  br i1 %t193, label %bb65, label %bb66
bb65:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l113, !tbaa !29
  %t196 = load i64, ptr %l2, !tbaa !24
  store i64 %t196, ptr %l114, !tbaa !24
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/typed:LocalUses", ptr %t197, i32 0, i32 46
  %t200 = load i64, ptr %l12, !tbaa !24
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t199, i64 %t200)
  store i64 %t203, ptr %l118
  br label %bb67
bb66:
  br label %bb74
bb67:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/typed:LocalUses", ptr %t204, i32 0, i32 47
  %t207 = load i64, ptr %l12, !tbaa !24
  %t210 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t206, i64 %t207)
  store i64 %t210, ptr %l122
  br label %bb68
bb68:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/typed:LocalUses", ptr %t211, i32 0, i32 48
  %t214 = load i64, ptr %l12, !tbaa !24
  %t217 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t213, i64 %t214)
  store i1 %t217, ptr %l126
  br label %bb69
bb69:
  %t218 = load i1, ptr %l126, !tbaa !21
  br i1 %t218, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb72
bb71:
  %t219 = load i1, ptr %l3, !tbaa !21
  store i1 %t219, ptr %l127, !tbaa !21
  br label %bb72
bb72:
  %t221 = load ptr, ptr %l113, !tbaa !29
  %t222 = load i64, ptr %l114, !tbaa !24
  %t223 = load i64, ptr %l118, !tbaa !24
  %t224 = load i64, ptr %l122, !tbaa !24
  %t225 = load i1, ptr %l127, !tbaa !21
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2egive(ptr %v0, ptr %t221, i64 %t222, i64 %t223, i64 %t224, i1 %t225)
  br label %bb73
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t226 = load i64, ptr %l11, !tbaa !24
  %t229 = add i64 %t226, 1
  store i64 %t229, ptr %l11, !tbaa !24
  br label %bb60
bb76:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l59 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LostStores", ptr %t2, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = add i64 %t4, 1
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = getelementptr %"compiler/typed:LostStores", ptr %t9, i32 0, i32 3
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Arm", ptr %t11, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t28, ptr %l22, !tbaa !27
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr ptr, ptr %t32, i64 %t29
  %t34 = load ptr, ptr %t33, !tbaa !39
  store ptr %t34, ptr %l5, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/typed:Alt", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t36, ptr %t40)
  br label %bb5
bb5:
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Alt", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t61 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Bind", ptr %t67, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t69, ptr %t73)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = add i64 %t77, 1
  store i64 %t80, ptr %l7, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Arm", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  br label %bb15
bb15:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Arm", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eblock(ptr %v0, ptr %v1, ptr %t94, ptr %t98)
  br label %bb16
bb16:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Arm", ptr %t102, i32 0, i32 4
  %t105 = load ptr, ptr %t104, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t101, ptr %t105)
  br label %bb17
bb17:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l59, !tbaa !29
  %t109 = load ptr, ptr %l59, !tbaa !29
  %t110 = getelementptr %"compiler/typed:LostStores", ptr %t109, i32 0, i32 3
  %t111 = load i64, ptr %t110, !tbaa !24
  %t114 = sub i64 %t111, 1
  %t116 = load ptr, ptr %l59, !tbaa !29
  %t117 = getelementptr %"compiler/typed:LostStores", ptr %t116, i32 0, i32 3
  store i64 %t114, ptr %t117, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2ebranch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l8 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LostStores", ptr %t2, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = add i64 %t4, 1
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/typed:LostStores", ptr %t9, i32 0, i32 3
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eblock(ptr %v0, ptr %v1, ptr %t11, ptr %a1)
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"compiler/typed:LostStores", ptr %t16, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = sub i64 %t18, 1
  %t23 = load ptr, ptr %l8, !tbaa !29
  %t24 = getelementptr %"compiler/typed:LostStores", ptr %t23, i32 0, i32 3
  store i64 %t21, ptr %t24, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l153 = alloca ptr
  %l164 = alloca ptr
  %l168 = alloca ptr
  %l169 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l197 = alloca { i64, ptr }
  %l209 = alloca ptr
  %l215 = alloca ptr
  %l216 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l233 = alloca ptr
  %l237 = alloca ptr
  %l238 = alloca i1
  %l250 = alloca { i64, ptr }
  %l260 = alloca ptr
  %l261 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca i1
  %l273 = alloca ptr
  %l277 = alloca ptr
  %l278 = alloca i1
  %l291 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l295 = alloca i1
  %l306 = alloca ptr
  %l307 = alloca i1
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t6 = load ptr, ptr %l35, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l35, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l36, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l36, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t15 = load ptr, ptr %l39, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l39, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l40, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l40, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb191
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t24 = load ptr, ptr %l43, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l43, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l44, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb26
bb17:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t39 = load ptr, ptr %l49, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l49, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l50, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l50, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb26
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t54 = load ptr, ptr %l55, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l55, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l56, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l56, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eplace(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb27
bb27:
  br label %bb191
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t73 = load ptr, ptr %l63, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb29, label %bb30
bb29:
  %t76 = load ptr, ptr %l63, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 5
  store i1 %t79, ptr %l64, !tbaa !21
  br label %bb30
bb30:
  %t80 = load i1, ptr %l64, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  br label %bb34
bb34:
  br label %bb191
bb35:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t96 = load ptr, ptr %l73, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l73, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 18}
  %t102 = icmp eq i64 %t100, 6
  store i1 %t102, ptr %l74, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l74, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb54
bb40:
  %t110 = load ptr, ptr %l4, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Call", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l5, !tbaa !29
  %t115 = load ptr, ptr %l5, !tbaa !29
  store ptr %t115, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t116 = load ptr, ptr %l81, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb41, label %bb42
bb41:
  %t119 = load ptr, ptr %l81, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 5}
  %t122 = icmp eq i64 %t120, 2
  store i1 %t122, ptr %l82, !tbaa !21
  br label %bb42
bb42:
  %t123 = load i1, ptr %l82, !tbaa !21
  br i1 %t123, label %bb43, label %bb44
bb43:
  %t124 = load ptr, ptr %l5, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { ptr }, ptr %t126, i32 0, i32 0
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l6, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  br label %bb46
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_c8e89ecf105db19_6b4b68a887b2ef25)
  unreachable
bb52:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Call", ptr %t136, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexprs(ptr %v0, ptr %v1, ptr %t135, { i64, ptr } %t139)
  br label %bb53
bb53:
  br label %bb191
bb54:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t143 = load ptr, ptr %l93, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb55, label %bb56
bb55:
  %t146 = load ptr, ptr %l93, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 18}
  %t149 = icmp eq i64 %t147, 7
  store i1 %t149, ptr %l94, !tbaa !21
  br label %bb56
bb56:
  %t150 = load i1, ptr %l94, !tbaa !21
  br i1 %t150, label %bb57, label %bb58
bb57:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l7, !tbaa !29
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l7, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Make", ptr %t158, i32 0, i32 2
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexprs(ptr %v0, ptr %v1, ptr %t157, { i64, ptr } %t161)
  br label %bb60
bb60:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l7, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Make", ptr %t165, i32 0, i32 3
  %t168 = load ptr, ptr %t167, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t164, ptr %t168)
  br label %bb61
bb61:
  br label %bb191
bb62:
  %t171 = load ptr, ptr %l1, !tbaa !29
  store ptr %t171, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t172 = load ptr, ptr %l105, !tbaa !29
  %t173 = icmp ne ptr %t172, null
  br i1 %t173, label %bb63, label %bb64
bb63:
  %t175 = load ptr, ptr %l105, !tbaa !29
  %t176 = load i64, ptr %t175, !range !{i64 0, i64 18}
  %t178 = icmp eq i64 %t176, 8
  store i1 %t178, ptr %l106, !tbaa !21
  br label %bb64
bb64:
  %t179 = load i1, ptr %l106, !tbaa !21
  br i1 %t179, label %bb65, label %bb66
bb65:
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t182, i32 0, i32 2
  %t184 = load ptr, ptr %t183
  store ptr %t184, ptr %l8, !tbaa !29
  br label %bb67
bb66:
  br label %bb70
bb67:
  store %olang.scope zeroinitializer, ptr %s9
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Collect", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t186, ptr %t190)
  br label %bb68
bb68:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Collect", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eloop(ptr %v0, ptr %v1, ptr %s9, ptr %t193, ptr %t197, ptr null)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s9)
  br label %bb191
bb70:
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t202 = load ptr, ptr %l118, !tbaa !29
  %t203 = icmp ne ptr %t202, null
  br i1 %t203, label %bb71, label %bb72
bb71:
  %t205 = load ptr, ptr %l118, !tbaa !29
  %t206 = load i64, ptr %t205, !range !{i64 0, i64 18}
  %t208 = icmp eq i64 %t206, 9
  store i1 %t208, ptr %l119, !tbaa !21
  br label %bb72
bb72:
  %t209 = load i1, ptr %l119, !tbaa !21
  br i1 %t209, label %bb73, label %bb74
bb73:
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t212, i32 0, i32 4
  %t214 = load { i64, ptr }, ptr %t213
  store { i64, ptr } %t214, ptr %l9, !tbaa !27
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexprs(ptr %v0, ptr %v1, ptr %t216, { i64, ptr } %t217)
  br label %bb76
bb76:
  br label %bb191
bb77:
  %t220 = load ptr, ptr %l1, !tbaa !29
  store ptr %t220, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t221 = load ptr, ptr %l126, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb78, label %bb79
bb78:
  %t224 = load ptr, ptr %l126, !tbaa !29
  %t225 = load i64, ptr %t224, !range !{i64 0, i64 18}
  %t227 = icmp eq i64 %t225, 10
  store i1 %t227, ptr %l127, !tbaa !21
  br label %bb79
bb79:
  %t228 = load i1, ptr %l127, !tbaa !21
  br i1 %t228, label %bb80, label %bb81
bb80:
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t231, i32 0, i32 2
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l10, !tbaa !29
  br label %bb82
bb81:
  br label %bb86
bb82:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l10, !tbaa !29
  %t238 = getelementptr %"compiler/typed:Slice", ptr %t236, i32 0, i32 0
  %t239 = load ptr, ptr %t238, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eplace(ptr %v0, ptr %v1, ptr %t235, ptr %t239)
  br label %bb83
bb83:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l10, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Slice", ptr %t243, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t242, ptr %t246)
  br label %bb84
bb84:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l10, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Slice", ptr %t251, i32 0, i32 2
  %t254 = load ptr, ptr %t253, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t250, ptr %t254)
  br label %bb85
bb85:
  br label %bb191
bb86:
  %t258 = load ptr, ptr %l1, !tbaa !29
  store ptr %t258, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t259 = load ptr, ptr %l143, !tbaa !29
  %t260 = icmp ne ptr %t259, null
  br i1 %t260, label %bb87, label %bb88
bb87:
  %t262 = load ptr, ptr %l143, !tbaa !29
  %t263 = load i64, ptr %t262, !range !{i64 0, i64 18}
  %t265 = icmp eq i64 %t263, 11
  store i1 %t265, ptr %l144, !tbaa !21
  br label %bb88
bb88:
  %t266 = load i1, ptr %l144, !tbaa !21
  br i1 %t266, label %bb89, label %bb90
bb89:
  %t267 = load ptr, ptr %l1, !tbaa !29
  %t269 = getelementptr { i64, [5 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t269, i32 0, i32 2
  %t271 = load ptr, ptr %t270
  store ptr %t271, ptr %l11, !tbaa !29
  br label %bb91
bb90:
  br label %bb95
bb91:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l11, !tbaa !29
  %t276 = getelementptr %"compiler/typed:Cond", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t273, ptr %t277)
  br label %bb92
bb92:
  %t281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t281, ptr %l153, !tbaa !29
  %t282 = load ptr, ptr %l153, !tbaa !29
  %t283 = getelementptr %"compiler/typed:LostStores", ptr %t282, i32 0, i32 3
  %t284 = load i64, ptr %t283, !tbaa !24
  %t287 = add i64 %t284, 1
  %t289 = load ptr, ptr %l153, !tbaa !29
  %t290 = getelementptr %"compiler/typed:LostStores", ptr %t289, i32 0, i32 3
  store i64 %t287, ptr %t290, !tbaa !24
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load ptr, ptr %l11, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Cond", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t291, ptr %t295)
  br label %bb93
bb93:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l11, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Cond", ptr %t299, i32 0, i32 2
  %t302 = load ptr, ptr %t301, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t298, ptr %t302)
  br label %bb94
bb94:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l164, !tbaa !29
  %t307 = load ptr, ptr %l164, !tbaa !29
  %t308 = getelementptr %"compiler/typed:LostStores", ptr %t307, i32 0, i32 3
  %t309 = load i64, ptr %t308, !tbaa !24
  %t312 = sub i64 %t309, 1
  %t314 = load ptr, ptr %l164, !tbaa !29
  %t315 = getelementptr %"compiler/typed:LostStores", ptr %t314, i32 0, i32 3
  store i64 %t312, ptr %t315, !tbaa !24
  br label %bb191
bb95:
  %t316 = load ptr, ptr %l1, !tbaa !29
  store ptr %t316, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t317 = load ptr, ptr %l168, !tbaa !29
  %t318 = icmp ne ptr %t317, null
  br i1 %t318, label %bb96, label %bb97
bb96:
  %t320 = load ptr, ptr %l168, !tbaa !29
  %t321 = load i64, ptr %t320, !range !{i64 0, i64 18}
  %t323 = icmp eq i64 %t321, 12
  store i1 %t323, ptr %l169, !tbaa !21
  br label %bb97
bb97:
  %t324 = load i1, ptr %l169, !tbaa !21
  br i1 %t324, label %bb98, label %bb99
bb98:
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr { i64, [5 x i64] }, ptr %t325, i32 0, i32 1
  %t328 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t327, i32 0, i32 2
  %t329 = load ptr, ptr %t328
  store ptr %t329, ptr %l12, !tbaa !29
  br label %bb100
bb99:
  br label %bb103
bb100:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l12, !tbaa !29
  %t334 = getelementptr %"compiler/typed:Seq", ptr %t332, i32 0, i32 0
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eStmts(ptr %v0, ptr %v1, ptr %t331, { i64, ptr } %t335)
  br label %bb101
bb101:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load ptr, ptr %l12, !tbaa !29
  %t341 = getelementptr %"compiler/typed:Seq", ptr %t339, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t338, ptr %t342)
  br label %bb102
bb102:
  br label %bb191
bb103:
  %t345 = load ptr, ptr %l1, !tbaa !29
  store ptr %t345, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t346 = load ptr, ptr %l180, !tbaa !29
  %t347 = icmp ne ptr %t346, null
  br i1 %t347, label %bb104, label %bb105
bb104:
  %t349 = load ptr, ptr %l180, !tbaa !29
  %t350 = load i64, ptr %t349, !range !{i64 0, i64 18}
  %t352 = icmp eq i64 %t350, 13
  store i1 %t352, ptr %l181, !tbaa !21
  br label %bb105
bb105:
  %t353 = load i1, ptr %l181, !tbaa !21
  br i1 %t353, label %bb106, label %bb107
bb106:
  %t354 = load ptr, ptr %l1, !tbaa !29
  %t356 = getelementptr { i64, [5 x i64] }, ptr %t354, i32 0, i32 1
  %t357 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t356, i32 0, i32 2
  %t358 = load ptr, ptr %t357
  store ptr %t358, ptr %l13, !tbaa !29
  br label %bb108
bb107:
  br label %bb124
bb108:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load ptr, ptr %l13, !tbaa !29
  %t363 = getelementptr %"compiler/typed:Match", ptr %t361, i32 0, i32 0
  %t364 = load { i64, ptr }, ptr %t363, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eStmts(ptr %v0, ptr %v1, ptr %t360, { i64, ptr } %t364)
  br label %bb109
bb109:
  %t367 = load ptr, ptr %l13, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Match", ptr %t367, i32 0, i32 1
  %t370 = load { i64, ptr }, ptr %t369, !tbaa !27
  store { i64, ptr } %t370, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t372 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t372, 0
  store i64 %t374, ptr %l16, !tbaa !24
  br label %bb110
bb110:
  %t376 = load i64, ptr %l15, !tbaa !24
  %t377 = load i64, ptr %l16, !tbaa !24
  %t380 = icmp slt i64 %t376, %t377
  %t382 = xor i1 %t380, true
  br i1 %t382, label %bb111, label %bb112
bb111:
  br label %bb116
bb112:
  br label %bb113
bb113:
  %t384 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t384, ptr %l197, !tbaa !27
  %t385 = load i64, ptr %l15, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr ptr, ptr %t388, i64 %t385
  %t390 = load ptr, ptr %t389, !tbaa !39
  %t392 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2earm(ptr %v0, ptr %v1, ptr %t392, ptr %t390)
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t396 = load i64, ptr %l15, !tbaa !24
  %t399 = add i64 %t396, 1
  store i64 %t399, ptr %l15, !tbaa !24
  br label %bb110
bb116:
  %t401 = load ptr, ptr %l13, !tbaa !29
  %t403 = getelementptr %"compiler/typed:Match", ptr %t401, i32 0, i32 2
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = icmp eq ptr %t404, null
  %t408 = xor i1 %t406, true
  br i1 %t408, label %bb117, label %bb118
bb117:
  %t410 = load ptr, ptr %l0, !tbaa !29
  store ptr %t410, ptr %l209, !tbaa !29
  %t411 = load ptr, ptr %l13, !tbaa !29
  %t413 = getelementptr %"compiler/typed:Match", ptr %t411, i32 0, i32 2
  %t414 = load ptr, ptr %t413, !tbaa !29
  %t416 = icmp eq ptr %t414, null
  br i1 %t416, label %bb119, label %bb120
bb118:
  br label %bb123
bb119:
  call void @__olang_check_failed(ptr @olang_loc_97b4d4f91b5dfdc1_6f0d24ceace7504d)
  unreachable
bb120:
  br label %bb121
bb121:
  %t418 = load ptr, ptr %l13, !tbaa !29
  %t420 = getelementptr %"compiler/typed:Match", ptr %t418, i32 0, i32 2
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t422 = load ptr, ptr %l209, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2earm(ptr %v0, ptr %v1, ptr %t422, ptr %t421)
  br label %bb122
bb122:
  br label %bb123
bb123:
  br label %bb191
bb124:
  %t424 = load ptr, ptr %l1, !tbaa !29
  store ptr %t424, ptr %l215, !tbaa !29
  store i1 false, ptr %l216, !tbaa !21
  %t425 = load ptr, ptr %l215, !tbaa !29
  %t426 = icmp ne ptr %t425, null
  br i1 %t426, label %bb125, label %bb126
bb125:
  %t428 = load ptr, ptr %l215, !tbaa !29
  %t429 = load i64, ptr %t428, !range !{i64 0, i64 18}
  %t431 = icmp eq i64 %t429, 14
  store i1 %t431, ptr %l216, !tbaa !21
  br label %bb126
bb126:
  %t432 = load i1, ptr %l216, !tbaa !21
  br i1 %t432, label %bb127, label %bb128
bb127:
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t435 = getelementptr { i64, [5 x i64] }, ptr %t433, i32 0, i32 1
  %t436 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t435, i32 0, i32 2
  %t437 = load ptr, ptr %t436
  store ptr %t437, ptr %l18, !tbaa !29
  br label %bb129
bb128:
  br label %bb132
bb129:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load ptr, ptr %l18, !tbaa !29
  %t442 = getelementptr %"compiler/typed:Try", ptr %t440, i32 0, i32 0
  %t443 = load ptr, ptr %t442, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t439, ptr %t443)
  br label %bb130
bb130:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load ptr, ptr %l18, !tbaa !29
  %t449 = getelementptr %"compiler/typed:Try", ptr %t447, i32 0, i32 1
  %t450 = load { i64, ptr }, ptr %t449, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eclauses(ptr %v0, ptr %v1, ptr %t446, { i64, ptr } %t450)
  br label %bb131
bb131:
  br label %bb191
bb132:
  %t453 = load ptr, ptr %l1, !tbaa !29
  store ptr %t453, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t454 = load ptr, ptr %l227, !tbaa !29
  %t455 = icmp ne ptr %t454, null
  br i1 %t455, label %bb133, label %bb134
bb133:
  %t457 = load ptr, ptr %l227, !tbaa !29
  %t458 = load i64, ptr %t457, !range !{i64 0, i64 18}
  %t460 = icmp eq i64 %t458, 15
  store i1 %t460, ptr %l228, !tbaa !21
  br label %bb134
bb134:
  %t461 = load i1, ptr %l228, !tbaa !21
  br i1 %t461, label %bb135, label %bb136
bb135:
  %t462 = load ptr, ptr %l1, !tbaa !29
  %t464 = getelementptr { i64, [5 x i64] }, ptr %t462, i32 0, i32 1
  %t465 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t464, i32 0, i32 2
  %t466 = load ptr, ptr %t465
  store ptr %t466, ptr %l19, !tbaa !29
  br label %bb137
bb136:
  br label %bb165
bb137:
  %t468 = load ptr, ptr %l0, !tbaa !29
  store ptr %t468, ptr %l233, !tbaa !29
  %t469 = load ptr, ptr %l233, !tbaa !29
  %t470 = getelementptr %"compiler/typed:LostStores", ptr %t469, i32 0, i32 2
  %t471 = load i64, ptr %t470, !tbaa !24
  %t474 = add i64 %t471, 1
  %t476 = load ptr, ptr %l233, !tbaa !29
  %t477 = getelementptr %"compiler/typed:LostStores", ptr %t476, i32 0, i32 2
  store i64 %t474, ptr %t477, !tbaa !24
  %t478 = load ptr, ptr %l19, !tbaa !29
  store ptr %t478, ptr %l237, !tbaa !29
  store i1 false, ptr %l238, !tbaa !21
  %t479 = load ptr, ptr %l237, !tbaa !29
  %t480 = icmp ne ptr %t479, null
  br i1 %t480, label %bb138, label %bb139
bb138:
  %t482 = load ptr, ptr %l237, !tbaa !29
  %t483 = load i64, ptr %t482, !range !{i64 0, i64 3}
  %t485 = icmp eq i64 %t483, 1
  store i1 %t485, ptr %l238, !tbaa !21
  br label %bb139
bb139:
  %t486 = load i1, ptr %l238, !tbaa !21
  br i1 %t486, label %bb140, label %bb141
bb140:
  %t487 = load ptr, ptr %l19, !tbaa !29
  %t489 = getelementptr { i64, [4 x i64] }, ptr %t487, i32 0, i32 1
  %t490 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t489, i32 0, i32 1
  %t491 = load { i64, ptr }, ptr %t490
  store { i64, ptr } %t491, ptr %l20, !tbaa !27
  br label %bb142
bb141:
  br label %bb150
bb142:
  %t493 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t493, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t495 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t495, 0
  store i64 %t497, ptr %l23, !tbaa !24
  br label %bb143
bb143:
  %t499 = load i64, ptr %l22, !tbaa !24
  %t500 = load i64, ptr %l23, !tbaa !24
  %t503 = icmp slt i64 %t499, %t500
  %t505 = xor i1 %t503, true
  br i1 %t505, label %bb144, label %bb145
bb144:
  br label %bb149
bb145:
  br label %bb146
bb146:
  %t507 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t507, ptr %l250, !tbaa !27
  %t508 = load i64, ptr %l22, !tbaa !24
  %t510 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = getelementptr ptr, ptr %t511, i64 %t508
  %t513 = load ptr, ptr %t512, !tbaa !39
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/typed:Capture", ptr %t513, i32 0, i32 1
  %t519 = load ptr, ptr %t518, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t515, ptr %t519)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t523 = load i64, ptr %l22, !tbaa !24
  %t526 = add i64 %t523, 1
  store i64 %t526, ptr %l22, !tbaa !24
  br label %bb143
bb149:
  br label %bb164
bb150:
  %t528 = load ptr, ptr %l19, !tbaa !29
  store ptr %t528, ptr %l260, !tbaa !29
  store i1 false, ptr %l261, !tbaa !21
  %t529 = load ptr, ptr %l260, !tbaa !29
  %t530 = icmp ne ptr %t529, null
  br i1 %t530, label %bb151, label %bb152
bb151:
  %t532 = load ptr, ptr %l260, !tbaa !29
  %t533 = load i64, ptr %t532, !range !{i64 0, i64 3}
  %t535 = icmp eq i64 %t533, 2
  store i1 %t535, ptr %l261, !tbaa !21
  br label %bb152
bb152:
  %t536 = load i1, ptr %l261, !tbaa !21
  br i1 %t536, label %bb153, label %bb154
bb153:
  %t537 = load ptr, ptr %l19, !tbaa !29
  %t539 = getelementptr { i64, [4 x i64] }, ptr %t537, i32 0, i32 1
  %t540 = getelementptr { i32, ptr, i32 }, ptr %t539, i32 0, i32 1
  %t541 = load ptr, ptr %t540
  store ptr %t541, ptr %l25, !tbaa !29
  br label %bb155
bb154:
  br label %bb157
bb155:
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t543, ptr %t544)
  br label %bb156
bb156:
  br label %bb164
bb157:
  %t548 = load ptr, ptr %l19, !tbaa !29
  store ptr %t548, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t549 = load ptr, ptr %l269, !tbaa !29
  %t550 = icmp ne ptr %t549, null
  br i1 %t550, label %bb158, label %bb159
bb158:
  %t552 = load ptr, ptr %l269, !tbaa !29
  %t553 = load i64, ptr %t552, !range !{i64 0, i64 3}
  %t555 = icmp eq i64 %t553, 0
  store i1 %t555, ptr %l270, !tbaa !21
  br label %bb159
bb159:
  %t556 = load i1, ptr %l270, !tbaa !21
  br i1 %t556, label %bb160, label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb163
bb162:
  br label %bb164
bb163:
  call void @__olang_check_failed(ptr @olang_loc_2900faaa17bf3b23_aa9541689676b42f)
  unreachable
bb164:
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l273, !tbaa !29
  %t558 = load ptr, ptr %l273, !tbaa !29
  %t559 = getelementptr %"compiler/typed:LostStores", ptr %t558, i32 0, i32 2
  %t560 = load i64, ptr %t559, !tbaa !24
  %t563 = sub i64 %t560, 1
  %t565 = load ptr, ptr %l273, !tbaa !29
  %t566 = getelementptr %"compiler/typed:LostStores", ptr %t565, i32 0, i32 2
  store i64 %t563, ptr %t566, !tbaa !24
  br label %bb191
bb165:
  %t567 = load ptr, ptr %l1, !tbaa !29
  store ptr %t567, ptr %l277, !tbaa !29
  store i1 false, ptr %l278, !tbaa !21
  %t568 = load ptr, ptr %l277, !tbaa !29
  %t569 = icmp ne ptr %t568, null
  br i1 %t569, label %bb166, label %bb167
bb166:
  %t571 = load ptr, ptr %l277, !tbaa !29
  %t572 = load i64, ptr %t571, !range !{i64 0, i64 18}
  %t574 = icmp eq i64 %t572, 16
  store i1 %t574, ptr %l278, !tbaa !21
  br label %bb167
bb167:
  %t575 = load i1, ptr %l278, !tbaa !21
  br i1 %t575, label %bb168, label %bb169
bb168:
  %t576 = load ptr, ptr %l1, !tbaa !29
  %t578 = getelementptr { i64, [5 x i64] }, ptr %t576, i32 0, i32 1
  %t579 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t578, i32 0, i32 2
  %t580 = load ptr, ptr %t579
  store ptr %t580, ptr %l26, !tbaa !29
  br label %bb170
bb169:
  br label %bb183
bb170:
  %t582 = load ptr, ptr %l26, !tbaa !29
  %t584 = getelementptr %"compiler/typed:Text", ptr %t582, i32 0, i32 0
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  store { i64, ptr } %t585, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t587 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t589 = extractvalue { i64, ptr } %t587, 0
  store i64 %t589, ptr %l29, !tbaa !24
  br label %bb171
bb171:
  %t591 = load i64, ptr %l28, !tbaa !24
  %t592 = load i64, ptr %l29, !tbaa !24
  %t595 = icmp slt i64 %t591, %t592
  %t597 = xor i1 %t595, true
  br i1 %t597, label %bb172, label %bb173
bb172:
  br label %bb182
bb173:
  br label %bb174
bb174:
  %t599 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t599, ptr %l291, !tbaa !27
  %t600 = load i64, ptr %l28, !tbaa !24
  %t602 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !27
  %t604 = getelementptr ptr, ptr %t603, i64 %t600
  %t605 = load ptr, ptr %t604, !tbaa !39
  store ptr %t605, ptr %l30, !tbaa !29
  %t607 = load ptr, ptr %l30, !tbaa !29
  store ptr %t607, ptr %l294, !tbaa !29
  store i1 false, ptr %l295, !tbaa !21
  %t608 = load ptr, ptr %l294, !tbaa !29
  %t609 = icmp ne ptr %t608, null
  br i1 %t609, label %bb175, label %bb176
bb175:
  %t611 = load ptr, ptr %l294, !tbaa !29
  %t612 = load i64, ptr %t611, !range !{i64 0, i64 2}
  %t614 = icmp eq i64 %t612, 1
  store i1 %t614, ptr %l295, !tbaa !21
  br label %bb176
bb176:
  %t615 = load i1, ptr %l295, !tbaa !21
  br i1 %t615, label %bb177, label %bb178
bb177:
  %t616 = load ptr, ptr %l30, !tbaa !29
  %t618 = getelementptr { i64, [2 x i64] }, ptr %t616, i32 0, i32 1
  %t619 = getelementptr { ptr }, ptr %t618, i32 0, i32 0
  %t620 = load ptr, ptr %t619
  %t622 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t622, ptr %t620)
  br label %bb179
bb178:
  br label %bb180
bb179:
  br label %bb180
bb180:
  br label %bb181
bb181:
  %t627 = load i64, ptr %l28, !tbaa !24
  %t630 = add i64 %t627, 1
  store i64 %t630, ptr %l28, !tbaa !24
  br label %bb171
bb182:
  br label %bb191
bb183:
  %t632 = load ptr, ptr %l1, !tbaa !29
  store ptr %t632, ptr %l306, !tbaa !29
  store i1 false, ptr %l307, !tbaa !21
  %t633 = load ptr, ptr %l306, !tbaa !29
  %t634 = icmp ne ptr %t633, null
  br i1 %t634, label %bb184, label %bb185
bb184:
  %t636 = load ptr, ptr %l306, !tbaa !29
  %t637 = load i64, ptr %t636, !range !{i64 0, i64 18}
  %t639 = icmp eq i64 %t637, 17
  store i1 %t639, ptr %l307, !tbaa !21
  br label %bb185
bb185:
  %t640 = load i1, ptr %l307, !tbaa !21
  br i1 %t640, label %bb186, label %bb187
bb186:
  %t641 = load ptr, ptr %l1, !tbaa !29
  %t643 = getelementptr { i64, [5 x i64] }, ptr %t641, i32 0, i32 1
  %t644 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t643, i32 0, i32 2
  %t645 = load ptr, ptr %t644
  store ptr %t645, ptr %l32, !tbaa !29
  br label %bb188
bb187:
  br label %bb190
bb188:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t648 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t647, ptr %t648)
  br label %bb189
bb189:
  br label %bb191
bb190:
  call void @__olang_check_failed(ptr @olang_loc_7596ed2c7d631a22_34e31769c135136e)
  unreachable
bb191:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2elaterBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l8 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LostStores", ptr %t2, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = add i64 %t4, 1
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t10 = getelementptr %"compiler/typed:LostStores", ptr %t9, i32 0, i32 2
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eblock(ptr %v0, ptr %v1, ptr %t11, ptr %a1)
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l8, !tbaa !29
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t17 = getelementptr %"compiler/typed:LostStores", ptr %t16, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t21 = sub i64 %t18, 1
  %t23 = load ptr, ptr %l8, !tbaa !29
  %t24 = getelementptr %"compiler/typed:LostStores", ptr %t23, i32 0, i32 2
  store i64 %t21, ptr %t24, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eownStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l63 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:LostStores", ptr %t17, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t23 = icmp eq i32 %t16, %t20
  store i1 %t23, ptr %l7, !tbaa !21
  br label %bb45
bb6:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 8}
  %t32 = icmp eq i64 %t30, 2
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:LostStores", ptr %t40, i32 0, i32 4
  %t43 = load i1, ptr %t42, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/typed:LostStores", ptr %t45, i32 0, i32 2
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = icmp eq i64 %t48, 0
  store i1 %t50, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t52 = load i1, ptr %l26, !tbaa !21
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:LostStores", ptr %t54, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  %t60 = call i1 @compiler_2ftyped_2ereadsL(ptr %v1, ptr %t53, i32 %t57)
  store i1 %t60, ptr %l34
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t61 = load i1, ptr %l34, !tbaa !21
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l30, !tbaa !21
  store i1 %t62, ptr %l7, !tbaa !21
  br label %bb45
bb19:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t64 = load ptr, ptr %l35, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 3
  store i1 %t70, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t71 = load i1, ptr %l36, !tbaa !21
  br i1 %t71, label %bb22, label %bb23
bb22:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l4, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t82 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eownStore(ptr %v0, ptr %v1, ptr %t78, ptr %t79)
  store i1 %t82, ptr %l43
  br label %bb25
bb25:
  %t83 = load i1, ptr %l43, !tbaa !21
  store i1 %t83, ptr %l7, !tbaa !21
  br label %bb45
bb26:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t85 = load ptr, ptr %l44, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l44, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 8}
  %t91 = icmp eq i64 %t89, 4
  store i1 %t91, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t92 = load i1, ptr %l45, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Elem", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t106 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eownStore(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  store i1 %t106, ptr %l53
  br label %bb32
bb32:
  %t107 = load i1, ptr %l53, !tbaa !21
  store i1 %t107, ptr %l7, !tbaa !21
  br label %bb45
bb33:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t109 = load ptr, ptr %l54, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t112 = load ptr, ptr %l54, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 8}
  %t115 = icmp eq i64 %t113, 5
  store i1 %t115, ptr %l55, !tbaa !21
  br label %bb35
bb35:
  %t116 = load i1, ptr %l55, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Payload", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t130 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eownStore(ptr %v0, ptr %v1, ptr %t123, ptr %t127)
  store i1 %t130, ptr %l63
  br label %bb39
bb39:
  %t131 = load i1, ptr %l63, !tbaa !21
  store i1 %t131, ptr %l7, !tbaa !21
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_ffe0189e7b721f8f_5dca816419dc18f3)
  unreachable
bb45:
  %t132 = load i1, ptr %l7, !tbaa !21
  store i1 %t132, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l52 = alloca i1
  %l64 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i1
  %l82 = alloca ptr
  %l85 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca i1
  %l92 = alloca i1
  %l100 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l122 = alloca i1
  %l128 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i1
  %l174 = alloca ptr
  %l175 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i1
  %l203 = alloca ptr
  %l204 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca i1
  %l225 = alloca ptr
  %l226 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca i1
  %l240 = alloca ptr
  %l251 = alloca ptr
  %l255 = alloca ptr
  %l256 = alloca i1
  %l261 = alloca ptr
  %l273 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l305 = alloca ptr
  %l309 = alloca ptr
  %l310 = alloca i1
  %l313 = alloca ptr
  %l314 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t2 = load ptr, ptr %l31, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l31, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l32, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l32, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb166
bb7:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t22 = load ptr, ptr %l40, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l40, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 17}
  %t28 = icmp eq i64 %t26, 1
  store i1 %t28, ptr %l41, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l41, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t32, i32 0, i32 0
  %t34 = load %"compiler/source:Span", ptr %t33
  store %"compiler/source:Span" %t34, ptr %l3
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t38, i32 0, i32 1
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [3 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb55
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t52 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eownStore(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store i1 %t52, ptr %l52
  br label %bb13
bb13:
  %t53 = load i1, ptr %l52, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eplace(ptr %v0, ptr %v1, ptr %t56, ptr %t57)
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  br label %bb17
bb17:
  br label %ret
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2estoreParts(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  br label %bb19
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l64, !tbaa !29
  %t75 = load ptr, ptr %l64, !tbaa !29
  %t76 = getelementptr %"compiler/typed:LostStores", ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76, !tbaa !24
  %t80 = add i64 %t77, 1
  %t82 = load ptr, ptr %l64, !tbaa !29
  %t83 = getelementptr %"compiler/typed:LostStores", ptr %t82, i32 0, i32 1
  store i64 %t80, ptr %t83, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/typed:LostStores", ptr %t84, i32 0, i32 6
  %t87 = load %"compiler/source:Span", ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t86, %"compiler/source:Span" %t87)
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/typed:LostStores", ptr %t90, i32 0, i32 7
  store ptr %t92, ptr %l72, !tbaa !29
  %t93 = load ptr, ptr %l4, !tbaa !29
  store ptr %t93, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t94 = load ptr, ptr %l73, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb22, label %bb23
bb22:
  %t97 = load ptr, ptr %l73, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 8}
  %t100 = icmp eq i64 %t98, 0
  store i1 %t100, ptr %l74, !tbaa !21
  br label %bb23
bb23:
  %t101 = load i1, ptr %l74, !tbaa !21
  br i1 %t101, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb27
bb25:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t106 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2ethrough(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l80
  br label %bb26
bb26:
  %t107 = load i1, ptr %l80, !tbaa !21
  store i1 %t107, ptr %l77, !tbaa !21
  br label %bb27
bb27:
  %t108 = load ptr, ptr %l72, !tbaa !29
  %t109 = load i1, ptr %l77, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t108, i1 %t109)
  br label %bb28
bb28:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/typed:LostStores", ptr %t110, i32 0, i32 8
  store ptr %t112, ptr %l82, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l4, !tbaa !29
  %t117 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2ethrough(ptr %v0, ptr %v1, ptr %t113, ptr %t114)
  store i1 %t117, ptr %l85
  br label %bb29
bb29:
  %t118 = load ptr, ptr %l82, !tbaa !29
  %t119 = load i1, ptr %l85, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t118, i1 %t119)
  br label %bb30
bb30:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/typed:LostStores", ptr %t120, i32 0, i32 9
  store ptr %t122, ptr %l87, !tbaa !29
  %t123 = load ptr, ptr %l4, !tbaa !29
  store ptr %t123, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t124 = load ptr, ptr %l88, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb31, label %bb32
bb31:
  %t127 = load ptr, ptr %l88, !tbaa !29
  %t128 = load i64, ptr %t127, !range !{i64 0, i64 8}
  %t130 = icmp eq i64 %t128, 0
  store i1 %t130, ptr %l89, !tbaa !21
  br label %bb32
bb32:
  %t131 = load i1, ptr %l89, !tbaa !21
  br i1 %t131, label %bb33, label %bb34
bb33:
  %t132 = load ptr, ptr %l4, !tbaa !29
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t134, i32 0, i32 0
  %t136 = load %"compiler/source:Span", ptr %t135
  store %"compiler/source:Span" %t136, ptr %l6
  %t138 = load ptr, ptr %l4, !tbaa !29
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t140, i32 0, i32 1
  %t142 = load i32, ptr %t141
  store i32 %t142, ptr %l7, !tbaa !23
  %t144 = load ptr, ptr %l4, !tbaa !29
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t146, i32 0, i32 2
  %t148 = load i32, ptr %t147
  store i32 %t148, ptr %l8, !tbaa !23
  %t150 = load ptr, ptr %l5, !tbaa !29
  %t152 = call i1 @compiler_2ftyped_2efreshStorage(ptr %v1, ptr %t150)
  store i1 %t152, ptr %l100
  br label %bb35
bb34:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb36
bb35:
  %t153 = load i1, ptr %l100, !tbaa !21
  store i1 %t153, ptr %l92, !tbaa !21
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l87, !tbaa !29
  %t155 = load i1, ptr %l92, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t154, i1 %t155)
  br label %bb37
bb37:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/typed:LostStores", ptr %t156, i32 0, i32 10
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/typed:LostStores", ptr %t159, i32 0, i32 1
  %t162 = load i64, ptr %t161, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t158, i64 %t162)
  br label %bb38
bb38:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/typed:LostStores", ptr %t165, i32 0, i32 11
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/typed:LostStores", ptr %t168, i32 0, i32 2
  %t171 = load i64, ptr %t170, !tbaa !24
  %t173 = icmp sgt i64 %t171, 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t167, i1 %t173)
  br label %bb39
bb39:
  %t176 = load ptr, ptr %l4, !tbaa !29
  store ptr %t176, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t177 = load ptr, ptr %l110, !tbaa !29
  %t178 = icmp ne ptr %t177, null
  br i1 %t178, label %bb40, label %bb41
bb40:
  %t180 = load ptr, ptr %l110, !tbaa !29
  %t181 = load i64, ptr %t180, !range !{i64 0, i64 8}
  %t183 = icmp eq i64 %t181, 0
  store i1 %t183, ptr %l111, !tbaa !21
  br label %bb41
bb41:
  %t184 = load i1, ptr %l111, !tbaa !21
  %t185 = xor i1 %t184, true
  br i1 %t185, label %bb42, label %bb43
bb42:
  br label %ret
bb43:
  br label %bb44
bb44:
  %t187 = load ptr, ptr %l4, !tbaa !29
  %t189 = getelementptr { i64, [4 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t189, i32 0, i32 0
  %t191 = load %"compiler/source:Span", ptr %t190
  store %"compiler/source:Span" %t191, ptr %l9
  %t193 = load ptr, ptr %l4, !tbaa !29
  %t195 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t195, i32 0, i32 1
  %t197 = load i32, ptr %t196
  store i32 %t197, ptr %l10, !tbaa !23
  %t199 = load ptr, ptr %l4, !tbaa !29
  %t201 = getelementptr { i64, [4 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t201, i32 0, i32 2
  %t203 = load i32, ptr %t202
  store i32 %t203, ptr %l11, !tbaa !23
  %t205 = load ptr, ptr %l5, !tbaa !29
  %t207 = call i1 @compiler_2ftyped_2efreshStorage(ptr %v1, ptr %t205)
  store i1 %t207, ptr %l122
  br label %bb45
bb45:
  %t208 = load i1, ptr %l122, !tbaa !21
  %t209 = xor i1 %t208, true
  br i1 %t209, label %bb46, label %bb47
bb46:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/typed:LostStores", ptr %t211, i32 0, i32 4
  store i1 false, ptr %t213, !tbaa !21
  br label %bb54
bb47:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/typed:LostStores", ptr %t214, i32 0, i32 3
  %t217 = load i64, ptr %t216, !tbaa !24
  %t219 = icmp eq i64 %t217, 0
  br i1 %t219, label %bb48, label %bb49
bb48:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/typed:LostStores", ptr %t221, i32 0, i32 2
  %t224 = load i64, ptr %t223, !tbaa !24
  %t226 = icmp eq i64 %t224, 0
  store i1 %t226, ptr %l128, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb50
bb50:
  %t228 = load i1, ptr %l128, !tbaa !21
  br i1 %t228, label %bb51, label %bb52
bb51:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/typed:LostStores", ptr %t229, i32 0, i32 4
  store i1 true, ptr %t231, !tbaa !21
  br label %bb53
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  br label %bb166
bb55:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t233 = load ptr, ptr %l133, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb56, label %bb57
bb56:
  %t236 = load ptr, ptr %l133, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 17}
  %t239 = icmp eq i64 %t237, 2
  store i1 %t239, ptr %l134, !tbaa !21
  br label %bb57
bb57:
  %t240 = load i1, ptr %l134, !tbaa !21
  br i1 %t240, label %bb58, label %bb59
bb58:
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 1
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l12, !tbaa !29
  br label %bb68
bb59:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t248 = load ptr, ptr %l139, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb60, label %bb61
bb60:
  %t251 = load ptr, ptr %l139, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 15
  store i1 %t254, ptr %l140, !tbaa !21
  br label %bb61
bb61:
  %t255 = load i1, ptr %l140, !tbaa !21
  br i1 %t255, label %bb62, label %bb63
bb62:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l12, !tbaa !29
  br label %bb68
bb63:
  %t262 = load ptr, ptr %l1, !tbaa !29
  store ptr %t262, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t263 = load ptr, ptr %l145, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb64, label %bb65
bb64:
  %t266 = load ptr, ptr %l145, !tbaa !29
  %t267 = load i64, ptr %t266, !range !{i64 0, i64 17}
  %t269 = icmp eq i64 %t267, 8
  store i1 %t269, ptr %l146, !tbaa !21
  br label %bb65
bb65:
  %t270 = load i1, ptr %l146, !tbaa !21
  br i1 %t270, label %bb66, label %bb67
bb66:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr { i64, [3 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t273, i32 0, i32 1
  %t275 = load ptr, ptr %t274
  store ptr %t275, ptr %l12, !tbaa !29
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t277, ptr %t278)
  br label %bb69
bb69:
  br label %bb166
bb70:
  %t282 = load ptr, ptr %l1, !tbaa !29
  store ptr %t282, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t283 = load ptr, ptr %l154, !tbaa !29
  %t284 = icmp ne ptr %t283, null
  br i1 %t284, label %bb71, label %bb72
bb71:
  %t286 = load ptr, ptr %l154, !tbaa !29
  %t287 = load i64, ptr %t286, !range !{i64 0, i64 17}
  %t289 = icmp eq i64 %t287, 6
  store i1 %t289, ptr %l155, !tbaa !21
  br label %bb72
bb72:
  %t290 = load i1, ptr %l155, !tbaa !21
  br i1 %t290, label %bb73, label %bb74
bb73:
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [3 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", ptr }, ptr %t293, i32 0, i32 1
  %t295 = load ptr, ptr %t294
  store ptr %t295, ptr %l13, !tbaa !29
  br label %bb83
bb74:
  %t297 = load ptr, ptr %l1, !tbaa !29
  store ptr %t297, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t298 = load ptr, ptr %l160, !tbaa !29
  %t299 = icmp ne ptr %t298, null
  br i1 %t299, label %bb75, label %bb76
bb75:
  %t301 = load ptr, ptr %l160, !tbaa !29
  %t302 = load i64, ptr %t301, !range !{i64 0, i64 17}
  %t304 = icmp eq i64 %t302, 16
  store i1 %t304, ptr %l161, !tbaa !21
  br label %bb76
bb76:
  %t305 = load i1, ptr %l161, !tbaa !21
  br i1 %t305, label %bb77, label %bb78
bb77:
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t308 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 1
  %t309 = getelementptr { %"compiler/source:Span", ptr }, ptr %t308, i32 0, i32 1
  %t310 = load ptr, ptr %t309
  store ptr %t310, ptr %l13, !tbaa !29
  br label %bb83
bb78:
  %t312 = load ptr, ptr %l1, !tbaa !29
  store ptr %t312, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t313 = load ptr, ptr %l166, !tbaa !29
  %t314 = icmp ne ptr %t313, null
  br i1 %t314, label %bb79, label %bb80
bb79:
  %t316 = load ptr, ptr %l166, !tbaa !29
  %t317 = load i64, ptr %t316, !range !{i64 0, i64 17}
  %t319 = icmp eq i64 %t317, 9
  store i1 %t319, ptr %l167, !tbaa !21
  br label %bb80
bb80:
  %t320 = load i1, ptr %l167, !tbaa !21
  br i1 %t320, label %bb81, label %bb82
bb81:
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr { i64, [3 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t323, i32 0, i32 2
  %t325 = load ptr, ptr %t324
  store ptr %t325, ptr %l13, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t327, ptr %t328)
  br label %bb84
bb84:
  br label %bb166
bb85:
  %t331 = load ptr, ptr %l1, !tbaa !29
  store ptr %t331, ptr %l174, !tbaa !29
  store i1 false, ptr %l175, !tbaa !21
  %t332 = load ptr, ptr %l174, !tbaa !29
  %t333 = icmp ne ptr %t332, null
  br i1 %t333, label %bb86, label %bb87
bb86:
  %t335 = load ptr, ptr %l174, !tbaa !29
  %t336 = load i64, ptr %t335, !range !{i64 0, i64 17}
  %t338 = icmp eq i64 %t336, 3
  store i1 %t338, ptr %l175, !tbaa !21
  br label %bb87
bb87:
  %t339 = load i1, ptr %l175, !tbaa !21
  br i1 %t339, label %bb88, label %bb89
bb88:
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr { i64, [3 x i64] }, ptr %t340, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", ptr }, ptr %t342, i32 0, i32 1
  %t344 = load ptr, ptr %t343
  store ptr %t344, ptr %l14, !tbaa !29
  br label %bb90
bb89:
  br label %bb94
bb90:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l14, !tbaa !29
  %t349 = getelementptr %"compiler/typed:If", ptr %t347, i32 0, i32 0
  %t350 = load ptr, ptr %t349, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t346, ptr %t350)
  br label %bb91
bb91:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load ptr, ptr %l14, !tbaa !29
  %t357 = getelementptr %"compiler/typed:If", ptr %t355, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2ebranch(ptr %v0, ptr %v1, ptr %t354, ptr %t358)
  br label %bb92
bb92:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load ptr, ptr %l14, !tbaa !29
  %t365 = getelementptr %"compiler/typed:If", ptr %t363, i32 0, i32 2
  %t366 = load ptr, ptr %t365, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2ebranch(ptr %v0, ptr %v1, ptr %t362, ptr %t366)
  br label %bb93
bb93:
  br label %bb166
bb94:
  %t369 = load ptr, ptr %l1, !tbaa !29
  store ptr %t369, ptr %l191, !tbaa !29
  store i1 false, ptr %l192, !tbaa !21
  %t370 = load ptr, ptr %l191, !tbaa !29
  %t371 = icmp ne ptr %t370, null
  br i1 %t371, label %bb95, label %bb96
bb95:
  %t373 = load ptr, ptr %l191, !tbaa !29
  %t374 = load i64, ptr %t373, !range !{i64 0, i64 17}
  %t376 = icmp eq i64 %t374, 4
  store i1 %t376, ptr %l192, !tbaa !21
  br label %bb96
bb96:
  %t377 = load i1, ptr %l192, !tbaa !21
  br i1 %t377, label %bb97, label %bb98
bb97:
  %t378 = load ptr, ptr %l1, !tbaa !29
  %t380 = getelementptr { i64, [3 x i64] }, ptr %t378, i32 0, i32 1
  %t381 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t380, i32 0, i32 1
  %t382 = load ptr, ptr %t381
  store ptr %t382, ptr %l15, !tbaa !29
  %t384 = load ptr, ptr %l1, !tbaa !29
  %t386 = getelementptr { i64, [3 x i64] }, ptr %t384, i32 0, i32 1
  %t387 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t386, i32 0, i32 2
  %t388 = load ptr, ptr %t387
  store ptr %t388, ptr %l16, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load ptr, ptr %l15, !tbaa !29
  %t393 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %t390, ptr %t391, ptr %t393)
  br label %bb100
bb100:
  br label %bb166
bb101:
  %t397 = load ptr, ptr %l1, !tbaa !29
  store ptr %t397, ptr %l203, !tbaa !29
  store i1 false, ptr %l204, !tbaa !21
  %t398 = load ptr, ptr %l203, !tbaa !29
  %t399 = icmp ne ptr %t398, null
  br i1 %t399, label %bb102, label %bb103
bb102:
  %t401 = load ptr, ptr %l203, !tbaa !29
  %t402 = load i64, ptr %t401, !range !{i64 0, i64 17}
  %t404 = icmp eq i64 %t402, 10
  store i1 %t404, ptr %l204, !tbaa !21
  br label %bb103
bb103:
  %t405 = load i1, ptr %l204, !tbaa !21
  br i1 %t405, label %bb104, label %bb105
bb104:
  %t406 = load ptr, ptr %l1, !tbaa !29
  %t408 = getelementptr { i64, [3 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t408, i32 0, i32 1
  %t410 = load ptr, ptr %t409
  store ptr %t410, ptr %l17, !tbaa !29
  %t412 = load ptr, ptr %l1, !tbaa !29
  %t414 = getelementptr { i64, [3 x i64] }, ptr %t412, i32 0, i32 1
  %t415 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t414, i32 0, i32 2
  %t416 = load ptr, ptr %t415
  store ptr %t416, ptr %l18, !tbaa !29
  br label %bb106
bb105:
  br label %bb109
bb106:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t418, ptr %t419)
  br label %bb107
bb107:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t423, ptr %t424)
  br label %bb108
bb108:
  br label %bb166
bb109:
  %t427 = load ptr, ptr %l1, !tbaa !29
  store ptr %t427, ptr %l216, !tbaa !29
  store i1 false, ptr %l217, !tbaa !21
  %t428 = load ptr, ptr %l216, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb110, label %bb111
bb110:
  %t431 = load ptr, ptr %l216, !tbaa !29
  %t432 = load i64, ptr %t431, !range !{i64 0, i64 17}
  %t434 = icmp eq i64 %t432, 11
  store i1 %t434, ptr %l217, !tbaa !21
  br label %bb111
bb111:
  %t435 = load i1, ptr %l217, !tbaa !21
  br i1 %t435, label %bb112, label %bb113
bb112:
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr { i64, [3 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", ptr }, ptr %t438, i32 0, i32 1
  %t440 = load ptr, ptr %t439
  store ptr %t440, ptr %l19, !tbaa !29
  br label %bb114
bb113:
  br label %bb116
bb114:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eblock(ptr %v0, ptr %v1, ptr %t442, ptr %t443)
  br label %bb115
bb115:
  br label %bb166
bb116:
  %t447 = load ptr, ptr %l1, !tbaa !29
  store ptr %t447, ptr %l225, !tbaa !29
  store i1 false, ptr %l226, !tbaa !21
  %t448 = load ptr, ptr %l225, !tbaa !29
  %t449 = icmp ne ptr %t448, null
  br i1 %t449, label %bb117, label %bb118
bb117:
  %t451 = load ptr, ptr %l225, !tbaa !29
  %t452 = load i64, ptr %t451, !range !{i64 0, i64 17}
  %t454 = icmp eq i64 %t452, 12
  store i1 %t454, ptr %l226, !tbaa !21
  br label %bb118
bb118:
  %t455 = load i1, ptr %l226, !tbaa !21
  br i1 %t455, label %bb119, label %bb120
bb119:
  %t456 = load ptr, ptr %l1, !tbaa !29
  %t458 = getelementptr { i64, [3 x i64] }, ptr %t456, i32 0, i32 1
  %t459 = getelementptr { %"compiler/source:Span", ptr }, ptr %t458, i32 0, i32 1
  %t460 = load ptr, ptr %t459
  store ptr %t460, ptr %l20, !tbaa !29
  br label %bb121
bb120:
  br label %bb123
bb121:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2elaterBlock(ptr %v0, ptr %v1, ptr %t462, ptr %t463)
  br label %bb122
bb122:
  br label %bb166
bb123:
  %t467 = load ptr, ptr %l1, !tbaa !29
  store ptr %t467, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t468 = load ptr, ptr %l234, !tbaa !29
  %t469 = icmp ne ptr %t468, null
  br i1 %t469, label %bb124, label %bb125
bb124:
  %t471 = load ptr, ptr %l234, !tbaa !29
  %t472 = load i64, ptr %t471, !range !{i64 0, i64 17}
  %t474 = icmp eq i64 %t472, 13
  store i1 %t474, ptr %l235, !tbaa !21
  br label %bb125
bb125:
  %t475 = load i1, ptr %l235, !tbaa !21
  br i1 %t475, label %bb126, label %bb127
bb126:
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr { i64, [3 x i64] }, ptr %t476, i32 0, i32 1
  %t479 = getelementptr { %"compiler/source:Span", ptr }, ptr %t478, i32 0, i32 1
  %t480 = load ptr, ptr %t479
  store ptr %t480, ptr %l21, !tbaa !29
  br label %bb128
bb127:
  br label %bb131
bb128:
  %t482 = load ptr, ptr %l0, !tbaa !29
  store ptr %t482, ptr %l240, !tbaa !29
  %t483 = load ptr, ptr %l240, !tbaa !29
  %t484 = getelementptr %"compiler/typed:LostStores", ptr %t483, i32 0, i32 2
  %t485 = load i64, ptr %t484, !tbaa !24
  %t488 = add i64 %t485, 1
  %t490 = load ptr, ptr %l240, !tbaa !29
  %t491 = getelementptr %"compiler/typed:LostStores", ptr %t490, i32 0, i32 2
  store i64 %t488, ptr %t491, !tbaa !24
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load ptr, ptr %l21, !tbaa !29
  %t495 = getelementptr %"compiler/typed:Join", ptr %t493, i32 0, i32 0
  %t496 = load ptr, ptr %t495, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eblock(ptr %v0, ptr %v1, ptr %t492, ptr %t496)
  br label %bb129
bb129:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load ptr, ptr %l21, !tbaa !29
  %t503 = getelementptr %"compiler/typed:Join", ptr %t501, i32 0, i32 2
  %t504 = load { i64, ptr }, ptr %t503, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eclauses(ptr %v0, ptr %v1, ptr %t500, { i64, ptr } %t504)
  br label %bb130
bb130:
  %t507 = load ptr, ptr %l0, !tbaa !29
  store ptr %t507, ptr %l251, !tbaa !29
  %t508 = load ptr, ptr %l251, !tbaa !29
  %t509 = getelementptr %"compiler/typed:LostStores", ptr %t508, i32 0, i32 2
  %t510 = load i64, ptr %t509, !tbaa !24
  %t513 = sub i64 %t510, 1
  %t515 = load ptr, ptr %l251, !tbaa !29
  %t516 = getelementptr %"compiler/typed:LostStores", ptr %t515, i32 0, i32 2
  store i64 %t513, ptr %t516, !tbaa !24
  br label %bb166
bb131:
  %t517 = load ptr, ptr %l1, !tbaa !29
  store ptr %t517, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t518 = load ptr, ptr %l255, !tbaa !29
  %t519 = icmp ne ptr %t518, null
  br i1 %t519, label %bb132, label %bb133
bb132:
  %t521 = load ptr, ptr %l255, !tbaa !29
  %t522 = load i64, ptr %t521, !range !{i64 0, i64 17}
  %t524 = icmp eq i64 %t522, 14
  store i1 %t524, ptr %l256, !tbaa !21
  br label %bb133
bb133:
  %t525 = load i1, ptr %l256, !tbaa !21
  br i1 %t525, label %bb134, label %bb135
bb134:
  %t526 = load ptr, ptr %l1, !tbaa !29
  %t528 = getelementptr { i64, [3 x i64] }, ptr %t526, i32 0, i32 1
  %t529 = getelementptr { %"compiler/source:Span", ptr }, ptr %t528, i32 0, i32 1
  %t530 = load ptr, ptr %t529
  store ptr %t530, ptr %l22, !tbaa !29
  br label %bb136
bb135:
  br label %bb155
bb136:
  %t532 = load ptr, ptr %l0, !tbaa !29
  store ptr %t532, ptr %l261, !tbaa !29
  %t533 = load ptr, ptr %l261, !tbaa !29
  %t534 = getelementptr %"compiler/typed:LostStores", ptr %t533, i32 0, i32 2
  %t535 = load i64, ptr %t534, !tbaa !24
  %t538 = add i64 %t535, 1
  %t540 = load ptr, ptr %l261, !tbaa !29
  %t541 = getelementptr %"compiler/typed:LostStores", ptr %t540, i32 0, i32 2
  store i64 %t538, ptr %t541, !tbaa !24
  %t542 = load ptr, ptr %l22, !tbaa !29
  %t544 = getelementptr %"compiler/typed:Spawn", ptr %t542, i32 0, i32 0
  %t545 = load { i64, ptr }, ptr %t544, !tbaa !27
  store { i64, ptr } %t545, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t547 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t547, 0
  store i64 %t549, ptr %l25, !tbaa !24
  br label %bb137
bb137:
  %t551 = load i64, ptr %l24, !tbaa !24
  %t552 = load i64, ptr %l25, !tbaa !24
  %t555 = icmp slt i64 %t551, %t552
  %t557 = xor i1 %t555, true
  br i1 %t557, label %bb138, label %bb139
bb138:
  br label %bb146
bb139:
  br label %bb140
bb140:
  %t559 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t559, ptr %l273, !tbaa !27
  %t560 = load i64, ptr %l24, !tbaa !24
  %t562 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t563 = load ptr, ptr %t562, !tbaa !27
  %t564 = getelementptr ptr, ptr %t563, i64 %t560
  %t565 = load ptr, ptr %t564, !tbaa !39
  store ptr %t565, ptr %l26, !tbaa !29
  %t567 = load ptr, ptr %l26, !tbaa !29
  %t569 = icmp eq ptr %t567, null
  %t571 = xor i1 %t569, true
  br i1 %t571, label %bb141, label %bb142
bb141:
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t574 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eplace(ptr %v0, ptr %v1, ptr %t573, ptr %t574)
  br label %bb143
bb142:
  br label %bb144
bb143:
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t577 = load i64, ptr %l24, !tbaa !24
  %t580 = add i64 %t577, 1
  store i64 %t580, ptr %l24, !tbaa !24
  br label %bb137
bb146:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t583 = load ptr, ptr %l22, !tbaa !29
  %t585 = getelementptr %"compiler/typed:Spawn", ptr %t583, i32 0, i32 1
  %t586 = load ptr, ptr %t585, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t582, ptr %t586)
  br label %bb147
bb147:
  %t590 = load ptr, ptr %l22, !tbaa !29
  %t592 = getelementptr %"compiler/typed:Spawn", ptr %t590, i32 0, i32 2
  %t593 = load { i64, ptr }, ptr %t592, !tbaa !27
  store { i64, ptr } %t593, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t595 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t597 = extractvalue { i64, ptr } %t595, 0
  store i64 %t597, ptr %l29, !tbaa !24
  br label %bb148
bb148:
  %t599 = load i64, ptr %l28, !tbaa !24
  %t600 = load i64, ptr %l29, !tbaa !24
  %t603 = icmp slt i64 %t599, %t600
  %t605 = xor i1 %t603, true
  br i1 %t605, label %bb149, label %bb150
bb149:
  br label %bb154
bb150:
  br label %bb151
bb151:
  %t607 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t607, ptr %l296, !tbaa !27
  %t608 = load i64, ptr %l28, !tbaa !24
  %t610 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !27
  %t612 = getelementptr ptr, ptr %t611, i64 %t608
  %t613 = load ptr, ptr %t612, !tbaa !39
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t618 = getelementptr %"compiler/typed:TaskClause", ptr %t613, i32 0, i32 3
  %t619 = load ptr, ptr %t618, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t615, ptr %t619)
  br label %bb152
bb152:
  br label %bb153
bb153:
  %t622 = load i64, ptr %l28, !tbaa !24
  %t625 = add i64 %t622, 1
  store i64 %t625, ptr %l28, !tbaa !24
  br label %bb148
bb154:
  %t627 = load ptr, ptr %l0, !tbaa !29
  store ptr %t627, ptr %l305, !tbaa !29
  %t628 = load ptr, ptr %l305, !tbaa !29
  %t629 = getelementptr %"compiler/typed:LostStores", ptr %t628, i32 0, i32 2
  %t630 = load i64, ptr %t629, !tbaa !24
  %t633 = sub i64 %t630, 1
  %t635 = load ptr, ptr %l305, !tbaa !29
  %t636 = getelementptr %"compiler/typed:LostStores", ptr %t635, i32 0, i32 2
  store i64 %t633, ptr %t636, !tbaa !24
  br label %bb166
bb155:
  %t637 = load ptr, ptr %l1, !tbaa !29
  store ptr %t637, ptr %l309, !tbaa !29
  store i1 false, ptr %l310, !tbaa !21
  %t638 = load ptr, ptr %l309, !tbaa !29
  %t639 = icmp ne ptr %t638, null
  br i1 %t639, label %bb156, label %bb157
bb156:
  %t641 = load ptr, ptr %l309, !tbaa !29
  %t642 = load i64, ptr %t641, !range !{i64 0, i64 17}
  %t644 = icmp eq i64 %t642, 5
  store i1 %t644, ptr %l310, !tbaa !21
  br label %bb157
bb157:
  %t645 = load i1, ptr %l310, !tbaa !21
  br i1 %t645, label %bb158, label %bb159
bb158:
  br label %bb164
bb159:
  %t646 = load ptr, ptr %l1, !tbaa !29
  store ptr %t646, ptr %l313, !tbaa !29
  store i1 false, ptr %l314, !tbaa !21
  %t647 = load ptr, ptr %l313, !tbaa !29
  %t648 = icmp ne ptr %t647, null
  br i1 %t648, label %bb160, label %bb161
bb160:
  %t650 = load ptr, ptr %l313, !tbaa !29
  %t651 = load i64, ptr %t650, !range !{i64 0, i64 17}
  %t653 = icmp eq i64 %t651, 7
  store i1 %t653, ptr %l314, !tbaa !21
  br label %bb161
bb161:
  %t654 = load i1, ptr %l314, !tbaa !21
  br i1 %t654, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_237180dabec9849e_b4dbc260c308006a)
  unreachable
bb166:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2estoreParts(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2estoreParts(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb27
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 4
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Elem", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2estoreParts(ptr %v0, ptr %v1, ptr %t35, ptr %t39)
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Elem", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexpr(ptr %v0, ptr %v1, ptr %t42, ptr %t46)
  br label %bb14
bb14:
  br label %bb27
bb15:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 5
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l27, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Payload", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2estoreParts(ptr %v0, ptr %v1, ptr %t65, ptr %t69)
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_45ead01c569de36f_c5d1cb857cc40283)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2ethrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb32
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t29 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2ethrough(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i1 %t29, ptr %l18
  br label %bb12
bb12:
  %t30 = load i1, ptr %l18, !tbaa !21
  store i1 %t30, ptr %l5, !tbaa !21
  br label %bb32
bb13:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb14, label %bb15
bb14:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 4
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb16, label %bb17
bb16:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Elem", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t53 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2ethrough(ptr %v0, ptr %v1, ptr %t46, ptr %t50)
  store i1 %t53, ptr %l28
  br label %bb19
bb19:
  %t54 = load i1, ptr %l28, !tbaa !21
  store i1 %t54, ptr %l5, !tbaa !21
  br label %bb32
bb20:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 8}
  %t62 = icmp eq i64 %t60, 5
  store i1 %t62, ptr %l30, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l30, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Payload", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t77 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2ethrough(ptr %v0, ptr %v1, ptr %t70, ptr %t74)
  store i1 %t77, ptr %l38
  br label %bb26
bb26:
  %t78 = load i1, ptr %l38, !tbaa !21
  store i1 %t78, ptr %l5, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_6ff0b07d48f8f2b7_c646bc78fcfe1ce3)
  unreachable
bb32:
  %t79 = load i1, ptr %l5, !tbaa !21
  store i1 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eReadExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2c, ptr %a2e) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"compiler/typed:wordReader"
  %l4 = alloca ptr
  %l7 = alloca %"compiler/typed:wordReader"
  %l8 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store { i64, ptr } %a1, ptr %l1
  %pf2 = insertvalue { ptr, ptr } undef, ptr %a2c, 0
  %pg2 = insertvalue { ptr, ptr } %pf2, ptr %a2e, 1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { ptr, ptr } %pg2, 0
  %t6 = extractvalue { ptr, ptr } %pg2, 1
  %t7 = call %"compiler/typed:wordReader" @compiler_2ftyped_3awordReader_2ector(ptr %v1, ptr %v2, ptr %s0, { i64, ptr } %t1, ptr %t5, ptr %t6)
  store %"compiler/typed:wordReader" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/typed:wordReader", ptr %l7
  store %"compiler/typed:wordReader" %t8, ptr %l3
  %t12 = call { i32, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ereadExpr(ptr %v0, ptr %s0, ptr %v3, ptr %a0, ptr %l3)
  %t13 = extractvalue { i32, ptr } %t12, 1
  %t14 = extractvalue { i32, ptr } %t12, 0
  store i32 %t14, ptr %l12
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16, !prof !99
ok.16:
  store ptr %t13, ptr %l11
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l11, !tbaa !29
  store ptr %t17, ptr %l8, !tbaa !29
  br label %bb4
bb3:
  %t18 = load i32, ptr %l12, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  call void @__olang_scope_close(ptr %s0)
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb4:
  %t29 = load ptr, ptr %l8, !tbaa !29
  store ptr %t29, ptr %l4, !tbaa !29
  %t30 = getelementptr %"compiler/typed:wordReader", ptr %l3, i32 0, i32 2
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t37 = icmp ne i64 %t31, %t34
  br i1 %t37, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  %t43 = insertvalue { i32, ptr } zeroinitializer, ptr %t41, 1
  store { i32, ptr } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ereadExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i8
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l26 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i64
  %l43 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca i32
  %l52 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i32
  %l63 = alloca i32
  %l65 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca i32
  %l72 = alloca i32
  %rv = alloca { i32, ptr }
  %t218 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:wordReader", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:wordReader", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp sge i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t16 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t16, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/typed:wordReader", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l16, !tbaa !27
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:wordReader", ptr %t21, i32 0, i32 2
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 %t24
  %t29 = load i8, ptr %t28, !tbaa !32
  store i8 %t29, ptr %l2, !tbaa !22
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = getelementptr %"compiler/typed:wordReader", ptr %t32, i32 0, i32 2
  %t34 = load i64, ptr %t33, !tbaa !24
  %t37 = add i64 %t34, 1
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t40 = getelementptr %"compiler/typed:wordReader", ptr %t39, i32 0, i32 2
  store i64 %t37, ptr %t40, !tbaa !24
  %t41 = load i8, ptr %l2, !tbaa !22
  %t43 = icmp eq i8 %t41, 78
  br i1 %t43, label %bb4, label %bb5
bb4:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = call { i32, i64 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2eint(ptr %v1, ptr %t45)
  %t48 = extractvalue { i32, i64 } %t47, 1
  %t49 = extractvalue { i32, i64 } %t47, 0
  store i32 %t49, ptr %l29
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb7, label %ok.51, !prof !99
ok.51:
  store i64 %t48, ptr %l28
  br label %bb6
bb5:
  br label %bb17
bb6:
  %t52 = load i64, ptr %l28, !tbaa !24
  store i64 %t52, ptr %l26, !tbaa !24
  br label %bb8
bb7:
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = lshr i32 %t53, 16
  %t55 = and i32 %t53, 65535
  %t56 = icmp eq i32 %t54, 1
  %t57 = select i1 %t56, i32 1, i32 0
  %t58 = icmp eq i32 %t53, 0
  %t59 = shl i32 %t57, 16
  %t60 = or i32 %t59, %t55
  %t61 = select i1 %t58, i32 0, i32 %t60
  %t63 = insertvalue { i32, ptr } zeroinitializer, i32 %t61, 0
  store { i32, ptr } %t63, ptr %rv
  br label %ret
bb8:
  %t64 = load i64, ptr %l26, !tbaa !24
  store i64 %t64, ptr %l3, !tbaa !24
  %t65 = load i64, ptr %l3, !tbaa !24
  %t67 = icmp slt i64 %t65, 0
  br i1 %t67, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb12
bb10:
  %t69 = load i64, ptr %l3, !tbaa !24
  store i64 %t69, ptr %l34, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Nodes", ptr %t70, i32 0, i32 0
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t72)
  store i64 %t74, ptr %l37
  br label %bb11
bb11:
  %t75 = load i64, ptr %l34, !tbaa !24
  %t76 = load i64, ptr %l37, !tbaa !24
  %t77 = icmp sge i64 %t75, %t76
  store i1 %t77, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t79 = load i1, ptr %l33, !tbaa !21
  br i1 %t79, label %bb13, label %bb14
bb13:
  %t81 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t81, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Nodes", ptr %t82, i32 0, i32 0
  %t85 = load i64, ptr %l3, !tbaa !24
  %t88 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t84, i64 %t85)
  store ptr %t88, ptr %l43
  br label %bb16
bb16:
  %t89 = load ptr, ptr %l43, !tbaa !29
  %t90 = insertvalue { i32, ptr } zeroinitializer, ptr %t89, 1
  store { i32, ptr } %t90, ptr %rv
  br label %ret
bb17:
  %t91 = load i8, ptr %l2, !tbaa !22
  %t93 = icmp ne i8 %t91, 82
  br i1 %t93, label %bb18, label %bb19
bb18:
  %t96 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t96, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = call { i32, %"compiler/source:Span" } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2espan(ptr %v1, ptr %t97)
  %t100 = extractvalue { i32, %"compiler/source:Span" } %t99, 1
  %t101 = extractvalue { i32, %"compiler/source:Span" } %t99, 0
  store i32 %t101, ptr %l50
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb22, label %ok.103, !prof !99
ok.103:
  store %"compiler/source:Span" %t100, ptr %l49
  br label %bb21
bb21:
  %t104 = load %"compiler/source:Span", ptr %l49
  store %"compiler/source:Span" %t104, ptr %l47
  br label %bb23
bb22:
  %t105 = load i32, ptr %l50, !tbaa !23
  %t106 = lshr i32 %t105, 16
  %t107 = and i32 %t105, 65535
  %t108 = icmp eq i32 %t106, 1
  %t109 = select i1 %t108, i32 1, i32 0
  %t110 = icmp eq i32 %t105, 0
  %t111 = shl i32 %t109, 16
  %t112 = or i32 %t111, %t107
  %t113 = select i1 %t110, i32 0, i32 %t112
  %t115 = insertvalue { i32, ptr } zeroinitializer, i32 %t113, 0
  store { i32, ptr } %t115, ptr %rv
  br label %ret
bb23:
  %t116 = load %"compiler/source:Span", ptr %l47
  store %"compiler/source:Span" %t116, ptr %l4
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = call { i32, i32 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2ety(ptr %v1, ptr %t117)
  %t120 = extractvalue { i32, i32 } %t119, 1
  %t121 = extractvalue { i32, i32 } %t119, 0
  store i32 %t121, ptr %l55
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb25, label %ok.123, !prof !99
ok.123:
  store i32 %t120, ptr %l54
  br label %bb24
bb24:
  %t124 = load i32, ptr %l54, !tbaa !23
  store i32 %t124, ptr %l52, !tbaa !23
  br label %bb26
bb25:
  %t125 = load i32, ptr %l55, !tbaa !23
  %t126 = lshr i32 %t125, 16
  %t127 = and i32 %t125, 65535
  %t128 = icmp eq i32 %t126, 1
  %t129 = select i1 %t128, i32 1, i32 0
  %t130 = icmp eq i32 %t125, 0
  %t131 = shl i32 %t129, 16
  %t132 = or i32 %t131, %t127
  %t133 = select i1 %t130, i32 0, i32 %t132
  %t135 = insertvalue { i32, ptr } zeroinitializer, i32 %t133, 0
  store { i32, ptr } %t135, ptr %rv
  br label %ret
bb26:
  %t136 = load i32, ptr %l52, !tbaa !23
  store i32 %t136, ptr %l5, !tbaa !23
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = call { i32, i64 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2eint(ptr %v1, ptr %t137)
  %t140 = extractvalue { i32, i64 } %t139, 1
  %t141 = extractvalue { i32, i64 } %t139, 0
  store i32 %t141, ptr %l60
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb28, label %ok.143, !prof !99
ok.143:
  store i64 %t140, ptr %l59
  br label %bb27
bb27:
  %t144 = load i64, ptr %l59, !tbaa !24
  store i64 %t144, ptr %l57, !tbaa !24
  br label %bb29
bb28:
  %t145 = load i32, ptr %l60, !tbaa !23
  %t146 = lshr i32 %t145, 16
  %t147 = and i32 %t145, 65535
  %t148 = icmp eq i32 %t146, 1
  %t149 = select i1 %t148, i32 1, i32 0
  %t150 = icmp eq i32 %t145, 0
  %t151 = shl i32 %t149, 16
  %t152 = or i32 %t151, %t147
  %t153 = select i1 %t150, i32 0, i32 %t152
  %t155 = insertvalue { i32, ptr } zeroinitializer, i32 %t153, 0
  store { i32, ptr } %t155, ptr %rv
  br label %ret
bb29:
  %t156 = load i64, ptr %l57, !tbaa !24
  store i64 %t156, ptr %l6, !tbaa !24
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2echar(ptr %v1, ptr %t157, i8 40)
  store i32 %t159, ptr %l63
  %t160 = icmp ne i32 %t159, 0
  br i1 %t160, label %bb31, label %ok.161, !prof !99
ok.161:
  br label %bb30
bb30:
  br label %bb32
bb31:
  %t162 = load i32, ptr %l63, !tbaa !23
  %t163 = lshr i32 %t162, 16
  %t164 = and i32 %t162, 65535
  %t165 = icmp eq i32 %t163, 1
  %t166 = select i1 %t165, i32 1, i32 0
  %t167 = icmp eq i32 %t162, 0
  %t168 = shl i32 %t166, 16
  %t169 = or i32 %t168, %t164
  %t170 = select i1 %t167, i32 0, i32 %t169
  %t172 = insertvalue { i32, ptr } zeroinitializer, i32 %t170, 0
  store { i32, ptr } %t172, ptr %rv
  br label %ret
bb32:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t177 = call { i32, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t173, ptr %t174)
  %t178 = extractvalue { i32, ptr } %t177, 1
  %t179 = extractvalue { i32, ptr } %t177, 0
  store i32 %t179, ptr %l69
  %t180 = icmp ne i32 %t179, 0
  br i1 %t180, label %bb34, label %ok.181, !prof !99
ok.181:
  store ptr %t178, ptr %l68
  br label %bb33
bb33:
  %t182 = load ptr, ptr %l68, !tbaa !29
  store ptr %t182, ptr %l65, !tbaa !29
  br label %bb35
bb34:
  %t183 = load i32, ptr %l69, !tbaa !23
  %t184 = lshr i32 %t183, 16
  %t185 = and i32 %t183, 65535
  %t186 = icmp eq i32 %t184, 1
  %t187 = select i1 %t186, i32 1, i32 0
  %t188 = icmp eq i32 %t183, 0
  %t189 = shl i32 %t187, 16
  %t190 = or i32 %t189, %t185
  %t191 = select i1 %t188, i32 0, i32 %t190
  %t193 = insertvalue { i32, ptr } zeroinitializer, i32 %t191, 0
  store { i32, ptr } %t193, ptr %rv
  br label %ret
bb35:
  %t194 = load ptr, ptr %l65, !tbaa !29
  store ptr %t194, ptr %l7, !tbaa !29
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2echar(ptr %v1, ptr %t195, i8 41)
  store i32 %t197, ptr %l72
  %t198 = icmp ne i32 %t197, 0
  br i1 %t198, label %bb37, label %ok.199, !prof !99
ok.199:
  br label %bb36
bb36:
  br label %bb38
bb37:
  %t200 = load i32, ptr %l72, !tbaa !23
  %t201 = lshr i32 %t200, 16
  %t202 = and i32 %t200, 65535
  %t203 = icmp eq i32 %t201, 1
  %t204 = select i1 %t203, i32 1, i32 0
  %t205 = icmp eq i32 %t200, 0
  %t206 = shl i32 %t204, 16
  %t207 = or i32 %t206, %t202
  %t208 = select i1 %t205, i32 0, i32 %t207
  %t210 = insertvalue { i32, ptr } zeroinitializer, i32 %t208, 0
  store { i32, ptr } %t210, ptr %rv
  br label %ret
bb38:
  %t211 = load %"compiler/source:Span", ptr %l4
  %t212 = load i32, ptr %l5, !tbaa !23
  %t213 = load ptr, ptr %l7, !tbaa !29
  %t214 = load i64, ptr %l6, !tbaa !24
  %t216 = trunc i64 %t214 to i32
  store { i64, [5 x i64] } zeroinitializer, ptr %t218
  %t219 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 0
  store i64 2, ptr %t219
  %t221 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t211, 0
  %t223 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t221, i32 %t212, 1
  %t225 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t223, ptr %t213, 2
  %t227 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t225, i32 %t216, 3
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t227, ptr %t228
  %t229 = load { i64, [5 x i64] }, ptr %t218
  %t231 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t229, ptr %t231
  %t233 = insertvalue { i32, ptr } zeroinitializer, ptr %t231, 1
  store { i32, ptr } %t233, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l166 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb118
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t21 = load ptr, ptr %l31, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l31, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 17}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l32, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [3 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %t41, ptr %t42)
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  br label %bb14
bb14:
  br label %bb118
bb15:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t50 = load ptr, ptr %l43, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l43, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 17}
  %t56 = icmp eq i64 %t54, 2
  store i1 %t56, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l44, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  br label %bb28
bb19:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t65 = load ptr, ptr %l49, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l49, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 17}
  %t71 = icmp eq i64 %t69, 15
  store i1 %t71, ptr %l50, !tbaa !21
  br label %bb21
bb21:
  %t72 = load i1, ptr %l50, !tbaa !21
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l5, !tbaa !29
  br label %bb28
bb23:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t80 = load ptr, ptr %l55, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb24, label %bb25
bb24:
  %t83 = load ptr, ptr %l55, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 17}
  %t86 = icmp eq i64 %t84, 8
  store i1 %t86, ptr %l56, !tbaa !21
  br label %bb25
bb25:
  %t87 = load i1, ptr %l56, !tbaa !21
  br i1 %t87, label %bb26, label %bb27
bb26:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t90, i32 0, i32 1
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t94, ptr %t95)
  br label %bb29
bb29:
  br label %bb118
bb30:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t99 = load ptr, ptr %l63, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 17}
  %t105 = icmp eq i64 %t103, 3
  store i1 %t105, ptr %l64, !tbaa !21
  br label %bb32
bb32:
  %t106 = load i1, ptr %l64, !tbaa !21
  br i1 %t106, label %bb33, label %bb34
bb33:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [3 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", ptr }, ptr %t109, i32 0, i32 1
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l6, !tbaa !29
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/typed:If", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t113, ptr %t117)
  br label %bb36
bb36:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l6, !tbaa !29
  %t123 = getelementptr %"compiler/typed:If", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t120, ptr %t124)
  br label %bb37
bb37:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l6, !tbaa !29
  %t131 = getelementptr %"compiler/typed:If", ptr %t129, i32 0, i32 2
  %t132 = load ptr, ptr %t131, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t128, ptr %t132)
  br label %bb38
bb38:
  br label %bb118
bb39:
  %t135 = load ptr, ptr %l1, !tbaa !29
  store ptr %t135, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t136 = load ptr, ptr %l79, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb40, label %bb41
bb40:
  %t139 = load ptr, ptr %l79, !tbaa !29
  %t140 = load i64, ptr %t139, !range !{i64 0, i64 17}
  %t142 = icmp eq i64 %t140, 4
  store i1 %t142, ptr %l80, !tbaa !21
  br label %bb41
bb41:
  %t143 = load i1, ptr %l80, !tbaa !21
  br i1 %t143, label %bb42, label %bb43
bb42:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t146, i32 0, i32 1
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l7, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [3 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t152, i32 0, i32 2
  %t154 = load ptr, ptr %t153
  store ptr %t154, ptr %l8, !tbaa !29
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t156, ptr %t157)
  br label %bb45
bb45:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t161, ptr %t162)
  br label %bb46
bb46:
  br label %bb118
bb47:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t166 = load ptr, ptr %l92, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb48, label %bb49
bb48:
  %t169 = load ptr, ptr %l92, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 17}
  %t172 = icmp eq i64 %t170, 6
  store i1 %t172, ptr %l93, !tbaa !21
  br label %bb49
bb49:
  %t173 = load i1, ptr %l93, !tbaa !21
  br i1 %t173, label %bb50, label %bb51
bb50:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [3 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", ptr }, ptr %t176, i32 0, i32 1
  %t178 = load ptr, ptr %t177
  store ptr %t178, ptr %l9, !tbaa !29
  br label %bb60
bb51:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t181 = load ptr, ptr %l98, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb52, label %bb53
bb52:
  %t184 = load ptr, ptr %l98, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 17}
  %t187 = icmp eq i64 %t185, 16
  store i1 %t187, ptr %l99, !tbaa !21
  br label %bb53
bb53:
  %t188 = load i1, ptr %l99, !tbaa !21
  br i1 %t188, label %bb54, label %bb55
bb54:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [3 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", ptr }, ptr %t191, i32 0, i32 1
  %t193 = load ptr, ptr %t192
  store ptr %t193, ptr %l9, !tbaa !29
  br label %bb60
bb55:
  %t195 = load ptr, ptr %l1, !tbaa !29
  store ptr %t195, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t196 = load ptr, ptr %l104, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb56, label %bb57
bb56:
  %t199 = load ptr, ptr %l104, !tbaa !29
  %t200 = load i64, ptr %t199, !range !{i64 0, i64 17}
  %t202 = icmp eq i64 %t200, 9
  store i1 %t202, ptr %l105, !tbaa !21
  br label %bb57
bb57:
  %t203 = load i1, ptr %l105, !tbaa !21
  br i1 %t203, label %bb58, label %bb59
bb58:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t206, i32 0, i32 2
  %t208 = load ptr, ptr %t207
  store ptr %t208, ptr %l9, !tbaa !29
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t210, ptr %t211)
  br label %bb61
bb61:
  br label %bb118
bb62:
  %t214 = load ptr, ptr %l1, !tbaa !29
  store ptr %t214, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t215 = load ptr, ptr %l112, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb63, label %bb64
bb63:
  %t218 = load ptr, ptr %l112, !tbaa !29
  %t219 = load i64, ptr %t218, !range !{i64 0, i64 17}
  %t221 = icmp eq i64 %t219, 10
  store i1 %t221, ptr %l113, !tbaa !21
  br label %bb64
bb64:
  %t222 = load i1, ptr %l113, !tbaa !21
  br i1 %t222, label %bb65, label %bb66
bb65:
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr { i64, [3 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t225, i32 0, i32 1
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l10, !tbaa !29
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t231, i32 0, i32 2
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l11, !tbaa !29
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t235, ptr %t236)
  br label %bb68
bb68:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t239, ptr %t240)
  br label %bb69
bb69:
  br label %bb118
bb70:
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t244 = load ptr, ptr %l124, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb71, label %bb72
bb71:
  %t247 = load ptr, ptr %l124, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 17}
  %t250 = icmp eq i64 %t248, 11
  store i1 %t250, ptr %l125, !tbaa !21
  br label %bb72
bb72:
  %t251 = load i1, ptr %l125, !tbaa !21
  br i1 %t251, label %bb73, label %bb74
bb73:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr { i64, [3 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", ptr }, ptr %t254, i32 0, i32 1
  %t256 = load ptr, ptr %t255
  store ptr %t256, ptr %l12, !tbaa !29
  br label %bb79
bb74:
  %t258 = load ptr, ptr %l1, !tbaa !29
  store ptr %t258, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t259 = load ptr, ptr %l130, !tbaa !29
  %t260 = icmp ne ptr %t259, null
  br i1 %t260, label %bb75, label %bb76
bb75:
  %t262 = load ptr, ptr %l130, !tbaa !29
  %t263 = load i64, ptr %t262, !range !{i64 0, i64 17}
  %t265 = icmp eq i64 %t263, 12
  store i1 %t265, ptr %l131, !tbaa !21
  br label %bb76
bb76:
  %t266 = load i1, ptr %l131, !tbaa !21
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t267 = load ptr, ptr %l1, !tbaa !29
  %t269 = getelementptr { i64, [3 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", ptr }, ptr %t269, i32 0, i32 1
  %t271 = load ptr, ptr %t270
  store ptr %t271, ptr %l12, !tbaa !29
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t273, ptr %t274)
  br label %bb80
bb80:
  br label %bb118
bb81:
  %t278 = load ptr, ptr %l1, !tbaa !29
  store ptr %t278, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t279 = load ptr, ptr %l139, !tbaa !29
  %t280 = icmp ne ptr %t279, null
  br i1 %t280, label %bb82, label %bb83
bb82:
  %t282 = load ptr, ptr %l139, !tbaa !29
  %t283 = load i64, ptr %t282, !range !{i64 0, i64 17}
  %t285 = icmp eq i64 %t283, 13
  store i1 %t285, ptr %l140, !tbaa !21
  br label %bb83
bb83:
  %t286 = load i1, ptr %l140, !tbaa !21
  br i1 %t286, label %bb84, label %bb85
bb84:
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = getelementptr { i64, [3 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { %"compiler/source:Span", ptr }, ptr %t289, i32 0, i32 1
  %t291 = load ptr, ptr %t290
  store ptr %t291, ptr %l13, !tbaa !29
  br label %bb86
bb85:
  br label %bb89
bb86:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l13, !tbaa !29
  %t296 = getelementptr %"compiler/typed:Join", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t293, ptr %t297)
  br label %bb87
bb87:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load ptr, ptr %l13, !tbaa !29
  %t304 = getelementptr %"compiler/typed:Join", ptr %t302, i32 0, i32 2
  %t305 = load { i64, ptr }, ptr %t304, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eclauses(ptr %v0, ptr %v1, ptr %t301, { i64, ptr } %t305)
  br label %bb88
bb88:
  br label %bb118
bb89:
  %t308 = load ptr, ptr %l1, !tbaa !29
  store ptr %t308, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t309 = load ptr, ptr %l152, !tbaa !29
  %t310 = icmp ne ptr %t309, null
  br i1 %t310, label %bb90, label %bb91
bb90:
  %t312 = load ptr, ptr %l152, !tbaa !29
  %t313 = load i64, ptr %t312, !range !{i64 0, i64 17}
  %t315 = icmp eq i64 %t313, 14
  store i1 %t315, ptr %l153, !tbaa !21
  br label %bb91
bb91:
  %t316 = load i1, ptr %l153, !tbaa !21
  br i1 %t316, label %bb92, label %bb93
bb92:
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = getelementptr { i64, [3 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", ptr }, ptr %t319, i32 0, i32 1
  %t321 = load ptr, ptr %t320
  store ptr %t321, ptr %l14, !tbaa !29
  br label %bb94
bb93:
  br label %bb113
bb94:
  %t323 = load ptr, ptr %l14, !tbaa !29
  %t325 = getelementptr %"compiler/typed:Spawn", ptr %t323, i32 0, i32 0
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t328 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t328, 0
  store i64 %t330, ptr %l17, !tbaa !24
  br label %bb95
bb95:
  %t332 = load i64, ptr %l16, !tbaa !24
  %t333 = load i64, ptr %l17, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb96, label %bb97
bb96:
  br label %bb104
bb97:
  br label %bb98
bb98:
  %t340 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t340, ptr %l166, !tbaa !27
  %t341 = load i64, ptr %l16, !tbaa !24
  %t343 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr ptr, ptr %t344, i64 %t341
  %t346 = load ptr, ptr %t345, !tbaa !39
  store ptr %t346, ptr %l18, !tbaa !29
  %t348 = load ptr, ptr %l18, !tbaa !29
  %t350 = icmp eq ptr %t348, null
  %t352 = xor i1 %t350, true
  br i1 %t352, label %bb99, label %bb100
bb99:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %t354, ptr %t355)
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb102
bb102:
  br label %bb103
bb103:
  %t358 = load i64, ptr %l16, !tbaa !24
  %t361 = add i64 %t358, 1
  store i64 %t361, ptr %l16, !tbaa !24
  br label %bb95
bb104:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load ptr, ptr %l14, !tbaa !29
  %t366 = getelementptr %"compiler/typed:Spawn", ptr %t364, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t363, ptr %t367)
  br label %bb105
bb105:
  %t370 = load ptr, ptr %l14, !tbaa !29
  %t372 = getelementptr %"compiler/typed:Spawn", ptr %t370, i32 0, i32 2
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  store { i64, ptr } %t373, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t375 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t375, 0
  store i64 %t377, ptr %l21, !tbaa !24
  br label %bb106
bb106:
  %t379 = load i64, ptr %l20, !tbaa !24
  %t380 = load i64, ptr %l21, !tbaa !24
  %t383 = icmp slt i64 %t379, %t380
  %t385 = xor i1 %t383, true
  br i1 %t385, label %bb107, label %bb108
bb107:
  br label %bb112
bb108:
  br label %bb109
bb109:
  %t387 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t387, ptr %l188, !tbaa !27
  %t388 = load i64, ptr %l20, !tbaa !24
  %t390 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr ptr, ptr %t391, i64 %t388
  %t393 = load ptr, ptr %t392, !tbaa !39
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/typed:TaskClause", ptr %t393, i32 0, i32 3
  %t399 = load ptr, ptr %t398, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t395, ptr %t399)
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t402 = load i64, ptr %l20, !tbaa !24
  %t405 = add i64 %t402, 1
  store i64 %t405, ptr %l20, !tbaa !24
  br label %bb106
bb112:
  br label %bb118
bb113:
  br i1 true, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_check_failed(ptr @olang_loc_4e4df3a218fbdfef_2fc14a2cfade6f23)
  unreachable
bb118:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ereadRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3c, ptr %a3e, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i32
  %l57 = alloca i64
  %l58 = alloca i32
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l75 = alloca i64
  %l78 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca i32
  %l83 = alloca i64
  %l84 = alloca i32
  %l86 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca i32
  %l91 = alloca i64
  %l92 = alloca i32
  %l96 = alloca i1
  %l102 = alloca i1
  %l105 = alloca i1
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca i64
  %l126 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l128 = alloca i64
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca i32
  %l133 = alloca i64
  %l134 = alloca i32
  %l138 = alloca i1
  %l139 = alloca i64
  %l142 = alloca i64
  %l145 = alloca { i64, ptr }
  %l149 = alloca i64
  %l152 = alloca ptr
  %l156 = alloca ptr
  %l157 = alloca { i64, [2 x i64] }
  %l159 = alloca { i64, ptr }
  %l160 = alloca { i64, [2 x i64] }
  %l161 = alloca i32
  %l163 = alloca { i64, ptr }
  %l167 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l169 = alloca i64
  %l173 = alloca i64
  %l176 = alloca i64
  %l196 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l198 = alloca ptr
  %l200 = alloca i64
  %l203 = alloca i64
  %l205 = alloca { i64, ptr }
  %l206 = alloca i64
  %l207 = alloca i32
  %l208 = alloca i64
  %l209 = alloca i32
  %l211 = alloca i64
  %l213 = alloca { i64, ptr }
  %l214 = alloca i64
  %l215 = alloca i32
  %l216 = alloca i64
  %l217 = alloca i32
  %l219 = alloca ptr
  %l220 = alloca i64
  %l221 = alloca i64
  %l222 = alloca { i64, [2 x i64] }
  %l226 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l230 = alloca i64
  %l232 = alloca { i64, ptr }
  %l235 = alloca i64
  %l239 = alloca { i64, ptr }
  %l242 = alloca i64
  %l243 = alloca i64
  %l248 = alloca { i64, [2 x i64] }
  %l249 = alloca i32
  %l251 = alloca %"compiler/typed:DerivedArg"
  %l255 = alloca ptr
  %l259 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  %pf3 = insertvalue { ptr, ptr } undef, ptr %a3c, 0
  %pg3 = insertvalue { ptr, ptr } %pf3, ptr %a3e, 1
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l20, !tbaa !27
  %t2 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t3 = load ptr, ptr %t2, !tbaa !27
  %t4 = getelementptr i8, ptr %t3, i64 0
  %t5 = load i8, ptr %t4, !tbaa !32
  %t7 = icmp eq i8 %t5, 114
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Plan", ptr %t9, i32 0, i32 11
  store ptr %t11, ptr %l24, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l26, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l27, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t14, 0
  store i64 %t17, ptr %l30, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l31, !tbaa !24
  %t20 = icmp sge i64 1, 0
  br i1 %t20, label %bb3, label %bb4
bb2:
  br label %bb13
bb3:
  %t22 = load i64, ptr %l30, !tbaa !24
  %t23 = icmp sle i64 1, %t22
  br i1 %t23, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_df109db0fdeebc9d_ef38e7cbbce86079)
  unreachable
bb5:
  %t25 = load i64, ptr %l30, !tbaa !24
  %t26 = load i64, ptr %l31, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_df109db0fdeebc9d_ef38e7cbbce86079)
  unreachable
bb7:
  %t29 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l30, !tbaa !24
  %t32 = getelementptr i8, ptr %t30, i64 1
  %t33 = sub i64 %t31, 1
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t37 = load ptr, ptr %l26, !tbaa !29
  %t40 = extractvalue { ptr, ptr } %pg3, 0
  %t41 = extractvalue { ptr, ptr } %pg3, 1
  %t42 = call { i32, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eReadExpr(ptr %v2, ptr %v1, ptr %v3, ptr %v2, ptr %t37, { i64, ptr } %t35, ptr %t40, ptr %t41)
  %t43 = extractvalue { i32, ptr } %t42, 1
  %t44 = extractvalue { i32, ptr } %t42, 0
  store i32 %t44, ptr %l38
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb10, label %ok.46, !prof !99
ok.46:
  store ptr %t43, ptr %l37
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_df109db0fdeebc9d_ef38e7cbbce86079)
  unreachable
bb9:
  %t47 = load ptr, ptr %l37, !tbaa !29
  store ptr %t47, ptr %l25, !tbaa !29
  br label %bb11
bb10:
  %t48 = load i32, ptr %l38, !tbaa !23
  %t49 = lshr i32 %t48, 16
  %t50 = and i32 %t48, 65535
  %t51 = icmp eq i32 %t49, 1
  %t52 = select i1 %t51, i32 1, i32 0
  %t53 = icmp eq i32 %t48, 0
  %t54 = shl i32 %t52, 16
  %t55 = or i32 %t54, %t50
  %t56 = select i1 %t53, i32 0, i32 %t55
  call void @__olang_scope_close(ptr %s0)
  store i32 %t56, ptr %rv
  br label %ret
bb11:
  %t58 = load ptr, ptr %l24, !tbaa !29
  %t59 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t58, ptr %t59)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb13:
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t60, ptr %l40, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 0
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 101
  br i1 %t66, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Plan", ptr %t68, i32 0, i32 12
  store ptr %t70, ptr %l44, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t71, ptr %l46, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t72, 0
  store i64 %t75, ptr %l49, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l50, !tbaa !24
  %t78 = icmp sge i64 1, 0
  br i1 %t78, label %bb16, label %bb17
bb15:
  br label %bb29
bb16:
  %t80 = load i64, ptr %l49, !tbaa !24
  %t81 = icmp sle i64 1, %t80
  br i1 %t81, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_4e1b3d3964dcf140_426a19f9f36fcc4c)
  unreachable
bb18:
  %t83 = load i64, ptr %l49, !tbaa !24
  %t84 = load i64, ptr %l50, !tbaa !24
  %t85 = icmp sle i64 %t83, %t84
  br i1 %t85, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_4e1b3d3964dcf140_426a19f9f36fcc4c)
  unreachable
bb20:
  %t87 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l49, !tbaa !24
  %t90 = getelementptr i8, ptr %t88, i64 1
  %t91 = sub i64 %t89, 1
  %t92 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t90, 1
  store { i64, ptr } %t93, ptr %l54, !tbaa !27
  %t94 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 10)
  %t95 = extractvalue { i32, i64 } %t94, 1
  %t96 = extractvalue { i32, i64 } %t94, 0
  store i32 %t96, ptr %l56
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb23, label %ok.98, !prof !99
ok.98:
  store i64 %t95, ptr %l55
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4e1b3d3964dcf140_426a19f9f36fcc4c)
  unreachable
bb22:
  %t99 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t100 = load i64, ptr %l55, !tbaa !24
  %t101 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v1, { i64, ptr } %t99, i64 %t100)
  %t102 = extractvalue { i32, i64 } %t101, 1
  %t103 = extractvalue { i32, i64 } %t101, 0
  store i32 %t103, ptr %l58
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb26, label %ok.105, !prof !99
ok.105:
  store i64 %t102, ptr %l57
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb25:
  %t107 = load i64, ptr %l57, !tbaa !24
  store i64 %t107, ptr %l45, !tbaa !24
  br label %bb27
bb26:
  br label %bb24
bb27:
  %t108 = load ptr, ptr %l44, !tbaa !29
  %t109 = load i64, ptr %l45, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t108, i64 %t109)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb29:
  %t110 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t110, ptr %l60, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 0
  %t114 = load i8, ptr %t113, !tbaa !32
  %t116 = icmp eq i8 %t114, 116
  br i1 %t116, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t118, ptr %l63, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t119, 0
  store i64 %t122, ptr %l66, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l67, !tbaa !24
  %t125 = icmp sge i64 1, 0
  br i1 %t125, label %bb32, label %bb33
bb31:
  br label %bb70
bb32:
  %t127 = load i64, ptr %l66, !tbaa !24
  %t128 = icmp sle i64 1, %t127
  br i1 %t128, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_814422372e4dce3b_a43643d36bfe9937)
  unreachable
bb34:
  %t130 = load i64, ptr %l66, !tbaa !24
  %t131 = load i64, ptr %l67, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_814422372e4dce3b_a43643d36bfe9937)
  unreachable
bb36:
  %t134 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l66, !tbaa !24
  %t137 = getelementptr i8, ptr %t135, i64 1
  %t138 = sub i64 %t136, 1
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  %t142 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s4, ptr %s4, { i64, ptr } %t140, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store { i64, ptr } %t142, ptr %l72
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_814422372e4dce3b_a43643d36bfe9937)
  unreachable
bb38:
  %t143 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t144 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s4, ptr %s4, { i64, ptr } %t143)
  store ptr %t144, ptr %l73
  br label %bb39
bb39:
  %t145 = load ptr, ptr %l73, !tbaa !29
  store ptr %t145, ptr %l5, !tbaa !29
  %t146 = load ptr, ptr %l5, !tbaa !29
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s4, ptr %t146)
  store i64 %t148, ptr %l75
  br label %bb40
bb40:
  %t149 = load i64, ptr %l75, !tbaa !24
  %t150 = icmp ne i64 %t149, 2
  br i1 %t150, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t153 = load ptr, ptr %l5, !tbaa !29
  %t155 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s4, ptr %s4, ptr %t153, i64 0)
  store { i64, ptr } %t155, ptr %l80
  br label %bb44
bb44:
  %t156 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 10)
  %t157 = extractvalue { i32, i64 } %t156, 1
  %t158 = extractvalue { i32, i64 } %t156, 0
  store i32 %t158, ptr %l82
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb46, label %ok.160, !prof !99
ok.160:
  store i64 %t157, ptr %l81
  br label %bb45
bb45:
  %t161 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t162 = load i64, ptr %l81, !tbaa !24
  %t163 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s4, { i64, ptr } %t161, i64 %t162)
  %t164 = extractvalue { i32, i64 } %t163, 1
  %t165 = extractvalue { i32, i64 } %t163, 0
  store i32 %t165, ptr %l84
  %t166 = icmp ne i32 %t165, 0
  br i1 %t166, label %bb49, label %ok.167, !prof !99
ok.167:
  store i64 %t164, ptr %l83
  br label %bb48
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb48:
  %t169 = load i64, ptr %l83, !tbaa !24
  store i64 %t169, ptr %l78, !tbaa !24
  br label %bb50
bb49:
  br label %bb47
bb50:
  %t170 = load i64, ptr %l78, !tbaa !24
  store i64 %t170, ptr %l6, !tbaa !24
  %t171 = load ptr, ptr %l5, !tbaa !29
  %t173 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s4, ptr %s4, ptr %t171, i64 1)
  store { i64, ptr } %t173, ptr %l88
  br label %bb51
bb51:
  %t174 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 10)
  %t175 = extractvalue { i32, i64 } %t174, 1
  %t176 = extractvalue { i32, i64 } %t174, 0
  store i32 %t176, ptr %l90
  %t177 = icmp ne i32 %t176, 0
  br i1 %t177, label %bb53, label %ok.178, !prof !99
ok.178:
  store i64 %t175, ptr %l89
  br label %bb52
bb52:
  %t179 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t180 = load i64, ptr %l89, !tbaa !24
  %t181 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s4, { i64, ptr } %t179, i64 %t180)
  %t182 = extractvalue { i32, i64 } %t181, 1
  %t183 = extractvalue { i32, i64 } %t181, 0
  store i32 %t183, ptr %l92
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb56, label %ok.185, !prof !99
ok.185:
  store i64 %t182, ptr %l91
  br label %bb55
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb55:
  %t187 = load i64, ptr %l91, !tbaa !24
  store i64 %t187, ptr %l86, !tbaa !24
  br label %bb57
bb56:
  br label %bb54
bb57:
  %t188 = load i64, ptr %l86, !tbaa !24
  store i64 %t188, ptr %l7, !tbaa !24
  %t189 = load i64, ptr %l6, !tbaa !24
  %t191 = icmp slt i64 %t189, 0
  br i1 %t191, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb60
bb59:
  %t193 = load i64, ptr %l6, !tbaa !24
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Plan", ptr %t194, i32 0, i32 13
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t202 = icmp sge i64 %t193, %t199
  store i1 %t202, ptr %l96, !tbaa !21
  br label %bb60
bb60:
  %t204 = load i1, ptr %l96, !tbaa !21
  br i1 %t204, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb63
bb62:
  %t205 = load i64, ptr %l7, !tbaa !24
  %t207 = icmp slt i64 %t205, 0
  store i1 %t207, ptr %l102, !tbaa !21
  br label %bb63
bb63:
  %t209 = load i1, ptr %l102, !tbaa !21
  br i1 %t209, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb66
bb65:
  %t210 = load i64, ptr %l7, !tbaa !24
  %t211 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t216 = icmp sge i64 %t210, %t213
  store i1 %t216, ptr %l105, !tbaa !21
  br label %bb66
bb66:
  %t218 = load i1, ptr %l105, !tbaa !21
  br i1 %t218, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Plan", ptr %t220, i32 0, i32 13
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  store { i64, ptr } %t223, ptr %l112, !tbaa !27
  %t224 = load i64, ptr %l6, !tbaa !24
  %t225 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t225, ptr %l114, !tbaa !27
  %t226 = load i64, ptr %l7, !tbaa !24
  %t228 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr i64, ptr %t229, i64 %t226
  %t231 = load i64, ptr %t230, !tbaa !34
  %t234 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i64, ptr %t235, i64 %t224
  store i64 %t231, ptr %t236, !tbaa !34
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb70:
  %t237 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t237, ptr %l117, !tbaa !27
  %t238 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t238, 0
  store i64 %t241, ptr %l120, !tbaa !24
  %t242 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  store i64 %t243, ptr %l121, !tbaa !24
  %t244 = icmp sge i64 1, 0
  br i1 %t244, label %bb71, label %bb72
bb71:
  %t246 = load i64, ptr %l120, !tbaa !24
  %t247 = icmp sle i64 1, %t246
  br i1 %t247, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_964b6738afc8bcbe_650d3b8036ee77da)
  unreachable
bb73:
  %t249 = load i64, ptr %l120, !tbaa !24
  %t250 = load i64, ptr %l121, !tbaa !24
  %t251 = icmp sle i64 %t249, %t250
  br i1 %t251, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_964b6738afc8bcbe_650d3b8036ee77da)
  unreachable
bb75:
  %t253 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = load i64, ptr %l120, !tbaa !24
  %t256 = getelementptr i8, ptr %t254, i64 1
  %t257 = sub i64 %t255, 1
  %t258 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t256, 1
  %t261 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t259, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store { i64, ptr } %t261, ptr %l126
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_964b6738afc8bcbe_650d3b8036ee77da)
  unreachable
bb77:
  %t262 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t263 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0, ptr %s0, { i64, ptr } %t262)
  store ptr %t263, ptr %l127
  br label %bb78
bb78:
  %t264 = load ptr, ptr %l127, !tbaa !29
  store ptr %t264, ptr %l8, !tbaa !29
  %t265 = load ptr, ptr %l8, !tbaa !29
  %t267 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t265, i64 0)
  store { i64, ptr } %t267, ptr %l130
  br label %bb79
bb79:
  %t268 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t269 = extractvalue { i32, i64 } %t268, 1
  %t270 = extractvalue { i32, i64 } %t268, 0
  store i32 %t270, ptr %l132
  %t271 = icmp ne i32 %t270, 0
  br i1 %t271, label %bb81, label %ok.272, !prof !99
ok.272:
  store i64 %t269, ptr %l131
  br label %bb80
bb80:
  %t273 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t274 = load i64, ptr %l131, !tbaa !24
  %t275 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s0, { i64, ptr } %t273, i64 %t274)
  %t276 = extractvalue { i32, i64 } %t275, 1
  %t277 = extractvalue { i32, i64 } %t275, 0
  store i32 %t277, ptr %l134
  %t278 = icmp ne i32 %t277, 0
  br i1 %t278, label %bb84, label %ok.279, !prof !99
ok.279:
  store i64 %t276, ptr %l133
  br label %bb83
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb83:
  %t281 = load i64, ptr %l133, !tbaa !24
  store i64 %t281, ptr %l128, !tbaa !24
  br label %bb85
bb84:
  br label %bb82
bb85:
  %t282 = load i64, ptr %l128, !tbaa !24
  store i64 %t282, ptr %l9, !tbaa !24
  %t283 = load i64, ptr %l9, !tbaa !24
  %t285 = icmp slt i64 %t283, 0
  br i1 %t285, label %bb86, label %bb87
bb86:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb89
bb87:
  %t287 = load i64, ptr %l9, !tbaa !24
  store i64 %t287, ptr %l139, !tbaa !24
  %t288 = load ptr, ptr %l2, !tbaa !29
  %t290 = getelementptr %"compiler/typed:Nodes", ptr %t288, i32 0, i32 0
  %t292 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v2, ptr %t290)
  store i64 %t292, ptr %l142
  br label %bb88
bb88:
  %t293 = load i64, ptr %l139, !tbaa !24
  %t294 = load i64, ptr %l142, !tbaa !24
  %t295 = icmp sge i64 %t293, %t294
  store i1 %t295, ptr %l138, !tbaa !21
  br label %bb89
bb89:
  %t297 = load i1, ptr %l138, !tbaa !21
  br i1 %t297, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb91:
  br label %bb92
bb92:
  %t299 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t299, ptr %l145, !tbaa !27
  %t300 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr i8, ptr %t301, i64 0
  %t303 = load i8, ptr %t302, !tbaa !32
  %t305 = icmp eq i8 %t303, 105
  br i1 %t305, label %bb93, label %bb94
bb93:
  %t307 = load ptr, ptr %l8, !tbaa !29
  %t309 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t307)
  store i64 %t309, ptr %l149
  br label %bb95
bb94:
  br label %bb105
bb95:
  %t310 = load i64, ptr %l149, !tbaa !24
  %t311 = icmp ne i64 %t310, 2
  br i1 %t311, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb97:
  br label %bb98
bb98:
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l152, !tbaa !29
  %t315 = load ptr, ptr %l2, !tbaa !29
  %t317 = getelementptr %"compiler/typed:Nodes", ptr %t315, i32 0, i32 0
  %t318 = load i64, ptr %l9, !tbaa !24
  %t321 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v2, ptr %v2, ptr %t317, i64 %t318)
  store ptr %t321, ptr %l156
  br label %bb99
bb99:
  %t322 = load ptr, ptr %l8, !tbaa !29
  %t324 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t322, i64 1)
  store { i64, ptr } %t324, ptr %l159
  br label %bb100
bb100:
  %t325 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t326 = call { i32, { i64, [2 x i64] } } @compiler_2ftyped_2eScope_2eOfText(ptr %s0, { i64, ptr } %t325)
  %t327 = extractvalue { i32, { i64, [2 x i64] } } %t326, 1
  %t328 = extractvalue { i32, { i64, [2 x i64] } } %t326, 0
  store i32 %t328, ptr %l161
  %t329 = icmp ne i32 %t328, 0
  br i1 %t329, label %bb102, label %ok.330, !prof !99
ok.330:
  store { i64, [2 x i64] } %t327, ptr %l160
  br label %bb101
bb101:
  %t331 = load { i64, [2 x i64] }, ptr %l160
  store { i64, [2 x i64] } %t331, ptr %l157
  br label %bb103
bb102:
  %t332 = load i32, ptr %l161, !tbaa !23
  %t333 = lshr i32 %t332, 16
  %t334 = and i32 %t332, 65535
  %t335 = icmp eq i32 %t333, 1
  %t336 = select i1 %t335, i32 1, i32 0
  %t337 = icmp eq i32 %t332, 0
  %t338 = shl i32 %t336, 16
  %t339 = or i32 %t338, %t334
  %t340 = select i1 %t337, i32 0, i32 %t339
  call void @__olang_scope_close(ptr %s0)
  store i32 %t340, ptr %rv
  br label %ret
bb103:
  %t342 = load ptr, ptr %l152, !tbaa !29
  %t343 = load ptr, ptr %l156, !tbaa !29
  %t344 = load { i64, [2 x i64] }, ptr %l157
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eDropHome(ptr %v0, ptr %v2, ptr %t342, ptr %t343, { i64, [2 x i64] } %t344)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb105:
  %t345 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t345, ptr %l163, !tbaa !27
  %t346 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr i8, ptr %t347, i64 0
  %t349 = load i8, ptr %t348, !tbaa !32
  %t351 = icmp ne i8 %t349, 100
  br i1 %t351, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb107:
  br label %bb108
bb108:
  %t354 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t354, ptr %l167
  br label %bb109
bb109:
  %t355 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l167
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t355, ptr %l10
  store i64 1, ptr %l11, !tbaa !24
  %t356 = load ptr, ptr %l8, !tbaa !29
  %t358 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t356)
  store i64 %t358, ptr %l169
  br label %bb110
bb110:
  %t359 = load i64, ptr %l169, !tbaa !24
  store i64 %t359, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t360 = load i64, ptr %l12, !tbaa !24
  %t361 = load i64, ptr %l11, !tbaa !24
  %t364 = icmp sgt i64 %t360, %t361
  br i1 %t364, label %bb111, label %bb112
bb111:
  %t366 = load i64, ptr %l13, !tbaa !24
  %t368 = icmp sgt i64 %t366, 0
  br i1 %t368, label %bb113, label %bb114
bb112:
  store i64 0, ptr %l173, !tbaa !24
  br label %bb116
bb113:
  %t370 = load i64, ptr %l12, !tbaa !24
  %t371 = load i64, ptr %l11, !tbaa !24
  %t374 = sub i64 %t370, %t371
  %t375 = load i64, ptr %l13, !tbaa !24
  %t378 = add i64 %t374, %t375
  %t380 = sub i64 %t378, 1
  %t381 = load i64, ptr %l13, !tbaa !24
  %t384 = sdiv i64 %t380, %t381
  store i64 %t384, ptr %l176, !tbaa !24
  br label %bb115
bb114:
  store i64 0, ptr %l176, !tbaa !24
  br label %bb115
bb115:
  %t386 = load i64, ptr %l176, !tbaa !24
  store i64 %t386, ptr %l173, !tbaa !24
  br label %bb116
bb116:
  %t387 = load i64, ptr %l173, !tbaa !24
  store i64 %t387, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb117
bb117:
  store %olang.scope zeroinitializer, ptr %s15
  %t388 = load i64, ptr %l15, !tbaa !24
  %t389 = load i64, ptr %l14, !tbaa !24
  %t392 = icmp slt i64 %t388, %t389
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb118, label %bb119
bb118:
  call void @__olang_scope_close(ptr %s15)
  br label %bb158
bb119:
  br label %bb120
bb120:
  %t396 = load i64, ptr %l11, !tbaa !24
  %t397 = load i64, ptr %l15, !tbaa !24
  %t398 = load i64, ptr %l13, !tbaa !24
  %t401 = mul i64 %t397, %t398
  %t404 = add i64 %t396, %t401
  store i64 %t404, ptr %l16, !tbaa !24
  %t406 = load ptr, ptr %l8, !tbaa !29
  %t407 = load i64, ptr %l16, !tbaa !24
  %t410 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t406, i64 %t407)
  store { i64, ptr } %t410, ptr %l196
  br label %bb121
bb121:
  %t411 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t412 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %s0, ptr %s15, ptr %s0, { i64, ptr } %t411, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store { i64, ptr } %t412, ptr %l197
  br label %bb122
bb122:
  %t413 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t414 = call ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0, ptr %s15, { i64, ptr } %t413)
  store ptr %t414, ptr %l198
  br label %bb123
bb123:
  %t415 = load ptr, ptr %l198, !tbaa !29
  store ptr %t415, ptr %l17, !tbaa !29
  %t416 = load ptr, ptr %l17, !tbaa !29
  %t418 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s15, ptr %t416)
  store i64 %t418, ptr %l200
  br label %bb124
bb124:
  %t419 = load i64, ptr %l200, !tbaa !24
  %t420 = icmp slt i64 %t419, 3
  br i1 %t420, label %bb125, label %bb126
bb125:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb126:
  br label %bb127
bb127:
  %t423 = load ptr, ptr %l17, !tbaa !29
  %t425 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s15, ptr %s15, ptr %t423, i64 0)
  store { i64, ptr } %t425, ptr %l205
  br label %bb128
bb128:
  %t426 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s15, i64 10)
  %t427 = extractvalue { i32, i64 } %t426, 1
  %t428 = extractvalue { i32, i64 } %t426, 0
  store i32 %t428, ptr %l207
  %t429 = icmp ne i32 %t428, 0
  br i1 %t429, label %bb130, label %ok.430, !prof !99
ok.430:
  store i64 %t427, ptr %l206
  br label %bb129
bb129:
  %t431 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t432 = load i64, ptr %l206, !tbaa !24
  %t433 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s15, { i64, ptr } %t431, i64 %t432)
  %t434 = extractvalue { i32, i64 } %t433, 1
  %t435 = extractvalue { i32, i64 } %t433, 0
  store i32 %t435, ptr %l209
  %t436 = icmp ne i32 %t435, 0
  br i1 %t436, label %bb133, label %ok.437, !prof !99
ok.437:
  store i64 %t434, ptr %l208
  br label %bb132
bb130:
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb132:
  %t439 = load i64, ptr %l208, !tbaa !24
  store i64 %t439, ptr %l203, !tbaa !24
  br label %bb134
bb133:
  br label %bb131
bb134:
  %t440 = load i64, ptr %l203, !tbaa !24
  store i64 %t440, ptr %l18, !tbaa !24
  %t441 = load ptr, ptr %l17, !tbaa !29
  %t443 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s15, ptr %s15, ptr %t441, i64 1)
  store { i64, ptr } %t443, ptr %l213
  br label %bb135
bb135:
  %t444 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s15, i64 10)
  %t445 = extractvalue { i32, i64 } %t444, 1
  %t446 = extractvalue { i32, i64 } %t444, 0
  store i32 %t446, ptr %l215
  %t447 = icmp ne i32 %t446, 0
  br i1 %t447, label %bb137, label %ok.448, !prof !99
ok.448:
  store i64 %t445, ptr %l214
  br label %bb136
bb136:
  %t449 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t450 = load i64, ptr %l214, !tbaa !24
  %t451 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s15, { i64, ptr } %t449, i64 %t450)
  %t452 = extractvalue { i32, i64 } %t451, 1
  %t453 = extractvalue { i32, i64 } %t451, 0
  store i32 %t453, ptr %l217
  %t454 = icmp ne i32 %t453, 0
  br i1 %t454, label %bb140, label %ok.455, !prof !99
ok.455:
  store i64 %t452, ptr %l216
  br label %bb139
bb137:
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb139:
  %t457 = load i64, ptr %l216, !tbaa !24
  store i64 %t457, ptr %l211, !tbaa !24
  br label %bb141
bb140:
  br label %bb138
bb141:
  %t458 = load i64, ptr %l211, !tbaa !24
  store ptr %l10, ptr %l219, !tbaa !29
  %t459 = load i64, ptr %l18, !tbaa !24
  store i64 %t459, ptr %l220, !tbaa !24
  store i64 %t458, ptr %l221, !tbaa !24
  %t461 = load ptr, ptr %l8, !tbaa !29
  %t463 = load i64, ptr %l16, !tbaa !24
  %t466 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t461, i64 %t463)
  store { i64, ptr } %t466, ptr %l226
  br label %bb142
bb142:
  %t467 = load { i64, ptr }, ptr %l226, !tbaa !27
  store { i64, ptr } %t467, ptr %l227, !tbaa !27
  %t468 = load ptr, ptr %l17, !tbaa !29
  %t470 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s15, ptr %s15, ptr %t468, i64 0)
  store { i64, ptr } %t470, ptr %l229
  br label %bb143
bb143:
  %t471 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t471, 0
  store i64 %t472, ptr %l230, !tbaa !24
  %t473 = load ptr, ptr %l17, !tbaa !29
  %t475 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s15, ptr %s15, ptr %t473, i64 1)
  store { i64, ptr } %t475, ptr %l232
  br label %bb144
bb144:
  %t476 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t477 = extractvalue { i64, ptr } %t476, 0
  %t478 = load i64, ptr %l230, !tbaa !24
  %t480 = add i64 %t478, %t477
  %t482 = add i64 %t480, 2
  store i64 %t482, ptr %l235, !tbaa !24
  %t483 = load ptr, ptr %l8, !tbaa !29
  %t485 = load i64, ptr %l16, !tbaa !24
  %t488 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t483, i64 %t485)
  store { i64, ptr } %t488, ptr %l239
  br label %bb145
bb145:
  %t489 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t489, 0
  store i64 %t492, ptr %l242, !tbaa !24
  %t493 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t493, 0
  store i64 %t494, ptr %l243, !tbaa !24
  %t495 = load i64, ptr %l235, !tbaa !24
  %t496 = icmp sge i64 %t495, 0
  br i1 %t496, label %bb146, label %bb147
bb146:
  %t498 = load i64, ptr %l235, !tbaa !24
  %t499 = load i64, ptr %l242, !tbaa !24
  %t500 = icmp sle i64 %t498, %t499
  br i1 %t500, label %bb148, label %bb149
bb147:
  call void @__olang_check_failed(ptr @olang_loc_e3571a351cb0ce21_2bd4e5481f65df95)
  unreachable
bb148:
  %t502 = load i64, ptr %l242, !tbaa !24
  %t503 = load i64, ptr %l243, !tbaa !24
  %t504 = icmp sle i64 %t502, %t503
  br i1 %t504, label %bb150, label %bb151
bb149:
  call void @__olang_check_failed(ptr @olang_loc_e3571a351cb0ce21_2bd4e5481f65df95)
  unreachable
bb150:
  %t506 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = load i64, ptr %l235, !tbaa !24
  %t509 = load i64, ptr %l242, !tbaa !24
  %t510 = getelementptr i8, ptr %t507, i64 %t508
  %t511 = sub i64 %t509, %t508
  %t512 = insertvalue { i64, ptr } undef, i64 %t511, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t510, 1
  %t515 = call { i32, { i64, [2 x i64] } } @compiler_2ftyped_2eScope_2eOfText(ptr %s0, { i64, ptr } %t513)
  %t516 = extractvalue { i32, { i64, [2 x i64] } } %t515, 1
  %t517 = extractvalue { i32, { i64, [2 x i64] } } %t515, 0
  store i32 %t517, ptr %l249
  %t518 = icmp ne i32 %t517, 0
  br i1 %t518, label %bb153, label %ok.519, !prof !99
ok.519:
  store { i64, [2 x i64] } %t516, ptr %l248
  br label %bb152
bb151:
  call void @__olang_check_failed(ptr @olang_loc_e3571a351cb0ce21_2bd4e5481f65df95)
  unreachable
bb152:
  %t520 = load { i64, [2 x i64] }, ptr %l248
  store { i64, [2 x i64] } %t520, ptr %l222
  br label %bb154
bb153:
  %t521 = load i32, ptr %l249, !tbaa !23
  %t522 = lshr i32 %t521, 16
  %t523 = and i32 %t521, 65535
  %t524 = icmp eq i32 %t522, 1
  %t525 = select i1 %t524, i32 1, i32 0
  %t526 = icmp eq i32 %t521, 0
  %t527 = shl i32 %t525, 16
  %t528 = or i32 %t527, %t523
  %t529 = select i1 %t526, i32 0, i32 %t528
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t529, ptr %rv
  br label %ret
bb154:
  %t531 = load i64, ptr %l220, !tbaa !24
  %t532 = load i64, ptr %l221, !tbaa !24
  %t533 = load { i64, [2 x i64] }, ptr %l222
  %t534 = call %"compiler/typed:DerivedArg" @compiler_2ftyped_3aDerivedArg_2ector(ptr %s15, i64 %t531, i64 %t532, { i64, [2 x i64] } %t533)
  store %"compiler/typed:DerivedArg" %t534, ptr %l251
  br label %bb155
bb155:
  %t535 = load ptr, ptr %l219, !tbaa !29
  %t536 = load %"compiler/typed:DerivedArg", ptr %l251
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2ePus_Hd9c60b9bc3eb0bc15b58bce924fabf2c(ptr %s0, ptr %t535, %"compiler/typed:DerivedArg" %t536)
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s15)
  br label %bb157
bb157:
  %t537 = load i64, ptr %l15, !tbaa !24
  %t540 = add i64 %t537, 1
  store i64 %t540, ptr %l15, !tbaa !24
  br label %bb117
bb158:
  %t542 = load ptr, ptr %l0, !tbaa !29
  store ptr %t542, ptr %l255, !tbaa !29
  %t543 = load ptr, ptr %l2, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Nodes", ptr %t543, i32 0, i32 0
  %t546 = load i64, ptr %l9, !tbaa !24
  %t549 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v2, ptr %v2, ptr %t545, i64 %t546)
  store ptr %t549, ptr %l259
  br label %bb159
bb159:
  %t550 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t551 = load ptr, ptr %l255, !tbaa !29
  %t552 = load ptr, ptr %l259, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eDropDerived(ptr %v0, ptr %v2, ptr %s0, ptr %t551, ptr %t552, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t550)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca i32
  %l47 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca ptr
  %l54 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l139 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l180 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l185 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l194 = alloca ptr
  %l195 = alloca i1
  %l208 = alloca { i64, ptr }
  %l219 = alloca ptr
  %l220 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l234 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l237 = alloca i64
  %l242 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l247 = alloca i64
  %l252 = alloca i64
  %l255 = alloca i64
  %l273 = alloca ptr
  %l274 = alloca i64
  %l275 = alloca ptr
  %l278 = alloca i64
  %l281 = alloca i64
  %l282 = alloca i64
  %l286 = alloca ptr
  %l288 = alloca i64
  %l289 = alloca i64
  %l290 = alloca ptr
  %l292 = alloca i64
  %l294 = alloca i64
  %l298 = alloca i64
  %l302 = alloca i64
  %l305 = alloca i64
  %l323 = alloca ptr
  %l327 = alloca i64
  %l328 = alloca ptr
  %l329 = alloca ptr
  %l333 = alloca i64
  %l334 = alloca i64
  %l335 = alloca i64
  %l343 = alloca ptr
  %l344 = alloca i1
  %l349 = alloca ptr
  %l350 = alloca i1
  %l366 = alloca { i64, ptr }
  %l376 = alloca ptr
  %l377 = alloca i1
  %l389 = alloca ptr
  %l390 = alloca i1
  %l403 = alloca { i64, ptr }
  %l406 = alloca ptr
  %l407 = alloca i1
  %l418 = alloca ptr
  %l419 = alloca i1
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t6 = load ptr, ptr %l57, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l57, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l58, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l58, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t15 = load ptr, ptr %l61, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l61, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l62, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l62, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb222
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t24 = load ptr, ptr %l65, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l65, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l66, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l66, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb26
bb17:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t39 = load ptr, ptr %l71, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l71, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l72, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l72, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb26
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t54 = load ptr, ptr %l77, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l77, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l78, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l78, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb27
bb27:
  br label %bb222
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t73 = load ptr, ptr %l85, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb29, label %bb30
bb29:
  %t76 = load ptr, ptr %l85, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 5
  store i1 %t79, ptr %l86, !tbaa !21
  br label %bb30
bb30:
  %t80 = load i1, ptr %l86, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  br label %bb34
bb34:
  br label %bb222
bb35:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t96 = load ptr, ptr %l95, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l95, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 18}
  %t102 = icmp eq i64 %t100, 6
  store i1 %t102, ptr %l96, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l96, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb48
bb40:
  %t110 = load ptr, ptr %l4, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Call", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l5, !tbaa !29
  %t115 = load ptr, ptr %l5, !tbaa !29
  store ptr %t115, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t116 = load ptr, ptr %l103, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb41, label %bb42
bb41:
  %t119 = load ptr, ptr %l103, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 5}
  %t122 = icmp eq i64 %t120, 2
  store i1 %t122, ptr %l104, !tbaa !21
  br label %bb42
bb42:
  %t123 = load i1, ptr %l104, !tbaa !21
  br i1 %t123, label %bb43, label %bb44
bb43:
  %t124 = load ptr, ptr %l5, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { ptr }, ptr %t126, i32 0, i32 0
  %t128 = load ptr, ptr %t127
  %t130 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t130, ptr %t128)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Call", ptr %t136, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %t135, { i64, ptr } %t139)
  br label %bb47
bb47:
  br label %bb222
bb48:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t143 = load ptr, ptr %l115, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb49, label %bb50
bb49:
  %t146 = load ptr, ptr %l115, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 18}
  %t149 = icmp eq i64 %t147, 7
  store i1 %t149, ptr %l116, !tbaa !21
  br label %bb50
bb50:
  %t150 = load i1, ptr %l116, !tbaa !21
  br i1 %t150, label %bb51, label %bb52
bb51:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l7, !tbaa !29
  br label %bb53
bb52:
  br label %bb56
bb53:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l7, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Make", ptr %t158, i32 0, i32 2
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %t157, { i64, ptr } %t161)
  br label %bb54
bb54:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l7, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Make", ptr %t165, i32 0, i32 3
  %t168 = load ptr, ptr %t167, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t164, ptr %t168)
  br label %bb55
bb55:
  br label %bb222
bb56:
  %t171 = load ptr, ptr %l1, !tbaa !29
  store ptr %t171, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t172 = load ptr, ptr %l127, !tbaa !29
  %t173 = icmp ne ptr %t172, null
  br i1 %t173, label %bb57, label %bb58
bb57:
  %t175 = load ptr, ptr %l127, !tbaa !29
  %t176 = load i64, ptr %t175, !range !{i64 0, i64 18}
  %t178 = icmp eq i64 %t176, 8
  store i1 %t178, ptr %l128, !tbaa !21
  br label %bb58
bb58:
  %t179 = load i1, ptr %l128, !tbaa !21
  br i1 %t179, label %bb59, label %bb60
bb59:
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t182, i32 0, i32 2
  %t184 = load ptr, ptr %t183
  store ptr %t184, ptr %l8, !tbaa !29
  br label %bb61
bb60:
  br label %bb69
bb61:
  store %olang.scope zeroinitializer, ptr %s8
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Collect", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t186, ptr %t190)
  br label %bb62
bb62:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Collect", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t200 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eloop(ptr %v0, ptr %v1, ptr %v0, ptr %s8, ptr %t193, ptr %t197, ptr null)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t200, ptr %l139
  br label %bb63
bb63:
  %t201 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l139
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t201, ptr %l9
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %t202)
  store i1 %t204, ptr %l141
  br label %bb64
bb64:
  %t205 = load i1, ptr %l141, !tbaa !21
  br i1 %t205, label %bb65, label %bb66
bb65:
  %t206 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s8, ptr %t206, ptr %l9)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s8)
  br label %bb222
bb69:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t210 = load ptr, ptr %l144, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb70, label %bb71
bb70:
  %t213 = load ptr, ptr %l144, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 18}
  %t216 = icmp eq i64 %t214, 9
  store i1 %t216, ptr %l145, !tbaa !21
  br label %bb71
bb71:
  %t217 = load i1, ptr %l145, !tbaa !21
  br i1 %t217, label %bb72, label %bb73
bb72:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t220, i32 0, i32 4
  %t222 = load { i64, ptr }, ptr %t221
  store { i64, ptr } %t222, ptr %l10, !tbaa !27
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %t224, { i64, ptr } %t225)
  br label %bb75
bb75:
  br label %bb222
bb76:
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t229 = load ptr, ptr %l152, !tbaa !29
  %t230 = icmp ne ptr %t229, null
  br i1 %t230, label %bb77, label %bb78
bb77:
  %t232 = load ptr, ptr %l152, !tbaa !29
  %t233 = load i64, ptr %t232, !range !{i64 0, i64 18}
  %t235 = icmp eq i64 %t233, 10
  store i1 %t235, ptr %l153, !tbaa !21
  br label %bb78
bb78:
  %t236 = load i1, ptr %l153, !tbaa !21
  br i1 %t236, label %bb79, label %bb80
bb79:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t239, i32 0, i32 2
  %t241 = load ptr, ptr %t240
  store ptr %t241, ptr %l11, !tbaa !29
  br label %bb81
bb80:
  br label %bb85
bb81:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l11, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Slice", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %t243, ptr %t247)
  br label %bb82
bb82:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l11, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Slice", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t250, ptr %t254)
  br label %bb83
bb83:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %l11, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Slice", ptr %t259, i32 0, i32 2
  %t262 = load ptr, ptr %t261, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t258, ptr %t262)
  br label %bb84
bb84:
  br label %bb222
bb85:
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t267 = load ptr, ptr %l169, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %bb86, label %bb87
bb86:
  %t270 = load ptr, ptr %l169, !tbaa !29
  %t271 = load i64, ptr %t270, !range !{i64 0, i64 18}
  %t273 = icmp eq i64 %t271, 11
  store i1 %t273, ptr %l170, !tbaa !21
  br label %bb87
bb87:
  %t274 = load i1, ptr %l170, !tbaa !21
  br i1 %t274, label %bb88, label %bb89
bb88:
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr { i64, [5 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t277, i32 0, i32 2
  %t279 = load ptr, ptr %t278
  store ptr %t279, ptr %l12, !tbaa !29
  br label %bb90
bb89:
  br label %bb98
bb90:
  store %olang.scope zeroinitializer, ptr %s12
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l12, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Cond", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t281, ptr %t285)
  br label %bb91
bb91:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s12, ptr %t289)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t291, ptr %l180
  br label %bb92
bb92:
  %t292 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l180
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t292, ptr %l13
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l12, !tbaa !29
  %t296 = getelementptr %"compiler/typed:Cond", ptr %t294, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t293, ptr %t297)
  br label %bb93
bb93:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s12, ptr %t300)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t302, ptr %l185
  br label %bb94
bb94:
  %t303 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l185
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t303, ptr %l14
  %t304 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s12, ptr %t304, ptr %l13)
  br label %bb95
bb95:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load ptr, ptr %l12, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Cond", ptr %t308, i32 0, i32 2
  %t311 = load ptr, ptr %t310, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t307, ptr %t311)
  br label %bb96
bb96:
  %t315 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s12, ptr %t315, ptr %l14)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s12)
  br label %bb222
bb98:
  %t318 = load ptr, ptr %l1, !tbaa !29
  store ptr %t318, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t319 = load ptr, ptr %l194, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb99, label %bb100
bb99:
  %t322 = load ptr, ptr %l194, !tbaa !29
  %t323 = load i64, ptr %t322, !range !{i64 0, i64 18}
  %t325 = icmp eq i64 %t323, 12
  store i1 %t325, ptr %l195, !tbaa !21
  br label %bb100
bb100:
  %t326 = load i1, ptr %l195, !tbaa !21
  br i1 %t326, label %bb101, label %bb102
bb101:
  %t327 = load ptr, ptr %l1, !tbaa !29
  %t329 = getelementptr { i64, [5 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t329, i32 0, i32 2
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l15, !tbaa !29
  br label %bb103
bb102:
  br label %bb112
bb103:
  %t333 = load ptr, ptr %l15, !tbaa !29
  %t335 = getelementptr %"compiler/typed:Seq", ptr %t333, i32 0, i32 0
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  store { i64, ptr } %t336, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t338 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t338, 0
  store i64 %t340, ptr %l18, !tbaa !24
  br label %bb104
bb104:
  %t342 = load i64, ptr %l17, !tbaa !24
  %t343 = load i64, ptr %l18, !tbaa !24
  %t346 = icmp slt i64 %t342, %t343
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb105, label %bb106
bb105:
  br label %bb110
bb106:
  br label %bb107
bb107:
  %t350 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t350, ptr %l208, !tbaa !27
  %t351 = load i64, ptr %l17, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 %t351
  %t356 = load ptr, ptr %t355, !tbaa !39
  %t358 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %t358, ptr %t356)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t362 = load i64, ptr %l17, !tbaa !24
  %t365 = add i64 %t362, 1
  store i64 %t365, ptr %l17, !tbaa !24
  br label %bb104
bb110:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l15, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Seq", ptr %t368, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t367, ptr %t371)
  br label %bb111
bb111:
  br label %bb222
bb112:
  %t374 = load ptr, ptr %l1, !tbaa !29
  store ptr %t374, ptr %l219, !tbaa !29
  store i1 false, ptr %l220, !tbaa !21
  %t375 = load ptr, ptr %l219, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb113, label %bb114
bb113:
  %t378 = load ptr, ptr %l219, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 18}
  %t381 = icmp eq i64 %t379, 13
  store i1 %t381, ptr %l220, !tbaa !21
  br label %bb114
bb114:
  %t382 = load i1, ptr %l220, !tbaa !21
  br i1 %t382, label %bb115, label %bb116
bb115:
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = getelementptr { i64, [5 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t385, i32 0, i32 2
  %t387 = load ptr, ptr %t386
  store ptr %t387, ptr %l20, !tbaa !29
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ematch(ptr %v0, ptr %v1, ptr %t389, ptr %t390)
  br label %bb118
bb118:
  br label %bb222
bb119:
  %t393 = load ptr, ptr %l1, !tbaa !29
  store ptr %t393, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t394 = load ptr, ptr %l227, !tbaa !29
  %t395 = icmp ne ptr %t394, null
  br i1 %t395, label %bb120, label %bb121
bb120:
  %t397 = load ptr, ptr %l227, !tbaa !29
  %t398 = load i64, ptr %t397, !range !{i64 0, i64 18}
  %t400 = icmp eq i64 %t398, 14
  store i1 %t400, ptr %l228, !tbaa !21
  br label %bb121
bb121:
  %t401 = load i1, ptr %l228, !tbaa !21
  br i1 %t401, label %bb122, label %bb123
bb122:
  %t402 = load ptr, ptr %l1, !tbaa !29
  %t404 = getelementptr { i64, [5 x i64] }, ptr %t402, i32 0, i32 1
  %t405 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t404, i32 0, i32 2
  %t406 = load ptr, ptr %t405
  store ptr %t406, ptr %l21, !tbaa !29
  br label %bb124
bb123:
  br label %bb172
bb124:
  store %olang.scope zeroinitializer, ptr %s18
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s18, ptr %t408)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t410, ptr %l234
  br label %bb125
bb125:
  %t411 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l234
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t411, ptr %l22
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = getelementptr %"compiler/typed:Versions", ptr %t412, i32 0, i32 15
  %t416 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t414)
  store i64 %t416, ptr %l237
  br label %bb126
bb126:
  %t417 = load i64, ptr %l237, !tbaa !24
  store i64 %t417, ptr %l23, !tbaa !24
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load ptr, ptr %l21, !tbaa !29
  %t421 = getelementptr %"compiler/typed:Try", ptr %t419, i32 0, i32 0
  %t422 = load ptr, ptr %t421, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t418, ptr %t422)
  br label %bb127
bb127:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s18, ptr %t425)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t427, ptr %l242
  br label %bb128
bb128:
  %t428 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l242
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t428, ptr %l24
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/typed:Versions", ptr %t429, i32 0, i32 20
  %t432 = load i1, ptr %t431, !tbaa !21
  %t434 = xor i1 %t432, true
  br i1 %t434, label %bb129, label %bb130
bb129:
  store i64 0, ptr %l25, !tbaa !24
  %t437 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %l22)
  store i64 %t437, ptr %l247
  br label %bb131
bb130:
  br label %bb170
bb131:
  %t438 = load i64, ptr %l247, !tbaa !24
  %t439 = sub i64 %t438, 1
  store i64 %t439, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t441 = load i64, ptr %l26, !tbaa !24
  %t442 = load i64, ptr %l25, !tbaa !24
  %t445 = icmp sgt i64 %t441, %t442
  br i1 %t445, label %bb132, label %bb133
bb132:
  %t447 = load i64, ptr %l27, !tbaa !24
  %t449 = icmp sgt i64 %t447, 0
  br i1 %t449, label %bb134, label %bb135
bb133:
  store i64 0, ptr %l252, !tbaa !24
  br label %bb137
bb134:
  %t451 = load i64, ptr %l26, !tbaa !24
  %t452 = load i64, ptr %l25, !tbaa !24
  %t455 = sub i64 %t451, %t452
  %t456 = load i64, ptr %l27, !tbaa !24
  %t459 = add i64 %t455, %t456
  %t461 = sub i64 %t459, 1
  %t462 = load i64, ptr %l27, !tbaa !24
  %t465 = sdiv i64 %t461, %t462
  store i64 %t465, ptr %l255, !tbaa !24
  br label %bb136
bb135:
  store i64 0, ptr %l255, !tbaa !24
  br label %bb136
bb136:
  %t467 = load i64, ptr %l255, !tbaa !24
  store i64 %t467, ptr %l252, !tbaa !24
  br label %bb137
bb137:
  %t468 = load i64, ptr %l252, !tbaa !24
  store i64 %t468, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb138
bb138:
  %t469 = load i64, ptr %l29, !tbaa !24
  %t470 = load i64, ptr %l28, !tbaa !24
  %t473 = icmp slt i64 %t469, %t470
  %t475 = xor i1 %t473, true
  br i1 %t475, label %bb139, label %bb140
bb139:
  br label %bb147
bb140:
  br label %bb141
bb141:
  %t477 = load i64, ptr %l25, !tbaa !24
  %t478 = load i64, ptr %l29, !tbaa !24
  %t479 = load i64, ptr %l27, !tbaa !24
  %t482 = mul i64 %t478, %t479
  %t485 = add i64 %t477, %t482
  store i64 %t485, ptr %l30, !tbaa !24
  store ptr %l24, ptr %l273, !tbaa !29
  %t487 = load i64, ptr %l30, !tbaa !24
  store i64 %t487, ptr %l274, !tbaa !24
  %t488 = load ptr, ptr %l0, !tbaa !29
  store ptr %t488, ptr %l275, !tbaa !29
  %t489 = load i64, ptr %l30, !tbaa !24
  %t492 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l24, i64 %t489)
  store i64 %t492, ptr %l278
  br label %bb142
bb142:
  %t493 = load i64, ptr %l30, !tbaa !24
  %t496 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l22, i64 %t493)
  store i64 %t496, ptr %l281
  br label %bb143
bb143:
  %t497 = load ptr, ptr %l275, !tbaa !29
  %t498 = load i64, ptr %l278, !tbaa !24
  %t499 = load i64, ptr %l281, !tbaa !24
  %t500 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t497, i64 %t498, i64 %t499)
  store i64 %t500, ptr %l282
  br label %bb144
bb144:
  %t501 = load ptr, ptr %l273, !tbaa !29
  %t502 = load i64, ptr %l274, !tbaa !24
  %t503 = load i64, ptr %l282, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s18, ptr %t501, i64 %t502, i64 %t503)
  br label %bb145
bb145:
  br label %bb146
bb146:
  %t504 = load i64, ptr %l29, !tbaa !24
  %t507 = add i64 %t504, 1
  store i64 %t507, ptr %l29, !tbaa !24
  br label %bb138
bb147:
  store ptr %l24, ptr %l286, !tbaa !29
  %t510 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %l22)
  store i64 %t510, ptr %l288
  br label %bb148
bb148:
  %t511 = load i64, ptr %l288, !tbaa !24
  %t512 = sub i64 %t511, 1
  store i64 %t512, ptr %l289, !tbaa !24
  store ptr %l22, ptr %l290, !tbaa !29
  %t514 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %l22)
  store i64 %t514, ptr %l292
  br label %bb149
bb149:
  %t515 = load i64, ptr %l292, !tbaa !24
  %t516 = sub i64 %t515, 1
  %t517 = load ptr, ptr %l290, !tbaa !29
  %t519 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %t517, i64 %t516)
  store i64 %t519, ptr %l294
  br label %bb150
bb150:
  %t520 = load ptr, ptr %l286, !tbaa !29
  %t521 = load i64, ptr %l289, !tbaa !24
  %t522 = load i64, ptr %l294, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s18, ptr %t520, i64 %t521, i64 %t522)
  br label %bb151
bb151:
  %t523 = load i64, ptr %l23, !tbaa !24
  store i64 %t523, ptr %l31, !tbaa !24
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t527 = getelementptr %"compiler/typed:Versions", ptr %t525, i32 0, i32 15
  %t529 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t527)
  store i64 %t529, ptr %l298
  br label %bb152
bb152:
  %t530 = load i64, ptr %l298, !tbaa !24
  store i64 %t530, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t531 = load i64, ptr %l32, !tbaa !24
  %t532 = load i64, ptr %l31, !tbaa !24
  %t535 = icmp sgt i64 %t531, %t532
  br i1 %t535, label %bb153, label %bb154
bb153:
  %t537 = load i64, ptr %l33, !tbaa !24
  %t539 = icmp sgt i64 %t537, 0
  br i1 %t539, label %bb155, label %bb156
bb154:
  store i64 0, ptr %l302, !tbaa !24
  br label %bb158
bb155:
  %t541 = load i64, ptr %l32, !tbaa !24
  %t542 = load i64, ptr %l31, !tbaa !24
  %t545 = sub i64 %t541, %t542
  %t546 = load i64, ptr %l33, !tbaa !24
  %t549 = add i64 %t545, %t546
  %t551 = sub i64 %t549, 1
  %t552 = load i64, ptr %l33, !tbaa !24
  %t555 = sdiv i64 %t551, %t552
  store i64 %t555, ptr %l305, !tbaa !24
  br label %bb157
bb156:
  store i64 0, ptr %l305, !tbaa !24
  br label %bb157
bb157:
  %t557 = load i64, ptr %l305, !tbaa !24
  store i64 %t557, ptr %l302, !tbaa !24
  br label %bb158
bb158:
  %t558 = load i64, ptr %l302, !tbaa !24
  store i64 %t558, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb159
bb159:
  %t559 = load i64, ptr %l35, !tbaa !24
  %t560 = load i64, ptr %l34, !tbaa !24
  %t563 = icmp slt i64 %t559, %t560
  %t565 = xor i1 %t563, true
  br i1 %t565, label %bb160, label %bb161
bb160:
  br label %bb169
bb161:
  br label %bb162
bb162:
  %t567 = load i64, ptr %l31, !tbaa !24
  %t568 = load i64, ptr %l35, !tbaa !24
  %t569 = load i64, ptr %l33, !tbaa !24
  %t572 = mul i64 %t568, %t569
  %t575 = add i64 %t567, %t572
  store i64 %t575, ptr %l36, !tbaa !24
  store ptr %l24, ptr %l323, !tbaa !29
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t579 = getelementptr %"compiler/typed:Versions", ptr %t577, i32 0, i32 15
  %t580 = load i64, ptr %l36, !tbaa !24
  %t583 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t579, i64 %t580)
  store i64 %t583, ptr %l327
  br label %bb163
bb163:
  %t584 = load ptr, ptr %l0, !tbaa !29
  store ptr %t584, ptr %l328, !tbaa !29
  store ptr %l24, ptr %l329, !tbaa !29
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t587 = getelementptr %"compiler/typed:Versions", ptr %t585, i32 0, i32 15
  %t588 = load i64, ptr %l36, !tbaa !24
  %t591 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t587, i64 %t588)
  store i64 %t591, ptr %l333
  br label %bb164
bb164:
  %t592 = load ptr, ptr %l329, !tbaa !29
  %t593 = load i64, ptr %l333, !tbaa !24
  %t594 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %t592, i64 %t593)
  store i64 %t594, ptr %l334
  br label %bb165
bb165:
  %t595 = load ptr, ptr %l328, !tbaa !29
  %t596 = load i64, ptr %l334, !tbaa !24
  %t597 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t595, i64 %t596, i64 -1)
  store i64 %t597, ptr %l335
  br label %bb166
bb166:
  %t598 = load ptr, ptr %l323, !tbaa !29
  %t599 = load i64, ptr %l327, !tbaa !24
  %t600 = load i64, ptr %l335, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s18, ptr %t598, i64 %t599, i64 %t600)
  br label %bb167
bb167:
  br label %bb168
bb168:
  %t601 = load i64, ptr %l35, !tbaa !24
  %t604 = add i64 %t601, 1
  store i64 %t604, ptr %l35, !tbaa !24
  br label %bb159
bb169:
  br label %bb170
bb170:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load ptr, ptr %l21, !tbaa !29
  %t609 = getelementptr %"compiler/typed:Try", ptr %t607, i32 0, i32 1
  %t610 = load { i64, ptr }, ptr %t609, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclauses(ptr %v0, ptr %v1, ptr %s18, ptr %t606, { i64, ptr } %t610, ptr %l24, i1 false)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s18)
  br label %bb222
bb172:
  %t614 = load ptr, ptr %l1, !tbaa !29
  store ptr %t614, ptr %l343, !tbaa !29
  store i1 false, ptr %l344, !tbaa !21
  %t615 = load ptr, ptr %l343, !tbaa !29
  %t616 = icmp ne ptr %t615, null
  br i1 %t616, label %bb173, label %bb174
bb173:
  %t618 = load ptr, ptr %l343, !tbaa !29
  %t619 = load i64, ptr %t618, !range !{i64 0, i64 18}
  %t621 = icmp eq i64 %t619, 15
  store i1 %t621, ptr %l344, !tbaa !21
  br label %bb174
bb174:
  %t622 = load i1, ptr %l344, !tbaa !21
  br i1 %t622, label %bb175, label %bb176
bb175:
  %t623 = load ptr, ptr %l1, !tbaa !29
  %t625 = getelementptr { i64, [5 x i64] }, ptr %t623, i32 0, i32 1
  %t626 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t625, i32 0, i32 2
  %t627 = load ptr, ptr %t626
  store ptr %t627, ptr %l37, !tbaa !29
  br label %bb177
bb176:
  br label %bb196
bb177:
  %t629 = load ptr, ptr %l37, !tbaa !29
  store ptr %t629, ptr %l349, !tbaa !29
  store i1 false, ptr %l350, !tbaa !21
  %t630 = load ptr, ptr %l349, !tbaa !29
  %t631 = icmp ne ptr %t630, null
  br i1 %t631, label %bb178, label %bb179
bb178:
  %t633 = load ptr, ptr %l349, !tbaa !29
  %t634 = load i64, ptr %t633, !range !{i64 0, i64 3}
  %t636 = icmp eq i64 %t634, 1
  store i1 %t636, ptr %l350, !tbaa !21
  br label %bb179
bb179:
  %t637 = load i1, ptr %l350, !tbaa !21
  br i1 %t637, label %bb180, label %bb181
bb180:
  %t638 = load ptr, ptr %l37, !tbaa !29
  %t640 = getelementptr { i64, [4 x i64] }, ptr %t638, i32 0, i32 1
  %t641 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t640, i32 0, i32 0
  %t642 = load i32, ptr %t641
  store i32 %t642, ptr %l38, !tbaa !23
  %t644 = load ptr, ptr %l37, !tbaa !29
  %t646 = getelementptr { i64, [4 x i64] }, ptr %t644, i32 0, i32 1
  %t647 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t646, i32 0, i32 1
  %t648 = load { i64, ptr }, ptr %t647
  %t650 = load ptr, ptr %l37, !tbaa !29
  %t652 = getelementptr { i64, [4 x i64] }, ptr %t650, i32 0, i32 1
  %t653 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t652, i32 0, i32 2
  %t654 = load i32, ptr %t653
  store i32 %t654, ptr %l40, !tbaa !23
  store { i64, ptr } %t648, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t658 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t660 = extractvalue { i64, ptr } %t658, 0
  store i64 %t660, ptr %l43, !tbaa !24
  br label %bb182
bb181:
  br label %bb189
bb182:
  %t662 = load i64, ptr %l42, !tbaa !24
  %t663 = load i64, ptr %l43, !tbaa !24
  %t666 = icmp slt i64 %t662, %t663
  %t668 = xor i1 %t666, true
  br i1 %t668, label %bb183, label %bb184
bb183:
  br label %bb188
bb184:
  br label %bb185
bb185:
  %t670 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t670, ptr %l366, !tbaa !27
  %t671 = load i64, ptr %l42, !tbaa !24
  %t673 = getelementptr { i64, ptr }, ptr %l366, i32 0, i32 1
  %t674 = load ptr, ptr %t673, !tbaa !27
  %t675 = getelementptr ptr, ptr %t674, i64 %t671
  %t676 = load ptr, ptr %t675, !tbaa !39
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t681 = getelementptr %"compiler/typed:Capture", ptr %t676, i32 0, i32 1
  %t682 = load ptr, ptr %t681, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t678, ptr %t682)
  br label %bb186
bb186:
  br label %bb187
bb187:
  %t686 = load i64, ptr %l42, !tbaa !24
  %t689 = add i64 %t686, 1
  store i64 %t689, ptr %l42, !tbaa !24
  br label %bb182
bb188:
  br label %bb189
bb189:
  %t691 = load ptr, ptr %l37, !tbaa !29
  store ptr %t691, ptr %l376, !tbaa !29
  store i1 false, ptr %l377, !tbaa !21
  %t692 = load ptr, ptr %l376, !tbaa !29
  %t693 = icmp ne ptr %t692, null
  br i1 %t693, label %bb190, label %bb191
bb190:
  %t695 = load ptr, ptr %l376, !tbaa !29
  %t696 = load i64, ptr %t695, !range !{i64 0, i64 3}
  %t698 = icmp eq i64 %t696, 2
  store i1 %t698, ptr %l377, !tbaa !21
  br label %bb191
bb191:
  %t699 = load i1, ptr %l377, !tbaa !21
  br i1 %t699, label %bb192, label %bb193
bb192:
  %t700 = load ptr, ptr %l37, !tbaa !29
  %t702 = getelementptr { i64, [4 x i64] }, ptr %t700, i32 0, i32 1
  %t703 = getelementptr { i32, ptr, i32 }, ptr %t702, i32 0, i32 0
  %t704 = load i32, ptr %t703
  store i32 %t704, ptr %l45, !tbaa !23
  %t706 = load ptr, ptr %l37, !tbaa !29
  %t708 = getelementptr { i64, [4 x i64] }, ptr %t706, i32 0, i32 1
  %t709 = getelementptr { i32, ptr, i32 }, ptr %t708, i32 0, i32 1
  %t710 = load ptr, ptr %t709
  %t712 = load ptr, ptr %l37, !tbaa !29
  %t714 = getelementptr { i64, [4 x i64] }, ptr %t712, i32 0, i32 1
  %t715 = getelementptr { i32, ptr, i32 }, ptr %t714, i32 0, i32 2
  %t716 = load i32, ptr %t715
  store i32 %t716, ptr %l47, !tbaa !23
  %t718 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t718, ptr %t710)
  br label %bb194
bb193:
  br label %bb195
bb194:
  br label %bb195
bb195:
  br label %bb222
bb196:
  %t723 = load ptr, ptr %l1, !tbaa !29
  store ptr %t723, ptr %l389, !tbaa !29
  store i1 false, ptr %l390, !tbaa !21
  %t724 = load ptr, ptr %l389, !tbaa !29
  %t725 = icmp ne ptr %t724, null
  br i1 %t725, label %bb197, label %bb198
bb197:
  %t727 = load ptr, ptr %l389, !tbaa !29
  %t728 = load i64, ptr %t727, !range !{i64 0, i64 18}
  %t730 = icmp eq i64 %t728, 16
  store i1 %t730, ptr %l390, !tbaa !21
  br label %bb198
bb198:
  %t731 = load i1, ptr %l390, !tbaa !21
  br i1 %t731, label %bb199, label %bb200
bb199:
  %t732 = load ptr, ptr %l1, !tbaa !29
  %t734 = getelementptr { i64, [5 x i64] }, ptr %t732, i32 0, i32 1
  %t735 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t734, i32 0, i32 2
  %t736 = load ptr, ptr %t735
  store ptr %t736, ptr %l48, !tbaa !29
  br label %bb201
bb200:
  br label %bb214
bb201:
  %t738 = load ptr, ptr %l48, !tbaa !29
  %t740 = getelementptr %"compiler/typed:Text", ptr %t738, i32 0, i32 0
  %t741 = load { i64, ptr }, ptr %t740, !tbaa !27
  store { i64, ptr } %t741, ptr %l49, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  %t743 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t745 = extractvalue { i64, ptr } %t743, 0
  store i64 %t745, ptr %l51, !tbaa !24
  br label %bb202
bb202:
  %t747 = load i64, ptr %l50, !tbaa !24
  %t748 = load i64, ptr %l51, !tbaa !24
  %t751 = icmp slt i64 %t747, %t748
  %t753 = xor i1 %t751, true
  br i1 %t753, label %bb203, label %bb204
bb203:
  br label %bb213
bb204:
  br label %bb205
bb205:
  %t755 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t755, ptr %l403, !tbaa !27
  %t756 = load i64, ptr %l50, !tbaa !24
  %t758 = getelementptr { i64, ptr }, ptr %l403, i32 0, i32 1
  %t759 = load ptr, ptr %t758, !tbaa !27
  %t760 = getelementptr ptr, ptr %t759, i64 %t756
  %t761 = load ptr, ptr %t760, !tbaa !39
  store ptr %t761, ptr %l52, !tbaa !29
  %t763 = load ptr, ptr %l52, !tbaa !29
  store ptr %t763, ptr %l406, !tbaa !29
  store i1 false, ptr %l407, !tbaa !21
  %t764 = load ptr, ptr %l406, !tbaa !29
  %t765 = icmp ne ptr %t764, null
  br i1 %t765, label %bb206, label %bb207
bb206:
  %t767 = load ptr, ptr %l406, !tbaa !29
  %t768 = load i64, ptr %t767, !range !{i64 0, i64 2}
  %t770 = icmp eq i64 %t768, 1
  store i1 %t770, ptr %l407, !tbaa !21
  br label %bb207
bb207:
  %t771 = load i1, ptr %l407, !tbaa !21
  br i1 %t771, label %bb208, label %bb209
bb208:
  %t772 = load ptr, ptr %l52, !tbaa !29
  %t774 = getelementptr { i64, [2 x i64] }, ptr %t772, i32 0, i32 1
  %t775 = getelementptr { ptr }, ptr %t774, i32 0, i32 0
  %t776 = load ptr, ptr %t775
  %t778 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t778, ptr %t776)
  br label %bb210
bb209:
  br label %bb211
bb210:
  br label %bb211
bb211:
  br label %bb212
bb212:
  %t783 = load i64, ptr %l50, !tbaa !24
  %t786 = add i64 %t783, 1
  store i64 %t786, ptr %l50, !tbaa !24
  br label %bb202
bb213:
  br label %bb222
bb214:
  %t788 = load ptr, ptr %l1, !tbaa !29
  store ptr %t788, ptr %l418, !tbaa !29
  store i1 false, ptr %l419, !tbaa !21
  %t789 = load ptr, ptr %l418, !tbaa !29
  %t790 = icmp ne ptr %t789, null
  br i1 %t790, label %bb215, label %bb216
bb215:
  %t792 = load ptr, ptr %l418, !tbaa !29
  %t793 = load i64, ptr %t792, !range !{i64 0, i64 18}
  %t795 = icmp eq i64 %t793, 17
  store i1 %t795, ptr %l419, !tbaa !21
  br label %bb216
bb216:
  %t796 = load i1, ptr %l419, !tbaa !21
  br i1 %t796, label %bb217, label %bb218
bb217:
  %t797 = load ptr, ptr %l1, !tbaa !29
  %t799 = getelementptr { i64, [5 x i64] }, ptr %t797, i32 0, i32 1
  %t800 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t799, i32 0, i32 2
  %t801 = load ptr, ptr %t800
  store ptr %t801, ptr %l54, !tbaa !29
  br label %bb219
bb218:
  br label %bb221
bb219:
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t804 = load ptr, ptr %l54, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t803, ptr %t804)
  br label %bb220
bb220:
  br label %bb222
bb221:
  call void @__olang_check_failed(ptr @olang_loc_77315c1e1ec03e98_be22ee0dd90c53a4)
  unreachable
bb222:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esettle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l80 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i64
  %l106 = alloca { i64, ptr }
  %l109 = alloca i64
  %l111 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l117 = alloca i64
  %l120 = alloca i32
  %l123 = alloca ptr
  %l126 = alloca i1
  %l132 = alloca i64
  %l136 = alloca i64
  %l139 = alloca i64
  %l160 = alloca i64
  %l164 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i64
  %l169 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l170 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca i32
  %l183 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 3
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l21
  %t6 = call ptr @__olang_scope_hold(ptr %s0)
  %t7 = ptrtoint ptr %t6 to i64
  store i64 %t7, ptr %l22, !tbaa !24
  %t8 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = call ptr @__olang_region_make_part(ptr %s0)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l22, !tbaa !24
  br label %bb2
bb2:
  %t12 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l24, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l25, !tbaa !24
  %t16 = load i64, ptr %l25, !tbaa !24
  %t17 = mul i64 %t16, 8
  %t18 = load i64, ptr %l22
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  %t21 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l26, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l25, !tbaa !24
  %t28 = mul i64 %t27, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  %t29 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t30 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21, i32 0, i32 0
  store { i64, ptr } %t29, ptr %t30, !tbaa !27
  %t31 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t31, label %bb3, label %bb4
bb3:
  %t33 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t37 = icmp eq i64 %t35, 0
  br i1 %t37, label %bb5, label %bb6
bb4:
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l1
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Versions", ptr %t40, i32 0, i32 4
  %t43 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l32
  %t45 = call ptr @__olang_scope_hold(ptr %s0)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l33, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2e0
  br i1 %t47, label %bb7, label %bb8
bb5:
  %t49 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t49, !tbaa !27
  br label %bb6
bb6:
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21, i32 0, i32 0
  %t51 = load i64, ptr %l22
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = load { i64, ptr }, ptr %t50
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = call ptr @__olang_region_or(ptr %t54, ptr null)
  %t56 = icmp ne ptr %t55, null
  %t57 = select i1 %t56, ptr %t55, ptr null
  call void @__olang_region_settle_in(ptr %t52, ptr %t57)
  br label %bb4
bb7:
  %t58 = call ptr @__olang_region_make_part(ptr %s0)
  %t59 = ptrtoint ptr %t58 to i64
  store i64 %t59, ptr %l33, !tbaa !24
  br label %bb8
bb8:
  %t60 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l35, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load i64, ptr %l36, !tbaa !24
  %t65 = mul i64 %t64, 8
  %t66 = load i64, ptr %l33
  %t67 = inttoptr i64 %t66 to ptr
  %t68 = call ptr @__olang_held_alloc(ptr %t67, i64 %t65)
  %t69 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  store { i64, ptr } %t70, ptr %l37, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l36, !tbaa !24
  %t76 = mul i64 %t75, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t72, ptr %t74, i64 %t76, i1 false)
  %t77 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t78 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32, i32 0, i32 0
  store { i64, ptr } %t77, ptr %t78, !tbaa !27
  %t79 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2e0
  br i1 %t79, label %bb9, label %bb10
bb9:
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  %t85 = icmp eq i64 %t83, 0
  br i1 %t85, label %bb11, label %bb12
bb10:
  %t87 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l2
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Versions", ptr %t88, i32 0, i32 5
  %t91 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t90
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %l43
  %t93 = call ptr @__olang_scope_hold(ptr %s0)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l44, !tbaa !24
  %t95 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2e0
  br i1 %t95, label %bb13, label %bb14
bb11:
  %t97 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t97, !tbaa !27
  br label %bb12
bb12:
  %t98 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32, i32 0, i32 0
  %t99 = load i64, ptr %l33
  %t100 = inttoptr i64 %t99 to ptr
  %t101 = load { i64, ptr }, ptr %t98
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = call ptr @__olang_region_or(ptr %t102, ptr null)
  %t104 = icmp ne ptr %t103, null
  %t105 = select i1 %t104, ptr %t103, ptr null
  call void @__olang_region_settle_in(ptr %t100, ptr %t105)
  br label %bb10
bb13:
  %t106 = call ptr @__olang_region_make_part(ptr %s0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l44, !tbaa !24
  br label %bb14
bb14:
  %t108 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l46, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %l47, !tbaa !24
  %t112 = load i64, ptr %l47, !tbaa !24
  %t113 = mul i64 %t112, 4
  %t114 = load i64, ptr %l44
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = call ptr @__olang_held_alloc(ptr %t115, i64 %t113)
  %t117 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l48, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = load i64, ptr %l47, !tbaa !24
  %t124 = mul i64 %t123, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t120, ptr %t122, i64 %t124, i1 false)
  %t125 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t126 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  store { i64, ptr } %t125, ptr %t126, !tbaa !27
  %t127 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2e0
  br i1 %t127, label %bb15, label %bb16
bb15:
  %t129 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  %t133 = icmp eq i64 %t131, 0
  br i1 %t133, label %bb17, label %bb18
bb16:
  %t135 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t135, ptr %l3
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Versions", ptr %t136, i32 0, i32 6
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t138
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %l53
  %t141 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %s0, ptr %l53)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t141, ptr %l55
  br label %bb19
bb17:
  %t142 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t142, !tbaa !27
  br label %bb18
bb18:
  %t143 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  %t144 = load i64, ptr %l44
  %t145 = inttoptr i64 %t144 to ptr
  %t146 = load { i64, ptr }, ptr %t143
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = call ptr @__olang_region_or(ptr %t147, ptr null)
  %t149 = icmp ne ptr %t148, null
  %t150 = select i1 %t149, ptr %t148, ptr null
  call void @__olang_region_settle_in(ptr %t145, ptr %t150)
  br label %bb16
bb19:
  %t151 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l4
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Versions", ptr %t152, i32 0, i32 7
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %l58
  %t157 = call ptr @__olang_scope_hold(ptr %s0)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l59, !tbaa !24
  %t159 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0
  br i1 %t159, label %bb20, label %bb21
bb20:
  %t161 = call ptr @__olang_region_make_part(ptr %s0)
  %t162 = ptrtoint ptr %t161 to i64
  store i64 %t162, ptr %l59, !tbaa !24
  br label %bb21
bb21:
  %t163 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58, i32 0, i32 0
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  store { i64, ptr } %t164, ptr %l61, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 0
  store i64 %t166, ptr %l62, !tbaa !24
  %t167 = load i64, ptr %l62, !tbaa !24
  %t168 = mul i64 %t167, 1
  %t169 = load i64, ptr %l59
  %t170 = inttoptr i64 %t169 to ptr
  %t171 = call ptr @__olang_held_alloc(ptr %t170, i64 %t168)
  %t172 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  store { i64, ptr } %t173, ptr %l63, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = load i64, ptr %l62, !tbaa !24
  %t179 = mul i64 %t178, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t175, ptr %t177, i64 %t179, i1 false)
  %t180 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t181 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58, i32 0, i32 0
  store { i64, ptr } %t180, ptr %t181, !tbaa !27
  %t182 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0
  br i1 %t182, label %bb22, label %bb23
bb22:
  %t184 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t188 = icmp eq i64 %t186, 0
  br i1 %t188, label %bb24, label %bb25
bb23:
  %t190 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t190, ptr %l5
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Versions", ptr %t191, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t193)
  br label %bb26
bb24:
  %t195 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t195, !tbaa !27
  br label %bb25
bb25:
  %t196 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58, i32 0, i32 0
  %t197 = load i64, ptr %l59
  %t198 = inttoptr i64 %t197 to ptr
  %t199 = load { i64, ptr }, ptr %t196
  %t200 = extractvalue { i64, ptr } %t199, 1
  %t201 = call ptr @__olang_region_or(ptr %t200, ptr null)
  %t202 = icmp ne ptr %t201, null
  %t203 = select i1 %t202, ptr %t201, ptr null
  call void @__olang_region_settle_in(ptr %t198, ptr %t203)
  br label %bb23
bb26:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/typed:Versions", ptr %t204, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t206)
  br label %bb27
bb27:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Versions", ptr %t208, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t210)
  br label %bb28
bb28:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/typed:Versions", ptr %t212, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eCle_H9e31dbf06df58c38226424712d120dfe(ptr %v0, ptr %t214)
  br label %bb29
bb29:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Versions", ptr %t216, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t218)
  br label %bb30
bb30:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Versions", ptr %t220, i32 0, i32 8
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t222)
  br label %bb31
bb31:
  store i64 0, ptr %l6, !tbaa !24
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l1)
  store i64 %t225, ptr %l80
  br label %bb32
bb32:
  %t226 = load i64, ptr %l80, !tbaa !24
  store i64 %t226, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t227 = load i64, ptr %l7, !tbaa !24
  %t228 = load i64, ptr %l6, !tbaa !24
  %t231 = icmp sgt i64 %t227, %t228
  br i1 %t231, label %bb33, label %bb34
bb33:
  %t233 = load i64, ptr %l8, !tbaa !24
  %t235 = icmp sgt i64 %t233, 0
  br i1 %t235, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb38
bb35:
  %t237 = load i64, ptr %l7, !tbaa !24
  %t238 = load i64, ptr %l6, !tbaa !24
  %t241 = sub i64 %t237, %t238
  %t242 = load i64, ptr %l8, !tbaa !24
  %t245 = add i64 %t241, %t242
  %t247 = sub i64 %t245, 1
  %t248 = load i64, ptr %l8, !tbaa !24
  %t251 = sdiv i64 %t247, %t248
  store i64 %t251, ptr %l87, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb37
bb37:
  %t253 = load i64, ptr %l87, !tbaa !24
  store i64 %t253, ptr %l84, !tbaa !24
  br label %bb38
bb38:
  %t254 = load i64, ptr %l84, !tbaa !24
  store i64 %t254, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb39
bb39:
  %t255 = load i64, ptr %l10, !tbaa !24
  %t256 = load i64, ptr %l9, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb40, label %bb41
bb40:
  br label %bb54
bb41:
  br label %bb42
bb42:
  %t263 = load i64, ptr %l6, !tbaa !24
  %t264 = load i64, ptr %l10, !tbaa !24
  %t265 = load i64, ptr %l8, !tbaa !24
  %t268 = mul i64 %t264, %t265
  %t271 = add i64 %t263, %t268
  store i64 %t271, ptr %l11, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/typed:Versions", ptr %t273, i32 0, i32 2
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  store { i64, ptr } %t276, ptr %l106, !tbaa !27
  %t277 = load i64, ptr %l11, !tbaa !24
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l1, i64 %t277)
  store i64 %t280, ptr %l109
  br label %bb43
bb43:
  %t281 = load i64, ptr %l109, !tbaa !24
  %t282 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr i1, ptr %t283, i64 %t281
  %t285 = load i1, ptr %t284, !tbaa !31
  br i1 %t285, label %bb44, label %bb45
bb44:
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l111, !tbaa !29
  %t288 = load i64, ptr %l11, !tbaa !24
  %t291 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l2, i64 %t288)
  store %"compiler/source:Span" %t291, ptr %l114
  br label %bb46
bb45:
  br label %bb52
bb46:
  %t292 = load i64, ptr %l11, !tbaa !24
  %t295 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l1, i64 %t292)
  store i64 %t295, ptr %l117
  br label %bb47
bb47:
  %t296 = load i64, ptr %l11, !tbaa !24
  %t299 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %s0, ptr %l3, i64 %t296)
  store i32 %t299, ptr %l120
  br label %bb48
bb48:
  %t300 = load i64, ptr %l11, !tbaa !24
  %t303 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v0, ptr %l4, i64 %t300)
  store ptr %t303, ptr %l123
  br label %bb49
bb49:
  %t304 = load i64, ptr %l11, !tbaa !24
  %t307 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %l5, i64 %t304)
  store i1 %t307, ptr %l126
  br label %bb50
bb50:
  %t308 = load ptr, ptr %l111, !tbaa !29
  %t309 = load %"compiler/source:Span", ptr %l114
  %t310 = load i64, ptr %l117, !tbaa !24
  %t311 = load i32, ptr %l120, !tbaa !23
  %t312 = load ptr, ptr %l123, !tbaa !29
  %t313 = load i1, ptr %l126, !tbaa !21
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eaddDef(ptr %v0, ptr %v0, ptr %t308, %"compiler/source:Span" %t309, i64 %t310, i32 %t311, ptr %t312, i1 %t313)
  br label %bb51
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t314 = load i64, ptr %l10, !tbaa !24
  %t317 = add i64 %t314, 1
  store i64 %t317, ptr %l10, !tbaa !24
  br label %bb39
bb54:
  store i64 0, ptr %l12, !tbaa !24
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Versions", ptr %t319, i32 0, i32 3
  %t323 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t321)
  store i64 %t323, ptr %l132
  br label %bb55
bb55:
  %t324 = load i64, ptr %l132, !tbaa !24
  store i64 %t324, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t325 = load i64, ptr %l13, !tbaa !24
  %t326 = load i64, ptr %l12, !tbaa !24
  %t329 = icmp sgt i64 %t325, %t326
  br i1 %t329, label %bb56, label %bb57
bb56:
  %t331 = load i64, ptr %l14, !tbaa !24
  %t333 = icmp sgt i64 %t331, 0
  br i1 %t333, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb61
bb58:
  %t335 = load i64, ptr %l13, !tbaa !24
  %t336 = load i64, ptr %l12, !tbaa !24
  %t339 = sub i64 %t335, %t336
  %t340 = load i64, ptr %l14, !tbaa !24
  %t343 = add i64 %t339, %t340
  %t345 = sub i64 %t343, 1
  %t346 = load i64, ptr %l14, !tbaa !24
  %t349 = sdiv i64 %t345, %t346
  store i64 %t349, ptr %l139, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l139, !tbaa !24
  br label %bb60
bb60:
  %t351 = load i64, ptr %l139, !tbaa !24
  store i64 %t351, ptr %l136, !tbaa !24
  br label %bb61
bb61:
  %t352 = load i64, ptr %l136, !tbaa !24
  store i64 %t352, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb62
bb62:
  %t353 = load i64, ptr %l16, !tbaa !24
  %t354 = load i64, ptr %l15, !tbaa !24
  %t357 = icmp slt i64 %t353, %t354
  %t359 = xor i1 %t357, true
  br i1 %t359, label %bb63, label %bb64
bb63:
  br label %bb80
bb64:
  br label %bb65
bb65:
  %t361 = load i64, ptr %l12, !tbaa !24
  %t362 = load i64, ptr %l16, !tbaa !24
  %t363 = load i64, ptr %l14, !tbaa !24
  %t366 = mul i64 %t362, %t363
  %t369 = add i64 %t361, %t366
  store i64 %t369, ptr %l17, !tbaa !24
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/typed:Versions", ptr %t371, i32 0, i32 3
  %t374 = load i64, ptr %l17, !tbaa !24
  %t377 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t373, i64 %t374)
  store i64 %t377, ptr %l160
  br label %bb66
bb66:
  %t378 = load i64, ptr %l160, !tbaa !24
  store i64 %t378, ptr %l18, !tbaa !24
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/typed:Versions", ptr %t379, i32 0, i32 9
  %t382 = load i64, ptr %l18, !tbaa !24
  %t385 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t381, i64 %t382)
  store i1 %t385, ptr %l164
  br label %bb67
bb67:
  %t386 = load i1, ptr %l164, !tbaa !21
  %t387 = xor i1 %t386, true
  br i1 %t387, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s7
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/typed:Versions", ptr %t389, i32 0, i32 9
  store ptr %t391, ptr %l167, !tbaa !29
  %t392 = load i64, ptr %l18, !tbaa !24
  store i64 %t392, ptr %l168, !tbaa !24
  %t393 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t393, ptr %l169
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t394 = load ptr, ptr %l167, !tbaa !29
  %t395 = load i64, ptr %l168, !tbaa !24
  %t396 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l169
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %s7, ptr %t394, i64 %t395, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t396)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s7)
  br label %bb72
bb72:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Versions", ptr %t397, i32 0, i32 9
  %t400 = load i64, ptr %l18, !tbaa !24
  %t403 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hdc84c10e1af960a666eeb267120f3ec3(ptr %v0, ptr %v0, ptr %t399, i64 %t400)
  %t404 = extractvalue { i32, ptr } %t403, 1
  %t405 = extractvalue { i32, ptr } %t403, 0
  store i32 %t405, ptr %l175
  %t406 = icmp ne i32 %t405, 0
  br i1 %t406, label %bb74, label %ok.407, !prof !99
ok.407:
  store ptr %t404, ptr %l174
  br label %bb73
bb73:
  %t408 = load ptr, ptr %l174, !tbaa !29
  store ptr %t408, ptr %l170, !tbaa !29
  br label %bb77
bb74:
  %t409 = load i32, ptr %l175, !tbaa !23
  %t410 = icmp eq i32 %t409, 65536
  br i1 %t410, label %bb75, label %bb76
bb75:
  call void @__olang_bang_failed_plain(ptr @olang_loc_59830ee0ec754a32_f5aff824d93b155e)
  unreachable
bb76:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b8ff85e818b1a126_11cf17c421c4721a)
  unreachable
bb77:
  %t412 = load i64, ptr %l17, !tbaa !24
  %t413 = load ptr, ptr %l170, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t413, i64 %t412)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t415 = load i64, ptr %l16, !tbaa !24
  %t418 = add i64 %t415, 1
  store i64 %t418, ptr %l16, !tbaa !24
  br label %bb62
bb80:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/typed:Versions", ptr %t420, i32 0, i32 3
  %t424 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t422)
  store i64 %t424, ptr %l183
  br label %bb81
bb81:
  %t425 = load i64, ptr %l183, !tbaa !24
  %t426 = icmp sgt i64 %t425, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t426, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca ptr
  %l15 = alloca i64
  %l24 = alloca { i64, ptr }
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i32
  %l50 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l58 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = getelementptr %"compiler/typed:dropWalk", ptr %t6, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = add i64 %t8, 1
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t14 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 4
  store i64 %t11, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:dropWalk", ptr %t15, i32 0, i32 5
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l15
  br label %bb4
bb4:
  %t20 = load i64, ptr %l15, !tbaa !24
  store i64 %t20, ptr %l2, !tbaa !24
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Block", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l24, !tbaa !27
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %t46, ptr %t44)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = add i64 %t50, 1
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb5
bb11:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/typed:dropWalk", ptr %t56, i32 0, i32 4
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = sub i64 %t59, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t55, i64 %t61)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:dropWalk", ptr %t64, i32 0, i32 5
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l38
  br label %bb14
bb14:
  %t69 = load i64, ptr %l2, !tbaa !24
  %t70 = load i64, ptr %l38, !tbaa !24
  %t72 = icmp sgt i64 %t70, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb15, label %bb16
bb15:
  br label %bb37
bb16:
  br label %bb17
bb17:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/typed:dropWalk", ptr %t76, i32 0, i32 5
  %t80 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t78)
  %t81 = extractvalue { i32, i64 } %t80, 1
  %t82 = extractvalue { i32, i64 } %t80, 0
  store i32 %t82, ptr %l46
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb19, label %ok.84, !prof !99
ok.84:
  store i64 %t81, ptr %l45
  br label %bb18
bb18:
  %t85 = load i64, ptr %l45, !tbaa !24
  store i64 %t85, ptr %l42, !tbaa !24
  br label %bb26
bb19:
  %t86 = load i32, ptr %l46, !tbaa !23
  %t87 = icmp eq i32 %t86, 65536
  br i1 %t87, label %bb20, label %bb21
bb20:
  call void @__olang_bang_failed_plain(ptr @olang_loc_17c315ca28f40c4c_14b80e258f8c2b0)
  unreachable
bb21:
  %t89 = load i32, ptr %l46, !tbaa !23
  %t90 = icmp eq i32 %t89, 65537
  br i1 %t90, label %bb22, label %bb23
bb22:
  call void @__olang_bang_failed_plain(ptr @olang_loc_db2d0e7e8bf65551_fc4da676f7c58ce5)
  unreachable
bb23:
  %t92 = load i32, ptr %l46, !tbaa !23
  %t93 = icmp eq i32 %t92, 65538
  br i1 %t93, label %bb24, label %bb25
bb24:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6fe9eb3ff5642bc1_33392e6f48613205)
  unreachable
bb25:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5f1ddc7ef7469727_e10177d23ca0510b)
  unreachable
bb26:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:dropWalk", ptr %t95, i32 0, i32 6
  %t99 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t97)
  %t100 = extractvalue { i32, i64 } %t99, 1
  %t101 = extractvalue { i32, i64 } %t99, 0
  store i32 %t101, ptr %l54
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb28, label %ok.103, !prof !99
ok.103:
  store i64 %t100, ptr %l53
  br label %bb27
bb27:
  %t104 = load i64, ptr %l53, !tbaa !24
  store i64 %t104, ptr %l50, !tbaa !24
  br label %bb35
bb28:
  %t105 = load i32, ptr %l54, !tbaa !23
  %t106 = icmp eq i32 %t105, 65536
  br i1 %t106, label %bb29, label %bb30
bb29:
  call void @__olang_bang_failed_plain(ptr @olang_loc_24a3ccdd47c97c70_8558c77bc7af118c)
  unreachable
bb30:
  %t108 = load i32, ptr %l54, !tbaa !23
  %t109 = icmp eq i32 %t108, 65537
  br i1 %t109, label %bb31, label %bb32
bb31:
  call void @__olang_bang_failed_plain(ptr @olang_loc_130a89b2782f12a5_38e9334e27b56d91)
  unreachable
bb32:
  %t111 = load i32, ptr %l54, !tbaa !23
  %t112 = icmp eq i32 %t111, 65538
  br i1 %t112, label %bb33, label %bb34
bb33:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1916e27cc0da8fc5_b948d7408e366d01)
  unreachable
bb34:
  call void @__olang_bang_failed_plain(ptr @olang_loc_567e5689d7ac5ccb_d57870be630e767)
  unreachable
bb35:
  br label %bb36
bb36:
  br label %bb13
bb37:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l58, !tbaa !29
  %t115 = load ptr, ptr %l58, !tbaa !29
  %t116 = getelementptr %"compiler/typed:dropWalk", ptr %t115, i32 0, i32 4
  %t117 = load i64, ptr %t116, !tbaa !24
  %t120 = sub i64 %t117, 1
  %t122 = load ptr, ptr %l58, !tbaa !29
  %t123 = getelementptr %"compiler/typed:dropWalk", ptr %t122, i32 0, i32 4
  store i64 %t120, ptr %t123, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca i1
  %l52 = alloca i1
  %l62 = alloca i1
  %l89 = alloca { i64, ptr }
  %l108 = alloca i64
  %l110 = alloca i64
  %l115 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t7 = load ptr, ptr %l27, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l27, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l28, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l28, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  br label %bb6
bb6:
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_5f0c96ba8f37c420_5ca612e1d5c707f4)
  unreachable
bb12:
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l36
  br label %bb13
bb13:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l4
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Call", ptr %t28, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb15, label %bb16
bb15:
  br label %bb39
bb16:
  br label %bb17
bb17:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t45, ptr %l45, !tbaa !27
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  store ptr %t51, ptr %l8, !tbaa !29
  %t53 = load ptr, ptr %l8, !tbaa !29
  store ptr %t53, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t54 = load ptr, ptr %l48, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l48, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 12
  store i1 %t60, ptr %l49, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l49, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l8, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  store %"compiler/source:Span" %t66, ptr %l9
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l10, !tbaa !23
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  %t83 = getelementptr %"compiler/typed:Seq", ptr %t78, i32 0, i32 2
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l52, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l52, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t87 = load ptr, ptr %l8, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l12
  %t93 = load ptr, ptr %l8, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 1
  %t97 = load i32, ptr %t96
  store i32 %t97, ptr %l13, !tbaa !23
  %t99 = load ptr, ptr %l8, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  %t108 = getelementptr %"compiler/typed:Seq", ptr %t103, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = icmp eq ptr %t109, null
  %t113 = xor i1 %t111, true
  store i1 %t113, ptr %l62, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb25
bb25:
  %t115 = load i1, ptr %l62, !tbaa !21
  br i1 %t115, label %bb26, label %bb27
bb26:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = getelementptr { i64, [5 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t118, i32 0, i32 0
  %t120 = load %"compiler/source:Span", ptr %t119
  store %"compiler/source:Span" %t120, ptr %l15
  %t122 = load ptr, ptr %l8, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 1
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l16, !tbaa !23
  %t128 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t130, i32 0, i32 2
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l17, !tbaa !29
  %t134 = load ptr, ptr %l17, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Seq", ptr %t134, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l20, !tbaa !24
  br label %bb28
bb27:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t144, ptr %t145)
  br label %bb36
bb28:
  %t149 = load i64, ptr %l19, !tbaa !24
  %t150 = load i64, ptr %l20, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb29, label %bb30
bb29:
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t157 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t157, ptr %l89, !tbaa !27
  %t158 = load i64, ptr %l19, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr ptr, ptr %t161, i64 %t158
  %t163 = load ptr, ptr %t162, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %s0, ptr %v1, ptr %l4, ptr %t163)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t168 = load i64, ptr %l19, !tbaa !24
  %t171 = add i64 %t168, 1
  store i64 %t171, ptr %l19, !tbaa !24
  br label %bb28
bb34:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l17, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Seq", ptr %t174, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t173, ptr %t178)
  br label %bb35
bb35:
  br label %bb37
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t181 = load i64, ptr %l6, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l6, !tbaa !24
  br label %bb14
bb39:
  store ptr %l4, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb40
bb40:
  %t187 = load i64, ptr %l23, !tbaa !24
  store i64 %t187, ptr %l108, !tbaa !24
  %t188 = load ptr, ptr %l22, !tbaa !29
  %t190 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %s0, ptr %t188)
  store i64 %t190, ptr %l110
  br label %bb41
bb41:
  %t191 = load i64, ptr %l108, !tbaa !24
  %t192 = load i64, ptr %l110, !tbaa !24
  %t193 = icmp slt i64 %t191, %t192
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb42, label %bb43
bb42:
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t197 = load ptr, ptr %l22, !tbaa !29
  %t198 = load i64, ptr %l23, !tbaa !24
  %t201 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %s0, ptr %s0, ptr %t197, i64 %t198)
  store ptr %t201, ptr %l115
  br label %bb45
bb45:
  %t202 = load ptr, ptr %l115, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %s0, ptr %t203, ptr %t202)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t207 = load i64, ptr %l23, !tbaa !24
  %t210 = add i64 %t207, 1
  store i64 %t210, ptr %l23, !tbaa !24
  br label %bb40
bb48:
  %t212 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t212, i1 false)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i32
  %l36 = alloca i32
  %l39 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l151 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l166 = alloca i1
  %l179 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l191 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca i1
  %l220 = alloca { i64, ptr }
  %l223 = alloca ptr
  %l224 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i1
  %l244 = alloca ptr
  %l245 = alloca i1
  %l250 = alloca ptr
  %l251 = alloca i1
  %l267 = alloca { i64, ptr }
  %l277 = alloca ptr
  %l278 = alloca i1
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:dropWalk", ptr %t5, i32 0, i32 3
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l39, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l39, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t12 = load ptr, ptr %l42, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l42, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 18}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l43, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l43, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t21 = load ptr, ptr %l46, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l46, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l47, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l47, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb169
bb16:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t30 = load ptr, ptr %l50, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb17, label %bb18
bb17:
  %t33 = load ptr, ptr %l50, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l51, !tbaa !21
  br label %bb18
bb18:
  %t37 = load i1, ptr %l51, !tbaa !21
  br i1 %t37, label %bb19, label %bb20
bb19:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb29
bb20:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t45 = load ptr, ptr %l56, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb21, label %bb22
bb21:
  %t48 = load ptr, ptr %l56, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 3
  store i1 %t51, ptr %l57, !tbaa !21
  br label %bb22
bb22:
  %t52 = load i1, ptr %l57, !tbaa !21
  br i1 %t52, label %bb23, label %bb24
bb23:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l2, !tbaa !29
  br label %bb29
bb24:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t60 = load ptr, ptr %l62, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb25, label %bb26
bb25:
  %t63 = load ptr, ptr %l62, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 18}
  %t66 = icmp eq i64 %t64, 4
  store i1 %t66, ptr %l63, !tbaa !21
  br label %bb26
bb26:
  %t67 = load i1, ptr %l63, !tbaa !21
  br i1 %t67, label %bb27, label %bb28
bb27:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l2, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  br label %bb30
bb30:
  br label %bb169
bb31:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t80 = load ptr, ptr %l71, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb32, label %bb33
bb32:
  %t83 = load ptr, ptr %l71, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 18}
  %t86 = icmp eq i64 %t84, 5
  store i1 %t86, ptr %l72, !tbaa !21
  br label %bb33
bb33:
  %t87 = load i1, ptr %l72, !tbaa !21
  br i1 %t87, label %bb34, label %bb35
bb34:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t90, i32 0, i32 2
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l3, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l3, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Promote", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t94, ptr %t98)
  br label %bb37
bb37:
  br label %bb169
bb38:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t103 = load ptr, ptr %l81, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb39, label %bb40
bb39:
  %t106 = load ptr, ptr %l81, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 18}
  %t109 = icmp eq i64 %t107, 6
  store i1 %t109, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t110 = load i1, ptr %l82, !tbaa !21
  br i1 %t110, label %bb41, label %bb42
bb41:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l4, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ecall(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  br label %bb44
bb44:
  br label %bb169
bb45:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t122 = load ptr, ptr %l89, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb46, label %bb47
bb46:
  %t125 = load ptr, ptr %l89, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 18}
  %t128 = icmp eq i64 %t126, 7
  store i1 %t128, ptr %l90, !tbaa !21
  br label %bb47
bb47:
  %t129 = load i1, ptr %l90, !tbaa !21
  br i1 %t129, label %bb48, label %bb49
bb48:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l5, !tbaa !29
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l5, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Make", ptr %t137, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t136, { i64, ptr } %t140)
  br label %bb51
bb51:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l5, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Make", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t143, ptr %t147)
  br label %bb52
bb52:
  br label %bb169
bb53:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t151 = load ptr, ptr %l101, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb54, label %bb55
bb54:
  %t154 = load ptr, ptr %l101, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 18}
  %t157 = icmp eq i64 %t155, 8
  store i1 %t157, ptr %l102, !tbaa !21
  br label %bb55
bb55:
  %t158 = load i1, ptr %l102, !tbaa !21
  br i1 %t158, label %bb56, label %bb57
bb56:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t161, i32 0, i32 2
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l6, !tbaa !29
  br label %bb58
bb57:
  br label %bb61
bb58:
  store %olang.scope zeroinitializer, ptr %s7
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l6, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Collect", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t165, ptr %t169)
  br label %bb59
bb59:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l6, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Collect", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %s7, ptr %t172, ptr %t176, ptr null)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s7)
  br label %bb169
bb61:
  %t179 = load ptr, ptr %l1, !tbaa !29
  store ptr %t179, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t180 = load ptr, ptr %l113, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb62, label %bb63
bb62:
  %t183 = load ptr, ptr %l113, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 18}
  %t186 = icmp eq i64 %t184, 9
  store i1 %t186, ptr %l114, !tbaa !21
  br label %bb63
bb63:
  %t187 = load i1, ptr %l114, !tbaa !21
  br i1 %t187, label %bb64, label %bb65
bb64:
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t190, i32 0, i32 4
  %t192 = load { i64, ptr }, ptr %t191
  store { i64, ptr } %t192, ptr %l7, !tbaa !27
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t194, { i64, ptr } %t195)
  br label %bb67
bb67:
  %t198 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t198, i1 false)
  br label %bb68
bb68:
  br label %bb169
bb69:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t201 = load ptr, ptr %l122, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb70, label %bb71
bb70:
  %t204 = load ptr, ptr %l122, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 18}
  %t207 = icmp eq i64 %t205, 10
  store i1 %t207, ptr %l123, !tbaa !21
  br label %bb71
bb71:
  %t208 = load i1, ptr %l123, !tbaa !21
  br i1 %t208, label %bb72, label %bb73
bb72:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l8, !tbaa !29
  br label %bb74
bb73:
  br label %bb78
bb74:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l8, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Slice", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t215, ptr %t219)
  br label %bb75
bb75:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l8, !tbaa !29
  %t226 = getelementptr %"compiler/typed:Slice", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t223, ptr %t227)
  br label %bb76
bb76:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l8, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Slice", ptr %t232, i32 0, i32 2
  %t235 = load ptr, ptr %t234, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t231, ptr %t235)
  br label %bb77
bb77:
  br label %bb169
bb78:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t240 = load ptr, ptr %l140, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb79, label %bb80
bb79:
  %t243 = load ptr, ptr %l140, !tbaa !29
  %t244 = load i64, ptr %t243, !range !{i64 0, i64 18}
  %t246 = icmp eq i64 %t244, 11
  store i1 %t246, ptr %l141, !tbaa !21
  br label %bb80
bb80:
  %t247 = load i1, ptr %l141, !tbaa !21
  br i1 %t247, label %bb81, label %bb82
bb81:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l9, !tbaa !29
  br label %bb83
bb82:
  br label %bb91
bb83:
  store %olang.scope zeroinitializer, ptr %s10
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l9, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Cond", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t254, ptr %t258)
  br label %bb84
bb84:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s10, ptr %t262)
  store { i64, ptr } %t264, ptr %l151
  br label %bb85
bb85:
  %t265 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t265, ptr %l10, !tbaa !27
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load ptr, ptr %l9, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Cond", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t266, ptr %t270)
  br label %bb86
bb86:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s10, ptr %t273)
  store { i64, ptr } %t275, ptr %l156
  br label %bb87
bb87:
  %t276 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t276, ptr %l11, !tbaa !27
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s10, ptr %t277, { i64, ptr } %t278)
  br label %bb88
bb88:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l9, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Cond", ptr %t282, i32 0, i32 2
  %t285 = load ptr, ptr %t284, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t281, ptr %t285)
  br label %bb89
bb89:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s10, ptr %t289, { i64, ptr } %t290)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s10)
  br label %bb169
bb91:
  %t293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t293, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t294 = load ptr, ptr %l165, !tbaa !29
  %t295 = icmp ne ptr %t294, null
  br i1 %t295, label %bb92, label %bb93
bb92:
  %t297 = load ptr, ptr %l165, !tbaa !29
  %t298 = load i64, ptr %t297, !range !{i64 0, i64 18}
  %t300 = icmp eq i64 %t298, 12
  store i1 %t300, ptr %l166, !tbaa !21
  br label %bb93
bb93:
  %t301 = load i1, ptr %l166, !tbaa !21
  br i1 %t301, label %bb94, label %bb95
bb94:
  %t302 = load ptr, ptr %l1, !tbaa !29
  %t304 = getelementptr { i64, [5 x i64] }, ptr %t302, i32 0, i32 1
  %t305 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t304, i32 0, i32 2
  %t306 = load ptr, ptr %t305
  store ptr %t306, ptr %l12, !tbaa !29
  br label %bb96
bb95:
  br label %bb105
bb96:
  %t308 = load ptr, ptr %l12, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Seq", ptr %t308, i32 0, i32 0
  %t311 = load { i64, ptr }, ptr %t310, !tbaa !27
  store { i64, ptr } %t311, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t313 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t313, 0
  store i64 %t315, ptr %l15, !tbaa !24
  br label %bb97
bb97:
  %t317 = load i64, ptr %l14, !tbaa !24
  %t318 = load i64, ptr %l15, !tbaa !24
  %t321 = icmp slt i64 %t317, %t318
  %t323 = xor i1 %t321, true
  br i1 %t323, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t325 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t325, ptr %l179, !tbaa !27
  %t326 = load i64, ptr %l14, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr ptr, ptr %t329, i64 %t326
  %t331 = load ptr, ptr %t330, !tbaa !39
  %t333 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %t333, ptr %t331)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t337 = load i64, ptr %l14, !tbaa !24
  %t340 = add i64 %t337, 1
  store i64 %t340, ptr %l14, !tbaa !24
  br label %bb97
bb103:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l12, !tbaa !29
  %t345 = getelementptr %"compiler/typed:Seq", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t342, ptr %t346)
  br label %bb104
bb104:
  br label %bb169
bb105:
  %t349 = load ptr, ptr %l1, !tbaa !29
  store ptr %t349, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t350 = load ptr, ptr %l190, !tbaa !29
  %t351 = icmp ne ptr %t350, null
  br i1 %t351, label %bb106, label %bb107
bb106:
  %t353 = load ptr, ptr %l190, !tbaa !29
  %t354 = load i64, ptr %t353, !range !{i64 0, i64 18}
  %t356 = icmp eq i64 %t354, 13
  store i1 %t356, ptr %l191, !tbaa !21
  br label %bb107
bb107:
  %t357 = load i1, ptr %l191, !tbaa !21
  br i1 %t357, label %bb108, label %bb109
bb108:
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr { i64, [5 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t360, i32 0, i32 2
  %t362 = load ptr, ptr %t361
  store ptr %t362, ptr %l17, !tbaa !29
  br label %bb110
bb109:
  br label %bb112
bb110:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ematch(ptr %v0, ptr %v1, ptr %t364, ptr %t365)
  br label %bb111
bb111:
  br label %bb169
bb112:
  %t368 = load ptr, ptr %l1, !tbaa !29
  store ptr %t368, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t369 = load ptr, ptr %l198, !tbaa !29
  %t370 = icmp ne ptr %t369, null
  br i1 %t370, label %bb113, label %bb114
bb113:
  %t372 = load ptr, ptr %l198, !tbaa !29
  %t373 = load i64, ptr %t372, !range !{i64 0, i64 18}
  %t375 = icmp eq i64 %t373, 14
  store i1 %t375, ptr %l199, !tbaa !21
  br label %bb114
bb114:
  %t376 = load i1, ptr %l199, !tbaa !21
  br i1 %t376, label %bb115, label %bb116
bb115:
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr { i64, [5 x i64] }, ptr %t377, i32 0, i32 1
  %t380 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t379, i32 0, i32 2
  %t381 = load ptr, ptr %t380
  store ptr %t381, ptr %l18, !tbaa !29
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2etry(ptr %v0, ptr %v1, ptr %t383, ptr %t384)
  br label %bb118
bb118:
  br label %bb169
bb119:
  %t387 = load ptr, ptr %l1, !tbaa !29
  store ptr %t387, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t388 = load ptr, ptr %l206, !tbaa !29
  %t389 = icmp ne ptr %t388, null
  br i1 %t389, label %bb120, label %bb121
bb120:
  %t391 = load ptr, ptr %l206, !tbaa !29
  %t392 = load i64, ptr %t391, !range !{i64 0, i64 18}
  %t394 = icmp eq i64 %t392, 16
  store i1 %t394, ptr %l207, !tbaa !21
  br label %bb121
bb121:
  %t395 = load i1, ptr %l207, !tbaa !21
  br i1 %t395, label %bb122, label %bb123
bb122:
  %t396 = load ptr, ptr %l1, !tbaa !29
  %t398 = getelementptr { i64, [5 x i64] }, ptr %t396, i32 0, i32 1
  %t399 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t398, i32 0, i32 2
  %t400 = load ptr, ptr %t399
  store ptr %t400, ptr %l19, !tbaa !29
  br label %bb124
bb123:
  br label %bb137
bb124:
  %t402 = load ptr, ptr %l19, !tbaa !29
  %t404 = getelementptr %"compiler/typed:Text", ptr %t402, i32 0, i32 0
  %t405 = load { i64, ptr }, ptr %t404, !tbaa !27
  store { i64, ptr } %t405, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t407 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t407, 0
  store i64 %t409, ptr %l22, !tbaa !24
  br label %bb125
bb125:
  %t411 = load i64, ptr %l21, !tbaa !24
  %t412 = load i64, ptr %l22, !tbaa !24
  %t415 = icmp slt i64 %t411, %t412
  %t417 = xor i1 %t415, true
  br i1 %t417, label %bb126, label %bb127
bb126:
  br label %bb136
bb127:
  br label %bb128
bb128:
  %t419 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t419, ptr %l220, !tbaa !27
  %t420 = load i64, ptr %l21, !tbaa !24
  %t422 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr ptr, ptr %t423, i64 %t420
  %t425 = load ptr, ptr %t424, !tbaa !39
  store ptr %t425, ptr %l23, !tbaa !29
  %t427 = load ptr, ptr %l23, !tbaa !29
  store ptr %t427, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t428 = load ptr, ptr %l223, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb129, label %bb130
bb129:
  %t431 = load ptr, ptr %l223, !tbaa !29
  %t432 = load i64, ptr %t431, !range !{i64 0, i64 2}
  %t434 = icmp eq i64 %t432, 1
  store i1 %t434, ptr %l224, !tbaa !21
  br label %bb130
bb130:
  %t435 = load i1, ptr %l224, !tbaa !21
  br i1 %t435, label %bb131, label %bb132
bb131:
  %t436 = load ptr, ptr %l23, !tbaa !29
  %t438 = getelementptr { i64, [2 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { ptr }, ptr %t438, i32 0, i32 0
  %t440 = load ptr, ptr %t439
  %t442 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t442, ptr %t440)
  br label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t447 = load i64, ptr %l21, !tbaa !24
  %t450 = add i64 %t447, 1
  store i64 %t450, ptr %l21, !tbaa !24
  br label %bb125
bb136:
  br label %bb169
bb137:
  %t452 = load ptr, ptr %l1, !tbaa !29
  store ptr %t452, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t453 = load ptr, ptr %l235, !tbaa !29
  %t454 = icmp ne ptr %t453, null
  br i1 %t454, label %bb138, label %bb139
bb138:
  %t456 = load ptr, ptr %l235, !tbaa !29
  %t457 = load i64, ptr %t456, !range !{i64 0, i64 18}
  %t459 = icmp eq i64 %t457, 17
  store i1 %t459, ptr %l236, !tbaa !21
  br label %bb139
bb139:
  %t460 = load i1, ptr %l236, !tbaa !21
  br i1 %t460, label %bb140, label %bb141
bb140:
  %t461 = load ptr, ptr %l1, !tbaa !29
  %t463 = getelementptr { i64, [5 x i64] }, ptr %t461, i32 0, i32 1
  %t464 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t463, i32 0, i32 2
  %t465 = load ptr, ptr %t464
  store ptr %t465, ptr %l25, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t467, ptr %t468)
  br label %bb143
bb143:
  br label %bb169
bb144:
  %t472 = load ptr, ptr %l1, !tbaa !29
  store ptr %t472, ptr %l244, !tbaa !29
  store i1 false, ptr %l245, !tbaa !21
  %t473 = load ptr, ptr %l244, !tbaa !29
  %t474 = icmp ne ptr %t473, null
  br i1 %t474, label %bb145, label %bb146
bb145:
  %t476 = load ptr, ptr %l244, !tbaa !29
  %t477 = load i64, ptr %t476, !range !{i64 0, i64 18}
  %t479 = icmp eq i64 %t477, 15
  store i1 %t479, ptr %l245, !tbaa !21
  br label %bb146
bb146:
  %t480 = load i1, ptr %l245, !tbaa !21
  br i1 %t480, label %bb147, label %bb148
bb147:
  %t481 = load ptr, ptr %l1, !tbaa !29
  %t483 = getelementptr { i64, [5 x i64] }, ptr %t481, i32 0, i32 1
  %t484 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t483, i32 0, i32 2
  %t485 = load ptr, ptr %t484
  store ptr %t485, ptr %l26, !tbaa !29
  br label %bb149
bb148:
  br label %bb168
bb149:
  %t487 = load ptr, ptr %l26, !tbaa !29
  store ptr %t487, ptr %l250, !tbaa !29
  store i1 false, ptr %l251, !tbaa !21
  %t488 = load ptr, ptr %l250, !tbaa !29
  %t489 = icmp ne ptr %t488, null
  br i1 %t489, label %bb150, label %bb151
bb150:
  %t491 = load ptr, ptr %l250, !tbaa !29
  %t492 = load i64, ptr %t491, !range !{i64 0, i64 3}
  %t494 = icmp eq i64 %t492, 1
  store i1 %t494, ptr %l251, !tbaa !21
  br label %bb151
bb151:
  %t495 = load i1, ptr %l251, !tbaa !21
  br i1 %t495, label %bb152, label %bb153
bb152:
  %t496 = load ptr, ptr %l26, !tbaa !29
  %t498 = getelementptr { i64, [4 x i64] }, ptr %t496, i32 0, i32 1
  %t499 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t498, i32 0, i32 0
  %t500 = load i32, ptr %t499
  store i32 %t500, ptr %l27, !tbaa !23
  %t502 = load ptr, ptr %l26, !tbaa !29
  %t504 = getelementptr { i64, [4 x i64] }, ptr %t502, i32 0, i32 1
  %t505 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t504, i32 0, i32 1
  %t506 = load { i64, ptr }, ptr %t505
  %t508 = load ptr, ptr %l26, !tbaa !29
  %t510 = getelementptr { i64, [4 x i64] }, ptr %t508, i32 0, i32 1
  %t511 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t510, i32 0, i32 2
  %t512 = load i32, ptr %t511
  store i32 %t512, ptr %l29, !tbaa !23
  store { i64, ptr } %t506, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t516 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t518 = extractvalue { i64, ptr } %t516, 0
  store i64 %t518, ptr %l32, !tbaa !24
  br label %bb154
bb153:
  br label %bb161
bb154:
  %t520 = load i64, ptr %l31, !tbaa !24
  %t521 = load i64, ptr %l32, !tbaa !24
  %t524 = icmp slt i64 %t520, %t521
  %t526 = xor i1 %t524, true
  br i1 %t526, label %bb155, label %bb156
bb155:
  br label %bb160
bb156:
  br label %bb157
bb157:
  %t528 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t528, ptr %l267, !tbaa !27
  %t529 = load i64, ptr %l31, !tbaa !24
  %t531 = getelementptr { i64, ptr }, ptr %l267, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = getelementptr ptr, ptr %t532, i64 %t529
  %t534 = load ptr, ptr %t533, !tbaa !39
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr %"compiler/typed:Capture", ptr %t534, i32 0, i32 1
  %t540 = load ptr, ptr %t539, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t536, ptr %t540)
  br label %bb158
bb158:
  br label %bb159
bb159:
  %t544 = load i64, ptr %l31, !tbaa !24
  %t547 = add i64 %t544, 1
  store i64 %t547, ptr %l31, !tbaa !24
  br label %bb154
bb160:
  br label %bb161
bb161:
  %t549 = load ptr, ptr %l26, !tbaa !29
  store ptr %t549, ptr %l277, !tbaa !29
  store i1 false, ptr %l278, !tbaa !21
  %t550 = load ptr, ptr %l277, !tbaa !29
  %t551 = icmp ne ptr %t550, null
  br i1 %t551, label %bb162, label %bb163
bb162:
  %t553 = load ptr, ptr %l277, !tbaa !29
  %t554 = load i64, ptr %t553, !range !{i64 0, i64 3}
  %t556 = icmp eq i64 %t554, 2
  store i1 %t556, ptr %l278, !tbaa !21
  br label %bb163
bb163:
  %t557 = load i1, ptr %l278, !tbaa !21
  br i1 %t557, label %bb164, label %bb165
bb164:
  %t558 = load ptr, ptr %l26, !tbaa !29
  %t560 = getelementptr { i64, [4 x i64] }, ptr %t558, i32 0, i32 1
  %t561 = getelementptr { i32, ptr, i32 }, ptr %t560, i32 0, i32 0
  %t562 = load i32, ptr %t561
  store i32 %t562, ptr %l34, !tbaa !23
  %t564 = load ptr, ptr %l26, !tbaa !29
  %t566 = getelementptr { i64, [4 x i64] }, ptr %t564, i32 0, i32 1
  %t567 = getelementptr { i32, ptr, i32 }, ptr %t566, i32 0, i32 1
  %t568 = load ptr, ptr %t567
  %t570 = load ptr, ptr %l26, !tbaa !29
  %t572 = getelementptr { i64, [4 x i64] }, ptr %t570, i32 0, i32 1
  %t573 = getelementptr { i32, ptr, i32 }, ptr %t572, i32 0, i32 2
  %t574 = load i32, ptr %t573
  store i32 %t574, ptr %l36, !tbaa !23
  %t576 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t576, ptr %t568)
  br label %bb166
bb165:
  br label %bb167
bb166:
  br label %bb167
bb167:
  br label %bb169
bb168:
  call void @__olang_check_failed(ptr @olang_loc_e0d071190e38de5d_291e4ea72946f179)
  unreachable
bb169:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l14 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 7
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:dropWalk", ptr %t15, i32 0, i32 7
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l14
  br label %bb6
bb6:
  %t23 = load i32, ptr %l14, !tbaa !23
  %t25 = icmp ne i32 %t23, %a2
  br i1 %t25, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l17, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:dropWalk", ptr %t28, i32 0, i32 8
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t30, i64 %t31)
  store i64 %t34, ptr %l21
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t35, i64 %t36)
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t40 = trunc i64 0 to i32
  %t41 = icmp eq i32 %a1, %t40
  %t42 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ekeepFor(ptr %v0, ptr %t37, i1 %t41, i64 %t42)
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = sub i64 %t46, 1
  store i64 %t49, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/typed:dropWalk", ptr %t51, i32 0, i32 3
  store i1 true, ptr %t53, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ekeepFor(ptr %v0, ptr %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca i1
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = add i64 %t8, 1
  %t13 = mul i64 %a2, %t10
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l25, !tbaa !24
  store i64 %t43, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l22, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:dropWalk", ptr %t63, i32 0, i32 2
  %t66 = load i64, ptr %l10, !tbaa !24
  %t69 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t65, i64 %t66)
  store i1 %t69, ptr %l46
  br label %bb12
bb12:
  %t70 = load i1, ptr %l46, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t73 = load i1, ptr %l1, !tbaa !21
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/typed:dropWalk", ptr %t75, i32 0, i32 9
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = add i64 %t78, %t79
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t77, i64 %t82, i1 true)
  br label %bb18
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:dropWalk", ptr %t85, i32 0, i32 10
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = add i64 %t88, %t89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t87, i64 %t92, i1 true)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t95 = load i64, ptr %l9, !tbaa !24
  %t98 = add i64 %t95, 1
  store i64 %t98, ptr %l9, !tbaa !24
  br label %bb8
bb22:
  %t100 = load i1, ptr %l1, !tbaa !21
  br i1 %t100, label %bb23, label %bb24
bb23:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/typed:dropWalk", ptr %t102, i32 0, i32 9
  %t105 = load i64, ptr %l4, !tbaa !24
  %t106 = load i64, ptr %l3, !tbaa !24
  %t109 = add i64 %t105, %t106
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t104, i64 %t109, i1 false)
  br label %bb25
bb24:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/typed:dropWalk", ptr %t112, i32 0, i32 10
  %t115 = load i64, ptr %l4, !tbaa !24
  %t116 = load i64, ptr %l3, !tbaa !24
  %t119 = add i64 %t115, %t116
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t114, i64 %t119, i1 false)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esetLocal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 1
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l12
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l11
  br label %bb1
bb1:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  br label %ret
bb4:
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 2
  store ptr %t16, ptr %l14, !tbaa !29
  store i64 %t13, ptr %l15, !tbaa !24
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t36, i32 0, i32 0
  %t38 = load %"compiler/source:Span", ptr %t37
  store %"compiler/source:Span" %t38, ptr %l4
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l5, !tbaa !23
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t48, i32 0, i32 2
  %t50 = load i64, ptr %t49
  %t54 = icmp eq i64 %t50, 0
  store i1 %t54, ptr %l24, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l24, !tbaa !21
  %t57 = xor i1 %t56, true
  %t58 = load ptr, ptr %l14, !tbaa !29
  %t59 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t58, i64 %t59, i1 %t57)
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l168 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l183 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca i1
  %l213 = alloca ptr
  %l214 = alloca i1
  %l221 = alloca i64
  %l224 = alloca i1
  %l228 = alloca i1
  %l235 = alloca i1
  %l239 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i1
  %l261 = alloca { i64, ptr }
  %l270 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l285 = alloca ptr
  %l286 = alloca i1
  %l299 = alloca { i64, ptr }
  %s12 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t7 = load ptr, ptr %l40, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l40, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 17}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l41, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l41, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l2, !tbaa !23
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esetLocal(ptr %v0, ptr %v1, ptr %t32, i64 %t35, ptr %t36)
  br label %bb10
bb10:
  br label %bb176
bb11:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t42 = load ptr, ptr %l56, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load ptr, ptr %l56, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 17}
  %t48 = icmp eq i64 %t46, 1
  store i1 %t48, ptr %l57, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l57, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t52, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [3 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb25
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  br label %bb18
bb18:
  %t72 = load ptr, ptr %l4, !tbaa !29
  store ptr %t72, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t73 = load ptr, ptr %l70, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t76 = load ptr, ptr %l70, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 8}
  %t79 = icmp eq i64 %t77, 0
  store i1 %t79, ptr %l71, !tbaa !21
  br label %bb20
bb20:
  %t80 = load i1, ptr %l71, !tbaa !21
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t83, i32 0, i32 0
  %t85 = load %"compiler/source:Span", ptr %t84
  store %"compiler/source:Span" %t85, ptr %l6
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l7, !tbaa !23
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t95, i32 0, i32 2
  %t97 = load i32, ptr %t96
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t102 = sext i32 %t97 to i64
  %t103 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esetLocal(ptr %v0, ptr %v1, ptr %t99, i64 %t102, ptr %t103)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb176
bb25:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t109 = load ptr, ptr %l85, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t112 = load ptr, ptr %l85, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 17}
  %t115 = icmp eq i64 %t113, 2
  store i1 %t115, ptr %l86, !tbaa !21
  br label %bb27
bb27:
  %t116 = load i1, ptr %l86, !tbaa !21
  br i1 %t116, label %bb28, label %bb29
bb28:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l9, !tbaa !29
  br label %bb34
bb29:
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t124 = load ptr, ptr %l91, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t127 = load ptr, ptr %l91, !tbaa !29
  %t128 = load i64, ptr %t127, !range !{i64 0, i64 17}
  %t130 = icmp eq i64 %t128, 15
  store i1 %t130, ptr %l92, !tbaa !21
  br label %bb31
bb31:
  %t131 = load i1, ptr %l92, !tbaa !21
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", ptr }, ptr %t134, i32 0, i32 1
  %t136 = load ptr, ptr %t135
  store ptr %t136, ptr %l9, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t138, ptr %t139)
  br label %bb35
bb35:
  br label %bb176
bb36:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t144 = load ptr, ptr %l100, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb37, label %bb38
bb37:
  %t147 = load ptr, ptr %l100, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 17}
  %t150 = icmp eq i64 %t148, 16
  store i1 %t150, ptr %l101, !tbaa !21
  br label %bb38
bb38:
  %t151 = load i1, ptr %l101, !tbaa !21
  br i1 %t151, label %bb39, label %bb40
bb39:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", ptr }, ptr %t154, i32 0, i32 1
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l10, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  br label %bb42
bb42:
  br label %bb176
bb43:
  %t162 = load ptr, ptr %l1, !tbaa !29
  store ptr %t162, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t163 = load ptr, ptr %l108, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb44, label %bb45
bb44:
  %t166 = load ptr, ptr %l108, !tbaa !29
  %t167 = load i64, ptr %t166, !range !{i64 0, i64 17}
  %t169 = icmp eq i64 %t167, 6
  store i1 %t169, ptr %l109, !tbaa !21
  br label %bb45
bb45:
  %t170 = load i1, ptr %l109, !tbaa !21
  br i1 %t170, label %bb46, label %bb47
bb46:
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", ptr }, ptr %t173, i32 0, i32 1
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l11, !tbaa !29
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t177, ptr %t178)
  br label %bb49
bb49:
  %t181 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t181, i64 -1)
  br label %bb50
bb50:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/typed:dropWalk", ptr %t183, i32 0, i32 3
  store i1 true, ptr %t185, !tbaa !21
  br label %bb176
bb51:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t187 = load ptr, ptr %l118, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb52, label %bb53
bb52:
  %t190 = load ptr, ptr %l118, !tbaa !29
  %t191 = load i64, ptr %t190, !range !{i64 0, i64 17}
  %t193 = icmp eq i64 %t191, 8
  store i1 %t193, ptr %l119, !tbaa !21
  br label %bb53
bb53:
  %t194 = load i1, ptr %l119, !tbaa !21
  br i1 %t194, label %bb54, label %bb55
bb54:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [3 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t197, i32 0, i32 1
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l12, !tbaa !29
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t201, ptr %t202)
  br label %bb57
bb57:
  %t206 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t206, i1 true)
  br label %bb58
bb58:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/typed:dropWalk", ptr %t208, i32 0, i32 3
  store i1 true, ptr %t210, !tbaa !21
  br label %bb176
bb59:
  %t211 = load ptr, ptr %l1, !tbaa !29
  store ptr %t211, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t212 = load ptr, ptr %l129, !tbaa !29
  %t213 = icmp ne ptr %t212, null
  br i1 %t213, label %bb60, label %bb61
bb60:
  %t215 = load ptr, ptr %l129, !tbaa !29
  %t216 = load i64, ptr %t215, !range !{i64 0, i64 17}
  %t218 = icmp eq i64 %t216, 7
  store i1 %t218, ptr %l130, !tbaa !21
  br label %bb61
bb61:
  %t219 = load i1, ptr %l130, !tbaa !21
  br i1 %t219, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t220 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t220, i1 true)
  br label %bb65
bb65:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/typed:dropWalk", ptr %t222, i32 0, i32 3
  store i1 true, ptr %t224, !tbaa !21
  br label %bb176
bb66:
  %t225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t225, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t226 = load ptr, ptr %l135, !tbaa !29
  %t227 = icmp ne ptr %t226, null
  br i1 %t227, label %bb67, label %bb68
bb67:
  %t229 = load ptr, ptr %l135, !tbaa !29
  %t230 = load i64, ptr %t229, !range !{i64 0, i64 17}
  %t232 = icmp eq i64 %t230, 9
  store i1 %t232, ptr %l136, !tbaa !21
  br label %bb68
bb68:
  %t233 = load i1, ptr %l136, !tbaa !21
  br i1 %t233, label %bb69, label %bb70
bb69:
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t234, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t236, i32 0, i32 2
  %t238 = load ptr, ptr %t237
  store ptr %t238, ptr %l13, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t240, ptr %t241)
  br label %bb72
bb72:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/typed:dropWalk", ptr %t244, i32 0, i32 3
  store i1 true, ptr %t246, !tbaa !21
  br label %bb176
bb73:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t248 = load ptr, ptr %l144, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb74, label %bb75
bb74:
  %t251 = load ptr, ptr %l144, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 10
  store i1 %t254, ptr %l145, !tbaa !21
  br label %bb75
bb75:
  %t255 = load i1, ptr %l145, !tbaa !21
  br i1 %t255, label %bb76, label %bb77
bb76:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l14, !tbaa !29
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [3 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t264, i32 0, i32 2
  %t266 = load ptr, ptr %t265
  store ptr %t266, ptr %l15, !tbaa !29
  br label %bb78
bb77:
  br label %bb81
bb78:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t268, ptr %t269)
  br label %bb79
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t273, ptr %t274)
  br label %bb80
bb80:
  br label %bb176
bb81:
  %t277 = load ptr, ptr %l1, !tbaa !29
  store ptr %t277, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t278 = load ptr, ptr %l157, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb82, label %bb83
bb82:
  %t281 = load ptr, ptr %l157, !tbaa !29
  %t282 = load i64, ptr %t281, !range !{i64 0, i64 17}
  %t284 = icmp eq i64 %t282, 3
  store i1 %t284, ptr %l158, !tbaa !21
  br label %bb83
bb83:
  %t285 = load i1, ptr %l158, !tbaa !21
  br i1 %t285, label %bb84, label %bb85
bb84:
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr { i64, [3 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr }, ptr %t288, i32 0, i32 1
  %t290 = load ptr, ptr %t289
  store ptr %t290, ptr %l16, !tbaa !29
  br label %bb86
bb85:
  br label %bb94
bb86:
  store %olang.scope zeroinitializer, ptr %s12
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l16, !tbaa !29
  %t295 = getelementptr %"compiler/typed:If", ptr %t293, i32 0, i32 0
  %t296 = load ptr, ptr %t295, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t292, ptr %t296)
  br label %bb87
bb87:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s12, ptr %t300)
  store { i64, ptr } %t302, ptr %l168
  br label %bb88
bb88:
  %t303 = load { i64, ptr }, ptr %l168, !tbaa !27
  store { i64, ptr } %t303, ptr %l17, !tbaa !27
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load ptr, ptr %l16, !tbaa !29
  %t307 = getelementptr %"compiler/typed:If", ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t304, ptr %t308)
  br label %bb89
bb89:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s12, ptr %t312)
  store { i64, ptr } %t314, ptr %l174
  br label %bb90
bb90:
  %t315 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t315, ptr %l18, !tbaa !27
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s12, ptr %t316, { i64, ptr } %t317)
  br label %bb91
bb91:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load ptr, ptr %l16, !tbaa !29
  %t323 = getelementptr %"compiler/typed:If", ptr %t321, i32 0, i32 2
  %t324 = load ptr, ptr %t323, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t320, ptr %t324)
  br label %bb92
bb92:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s12, ptr %t327, { i64, ptr } %t328)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s12)
  br label %bb176
bb94:
  %t331 = load ptr, ptr %l1, !tbaa !29
  store ptr %t331, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t332 = load ptr, ptr %l182, !tbaa !29
  %t333 = icmp ne ptr %t332, null
  br i1 %t333, label %bb95, label %bb96
bb95:
  %t335 = load ptr, ptr %l182, !tbaa !29
  %t336 = load i64, ptr %t335, !range !{i64 0, i64 17}
  %t338 = icmp eq i64 %t336, 4
  store i1 %t338, ptr %l183, !tbaa !21
  br label %bb96
bb96:
  %t339 = load i1, ptr %l183, !tbaa !21
  br i1 %t339, label %bb97, label %bb98
bb97:
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr { i64, [3 x i64] }, ptr %t340, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t342, i32 0, i32 1
  %t344 = load ptr, ptr %t343
  store ptr %t344, ptr %l19, !tbaa !29
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t348 = getelementptr { i64, [3 x i64] }, ptr %t346, i32 0, i32 1
  %t349 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t348, i32 0, i32 2
  %t350 = load ptr, ptr %t349
  store ptr %t350, ptr %l20, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l19, !tbaa !29
  %t354 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %t352, ptr %t353, ptr %t354)
  br label %bb100
bb100:
  br label %bb176
bb101:
  %t358 = load ptr, ptr %l1, !tbaa !29
  store ptr %t358, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t359 = load ptr, ptr %l193, !tbaa !29
  %t360 = icmp ne ptr %t359, null
  br i1 %t360, label %bb102, label %bb103
bb102:
  %t362 = load ptr, ptr %l193, !tbaa !29
  %t363 = load i64, ptr %t362, !range !{i64 0, i64 17}
  %t365 = icmp eq i64 %t363, 5
  store i1 %t365, ptr %l194, !tbaa !21
  br label %bb103
bb103:
  %t366 = load i1, ptr %l194, !tbaa !21
  br i1 %t366, label %bb104, label %bb105
bb104:
  %t367 = load ptr, ptr %l1, !tbaa !29
  %t369 = getelementptr { i64, [3 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t369, i32 0, i32 1
  %t371 = load i32, ptr %t370, !range !{i32 0, i32 2}
  store i32 %t371, ptr %l21
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [3 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t375, i32 0, i32 2
  %t377 = load i32, ptr %t376
  store i32 %t377, ptr %l22, !tbaa !23
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load i32, ptr %l21, !range !{i32 0, i32 2}
  %t381 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejump(ptr %v0, ptr %t379, i32 %t380, i32 %t381)
  br label %bb107
bb107:
  br label %bb176
bb108:
  %t385 = load ptr, ptr %l1, !tbaa !29
  store ptr %t385, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t386 = load ptr, ptr %l204, !tbaa !29
  %t387 = icmp ne ptr %t386, null
  br i1 %t387, label %bb109, label %bb110
bb109:
  %t389 = load ptr, ptr %l204, !tbaa !29
  %t390 = load i64, ptr %t389, !range !{i64 0, i64 17}
  %t392 = icmp eq i64 %t390, 11
  store i1 %t392, ptr %l205, !tbaa !21
  br label %bb110
bb110:
  %t393 = load i1, ptr %l205, !tbaa !21
  br i1 %t393, label %bb111, label %bb112
bb111:
  %t394 = load ptr, ptr %l1, !tbaa !29
  %t396 = getelementptr { i64, [3 x i64] }, ptr %t394, i32 0, i32 1
  %t397 = getelementptr { %"compiler/source:Span", ptr }, ptr %t396, i32 0, i32 1
  %t398 = load ptr, ptr %t397
  store ptr %t398, ptr %l23, !tbaa !29
  br label %bb113
bb112:
  br label %bb115
bb113:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t400, ptr %t401)
  br label %bb114
bb114:
  br label %bb176
bb115:
  %t405 = load ptr, ptr %l1, !tbaa !29
  store ptr %t405, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t406 = load ptr, ptr %l213, !tbaa !29
  %t407 = icmp ne ptr %t406, null
  br i1 %t407, label %bb116, label %bb117
bb116:
  %t409 = load ptr, ptr %l213, !tbaa !29
  %t410 = load i64, ptr %t409, !range !{i64 0, i64 17}
  %t412 = icmp eq i64 %t410, 12
  store i1 %t412, ptr %l214, !tbaa !21
  br label %bb117
bb117:
  %t413 = load i1, ptr %l214, !tbaa !21
  br i1 %t413, label %bb118, label %bb119
bb118:
  %t414 = load ptr, ptr %l1, !tbaa !29
  %t416 = getelementptr { i64, [3 x i64] }, ptr %t414, i32 0, i32 1
  %t417 = getelementptr { %"compiler/source:Span", ptr }, ptr %t416, i32 0, i32 1
  %t418 = load ptr, ptr %t417
  store ptr %t418, ptr %l24, !tbaa !29
  br label %bb120
bb119:
  br label %bb139
bb120:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load ptr, ptr %l24, !tbaa !29
  %t424 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %t420, ptr %t421)
  store i64 %t424, ptr %l221
  br label %bb121
bb121:
  %t425 = load i64, ptr %l221, !tbaa !24
  store i64 %t425, ptr %l25, !tbaa !24
  %t426 = load i64, ptr %l25, !tbaa !24
  %t428 = icmp sge i64 %t426, 0
  br i1 %t428, label %bb122, label %bb123
bb122:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/typed:dropWalk", ptr %t430, i32 0, i32 1
  %t433 = load i64, ptr %l25, !tbaa !24
  %t436 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t432, i64 %t433)
  store i1 %t436, ptr %l228
  br label %bb124
bb123:
  store i1 false, ptr %l224, !tbaa !21
  br label %bb125
bb124:
  %t437 = load i1, ptr %l228, !tbaa !21
  %t438 = xor i1 %t437, true
  store i1 %t438, ptr %l224, !tbaa !21
  br label %bb125
bb125:
  %t440 = load i1, ptr %l224, !tbaa !21
  br i1 %t440, label %bb126, label %bb127
bb126:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/typed:dropWalk", ptr %t441, i32 0, i32 14
  %t444 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t443, i64 %t444, i1 true)
  br label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb129
bb129:
  %t447 = load i64, ptr %l25, !tbaa !24
  %t449 = icmp sge i64 %t447, 0
  br i1 %t449, label %bb130, label %bb131
bb130:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/typed:dropWalk", ptr %t451, i32 0, i32 1
  %t454 = load i64, ptr %l25, !tbaa !24
  %t457 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t453, i64 %t454)
  store i1 %t457, ptr %l239
  br label %bb132
bb131:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb133
bb132:
  %t458 = load i1, ptr %l239, !tbaa !21
  store i1 %t458, ptr %l235, !tbaa !21
  br label %bb133
bb133:
  %t459 = load i1, ptr %l235, !tbaa !21
  br i1 %t459, label %bb134, label %bb135
bb134:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/typed:dropWalk", ptr %t460, i32 0, i32 5
  %t463 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t462, i64 %t463)
  br label %bb136
bb135:
  br label %bb138
bb136:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t468 = getelementptr %"compiler/typed:dropWalk", ptr %t466, i32 0, i32 6
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/typed:dropWalk", ptr %t469, i32 0, i32 4
  %t472 = load i64, ptr %t471, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t468, i64 %t472)
  br label %bb137
bb137:
  br label %bb138
bb138:
  br label %bb176
bb139:
  %t475 = load ptr, ptr %l1, !tbaa !29
  store ptr %t475, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t476 = load ptr, ptr %l247, !tbaa !29
  %t477 = icmp ne ptr %t476, null
  br i1 %t477, label %bb140, label %bb141
bb140:
  %t479 = load ptr, ptr %l247, !tbaa !29
  %t480 = load i64, ptr %t479, !range !{i64 0, i64 17}
  %t482 = icmp eq i64 %t480, 13
  store i1 %t482, ptr %l248, !tbaa !21
  br label %bb141
bb141:
  %t483 = load i1, ptr %l248, !tbaa !21
  br i1 %t483, label %bb142, label %bb143
bb142:
  %t484 = load ptr, ptr %l1, !tbaa !29
  %t486 = getelementptr { i64, [3 x i64] }, ptr %t484, i32 0, i32 1
  %t487 = getelementptr { %"compiler/source:Span", ptr }, ptr %t486, i32 0, i32 1
  %t488 = load ptr, ptr %t487
  store ptr %t488, ptr %l26, !tbaa !29
  br label %bb144
bb143:
  br label %bb161
bb144:
  store %olang.scope zeroinitializer, ptr %s19
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t491 = load ptr, ptr %l26, !tbaa !29
  %t493 = getelementptr %"compiler/typed:Join", ptr %t491, i32 0, i32 0
  %t494 = load ptr, ptr %t493, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t490, ptr %t494)
  br label %bb145
bb145:
  %t498 = load ptr, ptr %l26, !tbaa !29
  %t500 = getelementptr %"compiler/typed:Join", ptr %t498, i32 0, i32 1
  %t501 = load i1, ptr %t500, !tbaa !21
  br i1 %t501, label %bb146, label %bb147
bb146:
  %t503 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t503, i1 true)
  br label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb149
bb149:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t507 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s19, ptr %t505)
  store { i64, ptr } %t507, ptr %l261
  br label %bb150
bb150:
  %t508 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t508, ptr %l27, !tbaa !27
  %t509 = load ptr, ptr %l26, !tbaa !29
  %t511 = getelementptr %"compiler/typed:Join", ptr %t509, i32 0, i32 2
  %t512 = load { i64, ptr }, ptr %t511, !tbaa !27
  store { i64, ptr } %t512, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t514 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t514, 0
  store i64 %t516, ptr %l30, !tbaa !24
  br label %bb151
bb151:
  store %olang.scope zeroinitializer, ptr %s22
  %t518 = load i64, ptr %l29, !tbaa !24
  %t519 = load i64, ptr %l30, !tbaa !24
  %t522 = icmp slt i64 %t518, %t519
  %t524 = xor i1 %t522, true
  br i1 %t524, label %bb152, label %bb153
bb152:
  call void @__olang_scope_close(ptr %s22)
  br label %bb160
bb153:
  br label %bb154
bb154:
  %t526 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t526, ptr %l270, !tbaa !27
  %t527 = load i64, ptr %l29, !tbaa !24
  %t529 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !27
  %t531 = getelementptr ptr, ptr %t530, i64 %t527
  %t532 = load ptr, ptr %t531, !tbaa !39
  store ptr %t532, ptr %l31, !tbaa !29
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t536 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s22, ptr %t534)
  store { i64, ptr } %t536, ptr %l274
  br label %bb155
bb155:
  %t537 = load { i64, ptr }, ptr %l274, !tbaa !27
  store { i64, ptr } %t537, ptr %l32, !tbaa !27
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s19, ptr %t538, { i64, ptr } %t539)
  br label %bb156
bb156:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = load ptr, ptr %l31, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Clause", ptr %t543, i32 0, i32 3
  %t546 = load ptr, ptr %t545, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t542, ptr %t546)
  br label %bb157
bb157:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t550 = load { i64, ptr }, ptr %l32, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s22, ptr %t549, { i64, ptr } %t550)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s22)
  br label %bb159
bb159:
  %t553 = load i64, ptr %l29, !tbaa !24
  %t556 = add i64 %t553, 1
  store i64 %t556, ptr %l29, !tbaa !24
  br label %bb151
bb160:
  call void @__olang_scope_close(ptr %s19)
  br label %bb176
bb161:
  %t558 = load ptr, ptr %l1, !tbaa !29
  store ptr %t558, ptr %l285, !tbaa !29
  store i1 false, ptr %l286, !tbaa !21
  %t559 = load ptr, ptr %l285, !tbaa !29
  %t560 = icmp ne ptr %t559, null
  br i1 %t560, label %bb162, label %bb163
bb162:
  %t562 = load ptr, ptr %l285, !tbaa !29
  %t563 = load i64, ptr %t562, !range !{i64 0, i64 17}
  %t565 = icmp eq i64 %t563, 14
  store i1 %t565, ptr %l286, !tbaa !21
  br label %bb163
bb163:
  %t566 = load i1, ptr %l286, !tbaa !21
  br i1 %t566, label %bb164, label %bb165
bb164:
  %t567 = load ptr, ptr %l1, !tbaa !29
  %t569 = getelementptr { i64, [3 x i64] }, ptr %t567, i32 0, i32 1
  %t570 = getelementptr { %"compiler/source:Span", ptr }, ptr %t569, i32 0, i32 1
  %t571 = load ptr, ptr %t570
  store ptr %t571, ptr %l33, !tbaa !29
  br label %bb166
bb165:
  br label %bb175
bb166:
  %t573 = load ptr, ptr %l33, !tbaa !29
  %t575 = getelementptr %"compiler/typed:Spawn", ptr %t573, i32 0, i32 0
  %t576 = load { i64, ptr }, ptr %t575, !tbaa !27
  store { i64, ptr } %t576, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t578 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t578, 0
  store i64 %t580, ptr %l36, !tbaa !24
  br label %bb167
bb167:
  %t582 = load i64, ptr %l35, !tbaa !24
  %t583 = load i64, ptr %l36, !tbaa !24
  %t586 = icmp slt i64 %t582, %t583
  %t588 = xor i1 %t586, true
  br i1 %t588, label %bb168, label %bb169
bb168:
  br label %bb173
bb169:
  br label %bb170
bb170:
  %t590 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t590, ptr %l299, !tbaa !27
  %t591 = load i64, ptr %l35, !tbaa !24
  %t593 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !27
  %t595 = getelementptr ptr, ptr %t594, i64 %t591
  %t596 = load ptr, ptr %t595, !tbaa !39
  %t598 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t598, ptr %t596)
  br label %bb171
bb171:
  br label %bb172
bb172:
  %t602 = load i64, ptr %l35, !tbaa !24
  %t605 = add i64 %t602, 1
  store i64 %t605, ptr %l35, !tbaa !24
  br label %bb167
bb173:
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t608 = load ptr, ptr %l33, !tbaa !29
  %t610 = getelementptr %"compiler/typed:Spawn", ptr %t608, i32 0, i32 1
  %t611 = load ptr, ptr %t610, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t607, ptr %t611)
  br label %bb174
bb174:
  br label %bb176
bb175:
  call void @__olang_check_failed(ptr @olang_loc_43e833e67406aee2_76f2107f4f2989fe)
  unreachable
bb176:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca ptr
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s2, ptr %v3, ptr %v4, ptr %t26, ptr %t30)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l25
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Alt", ptr %t35, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb8:
  br label %bb9
bb9:
  %t52 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t52, ptr %l34, !tbaa !27
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr ptr, ptr %t56, i64 %t53
  %t58 = load ptr, ptr %t57, !tbaa !39
  store ptr %t58, ptr %l9, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l37, !tbaa !29
  %t61 = load ptr, ptr %l9, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Bind", ptr %t61, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %s4, i64 %t66)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l41
  br label %bb10
bb10:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  %t70 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %t70
  store ptr %t70, ptr %l42, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l9, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Bind", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %s4, ptr %v3, ptr %v4, ptr %t71, ptr %t75)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l47
  br label %bb11
bb11:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  %t81 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %t81
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = load ptr, ptr %l42, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estore(ptr %v0, ptr %s4, ptr %s4, ptr %v4, ptr %v3, ptr %t82, ptr %t83, ptr %t81)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = add i64 %t85, 1
  store i64 %t88, ptr %l7, !tbaa !24
  br label %bb6
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Arm", ptr %t96, i32 0, i32 2
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t102 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s0, ptr %v3, ptr %v4, ptr %t95, ptr %t99)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %l58
  br label %bb17
bb17:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Arm", ptr %t104, i32 0, i32 3
  %t107 = load ptr, ptr %t106, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t103, ptr %t107)
  br label %bb18
bb18:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Arm", ptr %t111, i32 0, i32 4
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t117 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t110, ptr %t114)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %l65
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t118 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l17 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Clause", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t23, ptr %t27)
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t30, i32 0, i32 4
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t47, ptr %l31, !tbaa !27
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t60 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s4, ptr %v2, ptr %v3, ptr %t55, ptr %t53)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l37
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s4)
  br label %bb11
bb11:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = add i64 %t61, 1
  store i64 %t64, ptr %l7, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t66 = load i64, ptr %l3, !tbaa !24
  %t69 = add i64 %t66, 1
  store i64 %t69, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheld(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t30, i32 0, i32 3
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l5, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t34, ptr %t35)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %rv
  br label %ret
bb6:
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l25
  br label %bb7
bb7:
  %t41 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l6
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %s2, ptr %v3, ptr %v4, ptr %t42, ptr %t43)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l28
  br label %bb8
bb8:
  %t47 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  %t48 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %t48
  store ptr %t48, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load i64, ptr %l8, !tbaa !24
  store i64 %t50, ptr %l30, !tbaa !24
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t51)
  store i64 %t53, ptr %l32
  br label %bb10
bb10:
  %t54 = load i64, ptr %l30, !tbaa !24
  %t55 = load i64, ptr %l32, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l7, !tbaa !29
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l37
  br label %bb14
bb14:
  %t65 = load i64, ptr %l37, !tbaa !24
  store ptr %l6, ptr %l38, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/typed:holdWalk", ptr %t66, i32 0, i32 2
  %t72 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t68, i64 %t65)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l42
  br label %bb15
bb15:
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s3, ptr %l42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l44
  br label %bb16
bb16:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t76 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %t76
  %t77 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t77, ptr %t76)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  call void @__olang_scope_close(ptr %s2)
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ematch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Match", ptr %t3, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t20, ptr %l20, !tbaa !27
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  %t28 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estmt(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t28, ptr %t26)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/typed:Match", ptr %t37, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s5)
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t54 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t54, ptr %l36, !tbaa !27
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 %t55
  %t60 = load ptr, ptr %t59, !tbaa !39
  store ptr %l2, ptr %l39, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t66 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2earm(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %v4, ptr %t62, ptr %t60)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l42
  br label %bb13
bb13:
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  %t68 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %t68
  %t69 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t69, ptr %t68)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb15:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l8, !tbaa !24
  br label %bb9
bb16:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Match", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l2, ptr %l51, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l52, !tbaa !29
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Match", ptr %t86, i32 0, i32 2
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb19, label %bb20
bb18:
  br label %bb24
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7fb442b2027c5df4_8cb8a301a51c1668)
  unreachable
bb20:
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Match", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load ptr, ptr %l52, !tbaa !29
  %t99 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2earm(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %v4, ptr %t97, ptr %t96)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l58
  br label %bb22
bb22:
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  %t101 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %t101
  %t102 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t102, ptr %t101)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s7)
  br label %bb24
bb24:
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca ptr
  %l52 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca ptr
  %l67 = alloca i1
  %l73 = alloca ptr
  %l75 = alloca i32
  %l77 = alloca i32
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca ptr
  %l88 = alloca i1
  %l97 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca ptr
  %l99 = alloca i1
  %l106 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l107 = alloca ptr
  %l108 = alloca i1
  %l121 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l128 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l136 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l137 = alloca ptr
  %l138 = alloca i1
  %l146 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l148 = alloca ptr
  %l149 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l154 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l157 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l158 = alloca i32
  %l162 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l165 = alloca ptr
  %l166 = alloca i1
  %l183 = alloca { i64, ptr }
  %l186 = alloca ptr
  %l190 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l195 = alloca ptr
  %l196 = alloca i1
  %l205 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l210 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l214 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l215 = alloca ptr
  %l216 = alloca i1
  %l225 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l226 = alloca ptr
  %l230 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l232 = alloca ptr
  %l237 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l239 = alloca ptr
  %l240 = alloca i1
  %l253 = alloca { i64, ptr }
  %l264 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l265 = alloca ptr
  %l266 = alloca i1
  %l273 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l274 = alloca ptr
  %l275 = alloca i1
  %l283 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l284 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l295 = alloca { i64, ptr }
  %l309 = alloca { i64, ptr }
  %l312 = alloca ptr
  %l316 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l324 = alloca ptr
  %l325 = alloca i1
  %l332 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l333 = alloca ptr
  %l334 = alloca i1
  %l347 = alloca { i64, ptr }
  %l350 = alloca ptr
  %l351 = alloca i1
  %l359 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l363 = alloca ptr
  %l364 = alloca i1
  %l372 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l44, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aholdWalk__2erefs_2elocal_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l44, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l44
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l46
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aholdWalk__2erefs_2elocal_2e2
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l44
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l2
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t29 = load ptr, ptr %l51, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l51, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l52, !tbaa !21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l52, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb17
bb12:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t44 = load ptr, ptr %l57, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t47 = load ptr, ptr %l57, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l58, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l58, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t62 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheld(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t58, ptr %t59)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %l65
  br label %bb18
bb18:
  %t63 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %rv
  br label %ret
bb19:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t65 = load ptr, ptr %l66, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l66, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 3
  store i1 %t71, ptr %l67, !tbaa !21
  br label %bb21
bb21:
  %t72 = load i1, ptr %l67, !tbaa !21
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l4, !tbaa !29
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:holdWalk", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  store ptr %t82, ptr %l73, !tbaa !29
  %t83 = load ptr, ptr %l4, !tbaa !29
  %t85 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t83)
  store i32 %t85, ptr %l75
  br label %bb25
bb25:
  %t86 = load ptr, ptr %l73, !tbaa !29
  %t87 = call ptr @__olang_scope_or(ptr %v3, ptr %t86)
  %t88 = call ptr @__olang_scope_hold(ptr %t87)
  %t89 = ptrtoint ptr %t88 to i64
  %t91 = inttoptr i64 %t89 to ptr
  %t92 = load ptr, ptr %l73, !tbaa !29
  %t93 = load i32, ptr %l75, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t91, ptr %t92, i32 %t93)
  store i32 %t94, ptr %l77
  br label %bb26
bb26:
  %t95 = load i32, ptr %l77, !range !{i32 0, i32 33}
  %t97 = trunc i64 20 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb27, label %bb28
bb27:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheld(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t100, ptr %t101)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l83
  br label %bb29
bb28:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t109 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t105, ptr %t106)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l86
  br label %bb30
bb29:
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %l80
  br label %bb31
bb30:
  %t111 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t111, ptr %l80
  br label %bb31
bb31:
  %t112 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %rv
  br label %ret
bb32:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t114 = load ptr, ptr %l87, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l87, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 18}
  %t120 = icmp eq i64 %t118, 5
  store i1 %t120, ptr %l88, !tbaa !21
  br label %bb34
bb34:
  %t121 = load i1, ptr %l88, !tbaa !21
  br i1 %t121, label %bb35, label %bb36
bb35:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l5, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l5, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Promote", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t136 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t128, ptr %t132)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %l97
  br label %bb38
bb38:
  %t137 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l97
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %rv
  br label %ret
bb39:
  %t138 = load ptr, ptr %l1, !tbaa !29
  store ptr %t138, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t139 = load ptr, ptr %l98, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb40, label %bb41
bb40:
  %t142 = load ptr, ptr %l98, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 18}
  %t145 = icmp eq i64 %t143, 6
  store i1 %t145, ptr %l99, !tbaa !21
  br label %bb41
bb41:
  %t146 = load i1, ptr %l99, !tbaa !21
  br i1 %t146, label %bb42, label %bb43
bb42:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t149, i32 0, i32 2
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l6, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l6, !tbaa !29
  %t157 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t153, ptr %t154)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %l106
  br label %bb45
bb45:
  %t158 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t158, ptr %rv
  br label %ret
bb46:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t160 = load ptr, ptr %l107, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb47, label %bb48
bb47:
  %t163 = load ptr, ptr %l107, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 18}
  %t166 = icmp eq i64 %t164, 7
  store i1 %t166, ptr %l108, !tbaa !21
  br label %bb48
bb48:
  %t167 = load i1, ptr %l108, !tbaa !21
  br i1 %t167, label %bb49, label %bb50
bb49:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [5 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l7, !tbaa !29
  br label %bb51
bb50:
  br label %bb61
bb51:
  store %olang.scope zeroinitializer, ptr %s6
  %t174 = load ptr, ptr %l7, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Make", ptr %t174, i32 0, i32 2
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  store { i64, ptr } %t177, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  store i64 %t181, ptr %l10, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s8
  %t183 = load i64, ptr %l9, !tbaa !24
  %t184 = load i64, ptr %l10, !tbaa !24
  %t187 = icmp slt i64 %t183, %t184
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s8)
  br label %bb59
bb54:
  br label %bb55
bb55:
  %t191 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t191, ptr %l121, !tbaa !27
  %t192 = load i64, ptr %l9, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr ptr, ptr %t195, i64 %t192
  %t197 = load ptr, ptr %t196, !tbaa !39
  store ptr %l2, ptr %l124, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t204 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %v4, ptr %t199, ptr %t197)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t204, ptr %l128
  br label %bb56
bb56:
  %t205 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l128
  %t206 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %t206
  %t207 = load ptr, ptr %l124, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t207, ptr %t206)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  %t209 = load i64, ptr %l9, !tbaa !24
  %t212 = add i64 %t209, 1
  store i64 %t212, ptr %l9, !tbaa !24
  br label %bb52
bb59:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l7, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Make", ptr %t215, i32 0, i32 3
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t221 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s6, ptr %v3, ptr %v4, ptr %t214, ptr %t218)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t221, ptr %l136
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s6)
  br label %bb205
bb61:
  %t222 = load ptr, ptr %l1, !tbaa !29
  store ptr %t222, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t223 = load ptr, ptr %l137, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  br i1 %t224, label %bb62, label %bb63
bb62:
  %t226 = load ptr, ptr %l137, !tbaa !29
  %t227 = load i64, ptr %t226, !range !{i64 0, i64 18}
  %t229 = icmp eq i64 %t227, 8
  store i1 %t229, ptr %l138, !tbaa !21
  br label %bb63
bb63:
  %t230 = load i1, ptr %l138, !tbaa !21
  br i1 %t230, label %bb64, label %bb65
bb64:
  %t231 = load ptr, ptr %l1, !tbaa !29
  %t233 = getelementptr { i64, [5 x i64] }, ptr %t231, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t233, i32 0, i32 2
  %t235 = load ptr, ptr %t234
  store ptr %t235, ptr %l12, !tbaa !29
  br label %bb66
bb65:
  br label %bb84
bb66:
  store %olang.scope zeroinitializer, ptr %s10
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load ptr, ptr %l12, !tbaa !29
  %t240 = getelementptr %"compiler/typed:Collect", ptr %t238, i32 0, i32 0
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t244 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s10, ptr %v3, ptr %v4, ptr %t237, ptr %t241)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t244, ptr %l146
  br label %bb67
bb67:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/typed:holdWalk", ptr %t245, i32 0, i32 5
  store ptr %t247, ptr %l148, !tbaa !29
  %t248 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t248, ptr %l149
  br label %bb68
bb68:
  %t249 = load ptr, ptr %l148, !tbaa !29
  %t250 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %s10, ptr %t249, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t250)
  br label %bb69
bb69:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l12, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Collect", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t251, ptr %t255)
  br label %bb70
bb70:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/typed:holdWalk", ptr %t259, i32 0, i32 5
  %t263 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcd1867a2c89de03c7af27b93b5b476d9(ptr %v0, ptr %v2, ptr %t261)
  %t264 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t263, 1
  %t265 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t263, 0
  store i32 %t265, ptr %l158
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb72, label %ok.267, !prof !99
ok.267:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t264, ptr %l157
  br label %bb71
bb71:
  %t268 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t268, ptr %l154
  br label %bb79
bb72:
  %t269 = load i32, ptr %l158, !tbaa !23
  %t270 = icmp eq i32 %t269, 65536
  br i1 %t270, label %bb73, label %bb74
bb73:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2fe17ed863e993f3_a4fd95e432e2de7)
  unreachable
bb74:
  %t272 = load i32, ptr %l158, !tbaa !23
  %t273 = icmp eq i32 %t272, 65537
  br i1 %t273, label %bb75, label %bb76
bb75:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2b0ce19cf8abfa0_63d28338a0667b94)
  unreachable
bb76:
  %t275 = load i32, ptr %l158, !tbaa !23
  %t276 = icmp eq i32 %t275, 65538
  br i1 %t276, label %bb77, label %bb78
bb77:
  call void @__olang_bang_failed_plain(ptr @olang_loc_231c306bfae66ae8_f9a103d13bf0009c)
  unreachable
bb78:
  call void @__olang_bang_failed_plain(ptr @olang_loc_60c7f079a8f50056_f0211a32bac11e1a)
  unreachable
bb79:
  %t278 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %l162
  %t279 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l154
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t279, ptr %l2
  %t280 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aholdWalk__2erefs_2elocal_2e2
  br i1 %t280, label %bb80, label %bb81
bb80:
  %t282 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l162, i32 0, i32 0
  %t283 = load { i64, ptr }, ptr %t282
  %t284 = extractvalue { i64, ptr } %t283, 1
  %t285 = call ptr @__olang_region_or(ptr %t284, ptr null)
  %t286 = call ptr @__olang_region_home(ptr %t285)
  %t287 = icmp ne ptr %t286, null
  %t288 = select i1 %t287, ptr %t286, ptr null
  call void @__olang_region_drop(ptr %t288)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l162
  br label %bb81
bb81:
  %t289 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t289, label %bb82, label %bb83
bb82:
  %t291 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l162, i32 0, i32 0
  %t292 = load { i64, ptr }, ptr %t291
  %t293 = extractvalue { i64, ptr } %t292, 0
  %t294 = extractvalue { i64, ptr } %t292, 1
  call void @__olang_region_release_part(ptr %t294, i64 %t293)
  store { i64, ptr } zeroinitializer, ptr %t291
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s10)
  br label %bb205
bb84:
  %t295 = load ptr, ptr %l1, !tbaa !29
  store ptr %t295, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t296 = load ptr, ptr %l165, !tbaa !29
  %t297 = icmp ne ptr %t296, null
  br i1 %t297, label %bb85, label %bb86
bb85:
  %t299 = load ptr, ptr %l165, !tbaa !29
  %t300 = load i64, ptr %t299, !range !{i64 0, i64 18}
  %t302 = icmp eq i64 %t300, 9
  store i1 %t302, ptr %l166, !tbaa !21
  br label %bb86
bb86:
  %t303 = load i1, ptr %l166, !tbaa !21
  br i1 %t303, label %bb87, label %bb88
bb87:
  %t304 = load ptr, ptr %l1, !tbaa !29
  %t306 = getelementptr { i64, [5 x i64] }, ptr %t304, i32 0, i32 1
  %t307 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t306, i32 0, i32 2
  %t308 = load i32, ptr %t307, !range !{i32 0, i32 54}
  store i32 %t308, ptr %l13
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr { i64, [5 x i64] }, ptr %t310, i32 0, i32 1
  %t313 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t312, i32 0, i32 4
  %t314 = load { i64, ptr }, ptr %t313
  store { i64, ptr } %t314, ptr %l14, !tbaa !27
  br label %bb89
bb88:
  br label %bb101
bb89:
  %t316 = load i32, ptr %l13, !range !{i32 0, i32 54}
  %t318 = trunc i64 31 to i32
  %t319 = icmp eq i32 %t316, %t318
  br i1 %t319, label %bb90, label %bb91
bb90:
  %t321 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t321, ptr %rv
  br label %ret
bb91:
  br label %bb92
bb92:
  %t323 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t323, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t325 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t325, 0
  store i64 %t327, ptr %l17, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s14
  %t329 = load i64, ptr %l16, !tbaa !24
  %t330 = load i64, ptr %l17, !tbaa !24
  %t333 = icmp slt i64 %t329, %t330
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s14)
  br label %bb100
bb95:
  br label %bb96
bb96:
  %t337 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t337, ptr %l183, !tbaa !27
  %t338 = load i64, ptr %l16, !tbaa !24
  %t340 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr ptr, ptr %t341, i64 %t338
  %t343 = load ptr, ptr %t342, !tbaa !39
  store ptr %l2, ptr %l186, !tbaa !29
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t350 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %v4, ptr %t345, ptr %t343)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t350, ptr %l190
  br label %bb97
bb97:
  %t351 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l190
  %t352 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t351, ptr %t352
  %t353 = load ptr, ptr %l186, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t353, ptr %t352)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s14)
  br label %bb99
bb99:
  %t355 = load i64, ptr %l16, !tbaa !24
  %t358 = add i64 %t355, 1
  store i64 %t358, ptr %l16, !tbaa !24
  br label %bb93
bb100:
  br label %bb205
bb101:
  %t360 = load ptr, ptr %l1, !tbaa !29
  store ptr %t360, ptr %l195, !tbaa !29
  store i1 false, ptr %l196, !tbaa !21
  %t361 = load ptr, ptr %l195, !tbaa !29
  %t362 = icmp ne ptr %t361, null
  br i1 %t362, label %bb102, label %bb103
bb102:
  %t364 = load ptr, ptr %l195, !tbaa !29
  %t365 = load i64, ptr %t364, !range !{i64 0, i64 18}
  %t367 = icmp eq i64 %t365, 10
  store i1 %t367, ptr %l196, !tbaa !21
  br label %bb103
bb103:
  %t368 = load i1, ptr %l196, !tbaa !21
  br i1 %t368, label %bb104, label %bb105
bb104:
  %t369 = load ptr, ptr %l1, !tbaa !29
  %t371 = getelementptr { i64, [5 x i64] }, ptr %t369, i32 0, i32 1
  %t372 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t371, i32 0, i32 2
  %t373 = load ptr, ptr %t372
  store ptr %t373, ptr %l19, !tbaa !29
  br label %bb106
bb105:
  br label %bb110
bb106:
  store %olang.scope zeroinitializer, ptr %s16
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load ptr, ptr %l19, !tbaa !29
  %t378 = getelementptr %"compiler/typed:Slice", ptr %t376, i32 0, i32 1
  %t379 = load ptr, ptr %t378, !tbaa !29
  %t383 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s16, ptr %v3, ptr %v4, ptr %t375, ptr %t379)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t383, ptr %l205
  br label %bb107
bb107:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load ptr, ptr %l19, !tbaa !29
  %t387 = getelementptr %"compiler/typed:Slice", ptr %t385, i32 0, i32 2
  %t388 = load ptr, ptr %t387, !tbaa !29
  %t392 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s16, ptr %v3, ptr %v4, ptr %t384, ptr %t388)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t392, ptr %l210
  br label %bb108
bb108:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load ptr, ptr %l19, !tbaa !29
  %t396 = getelementptr %"compiler/typed:Slice", ptr %t394, i32 0, i32 0
  %t397 = load ptr, ptr %t396, !tbaa !29
  %t400 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t393, ptr %t397)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t400, ptr %l214
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s16)
  %t401 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l214
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t401, ptr %rv
  br label %ret
bb110:
  %t402 = load ptr, ptr %l1, !tbaa !29
  store ptr %t402, ptr %l215, !tbaa !29
  store i1 false, ptr %l216, !tbaa !21
  %t403 = load ptr, ptr %l215, !tbaa !29
  %t404 = icmp ne ptr %t403, null
  br i1 %t404, label %bb111, label %bb112
bb111:
  %t406 = load ptr, ptr %l215, !tbaa !29
  %t407 = load i64, ptr %t406, !range !{i64 0, i64 18}
  %t409 = icmp eq i64 %t407, 11
  store i1 %t409, ptr %l216, !tbaa !21
  br label %bb112
bb112:
  %t410 = load i1, ptr %l216, !tbaa !21
  br i1 %t410, label %bb113, label %bb114
bb113:
  %t411 = load ptr, ptr %l1, !tbaa !29
  %t413 = getelementptr { i64, [5 x i64] }, ptr %t411, i32 0, i32 1
  %t414 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t413, i32 0, i32 2
  %t415 = load ptr, ptr %t414
  store ptr %t415, ptr %l20, !tbaa !29
  br label %bb115
bb114:
  br label %bb121
bb115:
  store %olang.scope zeroinitializer, ptr %s17
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load ptr, ptr %l20, !tbaa !29
  %t420 = getelementptr %"compiler/typed:Cond", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t425 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s17, ptr %v3, ptr %v4, ptr %t417, ptr %t421)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t425, ptr %l225
  br label %bb116
bb116:
  store ptr %l2, ptr %l226, !tbaa !29
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l20, !tbaa !29
  %t429 = getelementptr %"compiler/typed:Cond", ptr %t427, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t433 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %v4, ptr %t426, ptr %t430)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t433, ptr %l230
  br label %bb117
bb117:
  %t434 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l230
  %t435 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t434, ptr %t435
  %t436 = load ptr, ptr %l226, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t436, ptr %t435)
  br label %bb118
bb118:
  store ptr %l2, ptr %l232, !tbaa !29
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load ptr, ptr %l20, !tbaa !29
  %t441 = getelementptr %"compiler/typed:Cond", ptr %t439, i32 0, i32 2
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t446 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %v4, ptr %t438, ptr %t442)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t446, ptr %l237
  br label %bb119
bb119:
  %t447 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l237
  %t448 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t447, ptr %t448
  %t449 = load ptr, ptr %l232, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t449, ptr %t448)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s17)
  br label %bb205
bb121:
  %t451 = load ptr, ptr %l1, !tbaa !29
  store ptr %t451, ptr %l239, !tbaa !29
  store i1 false, ptr %l240, !tbaa !21
  %t452 = load ptr, ptr %l239, !tbaa !29
  %t453 = icmp ne ptr %t452, null
  br i1 %t453, label %bb122, label %bb123
bb122:
  %t455 = load ptr, ptr %l239, !tbaa !29
  %t456 = load i64, ptr %t455, !range !{i64 0, i64 18}
  %t458 = icmp eq i64 %t456, 12
  store i1 %t458, ptr %l240, !tbaa !21
  br label %bb123
bb123:
  %t459 = load i1, ptr %l240, !tbaa !21
  br i1 %t459, label %bb124, label %bb125
bb124:
  %t460 = load ptr, ptr %l1, !tbaa !29
  %t462 = getelementptr { i64, [5 x i64] }, ptr %t460, i32 0, i32 1
  %t463 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t462, i32 0, i32 2
  %t464 = load ptr, ptr %t463
  store ptr %t464, ptr %l21, !tbaa !29
  br label %bb126
bb125:
  br label %bb135
bb126:
  %t466 = load ptr, ptr %l21, !tbaa !29
  %t468 = getelementptr %"compiler/typed:Seq", ptr %t466, i32 0, i32 0
  %t469 = load { i64, ptr }, ptr %t468, !tbaa !27
  store { i64, ptr } %t469, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t471 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t471, 0
  store i64 %t473, ptr %l24, !tbaa !24
  br label %bb127
bb127:
  %t475 = load i64, ptr %l23, !tbaa !24
  %t476 = load i64, ptr %l24, !tbaa !24
  %t479 = icmp slt i64 %t475, %t476
  %t481 = xor i1 %t479, true
  br i1 %t481, label %bb128, label %bb129
bb128:
  br label %bb133
bb129:
  br label %bb130
bb130:
  %t483 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t483, ptr %l253, !tbaa !27
  %t484 = load i64, ptr %l23, !tbaa !24
  %t486 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t487 = load ptr, ptr %t486, !tbaa !27
  %t488 = getelementptr ptr, ptr %t487, i64 %t484
  %t489 = load ptr, ptr %t488, !tbaa !39
  %t491 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estmt(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t491, ptr %t489)
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t495 = load i64, ptr %l23, !tbaa !24
  %t498 = add i64 %t495, 1
  store i64 %t498, ptr %l23, !tbaa !24
  br label %bb127
bb133:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t501 = load ptr, ptr %l21, !tbaa !29
  %t503 = getelementptr %"compiler/typed:Seq", ptr %t501, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !29
  %t507 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t500, ptr %t504)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t507, ptr %l264
  br label %bb134
bb134:
  %t508 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l264
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t508, ptr %rv
  br label %ret
bb135:
  %t509 = load ptr, ptr %l1, !tbaa !29
  store ptr %t509, ptr %l265, !tbaa !29
  store i1 false, ptr %l266, !tbaa !21
  %t510 = load ptr, ptr %l265, !tbaa !29
  %t511 = icmp ne ptr %t510, null
  br i1 %t511, label %bb136, label %bb137
bb136:
  %t513 = load ptr, ptr %l265, !tbaa !29
  %t514 = load i64, ptr %t513, !range !{i64 0, i64 18}
  %t516 = icmp eq i64 %t514, 13
  store i1 %t516, ptr %l266, !tbaa !21
  br label %bb137
bb137:
  %t517 = load i1, ptr %l266, !tbaa !21
  br i1 %t517, label %bb138, label %bb139
bb138:
  %t518 = load ptr, ptr %l1, !tbaa !29
  %t520 = getelementptr { i64, [5 x i64] }, ptr %t518, i32 0, i32 1
  %t521 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t520, i32 0, i32 2
  %t522 = load ptr, ptr %t521
  store ptr %t522, ptr %l26, !tbaa !29
  br label %bb140
bb139:
  br label %bb142
bb140:
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load ptr, ptr %l26, !tbaa !29
  %t528 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ematch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t524, ptr %t525)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t528, ptr %l273
  br label %bb141
bb141:
  %t529 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l273
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t529, ptr %rv
  br label %ret
bb142:
  %t530 = load ptr, ptr %l1, !tbaa !29
  store ptr %t530, ptr %l274, !tbaa !29
  store i1 false, ptr %l275, !tbaa !21
  %t531 = load ptr, ptr %l274, !tbaa !29
  %t532 = icmp ne ptr %t531, null
  br i1 %t532, label %bb143, label %bb144
bb143:
  %t534 = load ptr, ptr %l274, !tbaa !29
  %t535 = load i64, ptr %t534, !range !{i64 0, i64 18}
  %t537 = icmp eq i64 %t535, 14
  store i1 %t537, ptr %l275, !tbaa !21
  br label %bb144
bb144:
  %t538 = load i1, ptr %l275, !tbaa !21
  br i1 %t538, label %bb145, label %bb146
bb145:
  %t539 = load ptr, ptr %l1, !tbaa !29
  %t541 = getelementptr { i64, [5 x i64] }, ptr %t539, i32 0, i32 1
  %t542 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t541, i32 0, i32 2
  %t543 = load ptr, ptr %t542
  store ptr %t543, ptr %l27, !tbaa !29
  br label %bb147
bb146:
  br label %bb168
bb147:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load ptr, ptr %l27, !tbaa !29
  %t548 = getelementptr %"compiler/typed:Try", ptr %t546, i32 0, i32 0
  %t549 = load ptr, ptr %t548, !tbaa !29
  %t552 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t545, ptr %t549)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t552, ptr %l283
  br label %bb148
bb148:
  %t553 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t553, ptr %l284
  %t554 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l283
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t554, ptr %l2
  %t555 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aholdWalk__2erefs_2elocal_2e2
  br i1 %t555, label %bb149, label %bb150
bb149:
  %t557 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l284, i32 0, i32 0
  %t558 = load { i64, ptr }, ptr %t557
  %t559 = extractvalue { i64, ptr } %t558, 1
  %t560 = call ptr @__olang_region_or(ptr %t559, ptr null)
  %t561 = call ptr @__olang_region_home(ptr %t560)
  %t562 = icmp ne ptr %t561, null
  %t563 = select i1 %t562, ptr %t561, ptr null
  call void @__olang_region_drop(ptr %t563)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l284
  br label %bb150
bb150:
  %t564 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t564, label %bb151, label %bb152
bb151:
  %t566 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l284, i32 0, i32 0
  %t567 = load { i64, ptr }, ptr %t566
  %t568 = extractvalue { i64, ptr } %t567, 0
  %t569 = extractvalue { i64, ptr } %t567, 1
  call void @__olang_region_release_part(ptr %t569, i64 %t568)
  store { i64, ptr } zeroinitializer, ptr %t566
  br label %bb152
bb152:
  %t570 = load ptr, ptr %l27, !tbaa !29
  %t572 = getelementptr %"compiler/typed:Try", ptr %t570, i32 0, i32 1
  %t573 = load { i64, ptr }, ptr %t572, !tbaa !27
  store { i64, ptr } %t573, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t575 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t577 = extractvalue { i64, ptr } %t575, 0
  store i64 %t577, ptr %l30, !tbaa !24
  br label %bb153
bb153:
  %t579 = load i64, ptr %l29, !tbaa !24
  %t580 = load i64, ptr %l30, !tbaa !24
  %t583 = icmp slt i64 %t579, %t580
  %t585 = xor i1 %t583, true
  br i1 %t585, label %bb154, label %bb155
bb154:
  br label %bb167
bb155:
  br label %bb156
bb156:
  %t587 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t587, ptr %l295, !tbaa !27
  %t588 = load i64, ptr %l29, !tbaa !24
  %t590 = getelementptr { i64, ptr }, ptr %l295, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr ptr, ptr %t591, i64 %t588
  %t593 = load ptr, ptr %t592, !tbaa !39
  store ptr %t593, ptr %l31, !tbaa !29
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load ptr, ptr %l31, !tbaa !29
  %t598 = getelementptr %"compiler/typed:Clause", ptr %t596, i32 0, i32 3
  %t599 = load ptr, ptr %t598, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t595, ptr %t599)
  br label %bb157
bb157:
  %t602 = load ptr, ptr %l31, !tbaa !29
  %t604 = getelementptr %"compiler/typed:Clause", ptr %t602, i32 0, i32 4
  %t605 = load { i64, ptr }, ptr %t604, !tbaa !27
  store { i64, ptr } %t605, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t607 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t609 = extractvalue { i64, ptr } %t607, 0
  store i64 %t609, ptr %l34, !tbaa !24
  br label %bb158
bb158:
  store %olang.scope zeroinitializer, ptr %s27
  %t611 = load i64, ptr %l33, !tbaa !24
  %t612 = load i64, ptr %l34, !tbaa !24
  %t615 = icmp slt i64 %t611, %t612
  %t617 = xor i1 %t615, true
  br i1 %t617, label %bb159, label %bb160
bb159:
  call void @__olang_scope_close(ptr %s27)
  br label %bb165
bb160:
  br label %bb161
bb161:
  %t619 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t619, ptr %l309, !tbaa !27
  %t620 = load i64, ptr %l33, !tbaa !24
  %t622 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t623 = load ptr, ptr %t622, !tbaa !27
  %t624 = getelementptr ptr, ptr %t623, i64 %t620
  %t625 = load ptr, ptr %t624, !tbaa !39
  store ptr %l2, ptr %l312, !tbaa !29
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t632 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %v4, ptr %t627, ptr %t625)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t632, ptr %l316
  br label %bb162
bb162:
  %t633 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l316
  %t634 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t633, ptr %t634
  %t635 = load ptr, ptr %l312, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t635, ptr %t634)
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s27)
  br label %bb164
bb164:
  %t637 = load i64, ptr %l33, !tbaa !24
  %t640 = add i64 %t637, 1
  store i64 %t640, ptr %l33, !tbaa !24
  br label %bb158
bb165:
  br label %bb166
bb166:
  %t642 = load i64, ptr %l29, !tbaa !24
  %t645 = add i64 %t642, 1
  store i64 %t645, ptr %l29, !tbaa !24
  br label %bb153
bb167:
  br label %bb205
bb168:
  %t647 = load ptr, ptr %l1, !tbaa !29
  store ptr %t647, ptr %l324, !tbaa !29
  store i1 false, ptr %l325, !tbaa !21
  %t648 = load ptr, ptr %l324, !tbaa !29
  %t649 = icmp ne ptr %t648, null
  br i1 %t649, label %bb169, label %bb170
bb169:
  %t651 = load ptr, ptr %l324, !tbaa !29
  %t652 = load i64, ptr %t651, !range !{i64 0, i64 18}
  %t654 = icmp eq i64 %t652, 15
  store i1 %t654, ptr %l325, !tbaa !21
  br label %bb170
bb170:
  %t655 = load i1, ptr %l325, !tbaa !21
  br i1 %t655, label %bb171, label %bb172
bb171:
  %t656 = load ptr, ptr %l1, !tbaa !29
  %t658 = getelementptr { i64, [5 x i64] }, ptr %t656, i32 0, i32 1
  %t659 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t658, i32 0, i32 2
  %t660 = load ptr, ptr %t659
  store ptr %t660, ptr %l36, !tbaa !29
  br label %bb173
bb172:
  br label %bb175
bb173:
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t663 = load ptr, ptr %l36, !tbaa !29
  %t666 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2efnVal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t662, ptr %t663)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t666, ptr %l332
  br label %bb174
bb174:
  %t667 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l332
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t667, ptr %rv
  br label %ret
bb175:
  %t668 = load ptr, ptr %l1, !tbaa !29
  store ptr %t668, ptr %l333, !tbaa !29
  store i1 false, ptr %l334, !tbaa !21
  %t669 = load ptr, ptr %l333, !tbaa !29
  %t670 = icmp ne ptr %t669, null
  br i1 %t670, label %bb176, label %bb177
bb176:
  %t672 = load ptr, ptr %l333, !tbaa !29
  %t673 = load i64, ptr %t672, !range !{i64 0, i64 18}
  %t675 = icmp eq i64 %t673, 16
  store i1 %t675, ptr %l334, !tbaa !21
  br label %bb177
bb177:
  %t676 = load i1, ptr %l334, !tbaa !21
  br i1 %t676, label %bb178, label %bb179
bb178:
  %t677 = load ptr, ptr %l1, !tbaa !29
  %t679 = getelementptr { i64, [5 x i64] }, ptr %t677, i32 0, i32 1
  %t680 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t679, i32 0, i32 2
  %t681 = load ptr, ptr %t680
  store ptr %t681, ptr %l37, !tbaa !29
  br label %bb180
bb179:
  br label %bb193
bb180:
  %t683 = load ptr, ptr %l37, !tbaa !29
  %t685 = getelementptr %"compiler/typed:Text", ptr %t683, i32 0, i32 0
  %t686 = load { i64, ptr }, ptr %t685, !tbaa !27
  store { i64, ptr } %t686, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t688 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t690 = extractvalue { i64, ptr } %t688, 0
  store i64 %t690, ptr %l40, !tbaa !24
  br label %bb181
bb181:
  %t692 = load i64, ptr %l39, !tbaa !24
  %t693 = load i64, ptr %l40, !tbaa !24
  %t696 = icmp slt i64 %t692, %t693
  %t698 = xor i1 %t696, true
  br i1 %t698, label %bb182, label %bb183
bb182:
  br label %bb192
bb183:
  br label %bb184
bb184:
  %t700 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t700, ptr %l347, !tbaa !27
  %t701 = load i64, ptr %l39, !tbaa !24
  %t703 = getelementptr { i64, ptr }, ptr %l347, i32 0, i32 1
  %t704 = load ptr, ptr %t703, !tbaa !27
  %t705 = getelementptr ptr, ptr %t704, i64 %t701
  %t706 = load ptr, ptr %t705, !tbaa !39
  store ptr %t706, ptr %l41, !tbaa !29
  %t708 = load ptr, ptr %l41, !tbaa !29
  store ptr %t708, ptr %l350, !tbaa !29
  store i1 false, ptr %l351, !tbaa !21
  %t709 = load ptr, ptr %l350, !tbaa !29
  %t710 = icmp ne ptr %t709, null
  br i1 %t710, label %bb185, label %bb186
bb185:
  %t712 = load ptr, ptr %l350, !tbaa !29
  %t713 = load i64, ptr %t712, !range !{i64 0, i64 2}
  %t715 = icmp eq i64 %t713, 1
  store i1 %t715, ptr %l351, !tbaa !21
  br label %bb186
bb186:
  %t716 = load i1, ptr %l351, !tbaa !21
  br i1 %t716, label %bb187, label %bb188
bb187:
  store %olang.scope zeroinitializer, ptr %s34
  %t717 = load ptr, ptr %l41, !tbaa !29
  %t719 = getelementptr { i64, [2 x i64] }, ptr %t717, i32 0, i32 1
  %t720 = getelementptr { ptr }, ptr %t719, i32 0, i32 0
  %t721 = load ptr, ptr %t720
  %t723 = load ptr, ptr %l0, !tbaa !29
  %t728 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s34, ptr %v3, ptr %v4, ptr %t723, ptr %t721)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t728, ptr %l359
  br label %bb189
bb188:
  br label %bb190
bb189:
  call void @__olang_scope_close(ptr %s34)
  br label %bb190
bb190:
  br label %bb191
bb191:
  %t729 = load i64, ptr %l39, !tbaa !24
  %t732 = add i64 %t729, 1
  store i64 %t732, ptr %l39, !tbaa !24
  br label %bb181
bb192:
  br label %bb205
bb193:
  %t734 = load ptr, ptr %l1, !tbaa !29
  store ptr %t734, ptr %l363, !tbaa !29
  store i1 false, ptr %l364, !tbaa !21
  %t735 = load ptr, ptr %l363, !tbaa !29
  %t736 = icmp ne ptr %t735, null
  br i1 %t736, label %bb194, label %bb195
bb194:
  %t738 = load ptr, ptr %l363, !tbaa !29
  %t739 = load i64, ptr %t738, !range !{i64 0, i64 18}
  %t741 = icmp eq i64 %t739, 17
  store i1 %t741, ptr %l364, !tbaa !21
  br label %bb195
bb195:
  %t742 = load i1, ptr %l364, !tbaa !21
  br i1 %t742, label %bb196, label %bb197
bb196:
  %t743 = load ptr, ptr %l1, !tbaa !29
  %t745 = getelementptr { i64, [5 x i64] }, ptr %t743, i32 0, i32 1
  %t746 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t745, i32 0, i32 2
  %t747 = load ptr, ptr %t746
  store ptr %t747, ptr %l43, !tbaa !29
  br label %bb198
bb197:
  br label %bb200
bb198:
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t750 = load ptr, ptr %l43, !tbaa !29
  %t754 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t749, ptr %t750)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t754, ptr %l372
  br label %bb199
bb199:
  %t755 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l372
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t755, ptr %rv
  br label %ret
bb200:
  br i1 true, label %bb201, label %bb202
bb201:
  br label %bb203
bb202:
  br label %bb204
bb203:
  br label %bb205
bb204:
  call void @__olang_check_failed(ptr @olang_loc_7e259cde601a72ba_d3d8f3b52bf79a7e)
  unreachable
bb205:
  %t756 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t756, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregister(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i1
  %l49 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca i32
  %l68 = alloca i1
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l79 = alloca i1
  %l83 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:holdWalk", ptr %t6, i32 0, i32 10
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load i64, ptr %l14, !tbaa !24
  store i64 %t11, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l9, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:holdWalk", ptr %t58, i32 0, i32 10
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l42
  br label %bb12
bb12:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l42, !tbaa !24
  %t68 = icmp eq i64 %t66, %t65
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:holdWalk", ptr %t70, i32 0, i32 11
  %t73 = load i64, ptr %l9, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t73)
  store i64 %t76, ptr %l49
  br label %bb15
bb14:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb16
bb15:
  %t77 = load i64, ptr %l1, !tbaa !24
  %t78 = load i64, ptr %l49, !tbaa !24
  %t80 = icmp eq i64 %t78, %t77
  store i1 %t80, ptr %l45, !tbaa !21
  br label %bb16
bb16:
  %t82 = load i1, ptr %l45, !tbaa !21
  br i1 %t82, label %bb17, label %bb18
bb17:
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t86 = add i64 %t83, 1
  store i64 %t86, ptr %l8, !tbaa !24
  br label %bb8
bb21:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/typed:holdWalk", ptr %t88, i32 0, i32 10
  %t91 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t90, i64 %t91)
  br label %bb22
bb22:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/typed:holdWalk", ptr %t94, i32 0, i32 11
  %t97 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t96, i64 %t97)
  br label %bb23
bb23:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/typed:holdWalk", ptr %t100, i32 0, i32 12
  store ptr %t102, ptr %l62, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2einBlock(ptr %v0, ptr %t103)
  store i32 %t105, ptr %l64
  br label %bb24
bb24:
  %t106 = load ptr, ptr %l62, !tbaa !29
  %t107 = load i32, ptr %l64, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t106, i32 %t107)
  br label %bb25
bb25:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/typed:holdWalk", ptr %t108, i32 0, i32 9
  %t111 = load i64, ptr %l1, !tbaa !24
  %t114 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t110, i64 %t111)
  store i1 %t114, ptr %l68
  br label %bb26
bb26:
  %t115 = load i1, ptr %l68, !tbaa !21
  %t116 = xor i1 %t115, true
  br i1 %t116, label %bb27, label %bb28
bb27:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/typed:holdWalk", ptr %t118, i32 0, i32 9
  %t121 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t120, i64 %t121)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/typed:holdWalk", ptr %t124, i32 0, i32 2
  %t127 = load i64, ptr %l1, !tbaa !24
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t126, i64 %t127)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l76
  br label %bb31
bb31:
  %t131 = load i64, ptr %l1, !tbaa !24
  %t134 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %l76, i64 %t131)
  store i1 %t134, ptr %l79
  br label %bb32
bb32:
  %t135 = load i1, ptr %l79, !tbaa !21
  br i1 %t135, label %bb33, label %bb34
bb33:
  br label %ret
bb34:
  br label %bb35
bb35:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/typed:holdWalk", ptr %t136, i32 0, i32 2
  %t139 = load i64, ptr %l1, !tbaa !24
  %t142 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v0, ptr %t138, i64 %t139)
  store ptr %t142, ptr %l83
  br label %bb36
bb36:
  %t143 = load i64, ptr %l1, !tbaa !24
  %t144 = load ptr, ptr %l83, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t144, i64 %t143)
  br label %bb37
bb37:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/typed:holdWalk", ptr %t146, i32 0, i32 3
  store i1 true, ptr %t148, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca ptr
  %l39 = alloca i1
  %l51 = alloca i1
  %l56 = alloca ptr
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca ptr
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca ptr
  %l67 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l80 = alloca i1
  %l90 = alloca i1
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l112 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l125 = alloca ptr
  %l126 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l140 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca ptr
  %l142 = alloca i1
  %l152 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l155 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l156 = alloca ptr
  %l157 = alloca i1
  %l166 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l174 = alloca ptr
  %l175 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i1
  %l207 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l208 = alloca ptr
  %l209 = alloca i1
  %l214 = alloca ptr
  %l215 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca i1
  %l236 = alloca ptr
  %l237 = alloca i1
  %l246 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l255 = alloca { i64, ptr }
  %l261 = alloca ptr
  %l264 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l278 = alloca { i64, ptr }
  %l284 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l288 = alloca ptr
  %l289 = alloca i1
  %l297 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l300 = alloca i64
  %l302 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l305 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l306 = alloca i32
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t2 = load ptr, ptr %l38, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l38, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l39, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l39, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb14
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t33 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %v2, ptr %t28, ptr %t29)
  store i1 %t33, ptr %l51
  br label %bb6
bb6:
  %t34 = load i1, ptr %l51, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t38 = sext i32 %t36 to i64
  %t39 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregister(ptr %v0, ptr %t35, i64 %t38, %"compiler/source:Span" %t39)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l56, !tbaa !29
  %t44 = load i32, ptr %l3, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t48 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %s1, i64 %t46)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l59
  br label %bb11
bb11:
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  %t50 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %t50
  store ptr %t50, ptr %l60, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t56 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %s1, ptr %v2, ptr %v3, ptr %t51, ptr %t52)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l64
  br label %bb12
bb12:
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  %t58 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %t58
  %t59 = load ptr, ptr %l56, !tbaa !29
  %t60 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %v3, ptr %v2, ptr %t59, ptr %t60, ptr %t58)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb168
bb14:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t63 = load ptr, ptr %l66, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t66 = load ptr, ptr %l66, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 17}
  %t69 = icmp eq i64 %t67, 1
  store i1 %t69, ptr %l67, !tbaa !21
  br label %bb16
bb16:
  %t70 = load i1, ptr %l67, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t73, i32 0, i32 0
  %t75 = load %"compiler/source:Span", ptr %t74
  store %"compiler/source:Span" %t75, ptr %l5
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t79, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l6, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [3 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l7, !tbaa !29
  br label %bb19
bb18:
  br label %bb46
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t89 = load ptr, ptr %l6, !tbaa !29
  store ptr %t89, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t90 = load ptr, ptr %l76, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb20, label %bb21
bb20:
  %t93 = load ptr, ptr %l76, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 0
  store i1 %t96, ptr %l77, !tbaa !21
  br label %bb21
bb21:
  %t97 = load i1, ptr %l77, !tbaa !21
  br i1 %t97, label %bb22, label %bb23
bb22:
  %t98 = load ptr, ptr %l6, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t100, i32 0, i32 0
  %t102 = load %"compiler/source:Span", ptr %t101
  store %"compiler/source:Span" %t102, ptr %l8
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t106, i32 0, i32 1
  %t108 = load i32, ptr %t107
  store i32 %t108, ptr %l9, !tbaa !23
  %t110 = load ptr, ptr %l6, !tbaa !29
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t112, i32 0, i32 2
  %t114 = load i32, ptr %t113
  store i32 %t114, ptr %l10, !tbaa !23
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l7, !tbaa !29
  %t121 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %v2, ptr %t116, ptr %t117)
  store i1 %t121, ptr %l90
  br label %bb24
bb23:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb25
bb24:
  %t122 = load i1, ptr %l90, !tbaa !21
  store i1 %t122, ptr %l80, !tbaa !21
  br label %bb25
bb25:
  %t123 = load i1, ptr %l80, !tbaa !21
  br i1 %t123, label %bb26, label %bb27
bb26:
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t126, i32 0, i32 0
  %t128 = load %"compiler/source:Span", ptr %t127
  store %"compiler/source:Span" %t128, ptr %l11
  %t130 = load ptr, ptr %l6, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t132, i32 0, i32 1
  %t134 = load i32, ptr %t133
  store i32 %t134, ptr %l12, !tbaa !23
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t138, i32 0, i32 2
  %t140 = load i32, ptr %t139
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t145 = sext i32 %t140 to i64
  %t146 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregister(ptr %v0, ptr %t142, i64 %t145, %"compiler/source:Span" %t146)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t154 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %s3, ptr %v2, ptr %v3, ptr %t150, ptr %t151)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %l103
  br label %bb30
bb30:
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %l14
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/typed:holdWalk", ptr %t156, i32 0, i32 4
  store ptr %t158, ptr %l105, !tbaa !29
  %t160 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s3, ptr %s3, ptr %l14)
  store { i64, ptr } %t160, ptr %l107
  br label %bb31
bb31:
  %t161 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t162 = load ptr, ptr %l105, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v0, ptr %t162, { i64, ptr } %t161)
  br label %bb32
bb32:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l7, !tbaa !29
  %t169 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %s3, ptr %v2, ptr %v3, ptr %t164, ptr %t165)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t169, ptr %l112
  br label %bb33
bb33:
  %t170 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l15
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/typed:holdWalk", ptr %t171, i32 0, i32 4
  %t175 = call { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePop_3cArray_3cI64_3e_3e(ptr %v0, ptr %s3, ptr %t173)
  %t176 = extractvalue { i32, { i64, ptr } } %t175, 1
  %t177 = extractvalue { i32, { i64, ptr } } %t175, 0
  store i32 %t177, ptr %l117
  %t178 = icmp ne i32 %t177, 0
  br i1 %t178, label %bb35, label %ok.179, !prof !99
ok.179:
  store { i64, ptr } %t176, ptr %l116
  br label %bb34
bb34:
  %t180 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t180, ptr %l113, !tbaa !27
  br label %bb42
bb35:
  %t181 = load i32, ptr %l117, !tbaa !23
  %t182 = icmp eq i32 %t181, 65536
  br i1 %t182, label %bb36, label %bb37
bb36:
  call void @__olang_bang_failed_plain(ptr @olang_loc_96ed7c0737fb007f_bcf36b4956f76d4b)
  unreachable
bb37:
  %t184 = load i32, ptr %l117, !tbaa !23
  %t185 = icmp eq i32 %t184, 65537
  br i1 %t185, label %bb38, label %bb39
bb38:
  call void @__olang_bang_failed_plain(ptr @olang_loc_eee80033d1164c3c_3495c4b80935428)
  unreachable
bb39:
  %t187 = load i32, ptr %l117, !tbaa !23
  %t188 = icmp eq i32 %t187, 65538
  br i1 %t188, label %bb40, label %bb41
bb40:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d52aab1c9c36d4_17087f4c711c4240)
  unreachable
bb41:
  call void @__olang_bang_failed_plain(ptr @olang_loc_fe54fd99e9902812_25d1b4e50c46612e)
  unreachable
bb42:
  %t190 = load i1, ptr @olang_2esole_2eArray_3cArray_3cI64_3e_3e_2e_2d1
  br i1 %t190, label %bb43, label %bb44
bb43:
  %t192 = load { i64, ptr }, ptr %l113
  %t193 = extractvalue { i64, ptr } %t192, 0
  %t194 = extractvalue { i64, ptr } %t192, 1
  call void @__olang_region_release_part(ptr %t194, i64 %t193)
  store { i64, ptr } zeroinitializer, ptr %l113
  br label %bb44
bb44:
  %t195 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estore(ptr %v0, ptr %s3, ptr %s3, ptr %v3, ptr %v2, ptr %t195, ptr %l14, ptr %l15)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s3)
  br label %bb168
bb46:
  %t199 = load ptr, ptr %l1, !tbaa !29
  store ptr %t199, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t200 = load ptr, ptr %l125, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb47, label %bb48
bb47:
  %t203 = load ptr, ptr %l125, !tbaa !29
  %t204 = load i64, ptr %t203, !range !{i64 0, i64 17}
  %t206 = icmp eq i64 %t204, 2
  store i1 %t206, ptr %l126, !tbaa !21
  br label %bb48
bb48:
  %t207 = load i1, ptr %l126, !tbaa !21
  br i1 %t207, label %bb49, label %bb50
bb49:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr { i64, [3 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { %"compiler/source:Span", ptr }, ptr %t210, i32 0, i32 1
  %t212 = load ptr, ptr %t211
  store ptr %t212, ptr %l16, !tbaa !29
  br label %bb55
bb50:
  %t214 = load ptr, ptr %l1, !tbaa !29
  store ptr %t214, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t215 = load ptr, ptr %l131, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb51, label %bb52
bb51:
  %t218 = load ptr, ptr %l131, !tbaa !29
  %t219 = load i64, ptr %t218, !range !{i64 0, i64 17}
  %t221 = icmp eq i64 %t219, 8
  store i1 %t221, ptr %l132, !tbaa !21
  br label %bb52
bb52:
  %t222 = load i1, ptr %l132, !tbaa !21
  br i1 %t222, label %bb53, label %bb54
bb53:
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr { i64, [3 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t225, i32 0, i32 1
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l16, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  store %olang.scope zeroinitializer, ptr %s5
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l16, !tbaa !29
  %t234 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s5, ptr %v2, ptr %v3, ptr %t229, ptr %t230)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %l140
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s5)
  br label %bb168
bb57:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t236 = load ptr, ptr %l141, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb58, label %bb59
bb58:
  %t239 = load ptr, ptr %l141, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 17}
  %t242 = icmp eq i64 %t240, 10
  store i1 %t242, ptr %l142, !tbaa !21
  br label %bb59
bb59:
  %t243 = load i1, ptr %l142, !tbaa !21
  br i1 %t243, label %bb60, label %bb61
bb60:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t246, i32 0, i32 1
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l17, !tbaa !29
  %t250 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr { i64, [3 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t252, i32 0, i32 2
  %t254 = load ptr, ptr %t253
  store ptr %t254, ptr %l18, !tbaa !29
  br label %bb62
bb61:
  br label %bb65
bb62:
  store %olang.scope zeroinitializer, ptr %s6
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load ptr, ptr %l17, !tbaa !29
  %t261 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s6, ptr %v2, ptr %v3, ptr %t256, ptr %t257)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t261, ptr %l152
  br label %bb63
bb63:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l18, !tbaa !29
  %t266 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s6, ptr %v2, ptr %v3, ptr %t262, ptr %t263)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %l155
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb65:
  %t267 = load ptr, ptr %l1, !tbaa !29
  store ptr %t267, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t268 = load ptr, ptr %l156, !tbaa !29
  %t269 = icmp ne ptr %t268, null
  br i1 %t269, label %bb66, label %bb67
bb66:
  %t271 = load ptr, ptr %l156, !tbaa !29
  %t272 = load i64, ptr %t271, !range !{i64 0, i64 17}
  %t274 = icmp eq i64 %t272, 3
  store i1 %t274, ptr %l157, !tbaa !21
  br label %bb67
bb67:
  %t275 = load i1, ptr %l157, !tbaa !21
  br i1 %t275, label %bb68, label %bb69
bb68:
  %t276 = load ptr, ptr %l1, !tbaa !29
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t276, i32 0, i32 1
  %t279 = getelementptr { %"compiler/source:Span", ptr }, ptr %t278, i32 0, i32 1
  %t280 = load ptr, ptr %t279
  store ptr %t280, ptr %l19, !tbaa !29
  br label %bb70
bb69:
  br label %bb74
bb70:
  store %olang.scope zeroinitializer, ptr %s7
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load ptr, ptr %l19, !tbaa !29
  %t285 = getelementptr %"compiler/typed:If", ptr %t283, i32 0, i32 0
  %t286 = load ptr, ptr %t285, !tbaa !29
  %t290 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s7, ptr %v2, ptr %v3, ptr %t282, ptr %t286)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t290, ptr %l166
  br label %bb71
bb71:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load ptr, ptr %l19, !tbaa !29
  %t294 = getelementptr %"compiler/typed:If", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t291, ptr %t295)
  br label %bb72
bb72:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load ptr, ptr %l19, !tbaa !29
  %t302 = getelementptr %"compiler/typed:If", ptr %t300, i32 0, i32 2
  %t303 = load ptr, ptr %t302, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t299, ptr %t303)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s7)
  br label %bb168
bb74:
  %t306 = load ptr, ptr %l1, !tbaa !29
  store ptr %t306, ptr %l174, !tbaa !29
  store i1 false, ptr %l175, !tbaa !21
  %t307 = load ptr, ptr %l174, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb75, label %bb76
bb75:
  %t310 = load ptr, ptr %l174, !tbaa !29
  %t311 = load i64, ptr %t310, !range !{i64 0, i64 17}
  %t313 = icmp eq i64 %t311, 4
  store i1 %t313, ptr %l175, !tbaa !21
  br label %bb76
bb76:
  %t314 = load i1, ptr %l175, !tbaa !21
  br i1 %t314, label %bb77, label %bb78
bb77:
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t317 = getelementptr { i64, [3 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t317, i32 0, i32 1
  %t319 = load ptr, ptr %t318
  store ptr %t319, ptr %l20, !tbaa !29
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr { i64, [3 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t323, i32 0, i32 2
  %t325 = load ptr, ptr %t324
  store ptr %t325, ptr %l21, !tbaa !29
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t327, ptr %t328)
  br label %bb80
bb80:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t332, ptr %t333)
  br label %bb81
bb81:
  br label %bb168
bb82:
  %t336 = load ptr, ptr %l1, !tbaa !29
  store ptr %t336, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t337 = load ptr, ptr %l187, !tbaa !29
  %t338 = icmp ne ptr %t337, null
  br i1 %t338, label %bb83, label %bb84
bb83:
  %t340 = load ptr, ptr %l187, !tbaa !29
  %t341 = load i64, ptr %t340, !range !{i64 0, i64 17}
  %t343 = icmp eq i64 %t341, 6
  store i1 %t343, ptr %l188, !tbaa !21
  br label %bb84
bb84:
  %t344 = load i1, ptr %l188, !tbaa !21
  br i1 %t344, label %bb85, label %bb86
bb85:
  %t345 = load ptr, ptr %l1, !tbaa !29
  %t347 = getelementptr { i64, [3 x i64] }, ptr %t345, i32 0, i32 1
  %t348 = getelementptr { %"compiler/source:Span", ptr }, ptr %t347, i32 0, i32 1
  %t349 = load ptr, ptr %t348
  store ptr %t349, ptr %l22, !tbaa !29
  br label %bb95
bb86:
  %t351 = load ptr, ptr %l1, !tbaa !29
  store ptr %t351, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t352 = load ptr, ptr %l193, !tbaa !29
  %t353 = icmp ne ptr %t352, null
  br i1 %t353, label %bb87, label %bb88
bb87:
  %t355 = load ptr, ptr %l193, !tbaa !29
  %t356 = load i64, ptr %t355, !range !{i64 0, i64 17}
  %t358 = icmp eq i64 %t356, 16
  store i1 %t358, ptr %l194, !tbaa !21
  br label %bb88
bb88:
  %t359 = load i1, ptr %l194, !tbaa !21
  br i1 %t359, label %bb89, label %bb90
bb89:
  %t360 = load ptr, ptr %l1, !tbaa !29
  %t362 = getelementptr { i64, [3 x i64] }, ptr %t360, i32 0, i32 1
  %t363 = getelementptr { %"compiler/source:Span", ptr }, ptr %t362, i32 0, i32 1
  %t364 = load ptr, ptr %t363
  store ptr %t364, ptr %l22, !tbaa !29
  br label %bb95
bb90:
  %t366 = load ptr, ptr %l1, !tbaa !29
  store ptr %t366, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t367 = load ptr, ptr %l199, !tbaa !29
  %t368 = icmp ne ptr %t367, null
  br i1 %t368, label %bb91, label %bb92
bb91:
  %t370 = load ptr, ptr %l199, !tbaa !29
  %t371 = load i64, ptr %t370, !range !{i64 0, i64 17}
  %t373 = icmp eq i64 %t371, 9
  store i1 %t373, ptr %l200, !tbaa !21
  br label %bb92
bb92:
  %t374 = load i1, ptr %l200, !tbaa !21
  br i1 %t374, label %bb93, label %bb94
bb93:
  %t375 = load ptr, ptr %l1, !tbaa !29
  %t377 = getelementptr { i64, [3 x i64] }, ptr %t375, i32 0, i32 1
  %t378 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t377, i32 0, i32 2
  %t379 = load ptr, ptr %t378
  store ptr %t379, ptr %l22, !tbaa !29
  br label %bb95
bb94:
  br label %bb97
bb95:
  store %olang.scope zeroinitializer, ptr %s9
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l22, !tbaa !29
  %t385 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s9, ptr %v2, ptr %v3, ptr %t381, ptr %t382)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t385, ptr %l207
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s9)
  br label %bb168
bb97:
  %t386 = load ptr, ptr %l1, !tbaa !29
  store ptr %t386, ptr %l208, !tbaa !29
  store i1 false, ptr %l209, !tbaa !21
  %t387 = load ptr, ptr %l208, !tbaa !29
  %t388 = icmp ne ptr %t387, null
  br i1 %t388, label %bb98, label %bb99
bb98:
  %t390 = load ptr, ptr %l208, !tbaa !29
  %t391 = load i64, ptr %t390, !range !{i64 0, i64 17}
  %t393 = icmp eq i64 %t391, 11
  store i1 %t393, ptr %l209, !tbaa !21
  br label %bb99
bb99:
  %t394 = load i1, ptr %l209, !tbaa !21
  br i1 %t394, label %bb100, label %bb101
bb100:
  %t395 = load ptr, ptr %l1, !tbaa !29
  %t397 = getelementptr { i64, [3 x i64] }, ptr %t395, i32 0, i32 1
  %t398 = getelementptr { %"compiler/source:Span", ptr }, ptr %t397, i32 0, i32 1
  %t399 = load ptr, ptr %t398
  store ptr %t399, ptr %l23, !tbaa !29
  br label %bb106
bb101:
  %t401 = load ptr, ptr %l1, !tbaa !29
  store ptr %t401, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t402 = load ptr, ptr %l214, !tbaa !29
  %t403 = icmp ne ptr %t402, null
  br i1 %t403, label %bb102, label %bb103
bb102:
  %t405 = load ptr, ptr %l214, !tbaa !29
  %t406 = load i64, ptr %t405, !range !{i64 0, i64 17}
  %t408 = icmp eq i64 %t406, 12
  store i1 %t408, ptr %l215, !tbaa !21
  br label %bb103
bb103:
  %t409 = load i1, ptr %l215, !tbaa !21
  br i1 %t409, label %bb104, label %bb105
bb104:
  %t410 = load ptr, ptr %l1, !tbaa !29
  %t412 = getelementptr { i64, [3 x i64] }, ptr %t410, i32 0, i32 1
  %t413 = getelementptr { %"compiler/source:Span", ptr }, ptr %t412, i32 0, i32 1
  %t414 = load ptr, ptr %t413
  store ptr %t414, ptr %l23, !tbaa !29
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t416, ptr %t417)
  br label %bb107
bb107:
  br label %bb168
bb108:
  %t421 = load ptr, ptr %l1, !tbaa !29
  store ptr %t421, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t422 = load ptr, ptr %l223, !tbaa !29
  %t423 = icmp ne ptr %t422, null
  br i1 %t423, label %bb109, label %bb110
bb109:
  %t425 = load ptr, ptr %l223, !tbaa !29
  %t426 = load i64, ptr %t425, !range !{i64 0, i64 17}
  %t428 = icmp eq i64 %t426, 13
  store i1 %t428, ptr %l224, !tbaa !21
  br label %bb110
bb110:
  %t429 = load i1, ptr %l224, !tbaa !21
  br i1 %t429, label %bb111, label %bb112
bb111:
  %t430 = load ptr, ptr %l1, !tbaa !29
  %t432 = getelementptr { i64, [3 x i64] }, ptr %t430, i32 0, i32 1
  %t433 = getelementptr { %"compiler/source:Span", ptr }, ptr %t432, i32 0, i32 1
  %t434 = load ptr, ptr %t433
  store ptr %t434, ptr %l24, !tbaa !29
  br label %bb113
bb112:
  br label %bb116
bb113:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load ptr, ptr %l24, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Join", ptr %t437, i32 0, i32 0
  %t440 = load ptr, ptr %t439, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t436, ptr %t440)
  br label %bb114
bb114:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l24, !tbaa !29
  %t447 = getelementptr %"compiler/typed:Join", ptr %t445, i32 0, i32 2
  %t448 = load { i64, ptr }, ptr %t447, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t444, { i64, ptr } %t448)
  br label %bb115
bb115:
  br label %bb168
bb116:
  %t451 = load ptr, ptr %l1, !tbaa !29
  store ptr %t451, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t452 = load ptr, ptr %l236, !tbaa !29
  %t453 = icmp ne ptr %t452, null
  br i1 %t453, label %bb117, label %bb118
bb117:
  %t455 = load ptr, ptr %l236, !tbaa !29
  %t456 = load i64, ptr %t455, !range !{i64 0, i64 17}
  %t458 = icmp eq i64 %t456, 14
  store i1 %t458, ptr %l237, !tbaa !21
  br label %bb118
bb118:
  %t459 = load i1, ptr %l237, !tbaa !21
  br i1 %t459, label %bb119, label %bb120
bb119:
  %t460 = load ptr, ptr %l1, !tbaa !29
  %t462 = getelementptr { i64, [3 x i64] }, ptr %t460, i32 0, i32 1
  %t463 = getelementptr { %"compiler/source:Span", ptr }, ptr %t462, i32 0, i32 1
  %t464 = load ptr, ptr %t463
  store ptr %t464, ptr %l25, !tbaa !29
  br label %bb121
bb120:
  br label %bb141
bb121:
  store %olang.scope zeroinitializer, ptr %s12
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load ptr, ptr %l25, !tbaa !29
  %t469 = getelementptr %"compiler/typed:Spawn", ptr %t467, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !29
  %t474 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %s12, ptr %v2, ptr %v3, ptr %t466, ptr %t470)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t474, ptr %l246
  br label %bb122
bb122:
  %t475 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l246
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t475, ptr %l26
  %t476 = load ptr, ptr %l25, !tbaa !29
  %t478 = getelementptr %"compiler/typed:Spawn", ptr %t476, i32 0, i32 0
  %t479 = load { i64, ptr }, ptr %t478, !tbaa !27
  store { i64, ptr } %t479, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t481 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t483 = extractvalue { i64, ptr } %t481, 0
  store i64 %t483, ptr %l29, !tbaa !24
  br label %bb123
bb123:
  %t485 = load i64, ptr %l28, !tbaa !24
  %t486 = load i64, ptr %l29, !tbaa !24
  %t489 = icmp slt i64 %t485, %t486
  %t491 = xor i1 %t489, true
  br i1 %t491, label %bb124, label %bb125
bb124:
  br label %bb133
bb125:
  br label %bb126
bb126:
  %t493 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t493, ptr %l255, !tbaa !27
  %t494 = load i64, ptr %l28, !tbaa !24
  %t496 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t497 = load ptr, ptr %t496, !tbaa !27
  %t498 = getelementptr ptr, ptr %t497, i64 %t494
  %t499 = load ptr, ptr %t498, !tbaa !39
  store ptr %t499, ptr %l30, !tbaa !29
  %t501 = load ptr, ptr %l30, !tbaa !29
  %t503 = icmp eq ptr %t501, null
  %t505 = xor i1 %t503, true
  br i1 %t505, label %bb127, label %bb128
bb127:
  store %olang.scope zeroinitializer, ptr %s15
  %t507 = load ptr, ptr %l0, !tbaa !29
  store ptr %t507, ptr %l261, !tbaa !29
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load ptr, ptr %l30, !tbaa !29
  %t512 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %t508, ptr %t509)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t512, ptr %l264
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t513 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l264
  %t514 = call ptr @__olang_scope_alloc_a(ptr %s15, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t513, ptr %t514
  %t515 = load ptr, ptr %l261, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estore(ptr %v0, ptr %v0, ptr %s12, ptr %v3, ptr %v2, ptr %t515, ptr %t514, ptr %l26)
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s15)
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t518 = load i64, ptr %l28, !tbaa !24
  %t521 = add i64 %t518, 1
  store i64 %t521, ptr %l28, !tbaa !24
  br label %bb123
bb133:
  %t523 = load ptr, ptr %l25, !tbaa !29
  %t525 = getelementptr %"compiler/typed:Spawn", ptr %t523, i32 0, i32 2
  %t526 = load { i64, ptr }, ptr %t525, !tbaa !27
  store { i64, ptr } %t526, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t528 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t530 = extractvalue { i64, ptr } %t528, 0
  store i64 %t530, ptr %l33, !tbaa !24
  br label %bb134
bb134:
  store %olang.scope zeroinitializer, ptr %s18
  %t532 = load i64, ptr %l32, !tbaa !24
  %t533 = load i64, ptr %l33, !tbaa !24
  %t536 = icmp slt i64 %t532, %t533
  %t538 = xor i1 %t536, true
  br i1 %t538, label %bb135, label %bb136
bb135:
  call void @__olang_scope_close(ptr %s18)
  br label %bb140
bb136:
  br label %bb137
bb137:
  %t540 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t540, ptr %l278, !tbaa !27
  %t541 = load i64, ptr %l32, !tbaa !24
  %t543 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = getelementptr ptr, ptr %t544, i64 %t541
  %t546 = load ptr, ptr %t545, !tbaa !39
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/typed:TaskClause", ptr %t546, i32 0, i32 3
  %t552 = load ptr, ptr %t551, !tbaa !29
  %t555 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s18, ptr %v2, ptr %v3, ptr %t548, ptr %t552)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t555, ptr %l284
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s18)
  br label %bb139
bb139:
  %t556 = load i64, ptr %l32, !tbaa !24
  %t559 = add i64 %t556, 1
  store i64 %t559, ptr %l32, !tbaa !24
  br label %bb134
bb140:
  call void @__olang_scope_close(ptr %s12)
  br label %bb168
bb141:
  %t561 = load ptr, ptr %l1, !tbaa !29
  store ptr %t561, ptr %l288, !tbaa !29
  store i1 false, ptr %l289, !tbaa !21
  %t562 = load ptr, ptr %l288, !tbaa !29
  %t563 = icmp ne ptr %t562, null
  br i1 %t563, label %bb142, label %bb143
bb142:
  %t565 = load ptr, ptr %l288, !tbaa !29
  %t566 = load i64, ptr %t565, !range !{i64 0, i64 17}
  %t568 = icmp eq i64 %t566, 15
  store i1 %t568, ptr %l289, !tbaa !21
  br label %bb143
bb143:
  %t569 = load i1, ptr %l289, !tbaa !21
  br i1 %t569, label %bb144, label %bb145
bb144:
  %t570 = load ptr, ptr %l1, !tbaa !29
  %t572 = getelementptr { i64, [3 x i64] }, ptr %t570, i32 0, i32 1
  %t573 = getelementptr { %"compiler/source:Span", ptr }, ptr %t572, i32 0, i32 1
  %t574 = load ptr, ptr %t573
  store ptr %t574, ptr %l35, !tbaa !29
  br label %bb146
bb145:
  br label %bb163
bb146:
  store %olang.scope zeroinitializer, ptr %s20
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load ptr, ptr %l35, !tbaa !29
  %t581 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %s20, ptr %v2, ptr %v3, ptr %t576, ptr %t577)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t581, ptr %l297
  br label %bb147
bb147:
  %t582 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l297
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t582, ptr %l36
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t585 = getelementptr %"compiler/typed:holdWalk", ptr %t583, i32 0, i32 5
  %t587 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v0, ptr %t585)
  store i64 %t587, ptr %l300
  br label %bb148
bb148:
  %t588 = load i64, ptr %l300, !tbaa !24
  %t589 = icmp eq i64 %t588, 0
  br i1 %t589, label %bb149, label %bb150
bb149:
  call void @__olang_scope_close(ptr %s20)
  br label %ret
bb150:
  br label %bb151
bb151:
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t593 = getelementptr %"compiler/typed:holdWalk", ptr %t591, i32 0, i32 5
  %t595 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcd1867a2c89de03c7af27b93b5b476d9(ptr %v0, ptr %v0, ptr %t593)
  %t596 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t595, 1
  %t597 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t595, 0
  store i32 %t597, ptr %l306
  %t598 = icmp ne i32 %t597, 0
  br i1 %t598, label %bb153, label %ok.599, !prof !99
ok.599:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t596, ptr %l305
  br label %bb152
bb152:
  %t600 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l305
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t600, ptr %l302
  br label %bb160
bb153:
  %t601 = load i32, ptr %l306, !tbaa !23
  %t602 = icmp eq i32 %t601, 65536
  br i1 %t602, label %bb154, label %bb155
bb154:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5e6c689502ae97a3_4a93e9b8e1d69347)
  unreachable
bb155:
  %t604 = load i32, ptr %l306, !tbaa !23
  %t605 = icmp eq i32 %t604, 65537
  br i1 %t605, label %bb156, label %bb157
bb156:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b6b3adf054eb2e90_3f1400959d6043b4)
  unreachable
bb157:
  %t607 = load i32, ptr %l306, !tbaa !23
  %t608 = icmp eq i32 %t607, 65538
  br i1 %t608, label %bb158, label %bb159
bb158:
  call void @__olang_bang_failed_plain(ptr @olang_loc_7b8fc3b9339208b8_2c51799eb4e60e7c)
  unreachable
bb159:
  call void @__olang_bang_failed_plain(ptr @olang_loc_47bf7dbda354986_81bfc8ef2d8843ba)
  unreachable
bb160:
  %t610 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l302
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t610, ptr %l37
  call void @compiler_2ftyped_2eunion(ptr %s20, ptr %s20, ptr %l37, ptr %l36)
  br label %bb161
bb161:
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t615 = getelementptr %"compiler/typed:holdWalk", ptr %t613, i32 0, i32 5
  %t616 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %s20, ptr %t615, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t616)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s20)
  br label %bb168
bb163:
  br i1 true, label %bb164, label %bb165
bb164:
  br label %bb166
bb165:
  br label %bb167
bb166:
  br label %bb168
bb167:
  call void @__olang_check_failed(ptr @olang_loc_3ca74cad4df58772_2fc4655d37cc5656)
  unreachable
bb168:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca i1
  %l96 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t20 = sext i32 %t16 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  br label %bb55
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t46, i32 0, i32 3
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i32, ptr %l4, !tbaa !23
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t50)
  %t56 = add i64 %t53, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t61 = sext i32 %t51 to i64
  %t62 = call i64 @__olang_fmt_i64(ptr null, i64 %t61)
  %t63 = add i64 %t59, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t52, i64 %t53)
  %t65 = getelementptr i8, ptr %t64, i64 %t53
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t50)
  %t67 = getelementptr i8, ptr %t65, i64 %t55
  call void @olang_textcopy(ptr %t67, ptr %t57, i64 %t58)
  %t68 = getelementptr i8, ptr %t67, i64 %t58
  %t69 = call i64 @__olang_fmt_i64(ptr %t68, i64 %t61)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  store { i64, ptr } %t71, ptr %l12, !tbaa !27
  br label %bb55
bb12:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t74 = load ptr, ptr %l32, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb13, label %bb14
bb13:
  %t77 = load ptr, ptr %l32, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 8}
  %t80 = icmp eq i64 %t78, 2
  store i1 %t80, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t81 = load i1, ptr %l33, !tbaa !21
  br i1 %t81, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t93 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %v3, ptr %t88, ptr %t89)
  store { i64, ptr } %t93, ptr %l41
  br label %bb18
bb18:
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t96 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = add i64 %t95, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t94, i64 %t95)
  %t101 = getelementptr i8, ptr %t100, i64 %t95
  call void @olang_textcopy(ptr %t101, ptr %t97, i64 %t98)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  store { i64, ptr } %t103, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb19:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t106 = load ptr, ptr %l43, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb20, label %bb21
bb20:
  %t109 = load ptr, ptr %l43, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 8}
  %t112 = icmp eq i64 %t110, 3
  store i1 %t112, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t113 = load i1, ptr %l44, !tbaa !21
  br i1 %t113, label %bb22, label %bb23
bb22:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l6, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t122, i32 0, i32 3
  %t124 = load i64, ptr %t123
  store i64 %t124, ptr %l7, !tbaa !24
  br label %bb24
bb23:
  br label %bb26
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t130 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s7, ptr %v3, ptr %t126, ptr %t127)
  store { i64, ptr } %t130, ptr %l53
  br label %bb25
bb25:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t139 = call i64 @__olang_fmt_i64(ptr null, i64 %t131)
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t133, i64 %t134)
  %t142 = getelementptr i8, ptr %t141, i64 %t134
  call void @olang_textcopy(ptr %t142, ptr %t135, i64 %t136)
  %t143 = getelementptr i8, ptr %t142, i64 %t136
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t131)
  %t145 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t141, 1
  store { i64, ptr } %t146, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb26:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t149 = load ptr, ptr %l56, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb27, label %bb28
bb27:
  %t152 = load ptr, ptr %l56, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 8}
  %t155 = icmp eq i64 %t153, 4
  store i1 %t155, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t156 = load i1, ptr %l57, !tbaa !21
  br i1 %t156, label %bb29, label %bb30
bb29:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t159, i32 0, i32 2
  %t161 = load ptr, ptr %t160
  store ptr %t161, ptr %l8, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Elem", ptr %t164, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t170 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s9, ptr %v3, ptr %t163, ptr %t167)
  store { i64, ptr } %t170, ptr %l65
  br label %bb32
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l8, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Elem", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %v3, ptr %t171, ptr %t175)
  store { i64, ptr } %t179, ptr %l70
  br label %bb33
bb33:
  %t180 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t185 = add i64 %t182, %t184
  %t186 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t181, i64 %t182)
  %t194 = getelementptr i8, ptr %t193, i64 %t182
  call void @olang_textcopy(ptr %t194, ptr %t183, i64 %t184)
  %t195 = getelementptr i8, ptr %t194, i64 %t184
  call void @olang_textcopy(ptr %t195, ptr %t187, i64 %t188)
  %t196 = getelementptr i8, ptr %t195, i64 %t188
  call void @olang_textcopy(ptr %t196, ptr %t190, i64 %t191)
  %t197 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t193, 1
  store { i64, ptr } %t198, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb34:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t201 = load ptr, ptr %l72, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb35, label %bb36
bb35:
  %t204 = load ptr, ptr %l72, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 8}
  %t207 = icmp eq i64 %t205, 5
  store i1 %t207, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t208 = load i1, ptr %l73, !tbaa !21
  br i1 %t208, label %bb37, label %bb38
bb37:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [4 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l9, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l9, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Payload", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t222 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s11, ptr %v3, ptr %t215, ptr %t219)
  store { i64, ptr } %t222, ptr %l81
  br label %bb40
bb40:
  %t223 = load ptr, ptr %l9, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Payload", ptr %t223, i32 0, i32 1
  %t226 = load i64, ptr %t225, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t234 = call i64 @__olang_fmt_i64(ptr null, i64 %t226)
  %t235 = add i64 %t232, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t228, i64 %t229)
  %t237 = getelementptr i8, ptr %t236, i64 %t229
  call void @olang_textcopy(ptr %t237, ptr %t230, i64 %t231)
  %t238 = getelementptr i8, ptr %t237, i64 %t231
  %t239 = call i64 @__olang_fmt_i64(ptr %t238, i64 %t226)
  %t240 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t236, 1
  store { i64, ptr } %t241, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb41:
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t244 = load ptr, ptr %l85, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb42, label %bb43
bb42:
  %t247 = load ptr, ptr %l85, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 8}
  %t250 = icmp eq i64 %t248, 6
  store i1 %t250, ptr %l86, !tbaa !21
  br label %bb43
bb43:
  %t251 = load i1, ptr %l86, !tbaa !21
  br i1 %t251, label %bb44, label %bb45
bb44:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t254, i32 0, i32 2
  %t256 = load ptr, ptr %t255
  store ptr %t256, ptr %l10, !tbaa !29
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t260, i32 0, i32 3
  %t262 = load i32, ptr %t261
  store i32 %t262, ptr %l11, !tbaa !23
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l10, !tbaa !29
  %t269 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s13, ptr %v3, ptr %t264, ptr %t265)
  store { i64, ptr } %t269, ptr %l96
  br label %bb47
bb47:
  %t270 = load i32, ptr %l11, !tbaa !23
  %t271 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t273 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t279 = add i64 %t276, %t278
  %t281 = sext i32 %t270 to i64
  %t282 = call i64 @__olang_fmt_i64(ptr null, i64 %t281)
  %t283 = add i64 %t279, %t282
  %t284 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t283)
  call void @olang_textcopy(ptr %t284, ptr %t271, i64 %t272)
  %t285 = getelementptr i8, ptr %t284, i64 %t272
  call void @olang_textcopy(ptr %t285, ptr %t274, i64 %t275)
  %t286 = getelementptr i8, ptr %t285, i64 %t275
  call void @olang_textcopy(ptr %t286, ptr %t277, i64 %t278)
  %t287 = getelementptr i8, ptr %t286, i64 %t278
  %t288 = call i64 @__olang_fmt_i64(ptr %t287, i64 %t281)
  %t289 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t284, 1
  store { i64, ptr } %t290, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb55
bb48:
  %t292 = load ptr, ptr %l1, !tbaa !29
  store ptr %t292, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t293 = load ptr, ptr %l99, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb49, label %bb50
bb49:
  %t296 = load ptr, ptr %l99, !tbaa !29
  %t297 = load i64, ptr %t296, !range !{i64 0, i64 8}
  %t299 = icmp eq i64 %t297, 7
  store i1 %t299, ptr %l100, !tbaa !21
  br label %bb50
bb50:
  %t300 = load i1, ptr %l100, !tbaa !21
  br i1 %t300, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t301, ptr %l12, !tbaa !27
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_16612f18a9afa54d_299c1e15a68a5059)
  unreachable
bb55:
  %t303 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  store i64 %t304, ptr %l105, !tbaa !24
  %t305 = load i64, ptr %l105, !tbaa !24
  %t306 = mul i64 %t305, 1
  %t307 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t306)
  %t308 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  store { i64, ptr } %t309, ptr %l106, !tbaa !27
  %t310 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l105, !tbaa !24
  %t315 = mul i64 %t314, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t311, ptr %t313, i64 %t315, i1 false)
  %t316 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t316, ptr %l12, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t317, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, i32 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2ety(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l9 = alloca i32
  %l13 = alloca i1
  %l24 = alloca { ptr, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l38 = alloca i32
  %l39 = alloca ptr
  %l54 = alloca i1
  %l56 = alloca { i64, ptr }
  %l61 = alloca ptr
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, i64 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2eint(ptr %v0, ptr %t1)
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, i32 } zeroinitializer, i32 %t17, 0
  store { i32, i32 } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l1, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2echar(ptr %v0, ptr %t21, i8 58)
  store i32 %t23, ptr %l9
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  br label %bb4
bb4:
  br label %bb6
bb5:
  %t26 = load i32, ptr %l9, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  %t36 = insertvalue { i32, i32 } zeroinitializer, i32 %t34, 0
  store { i32, i32 } %t36, ptr %rv
  br label %ret
bb6:
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = icmp sle i64 %t37, 0
  br i1 %t39, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb9
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/typed:wordReader", ptr %t41, i32 0, i32 2
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:wordReader", ptr %t49, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t57 = icmp sgt i64 %t48, %t54
  store i1 %t57, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t59 = load i1, ptr %l13, !tbaa !21
  br i1 %t59, label %bb10, label %bb11
bb10:
  %t61 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t61, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/typed:wordReader", ptr %t62, i32 0, i32 1
  %t65 = load { ptr, ptr }, ptr %t64
  store { ptr, ptr } %t65, ptr %l24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/typed:wordReader", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l26, !tbaa !27
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:wordReader", ptr %t70, i32 0, i32 2
  %t73 = load i64, ptr %t72, !tbaa !24
  store i64 %t73, ptr %l28, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:wordReader", ptr %t74, i32 0, i32 2
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = load i64, ptr %l1, !tbaa !24
  %t81 = add i64 %t77, %t78
  store i64 %t81, ptr %l32, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l33, !tbaa !24
  %t84 = load i64, ptr %l28, !tbaa !24
  %t85 = icmp sge i64 %t84, 0
  br i1 %t85, label %bb13, label %bb14
bb13:
  %t87 = load i64, ptr %l28, !tbaa !24
  %t88 = load i64, ptr %l32, !tbaa !24
  %t89 = icmp sle i64 %t87, %t88
  br i1 %t89, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_5c89e5c784247c81_189415cf0391d0ed)
  unreachable
bb15:
  %t91 = load i64, ptr %l32, !tbaa !24
  %t92 = load i64, ptr %l33, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  br i1 %t93, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_5c89e5c784247c81_189415cf0391d0ed)
  unreachable
bb17:
  %t95 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l28, !tbaa !24
  %t98 = load i64, ptr %l32, !tbaa !24
  %t99 = getelementptr i8, ptr %t96, i64 %t97
  %t100 = sub i64 %t98, %t97
  %t101 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  %t103 = load { ptr, ptr }, ptr %l24
  %t104 = extractvalue { ptr, ptr } %t103, 0
  %t105 = extractvalue { ptr, ptr } %t103, 1
  %t107 = call i32 %t104(ptr %t105, ptr %v0, { i64, ptr } %t102)
  store i32 %t107, ptr %l38
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_5c89e5c784247c81_189415cf0391d0ed)
  unreachable
bb19:
  %t108 = load i32, ptr %l38, !tbaa !23
  store i32 %t108, ptr %l2, !tbaa !23
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l39, !tbaa !29
  %t110 = load ptr, ptr %l39, !tbaa !29
  %t111 = getelementptr %"compiler/typed:wordReader", ptr %t110, i32 0, i32 2
  %t112 = load i64, ptr %t111, !tbaa !24
  %t114 = load i64, ptr %l1, !tbaa !24
  %t117 = add i64 %t112, %t114
  %t119 = load ptr, ptr %l39, !tbaa !29
  %t120 = getelementptr %"compiler/typed:wordReader", ptr %t119, i32 0, i32 2
  store i64 %t117, ptr %t120, !tbaa !24
  %t121 = load i32, ptr %l2, !tbaa !23
  %t122 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t125 = icmp eq i32 %t121, %t122
  br i1 %t125, label %bb20, label %bb21
bb20:
  %t128 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t128, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/typed:wordReader", ptr %t129, i32 0, i32 2
  %t132 = load i64, ptr %t131, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/typed:wordReader", ptr %t133, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t141 = icmp slt i64 %t132, %t138
  br i1 %t141, label %bb23, label %bb24
bb23:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/typed:wordReader", ptr %t143, i32 0, i32 0
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l56, !tbaa !27
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/typed:wordReader", ptr %t147, i32 0, i32 2
  %t150 = load i64, ptr %t149, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i8, ptr %t153, i64 %t150
  %t155 = load i8, ptr %t154, !tbaa !32
  %t157 = icmp eq i8 %t155, 44
  store i1 %t157, ptr %l54, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb25
bb25:
  %t159 = load i1, ptr %l54, !tbaa !21
  br i1 %t159, label %bb26, label %bb27
bb26:
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l61, !tbaa !29
  %t161 = load ptr, ptr %l61, !tbaa !29
  %t162 = getelementptr %"compiler/typed:wordReader", ptr %t161, i32 0, i32 2
  %t163 = load i64, ptr %t162, !tbaa !24
  %t166 = add i64 %t163, 1
  %t168 = load ptr, ptr %l61, !tbaa !29
  %t169 = getelementptr %"compiler/typed:wordReader", ptr %t168, i32 0, i32 2
  store i64 %t166, ptr %t169, !tbaa !24
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t170 = load i32, ptr %l2, !tbaa !23
  %t172 = insertvalue { i32, i32 } zeroinitializer, i32 %t170, 1
  store { i32, i32 } %t172, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local i1 @compiler_2ftyped_2efreshStorage(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb18
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 17
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ftyped_2efreshStorage(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l14
  br label %bb12
bb12:
  %t28 = load i1, ptr %l14, !tbaa !21
  store i1 %t28, ptr %l2, !tbaa !21
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b7415bbb2ed75c50_93a549ec74f5bd34)
  unreachable
bb18:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2emadeBy(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l36 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb35
bb10:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 14
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb23
bb15:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Try", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Try", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb22
bb18:
  call void @__olang_check_failed(ptr @olang_loc_336e4a7a18e16ea4_5caa821eea897180)
  unreachable
bb19:
  br label %bb20
bb20:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Try", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call i1 @compiler_2ftyped_2emadeBy(ptr %v0, ptr %t53)
  store i1 %t55, ptr %l28
  br label %bb21
bb21:
  %t56 = load i1, ptr %l28, !tbaa !21
  store i1 %t56, ptr %l22, !tbaa !21
  br label %bb22
bb22:
  %t57 = load i1, ptr %l22, !tbaa !21
  store i1 %t57, ptr %l3, !tbaa !21
  br label %bb35
bb23:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l29, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 18}
  %t65 = icmp eq i64 %t63, 17
  store i1 %t65, ptr %l30, !tbaa !21
  br label %bb25
bb25:
  %t66 = load i1, ptr %l30, !tbaa !21
  br i1 %t66, label %bb26, label %bb27
bb26:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l2, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = call i1 @compiler_2ftyped_2emadeBy(ptr %v0, ptr %t73)
  store i1 %t75, ptr %l36
  br label %bb29
bb29:
  %t76 = load i1, ptr %l36, !tbaa !21
  store i1 %t76, ptr %l3, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_43ee4571abcd420a_a05ceada06352a66)
  unreachable
bb35:
  %t77 = load i1, ptr %l3, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftyped_2ereadBits(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l10 = alloca i1
  %l12 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i1
  %l50 = alloca { i64, ptr }
  %l56 = alloca i1
  %l60 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = add i64 %t12, 1
  %t17 = icmp ne i64 %t9, %t14
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l2, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb13
bb10:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l28, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb12
bb12:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l25, !tbaa !24
  br label %bb13
bb13:
  %t52 = load i64, ptr %l25, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = sub i64 %t53, 1
  store i64 %t54, ptr %l37, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = icmp slt i64 %t55, 2147483648
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp sge i64 %t57, 0
  %t61 = and i1 %t56, %t58
  store i1 %t61, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  br label %bb25
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l2, !tbaa !24
  %t71 = load i64, ptr %l6, !tbaa !24
  %t72 = load i64, ptr %l4, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l7, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t80, ptr %l50, !tbaa !27
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = add i64 %t81, 1
  %t85 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i8, ptr %t86, i64 %t83
  %t88 = load i8, ptr %t87, !tbaa !32
  store i8 %t88, ptr %l8, !tbaa !22
  %t90 = load i8, ptr %l8, !tbaa !22
  %t92 = icmp ne i8 %t90, 48
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = load i8, ptr %l8, !tbaa !22
  %t96 = icmp ne i8 %t94, 49
  store i1 %t96, ptr %l56, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t98 = load i1, ptr %l56, !tbaa !21
  br i1 %t98, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t100, ptr %l60, !tbaa !27
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i8, ptr %l8, !tbaa !22
  %t104 = icmp eq i8 %t102, 49
  %t107 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i1, ptr %t108, i64 %t101
  store i1 %t104, ptr %t109, !tbaa !31
  br label %bb24
bb24:
  %t110 = load i64, ptr %l6, !tbaa !24
  %t113 = add i64 %t110, 1
  store i64 %t113, ptr %l6, !tbaa !24
  br label %bb14
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ereadScopes(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, [2 x i64] }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, [2 x i64] }
  %l50 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ewordsOf(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l2)
  store i64 %t6, ptr %l12
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = load i64, ptr %l12, !tbaa !24
  %t12 = icmp ne i64 %t10, %t9
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  store i64 0, ptr %l3, !tbaa !24
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l2)
  store i64 %t16, ptr %l18
  br label %bb6
bb6:
  %t17 = load i64, ptr %l18, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb12
bb9:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l25, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %l22, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l22, !tbaa !24
  store i64 %t45, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb22
bb15:
  br label %bb16
bb16:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l8, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t64, ptr %l43, !tbaa !27
  %t65 = load i64, ptr %l8, !tbaa !24
  store i64 %t65, ptr %l44, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l2, i64 %t66)
  store { i64, ptr } %t69, ptr %l48
  br label %bb17
bb17:
  %t70 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t71 = call { i32, { i64, [2 x i64] } } @compiler_2ftyped_2eScope_2eOfText(ptr %s0, { i64, ptr } %t70)
  %t72 = extractvalue { i32, { i64, [2 x i64] } } %t71, 1
  %t73 = extractvalue { i32, { i64, [2 x i64] } } %t71, 0
  store i32 %t73, ptr %l50
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb19, label %ok.75, !prof !99
ok.75:
  store { i64, [2 x i64] } %t72, ptr %l49
  br label %bb18
bb18:
  %t76 = load { i64, [2 x i64] }, ptr %l49
  store { i64, [2 x i64] } %t76, ptr %l45
  br label %bb20
bb19:
  %t77 = load i32, ptr %l50, !tbaa !23
  %t78 = lshr i32 %t77, 16
  %t79 = and i32 %t77, 65535
  %t80 = icmp eq i32 %t78, 1
  %t81 = select i1 %t80, i32 1, i32 0
  %t82 = icmp eq i32 %t77, 0
  %t83 = shl i32 %t81, 16
  %t84 = or i32 %t83, %t79
  %t85 = select i1 %t82, i32 0, i32 %t84
  call void @__olang_scope_close(ptr %s0)
  store i32 %t85, ptr %rv
  br label %ret
bb20:
  %t87 = load { i64, [2 x i64] }, ptr %l45
  %t88 = load i64, ptr %l44, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, [2 x i64] }, ptr %t90, i64 %t88
  store { i64, [2 x i64] } %t87, ptr %t91
  br label %bb21
bb21:
  %t92 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t92, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb13
bb22:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftyped_2ereadsL(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l3
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l4, !tbaa !23
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load i32, ptr %t40
  %t44 = load i32, ptr %l1, !tbaa !23
  %t47 = icmp eq i32 %t41, %t44
  store i1 %t47, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t49 = load i1, ptr %l18, !tbaa !21
  store i1 %t49, ptr %l7, !tbaa !21
  br label %bb23
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb12, label %bb13
bb12:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 18}
  %t57 = icmp eq i64 %t55, 17
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l29, !tbaa !21
  br i1 %t58, label %bb14, label %bb15
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l6, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t65 = load ptr, ptr %l6, !tbaa !29
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i1 @compiler_2ftyped_2ereadsL(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l36
  br label %bb17
bb17:
  %t70 = load i1, ptr %l36, !tbaa !21
  store i1 %t70, ptr %l7, !tbaa !21
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_c3a0c9435d191b12_38a32ac3d3b8739e)
  unreachable
bb23:
  %t71 = load i1, ptr %l7, !tbaa !21
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ewholeCall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb18
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 17
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ftyped_2ewholeCall(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l14
  br label %bb12
bb12:
  %t28 = load i1, ptr %l14, !tbaa !21
  store i1 %t28, ptr %l2, !tbaa !21
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_7725d671f9e840_93f1d9571cb236fc)
  unreachable
bb18:
  %t29 = load i1, ptr %l2, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_3aContractInfo_2ector(ptr %out, ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"compiler/typed:ContractInfo"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 %a1, ptr %l3, !tbaa !24
  %t5 = call ptr @__olang_scope_hold(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l10, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call ptr @__olang_region_make(ptr %v1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l10, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l10
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t12, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l12
  br label %bb3
bb3:
  %t14 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e2
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l10
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = call ptr @__olang_region_or(ptr %t20, ptr null)
  %t22 = call ptr @__olang_region_home(ptr %t21)
  %t23 = icmp ne ptr %t22, null
  %t24 = select i1 %t23, ptr %t22, ptr null
  call void @__olang_region_settle_in(ptr %t17, ptr %t24)
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l4
  %t26 = call ptr @__olang_scope_hold(ptr %v1)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l14, !tbaa !24
  %t28 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e3
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = call ptr @__olang_region_make(ptr %v1)
  %t31 = ptrtoint ptr %t30 to i64
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l14
  %t33 = inttoptr i64 %t32 to ptr
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t33, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l16
  br label %bb8
bb8:
  %t35 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e3
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l14
  %t38 = inttoptr i64 %t37 to ptr
  %t39 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = call ptr @__olang_region_or(ptr %t41, ptr null)
  %t43 = call ptr @__olang_region_home(ptr %t42)
  %t44 = icmp ne ptr %t43, null
  %t45 = select i1 %t44, ptr %t43, ptr null
  call void @__olang_region_settle_in(ptr %t38, ptr %t45)
  br label %bb10
bb10:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l5
  %t47 = call ptr @__olang_scope_hold(ptr %v1)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l18, !tbaa !24
  %t49 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e4
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t51 = call ptr @__olang_region_make(ptr %v1)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l18, !tbaa !24
  br label %bb12
bb12:
  %t53 = load i64, ptr %l18
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t54, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l20
  br label %bb13
bb13:
  %t56 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e4
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t58 = load i64, ptr %l18
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = call ptr @__olang_region_or(ptr %t62, ptr null)
  %t64 = call ptr @__olang_region_home(ptr %t63)
  %t65 = icmp ne ptr %t64, null
  %t66 = select i1 %t65, ptr %t64, ptr null
  call void @__olang_region_settle_in(ptr %t59, ptr %t66)
  br label %bb15
bb15:
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l6
  %t68 = call ptr @__olang_scope_hold(ptr %v1)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l22, !tbaa !24
  %t70 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e5
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = call ptr @__olang_region_make(ptr %v1)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l22, !tbaa !24
  br label %bb17
bb17:
  %t74 = load i64, ptr %l22
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t75, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l24
  br label %bb18
bb18:
  %t77 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e5
  br i1 %t77, label %bb19, label %bb20
bb19:
  %t79 = load i64, ptr %l22
  %t80 = inttoptr i64 %t79 to ptr
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = call ptr @__olang_region_or(ptr %t83, ptr null)
  %t85 = call ptr @__olang_region_home(ptr %t84)
  %t86 = icmp ne ptr %t85, null
  %t87 = select i1 %t86, ptr %t85, ptr null
  call void @__olang_region_settle_in(ptr %t80, ptr %t87)
  br label %bb20
bb20:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  %t89 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 0
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t90, ptr %t89, !tbaa !27
  %t91 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 1
  %t92 = load i64, ptr %l3, !tbaa !24
  store i64 %t92, ptr %t91, !tbaa !24
  %t93 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 2
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %t93
  %t95 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 3
  %t96 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %t95
  %t97 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 4
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %t97
  %t99 = getelementptr %"compiler/typed:ContractInfo", ptr %l26, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %t99
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l26, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_3adropWalk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i64
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca i64
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca i64
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca i64
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca i64
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca i64
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca i64
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca i64
  %l63 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l65 = alloca %"compiler/typed:dropWalk"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call ptr @__olang_scope_hold(ptr %v1)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l17, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call ptr @__olang_region_make(ptr %v1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l17, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l17
  %t10 = inttoptr i64 %t9 to ptr
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t10)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l19
  br label %bb3
bb3:
  %t12 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e1
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l17
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19, i32 0, i32 2
  %t17 = load { i64, ptr }, ptr %t16
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = call ptr @__olang_region_or(ptr %t18, ptr null)
  %t20 = call ptr @__olang_region_home(ptr %t19)
  %t21 = icmp ne ptr %t20, null
  %t22 = select i1 %t21, ptr %t20, ptr null
  %t23 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = call ptr @__olang_region_or(ptr %t25, ptr null)
  %t27 = call ptr @__olang_region_home(ptr %t26)
  %t28 = icmp ne ptr %t27, null
  %t29 = select i1 %t28, ptr %t27, ptr %t22
  %t30 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  %t32 = extractvalue { i64, ptr } %t31, 1
  %t33 = call ptr @__olang_region_or(ptr %t32, ptr null)
  %t34 = call ptr @__olang_region_home(ptr %t33)
  %t35 = icmp ne ptr %t34, null
  %t36 = select i1 %t35, ptr %t34, ptr %t29
  call void @__olang_region_settle_in(ptr %t15, ptr %t36)
  br label %bb5
bb5:
  %t37 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t37, ptr %l2
  %t38 = call ptr @__olang_scope_hold(ptr %v1)
  %t39 = ptrtoint ptr %t38 to i64
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e2
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = call ptr @__olang_region_make(ptr %v1)
  %t43 = ptrtoint ptr %t42 to i64
  store i64 %t43, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l21
  %t45 = inttoptr i64 %t44 to ptr
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t45, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l23
  br label %bb8
bb8:
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e2
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load i64, ptr %l21
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = call ptr @__olang_region_or(ptr %t53, ptr null)
  %t55 = call ptr @__olang_region_home(ptr %t54)
  %t56 = icmp ne ptr %t55, null
  %t57 = select i1 %t56, ptr %t55, ptr null
  call void @__olang_region_settle_in(ptr %t50, ptr %t57)
  br label %bb10
bb10:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t59 = call ptr @__olang_scope_hold(ptr %v1)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l25, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e5
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = call ptr @__olang_region_make(ptr %v1)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l25, !tbaa !24
  br label %bb12
bb12:
  %t65 = load i64, ptr %l25
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t66, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l27
  br label %bb13
bb13:
  %t68 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e5
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t70 = load i64, ptr %l25
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = call ptr @__olang_region_or(ptr %t74, ptr null)
  %t76 = call ptr @__olang_region_home(ptr %t75)
  %t77 = icmp ne ptr %t76, null
  %t78 = select i1 %t77, ptr %t76, ptr null
  call void @__olang_region_settle_in(ptr %t71, ptr %t78)
  br label %bb15
bb15:
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l6
  %t80 = call ptr @__olang_scope_hold(ptr %v1)
  %t81 = ptrtoint ptr %t80 to i64
  store i64 %t81, ptr %l29, !tbaa !24
  %t82 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e6
  br i1 %t82, label %bb16, label %bb17
bb16:
  %t84 = call ptr @__olang_region_make(ptr %v1)
  %t85 = ptrtoint ptr %t84 to i64
  store i64 %t85, ptr %l29, !tbaa !24
  br label %bb17
bb17:
  %t86 = load i64, ptr %l29
  %t87 = inttoptr i64 %t86 to ptr
  %t88 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t87, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l31
  br label %bb18
bb18:
  %t89 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e6
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t91 = load i64, ptr %l29
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = call ptr @__olang_region_or(ptr %t95, ptr null)
  %t97 = call ptr @__olang_region_home(ptr %t96)
  %t98 = icmp ne ptr %t97, null
  %t99 = select i1 %t98, ptr %t97, ptr null
  call void @__olang_region_settle_in(ptr %t92, ptr %t99)
  br label %bb20
bb20:
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %l7
  %t101 = call ptr @__olang_scope_hold(ptr %v1)
  %t102 = ptrtoint ptr %t101 to i64
  store i64 %t102, ptr %l33, !tbaa !24
  %t103 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e7
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t105 = call ptr @__olang_region_make(ptr %v1)
  %t106 = ptrtoint ptr %t105 to i64
  store i64 %t106, ptr %l33, !tbaa !24
  br label %bb22
bb22:
  %t107 = load i64, ptr %l33
  %t108 = inttoptr i64 %t107 to ptr
  %t109 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t108, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l35
  br label %bb23
bb23:
  %t110 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e7
  br i1 %t110, label %bb24, label %bb25
bb24:
  %t112 = load i64, ptr %l33
  %t113 = inttoptr i64 %t112 to ptr
  %t114 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = call ptr @__olang_region_or(ptr %t116, ptr null)
  %t118 = call ptr @__olang_region_home(ptr %t117)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t113, ptr %t120)
  br label %bb25
bb25:
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l8
  %t122 = call ptr @__olang_scope_hold(ptr %v1)
  %t123 = ptrtoint ptr %t122 to i64
  store i64 %t123, ptr %l37, !tbaa !24
  %t124 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e8
  br i1 %t124, label %bb26, label %bb27
bb26:
  %t126 = call ptr @__olang_region_make(ptr %v1)
  %t127 = ptrtoint ptr %t126 to i64
  store i64 %t127, ptr %l37, !tbaa !24
  br label %bb27
bb27:
  %t128 = load i64, ptr %l37
  %t129 = inttoptr i64 %t128 to ptr
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t129, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l39
  br label %bb28
bb28:
  %t131 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e8
  br i1 %t131, label %bb29, label %bb30
bb29:
  %t133 = load i64, ptr %l37
  %t134 = inttoptr i64 %t133 to ptr
  %t135 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = call ptr @__olang_region_or(ptr %t137, ptr null)
  %t139 = call ptr @__olang_region_home(ptr %t138)
  %t140 = icmp ne ptr %t139, null
  %t141 = select i1 %t140, ptr %t139, ptr null
  call void @__olang_region_settle_in(ptr %t134, ptr %t141)
  br label %bb30
bb30:
  %t142 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t142, ptr %l9
  %t143 = call ptr @__olang_scope_hold(ptr %v1)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l41, !tbaa !24
  %t145 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e9
  br i1 %t145, label %bb31, label %bb32
bb31:
  %t147 = call ptr @__olang_region_make(ptr %v1)
  %t148 = ptrtoint ptr %t147 to i64
  store i64 %t148, ptr %l41, !tbaa !24
  br label %bb32
bb32:
  %t149 = load i64, ptr %l41
  %t150 = inttoptr i64 %t149 to ptr
  %t151 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t150, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l43
  br label %bb33
bb33:
  %t152 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e9
  br i1 %t152, label %bb34, label %bb35
bb34:
  %t154 = load i64, ptr %l41
  %t155 = inttoptr i64 %t154 to ptr
  %t156 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43, i32 0, i32 0
  %t157 = load { i64, ptr }, ptr %t156
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = call ptr @__olang_region_or(ptr %t158, ptr null)
  %t160 = call ptr @__olang_region_home(ptr %t159)
  %t161 = icmp ne ptr %t160, null
  %t162 = select i1 %t161, ptr %t160, ptr null
  call void @__olang_region_settle_in(ptr %t155, ptr %t162)
  br label %bb35
bb35:
  %t163 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %l10
  %t164 = call ptr @__olang_scope_hold(ptr %v1)
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l45, !tbaa !24
  %t166 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e10
  br i1 %t166, label %bb36, label %bb37
bb36:
  %t168 = call ptr @__olang_region_make(ptr %v1)
  %t169 = ptrtoint ptr %t168 to i64
  store i64 %t169, ptr %l45, !tbaa !24
  br label %bb37
bb37:
  %t170 = load i64, ptr %l45
  %t171 = inttoptr i64 %t170 to ptr
  %t172 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t171, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172, ptr %l47
  br label %bb38
bb38:
  %t173 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e10
  br i1 %t173, label %bb39, label %bb40
bb39:
  %t175 = load i64, ptr %l45
  %t176 = inttoptr i64 %t175 to ptr
  %t177 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = call ptr @__olang_region_or(ptr %t179, ptr null)
  %t181 = call ptr @__olang_region_home(ptr %t180)
  %t182 = icmp ne ptr %t181, null
  %t183 = select i1 %t182, ptr %t181, ptr null
  call void @__olang_region_settle_in(ptr %t176, ptr %t183)
  br label %bb40
bb40:
  %t184 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %l11
  %t185 = call ptr @__olang_scope_hold(ptr %v1)
  %t186 = ptrtoint ptr %t185 to i64
  store i64 %t186, ptr %l49, !tbaa !24
  %t187 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e11
  br i1 %t187, label %bb41, label %bb42
bb41:
  %t189 = call ptr @__olang_region_make(ptr %v1)
  %t190 = ptrtoint ptr %t189 to i64
  store i64 %t190, ptr %l49, !tbaa !24
  br label %bb42
bb42:
  %t191 = load i64, ptr %l49
  %t192 = inttoptr i64 %t191 to ptr
  %t193 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t192, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t193, ptr %l51
  br label %bb43
bb43:
  %t194 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e11
  br i1 %t194, label %bb44, label %bb45
bb44:
  %t196 = load i64, ptr %l49
  %t197 = inttoptr i64 %t196 to ptr
  %t198 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51, i32 0, i32 0
  %t199 = load { i64, ptr }, ptr %t198
  %t200 = extractvalue { i64, ptr } %t199, 1
  %t201 = call ptr @__olang_region_or(ptr %t200, ptr null)
  %t202 = call ptr @__olang_region_home(ptr %t201)
  %t203 = icmp ne ptr %t202, null
  %t204 = select i1 %t203, ptr %t202, ptr null
  call void @__olang_region_settle_in(ptr %t197, ptr %t204)
  br label %bb45
bb45:
  %t205 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l12
  %t206 = call ptr @__olang_scope_hold(ptr %v1)
  %t207 = ptrtoint ptr %t206 to i64
  store i64 %t207, ptr %l53, !tbaa !24
  %t208 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e12
  br i1 %t208, label %bb46, label %bb47
bb46:
  %t210 = call ptr @__olang_region_make(ptr %v1)
  %t211 = ptrtoint ptr %t210 to i64
  store i64 %t211, ptr %l53, !tbaa !24
  br label %bb47
bb47:
  %t212 = load i64, ptr %l53
  %t213 = inttoptr i64 %t212 to ptr
  %t214 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t213, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t214, ptr %l55
  br label %bb48
bb48:
  %t215 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e12
  br i1 %t215, label %bb49, label %bb50
bb49:
  %t217 = load i64, ptr %l53
  %t218 = inttoptr i64 %t217 to ptr
  %t219 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55, i32 0, i32 0
  %t220 = load { i64, ptr }, ptr %t219
  %t221 = extractvalue { i64, ptr } %t220, 1
  %t222 = call ptr @__olang_region_or(ptr %t221, ptr null)
  %t223 = call ptr @__olang_region_home(ptr %t222)
  %t224 = icmp ne ptr %t223, null
  %t225 = select i1 %t224, ptr %t223, ptr null
  call void @__olang_region_settle_in(ptr %t218, ptr %t225)
  br label %bb50
bb50:
  %t226 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t226, ptr %l13
  %t227 = call ptr @__olang_scope_hold(ptr %v1)
  %t228 = ptrtoint ptr %t227 to i64
  store i64 %t228, ptr %l57, !tbaa !24
  %t229 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e13
  br i1 %t229, label %bb51, label %bb52
bb51:
  %t231 = call ptr @__olang_region_make(ptr %v1)
  %t232 = ptrtoint ptr %t231 to i64
  store i64 %t232, ptr %l57, !tbaa !24
  br label %bb52
bb52:
  %t233 = load i64, ptr %l57
  %t234 = inttoptr i64 %t233 to ptr
  %t235 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t234, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t235, ptr %l59
  br label %bb53
bb53:
  %t236 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e13
  br i1 %t236, label %bb54, label %bb55
bb54:
  %t238 = load i64, ptr %l57
  %t239 = inttoptr i64 %t238 to ptr
  %t240 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59, i32 0, i32 0
  %t241 = load { i64, ptr }, ptr %t240
  %t242 = extractvalue { i64, ptr } %t241, 1
  %t243 = call ptr @__olang_region_or(ptr %t242, ptr null)
  %t244 = call ptr @__olang_region_home(ptr %t243)
  %t245 = icmp ne ptr %t244, null
  %t246 = select i1 %t245, ptr %t244, ptr null
  call void @__olang_region_settle_in(ptr %t239, ptr %t246)
  br label %bb55
bb55:
  %t247 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t247, ptr %l14
  %t248 = call ptr @__olang_scope_hold(ptr %v1)
  %t249 = ptrtoint ptr %t248 to i64
  store i64 %t249, ptr %l61, !tbaa !24
  %t250 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e14
  br i1 %t250, label %bb56, label %bb57
bb56:
  %t252 = call ptr @__olang_region_make(ptr %v1)
  %t253 = ptrtoint ptr %t252 to i64
  store i64 %t253, ptr %l61, !tbaa !24
  br label %bb57
bb57:
  %t254 = load i64, ptr %l61
  %t255 = inttoptr i64 %t254 to ptr
  %t256 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %t255)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t256, ptr %l63
  br label %bb58
bb58:
  %t257 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3adropWalk_2e14
  br i1 %t257, label %bb59, label %bb60
bb59:
  %t259 = load i64, ptr %l61
  %t260 = inttoptr i64 %t259 to ptr
  %t261 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l63, i32 0, i32 2
  %t262 = load { i64, ptr }, ptr %t261
  %t263 = extractvalue { i64, ptr } %t262, 1
  %t264 = call ptr @__olang_region_or(ptr %t263, ptr null)
  %t265 = call ptr @__olang_region_home(ptr %t264)
  %t266 = icmp ne ptr %t265, null
  %t267 = select i1 %t266, ptr %t265, ptr null
  %t268 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l63, i32 0, i32 1
  %t269 = load { i64, ptr }, ptr %t268
  %t270 = extractvalue { i64, ptr } %t269, 1
  %t271 = call ptr @__olang_region_or(ptr %t270, ptr null)
  %t272 = call ptr @__olang_region_home(ptr %t271)
  %t273 = icmp ne ptr %t272, null
  %t274 = select i1 %t273, ptr %t272, ptr %t267
  %t275 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l63, i32 0, i32 0
  %t276 = load { i64, ptr }, ptr %t275
  %t277 = extractvalue { i64, ptr } %t276, 1
  %t278 = call ptr @__olang_region_or(ptr %t277, ptr null)
  %t279 = call ptr @__olang_region_home(ptr %t278)
  %t280 = icmp ne ptr %t279, null
  %t281 = select i1 %t280, ptr %t279, ptr %t274
  call void @__olang_region_settle_in(ptr %t260, ptr %t281)
  br label %bb60
bb60:
  %t282 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l63
  %t283 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 0
  %t284 = load ptr, ptr %l1, !tbaa !29
  store ptr %t284, ptr %t283, !tbaa !29
  %t285 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 1
  %t286 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t286, ptr %t285
  %t287 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 2
  %t288 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t288, ptr %t287
  %t289 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 3
  %t290 = load i1, ptr %l4, !tbaa !21
  store i1 %t290, ptr %t289, !tbaa !21
  %t291 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 4
  %t292 = load i64, ptr %l5, !tbaa !24
  store i64 %t292, ptr %t291, !tbaa !24
  %t293 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 5
  %t294 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t294, ptr %t293
  %t295 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 6
  %t296 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t296, ptr %t295
  %t297 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 7
  %t298 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t298, ptr %t297
  %t299 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 8
  %t300 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t300, ptr %t299
  %t301 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 9
  %t302 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t302, ptr %t301
  %t303 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 10
  %t304 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t304, ptr %t303
  %t305 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 11
  %t306 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t306, ptr %t305
  %t307 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 12
  %t308 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t308, ptr %t307
  %t309 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 13
  %t310 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t310, ptr %t309
  %t311 = getelementptr %"compiler/typed:dropWalk", ptr %l65, i32 0, i32 14
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t282, ptr %t311
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l65, i64 488, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:wordReader" @compiler_2ftyped_3awordReader_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %rv = alloca %"compiler/typed:wordReader"
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:wordReader" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:wordReader" %t6, { ptr, ptr } %pg1, 1
  %t10 = insertvalue %"compiler/typed:wordReader" %t8, i64 0, 2
  store %"compiler/typed:wordReader" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:wordReader", ptr %rv
  ret %"compiler/typed:wordReader" %rr
}

@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" |" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare i64 @__olang_fmt_i64(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
declare ptr @__olang_scope_or(ptr, ptr)
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2e0 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2e0 = weak hidden constant i1 false
declare void @__olang_bang_failed_plain(ptr) cold noreturn
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aholdWalk__2erefs_2elocal_2e2 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
declare void @__olang_region_release_part(ptr, i64) noinline
@olang_2esole_2eArray_3cArray_3cI64_3e_3e_2e_2d1 = weak hidden constant i1 false
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"G" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" as " }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"tmp " }>, align 8
@.d23 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"target" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"b" }>, align 8
@olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aContractInfo_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e1 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e8 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e10 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e13 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3adropWalk_2e14 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eToVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ePlan_2eNew(ptr %out, ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ewordsOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_513fe42ccd619edb_f9eefb0210e3c837 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_f54e407a1957a5de_bac5f2aedbd3a6da = external constant [0 x i8]
declare { i32, { i64, [2 x i64] } } @compiler_2ftyped_2eScope_2eOfText(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eToArray_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a2b2db9c76964d3d_44f19efa61cd8f79 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_db138e9723fb9fe0_9822d1289854fb4c = external constant [0 x i8]
@olang_loc_850ab3b4cafc30bf_b865ab70d4df5d13 = external constant [0 x i8]
declare %"compiler/typed:DerivedArg" @compiler_2ftyped_3aDerivedArg_2ector(ptr %v0, i64 %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2ePus_Hd9c60b9bc3eb0bc15b58bce924fabf2c(ptr %v0, ptr %a0, %"compiler/typed:DerivedArg" %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassDerived(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecopySite(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_437e3b1aa2dfe07b_e7cef1b5dfa49877 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2edeclare(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_b7d0c4ef23cb16fa_bb49bf88955879a6 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2eRefReadOut(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eSet_H54ebfdc15a9c097858a2e264494e7d5a(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, [1 x i64] } %a2)
@olang_loc_9a2d2471d97215b1_125b5d47933e1fad = external constant [0 x i8]
declare %"compiler/typed:argRoot" @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eargRoot(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKeepsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_4086334666941342_2cd2470309ce51f6 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2egive(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c8e89ecf105db19_6b4b68a887b2ef25 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_97b4d4f91b5dfdc1_6f0d24ceace7504d = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLostStores_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_2900faaa17bf3b23_aa9541689676b42f = external constant [0 x i8]
@olang_loc_7596ed2c7d631a22_34e31769c135136e = external constant [0 x i8]
@olang_loc_ffe0189e7b721f8f_5dca816419dc18f3 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_237180dabec9849e_b4dbc260c308006a = external constant [0 x i8]
@olang_loc_45ead01c569de36f_c5d1cb857cc40283 = external constant [0 x i8]
@olang_loc_6ff0b07d48f8f2b7_c646bc78fcfe1ce3 = external constant [0 x i8]
declare { i32, i64 } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2eint(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, %"compiler/source:Span" } @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2espan(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3awordReader_2echar(ptr %v0, ptr %a0, i8 %a1)
declare { i32, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ereadPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_4e4df3a218fbdfef_2fc14a2cfade6f23 = external constant [0 x i8]
@olang_loc_df109db0fdeebc9d_ef38e7cbbce86079 = external constant [0 x i8]
@olang_loc_4e1b3d3964dcf140_426a19f9f36fcc4c = external constant [0 x i8]
@olang_loc_814422372e4dce3b_a43643d36bfe9937 = external constant [0 x i8]
@olang_loc_964b6738afc8bcbe_650d3b8036ee77da = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eDropHome(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_e3571a351cb0ce21_2bd4e5481f65df95 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eDropDerived(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3)
@olang_loc_77315c1e1ec03e98_be22ee0dd90c53a4 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eCle_H9e31dbf06df58c38226424712d120dfe(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eaddDef(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3, ptr %a4, i1 %a5)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hdc84c10e1af960a666eeb267120f3ec3(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_59830ee0ec754a32_f5aff824d93b155e = external constant [0 x i8]
@olang_loc_b8ff85e818b1a126_11cf17c421c4721a = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_17c315ca28f40c4c_14b80e258f8c2b0 = external constant [0 x i8]
@olang_loc_db2d0e7e8bf65551_fc4da676f7c58ce5 = external constant [0 x i8]
@olang_loc_6fe9eb3ff5642bc1_33392e6f48613205 = external constant [0 x i8]
@olang_loc_5f1ddc7ef7469727_e10177d23ca0510b = external constant [0 x i8]
@olang_loc_24a3ccdd47c97c70_8558c77bc7af118c = external constant [0 x i8]
@olang_loc_130a89b2782f12a5_38e9334e27b56d91 = external constant [0 x i8]
@olang_loc_1916e27cc0da8fc5_b948d7408e366d01 = external constant [0 x i8]
@olang_loc_567e5689d7ac5ccb_d57870be630e767 = external constant [0 x i8]
@olang_loc_5f0c96ba8f37c420_5ca612e1d5c707f4 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eAt_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %a0, i1 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2etry(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e0d071190e38de5d_291e4ea72946f179 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_43e833e67406aee2_76f2107f4f2989fe = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2eunion(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_7fb442b2027c5df4_8cb8a301a51c1668 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcd1867a2c89de03c7af27b93b5b476d9(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_2fe17ed863e993f3_a4fd95e432e2de7 = external constant [0 x i8]
@olang_loc_2b0ce19cf8abfa0_63d28338a0667b94 = external constant [0 x i8]
@olang_loc_231c306bfae66ae8_f9a103d13bf0009c = external constant [0 x i8]
@olang_loc_60c7f079a8f50056_f0211a32bac11e1a = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2efnVal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
@olang_loc_7e259cde601a72ba_d3d8f3b52bf79a7e = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2einBlock(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePop_3cArray_3cI64_3e_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_96ed7c0737fb007f_bcf36b4956f76d4b = external constant [0 x i8]
@olang_loc_eee80033d1164c3c_3495c4b80935428 = external constant [0 x i8]
@olang_loc_d52aab1c9c36d4_17087f4c711c4240 = external constant [0 x i8]
@olang_loc_fe54fd99e9902812_25d1b4e50c46612e = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v0, ptr %a0)
@olang_loc_5e6c689502ae97a3_4a93e9b8e1d69347 = external constant [0 x i8]
@olang_loc_b6b3adf054eb2e90_3f1400959d6043b4 = external constant [0 x i8]
@olang_loc_7b8fc3b9339208b8_2c51799eb4e60e7c = external constant [0 x i8]
@olang_loc_47bf7dbda354986_81bfc8ef2d8843ba = external constant [0 x i8]
@olang_loc_3ca74cad4df58772_2fc4655d37cc5656 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_16612f18a9afa54d_299c1e15a68a5059 = external constant [0 x i8]
@olang_loc_5c89e5c784247c81_189415cf0391d0ed = external constant [0 x i8]
@olang_loc_b7415bbb2ed75c50_93a549ec74f5bd34 = external constant [0 x i8]
@olang_loc_336e4a7a18e16ea4_5caa821eea897180 = external constant [0 x i8]
@olang_loc_43ee4571abcd420a_a05ceada06352a66 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_c3a0c9435d191b12_38a32ac3d3b8739e = external constant [0 x i8]
@olang_loc_7725d671f9e840_93f1d9571cb236fc = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
