; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
@G_2e_3cunistd_2eh_3e_2eCLOSE__RANGE__CLOEXEC = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eCLOSE__RANGE__UNSHARE = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eF__LOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eF__OK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eF__TEST = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eF__TLOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eF__ULOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eL__INCR = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eL__SET = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eL__XTND = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eR__OK = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eSEEK__CUR = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eSEEK__DATA = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eSEEK__END = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eSEEK__HOLE = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eSEEK__SET = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eSTDERR__FILENO = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eSTDIN__FILENO = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eSTDOUT__FILENO = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eW__OK = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cunistd_2eh_3e_2eX__OK = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
define dso_local void @_3cunistd_2eh_3e_2eCLOSE__RANGE__CLOEXEC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cunistd_2eh_3e_2eCLOSE__RANGE__CLOEXEC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eCLOSE__RANGE__UNSHARE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cunistd_2eh_3e_2eCLOSE__RANGE__UNSHARE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eF__LOCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cunistd_2eh_3e_2eF__LOCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eF__OK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cunistd_2eh_3e_2eF__OK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eF__TEST_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cunistd_2eh_3e_2eF__TEST, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eF__TLOCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cunistd_2eh_3e_2eF__TLOCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eF__ULOCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cunistd_2eh_3e_2eF__ULOCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eL__INCR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cunistd_2eh_3e_2eL__INCR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eL__SET_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cunistd_2eh_3e_2eL__SET, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eL__XTND_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cunistd_2eh_3e_2eL__XTND, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eR__OK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cunistd_2eh_3e_2eR__OK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eSEEK__CUR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cunistd_2eh_3e_2eSEEK__CUR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eSEEK__DATA_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cunistd_2eh_3e_2eSEEK__DATA, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eSEEK__END_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cunistd_2eh_3e_2eSEEK__END, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eSEEK__HOLE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cunistd_2eh_3e_2eSEEK__HOLE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eSEEK__SET_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cunistd_2eh_3e_2eSEEK__SET, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eSTDERR__FILENO_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cunistd_2eh_3e_2eSTDERR__FILENO, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eSTDIN__FILENO_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cunistd_2eh_3e_2eSTDIN__FILENO, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eSTDOUT__FILENO_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cunistd_2eh_3e_2eSTDOUT__FILENO, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eW__OK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cunistd_2eh_3e_2eW__OK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cunistd_2eh_3e_2eX__OK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cunistd_2eh_3e_2eX__OK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2e_3cunistd_2eh_3e() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @_3cunistd_2eh_3e_2eSTDIN__FILENO_2einit()
  br label %bb1
bb1:
  call void @_3cunistd_2eh_3e_2eSTDOUT__FILENO_2einit()
  br label %bb2
bb2:
  call void @_3cunistd_2eh_3e_2eSTDERR__FILENO_2einit()
  br label %bb3
bb3:
  call void @_3cunistd_2eh_3e_2eR__OK_2einit()
  br label %bb4
bb4:
  call void @_3cunistd_2eh_3e_2eW__OK_2einit()
  br label %bb5
bb5:
  call void @_3cunistd_2eh_3e_2eX__OK_2einit()
  br label %bb6
bb6:
  call void @_3cunistd_2eh_3e_2eF__OK_2einit()
  br label %bb7
bb7:
  call void @_3cunistd_2eh_3e_2eSEEK__SET_2einit()
  br label %bb8
bb8:
  call void @_3cunistd_2eh_3e_2eSEEK__CUR_2einit()
  br label %bb9
bb9:
  call void @_3cunistd_2eh_3e_2eSEEK__END_2einit()
  br label %bb10
bb10:
  call void @_3cunistd_2eh_3e_2eSEEK__DATA_2einit()
  br label %bb11
bb11:
  call void @_3cunistd_2eh_3e_2eSEEK__HOLE_2einit()
  br label %bb12
bb12:
  call void @_3cunistd_2eh_3e_2eL__SET_2einit()
  br label %bb13
bb13:
  call void @_3cunistd_2eh_3e_2eL__INCR_2einit()
  br label %bb14
bb14:
  call void @_3cunistd_2eh_3e_2eL__XTND_2einit()
  br label %bb15
bb15:
  call void @_3cunistd_2eh_3e_2eF__ULOCK_2einit()
  br label %bb16
bb16:
  call void @_3cunistd_2eh_3e_2eF__LOCK_2einit()
  br label %bb17
bb17:
  call void @_3cunistd_2eh_3e_2eF__TLOCK_2einit()
  br label %bb18
bb18:
  call void @_3cunistd_2eh_3e_2eF__TEST_2einit()
  br label %bb19
bb19:
  call void @_3cunistd_2eh_3e_2eCLOSE__RANGE__UNSHARE_2einit()
  br label %bb20
bb20:
  call void @_3cunistd_2eh_3e_2eCLOSE__RANGE__CLOEXEC_2einit()
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}


!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
