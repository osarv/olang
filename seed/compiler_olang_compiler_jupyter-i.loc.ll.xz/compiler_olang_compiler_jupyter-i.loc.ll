; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_52ebf82c81e62ac8_398e8a0e22669fdc = weak_odr constant [54 x i8] c"std/prelude/vec.olang:170: slice bounds out of range\0A\00"
@olang_loc_700189a95fc52edc_5dbb167cd876de20 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:170: slice bounds out of range\0A\00"
@olang_loc_8a9f5308fd72d88_6bfbd31656a1972c = weak_odr constant [54 x i8] c"std/prelude/vec.olang:170: slice bounds out of range\0A\00"
@olang_loc_8b4a7c5a190fd12e_6969a0fdb365e132 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_93d6c56decf70e25_efca121bd0cdc3a9 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_9a3e6fec75deff1a_50d627c7d167b22e = weak_odr constant [54 x i8] c"std/prelude/vec.olang:170: slice bounds out of range\0A\00"
@olang_loc_aba0837864f887e4_581934bce867f868 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
