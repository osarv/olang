; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/check:ownerAt" = type { i32, i1 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, i1 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
%"compiler/check:errNarrow" = type { i32, i32, i64, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Bind" = type { i32, ptr }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/check:signMag" = type { i1, i128 }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCheckProgram(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l12 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca i32
  %l52 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca ptr
  %l65 = alloca i64
  %l74 = alloca i64
  %l76 = alloca i64
  %l81 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l84 = alloca ptr
  %l85 = alloca i32
  %l89 = alloca i32
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l98 = alloca i1
  %l100 = alloca i1
  %l102 = alloca i1
  %l106 = alloca i1
  %l109 = alloca i1
  %l124 = alloca ptr
  %l126 = alloca i1
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i32
  %l130 = alloca i1
  %l138 = alloca ptr
  %l140 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l142 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t4)
  br label %bb1
bb1:
  store i64 0, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l18
  br label %bb2
bb2:
  %t12 = load i64, ptr %l18, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l2, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l25, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l25, !tbaa !24
  store i64 %t39, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l1, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t66 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t62, i64 %t57)
  store i32 %t66, ptr %l46
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l5, !tbaa !24
  br label %bb9
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 94
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = icmp slt i64 %t74, 0
  br i1 %t76, label %bb16, label %bb17
bb16:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l52, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/load:Loader", ptr %t85, i32 0, i32 4
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRecordCount(ptr %v0, ptr %t88)
  store i64 %t90, ptr %l57
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t91 = load i64, ptr %l57, !tbaa !24
  %t92 = load ptr, ptr %l52, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 94
  store i64 %t91, ptr %t93, !tbaa !24
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l58, !tbaa !29
  %t95 = load ptr, ptr %l58, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 69
  %t97 = load i64, ptr %t96, !tbaa !24
  %t99 = add i64 %t97, 1
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 69
  store i64 %t99, ptr %t102, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l65
  br label %bb21
bb21:
  %t115 = load i64, ptr %l65, !tbaa !24
  store i64 %t115, ptr %l7, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattempt(ptr %v0, ptr %t116)
  br label %bb22
bb22:
  %t118 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnset(ptr %v0, ptr %t118)
  br label %bb23
bb23:
  %t120 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleLandings(ptr %v0, ptr %t120)
  br label %bb24
bb24:
  %t122 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleHeldWalks(ptr %v0, ptr %t122)
  br label %bb25
bb25:
  %t124 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleIdle(ptr %v0, ptr %t124)
  br label %bb26
bb26:
  %t126 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnread(ptr %v0, ptr %t126)
  br label %bb27
bb27:
  store i1 false, ptr %l8, !tbaa !21
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 56
  store ptr %t130, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load i64, ptr %l10, !tbaa !24
  store i64 %t132, ptr %l74, !tbaa !24
  %t133 = load ptr, ptr %l9, !tbaa !29
  %t135 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %t133)
  store i64 %t135, ptr %l76
  br label %bb29
bb29:
  %t136 = load i64, ptr %l74, !tbaa !24
  %t137 = load i64, ptr %l76, !tbaa !24
  %t138 = icmp slt i64 %t136, %t137
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb31:
  br label %bb32
bb32:
  %t142 = load ptr, ptr %l9, !tbaa !29
  %t143 = load i64, ptr %l10, !tbaa !24
  %t146 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %t142, i64 %t143)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t146, ptr %l81
  br label %bb33
bb33:
  %t147 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l81
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t147, ptr %l11
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  store ptr %t153, ptr %l84, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 55
  %t157 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11, i32 0, i32 0
  %t158 = load i64, ptr %t157, !tbaa !24
  %t161 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %t156, i64 %t158)
  %t162 = extractvalue { i32, i32 } %t161, 1
  %t163 = extractvalue { i32, i32 } %t161, 0
  store i32 %t163, ptr %l90
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb35, label %ok.165, !prof !99
ok.165:
  store i32 %t162, ptr %l89
  br label %bb34
bb34:
  %t166 = load i32, ptr %l89, !tbaa !23
  store i32 %t166, ptr %l85, !tbaa !23
  br label %bb37
bb35:
  br label %bb36
bb36:
  call void @__olang_ert_req_clear()
  store i32 0, ptr %l85, !tbaa !23
  br label %bb37
bb37:
  %t167 = load ptr, ptr %l84, !tbaa !29
  %t168 = load i32, ptr %l85, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s7, ptr %t167, i32 %t168)
  store { i64, ptr } %t169, ptr %l91
  br label %bb38
bb38:
  %t170 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  %t172 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l11, i32 0, i32 1
  %t173 = load i64, ptr %t172, !tbaa !24
  %t176 = icmp ne i64 %t171, %t173
  br i1 %t176, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb41
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb42:
  %t178 = load i64, ptr %l10, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l10, !tbaa !24
  br label %bb28
bb43:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFacts(ptr %v0, ptr %t182)
  store i1 %t184, ptr %l98
  br label %bb44
bb44:
  %t185 = load i1, ptr %l98, !tbaa !21
  store i1 %t185, ptr %l12, !tbaa !21
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleInPlace(ptr %v0, ptr %t186)
  store i1 %t188, ptr %l100
  br label %bb45
bb45:
  %t189 = load i1, ptr %l100, !tbaa !21
  store i1 %t189, ptr %l13, !tbaa !21
  %t190 = load i1, ptr %l12, !tbaa !21
  br i1 %t190, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb48
bb47:
  %t192 = load i1, ptr %l13, !tbaa !21
  store i1 %t192, ptr %l102, !tbaa !21
  br label %bb48
bb48:
  %t194 = load i1, ptr %l102, !tbaa !21
  store i1 %t194, ptr %l12, !tbaa !21
  %t195 = load i1, ptr %l8, !tbaa !21
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb49, label %bb50
bb49:
  %t199 = load i1, ptr %l12, !tbaa !21
  %t201 = xor i1 %t199, true
  store i1 %t201, ptr %l106, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb51
bb51:
  %t203 = load i1, ptr %l106, !tbaa !21
  br i1 %t203, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb54
bb53:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/check:Checker", ptr %t204, i32 0, i32 69
  %t207 = load i64, ptr %t206, !tbaa !24
  %t209 = icmp sge i64 %t207, 20
  store i1 %t209, ptr %l109, !tbaa !21
  br label %bb54
bb54:
  %t211 = load i1, ptr %l109, !tbaa !21
  br i1 %t211, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t212 = load i1, ptr %l12, !tbaa !21
  br i1 %t212, label %bb57, label %bb58
bb56:
  br label %bb80
bb57:
  %t214 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsUndecided(ptr %v0, ptr %t214)
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t216 = load i1, ptr %l13, !tbaa !21
  br i1 %t216, label %bb61, label %bb62
bb61:
  %t218 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlaceUndecided(ptr %v0, ptr %t218)
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  %t220 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFixed(ptr %v0, ptr %t220)
  br label %bb65
bb65:
  %t222 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleDropOrder(ptr %v0, ptr %t222)
  br label %bb66
bb66:
  %t224 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyEffects(ptr %v0, ptr %t224)
  br label %bb67
bb67:
  %t226 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderGlobals(ptr %v0, ptr %t226)
  br label %bb68
bb68:
  %t228 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleAllViews(ptr %v0, ptr %t228)
  br label %bb69
bb69:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t235 = getelementptr %"compiler/generic:Program", ptr %t233, i32 0, i32 0
  %t236 = load ptr, ptr %t235, !tbaa !29
  store ptr %t236, ptr %l124, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutStorage(ptr %v0, ptr %t237)
  store i1 %t239, ptr %l126
  br label %bb70
bb70:
  %t240 = load i1, ptr %l126, !tbaa !21
  %t241 = load ptr, ptr %l124, !tbaa !29
  %t242 = getelementptr %"compiler/load:Loader", ptr %t241, i32 0, i32 8
  store i1 %t240, ptr %t242, !tbaa !21
  %t243 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s10, ptr %s10, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d0, i32 0, i32 1) })
  %t244 = extractvalue { i32, { i64, ptr } } %t243, 1
  %t245 = extractvalue { i32, { i64, ptr } } %t243, 0
  store i32 %t245, ptr %l129
  %t246 = icmp ne i32 %t245, 0
  br i1 %t246, label %bb72, label %ok.247, !prof !99
ok.247:
  store { i64, ptr } %t244, ptr %l128
  br label %bb71
bb71:
  %t248 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t248, ptr %l127, !tbaa !27
  br label %bb74
bb72:
  br label %bb73
bb73:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l127, !tbaa !27
  br label %bb74
bb74:
  %t249 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t250 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t249, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t250, ptr %l130
  br label %bb75
bb75:
  %t251 = load i1, ptr %l130, !tbaa !21
  %t252 = xor i1 %t251, true
  br i1 %t252, label %bb76, label %bb77
bb76:
  %t254 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleReport(ptr %v0, ptr %t254)
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s10)
  br label %ret
bb80:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/generic:Program", ptr %t259, i32 0, i32 0
  %t262 = load ptr, ptr %t261, !tbaa !29
  %t264 = getelementptr %"compiler/load:Loader", ptr %t262, i32 0, i32 4
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t266 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t265, i64 %t266)
  br label %bb81
bb81:
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l138, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 59
  %t273 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t272
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t273, ptr %l140
  %t275 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H7f6fc75342dba0a5a8ac6e31960b7ffa(ptr %v0, ptr %l140)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t275, ptr %l142
  br label %bb82
bb82:
  %t276 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l142
  %t277 = load ptr, ptr %l138, !tbaa !29
  %t278 = getelementptr %"compiler/check:Checker", ptr %t277, i32 0, i32 58
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t276, ptr %t278
  %t279 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereset(ptr %v0, ptr %t279)
  br label %bb83
bb83:
  br label %bb84
bb84:
  br label %bb20
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t5 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 7
  store i64 %a1, ptr %t5, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l17 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l7, !tbaa !29
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t6)
  store %"compiler/source:Span" %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l9
  %t11 = load %"compiler/source:Span", ptr %l11
  %t12 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t9, %"compiler/source:Span" %t10, %"compiler/source:Span" %t11, i64 2)
  store %"compiler/source:Span" %t12, ptr %l12
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t13)
  store i32 %t16, ptr %l15
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l12
  %t20 = load i32, ptr %l15, !tbaa !23
  %t22 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v3, ptr %t18, %"compiler/source:Span" %t19, i32 %t20, ptr %t17)
  store i32 %t22, ptr %l17
  br label %bb5
bb5:
  %t23 = load i32, ptr %l17, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t28 = icmp eq i32 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t30, %"compiler/source:Span" %t31)
  store ptr %t34, ptr %l23
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load ptr, ptr %l23, !tbaa !29
  store ptr %t35, ptr %rv
  br label %ret
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t37, ptr %l25
  %t38 = load ptr, ptr %l2, !tbaa !29
  store ptr %t38, ptr %l26, !tbaa !29
  %t39 = load i32, ptr %l5, !tbaa !23
  store i32 %t39, ptr %l27, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l28, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l30
  br label %bb10
bb10:
  %t44 = mul i64 1, 4
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 1, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l31, !tbaa !27
  %t48 = load i32, ptr %l30, !tbaa !23
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 0
  store i32 %t48, ptr %t51, !tbaa !33
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l34
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t56)
  store %"compiler/source:Span" %t58, ptr %l36
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l34
  %t61 = load %"compiler/source:Span", ptr %l36
  %t62 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t59, %"compiler/source:Span" %t60, %"compiler/source:Span" %t61, i64 2)
  store %"compiler/source:Span" %t62, ptr %l37
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l28, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t65 = load %"compiler/source:Span", ptr %l37
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t63, { i64, ptr } %t64, %"compiler/source:Span" %t65, i1 true)
  store i32 %t66, ptr %l38
  br label %bb14
bb14:
  %t67 = load ptr, ptr %l24, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l25
  %t69 = load ptr, ptr %l26, !tbaa !29
  %t70 = load i32, ptr %l27, !tbaa !23
  %t71 = load i32, ptr %l38, !range !{i32 0, i32 3}
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v1, ptr %v4, ptr %t67, %"compiler/source:Span" %t68, ptr %t69, i32 %t70, i32 %t71)
  store ptr %t72, ptr %l39
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t73 = load ptr, ptr %l39, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanySpawned(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l14 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca i64
  %l25 = alloca { i64, ptr }
  %l30 = alloca i32
  %l33 = alloca %"std/prelude/text:StringBuilder"
  %l36 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l53 = alloca i64
  %l56 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca i64
  %l68 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca i32
  %l77 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca { i64, ptr }
  %l86 = alloca %"compiler/diagmsg:Msg"
  %l87 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l14, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t8)
  store %"compiler/source:Span" %t10, ptr %l16
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l17, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l19
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l17, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l19
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t15, %"compiler/source:Span" %t16)
  store { i64, ptr } %t17, ptr %l20
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t19 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawned(ptr %v0, ptr %s1, { i64, ptr } %t18)
  store %"compiler/diagmsg:Msg" %t19, ptr %l21
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l16
  %t22 = load %"compiler/diagmsg:Msg", ptr %l21
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t20, %"compiler/source:Span" %t21, %"compiler/diagmsg:Msg" %t22)
  store i64 %t23, ptr %l22
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t24, i32 %t25)
  store { i64, ptr } %t28, ptr %l25
  br label %bb9
bb9:
  %t29 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t29, ptr %l5, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l4, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l30
  br label %bb10
bb10:
  %t40 = load i32, ptr %l30, !range !{i32 0, i32 33}
  %t42 = trunc i64 22 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t45, ptr %l33
  br label %bb13
bb12:
  br label %bb33
bb13:
  %t46 = load %"std/prelude/text:StringBuilder", ptr %l33
  store %"std/prelude/text:StringBuilder" %t46, ptr %l6
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  store ptr %t52, ptr %l36, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l41
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l36, !tbaa !29
  %t64 = load i32, ptr %l41, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t63, i32 %t64)
  store { i64, ptr } %t65, ptr %l42
  br label %bb15
bb15:
  %t66 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t66, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb18:
  br label %bb19
bb19:
  %t79 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t79, ptr %l49, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i32, ptr %t83, i64 %t80
  %t85 = load i32, ptr %t84, !tbaa !33
  store i32 %t85, ptr %l10, !tbaa !23
  %t88 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s2, ptr %l6)
  store i64 %t88, ptr %l53
  br label %bb20
bb20:
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = icmp sgt i64 %t89, 0
  br i1 %t90, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s5, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  store ptr %l6, ptr %l56, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l10, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t93, i32 %t94)
  store { i64, ptr } %t97, ptr %l59
  br label %bb25
bb25:
  %t98 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load ptr, ptr %l56, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s4, ptr %t105, { i64, ptr } %t104)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  %t107 = load i64, ptr %l8, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l8, !tbaa !24
  br label %bb16
bb28:
  %t112 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s0, ptr %l6)
  store { i64, ptr } %t112, ptr %l64
  br label %bb29
bb29:
  %t113 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t115 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l66, !tbaa !24
  %t118 = load i64, ptr %l66, !tbaa !24
  %t119 = icmp eq i64 %t114, %t118
  br i1 %t119, label %bb30, label %bb31
bb30:
  %t121 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l66, !tbaa !24
  %t126 = mul i64 %t125, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t122, ptr %t124, i64 %t126, i1 false)
  br label %bb32
bb31:
  %t127 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t127, ptr %l5, !tbaa !27
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l68, !tbaa !29
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t129)
  store %"compiler/source:Span" %t131, ptr %l70
  br label %bb34
bb34:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l71, !tbaa !29
  %t133 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t133, ptr %l72, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr ptr, ptr %t135, i64 0
  %t137 = load ptr, ptr %t136, !tbaa !39
  %t139 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t137)
  store %"compiler/source:Span" %t139, ptr %l74
  br label %bb35
bb35:
  %t140 = getelementptr %"compiler/source:Span", ptr %l74, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  store i32 %t141, ptr %l75, !tbaa !23
  %t144 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %a2)
  store %"compiler/source:Span" %t144, ptr %l77
  br label %bb36
bb36:
  %t145 = getelementptr %"compiler/source:Span", ptr %l77, i32 0, i32 0
  %t146 = load i32, ptr %t145, !tbaa !23
  %t147 = load i32, ptr %l75, !tbaa !23
  %t149 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t147, i32 %t146)
  store %"compiler/source:Span" %t149, ptr %l79
  br label %bb37
bb37:
  %t150 = load ptr, ptr %l71, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l79
  %t152 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t150, %"compiler/source:Span" %t151)
  store { i64, ptr } %t152, ptr %l80
  br label %bb38
bb38:
  %t153 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t153, ptr %l81, !tbaa !27
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l82, !tbaa !29
  %t155 = load ptr, ptr %l3, !tbaa !29
  %t157 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t155)
  store %"compiler/source:Span" %t157, ptr %l84
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l82, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l84
  %t160 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t158, %"compiler/source:Span" %t159)
  store { i64, ptr } %t160, ptr %l85
  br label %bb40
bb40:
  %t161 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t164 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawnedResult(ptr %v0, ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t161, { i64, ptr } %t162, { i64, ptr } %t163)
  store %"compiler/diagmsg:Msg" %t164, ptr %l86
  br label %bb41
bb41:
  %t165 = load ptr, ptr %l68, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l70
  %t167 = load %"compiler/diagmsg:Msg", ptr %l86
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t165, %"compiler/source:Span" %t166, %"compiler/diagmsg:Msg" %t167)
  store i64 %t168, ptr %l87
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyTable(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"compiler/generic:AnySlot"
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/generic:AnySlot"
  %l30 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l49 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i32
  %l71 = alloca i64
  %l74 = alloca i64
  %l92 = alloca { i64, ptr }
  %l99 = alloca i64
  %l107 = alloca i32
  %l109 = alloca ptr
  %l111 = alloca i64
  %l112 = alloca i64
  %l117 = alloca i32
  %l124 = alloca i32
  %l128 = alloca i1
  %l132 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l148 = alloca %"compiler/diagmsg:Msg"
  %l149 = alloca i64
  %l152 = alloca ptr
  %l153 = alloca i64
  %l154 = alloca i64
  %l157 = alloca { i64, ptr }
  %l159 = alloca %"compiler/diagmsg:Msg"
  %l170 = alloca ptr
  %l172 = alloca ptr
  %l180 = alloca i64
  %l183 = alloca i64
  %l201 = alloca { i64, ptr }
  %l206 = alloca ptr
  %l211 = alloca i32
  %l212 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l218 = alloca i64
  %l221 = alloca ptr
  %l222 = alloca i32
  %l228 = alloca i32
  %l229 = alloca i32
  %l231 = alloca ptr
  %l239 = alloca i64
  %l242 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i64
  %t446 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  %t10 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableOf(ptr %v0, ptr %t4, i32 %t5, i32 %t6)
  store i64 %t10, ptr %l35
  br label %bb1
bb1:
  %t11 = load i64, ptr %l35, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 134
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l41
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t23 = load i1, ptr %l41, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i64 -1, ptr %l42, !tbaa !24
  br label %bb7
bb6:
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l42, !tbaa !24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i64, ptr %l42, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l45, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  store i32 %t31, ptr %l46, !tbaa !23
  %t32 = load i32, ptr %l2, !tbaa !23
  store i32 %t32, ptr %l47, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t33)
  store ptr %t35, ptr %l49
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l49, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 2
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = load %"compiler/source:Span", ptr %l3
  %t41 = load ptr, ptr %l45, !tbaa !29
  %t42 = load i32, ptr %l46, !tbaa !23
  %t43 = load i32, ptr %l47, !tbaa !23
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eNewAnyTable(ptr %v0, ptr %t41, i32 %t42, i32 %t43, i64 %t39, %"compiler/source:Span" %t40)
  store i64 %t46, ptr %l53
  br label %bb10
bb10:
  %t47 = load i64, ptr %l53, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t51, i32 %t52)
  store { i64, ptr } %t55, ptr %l57
  br label %bb11
bb11:
  %t56 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l59, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %l1, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l64
  br label %bb12
bb12:
  %t71 = load ptr, ptr %l59, !tbaa !29
  %t72 = load i32, ptr %l64, !tbaa !23
  %t73 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t73, ptr %l65
  br label %bb13
bb13:
  %t74 = load i32, ptr %l65, !tbaa !23
  store i32 %t74, ptr %l7, !tbaa !23
  store i64 0, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = icmp sgt i64 %t79, %t80
  br i1 %t83, label %bb14, label %bb15
bb14:
  %t85 = load i64, ptr %l10, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb19
bb16:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = sub i64 %t89, %t90
  %t94 = load i64, ptr %l10, !tbaa !24
  %t97 = add i64 %t93, %t94
  %t99 = sub i64 %t97, 1
  %t100 = load i64, ptr %l10, !tbaa !24
  %t103 = sdiv i64 %t99, %t100
  store i64 %t103, ptr %l74, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb18
bb18:
  %t105 = load i64, ptr %l74, !tbaa !24
  store i64 %t105, ptr %l71, !tbaa !24
  br label %bb19
bb19:
  %t106 = load i64, ptr %l71, !tbaa !24
  store i64 %t106, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb20
bb20:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb21, label %bb22
bb21:
  br label %bb59
bb22:
  br label %bb23
bb23:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l10, !tbaa !24
  %t120 = mul i64 %t116, %t117
  %t123 = add i64 %t115, %t120
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t125, ptr %l92, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/generic:AnySlot", ptr %t129, i64 %t123
  %t131 = load %"compiler/generic:AnySlot", ptr %t130
  store %"compiler/generic:AnySlot" %t131, ptr %l14
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load i32, ptr %l1, !tbaa !23
  %t138 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t139 = load i32, ptr %t138, !tbaa !23
  %t143 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t136, i32 %t137, i32 %t139)
  store i64 %t143, ptr %l99
  br label %bb24
bb24:
  %t144 = load i64, ptr %l99, !tbaa !24
  store i64 %t144, ptr %l15, !tbaa !24
  %t145 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t145, ptr %l16, !tbaa !23
  %t147 = load i64, ptr %l15, !tbaa !24
  %t149 = icmp sge i64 %t147, 0
  br i1 %t149, label %bb25, label %bb26
bb25:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i32, ptr %l1, !tbaa !23
  %t160 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t154, i64 %t155, i32 %t156)
  store i32 %t160, ptr %l107
  br label %bb27
bb26:
  %t161 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 3
  %t162 = load i64, ptr %t161, !tbaa !24
  %t164 = icmp sge i64 %t162, 0
  br i1 %t164, label %bb34, label %bb35
bb27:
  %t166 = load i32, ptr %l107, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  store ptr %t170, ptr %l109, !tbaa !29
  %t171 = load i64, ptr %l15, !tbaa !24
  %t173 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t171)
  store i64 %t173, ptr %l111
  br label %bb28
bb28:
  %t174 = load ptr, ptr %l109, !tbaa !29
  %t175 = load i64, ptr %l111, !tbaa !24
  %t176 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t174, i64 %t175)
  store i64 %t176, ptr %l112
  br label %bb29
bb29:
  %t177 = load i64, ptr %l112, !tbaa !24
  %t178 = icmp sgt i64 %t177, 0
  br i1 %t178, label %bb30, label %bb31
bb30:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l15, !tbaa !24
  %t182 = load i32, ptr %l1, !tbaa !23
  %t186 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %t180, i64 %t181, i32 %t182)
  store i32 %t186, ptr %l117
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t187 = load i32, ptr %l117, !tbaa !23
  store i32 %t187, ptr %l16, !tbaa !23
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 3
  %t193 = load i64, ptr %t192, !tbaa !24
  %t194 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %t191, i64 %t193, i32 %t194)
  store i32 %t198, ptr %l124
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t199 = load i32, ptr %l124, !tbaa !23
  store i32 %t199, ptr %l16, !tbaa !23
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t200 = load i32, ptr %l16, !tbaa !23
  %t201 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t204 = icmp ne i32 %t200, %t201
  br i1 %t204, label %bb39, label %bb40
bb39:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i32, ptr %l16, !tbaa !23
  %t208 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 5
  %t209 = load i32, ptr %t208, !tbaa !23
  %t213 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %t206, i32 %t207, i32 %t209)
  store i1 %t213, ptr %l132
  br label %bb41
bb40:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb42
bb41:
  %t214 = load i1, ptr %l132, !tbaa !21
  %t215 = xor i1 %t214, true
  store i1 %t215, ptr %l128, !tbaa !21
  br label %bb42
bb42:
  %t217 = load i1, ptr %l128, !tbaa !21
  br i1 %t217, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l134, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t219, ptr %l135
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l1, !tbaa !23
  %t224 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t220, i32 %t221)
  store { i64, ptr } %t224, ptr %l138
  br label %bb45
bb44:
  br label %bb57
bb45:
  %t225 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  %t227 = extractvalue { i64, ptr } %t225, 1
  %t228 = mul i64 %t226, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t229, ptr %t227, i64 %t228, i1 false)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l139, !tbaa !27
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t234 = load i32, ptr %t233, !tbaa !23
  %t237 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t232, i32 %t234)
  store { i64, ptr } %t237, ptr %l142
  br label %bb46
bb46:
  %t238 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 0
  %t240 = extractvalue { i64, ptr } %t238, 1
  %t241 = mul i64 %t239, 1
  %t242 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t241)
  call void @llvm.memcpy.p0.p0.i64(ptr %t242, ptr %t240, i64 %t241, i1 false)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  store { i64, ptr } %t244, ptr %l143, !tbaa !27
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i32, ptr %l2, !tbaa !23
  %t249 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t245, i32 %t246)
  store { i64, ptr } %t249, ptr %l146
  br label %bb47
bb47:
  %t250 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t257 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t260 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %s8, ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t257, { i64, ptr } %t258, { i64, ptr } %t256)
  store %"compiler/diagmsg:Msg" %t260, ptr %l148
  br label %bb48
bb48:
  %t261 = load ptr, ptr %l134, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l135
  %t263 = load %"compiler/diagmsg:Msg", ptr %l148
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t261, %"compiler/source:Span" %t262, %"compiler/diagmsg:Msg" %t263)
  store i64 %t264, ptr %l149
  br label %bb49
bb49:
  %t265 = load i64, ptr %l149, !tbaa !24
  store i64 %t265, ptr %l17, !tbaa !24
  %t266 = load i64, ptr %l15, !tbaa !24
  %t268 = icmp sge i64 %t266, 0
  br i1 %t268, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l152, !tbaa !29
  %t271 = load i64, ptr %l17, !tbaa !24
  store i64 %t271, ptr %l153, !tbaa !24
  %t272 = load i64, ptr %l15, !tbaa !24
  store i64 %t272, ptr %l154, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t275 = load i32, ptr %t274, !tbaa !23
  %t278 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t273, i32 %t275)
  store { i64, ptr } %t278, ptr %l157
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t279 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 0
  %t281 = extractvalue { i64, ptr } %t279, 1
  %t282 = mul i64 %t280, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t282)
  call void @llvm.memcpy.p0.p0.i64(ptr %t283, ptr %t281, i64 %t282, i1 false)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  %t287 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteAnyMethod(ptr %s9, ptr %s9, { i64, ptr } %t285)
  store %"compiler/diagmsg:Msg" %t287, ptr %l159
  br label %bb53
bb53:
  %t288 = load ptr, ptr %l152, !tbaa !29
  %t289 = load i64, ptr %l153, !tbaa !24
  %t290 = load i64, ptr %l154, !tbaa !24
  %t291 = load %"compiler/diagmsg:Msg", ptr %l159
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %s9, ptr %t288, i64 %t289, i64 %t290, %"compiler/diagmsg:Msg" %t291)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 134
  %t295 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t294, i64 %t295, i1 true)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t299 = load i64, ptr %l12, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l12, !tbaa !24
  br label %bb20
bb59:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = getelementptr %"compiler/generic:Program", ptr %t306, i32 0, i32 52
  %t309 = load i64, ptr %l5, !tbaa !24
  %t312 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H0986089bcad3c266fbd2f46fa03b07d1(ptr %v0, ptr %v0, ptr %t308, i64 %t309)
  store ptr %t312, ptr %l170
  br label %bb60
bb60:
  %t313 = load ptr, ptr %l170, !tbaa !29
  store ptr %t313, ptr %l18, !tbaa !29
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t314)
  store ptr %t316, ptr %l172
  br label %bb61
bb61:
  %t317 = load ptr, ptr %l172, !tbaa !29
  %t319 = getelementptr %"compiler/check:frame", ptr %t317, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  store i64 %t320, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t322 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t322, 0
  store i64 %t324, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t326 = load i64, ptr %l21, !tbaa !24
  %t327 = load i64, ptr %l20, !tbaa !24
  %t330 = icmp sgt i64 %t326, %t327
  br i1 %t330, label %bb62, label %bb63
bb62:
  %t332 = load i64, ptr %l22, !tbaa !24
  %t334 = icmp sgt i64 %t332, 0
  br i1 %t334, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb67
bb64:
  %t336 = load i64, ptr %l21, !tbaa !24
  %t337 = load i64, ptr %l20, !tbaa !24
  %t340 = sub i64 %t336, %t337
  %t341 = load i64, ptr %l22, !tbaa !24
  %t344 = add i64 %t340, %t341
  %t346 = sub i64 %t344, 1
  %t347 = load i64, ptr %l22, !tbaa !24
  %t350 = sdiv i64 %t346, %t347
  store i64 %t350, ptr %l183, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb66
bb66:
  %t352 = load i64, ptr %l183, !tbaa !24
  store i64 %t352, ptr %l180, !tbaa !24
  br label %bb67
bb67:
  %t353 = load i64, ptr %l180, !tbaa !24
  store i64 %t353, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb68
bb68:
  %t354 = load i64, ptr %l24, !tbaa !24
  %t355 = load i64, ptr %l23, !tbaa !24
  %t358 = icmp slt i64 %t354, %t355
  %t360 = xor i1 %t358, true
  br i1 %t360, label %bb69, label %bb70
bb69:
  br label %bb80
bb70:
  br label %bb71
bb71:
  %t362 = load i64, ptr %l20, !tbaa !24
  %t363 = load i64, ptr %l24, !tbaa !24
  %t364 = load i64, ptr %l22, !tbaa !24
  %t367 = mul i64 %t363, %t364
  %t370 = add i64 %t362, %t367
  store i64 %t370, ptr %l25, !tbaa !24
  %t372 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t372, ptr %l201, !tbaa !27
  %t373 = load i64, ptr %l25, !tbaa !24
  %t375 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr %"compiler/generic:AnySlot", ptr %t376, i64 %t373
  %t378 = load %"compiler/generic:AnySlot", ptr %t377
  store %"compiler/generic:AnySlot" %t378, ptr %l26
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t385 = getelementptr %"compiler/generic:Program", ptr %t383, i32 0, i32 2
  store ptr %t385, ptr %l206, !tbaa !29
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/check:Checker", ptr %t386, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !29
  %t391 = getelementptr %"compiler/generic:Program", ptr %t389, i32 0, i32 2
  %t392 = getelementptr %"compiler/generic:AnySlot", ptr %l26, i32 0, i32 5
  %t393 = load i32, ptr %t392, !tbaa !23
  %t396 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t391, i32 %t393)
  store i32 %t396, ptr %l211
  br label %bb72
bb72:
  %t397 = load ptr, ptr %l206, !tbaa !29
  %t398 = load i32, ptr %l211, !tbaa !23
  %t399 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t397, i32 %t398)
  store { i64, ptr } %t399, ptr %l212
  br label %bb73
bb73:
  %t400 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/check:Checker", ptr %t401, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/generic:Program", ptr %t404, i32 0, i32 2
  store { i64, ptr } %t400, ptr %l216, !tbaa !27
  %t408 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = getelementptr i32, ptr %t409, i64 0
  %t411 = load i32, ptr %t410, !tbaa !33
  %t414 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t406, i32 %t411)
  store i64 %t414, ptr %l218
  br label %bb74
bb74:
  %t415 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t416 = load i64, ptr %l218, !tbaa !24
  %t418 = and i64 %t416, %t415
  %t420 = load ptr, ptr %l0, !tbaa !29
  store ptr %t420, ptr %l221, !tbaa !29
  %t421 = getelementptr %"compiler/generic:AnySlot", ptr %l26, i32 0, i32 5
  %t422 = load i32, ptr %t421, !tbaa !23
  store i32 %t422, ptr %l222, !tbaa !23
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !29
  %t428 = getelementptr %"compiler/generic:Program", ptr %t426, i32 0, i32 2
  %t429 = load i32, ptr %l7, !tbaa !23
  %t434 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t428, i32 %t429, i64 %t418)
  store i32 %t434, ptr %l228
  br label %bb75
bb75:
  %t435 = load ptr, ptr %l221, !tbaa !29
  %t436 = load i32, ptr %l222, !tbaa !23
  %t437 = load i32, ptr %l228, !tbaa !23
  %t438 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %t435, i32 %t436, i32 %t437)
  store i32 %t438, ptr %l229
  br label %bb76
bb76:
  %t439 = load i32, ptr %l229, !tbaa !23
  %t440 = load ptr, ptr %l18, !tbaa !29
  %t442 = getelementptr %"compiler/generic:AnyTable", ptr %t440, i32 0, i32 5
  store ptr %t442, ptr %l231, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load i64, ptr %l5, !tbaa !24
  %t445 = load i64, ptr %l25, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t446
  %t447 = getelementptr { i64, [2 x i64] }, ptr %t446, i32 0, i32 0
  store i64 9, ptr %t447
  %t449 = insertvalue { i64, i64 } undef, i64 %t444, 0
  %t451 = insertvalue { i64, i64 } %t449, i64 %t445, 1
  %t452 = getelementptr { i64, [2 x i64] }, ptr %t446, i32 0, i32 1
  store { i64, i64 } %t451, ptr %t452
  %t453 = load { i64, [2 x i64] }, ptr %t446
  %t455 = load i64, ptr %l19, !tbaa !24
  %t456 = load %"compiler/source:Span", ptr %l3
  %t462 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t443, { i64, [2 x i64] } %t453, i32 %t439, i64 %t455, %"compiler/source:Span" %t456)
  store i64 %t462, ptr %l239
  br label %bb77
bb77:
  %t463 = load ptr, ptr %l231, !tbaa !29
  %t464 = load i64, ptr %l239, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t463, i64 %t464)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t465 = load i64, ptr %l24, !tbaa !24
  %t467 = add i64 %t465, 1
  store i64 %t467, ptr %l24, !tbaa !24
  br label %bb68
bb80:
  %t469 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t469, ptr %l242
  br label %bb81
bb81:
  %t470 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l242
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t470, ptr %l30
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %s0, ptr %t471, i32 %t472, ptr %l30, i64 0)
  br label %bb82
bb82:
  %t476 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t476, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassertStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l21 = alloca { i64, [3 x i64] }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l27 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca i1
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca i64
  %l76 = alloca i64
  %l78 = alloca i64
  %l83 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca { i64, ptr }
  %l98 = alloca i1
  %l101 = alloca i1
  %l105 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l115 = alloca i64
  %l117 = alloca i64
  %l118 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l124 = alloca i64
  %l125 = alloca ptr
  %l128 = alloca ptr
  %l130 = alloca i32
  %l132 = alloca i32
  %l133 = alloca i64
  %l137 = alloca i64
  %l139 = alloca i64
  %l144 = alloca i64
  %l149 = alloca ptr
  %l151 = alloca %"compiler/source:Span"
  %l152 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l155 = alloca i64
  %l157 = alloca i64
  %l158 = alloca { i64, ptr }
  %l161 = alloca i1
  %l168 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l170 = alloca { i64, ptr }
  %l171 = alloca i64
  %l172 = alloca { i64, ptr }
  %l179 = alloca ptr
  %l182 = alloca i1
  %l186 = alloca i1
  %l188 = alloca i1
  %l191 = alloca i1
  %l193 = alloca i1
  %l197 = alloca i1
  %l200 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l203 = alloca i64
  %l205 = alloca i64
  %l206 = alloca { i64, ptr }
  %l208 = alloca ptr
  %l210 = alloca i64
  %l212 = alloca i64
  %l213 = alloca %"compiler/source:Span"
  %l216 = alloca %"compiler/source:Span"
  %l217 = alloca i64
  %l218 = alloca i64
  %l220 = alloca { i64, ptr }
  %l232 = alloca %"compiler/check:AssertAsk"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t26 = alloca { i64, [5 x i64] }, align 8
  %t49 = alloca { i64, [3 x i64] }, align 8
  %t519 = alloca %"compiler/check:AssertAsk", align 8
  %t533 = alloca %"compiler/check:AssertAsk", align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t6, ptr %l27
  br label %bb1
bb1:
  %t7 = load i64, ptr %l27, !tbaa !24
  store i64 %t7, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t10 = icmp eq i64 %t8, 1
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t12, 0
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v0, ptr %t16, ptr %t17)
  store ptr %t20, ptr %l35
  br label %bb7
bb6:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t21)
  store %"compiler/source:Span" %t23, ptr %l37
  br label %bb8
bb7:
  %t24 = load ptr, ptr %l35, !tbaa !29
  store ptr %t24, ptr %l32, !tbaa !29
  br label %bb9
bb8:
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 0
  store i64 0, ptr %t27
  %t28 = load %"compiler/source:Span", ptr %l37
  %t29 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t28, 0
  %t31 = insertvalue { %"compiler/source:Span", i32, i64 } %t29, i32 %t25, 1
  %t32 = insertvalue { %"compiler/source:Span", i32, i64 } %t31, i64 0, 2
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t32, ptr %t33
  %t34 = load { i64, [5 x i64] }, ptr %t26
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t34, ptr %t36
  store ptr %t36, ptr %l32, !tbaa !29
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l32, !tbaa !29
  store ptr %t38, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v2, ptr %v0, ptr %t39, ptr %t40, i1 false)
  store ptr %t43, ptr %l43
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l43, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  %t47 = load ptr, ptr %l5, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 0
  store i64 10, ptr %t50
  %t52 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t46, 0
  %t54 = insertvalue { %"compiler/source:Span", ptr, ptr } %t52, ptr %t47, 1
  %t56 = insertvalue { %"compiler/source:Span", ptr, ptr } %t54, ptr %t44, 2
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t56, ptr %t57
  %t58 = load { i64, [3 x i64] }, ptr %t49
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t58, ptr %t60
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t45, ptr %t60)
  br label %bb11
bb11:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l50, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l51, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t65)
  store ptr %t67, ptr %l53
  br label %bb12
bb12:
  %t68 = load ptr, ptr %l53, !tbaa !29
  %t70 = getelementptr %"compiler/check:frame", ptr %t68, i32 0, i32 7
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load ptr, ptr %l50, !tbaa !29
  %t73 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %t72, ptr %t73, i1 true, i64 %t71)
  br label %bb13
bb13:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t75)
  store ptr %t77, ptr %l57
  br label %bb14
bb14:
  %t78 = load ptr, ptr %l57, !tbaa !29
  store ptr %t78, ptr %l7, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 2
  %t82 = load i1, ptr %t81, !tbaa !21
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb15, label %bb16
bb15:
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t88 = getelementptr %"compiler/check:frame", ptr %t86, i32 0, i32 12
  %t89 = load i1, ptr %t88, !tbaa !21
  store i1 %t89, ptr %l61, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb17
bb17:
  %t91 = load i1, ptr %l61, !tbaa !21
  br i1 %t91, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb20
bb20:
  store i64 -1, ptr %l8, !tbaa !24
  %t92 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l64
  br label %bb21
bb21:
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l9
  %t94 = load i64, ptr %l4, !tbaa !24
  %t96 = icmp slt i64 %t94, 0
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 122
  store i1 true, ptr %t100, !tbaa !21
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l7, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t102, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t110 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %t101, i64 %t105, ptr %t106)
  store i64 %t110, ptr %l72
  br label %bb24
bb23:
  br label %bb34
bb24:
  %t111 = load i64, ptr %l72, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 122
  store i1 false, ptr %t114, !tbaa !21
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 131
  store ptr %t117, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  %t119 = load i64, ptr %l11, !tbaa !24
  store i64 %t119, ptr %l76, !tbaa !24
  %t120 = load ptr, ptr %l10, !tbaa !29
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t120)
  store i64 %t122, ptr %l78
  br label %bb26
bb26:
  %t123 = load i64, ptr %l76, !tbaa !24
  %t124 = load i64, ptr %l78, !tbaa !24
  %t125 = icmp slt i64 %t123, %t124
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  br label %bb29
bb29:
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t129, i64 %t130)
  store i64 %t133, ptr %l83
  br label %bb30
bb30:
  %t134 = load i64, ptr %l83, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t134)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l11, !tbaa !24
  br label %bb25
bb33:
  br label %bb34
bb34:
  store i64 -1, ptr %l13, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l88, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t142, ptr %l89, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l90, !tbaa !24
  %t145 = load i64, ptr %l90, !tbaa !24
  %t146 = mul i64 %t145, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t146)
  %t148 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  store { i64, ptr } %t149, ptr %l91, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l90, !tbaa !24
  %t155 = mul i64 %t154, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t151, ptr %t153, i64 %t155, i1 false)
  %t156 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t156, ptr %l14, !tbaa !27
  store i1 false, ptr %l15, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l92, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t157, ptr %l93, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  store i64 %t159, ptr %l94, !tbaa !24
  %t160 = load i64, ptr %l94, !tbaa !24
  %t161 = mul i64 %t160, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t161)
  %t163 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  store { i64, ptr } %t164, ptr %l95, !tbaa !27
  %t165 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = load i64, ptr %l94, !tbaa !24
  %t170 = mul i64 %t169, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t166, ptr %t168, i64 %t170, i1 false)
  %t171 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t171, ptr %l16, !tbaa !27
  %t172 = load i64, ptr %l8, !tbaa !24
  %t174 = icmp sge i64 %t172, 0
  br i1 %t174, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb37
bb36:
  %t176 = load i64, ptr %l4, !tbaa !24
  %t178 = icmp eq i64 %t176, 0
  store i1 %t178, ptr %l98, !tbaa !21
  br label %bb37
bb37:
  %t180 = load i1, ptr %l98, !tbaa !21
  br i1 %t180, label %bb38, label %bb39
bb38:
  %t181 = load ptr, ptr %l3, !tbaa !29
  %t183 = icmp eq ptr %t181, null
  %t185 = xor i1 %t183, true
  store i1 %t185, ptr %l101, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb40
bb40:
  %t187 = load i1, ptr %l101, !tbaa !21
  br i1 %t187, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l15, !tbaa !21
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l3, !tbaa !29
  %t192 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflText(ptr %v0, ptr %v2, ptr %s0, ptr %t188, ptr %t189)
  %t193 = extractvalue { i32, { i64, ptr } } %t192, 1
  %t194 = extractvalue { i32, { i64, ptr } } %t192, 0
  store i32 %t194, ptr %l109
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb44, label %ok.196, !prof !99
ok.196:
  store { i64, ptr } %t193, ptr %l108
  br label %bb43
bb42:
  br label %bb70
bb43:
  %t197 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t197, ptr %l105, !tbaa !27
  br label %bb46
bb44:
  %t198 = load i32, ptr %l109, !tbaa !23
  %t199 = ashr i32 %t198, 16
  %t201 = icmp eq i32 %t199, 1
  store i1 %t201, ptr %l111, !tbaa !21
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l15, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l112, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t202, ptr %l105, !tbaa !27
  br label %bb46
bb46:
  %t204 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 0
  %t206 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  store i64 %t207, ptr %l115, !tbaa !24
  %t209 = load i64, ptr %l115, !tbaa !24
  %t210 = icmp eq i64 %t205, %t209
  br i1 %t210, label %bb47, label %bb48
bb47:
  %t212 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = load i64, ptr %l115, !tbaa !24
  %t217 = mul i64 %t216, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t213, ptr %t215, i64 %t217, i1 false)
  br label %bb49
bb48:
  %t218 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  store i64 %t219, ptr %l117, !tbaa !24
  %t220 = load i64, ptr %l117, !tbaa !24
  %t221 = mul i64 %t220, 1
  %t222 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l118, !tbaa !27
  %t225 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l117, !tbaa !24
  %t230 = mul i64 %t229, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t226, ptr %t228, i64 %t230, i1 false)
  %t231 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t231, ptr %l14, !tbaa !27
  br label %bb49
bb49:
  %t232 = load i1, ptr %l15, !tbaa !21
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/check:Checker", ptr %t236, i32 0, i32 122
  store i1 true, ptr %t238, !tbaa !21
  %t239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t239, ptr %l122, !tbaa !29
  %t240 = load ptr, ptr %l7, !tbaa !29
  %t242 = getelementptr %"compiler/check:frame", ptr %t240, i32 0, i32 1
  %t243 = load i64, ptr %t242, !tbaa !24
  store i64 %t243, ptr %l124, !tbaa !24
  %t244 = load ptr, ptr %l3, !tbaa !29
  store ptr %t244, ptr %l125, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = getelementptr %"compiler/generic:Program", ptr %t248, i32 0, i32 2
  store ptr %t250, ptr %l128, !tbaa !29
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t251)
  store i32 %t253, ptr %l130
  br label %bb52
bb51:
  br label %bb69
bb52:
  %t254 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t255 = load ptr, ptr %l128, !tbaa !29
  %t256 = load i32, ptr %l130, !tbaa !23
  %t258 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t255, i32 %t256, i64 %t254)
  store i32 %t258, ptr %l132
  br label %bb53
bb53:
  %t259 = load ptr, ptr %l122, !tbaa !29
  %t260 = load i64, ptr %l124, !tbaa !24
  %t261 = load ptr, ptr %l125, !tbaa !29
  %t262 = load i32, ptr %l132, !tbaa !23
  %t263 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v2, ptr %t259, i64 %t260, ptr %t261, i32 %t262)
  store i64 %t263, ptr %l133
  br label %bb54
bb54:
  %t264 = load i64, ptr %l133, !tbaa !24
  store i64 %t264, ptr %l13, !tbaa !24
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 122
  store i1 false, ptr %t267, !tbaa !21
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 131
  store ptr %t270, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb55
bb55:
  %t272 = load i64, ptr %l18, !tbaa !24
  store i64 %t272, ptr %l137, !tbaa !24
  %t273 = load ptr, ptr %l17, !tbaa !29
  %t275 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t273)
  store i64 %t275, ptr %l139
  br label %bb56
bb56:
  %t276 = load i64, ptr %l137, !tbaa !24
  %t277 = load i64, ptr %l139, !tbaa !24
  %t278 = icmp slt i64 %t276, %t277
  %t280 = xor i1 %t278, true
  br i1 %t280, label %bb57, label %bb58
bb57:
  br label %bb63
bb58:
  br label %bb59
bb59:
  %t282 = load ptr, ptr %l17, !tbaa !29
  %t283 = load i64, ptr %l18, !tbaa !24
  %t286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t282, i64 %t283)
  store i64 %t286, ptr %l144
  br label %bb60
bb60:
  %t287 = load i64, ptr %l144, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t287)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t291 = load i64, ptr %l18, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l18, !tbaa !24
  br label %bb55
bb63:
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l149, !tbaa !29
  %t296 = load ptr, ptr %l3, !tbaa !29
  %t298 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t296)
  store %"compiler/source:Span" %t298, ptr %l151
  br label %bb64
bb64:
  %t299 = load ptr, ptr %l149, !tbaa !29
  %t300 = load %"compiler/source:Span", ptr %l151
  %t301 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s9, ptr %t299, %"compiler/source:Span" %t300)
  store { i64, ptr } %t301, ptr %l152
  br label %bb65
bb65:
  %t302 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t302, ptr %l153, !tbaa !27
  %t303 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  %t305 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t305, 0
  store i64 %t306, ptr %l155, !tbaa !24
  %t308 = load i64, ptr %l155, !tbaa !24
  %t309 = icmp eq i64 %t304, %t308
  br i1 %t309, label %bb66, label %bb67
bb66:
  %t311 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = load i64, ptr %l155, !tbaa !24
  %t316 = mul i64 %t315, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t312, ptr %t314, i64 %t316, i1 false)
  br label %bb68
bb67:
  %t317 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 0
  store i64 %t318, ptr %l157, !tbaa !24
  %t319 = load i64, ptr %l157, !tbaa !24
  %t320 = mul i64 %t319, 1
  %t321 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t320)
  %t322 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  store { i64, ptr } %t323, ptr %l158, !tbaa !27
  %t324 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !27
  %t328 = load i64, ptr %l157, !tbaa !24
  %t329 = mul i64 %t328, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t325, ptr %t327, i64 %t329, i1 false)
  %t330 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t330, ptr %l16, !tbaa !27
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s9)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t331 = load i64, ptr %l8, !tbaa !24
  %t333 = icmp slt i64 %t331, 0
  br i1 %t333, label %bb71, label %bb72
bb71:
  %t335 = load i64, ptr %l4, !tbaa !24
  %t337 = icmp ne i64 %t335, 0
  store i1 %t337, ptr %l161, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb73
bb73:
  %t339 = load i1, ptr %l161, !tbaa !21
  br i1 %t339, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb75:
  br label %bb76
bb76:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/check:Checker", ptr %t340, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t345 = getelementptr %"compiler/generic:Program", ptr %t343, i32 0, i32 0
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t348 = getelementptr %"compiler/load:Loader", ptr %t346, i32 0, i32 4
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t351 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %s0, ptr %t349)
  store { { i64, [3 x i64] }, { i64, ptr } } %t351, ptr %l168
  br label %bb77
bb77:
  %t352 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l168
  store { { i64, [3 x i64] }, { i64, ptr } } %t352, ptr %l20
  %t353 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l20, i32 0, i32 0
  %t354 = load { i64, [3 x i64] }, ptr %t353
  store { i64, [3 x i64] } %t354, ptr %l21
  %t356 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l20, i32 0, i32 1
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  store { i64, ptr } %t357, ptr %l170, !tbaa !27
  %t358 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  store i64 %t359, ptr %l171, !tbaa !24
  %t360 = load i64, ptr %l171, !tbaa !24
  %t361 = mul i64 %t360, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t361)
  %t363 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  store { i64, ptr } %t364, ptr %l172, !tbaa !27
  %t365 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = load i64, ptr %l171, !tbaa !24
  %t370 = mul i64 %t369, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t366, ptr %t368, i64 %t370, i1 false)
  %t371 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t371, ptr %l22, !tbaa !27
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t377 = getelementptr %"compiler/generic:Program", ptr %t375, i32 0, i32 0
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t380 = getelementptr %"compiler/load:Loader", ptr %t378, i32 0, i32 10
  %t381 = load ptr, ptr %l7, !tbaa !29
  %t383 = getelementptr %"compiler/check:frame", ptr %t381, i32 0, i32 1
  %t384 = load i64, ptr %t383, !tbaa !24
  %t387 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t380, i64 %t384)
  store ptr %t387, ptr %l179
  br label %bb78
bb78:
  %t388 = load ptr, ptr %l179, !tbaa !29
  %t390 = getelementptr %"compiler/load:Module", ptr %t388, i32 0, i32 2
  %t391 = load { i64, ptr }, ptr %t390, !tbaa !27
  %t393 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t391, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t393, ptr %l182
  br label %bb79
bb79:
  %t394 = load i1, ptr %l182, !tbaa !21
  store i1 %t394, ptr %l23, !tbaa !21
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l2, !tbaa !29
  %t400 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t395, ptr %t396)
  store i1 %t400, ptr %l186
  br label %bb80
bb80:
  %t401 = load i1, ptr %l186, !tbaa !21
  %t402 = xor i1 %t401, true
  br i1 %t402, label %bb81, label %bb82
bb81:
  %t404 = load i64, ptr %l4, !tbaa !24
  %t406 = icmp slt i64 %t404, 0
  store i1 %t406, ptr %l188, !tbaa !21
  br label %bb83
bb82:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb83
bb83:
  %t408 = load i1, ptr %l188, !tbaa !21
  br i1 %t408, label %bb84, label %bb85
bb84:
  %t409 = load i1, ptr %l15, !tbaa !21
  br i1 %t409, label %bb86, label %bb87
bb85:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb89
bb86:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/check:Checker", ptr %t411, i32 0, i32 137
  %t414 = load i1, ptr %t413, !tbaa !21
  store i1 %t414, ptr %l193, !tbaa !21
  br label %bb88
bb87:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb88
bb88:
  %t416 = load i1, ptr %l193, !tbaa !21
  %t417 = xor i1 %t416, true
  store i1 %t417, ptr %l191, !tbaa !21
  br label %bb89
bb89:
  %t419 = load i1, ptr %l191, !tbaa !21
  br i1 %t419, label %bb90, label %bb91
bb90:
  %t420 = load i1, ptr %l23, !tbaa !21
  %t422 = xor i1 %t420, true
  store i1 %t422, ptr %l197, !tbaa !21
  br label %bb92
bb91:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb92
bb92:
  %t424 = load i1, ptr %l197, !tbaa !21
  br i1 %t424, label %bb93, label %bb94
bb93:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l200, !tbaa !27
  %t425 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t425, ptr %l201, !tbaa !27
  %t426 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t426, 0
  %t428 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t429 = extractvalue { i64, ptr } %t428, 0
  store i64 %t429, ptr %l203, !tbaa !24
  %t431 = load i64, ptr %l203, !tbaa !24
  %t432 = icmp eq i64 %t427, %t431
  br i1 %t432, label %bb95, label %bb96
bb94:
  br label %bb98
bb95:
  %t434 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !27
  %t436 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = load i64, ptr %l203, !tbaa !24
  %t439 = mul i64 %t438, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t435, ptr %t437, i64 %t439, i1 false)
  br label %bb97
bb96:
  %t440 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t440, 0
  store i64 %t441, ptr %l205, !tbaa !24
  %t442 = load i64, ptr %l205, !tbaa !24
  %t443 = mul i64 %t442, 1
  %t444 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t443)
  %t445 = insertvalue { i64, ptr } undef, i64 %t442, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr %t444, 1
  store { i64, ptr } %t446, ptr %l206, !tbaa !27
  %t447 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !27
  %t451 = load i64, ptr %l205, !tbaa !24
  %t452 = mul i64 %t451, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t448, ptr %t450, i64 %t452, i1 false)
  %t453 = load { i64, ptr }, ptr %l206, !tbaa !27
  store { i64, ptr } %t453, ptr %l22, !tbaa !27
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/check:Checker", ptr %t454, i32 0, i32 98
  store ptr %t456, ptr %l208, !tbaa !29
  %t457 = load ptr, ptr %l7, !tbaa !29
  %t459 = getelementptr %"compiler/check:frame", ptr %t457, i32 0, i32 0
  %t460 = load i64, ptr %t459, !tbaa !24
  store i64 %t460, ptr %l210, !tbaa !24
  %t461 = load ptr, ptr %l7, !tbaa !29
  %t463 = getelementptr %"compiler/check:frame", ptr %t461, i32 0, i32 2
  %t464 = load i64, ptr %t463, !tbaa !24
  store i64 %t464, ptr %l212, !tbaa !24
  %t465 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t465, ptr %l213
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load ptr, ptr %l2, !tbaa !29
  %t470 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %t466, ptr %t467)
  store %"compiler/source:Span" %t470, ptr %l216
  br label %bb99
bb99:
  %t471 = load i64, ptr %l8, !tbaa !24
  store i64 %t471, ptr %l217, !tbaa !24
  %t472 = load i64, ptr %l13, !tbaa !24
  store i64 %t472, ptr %l218, !tbaa !24
  %t474 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %v0, ptr %l9)
  store { i64, ptr } %t474, ptr %l220
  br label %bb100
bb100:
  %t475 = load { i64, [3 x i64] }, ptr %l21
  %t476 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t476, 1
  %t479 = extractvalue { i64, ptr } %t476, 0
  %t480 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t479)
  call void @olang_textcopy(ptr %t480, ptr %t478, i64 %t479)
  %t481 = insertvalue { i64, ptr } undef, i64 %t479, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t480, 1
  %t484 = extractvalue { i64, ptr } %t482, 0
  %t485 = extractvalue { i64, ptr } %t482, 1
  %t486 = mul i64 %t484, 1
  %t487 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t486)
  call void @llvm.memcpy.p0.p0.i64(ptr %t487, ptr %t485, i64 %t486, i1 false)
  %t488 = insertvalue { i64, ptr } undef, i64 %t484, 0
  %t489 = insertvalue { i64, ptr } %t488, ptr %t487, 1
  %t490 = load i1, ptr %l15, !tbaa !21
  %t491 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 1
  %t494 = extractvalue { i64, ptr } %t491, 0
  %t495 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t494)
  call void @olang_textcopy(ptr %t495, ptr %t493, i64 %t494)
  %t496 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t495, 1
  %t499 = extractvalue { i64, ptr } %t497, 0
  %t500 = extractvalue { i64, ptr } %t497, 1
  %t501 = mul i64 %t499, 1
  %t502 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t501)
  call void @llvm.memcpy.p0.p0.i64(ptr %t502, ptr %t500, i64 %t501, i1 false)
  %t503 = insertvalue { i64, ptr } undef, i64 %t499, 0
  %t504 = insertvalue { i64, ptr } %t503, ptr %t502, 1
  %t505 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t507 = extractvalue { i64, ptr } %t505, 1
  %t508 = extractvalue { i64, ptr } %t505, 0
  %t509 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t508)
  call void @olang_textcopy(ptr %t509, ptr %t507, i64 %t508)
  %t510 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t509, 1
  %t513 = extractvalue { i64, ptr } %t511, 0
  %t514 = extractvalue { i64, ptr } %t511, 1
  %t515 = mul i64 %t513, 1
  %t516 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t515)
  call void @llvm.memcpy.p0.p0.i64(ptr %t516, ptr %t514, i64 %t515, i1 false)
  %t517 = insertvalue { i64, ptr } undef, i64 %t513, 0
  %t518 = insertvalue { i64, ptr } %t517, ptr %t516, 1
  %t520 = load i64, ptr %l210, !tbaa !24
  %t521 = load i64, ptr %l212, !tbaa !24
  %t522 = load %"compiler/source:Span", ptr %l213
  %t523 = load %"compiler/source:Span", ptr %l216
  %t524 = load i64, ptr %l217, !tbaa !24
  %t525 = load i64, ptr %l218, !tbaa !24
  %t526 = load { i64, ptr }, ptr %l220, !tbaa !27
  call void @compiler_2fcheck_3aAssertAsk_2ector(ptr %t519, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t520, i64 %t521, %"compiler/source:Span" %t522, %"compiler/source:Span" %t523, i64 %t524, i64 %t525, { i64, ptr } %t526, { i64, [3 x i64] } %t475, { i64, ptr } %t489, i1 %t490, { i64, ptr } %t504, { i64, ptr } %t518)
  call void @llvm.memmove.p0.p0.i64(ptr %l232, ptr %t519, i64 152, i1 false)
  br label %bb101
bb101:
  %t532 = load ptr, ptr %l208, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t533, ptr %l232, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2ePush_Hbdaad063a73077b3b5842d615b8c1d82(ptr %v0, ptr %v0, ptr %t532, ptr %t533)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatColls(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i32
  %l25 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallArgs(ptr %v0, ptr %v1, ptr %v1, ptr %t5, ptr %a1)
  store { i64, ptr } %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %lp2
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %lp2
  store ptr %t21, ptr %l17, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l19, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 0
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t30 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t27)
  store i32 %t30, ptr %l22
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load i32, ptr %l22, !tbaa !23
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t33, ptr %l23
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = load i32, ptr %l23, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t34, i32 %t35)
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l25, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 0
  %t41 = load ptr, ptr %t40, !tbaa !39
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatValue(ptr %v0, ptr %v1, ptr %v1, ptr %t36, ptr %t41)
  store ptr %t44, ptr %l27
  br label %bb9
bb9:
  %t45 = load ptr, ptr %l27, !tbaa !29
  store ptr %t45, ptr %l4, !tbaa !29
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t56 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatColls(ptr %v0, ptr %v1, ptr %s3, ptr %t52, ptr %t53)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l33
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t58 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %t58
  store ptr %t58, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %l35, !tbaa !24
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s3, ptr %t61)
  store i64 %t63, ptr %l37
  br label %bb14
bb14:
  %t64 = load i64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l37, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  br label %bb21
bb16:
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s3, ptr %t70, i64 %t71)
  store i32 %t74, ptr %l42
  br label %bb18
bb18:
  %t75 = load i32, ptr %l42, !tbaa !23
  %t76 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t76, i32 %t75)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb13
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t84 = load ptr, ptr %lp2
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatIndices(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t26 = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t2)
  store { i64, ptr } %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t10, i64 1)
  store i64 %t12, ptr %l16
  br label %bb2
bb2:
  %t13 = load i64, ptr %l16, !tbaa !24
  %t14 = sub i64 %t13, 1
  store i64 %t14, ptr %l17, !tbaa !24
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l18, !tbaa !29
  %t16 = load i64, ptr %l17, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = icmp sle i64 %t19, 1152921504606846975
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_3bfc508877dabbdc_ae4b6eee9a4b2328)
  unreachable
bb5:
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = mul i64 %t22, 8
  %t24 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t23)
  %t25 = load ptr, ptr %l18, !tbaa !29
  store i64 0, ptr %t26
  br label %fill.27
fill.27:
  %t30 = load i64, ptr %t26
  %t31 = icmp slt i64 %t30, %t22
  br i1 %t31, label %fillb.28, label %filld.29
fillb.28:
  %t32 = getelementptr ptr, ptr %t24, i64 %t30
  store ptr %t25, ptr %t32
  %t33 = add i64 %t30, 1
  store i64 %t33, ptr %t26
  br label %fill.27
filld.29:
  %t34 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t24, 1
  store { i64, ptr } %t35, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3bfc508877dabbdc_ae4b6eee9a4b2328)
  unreachable
bb7:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb12
bb9:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l30, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l30, !tbaa !24
  store i64 %t67, ptr %l27, !tbaa !24
  br label %bb12
bb12:
  %t68 = load i64, ptr %l27, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t77 = load i64, ptr %l4, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l9, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t87, ptr %l48, !tbaa !27
  %t88 = load i64, ptr %l9, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t89, ptr %l50, !tbaa !27
  %t90 = load i64, ptr %l9, !tbaa !24
  %t92 = add i64 %t90, 1
  %t94 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 %t92
  %t97 = load ptr, ptr %t96, !tbaa !39
  %t100 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr ptr, ptr %t101, i64 %t88
  store ptr %t97, ptr %t102, !tbaa !39
  br label %bb17
bb17:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l8, !tbaa !24
  br label %bb13
bb18:
  %t107 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t107, ptr %l57, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l58, !tbaa !24
  %t111 = load i64, ptr %l58, !tbaa !24
  %t112 = mul i64 %t111, 8
  %t113 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l59, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = load i64, ptr %l58, !tbaa !24
  %t121 = mul i64 %t120, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t117, ptr %t119, i64 %t121, i1 false)
  %t122 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t122, ptr %l57, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t123, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l63 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l12, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l15
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l4, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_37018c2ebf0da22a_371c8892c4c63a5e)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t47 = icmp slt i64 %t40, %t44
  br i1 %t47, label %bb7, label %bb8
bb7:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t55 = icmp slt i64 %t49, %t52
  store i1 %t55, ptr %l29, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t58 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t58, ptr %l35, !tbaa !27
  %t59 = load i64, ptr %l6, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 32
  br i1 %t66, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb21
bb12:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb14
bb13:
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t68, ptr %l40, !tbaa !27
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i8, ptr %t72, i64 %t69
  %t74 = load i8, ptr %t73, !tbaa !32
  %t76 = icmp eq i8 %t74, 10
  store i1 %t76, ptr %l39, !tbaa !21
  br label %bb14
bb14:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb17
bb16:
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t79, ptr %l45, !tbaa !27
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = icmp eq i8 %t85, 9
  store i1 %t87, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t89 = load i1, ptr %l44, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb20
bb19:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t90, ptr %l50, !tbaa !27
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i8, ptr %t94, i64 %t91
  %t96 = load i8, ptr %t95, !tbaa !32
  %t98 = icmp eq i8 %t96, 41
  store i1 %t98, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t100 = load i1, ptr %l49, !tbaa !21
  store i1 %t100, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t101 = load i1, ptr %l34, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l6, !tbaa !24
  br label %bb25
bb25:
  br label %bb6
bb26:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = trunc i64 %t108 to i32
  %t111 = load i64, ptr %l6, !tbaa !24
  %t115 = add i64 %t111, %a3
  %t117 = trunc i64 %t115 to i32
  %t120 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t110, i32 %t117)
  store %"compiler/source:Span" %t120, ptr %l63
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t121 = load %"compiler/source:Span", ptr %l63
  store %"compiler/source:Span" %t121, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildDefaulted(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l10, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 3
  %t18 = load i1, ptr %t17, !tbaa !21
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 2
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t25, ptr %l16
  br label %bb4
bb4:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb7:
  %t30 = getelementptr %"compiler/ast:VarDecl", ptr %a3, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = call i1 @compiler_2fgeneric_2eWrittenMut(ptr %v1, ptr %t31)
  store i1 %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load i1, ptr %l20, !tbaa !21
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l17, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/load:Loader", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t47, i32 %a2)
  store { i64, ptr } %t51, ptr %l28
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t54 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v0, ptr %t52, { i64, ptr } %t53)
  store i1 %t54, ptr %l29
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t55 = load i1, ptr %l29, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderRequired(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l20 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l48 = alloca { i64, ptr }
  %l52 = alloca i1
  %l64 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l72 = alloca %"compiler/generic:Context"
  %l76 = alloca i32
  %l81 = alloca i32
  %l85 = alloca ptr
  %l90 = alloca i32
  %l93 = alloca i32
  %s8 = alloca %olang.scope
  %rv = alloca i32
  %t120 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t4, i32 %t5)
  store ptr %t8, ptr %l20
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l20, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t10, 16
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb4
bb3:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  store i1 %t16, ptr %l23, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l23, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb7
bb6:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/ast:TypeDecl", ptr %t19, i32 0, i32 3
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  store i1 %t24, ptr %l26, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l26, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i32 0, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TypeDecl", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l4, !tbaa !29
  %t33 = load ptr, ptr %l4, !tbaa !29
  store ptr %t33, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t34 = load ptr, ptr %l33, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l33, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 5}
  %t40 = icmp eq i64 %t38, 2
  store i1 %t40, ptr %l34, !tbaa !21
  br label %bb12
bb12:
  %t41 = load i1, ptr %l34, !tbaa !21
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr { i64, [6 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l5, !tbaa !27
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr { i64, [6 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t50, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51
  store { i64, ptr } %t52, ptr %l6, !tbaa !27
  br label %bb15
bb14:
  br label %bb43
bb15:
  %t54 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t54, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t68 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t68, ptr %l48, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  store ptr %t74, ptr %l10, !tbaa !29
  %t76 = load ptr, ptr %l10, !tbaa !29
  %t78 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t76)
  store i1 %t78, ptr %l52
  br label %bb20
bb20:
  %t79 = load i1, ptr %l52, !tbaa !21
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t80 = load ptr, ptr %l10, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 10
  %t83 = load i32, ptr %t82, !tbaa !23
  store i32 %t83, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t85 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l8, !tbaa !24
  br label %bb16
bb25:
  %t89 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t89, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  store i64 %t93, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t95 = load i64, ptr %l12, !tbaa !24
  %t96 = load i64, ptr %l13, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s8)
  br label %bb42
bb28:
  br label %bb29
bb29:
  %t103 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t103, ptr %l64, !tbaa !27
  %t104 = load i64, ptr %l12, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr ptr, ptr %t107, i64 %t104
  %t109 = load ptr, ptr %t108, !tbaa !39
  store ptr %t109, ptr %l14, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  store ptr %t114, ptr %l68, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %t120, ptr %v0, ptr %s8, ptr %t118, i32 %t119)
  call void @llvm.memmove.p0.p0.i64(ptr %l72, ptr %t120, i64 160, i1 false)
  br label %bb30
bb30:
  %t123 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t123, ptr %l72, i64 160, i1 false)
  %t124 = load ptr, ptr %l14, !tbaa !29
  %t126 = load ptr, ptr %l68, !tbaa !29
  %t129 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %s8, ptr %v0, ptr %t126, ptr %t123, ptr %t124)
  store i32 %t129, ptr %l76
  br label %bb31
bb31:
  %t130 = load i32, ptr %l76, !tbaa !23
  store i32 %t130, ptr %l15, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l15, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t136, i32 %t137)
  store i32 %t140, ptr %l81
  br label %bb32
bb32:
  %t141 = load i32, ptr %l81, !range !{i32 0, i32 33}
  %t143 = trunc i64 18 to i32
  %t144 = icmp eq i32 %t141, %t143
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb34:
  br label %bb35
bb35:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l85, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i32, ptr %l15, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l90
  br label %bb36
bb36:
  %t159 = load i64, ptr %l2, !tbaa !24
  %t161 = add i64 %t159, 1
  %t162 = load ptr, ptr %l85, !tbaa !29
  %t163 = load i32, ptr %l90, !tbaa !23
  %t165 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderRequired(ptr %v0, ptr %t162, i32 %t163, i64 %t161)
  store i32 %t165, ptr %l93
  br label %bb37
bb37:
  %t166 = load i32, ptr %l93, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  %t167 = load i32, ptr %l16, !tbaa !23
  %t169 = icmp ne i32 %t167, 0
  br i1 %t169, label %bb38, label %bb39
bb38:
  %t171 = load i32, ptr %l16, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  store i32 %t171, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb41:
  %t173 = load i64, ptr %l12, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l12, !tbaa !24
  br label %bb26
bb42:
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_4153f13b2b5ba70f_539dcb5badf9f963)
  unreachable
bb48:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"compiler/check:ownerAt"
  %l6 = alloca i64
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca %"compiler/check:ownerAt"
  %l22 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l34 = alloca i64
  %l43 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i32
  %l77 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l89 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l94 = alloca %"compiler/diagmsg:Msg"
  %l95 = alloca i64
  %l98 = alloca ptr
  %l106 = alloca ptr
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t123 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %t1, ptr %a3)
  store %"compiler/check:ownerAt" %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load %"compiler/check:ownerAt", ptr %l15
  store %"compiler/check:ownerAt" %t6, ptr %l5
  %t7 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t12 = icmp eq i32 %t8, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t15, i32 %t17)
  store i1 %t20, ptr %l22
  br label %bb5
bb5:
  %t21 = load i1, ptr %l22, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t24 = load i32, ptr %t23, !tbaa !23
  %t25 = load i32, ptr %l4, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t22, i32 %t24, i32 %t25)
  store i1 %t29, ptr %l27
  br label %bb8
bb7:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb9
bb8:
  %t30 = load i1, ptr %l27, !tbaa !21
  store i1 %t30, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l23, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  store ptr null, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  %t39 = load i32, ptr %l4, !tbaa !23
  %t40 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 1
  %t41 = load i1, ptr %t40, !tbaa !21
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %t36, i32 %t38, i32 %t39, i1 %t41)
  store i64 %t46, ptr %l34
  br label %bb13
bb13:
  %t47 = load i64, ptr %l34, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t50 = icmp slt i64 %t48, 0
  br i1 %t50, label %bb14, label %bb15
bb14:
  store ptr null, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load %"compiler/source:Span", ptr %l2
  %t56 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t57 = load i32, ptr %t56, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderVisible(ptr %v0, ptr %t53, i64 %t54, %"compiler/source:Span" %t55, i32 %t57)
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l43, !tbaa !29
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t66)
  store i64 %t68, ptr %l45
  br label %bb18
bb18:
  %t69 = load ptr, ptr %l43, !tbaa !29
  %t70 = load i64, ptr %l45, !tbaa !24
  %t71 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t69, i64 %t70)
  store i64 %t71, ptr %l46
  br label %bb19
bb19:
  %t72 = load i64, ptr %l46, !tbaa !24
  store i64 %t72, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = icmp eq i64 %t73, 0
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l49, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t78, ptr %l50
  %t79 = load i64, ptr %l6, !tbaa !24
  store i64 %t79, ptr %l51, !tbaa !24
  %t80 = icmp sge i64 0, 0
  br i1 %t80, label %bb22, label %bb23
bb21:
  br label %bb27
bb22:
  %t82 = icmp sle i64 0, 2305843009213693951
  br i1 %t82, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_82b0d2a61edf3c68_78216e4ccea776dc)
  unreachable
bb24:
  %t84 = mul i64 0, 4
  %t85 = insertvalue { i64, ptr } undef, i64 0, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l50
  %t89 = load i64, ptr %l51, !tbaa !24
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v2, ptr %v2, ptr %t87, %"compiler/source:Span" %t88, i64 %t89, { i64, ptr } %t86)
  store ptr %t91, ptr %l55
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_82b0d2a61edf3c68_78216e4ccea776dc)
  unreachable
bb26:
  %t92 = load ptr, ptr %l55, !tbaa !29
  store ptr %t92, ptr %rv
  br label %ret
bb27:
  %t94 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 1
  %t95 = load i1, ptr %t94, !tbaa !21
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb28, label %bb29
bb28:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr %"compiler/check:ownerAt", ptr %l5, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerBinding(ptr %v0, ptr %v2, ptr %t102, i64 %t103, i32 %t105)
  store { i64, ptr } %t109, ptr %l64
  br label %bb30
bb29:
  %t110 = load i64, ptr %l7, !tbaa !24
  store i64 %t110, ptr %l65, !tbaa !24
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t111, ptr %l66, !tbaa !23
  %t112 = load i64, ptr %l65, !tbaa !24
  %t113 = icmp sge i64 %t112, 0
  br i1 %t113, label %bb31, label %bb32
bb30:
  %t115 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t115, ptr %l59, !tbaa !27
  br label %bb35
bb31:
  %t116 = load i64, ptr %l65, !tbaa !24
  %t117 = icmp sle i64 %t116, 2305843009213693951
  br i1 %t117, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e54de2b85f89ec55_546f3093ddc3c1a9)
  unreachable
bb33:
  %t119 = load i64, ptr %l65, !tbaa !24
  %t120 = mul i64 %t119, 4
  %t121 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t120)
  %t122 = load i32, ptr %l66, !tbaa !23
  store i64 0, ptr %t123
  br label %fill.124
fill.124:
  %t127 = load i64, ptr %t123
  %t128 = icmp slt i64 %t127, %t119
  br i1 %t128, label %fillb.125, label %filld.126
fillb.125:
  %t129 = getelementptr i32, ptr %t121, i64 %t127
  store i32 %t122, ptr %t129
  %t130 = add i64 %t127, 1
  store i64 %t130, ptr %t123
  br label %fill.124
filld.126:
  %t131 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t121, 1
  store { i64, ptr } %t132, ptr %l59, !tbaa !27
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e54de2b85f89ec55_546f3093ddc3c1a9)
  unreachable
bb35:
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t134, ptr %lp8
  %t135 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t136 = load ptr, ptr %lp8
  store { i64, ptr } %t135, ptr %t136, !tbaa !27
  %t137 = load ptr, ptr %lp8
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l11, !tbaa !24
  br label %bb36
bb36:
  %t144 = load i64, ptr %l10, !tbaa !24
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb37, label %bb38
bb37:
  br label %bb49
bb38:
  br label %bb39
bb39:
  %t152 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t152, ptr %l77, !tbaa !27
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i32, ptr %t156, i64 %t153
  %t158 = load i32, ptr %t157, !tbaa !33
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t164 = icmp eq i32 %t158, %t161
  br i1 %t164, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l83, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t167, ptr %l84
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l85, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load i64, ptr %l6, !tbaa !24
  %t176 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s7, ptr %t172, i64 %t173)
  store ptr %t176, ptr %l89
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t177 = load ptr, ptr %l89, !tbaa !29
  %t179 = getelementptr %"compiler/ast:Func", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %t179, !tbaa !23
  %t181 = load ptr, ptr %l85, !tbaa !29
  %t183 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t181, i32 %t180)
  store { i64, ptr } %t183, ptr %l92
  br label %bb43
bb43:
  %t184 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  %t186 = extractvalue { i64, ptr } %t184, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t192 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderNotValue(ptr %s7, ptr %s7, { i64, ptr } %t190)
  store %"compiler/diagmsg:Msg" %t192, ptr %l94
  br label %bb44
bb44:
  %t193 = load ptr, ptr %l83, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l84
  %t195 = load %"compiler/diagmsg:Msg", ptr %l94
  %t196 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t193, %"compiler/source:Span" %t194, %"compiler/diagmsg:Msg" %t195)
  store i64 %t196, ptr %l95
  br label %bb45
bb45:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t201 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t197, %"compiler/source:Span" %a1)
  store ptr %t201, ptr %l98
  br label %bb46
bb46:
  %t202 = load ptr, ptr %l98, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  store ptr %t202, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t204 = load i64, ptr %l10, !tbaa !24
  %t206 = add i64 %t204, 1
  store i64 %t206, ptr %l10, !tbaa !24
  br label %bb36
bb49:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l2
  %t210 = load i64, ptr %l6, !tbaa !24
  %t211 = load ptr, ptr %lp8
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  %t217 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v2, ptr %v2, ptr %t208, %"compiler/source:Span" %t209, i64 %t210, { i64, ptr } %t212)
  store ptr %t217, ptr %l106
  br label %bb50
bb50:
  %t218 = load ptr, ptr %l106, !tbaa !29
  store ptr %t218, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecCallback(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb12
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l14
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb11
bb8:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Func", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %t25, !tbaa !23
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t27, i32 %t26)
  store { i64, ptr } %t29, ptr %l17
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s1, { i64, ptr } %t30, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t31, ptr %l18
  br label %bb10
bb10:
  %t32 = load i1, ptr %l18, !tbaa !21
  %t33 = xor i1 %t32, true
  store i1 %t33, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  %t35 = load i1, ptr %l9, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @olang_loc_687718fa9f832d83_eed198ed3faef857)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/generic:Context"
  %l5 = alloca i32
  %l6 = alloca { i64, i32 }
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca %"compiler/generic:Context"
  %l20 = alloca %"compiler/generic:Context"
  %l25 = alloca i32
  %l33 = alloca ptr
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca { i64, i32 }
  %l46 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i64
  %l55 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  %t21 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t7 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %a1)
  store ptr %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l11, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t14 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t14, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t15)
  store ptr %t17, ptr %l16
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l16, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t18, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t20, i64 160, i1 false)
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %t21, ptr %s0, ptr %l18)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t21, i64 160, i1 false)
  br label %bb7
bb7:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l20, i64 160, i1 false)
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t31 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %s0, ptr %s0, ptr %t26, ptr %l4, ptr %t27)
  store i32 %t31, ptr %l25
  br label %bb8
bb8:
  %t32 = load i32, ptr %l25, !tbaa !23
  store i32 %t32, ptr %l5, !tbaa !23
  %t33 = load i32, ptr %l5, !tbaa !23
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t37 = icmp ne i32 %t33, %t34
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i32, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %lp2
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v2, ptr %t42, i32 %t43, ptr %t44)
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l33, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %lp2
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v2, ptr %v2, ptr %t49, ptr %t50)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l36
  br label %bb12
bb12:
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %t55
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t58 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v2, ptr %v2, ptr %t56, ptr %t55)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l38
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  %t60 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t60, ptr %rv
  br label %ret
bb14:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t65 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %s0, ptr %t61, ptr %t62)
  store { i64, i32 } %t65, ptr %l41
  br label %bb15
bb15:
  %t66 = load { i64, i32 }, ptr %l41
  store { i64, i32 } %t66, ptr %l6
  %t67 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  %t70 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  store i32 %t71, ptr %l8, !tbaa !23
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  br i1 %t75, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb18
bb17:
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = icmp sge i64 %t77, 64
  store i1 %t79, ptr %l46, !tbaa !21
  br label %bb18
bb18:
  %t81 = load i1, ptr %l46, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t83 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t83, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t84 = load ptr, ptr %lp2
  store ptr %t84, ptr %l50, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load i64, ptr %l7, !tbaa !24
  store i64 %t87, ptr %l53, !tbaa !24
  %t88 = load i64, ptr %l53, !tbaa !24
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = shl i64 1, %t89
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t85, i32 %t86, i64 %t90)
  store i32 %t94, ptr %l55
  br label %bb22
bb22:
  %t95 = load ptr, ptr %l50, !tbaa !29
  %t96 = load i32, ptr %l55, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t95, i32 %t96)
  br label %bb23
bb23:
  %t97 = load ptr, ptr %lp2
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t97
  call void @__olang_scope_close(ptr %s0)
  %t100 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatchValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l18 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i32
  %l38 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca i64
  %l57 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l65 = alloca %"compiler/source:Span"
  %l66 = alloca %"compiler/diagmsg:Msg"
  %l67 = alloca i64
  %l73 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l89 = alloca ptr
  %l104 = alloca ptr
  %l109 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l117 = alloca i32
  %l120 = alloca ptr
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  %t167 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l14, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 60
  %t7 = load %"compiler/source:Span", ptr %t6
  store %"compiler/source:Span" %t7, ptr %l4
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l18
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l18, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 61
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 37
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l23
  br label %bb3
bb3:
  %t22 = load i64, ptr %l23, !tbaa !24
  store i64 %t22, ptr %l6, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrPinned(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i1 %t27, ptr %l26
  br label %bb4
bb4:
  %t28 = load i1, ptr %l26, !tbaa !21
  %t29 = xor i1 %t28, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t31, %"compiler/source:Span" %t32)
  store ptr %t35, ptr %l30
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t36 = load ptr, ptr %l30, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t43 = call { i32, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %t37, %"compiler/source:Span" %t38, ptr %t39)
  %t44 = extractvalue { i32, i1 } %t43, 1
  %t45 = extractvalue { i32, i1 } %t43, 0
  store i32 %t45, ptr %l36
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb10, label %ok.47, !prof !99
ok.47:
  store i1 %t44, ptr %l35
  br label %bb9
bb9:
  %t48 = load i1, ptr %l35, !tbaa !21
  store i1 %t48, ptr %l31, !tbaa !21
  br label %bb14
bb10:
  %t49 = load i32, ptr %l36, !tbaa !23
  %t50 = ashr i32 %t49, 16
  %t52 = icmp eq i32 %t50, 1
  store i1 %t52, ptr %l38, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l4
  %t55 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunpin(ptr %v0, ptr %t53, %"compiler/source:Span" %t54, i64 %t55)
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t59, %"compiler/source:Span" %t60)
  store ptr %t63, ptr %l44
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l44, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
bb14:
  %t65 = load i1, ptr %l31, !tbaa !21
  store ptr null, ptr %l8, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtLast(ptr %v0, ptr %v1, ptr %t66, ptr %t67, i1 %t65)
  store i64 %t72, ptr %l48
  br label %bb15
bb15:
  %t73 = load i64, ptr %l48, !tbaa !24
  store i64 %t73, ptr %l9, !tbaa !24
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Match", ptr %t74, i32 0, i32 3
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t81 = sub i64 %t79, 1
  store i64 %t81, ptr %l10, !tbaa !24
  br label %bb16
bb16:
  %t83 = load i64, ptr %l10, !tbaa !24
  %t85 = icmp sge i64 %t83, 0
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb17, label %bb18
bb17:
  br label %bb38
bb18:
  br label %bb19
bb19:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Match", ptr %t89, i32 0, i32 3
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %l57, !tbaa !27
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr ptr, ptr %t96, i64 %t93
  %t98 = load ptr, ptr %t97, !tbaa !39
  store ptr %t98, ptr %l11, !tbaa !29
  %t100 = load ptr, ptr %l11, !tbaa !29
  %t102 = getelementptr %"compiler/ast:Case", ptr %t100, i32 0, i32 5
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = icmp eq ptr %t103, null
  br i1 %t105, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l63, !tbaa !29
  %t108 = load ptr, ptr %l11, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Case", ptr %t108, i32 0, i32 0
  %t111 = load %"compiler/source:Span", ptr %t110
  store %"compiler/source:Span" %t111, ptr %l65
  %t112 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtMatchBlock(ptr %s5)
  store %"compiler/diagmsg:Msg" %t112, ptr %l66
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t113 = load ptr, ptr %l63, !tbaa !29
  %t114 = load %"compiler/source:Span", ptr %l65
  %t115 = load %"compiler/diagmsg:Msg", ptr %l66
  %t116 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t113, %"compiler/source:Span" %t114, %"compiler/diagmsg:Msg" %t115)
  store i64 %t116, ptr %l67
  br label %bb23
bb23:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l4
  %t119 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunpin(ptr %v0, ptr %t117, %"compiler/source:Span" %t118, i64 %t119)
  br label %bb24
bb24:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t123, %"compiler/source:Span" %t124)
  store ptr %t127, ptr %l73
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  %t128 = load ptr, ptr %l73, !tbaa !29
  store ptr %t128, ptr %rv
  br label %ret
bb26:
  %t129 = load i64, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l9, !tbaa !24
  %t133 = icmp eq i64 %t129, %t130
  br i1 %t133, label %bb27, label %bb28
bb27:
  %t135 = load ptr, ptr %l11, !tbaa !29
  %t137 = getelementptr %"compiler/ast:Case", ptr %t135, i32 0, i32 5
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %l8, !tbaa !29
  br label %bb37
bb28:
  br label %bb29
bb29:
  %t140 = load ptr, ptr %l11, !tbaa !29
  %t142 = getelementptr %"compiler/ast:Case", ptr %t140, i32 0, i32 0
  %t143 = load %"compiler/source:Span", ptr %t142
  store %"compiler/source:Span" %t143, ptr %l80
  %t144 = load ptr, ptr %l11, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 5
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_45128824b39ec212_7869548692a04306)
  unreachable
bb31:
  br label %bb32
bb32:
  %t151 = load ptr, ptr %l11, !tbaa !29
  %t153 = getelementptr %"compiler/ast:Case", ptr %t151, i32 0, i32 5
  %t154 = load ptr, ptr %t153, !tbaa !29
  store ptr %t154, ptr %l85, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t157 = load ptr, ptr %l11, !tbaa !29
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCaseTest(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t155, ptr %t156, ptr %t157)
  store ptr %t161, ptr %l89
  br label %bb33
bb33:
  %t162 = load ptr, ptr %l8, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb34, label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_45128824b39ec212_7869548692a04306)
  unreachable
bb35:
  br label %bb36
bb36:
  %t166 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t167
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t167, i32 0, i32 0
  store i64 8, ptr %t168
  %t169 = load %"compiler/source:Span", ptr %l80
  %t170 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } undef, %"compiler/source:Span" %t169, 0
  %t171 = load ptr, ptr %l85, !tbaa !29
  %t172 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t170, ptr %t171, 1
  %t173 = load ptr, ptr %l89, !tbaa !29
  %t174 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t172, ptr %t173, 2
  %t176 = insertvalue { %"compiler/source:Span", ptr, ptr, ptr } %t174, ptr %t166, 3
  %t177 = getelementptr { i64, [4 x i64] }, ptr %t167, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr, ptr } %t176, ptr %t177
  %t178 = load { i64, [4 x i64] }, ptr %t167
  %t180 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t178, ptr %t180
  store ptr %t180, ptr %l8, !tbaa !29
  br label %bb37
bb37:
  %t182 = load i64, ptr %l10, !tbaa !24
  %t184 = sub i64 %t182, 1
  store i64 %t184, ptr %l10, !tbaa !24
  br label %bb16
bb38:
  %t186 = load ptr, ptr %l8, !tbaa !29
  %t188 = icmp eq ptr %t186, null
  br i1 %t188, label %bb39, label %bb40
bb39:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l4
  %t192 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunpin(ptr %v0, ptr %t190, %"compiler/source:Span" %t191, i64 %t192)
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l1
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t196, %"compiler/source:Span" %t197)
  store ptr %t200, ptr %l104
  br label %bb42
bb42:
  %t201 = load ptr, ptr %l104, !tbaa !29
  store ptr %t201, ptr %rv
  br label %ret
bb43:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l8, !tbaa !29
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v2, ptr %t202, ptr %t203, i32 %a3)
  store ptr %t209, ptr %l109
  br label %bb44
bb44:
  %t210 = load ptr, ptr %l109, !tbaa !29
  store ptr %t210, ptr %l12, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load %"compiler/source:Span", ptr %l4
  %t213 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunpin(ptr %v0, ptr %t211, %"compiler/source:Span" %t212, i64 %t213)
  br label %bb45
bb45:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l113, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t218, ptr %l114
  %t219 = load ptr, ptr %l12, !tbaa !29
  %t222 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t219)
  store i32 %t222, ptr %l117
  br label %bb46
bb46:
  %t223 = load i64, ptr %l6, !tbaa !24
  %t224 = load ptr, ptr %l12, !tbaa !29
  %t225 = load ptr, ptr %l113, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l114
  %t227 = load i32, ptr %l117, !tbaa !23
  %t230 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqOf(ptr %v0, ptr %v2, ptr %v2, ptr %t225, %"compiler/source:Span" %t226, i32 %t227, i64 %t223, ptr %t224)
  store ptr %t230, ptr %l120
  br label %bb47
bb47:
  %t231 = load ptr, ptr %l120, !tbaa !29
  store ptr %t231, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca i1
  %l20 = alloca %"compiler/check:narrowed"
  %l23 = alloca %"compiler/check:narrowed"
  %l24 = alloca i32
  %l29 = alloca %"compiler/check:narrowed"
  %l32 = alloca %"compiler/check:narrowed"
  %l33 = alloca i32
  %l39 = alloca i64
  %l41 = alloca i1
  %l42 = alloca %"compiler/check:nullNarrow"
  %l45 = alloca %"compiler/check:nullNarrow"
  %l46 = alloca i32
  %l51 = alloca %"compiler/check:nullNarrow"
  %l54 = alloca %"compiler/check:nullNarrow"
  %l55 = alloca i32
  %l58 = alloca i64
  %l60 = alloca i1
  %l61 = alloca %"compiler/check:errNarrow"
  %l64 = alloca %"compiler/check:errNarrow"
  %l65 = alloca i32
  %l70 = alloca %"compiler/check:errNarrow"
  %l73 = alloca %"compiler/check:errNarrow"
  %l74 = alloca i32
  %l80 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i32
  %l91 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i32
  %l101 = alloca i64
  %l103 = alloca i1
  %l104 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i32
  %l112 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i32
  %l121 = alloca ptr
  %l128 = alloca %"compiler/typed:Block"
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t7 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %t3, i64 %a4)
  store { i64, ptr } %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwind(ptr %v0, ptr %t9, i64 %a3)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t13)
  store ptr %t15, ptr %l14
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l14, !tbaa !29
  store ptr %t16, ptr %l6, !tbaa !29
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 46
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l17
  br label %bb5
bb5:
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = icmp sgt i64 %t22, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l6, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 46
  %t29 = call { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLast_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, %"compiler/check:narrowed" } %t29, 1
  %t31 = extractvalue { i32, %"compiler/check:narrowed" } %t29, 0
  store i32 %t31, ptr %l24
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb9, label %ok.33, !prof !99
ok.33:
  store %"compiler/check:narrowed" %t30, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb12
bb8:
  %t34 = load %"compiler/check:narrowed", ptr %l23
  store %"compiler/check:narrowed" %t34, ptr %l20
  br label %bb11
bb9:
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_f3fef639868d2bb5_dd9676d0e98a8921)
  unreachable
bb11:
  %t35 = getelementptr %"compiler/check:narrowed", ptr %l20, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = load i64, ptr %l1, !tbaa !24
  %t40 = icmp eq i64 %t36, %t37
  store i1 %t40, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l19, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb13, label %bb14
bb13:
  br label %bb26
bb14:
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 46
  %t49 = call { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2ePop_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t47)
  %t50 = extractvalue { i32, %"compiler/check:narrowed" } %t49, 1
  %t51 = extractvalue { i32, %"compiler/check:narrowed" } %t49, 0
  store i32 %t51, ptr %l33
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb17, label %ok.53, !prof !99
ok.53:
  store %"compiler/check:narrowed" %t50, ptr %l32
  br label %bb16
bb16:
  %t54 = load %"compiler/check:narrowed", ptr %l32
  store %"compiler/check:narrowed" %t54, ptr %l29
  br label %bb24
bb17:
  %t55 = load i32, ptr %l33, !tbaa !23
  %t56 = icmp eq i32 %t55, 65536
  br i1 %t56, label %bb18, label %bb19
bb18:
  call void @__olang_bang_failed_plain(ptr @olang_loc_df1f5fd28061949_6fd2bc487e6b648d)
  unreachable
bb19:
  %t58 = load i32, ptr %l33, !tbaa !23
  %t59 = icmp eq i32 %t58, 65537
  br i1 %t59, label %bb20, label %bb21
bb20:
  call void @__olang_bang_failed_plain(ptr @olang_loc_adf1079d57e55808_9269da6a723799fc)
  unreachable
bb21:
  %t61 = load i32, ptr %l33, !tbaa !23
  %t62 = icmp eq i32 %t61, 65538
  br i1 %t62, label %bb22, label %bb23
bb22:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4fa1eeadbabe5a66_3dfbfb89ab758d6a)
  unreachable
bb23:
  call void @__olang_bang_failed_plain(ptr @olang_loc_92a21335b7ae999a_7e07c1814bb2a646)
  unreachable
bb24:
  br label %bb25
bb25:
  br label %bb4
bb26:
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = getelementptr %"compiler/check:frame", ptr %t64, i32 0, i32 50
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l39
  br label %bb28
bb28:
  %t69 = load i64, ptr %l39, !tbaa !24
  %t70 = icmp sgt i64 %t69, 0
  br i1 %t70, label %bb29, label %bb30
bb29:
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t72, i32 0, i32 50
  %t76 = call { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLas_H41327bbfea6c01118b477d23a6e2def2(ptr %v0, ptr %s3, ptr %t74)
  %t77 = extractvalue { i32, %"compiler/check:nullNarrow" } %t76, 1
  %t78 = extractvalue { i32, %"compiler/check:nullNarrow" } %t76, 0
  store i32 %t78, ptr %l46
  %t79 = icmp ne i32 %t78, 0
  br i1 %t79, label %bb32, label %ok.80, !prof !99
ok.80:
  store %"compiler/check:nullNarrow" %t77, ptr %l45
  br label %bb31
bb30:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb35
bb31:
  %t81 = load %"compiler/check:nullNarrow", ptr %l45
  store %"compiler/check:nullNarrow" %t81, ptr %l42
  br label %bb34
bb32:
  br label %bb33
bb33:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_abe1ff4556bedc08_80ba96099639cb2c)
  unreachable
bb34:
  %t82 = getelementptr %"compiler/check:nullNarrow", ptr %l42, i32 0, i32 1
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  store i1 %t87, ptr %l41, !tbaa !21
  br label %bb35
bb35:
  %t89 = load i1, ptr %l41, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 50
  %t96 = call { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePop_H59a749d10c64cd066029408cbe89e7b7(ptr %v0, ptr %s3, ptr %t94)
  %t97 = extractvalue { i32, %"compiler/check:nullNarrow" } %t96, 1
  %t98 = extractvalue { i32, %"compiler/check:nullNarrow" } %t96, 0
  store i32 %t98, ptr %l55
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb40, label %ok.100, !prof !99
ok.100:
  store %"compiler/check:nullNarrow" %t97, ptr %l54
  br label %bb39
bb39:
  %t101 = load %"compiler/check:nullNarrow", ptr %l54
  store %"compiler/check:nullNarrow" %t101, ptr %l51
  br label %bb42
bb40:
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  br label %bb27
bb44:
  br label %bb45
bb45:
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t102, i32 0, i32 59
  %t106 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t104)
  store i64 %t106, ptr %l58
  br label %bb46
bb46:
  %t107 = load i64, ptr %l58, !tbaa !24
  %t108 = icmp sgt i64 %t107, 0
  br i1 %t108, label %bb47, label %bb48
bb47:
  %t110 = load ptr, ptr %l6, !tbaa !29
  %t112 = getelementptr %"compiler/check:frame", ptr %t110, i32 0, i32 59
  %t114 = call { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLast_He310b7451e653469b2155498b3293ff7(ptr %v0, ptr %t112)
  %t115 = extractvalue { i32, %"compiler/check:errNarrow" } %t114, 1
  %t116 = extractvalue { i32, %"compiler/check:errNarrow" } %t114, 0
  store i32 %t116, ptr %l65
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb50, label %ok.118, !prof !99
ok.118:
  store %"compiler/check:errNarrow" %t115, ptr %l64
  br label %bb49
bb48:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb53
bb49:
  %t119 = load %"compiler/check:errNarrow", ptr %l64
  store %"compiler/check:errNarrow" %t119, ptr %l61
  br label %bb52
bb50:
  br label %bb51
bb51:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_7a4929889a701fe3_96d6f303ecd0d8a7)
  unreachable
bb52:
  %t120 = getelementptr %"compiler/check:errNarrow", ptr %l61, i32 0, i32 2
  %t121 = load i64, ptr %t120, !tbaa !24
  %t122 = load i64, ptr %l1, !tbaa !24
  %t125 = icmp eq i64 %t121, %t122
  store i1 %t125, ptr %l60, !tbaa !21
  br label %bb53
bb53:
  %t127 = load i1, ptr %l60, !tbaa !21
  %t128 = xor i1 %t127, true
  br i1 %t128, label %bb54, label %bb55
bb54:
  br label %bb67
bb55:
  br label %bb56
bb56:
  %t130 = load ptr, ptr %l6, !tbaa !29
  %t132 = getelementptr %"compiler/check:frame", ptr %t130, i32 0, i32 59
  %t134 = call { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2ePop__He4c3571ab54dd9fc34e0d36cd7afb0ff(ptr %v0, ptr %t132)
  %t135 = extractvalue { i32, %"compiler/check:errNarrow" } %t134, 1
  %t136 = extractvalue { i32, %"compiler/check:errNarrow" } %t134, 0
  store i32 %t136, ptr %l74
  %t137 = icmp ne i32 %t136, 0
  br i1 %t137, label %bb58, label %ok.138, !prof !99
ok.138:
  store %"compiler/check:errNarrow" %t135, ptr %l73
  br label %bb57
bb57:
  %t139 = load %"compiler/check:errNarrow", ptr %l73
  store %"compiler/check:errNarrow" %t139, ptr %l70
  br label %bb65
bb58:
  %t140 = load i32, ptr %l74, !tbaa !23
  %t141 = icmp eq i32 %t140, 65536
  br i1 %t141, label %bb59, label %bb60
bb59:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b4897252f2a0467_e1365b27726b9d63)
  unreachable
bb60:
  %t143 = load i32, ptr %l74, !tbaa !23
  %t144 = icmp eq i32 %t143, 65537
  br i1 %t144, label %bb61, label %bb62
bb61:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b02f2e0c8b90d83e_466afc0716e3b9a2)
  unreachable
bb62:
  %t146 = load i32, ptr %l74, !tbaa !23
  %t147 = icmp eq i32 %t146, 65538
  br i1 %t147, label %bb63, label %bb64
bb63:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e882b6948f69dce8_e6367676615923ec)
  unreachable
bb64:
  call void @__olang_bang_failed_plain(ptr @olang_loc_9e6114e2cf841093_fa90ce222875bd2f)
  unreachable
bb65:
  br label %bb66
bb66:
  br label %bb45
bb67:
  br label %bb68
bb68:
  %t149 = load ptr, ptr %l6, !tbaa !29
  %t151 = getelementptr %"compiler/check:frame", ptr %t149, i32 0, i32 22
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t151)
  store i64 %t153, ptr %l80
  br label %bb69
bb69:
  %t154 = load i64, ptr %l80, !tbaa !24
  %t155 = icmp sgt i64 %t154, 0
  br i1 %t155, label %bb70, label %bb71
bb70:
  %t157 = load ptr, ptr %l6, !tbaa !29
  %t159 = getelementptr %"compiler/check:frame", ptr %t157, i32 0, i32 22
  %t161 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLast_3cI64_3e(ptr %v0, ptr %t159)
  %t162 = extractvalue { i32, i64 } %t161, 1
  %t163 = extractvalue { i32, i64 } %t161, 0
  store i32 %t163, ptr %l87
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb73, label %ok.165, !prof !99
ok.165:
  store i64 %t162, ptr %l86
  br label %bb72
bb71:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb76
bb72:
  %t166 = load i64, ptr %l86, !tbaa !24
  store i64 %t166, ptr %l83, !tbaa !24
  br label %bb75
bb73:
  br label %bb74
bb74:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_c349e4c9332250dd_9daf9d91ff07ef41)
  unreachable
bb75:
  %t167 = load i64, ptr %l1, !tbaa !24
  %t168 = load i64, ptr %l83, !tbaa !24
  %t170 = icmp eq i64 %t168, %t167
  store i1 %t170, ptr %l82, !tbaa !21
  br label %bb76
bb76:
  %t172 = load i1, ptr %l82, !tbaa !21
  %t173 = xor i1 %t172, true
  br i1 %t173, label %bb77, label %bb78
bb77:
  br label %bb90
bb78:
  br label %bb79
bb79:
  %t175 = load ptr, ptr %l6, !tbaa !29
  %t177 = getelementptr %"compiler/check:frame", ptr %t175, i32 0, i32 22
  %t179 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t177)
  %t180 = extractvalue { i32, i64 } %t179, 1
  %t181 = extractvalue { i32, i64 } %t179, 0
  store i32 %t181, ptr %l95
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb81, label %ok.183, !prof !99
ok.183:
  store i64 %t180, ptr %l94
  br label %bb80
bb80:
  %t184 = load i64, ptr %l94, !tbaa !24
  store i64 %t184, ptr %l91, !tbaa !24
  br label %bb88
bb81:
  %t185 = load i32, ptr %l95, !tbaa !23
  %t186 = icmp eq i32 %t185, 65536
  br i1 %t186, label %bb82, label %bb83
bb82:
  call void @__olang_bang_failed_plain(ptr @olang_loc_90c216d2a7707e63_13ebc04feeb9a31f)
  unreachable
bb83:
  %t188 = load i32, ptr %l95, !tbaa !23
  %t189 = icmp eq i32 %t188, 65537
  br i1 %t189, label %bb84, label %bb85
bb84:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e7cf760e54914750_8299ab19ca729e9c)
  unreachable
bb85:
  %t191 = load i32, ptr %l95, !tbaa !23
  %t192 = icmp eq i32 %t191, 65538
  br i1 %t192, label %bb86, label %bb87
bb86:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2de9afb4b96dcf94_71a46e56f9644858)
  unreachable
bb87:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6d051d6c732886d2_d9cb433bcdc0e6)
  unreachable
bb88:
  br label %bb89
bb89:
  br label %bb68
bb90:
  br label %bb91
bb91:
  %t194 = load ptr, ptr %l6, !tbaa !29
  %t196 = getelementptr %"compiler/check:frame", ptr %t194, i32 0, i32 24
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t196)
  store i64 %t198, ptr %l101
  br label %bb92
bb92:
  %t199 = load i64, ptr %l101, !tbaa !24
  %t200 = icmp sgt i64 %t199, 0
  br i1 %t200, label %bb93, label %bb94
bb93:
  %t202 = load ptr, ptr %l6, !tbaa !29
  %t204 = getelementptr %"compiler/check:frame", ptr %t202, i32 0, i32 24
  %t206 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLast_3cI64_3e(ptr %v0, ptr %t204)
  %t207 = extractvalue { i32, i64 } %t206, 1
  %t208 = extractvalue { i32, i64 } %t206, 0
  store i32 %t208, ptr %l108
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb96, label %ok.210, !prof !99
ok.210:
  store i64 %t207, ptr %l107
  br label %bb95
bb94:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb99
bb95:
  %t211 = load i64, ptr %l107, !tbaa !24
  store i64 %t211, ptr %l104, !tbaa !24
  br label %bb98
bb96:
  br label %bb97
bb97:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_fd3792a3478c708a_bd2f712e645466e6)
  unreachable
bb98:
  %t212 = load i64, ptr %l1, !tbaa !24
  %t213 = load i64, ptr %l104, !tbaa !24
  %t215 = icmp eq i64 %t213, %t212
  store i1 %t215, ptr %l103, !tbaa !21
  br label %bb99
bb99:
  %t217 = load i1, ptr %l103, !tbaa !21
  %t218 = xor i1 %t217, true
  br i1 %t218, label %bb100, label %bb101
bb100:
  br label %bb113
bb101:
  br label %bb102
bb102:
  %t220 = load ptr, ptr %l6, !tbaa !29
  %t222 = getelementptr %"compiler/check:frame", ptr %t220, i32 0, i32 24
  %t224 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t222)
  %t225 = extractvalue { i32, i64 } %t224, 1
  %t226 = extractvalue { i32, i64 } %t224, 0
  store i32 %t226, ptr %l116
  %t227 = icmp ne i32 %t226, 0
  br i1 %t227, label %bb104, label %ok.228, !prof !99
ok.228:
  store i64 %t225, ptr %l115
  br label %bb103
bb103:
  %t229 = load i64, ptr %l115, !tbaa !24
  store i64 %t229, ptr %l112, !tbaa !24
  br label %bb111
bb104:
  %t230 = load i32, ptr %l116, !tbaa !23
  %t231 = icmp eq i32 %t230, 65536
  br i1 %t231, label %bb105, label %bb106
bb105:
  call void @__olang_bang_failed_plain(ptr @olang_loc_12b3dc107423b434_482fbf8ad69d32f8)
  unreachable
bb106:
  %t233 = load i32, ptr %l116, !tbaa !23
  %t234 = icmp eq i32 %t233, 65537
  br i1 %t234, label %bb107, label %bb108
bb107:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4090f31281295d0b_b76133cd00d27c97)
  unreachable
bb108:
  %t236 = load i32, ptr %l116, !tbaa !23
  %t237 = icmp eq i32 %t236, 65538
  br i1 %t237, label %bb109, label %bb110
bb109:
  call void @__olang_bang_failed_plain(ptr @olang_loc_ee572ef2923bf685_6f413c271381cde1)
  unreachable
bb110:
  call void @__olang_bang_failed_plain(ptr @olang_loc_ff67d74e2821509e_7f8039e3a9b6d64a)
  unreachable
bb111:
  br label %bb112
bb112:
  br label %bb91
bb113:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t239)
  store ptr %t241, ptr %l121
  br label %bb114
bb114:
  %t242 = load ptr, ptr %l121, !tbaa !29
  %t246 = getelementptr %"compiler/check:frame", ptr %t242, i32 0, i32 7
  store i64 %a2, ptr %t246, !tbaa !24
  %t247 = load i64, ptr %l1, !tbaa !24
  %t249 = trunc i64 %t247 to i32
  %t251 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t254 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v1, ptr %v1, i32 %t249, { i64, ptr } %t251)
  store %"compiler/typed:Block" %t254, ptr %l128
  br label %bb115
bb115:
  %t255 = load %"compiler/typed:Block", ptr %l128
  %t256 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/typed:Block" %t255, ptr %t256
  store ptr %t256, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnsFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %lp17 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca i32
  %l24 = alloca ptr
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i32
  %l47 = alloca i32
  %l50 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca %"compiler/typed:Local"
  %l57 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l81 = alloca i64
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca { i64, ptr }
  %l114 = alloca i32
  %l115 = alloca %"compiler/source:Span"
  %l118 = alloca i32
  %l127 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l132 = alloca i1
  %l139 = alloca i1
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca { i64, ptr }
  %l143 = alloca i32
  %l144 = alloca i32
  %l147 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca ptr
  %l156 = alloca i32
  %l158 = alloca %"compiler/typed:Make"
  %l165 = alloca { i64, ptr }
  %l170 = alloca i64
  %l180 = alloca ptr
  %s0 = alloca %olang.scope
  %t198 = alloca { i64, [4 x i64] }, align 8
  %t211 = alloca { i64, [4 x i64] }, align 8
  %t289 = alloca { i64, [5 x i64] }, align 8
  %t317 = alloca { i64, [1 x i64] }, align 8
  %t335 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l22
  br label %bb1
bb1:
  %t9 = load i32, ptr %l22, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l24
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l24, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 5
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l26
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l28
  br label %bb3
bb3:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l3
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t21, ptr %l30
  br label %bb4
bb4:
  %t22 = load i64, ptr %l30, !tbaa !24
  %t23 = icmp slt i64 %t22, 2
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb8
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l35
  br label %bb7
bb7:
  %t30 = load i1, ptr %l35, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l32, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l32, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb12
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l41
  br label %bb11
bb11:
  %t42 = load i1, ptr %l41, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l37, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t47 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 0)
  store i32 %t47, ptr %l44
  br label %bb16
bb16:
  %t48 = load i32, ptr %l44, !tbaa !23
  %t49 = sext i32 %t48 to i64
  store i64 %t49, ptr %l4, !tbaa !24
  %t52 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 1)
  store i32 %t52, ptr %l47
  br label %bb17
bb17:
  %t53 = load i32, ptr %l47, !tbaa !23
  %t54 = sext i32 %t53 to i64
  store i64 %t54, ptr %l5, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t56)
  store ptr %t58, ptr %l50
  br label %bb18
bb18:
  %t60 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 0)
  store i32 %t60, ptr %l52
  br label %bb19
bb19:
  %t61 = load ptr, ptr %l50, !tbaa !29
  %t62 = load i32, ptr %l52, !tbaa !23
  %t63 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t61, i32 %t62)
  store %"compiler/typed:Local" %t63, ptr %l53
  br label %bb20
bb20:
  %t64 = getelementptr %"compiler/typed:Local", ptr %l53, i32 0, i32 1
  %t65 = load %"compiler/source:Span", ptr %t64
  store %"compiler/source:Span" %t65, ptr %l6
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  store ptr %t72, ptr %l57, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l1, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t82, ptr %l62
  br label %bb21
bb21:
  %t83 = load ptr, ptr %l57, !tbaa !29
  %t84 = load i32, ptr %l62, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t83, i32 %t84)
  store { i64, ptr } %t85, ptr %l63
  br label %bb22
bb22:
  %t86 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t91 = load i32, ptr %l1, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %s0, ptr %t90, i32 %t91)
  store { i64, ptr } %t94, ptr %l67
  br label %bb23
bb23:
  %t95 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t95, ptr %l8, !tbaa !27
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l70, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l2, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l75
  br label %bb24
bb24:
  %t112 = load ptr, ptr %l70, !tbaa !29
  %t113 = load i32, ptr %l75, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t112, i32 %t113)
  store { i64, ptr } %t114, ptr %l76
  br label %bb25
bb25:
  %t115 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t115, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t118, i64 %t121)
  store i64 %t124, ptr %l81
  br label %bb26
bb26:
  %t125 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = load i64, ptr %l81, !tbaa !24
  %t130 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t128, i64 %t127)
  store i64 %t130, ptr %l84
  br label %bb27
bb27:
  %t131 = load i64, ptr %l84, !tbaa !24
  store i64 %t131, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = icmp sgt i64 %t132, %t133
  br i1 %t136, label %bb28, label %bb29
bb28:
  %t138 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb33
bb30:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t143 = load i64, ptr %l10, !tbaa !24
  %t146 = sub i64 %t142, %t143
  %t147 = load i64, ptr %l12, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t152 = sub i64 %t150, 1
  %t153 = load i64, ptr %l12, !tbaa !24
  %t156 = sdiv i64 %t152, %t153
  store i64 %t156, ptr %l91, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb32
bb32:
  %t158 = load i64, ptr %l91, !tbaa !24
  store i64 %t158, ptr %l88, !tbaa !24
  br label %bb33
bb33:
  %t159 = load i64, ptr %l88, !tbaa !24
  store i64 %t159, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb34
bb34:
  %t160 = load i64, ptr %l14, !tbaa !24
  %t161 = load i64, ptr %l13, !tbaa !24
  %t164 = icmp slt i64 %t160, %t161
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb35, label %bb36
bb35:
  br label %bb55
bb36:
  br label %bb37
bb37:
  %t168 = load i64, ptr %l10, !tbaa !24
  %t169 = load i64, ptr %l14, !tbaa !24
  %t170 = load i64, ptr %l12, !tbaa !24
  %t173 = mul i64 %t169, %t170
  %t176 = add i64 %t168, %t173
  store i64 %t176, ptr %l15, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l109, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t179, ptr %l110
  %t180 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t180, ptr %l111
  %t181 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t181, ptr %l112, !tbaa !27
  %t182 = load i64, ptr %l15, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 %t182
  %t187 = load i32, ptr %t186, !tbaa !33
  store i32 %t187, ptr %l114, !tbaa !23
  %t188 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t188, ptr %l115
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i64, ptr %l5, !tbaa !24
  %t193 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t189, i64 %t190)
  store i32 %t193, ptr %l118
  br label %bb38
bb38:
  %t194 = load i64, ptr %l5, !tbaa !24
  %t196 = trunc i64 %t194 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t198, i32 0, i32 0
  store i64 0, ptr %t199
  %t200 = load %"compiler/source:Span", ptr %l115
  %t201 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t200, 0
  %t202 = load i32, ptr %l118, !tbaa !23
  %t203 = insertvalue { %"compiler/source:Span", i32, i32 } %t201, i32 %t202, 1
  %t205 = insertvalue { %"compiler/source:Span", i32, i32 } %t203, i32 %t196, 2
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t198, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t205, ptr %t206
  %t207 = load { i64, [4 x i64] }, ptr %t198
  %t209 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t207, ptr %t209
  %t210 = load i64, ptr %l15, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t211
  %t212 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 0
  store i64 3, ptr %t212
  %t213 = load %"compiler/source:Span", ptr %l111
  %t214 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t213, 0
  %t215 = load i32, ptr %l114, !tbaa !23
  %t216 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t214, i32 %t215, 1
  %t218 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t216, ptr %t209, 2
  %t220 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t218, i64 %t210, 3
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t220, ptr %t221
  %t222 = load { i64, [4 x i64] }, ptr %t211
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t222, ptr %t224
  %t225 = load ptr, ptr %l109, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l110
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t225, %"compiler/source:Span" %t226, ptr %t224)
  store ptr %t228, ptr %l127
  br label %bb39
bb39:
  %t229 = load ptr, ptr %l127, !tbaa !29
  store ptr %t229, ptr %l16, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t231, ptr %l129, !tbaa !27
  %t232 = load i64, ptr %l15, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  %t240 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t230, i32 %t237)
  store i1 %t240, ptr %l132
  br label %bb40
bb40:
  %t241 = load i1, ptr %l132, !tbaa !21
  %t242 = xor i1 %t241, true
  br i1 %t242, label %bb41, label %bb42
bb41:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l16, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l6
  %t248 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t253 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t244, ptr %t245, %"compiler/source:Span" %t247, i64 %t248)
  store i1 %t253, ptr %l139
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  %t254 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t254, ptr %l140
  %t255 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t255, ptr %l141, !tbaa !27
  %t256 = load i64, ptr %l15, !tbaa !24
  %t258 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i32, ptr %t259, i64 %t256
  %t261 = load i32, ptr %t260, !tbaa !33
  store i32 %t261, ptr %l143, !tbaa !23
  store i32 3, ptr %l144
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l16, !tbaa !29
  %t266 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t262, ptr %t263)
  store { i64, ptr } %t266, ptr %l147
  br label %bb45
bb45:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l6
  %t269 = load i64, ptr %l4, !tbaa !24
  %t273 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t267, %"compiler/source:Span" %t268, i64 %t269)
  store ptr %t273, ptr %l151
  br label %bb46
bb46:
  %t274 = load ptr, ptr %l151, !tbaa !29
  store ptr %t274, ptr %l152, !tbaa !29
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l6
  %t280 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t275, i32 1, %"compiler/source:Span" %t276)
  store i32 %t280, ptr %l156
  br label %bb47
bb47:
  %t281 = load i32, ptr %l144, !range !{i32 0, i32 5}
  %t282 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t283 = load ptr, ptr %l152, !tbaa !29
  %t284 = load i32, ptr %l156, !tbaa !23
  %t286 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t281, i64 0, { i64, ptr } %t282, ptr %t283, i32 %t284, i32 1, i1 false)
  store %"compiler/typed:Make" %t286, ptr %l158
  br label %bb48
bb48:
  %t287 = load %"compiler/typed:Make", ptr %l158
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t287, ptr %t288
  store { i64, [5 x i64] } zeroinitializer, ptr %t289
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 0
  store i64 7, ptr %t290
  %t291 = load %"compiler/source:Span", ptr %l140
  %t292 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t291, 0
  %t293 = load i32, ptr %l143, !tbaa !23
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr } %t292, i32 %t293, 1
  %t296 = insertvalue { %"compiler/source:Span", i32, ptr } %t294, ptr %t288, 2
  %t297 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t296, ptr %t297
  %t298 = load { i64, [5 x i64] }, ptr %t289
  %t299 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t299, ptr %lp17
  %t301 = load ptr, ptr %lp17
  store { i64, [5 x i64] } %t298, ptr %t301
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i64, ptr %l15, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i32, ptr %t306, i64 %t303
  %t308 = load i32, ptr %t307, !tbaa !33
  %t309 = load %"compiler/source:Span", ptr %l6
  %t310 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t310, ptr %l165, !tbaa !27
  %t311 = load i64, ptr %l15, !tbaa !24
  %t313 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr i32, ptr %t314, i64 %t311
  %t316 = load i32, ptr %t315, !tbaa !33
  store { i64, [1 x i64] } zeroinitializer, ptr %t317
  %t318 = getelementptr { i64, [1 x i64] }, ptr %t317, i32 0, i32 0
  store i64 4, ptr %t318
  %t319 = load { i64, [1 x i64] }, ptr %t317
  %t326 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t302, i32 %t308, %"compiler/source:Span" %t309, i32 %t316, i32 6, { i64, [1 x i64] } %t319)
  store i64 %t326, ptr %l170
  br label %bb49
bb49:
  %t327 = load i64, ptr %l170, !tbaa !24
  store i64 %t327, ptr %l18, !tbaa !24
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load %"compiler/source:Span", ptr %l6
  %t330 = load i64, ptr %l18, !tbaa !24
  %t332 = trunc i64 %t330 to i32
  %t334 = load ptr, ptr %lp17
  store { i64, [3 x i64] } zeroinitializer, ptr %t335
  %t336 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 0
  store i64 0, ptr %t336
  %t338 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t329, 0
  %t340 = insertvalue { %"compiler/source:Span", i32, ptr } %t338, i32 %t332, 1
  %t342 = insertvalue { %"compiler/source:Span", i32, ptr } %t340, ptr %t334, 2
  %t343 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t342, ptr %t343
  %t344 = load { i64, [3 x i64] }, ptr %t335
  %t346 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t344, ptr %t346
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t328, ptr %t346)
  br label %bb50
bb50:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t349)
  store ptr %t351, ptr %l180
  br label %bb51
bb51:
  %t352 = load ptr, ptr %l180, !tbaa !29
  %t354 = getelementptr %"compiler/typed:Body", ptr %t352, i32 0, i32 10
  %t355 = load i64, ptr %l18, !tbaa !24
  %t357 = trunc i64 %t355 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t354, i32 %t357)
  br label %bb52
bb52:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i64, ptr %l18, !tbaa !24
  %t363 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %t361, i64 %t362, %"compiler/source:Span" %t363, i1 true)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t367 = load i64, ptr %l14, !tbaa !24
  %t369 = add i64 %t367, 1
  store i64 %t369, ptr %l14, !tbaa !24
  br label %bb34
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclFact(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i1
  %l19 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l7, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Func", ptr %t14, i32 0, i32 3
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Sig", ptr %t17, i32 0, i32 4
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb22
bb6:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t24, ptr %l15
  br label %bb7
bb7:
  %t25 = load i1, ptr %l15, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 7
  %t29 = load i1, ptr %t28, !tbaa !21
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb22
bb11:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t33, ptr %l19
  br label %bb12
bb12:
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t38, i64 %t39)
  store i1 %t42, ptr %l23
  br label %bb16
bb16:
  %t43 = load i1, ptr %l23, !tbaa !21
  store i1 %t43, ptr %l8, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Sig", ptr %t47, i32 0, i32 6
  %t50 = load i1, ptr %t49, !tbaa !21
  store i1 %t50, ptr %l8, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bdeebae2e62e4381_d7e2b33750a898f5)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t52 = load i1, ptr %l8, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/check:reflList"
  %l10 = alloca %"compiler/check:reflVal"
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca ptr
  %l28 = alloca %"compiler/names:Ref"
  %l33 = alloca i32
  %l35 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i32
  %l43 = alloca i1
  %l48 = alloca i32
  %l55 = alloca i64
  %l58 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca %"compiler/generic:Desc"
  %l70 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca i1
  %l84 = alloca %"compiler/check:reflList"
  %l87 = alloca i1
  %l93 = alloca { i64, ptr }
  %l95 = alloca %"compiler/check:reflVal"
  %l103 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca i1
  %l112 = alloca i32
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb33
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l22, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l24
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l24, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l28
  br label %bb7
bb7:
  %t42 = getelementptr %"compiler/names:Ref", ptr %l28, i32 0, i32 0
  %t43 = load i32, ptr %t42, !range !{i32 0, i32 9}
  %t45 = trunc i64 1 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb8, label %bb9
bb8:
  store i32 -1, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t51)
  store ptr %t53, ptr %l35
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t56 = getelementptr %"compiler/check:frame", ptr %t54, i32 0, i32 4
  %t57 = getelementptr %"compiler/generic:Context", ptr %t56, i32 0, i32 3
  %t58 = load i32, ptr %l3, !tbaa !23
  %t61 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t57, i32 %t58)
  %t62 = extractvalue { i32, i32 } %t61, 1
  %t63 = extractvalue { i32, i32 } %t61, 0
  store i32 %t63, ptr %l40
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb13, label %ok.65, !prof !99
ok.65:
  store i32 %t62, ptr %l39
  br label %bb12
bb12:
  %t66 = load i32, ptr %l39, !tbaa !23
  store i32 %t66, ptr %l33, !tbaa !23
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l33, !tbaa !23
  br label %bb15
bb15:
  %t67 = load i32, ptr %l33, !tbaa !23
  store i32 %t67, ptr %l4, !tbaa !23
  %t68 = load i32, ptr %l4, !tbaa !23
  %t70 = icmp sge i32 %t68, 0
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  %t78 = load i32, ptr %l4, !tbaa !23
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t81, ptr %l48
  br label %bb18
bb17:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb19
bb18:
  %t82 = load i32, ptr %l48, !range !{i32 0, i32 33}
  %t84 = trunc i64 26 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l43, !tbaa !21
  br label %bb19
bb19:
  %t89 = load i1, ptr %l43, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  %t90 = load i32, ptr %l4, !tbaa !23
  store i32 %t90, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t92, i32 %t93)
  store i64 %t96, ptr %l55
  br label %bb23
bb23:
  %t97 = load i64, ptr %l55, !tbaa !24
  store i64 %t97, ptr %l5, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t100 = icmp sge i64 %t98, 0
  br i1 %t100, label %bb24, label %bb25
bb24:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  store ptr %t105, ptr %l60, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l5, !tbaa !24
  %t110 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t106, i64 %t107)
  store i32 %t110, ptr %l63
  br label %bb26
bb25:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb28
bb26:
  %t111 = load ptr, ptr %l60, !tbaa !29
  %t112 = load i32, ptr %l63, !tbaa !23
  %t113 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t111, i32 %t112)
  store %"compiler/generic:Desc" %t113, ptr %l64
  br label %bb27
bb27:
  %t114 = getelementptr %"compiler/generic:Desc", ptr %l64, i32 0, i32 0
  %t115 = load i64, ptr %t114, !tbaa !24
  %t116 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescNone, !tbaa !24
  %t119 = icmp ne i64 %t115, %t116
  store i1 %t119, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t121 = load i1, ptr %l58, !tbaa !21
  br i1 %t121, label %bb29, label %bb30
bb29:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t122, i64 %t123)
  store i32 %t126, ptr %l70
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t127 = load i32, ptr %l70, !tbaa !23
  store i32 %t127, ptr %rv
  br label %ret
bb32:
  store i32 -1, ptr %rv
  br label %ret
bb33:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t130 = load ptr, ptr %l72, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb34, label %bb35
bb34:
  %t133 = load ptr, ptr %l72, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 30}
  %t136 = icmp eq i64 %t134, 15
  store i1 %t136, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  %t137 = load i1, ptr %l73, !tbaa !21
  br i1 %t137, label %bb36, label %bb37
bb36:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t140, i32 0, i32 0
  %t142 = load %"compiler/source:Span", ptr %t141
  store %"compiler/source:Span" %t142, ptr %l6
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t146, i32 0, i32 1
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l7, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t152, i32 0, i32 2
  %t154 = load { i64, ptr }, ptr %t153
  store { i64, ptr } %t154, ptr %l8, !tbaa !27
  br label %bb38
bb37:
  br label %bb51
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t160 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t156, ptr %t157)
  store %"compiler/check:reflList" %t160, ptr %l84
  br label %bb39
bb39:
  %t161 = load %"compiler/check:reflList", ptr %l84
  store %"compiler/check:reflList" %t161, ptr %l9
  %t162 = getelementptr %"compiler/check:reflList", ptr %l9, i32 0, i32 0
  %t163 = load i1, ptr %t162, !tbaa !21
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb42
bb41:
  %t167 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t171 = icmp ne i64 %t169, 1
  store i1 %t171, ptr %l87, !tbaa !21
  br label %bb42
bb42:
  %t173 = load i1, ptr %l87, !tbaa !21
  br i1 %t173, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s5)
  store i32 -1, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t176, ptr %l93, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr ptr, ptr %t178, i64 0
  %t180 = load ptr, ptr %t179, !tbaa !39
  %t183 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflInt(ptr %v0, ptr %v1, ptr %s5, ptr %t175, ptr %t180)
  store %"compiler/check:reflVal" %t183, ptr %l95
  br label %bb46
bb46:
  %t184 = load %"compiler/check:reflVal", ptr %l95
  store %"compiler/check:reflVal" %t184, ptr %l10
  %t185 = getelementptr %"compiler/check:reflVal", ptr %l10, i32 0, i32 0
  %t186 = load i1, ptr %t185, !tbaa !21
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s5)
  store i32 -1, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l6
  %t193 = load %"compiler/check:reflList", ptr %l9
  %t194 = getelementptr %"compiler/check:reflVal", ptr %l10, i32 0, i32 2
  %t195 = load i64, ptr %t194, !tbaa !24
  %t200 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItem(ptr %v0, ptr %t191, %"compiler/source:Span" %t192, %"compiler/check:reflList" %t193, i64 %t195)
  store i32 %t200, ptr %l103
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s5)
  %t201 = load i32, ptr %l103, !tbaa !23
  store i32 %t201, ptr %rv
  br label %ret
bb51:
  %t202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t202, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t203 = load ptr, ptr %l104, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb52, label %bb53
bb52:
  %t206 = load ptr, ptr %l104, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 30}
  %t209 = icmp eq i64 %t207, 2
  store i1 %t209, ptr %l105, !tbaa !21
  br label %bb53
bb53:
  %t210 = load i1, ptr %l105, !tbaa !21
  br i1 %t210, label %bb54, label %bb55
bb54:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l11, !tbaa !29
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l11, !tbaa !29
  %t221 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t217, ptr %t218)
  store i32 %t221, ptr %l112
  br label %bb57
bb57:
  %t222 = load i32, ptr %l112, !tbaa !23
  store i32 %t222, ptr %rv
  br label %ret
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i32 -1, ptr %rv
  br label %ret
bb62:
  call void @__olang_check_failed(ptr @olang_loc_b90f60f44557575f_8372487000419b6b)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca ptr
  %l43 = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb39
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l5, !tbaa !29
  store ptr %t29, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 30}
  %t36 = icmp eq i64 %t34, 22
  store i1 %t36, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l21, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb37
bb13:
  %t38 = load ptr, ptr %l5, !tbaa !29
  store ptr %t38, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t39 = load ptr, ptr %l24, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 30}
  %t45 = icmp eq i64 %t43, 26
  store i1 %t45, ptr %l25, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l25, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l6, !tbaa !29
  br label %bb18
bb17:
  br label %bb31
bb18:
  %t53 = load ptr, ptr %l6, !tbaa !29
  store ptr %t53, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb19, label %bb20
bb19:
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 30}
  %t60 = icmp eq i64 %t58, 22
  store i1 %t60, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t61 = load i1, ptr %l31, !tbaa !21
  br i1 %t61, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb30
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l6, !tbaa !29
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t62, ptr %t63, i32 %t65)
  store ptr %t69, ptr %l38
  br label %bb28
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_721d232fa5d325a7_d23ce00c5b55667b)
  unreachable
bb30:
  br label %bb37
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t70, ptr %t71, i32 %t73)
  store ptr %t77, ptr %l43
  br label %bb35
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ab50fa771a5bafc6_239e772f46bf41fa)
  unreachable
bb37:
  br label %bb38
bb38:
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l3, !tbaa !24
  br label %bb4
bb39:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca i32
  %l15 = alloca i32
  %l17 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %lp34 = alloca ptr
  %lp35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca i32
  %l49 = alloca i32
  %l53 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i1
  %l68 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i32
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l82 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca i32
  %l89 = alloca i32
  %l95 = alloca ptr
  %l101 = alloca ptr
  %l104 = alloca i32
  %l107 = alloca i32
  %l112 = alloca i32
  %l115 = alloca i1
  %l120 = alloca i32
  %l123 = alloca i1
  %l128 = alloca i32
  %l133 = alloca i32
  %l139 = alloca i32
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l148 = alloca i32
  %l150 = alloca ptr
  %l153 = alloca i32
  %l156 = alloca i32
  %l163 = alloca i32
  %l166 = alloca ptr
  %l167 = alloca ptr
  %l172 = alloca i32
  %l174 = alloca ptr
  %l177 = alloca i32
  %l180 = alloca i32
  %l187 = alloca i32
  %l190 = alloca i1
  %l195 = alloca i32
  %l198 = alloca i1
  %l203 = alloca i1
  %l208 = alloca i1
  %l214 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca ptr
  %l221 = alloca i32
  %l223 = alloca ptr
  %l226 = alloca i32
  %l229 = alloca i32
  %l232 = alloca ptr
  %l233 = alloca ptr
  %l238 = alloca i32
  %l240 = alloca ptr
  %l243 = alloca i32
  %l246 = alloca i32
  %l254 = alloca i1
  %l259 = alloca i1
  %l260 = alloca ptr
  %l261 = alloca ptr
  %l264 = alloca i1
  %l265 = alloca i1
  %l268 = alloca i1
  %l269 = alloca i32
  %l275 = alloca i32
  %l278 = alloca ptr
  %l281 = alloca i32
  %l286 = alloca i1
  %l287 = alloca ptr
  %l288 = alloca ptr
  %l291 = alloca i1
  %l292 = alloca i1
  %l295 = alloca i1
  %l296 = alloca i32
  %l302 = alloca i32
  %l305 = alloca ptr
  %l308 = alloca i32
  %l314 = alloca i32
  %l317 = alloca i1
  %l322 = alloca i32
  %l325 = alloca i1
  %l328 = alloca ptr
  %l333 = alloca i32
  %l338 = alloca i32
  %l339 = alloca i1
  %l340 = alloca i1
  %l345 = alloca i1
  %l346 = alloca i1
  %l351 = alloca i1
  %l354 = alloca ptr
  %l357 = alloca ptr
  %l360 = alloca i32
  %l361 = alloca i32
  %l362 = alloca i32
  %l363 = alloca ptr
  %l364 = alloca ptr
  %l367 = alloca i1
  %l368 = alloca i1
  %l371 = alloca i1
  %l372 = alloca i32
  %l378 = alloca i32
  %l381 = alloca ptr
  %l382 = alloca ptr
  %l383 = alloca ptr
  %l386 = alloca i1
  %l387 = alloca i1
  %l390 = alloca i1
  %l391 = alloca i32
  %l397 = alloca i32
  %l400 = alloca ptr
  %l403 = alloca i32
  %l406 = alloca i32
  %l413 = alloca ptr
  %l414 = alloca %"compiler/source:Span"
  %l417 = alloca { i64, ptr }
  %l418 = alloca { i64, ptr }
  %l421 = alloca { i64, ptr }
  %l423 = alloca %"compiler/diagmsg:Msg"
  %l424 = alloca i64
  %l428 = alloca ptr
  %l431 = alloca i64
  %l437 = alloca ptr
  %l438 = alloca ptr
  %l442 = alloca %"compiler/source:Span"
  %l446 = alloca { i64, [3 x i64] }
  %l449 = alloca { i64, ptr }
  %l451 = alloca %"compiler/diagmsg:Msg"
  %l452 = alloca i64
  %l456 = alloca ptr
  %l459 = alloca i1
  %l462 = alloca i1
  %l463 = alloca i1
  %l466 = alloca i1
  %l467 = alloca i1
  %l472 = alloca i1
  %l473 = alloca i1
  %l478 = alloca i1
  %l481 = alloca i64
  %l487 = alloca i64
  %l502 = alloca i64
  %l512 = alloca ptr
  %l513 = alloca %"compiler/source:Span"
  %l514 = alloca i32
  %l515 = alloca i32
  %l519 = alloca ptr
  %l523 = alloca ptr
  %l525 = alloca ptr
  %l526 = alloca ptr
  %l527 = alloca %"compiler/source:Span"
  %l528 = alloca i32
  %l529 = alloca i32
  %l533 = alloca ptr
  %l537 = alloca ptr
  %l539 = alloca ptr
  %l540 = alloca ptr
  %l541 = alloca %"compiler/source:Span"
  %l542 = alloca i32
  %l543 = alloca i32
  %l547 = alloca ptr
  %l551 = alloca ptr
  %l553 = alloca ptr
  %l554 = alloca ptr
  %l555 = alloca %"compiler/source:Span"
  %l556 = alloca %"compiler/source:Span"
  %l561 = alloca i32
  %l567 = alloca ptr
  %l568 = alloca ptr
  %l569 = alloca %"compiler/source:Span"
  %l570 = alloca %"compiler/source:Span"
  %l575 = alloca i32
  %l581 = alloca ptr
  %l582 = alloca ptr
  %l583 = alloca %"compiler/source:Span"
  %l584 = alloca %"compiler/source:Span"
  %l585 = alloca i64
  %l587 = alloca ptr
  %l590 = alloca { i64, ptr }
  %l593 = alloca { i64, ptr }
  %l597 = alloca ptr
  %l598 = alloca %"compiler/source:Span"
  %l599 = alloca i32
  %l600 = alloca ptr
  %l604 = alloca ptr
  %l607 = alloca %"compiler/typed:Cond"
  %l610 = alloca %"compiler/source:Span"
  %l611 = alloca i32
  %l615 = alloca { i64, ptr }
  %l616 = alloca %"compiler/source:Span"
  %l617 = alloca i32
  %l622 = alloca %"compiler/typed:Cond"
  %l626 = alloca %"compiler/typed:Seq"
  %l631 = alloca ptr
  %l635 = alloca ptr
  %l639 = alloca ptr
  %l640 = alloca %"compiler/source:Span"
  %l641 = alloca %"compiler/source:Span"
  %l642 = alloca i64
  %l644 = alloca ptr
  %l647 = alloca { i64, ptr }
  %l650 = alloca { i64, ptr }
  %l654 = alloca ptr
  %l657 = alloca ptr
  %l661 = alloca ptr
  %l665 = alloca i1
  %l666 = alloca i1
  %l669 = alloca i1
  %l670 = alloca i1
  %l673 = alloca i1
  %l674 = alloca i1
  %l677 = alloca i1
  %l678 = alloca i1
  %l683 = alloca i32
  %l693 = alloca ptr
  %l696 = alloca ptr
  %l700 = alloca ptr
  %l704 = alloca i1
  %l710 = alloca ptr
  %l718 = alloca ptr
  %l721 = alloca ptr
  %l725 = alloca ptr
  %l729 = alloca i1
  %l730 = alloca i1
  %l733 = alloca i1
  %l734 = alloca i32
  %l740 = alloca i32
  %l744 = alloca i1
  %l745 = alloca i1
  %l748 = alloca i1
  %l749 = alloca i1
  %l754 = alloca i1
  %l755 = alloca i1
  %l760 = alloca i1
  %l765 = alloca i32
  %l770 = alloca ptr
  %l775 = alloca ptr
  %l778 = alloca i64
  %l785 = alloca ptr
  %l786 = alloca %"compiler/source:Span"
  %l787 = alloca i32
  %l791 = alloca ptr
  %l795 = alloca { i64, ptr }
  %l796 = alloca ptr
  %l799 = alloca ptr
  %l803 = alloca ptr
  %s1 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca ptr
  %t889 = alloca { i64, [1 x i64] }, align 8
  %t908 = alloca { i64, [3 x i64] }, align 8
  %t925 = alloca { i64, [1 x i64] }, align 8
  %t944 = alloca { i64, [3 x i64] }, align 8
  %t1053 = alloca { i64, [4 x i64] }, align 8
  %t1087 = alloca { i64, [4 x i64] }, align 8
  %t1157 = alloca { i64, [5 x i64] }, align 8
  %t1191 = alloca { i64, [5 x i64] }, align 8
  %t1208 = alloca { i64, [5 x i64] }, align 8
  %t1534 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l46
  br label %bb1
bb1:
  %t5 = load i32, ptr %l46, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t6)
  store i32 %t9, ptr %l49
  br label %bb2
bb2:
  %t10 = load i32, ptr %l49, !tbaa !23
  store i32 %t10, ptr %l6, !tbaa !23
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t15 = icmp eq i32 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i32, ptr %l6, !tbaa !23
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t21 = icmp eq i32 %t17, %t18
  store i1 %t21, ptr %l53, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l53, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t28 = icmp ne i32 %t24, %t25
  br i1 %t28, label %bb8, label %bb9
bb7:
  br label %bb29
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l60, !tbaa !29
  br label %bb10
bb9:
  %t32 = load ptr, ptr %l4, !tbaa !29
  store ptr %t32, ptr %l60, !tbaa !29
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l60, !tbaa !29
  store ptr %t34, ptr %l7, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l63, !tbaa !29
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t38 = load ptr, ptr @__olang_prog_scope
  %t40 = call i32 @compiler_2fcheck_2etypeOf(ptr %t38, ptr %t36)
  store i32 %t40, ptr %l66
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l63, !tbaa !29
  %t42 = load i32, ptr %l66, !tbaa !23
  %t43 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t43, ptr %l67
  br label %bb12
bb12:
  %t44 = load i1, ptr %l67, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb17
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  store ptr %t50, ptr %l71, !tbaa !29
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = load ptr, ptr @__olang_prog_scope
  %t55 = call i32 @compiler_2fcheck_2etypeOf(ptr %t53, ptr %t51)
  store i32 %t55, ptr %l74
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l71, !tbaa !29
  %t57 = load i32, ptr %l74, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t56, i32 %t57)
  store i32 %t58, ptr %l75
  br label %bb16
bb16:
  %t59 = load i32, ptr %l75, !range !{i32 0, i32 33}
  %t61 = trunc i64 21 to i32
  %t62 = icmp eq i32 %t59, %t61
  store i1 %t62, ptr %l68, !tbaa !21
  br label %bb17
bb17:
  %t64 = load i1, ptr %l68, !tbaa !21
  br i1 %t64, label %bb18, label %bb19
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l78, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l79
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = load ptr, ptr @__olang_prog_scope
  %t71 = call i32 @compiler_2fcheck_2etypeOf(ptr %t69, ptr %t67)
  store i32 %t71, ptr %l82
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t72 = load ptr, ptr %l78, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l79
  %t74 = load i32, ptr %l82, !tbaa !23
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v3, ptr %t72, %"compiler/source:Span" %t73, i32 %t74)
  store ptr %t75, ptr %l83
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l83, !tbaa !29
  store ptr %t76, ptr %l8, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l84, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t78, ptr %l85
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t79, ptr %l86, !tbaa !23
  %t80 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t82 = trunc i64 78 to i32
  %t83 = icmp eq i32 %t80, %t82
  br i1 %t83, label %bb22, label %bb23
bb22:
  store i32 19, ptr %l89
  br label %bb24
bb23:
  store i32 14, ptr %l89
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t88 = load ptr, ptr %l8, !tbaa !29
  %t90 = load ptr, ptr @__olang_prog_scope
  %t91 = load ptr, ptr %l84, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l85
  %t93 = load i32, ptr %l86, !tbaa !23
  %t94 = load i32, ptr %l89, !range !{i32 0, i32 46}
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t90, ptr %v3, ptr %v3, ptr %t91, %"compiler/source:Span" %t92, i32 %t93, i32 %t94, ptr %t87, ptr %t88)
  store ptr %t97, ptr %l95
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  %t98 = load ptr, ptr %l95, !tbaa !29
  store ptr %t98, ptr %rv
  br label %ret
bb26:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t99, %"compiler/source:Span" %t100, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb27
bb27:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l1
  %t105 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t109 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t103, %"compiler/source:Span" %t104, i32 %t105, i64 0)
  store ptr %t109, ptr %l101
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s1)
  %t110 = load ptr, ptr %l101, !tbaa !29
  store ptr %t110, ptr %rv
  br label %ret
bb29:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l5, !tbaa !23
  %t115 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l104
  br label %bb30
bb30:
  %t116 = load i32, ptr %l104, !tbaa !23
  store i32 %t116, ptr %l9, !tbaa !23
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l6, !tbaa !23
  %t121 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t117, i32 %t118)
  store i32 %t121, ptr %l107
  br label %bb31
bb31:
  %t122 = load i32, ptr %l107, !tbaa !23
  store i32 %t122, ptr %l10, !tbaa !23
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l9, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l112
  br label %bb32
bb32:
  %t133 = load i32, ptr %l112, !range !{i32 0, i32 33}
  %t135 = trunc i64 21 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb33, label %bb34
bb33:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l10, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l120
  br label %bb35
bb34:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb36
bb35:
  %t148 = load i32, ptr %l120, !range !{i32 0, i32 33}
  %t150 = trunc i64 21 to i32
  %t151 = icmp eq i32 %t148, %t150
  store i1 %t151, ptr %l115, !tbaa !21
  br label %bb36
bb36:
  %t153 = load i1, ptr %l115, !tbaa !21
  br i1 %t153, label %bb37, label %bb38
bb37:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l9, !tbaa !23
  %t163 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t159, i32 %t160)
  store i32 %t163, ptr %l128
  br label %bb39
bb38:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb41
bb39:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  %t170 = load i32, ptr %l10, !tbaa !23
  %t173 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t169, i32 %t170)
  store i32 %t173, ptr %l133
  br label %bb40
bb40:
  %t174 = load i32, ptr %l128, !tbaa !23
  %t175 = load i32, ptr %l133, !tbaa !23
  %t176 = icmp ne i32 %t174, %t175
  store i1 %t176, ptr %l123, !tbaa !21
  br label %bb41
bb41:
  %t178 = load i1, ptr %l123, !tbaa !21
  br i1 %t178, label %bb42, label %bb43
bb42:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l10, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l139
  br label %bb44
bb43:
  br label %bb60
bb44:
  %t189 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t190 = load i32, ptr %l139, !tbaa !23
  %t192 = icmp eq i32 %t190, %t189
  br i1 %t192, label %bb45, label %bb46
bb45:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l142, !tbaa !29
  %t195 = load ptr, ptr %l3, !tbaa !29
  store ptr %t195, ptr %l143, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 2
  %t202 = load i32, ptr %l9, !tbaa !23
  %t205 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUntagged(ptr %v0, ptr %t201, i32 %t202)
  store i32 %t205, ptr %l148
  br label %bb47
bb46:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 2
  %t212 = load i32, ptr %l9, !tbaa !23
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %t211, i32 %t212)
  store i32 %t215, ptr %l163
  br label %bb51
bb47:
  %t216 = load %"compiler/source:Span", ptr %l1
  %t217 = load ptr, ptr %l142, !tbaa !29
  %t218 = load ptr, ptr %l143, !tbaa !29
  %t219 = load i32, ptr %l148, !tbaa !23
  %t221 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v1, ptr %t217, ptr %t218, i32 %t219, %"compiler/source:Span" %t216)
  store ptr %t221, ptr %l150
  br label %bb48
bb48:
  %t222 = load ptr, ptr %l150, !tbaa !29
  store ptr %t222, ptr %l3, !tbaa !29
  %t223 = load ptr, ptr %l3, !tbaa !29
  %t226 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t223)
  store i32 %t226, ptr %l153
  br label %bb49
bb49:
  %t227 = load i32, ptr %l153, !tbaa !23
  store i32 %t227, ptr %l11, !tbaa !23
  %t228 = load ptr, ptr %l3, !tbaa !29
  %t231 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t228)
  store i32 %t231, ptr %l156
  br label %bb50
bb50:
  %t232 = load i32, ptr %l156, !tbaa !23
  %t233 = load i32, ptr %l11, !tbaa !23
  store i32 %t233, ptr %l5, !tbaa !23
  store i32 %t232, ptr %l9, !tbaa !23
  br label %bb59
bb51:
  %t237 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t238 = load i32, ptr %l163, !tbaa !23
  %t240 = icmp eq i32 %t238, %t237
  br i1 %t240, label %bb52, label %bb53
bb52:
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l166, !tbaa !29
  %t243 = load ptr, ptr %l4, !tbaa !29
  store ptr %t243, ptr %l167, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t249 = getelementptr %"compiler/generic:Program", ptr %t247, i32 0, i32 2
  %t250 = load i32, ptr %l10, !tbaa !23
  %t253 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUntagged(ptr %v0, ptr %t249, i32 %t250)
  store i32 %t253, ptr %l172
  br label %bb54
bb53:
  br label %bb58
bb54:
  %t254 = load %"compiler/source:Span", ptr %l1
  %t255 = load ptr, ptr %l166, !tbaa !29
  %t256 = load ptr, ptr %l167, !tbaa !29
  %t257 = load i32, ptr %l172, !tbaa !23
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t255, ptr %t256, i32 %t257, %"compiler/source:Span" %t254)
  store ptr %t259, ptr %l174
  br label %bb55
bb55:
  %t260 = load ptr, ptr %l174, !tbaa !29
  store ptr %t260, ptr %l4, !tbaa !29
  %t261 = load ptr, ptr %l4, !tbaa !29
  %t264 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t261)
  store i32 %t264, ptr %l177
  br label %bb56
bb56:
  %t265 = load i32, ptr %l177, !tbaa !23
  store i32 %t265, ptr %l13, !tbaa !23
  %t266 = load ptr, ptr %l4, !tbaa !29
  %t269 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t266)
  store i32 %t269, ptr %l180
  br label %bb57
bb57:
  %t270 = load i32, ptr %l180, !tbaa !23
  %t271 = load i32, ptr %l13, !tbaa !23
  store i32 %t271, ptr %l6, !tbaa !23
  store i32 %t270, ptr %l10, !tbaa !23
  br label %bb58
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t280 = getelementptr %"compiler/generic:Program", ptr %t278, i32 0, i32 2
  %t281 = load i32, ptr %l9, !tbaa !23
  %t284 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t280, i32 %t281)
  store i32 %t284, ptr %l187
  br label %bb61
bb61:
  %t285 = load i32, ptr %l187, !range !{i32 0, i32 33}
  %t287 = trunc i64 21 to i32
  %t288 = icmp eq i32 %t285, %t287
  br i1 %t288, label %bb62, label %bb63
bb62:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/check:Checker", ptr %t290, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t295 = getelementptr %"compiler/generic:Program", ptr %t293, i32 0, i32 2
  %t296 = load i32, ptr %l10, !tbaa !23
  %t299 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t295, i32 %t296)
  store i32 %t299, ptr %l195
  br label %bb64
bb63:
  store i1 false, ptr %l190, !tbaa !21
  br label %bb65
bb64:
  %t300 = load i32, ptr %l195, !range !{i32 0, i32 33}
  %t302 = trunc i64 21 to i32
  %t303 = icmp eq i32 %t300, %t302
  store i1 %t303, ptr %l190, !tbaa !21
  br label %bb65
bb65:
  %t305 = load i1, ptr %l190, !tbaa !21
  br i1 %t305, label %bb66, label %bb67
bb66:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/check:Checker", ptr %t306, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t311 = getelementptr %"compiler/generic:Program", ptr %t309, i32 0, i32 2
  %t312 = load i32, ptr %l9, !tbaa !23
  %t315 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t311, i32 %t312)
  store i1 %t315, ptr %l203
  br label %bb68
bb67:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb70
bb68:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/check:Checker", ptr %t316, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t321 = getelementptr %"compiler/generic:Program", ptr %t319, i32 0, i32 2
  %t322 = load i32, ptr %l10, !tbaa !23
  %t325 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t321, i32 %t322)
  store i1 %t325, ptr %l208
  br label %bb69
bb69:
  %t326 = load i1, ptr %l203, !tbaa !21
  %t327 = load i1, ptr %l208, !tbaa !21
  %t328 = icmp ne i1 %t326, %t327
  store i1 %t328, ptr %l198, !tbaa !21
  br label %bb70
bb70:
  %t330 = load i1, ptr %l198, !tbaa !21
  br i1 %t330, label %bb71, label %bb72
bb71:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/check:Checker", ptr %t331, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Program", ptr %t334, i32 0, i32 2
  %t337 = load i32, ptr %l10, !tbaa !23
  %t340 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t336, i32 %t337)
  store i1 %t340, ptr %l214
  br label %bb73
bb72:
  br label %bb85
bb73:
  %t341 = load i1, ptr %l214, !tbaa !21
  br i1 %t341, label %bb74, label %bb75
bb74:
  %t342 = load ptr, ptr %l0, !tbaa !29
  store ptr %t342, ptr %l215, !tbaa !29
  %t343 = load ptr, ptr %l3, !tbaa !29
  store ptr %t343, ptr %l216, !tbaa !29
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/check:Checker", ptr %t344, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !29
  %t349 = getelementptr %"compiler/generic:Program", ptr %t347, i32 0, i32 2
  %t350 = load i32, ptr %l9, !tbaa !23
  %t353 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t349, i32 %t350)
  store i32 %t353, ptr %l221
  br label %bb76
bb75:
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l232, !tbaa !29
  %t355 = load ptr, ptr %l4, !tbaa !29
  store ptr %t355, ptr %l233, !tbaa !29
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/check:Checker", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t361 = getelementptr %"compiler/generic:Program", ptr %t359, i32 0, i32 2
  %t362 = load i32, ptr %l10, !tbaa !23
  %t365 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t361, i32 %t362)
  store i32 %t365, ptr %l238
  br label %bb80
bb76:
  %t366 = load %"compiler/source:Span", ptr %l1
  %t367 = load ptr, ptr %l215, !tbaa !29
  %t368 = load ptr, ptr %l216, !tbaa !29
  %t369 = load i32, ptr %l221, !tbaa !23
  %t371 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v1, ptr %t367, ptr %t368, i32 %t369, %"compiler/source:Span" %t366)
  store ptr %t371, ptr %l223
  br label %bb77
bb77:
  %t372 = load ptr, ptr %l223, !tbaa !29
  store ptr %t372, ptr %l3, !tbaa !29
  %t373 = load ptr, ptr %l3, !tbaa !29
  %t376 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t373)
  store i32 %t376, ptr %l226
  br label %bb78
bb78:
  %t377 = load i32, ptr %l226, !tbaa !23
  store i32 %t377, ptr %l15, !tbaa !23
  %t378 = load ptr, ptr %l3, !tbaa !29
  %t381 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t378)
  store i32 %t381, ptr %l229
  br label %bb79
bb79:
  %t382 = load i32, ptr %l229, !tbaa !23
  %t383 = load i32, ptr %l15, !tbaa !23
  store i32 %t383, ptr %l5, !tbaa !23
  store i32 %t382, ptr %l9, !tbaa !23
  br label %bb84
bb80:
  %t387 = load %"compiler/source:Span", ptr %l1
  %t388 = load ptr, ptr %l232, !tbaa !29
  %t389 = load ptr, ptr %l233, !tbaa !29
  %t390 = load i32, ptr %l238, !tbaa !23
  %t392 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t388, ptr %t389, i32 %t390, %"compiler/source:Span" %t387)
  store ptr %t392, ptr %l240
  br label %bb81
bb81:
  %t393 = load ptr, ptr %l240, !tbaa !29
  store ptr %t393, ptr %l4, !tbaa !29
  %t394 = load ptr, ptr %l4, !tbaa !29
  %t397 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t394)
  store i32 %t397, ptr %l243
  br label %bb82
bb82:
  %t398 = load i32, ptr %l243, !tbaa !23
  store i32 %t398, ptr %l17, !tbaa !23
  %t399 = load ptr, ptr %l4, !tbaa !29
  %t402 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t399)
  store i32 %t402, ptr %l246
  br label %bb83
bb83:
  %t403 = load i32, ptr %l246, !tbaa !23
  %t404 = load i32, ptr %l17, !tbaa !23
  store i32 %t404, ptr %l6, !tbaa !23
  store i32 %t403, ptr %l10, !tbaa !23
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t413 = getelementptr %"compiler/generic:Program", ptr %t411, i32 0, i32 2
  %t414 = load i32, ptr %l9, !tbaa !23
  %t415 = load i32, ptr %l10, !tbaa !23
  %t419 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t413, i32 %t414, i32 %t415)
  store i1 %t419, ptr %l254
  br label %bb86
bb86:
  %t420 = load i1, ptr %l254, !tbaa !21
  %t421 = xor i1 %t420, true
  br i1 %t421, label %bb87, label %bb88
bb87:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load i32, ptr %l9, !tbaa !23
  %t425 = load i32, ptr %l10, !tbaa !23
  %t429 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t423, i32 %t424, i32 %t425)
  store i1 %t429, ptr %l259
  br label %bb89
bb88:
  br label %bb171
bb89:
  %t430 = load i1, ptr %l259, !tbaa !21
  br i1 %t430, label %bb90, label %bb91
bb90:
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l260, !tbaa !29
  %t432 = load ptr, ptr %l3, !tbaa !29
  store ptr %t432, ptr %l261, !tbaa !29
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load i32, ptr %l5, !tbaa !23
  %t437 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t433, i32 %t434)
  store i1 %t437, ptr %l264
  br label %bb92
bb91:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load i32, ptr %l10, !tbaa !23
  %t440 = load i32, ptr %l9, !tbaa !23
  %t444 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t438, i32 %t439, i32 %t440)
  store i1 %t444, ptr %l286
  br label %bb103
bb92:
  %t445 = load i1, ptr %l264, !tbaa !21
  br i1 %t445, label %bb93, label %bb94
bb93:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load i32, ptr %l6, !tbaa !23
  %t450 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t446, i32 %t447)
  store i1 %t450, ptr %l268
  br label %bb95
bb94:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb96
bb95:
  %t451 = load i1, ptr %l268, !tbaa !21
  store i1 %t451, ptr %l265, !tbaa !21
  br label %bb96
bb96:
  %t452 = load i1, ptr %l265, !tbaa !21
  br i1 %t452, label %bb97, label %bb98
bb97:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/check:Checker", ptr %t453, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t458 = getelementptr %"compiler/generic:Program", ptr %t456, i32 0, i32 2
  %t459 = load i32, ptr %l10, !tbaa !23
  %t460 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t464 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t458, i32 %t459, i64 %t460)
  store i32 %t464, ptr %l275
  br label %bb99
bb98:
  %t465 = load i32, ptr %l10, !tbaa !23
  store i32 %t465, ptr %l269, !tbaa !23
  br label %bb100
bb99:
  %t467 = load i32, ptr %l275, !tbaa !23
  store i32 %t467, ptr %l269, !tbaa !23
  br label %bb100
bb100:
  %t468 = load %"compiler/source:Span", ptr %l1
  %t469 = load ptr, ptr %l260, !tbaa !29
  %t470 = load ptr, ptr %l261, !tbaa !29
  %t471 = load i32, ptr %l269, !tbaa !23
  %t473 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v1, ptr %t469, ptr %t470, i32 %t471, %"compiler/source:Span" %t468)
  store ptr %t473, ptr %l278
  br label %bb101
bb101:
  %t474 = load ptr, ptr %l278, !tbaa !29
  store ptr %t474, ptr %l3, !tbaa !29
  %t475 = load ptr, ptr %l3, !tbaa !29
  %t478 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t475)
  store i32 %t478, ptr %l281
  br label %bb102
bb102:
  %t479 = load i32, ptr %l281, !tbaa !23
  store i32 %t479, ptr %l5, !tbaa !23
  %t480 = load i32, ptr %l10, !tbaa !23
  store i32 %t480, ptr %l9, !tbaa !23
  br label %bb170
bb103:
  %t482 = load i1, ptr %l286, !tbaa !21
  br i1 %t482, label %bb104, label %bb105
bb104:
  %t483 = load ptr, ptr %l0, !tbaa !29
  store ptr %t483, ptr %l287, !tbaa !29
  %t484 = load ptr, ptr %l4, !tbaa !29
  store ptr %t484, ptr %l288, !tbaa !29
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load i32, ptr %l5, !tbaa !23
  %t489 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t485, i32 %t486)
  store i1 %t489, ptr %l291
  br label %bb106
bb105:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/check:Checker", ptr %t490, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !29
  %t495 = getelementptr %"compiler/generic:Program", ptr %t493, i32 0, i32 2
  %t496 = load i32, ptr %l9, !tbaa !23
  %t499 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t495, i32 %t496)
  store i32 %t499, ptr %l314
  br label %bb117
bb106:
  %t500 = load i1, ptr %l291, !tbaa !21
  br i1 %t500, label %bb107, label %bb108
bb107:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load i32, ptr %l6, !tbaa !23
  %t505 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t501, i32 %t502)
  store i1 %t505, ptr %l295
  br label %bb109
bb108:
  store i1 false, ptr %l292, !tbaa !21
  br label %bb110
bb109:
  %t506 = load i1, ptr %l295, !tbaa !21
  store i1 %t506, ptr %l292, !tbaa !21
  br label %bb110
bb110:
  %t507 = load i1, ptr %l292, !tbaa !21
  br i1 %t507, label %bb111, label %bb112
bb111:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t510 = getelementptr %"compiler/check:Checker", ptr %t508, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !29
  %t513 = getelementptr %"compiler/generic:Program", ptr %t511, i32 0, i32 2
  %t514 = load i32, ptr %l9, !tbaa !23
  %t515 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t519 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t513, i32 %t514, i64 %t515)
  store i32 %t519, ptr %l302
  br label %bb113
bb112:
  %t520 = load i32, ptr %l9, !tbaa !23
  store i32 %t520, ptr %l296, !tbaa !23
  br label %bb114
bb113:
  %t522 = load i32, ptr %l302, !tbaa !23
  store i32 %t522, ptr %l296, !tbaa !23
  br label %bb114
bb114:
  %t523 = load %"compiler/source:Span", ptr %l1
  %t524 = load ptr, ptr %l287, !tbaa !29
  %t525 = load ptr, ptr %l288, !tbaa !29
  %t526 = load i32, ptr %l296, !tbaa !23
  %t528 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t524, ptr %t525, i32 %t526, %"compiler/source:Span" %t523)
  store ptr %t528, ptr %l305
  br label %bb115
bb115:
  %t529 = load ptr, ptr %l305, !tbaa !29
  store ptr %t529, ptr %l4, !tbaa !29
  %t530 = load ptr, ptr %l4, !tbaa !29
  %t533 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t530)
  store i32 %t533, ptr %l308
  br label %bb116
bb116:
  %t534 = load i32, ptr %l308, !tbaa !23
  store i32 %t534, ptr %l6, !tbaa !23
  %t535 = load i32, ptr %l9, !tbaa !23
  store i32 %t535, ptr %l10, !tbaa !23
  br label %bb169
bb117:
  %t537 = load i32, ptr %l314, !range !{i32 0, i32 33}
  %t539 = trunc i64 19 to i32
  %t540 = icmp eq i32 %t537, %t539
  br i1 %t540, label %bb118, label %bb119
bb118:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t544 = getelementptr %"compiler/check:Checker", ptr %t542, i32 0, i32 1
  %t545 = load ptr, ptr %t544, !tbaa !29
  %t547 = getelementptr %"compiler/generic:Program", ptr %t545, i32 0, i32 2
  %t548 = load i32, ptr %l10, !tbaa !23
  %t551 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t547, i32 %t548)
  store i32 %t551, ptr %l322
  br label %bb120
bb119:
  store i1 false, ptr %l317, !tbaa !21
  br label %bb121
bb120:
  %t552 = load i32, ptr %l322, !range !{i32 0, i32 33}
  %t554 = trunc i64 19 to i32
  %t555 = icmp eq i32 %t552, %t554
  store i1 %t555, ptr %l317, !tbaa !21
  br label %bb121
bb121:
  %t557 = load i1, ptr %l317, !tbaa !21
  br i1 %t557, label %bb122, label %bb123
bb122:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t560 = getelementptr %"compiler/check:Checker", ptr %t558, i32 0, i32 1
  %t561 = load ptr, ptr %t560, !tbaa !29
  %t563 = getelementptr %"compiler/generic:Program", ptr %t561, i32 0, i32 2
  store ptr %t563, ptr %l328, !tbaa !29
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t566 = getelementptr %"compiler/check:Checker", ptr %t564, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !29
  %t569 = getelementptr %"compiler/generic:Program", ptr %t567, i32 0, i32 2
  %t570 = load i32, ptr %l9, !tbaa !23
  %t573 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t569, i32 %t570)
  store i32 %t573, ptr %l333
  br label %bb124
bb123:
  store i1 false, ptr %l325, !tbaa !21
  br label %bb127
bb124:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/check:Checker", ptr %t574, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !29
  %t579 = getelementptr %"compiler/generic:Program", ptr %t577, i32 0, i32 2
  %t580 = load i32, ptr %l10, !tbaa !23
  %t583 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t579, i32 %t580)
  store i32 %t583, ptr %l338
  br label %bb125
bb125:
  %t584 = load ptr, ptr %l328, !tbaa !29
  %t585 = load i32, ptr %l333, !tbaa !23
  %t586 = load i32, ptr %l338, !tbaa !23
  %t587 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t584, i32 %t585, i32 %t586)
  store i1 %t587, ptr %l339
  br label %bb126
bb126:
  %t588 = load i1, ptr %l339, !tbaa !21
  store i1 %t588, ptr %l325, !tbaa !21
  br label %bb127
bb127:
  %t589 = load i1, ptr %l325, !tbaa !21
  br i1 %t589, label %bb128, label %bb129
bb128:
  store i1 true, ptr %l340, !tbaa !21
  br label %bb131
bb129:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load i32, ptr %l9, !tbaa !23
  %t592 = load ptr, ptr %l4, !tbaa !29
  %t593 = load i32, ptr %l10, !tbaa !23
  %t598 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextBeside(ptr %v0, ptr %v2, ptr %t590, i32 %t591, ptr %t592, i32 %t593)
  store i1 %t598, ptr %l345
  br label %bb130
bb130:
  %t599 = load i1, ptr %l345, !tbaa !21
  store i1 %t599, ptr %l340, !tbaa !21
  br label %bb131
bb131:
  %t600 = load i1, ptr %l340, !tbaa !21
  br i1 %t600, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l346, !tbaa !21
  br label %bb135
bb133:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t602 = load i32, ptr %l10, !tbaa !23
  %t603 = load ptr, ptr %l3, !tbaa !29
  %t604 = load i32, ptr %l9, !tbaa !23
  %t609 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextBeside(ptr %v0, ptr %v1, ptr %t601, i32 %t602, ptr %t603, i32 %t604)
  store i1 %t609, ptr %l351
  br label %bb134
bb134:
  %t610 = load i1, ptr %l351, !tbaa !21
  store i1 %t610, ptr %l346, !tbaa !21
  br label %bb135
bb135:
  %t611 = load i1, ptr %l346, !tbaa !21
  br i1 %t611, label %bb136, label %bb137
bb136:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t614 = getelementptr %"compiler/check:Checker", ptr %t612, i32 0, i32 1
  %t615 = load ptr, ptr %t614, !tbaa !29
  %t617 = getelementptr %"compiler/generic:Program", ptr %t615, i32 0, i32 2
  store ptr %t617, ptr %l354, !tbaa !29
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/check:Checker", ptr %t618, i32 0, i32 1
  %t621 = load ptr, ptr %t620, !tbaa !29
  %t623 = getelementptr %"compiler/generic:Program", ptr %t621, i32 0, i32 2
  store ptr %t623, ptr %l357, !tbaa !29
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t625 = load i32, ptr %l9, !tbaa !23
  %t628 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t624, i32 %t625)
  store i32 %t628, ptr %l360
  br label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s16
  %t629 = load ptr, ptr %l0, !tbaa !29
  store ptr %t629, ptr %l413, !tbaa !29
  %t630 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t630, ptr %l414
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t632 = load i32, ptr %l9, !tbaa !23
  %t635 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t631, i32 %t632)
  store { i64, ptr } %t635, ptr %l417
  br label %bb163
bb138:
  %t636 = load ptr, ptr %l357, !tbaa !29
  %t637 = load i32, ptr %l360, !tbaa !23
  %t638 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t636, i32 %t637)
  store i32 %t638, ptr %l361
  br label %bb139
bb139:
  %t639 = load ptr, ptr %l354, !tbaa !29
  %t640 = load i32, ptr %l361, !tbaa !23
  %t641 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t639, i32 %t640, i32 0)
  store i32 %t641, ptr %l362
  br label %bb140
bb140:
  %t642 = load i32, ptr %l362, !tbaa !23
  store i32 %t642, ptr %l19, !tbaa !23
  %t643 = load ptr, ptr %l0, !tbaa !29
  store ptr %t643, ptr %l363, !tbaa !29
  %t644 = load ptr, ptr %l3, !tbaa !29
  store ptr %t644, ptr %l364, !tbaa !29
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t646 = load i32, ptr %l5, !tbaa !23
  %t649 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t645, i32 %t646)
  store i1 %t649, ptr %l367
  br label %bb141
bb141:
  %t650 = load i1, ptr %l367, !tbaa !21
  br i1 %t650, label %bb142, label %bb143
bb142:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t652 = load i32, ptr %l6, !tbaa !23
  %t655 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t651, i32 %t652)
  store i1 %t655, ptr %l371
  br label %bb144
bb143:
  store i1 false, ptr %l368, !tbaa !21
  br label %bb145
bb144:
  %t656 = load i1, ptr %l371, !tbaa !21
  store i1 %t656, ptr %l368, !tbaa !21
  br label %bb145
bb145:
  %t657 = load i1, ptr %l368, !tbaa !21
  br i1 %t657, label %bb146, label %bb147
bb146:
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t660 = getelementptr %"compiler/check:Checker", ptr %t658, i32 0, i32 1
  %t661 = load ptr, ptr %t660, !tbaa !29
  %t663 = getelementptr %"compiler/generic:Program", ptr %t661, i32 0, i32 2
  %t664 = load i32, ptr %l19, !tbaa !23
  %t665 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t669 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t663, i32 %t664, i64 %t665)
  store i32 %t669, ptr %l378
  br label %bb148
bb147:
  %t670 = load i32, ptr %l19, !tbaa !23
  store i32 %t670, ptr %l372, !tbaa !23
  br label %bb149
bb148:
  %t672 = load i32, ptr %l378, !tbaa !23
  store i32 %t672, ptr %l372, !tbaa !23
  br label %bb149
bb149:
  %t673 = load %"compiler/source:Span", ptr %l1
  %t674 = load ptr, ptr %l363, !tbaa !29
  %t675 = load ptr, ptr %l364, !tbaa !29
  %t676 = load i32, ptr %l372, !tbaa !23
  %t678 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v1, ptr %t674, ptr %t675, i32 %t676, %"compiler/source:Span" %t673)
  store ptr %t678, ptr %l381
  br label %bb150
bb150:
  %t679 = load ptr, ptr %l381, !tbaa !29
  store ptr %t679, ptr %l3, !tbaa !29
  %t680 = load ptr, ptr %l0, !tbaa !29
  store ptr %t680, ptr %l382, !tbaa !29
  %t681 = load ptr, ptr %l4, !tbaa !29
  store ptr %t681, ptr %l383, !tbaa !29
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t683 = load i32, ptr %l5, !tbaa !23
  %t686 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t682, i32 %t683)
  store i1 %t686, ptr %l386
  br label %bb151
bb151:
  %t687 = load i1, ptr %l386, !tbaa !21
  br i1 %t687, label %bb152, label %bb153
bb152:
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t689 = load i32, ptr %l6, !tbaa !23
  %t692 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t688, i32 %t689)
  store i1 %t692, ptr %l390
  br label %bb154
bb153:
  store i1 false, ptr %l387, !tbaa !21
  br label %bb155
bb154:
  %t693 = load i1, ptr %l390, !tbaa !21
  store i1 %t693, ptr %l387, !tbaa !21
  br label %bb155
bb155:
  %t694 = load i1, ptr %l387, !tbaa !21
  br i1 %t694, label %bb156, label %bb157
bb156:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t697 = getelementptr %"compiler/check:Checker", ptr %t695, i32 0, i32 1
  %t698 = load ptr, ptr %t697, !tbaa !29
  %t700 = getelementptr %"compiler/generic:Program", ptr %t698, i32 0, i32 2
  %t701 = load i32, ptr %l19, !tbaa !23
  %t702 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t706 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t700, i32 %t701, i64 %t702)
  store i32 %t706, ptr %l397
  br label %bb158
bb157:
  %t707 = load i32, ptr %l19, !tbaa !23
  store i32 %t707, ptr %l391, !tbaa !23
  br label %bb159
bb158:
  %t709 = load i32, ptr %l397, !tbaa !23
  store i32 %t709, ptr %l391, !tbaa !23
  br label %bb159
bb159:
  %t710 = load %"compiler/source:Span", ptr %l1
  %t711 = load ptr, ptr %l382, !tbaa !29
  %t712 = load ptr, ptr %l383, !tbaa !29
  %t713 = load i32, ptr %l391, !tbaa !23
  %t715 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v2, ptr %t711, ptr %t712, i32 %t713, %"compiler/source:Span" %t710)
  store ptr %t715, ptr %l400
  br label %bb160
bb160:
  %t716 = load ptr, ptr %l400, !tbaa !29
  store ptr %t716, ptr %l4, !tbaa !29
  %t717 = load ptr, ptr %l3, !tbaa !29
  %t720 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t717)
  store i32 %t720, ptr %l403
  br label %bb161
bb161:
  %t721 = load i32, ptr %l403, !tbaa !23
  store i32 %t721, ptr %l20, !tbaa !23
  %t722 = load ptr, ptr %l4, !tbaa !29
  %t725 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t722)
  store i32 %t725, ptr %l406
  br label %bb162
bb162:
  %t726 = load i32, ptr %l406, !tbaa !23
  %t727 = load i32, ptr %l20, !tbaa !23
  store i32 %t727, ptr %l5, !tbaa !23
  store i32 %t726, ptr %l6, !tbaa !23
  %t731 = load i32, ptr %l19, !tbaa !23
  %t733 = load i32, ptr %l19, !tbaa !23
  store i32 %t731, ptr %l9, !tbaa !23
  store i32 %t733, ptr %l10, !tbaa !23
  br label %bb168
bb163:
  %t739 = load { i64, ptr }, ptr %l417, !tbaa !27
  %t740 = extractvalue { i64, ptr } %t739, 0
  %t741 = extractvalue { i64, ptr } %t739, 1
  %t742 = mul i64 %t740, 1
  %t743 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t742)
  call void @llvm.memcpy.p0.p0.i64(ptr %t743, ptr %t741, i64 %t742, i1 false)
  %t744 = insertvalue { i64, ptr } undef, i64 %t740, 0
  %t745 = insertvalue { i64, ptr } %t744, ptr %t743, 1
  store { i64, ptr } %t745, ptr %l418, !tbaa !27
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t747 = load i32, ptr %l10, !tbaa !23
  %t750 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t746, i32 %t747)
  store { i64, ptr } %t750, ptr %l421
  br label %bb164
bb164:
  %t751 = load { i64, ptr }, ptr %l421, !tbaa !27
  %t752 = extractvalue { i64, ptr } %t751, 0
  %t753 = extractvalue { i64, ptr } %t751, 1
  %t754 = mul i64 %t752, 1
  %t755 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t754)
  call void @llvm.memcpy.p0.p0.i64(ptr %t755, ptr %t753, i64 %t754, i1 false)
  %t756 = insertvalue { i64, ptr } undef, i64 %t752, 0
  %t757 = insertvalue { i64, ptr } %t756, ptr %t755, 1
  %t758 = load { i64, ptr }, ptr %l418, !tbaa !27
  %t760 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s16, ptr %s16, ptr %s16, { i64, ptr } %t758, { i64, ptr } %t757)
  store %"compiler/diagmsg:Msg" %t760, ptr %l423
  br label %bb165
bb165:
  %t761 = load ptr, ptr %l413, !tbaa !29
  %t762 = load %"compiler/source:Span", ptr %l414
  %t763 = load %"compiler/diagmsg:Msg", ptr %l423
  %t764 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t761, %"compiler/source:Span" %t762, %"compiler/diagmsg:Msg" %t763)
  store i64 %t764, ptr %l424
  br label %bb166
bb166:
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t766 = load %"compiler/source:Span", ptr %l1
  %t767 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t771 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t765, %"compiler/source:Span" %t766, i32 %t767, i64 0)
  store ptr %t771, ptr %l428
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s16)
  %t772 = load ptr, ptr %l428, !tbaa !29
  store ptr %t772, ptr %rv
  br label %ret
bb168:
  br label %bb169
bb169:
  br label %bb170
bb170:
  br label %bb171
bb171:
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t774 = load i32, ptr %l9, !tbaa !23
  %t777 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %t773, i32 %t774)
  store i64 %t777, ptr %l431
  br label %bb172
bb172:
  %t778 = load i64, ptr %l431, !tbaa !24
  store i64 %t778, ptr %l24, !tbaa !24
  %t779 = load i64, ptr %l24, !tbaa !24
  %t781 = icmp eq i64 %t779, -2
  br i1 %t781, label %bb173, label %bb174
bb173:
  store %olang.scope zeroinitializer, ptr %s17
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t785 = getelementptr %"compiler/check:Checker", ptr %t783, i32 0, i32 1
  %t786 = load ptr, ptr %t785, !tbaa !29
  %t788 = getelementptr %"compiler/generic:Program", ptr %t786, i32 0, i32 0
  %t789 = load ptr, ptr %t788, !tbaa !29
  %t791 = getelementptr %"compiler/load:Loader", ptr %t789, i32 0, i32 4
  %t792 = load ptr, ptr %t791, !tbaa !29
  store ptr %t792, ptr %l437, !tbaa !29
  %t793 = load ptr, ptr %l0, !tbaa !29
  store ptr %t793, ptr %l438, !tbaa !29
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t796 = getelementptr %"compiler/check:Checker", ptr %t794, i32 0, i32 45
  %t797 = getelementptr %"compiler/source:Span", ptr %t796, i32 0, i32 0
  %t798 = load i32, ptr %t797, !tbaa !23
  %t800 = icmp sge i32 %t798, 0
  br i1 %t800, label %bb175, label %bb176
bb174:
  br label %bb183
bb175:
  %t802 = load ptr, ptr %l0, !tbaa !29
  %t804 = getelementptr %"compiler/check:Checker", ptr %t802, i32 0, i32 45
  %t805 = load %"compiler/source:Span", ptr %t804
  store %"compiler/source:Span" %t805, ptr %l442
  br label %bb177
bb176:
  %t807 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t807, ptr %l442
  br label %bb177
bb177:
  %t809 = load ptr, ptr %l438, !tbaa !29
  %t810 = load %"compiler/source:Span", ptr %l442
  %t811 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t809, %"compiler/source:Span" %t810)
  store { i64, [3 x i64] } %t811, ptr %l446
  br label %bb178
bb178:
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t813 = load i32, ptr %l9, !tbaa !23
  %t816 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s17, ptr %t812, i32 %t813)
  store { i64, ptr } %t816, ptr %l449
  br label %bb179
bb179:
  %t817 = load { i64, ptr }, ptr %l449, !tbaa !27
  %t818 = extractvalue { i64, ptr } %t817, 0
  %t819 = extractvalue { i64, ptr } %t817, 1
  %t820 = mul i64 %t818, 1
  %t821 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t820)
  call void @llvm.memcpy.p0.p0.i64(ptr %t821, ptr %t819, i64 %t820, i1 false)
  %t822 = insertvalue { i64, ptr } undef, i64 %t818, 0
  %t823 = insertvalue { i64, ptr } %t822, ptr %t821, 1
  %t825 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %s17, ptr %s17, ptr %s17, ptr %s17, ptr %s17, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, { i64, ptr } %t823, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t825, ptr %l451
  br label %bb180
bb180:
  %t826 = load ptr, ptr %l437, !tbaa !29
  %t827 = load { i64, [3 x i64] }, ptr %l446
  %t828 = load %"compiler/diagmsg:Msg", ptr %l451
  %t829 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %s17, ptr %t826, { i64, [3 x i64] } %t827, %"compiler/diagmsg:Msg" %t828)
  store i64 %t829, ptr %l452
  br label %bb181
bb181:
  %t830 = load ptr, ptr %l0, !tbaa !29
  %t831 = load %"compiler/source:Span", ptr %l1
  %t832 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t836 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t830, %"compiler/source:Span" %t831, i32 %t832, i64 0)
  store ptr %t836, ptr %l456
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s17)
  %t837 = load ptr, ptr %l456, !tbaa !29
  store ptr %t837, ptr %rv
  br label %ret
bb183:
  %t838 = load i64, ptr %l24, !tbaa !24
  %t840 = icmp sge i64 %t838, 0
  br i1 %t840, label %bb184, label %bb185
bb184:
  %t842 = load ptr, ptr %l0, !tbaa !29
  %t843 = load i32, ptr %l5, !tbaa !23
  %t846 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t842, i32 %t843)
  store i1 %t846, ptr %l462
  br label %bb186
bb185:
  store i1 false, ptr %l459, !tbaa !21
  br label %bb187
bb186:
  %t847 = load i1, ptr %l462, !tbaa !21
  store i1 %t847, ptr %l459, !tbaa !21
  br label %bb187
bb187:
  %t848 = load i1, ptr %l459, !tbaa !21
  br i1 %t848, label %bb188, label %bb189
bb188:
  %t849 = load ptr, ptr %l0, !tbaa !29
  %t850 = load i32, ptr %l6, !tbaa !23
  %t853 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t849, i32 %t850)
  store i1 %t853, ptr %l466
  br label %bb190
bb189:
  store i1 false, ptr %l463, !tbaa !21
  br label %bb191
bb190:
  %t854 = load i1, ptr %l466, !tbaa !21
  store i1 %t854, ptr %l463, !tbaa !21
  br label %bb191
bb191:
  %t855 = load i1, ptr %l463, !tbaa !21
  br i1 %t855, label %bb192, label %bb193
bb192:
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t858 = getelementptr %"compiler/check:Checker", ptr %t856, i32 0, i32 1
  %t859 = load ptr, ptr %t858, !tbaa !29
  %t861 = getelementptr %"compiler/generic:Program", ptr %t859, i32 0, i32 2
  %t862 = load i32, ptr %l5, !tbaa !23
  %t865 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t861, i32 %t862)
  store i1 %t865, ptr %l472
  br label %bb194
bb193:
  store i1 false, ptr %l467, !tbaa !21
  br label %bb199
bb194:
  %t866 = load i1, ptr %l472, !tbaa !21
  br i1 %t866, label %bb195, label %bb196
bb195:
  store i1 true, ptr %l473, !tbaa !21
  br label %bb198
bb196:
  %t867 = load ptr, ptr %l0, !tbaa !29
  %t869 = getelementptr %"compiler/check:Checker", ptr %t867, i32 0, i32 1
  %t870 = load ptr, ptr %t869, !tbaa !29
  %t872 = getelementptr %"compiler/generic:Program", ptr %t870, i32 0, i32 2
  %t873 = load i32, ptr %l6, !tbaa !23
  %t876 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t872, i32 %t873)
  store i1 %t876, ptr %l478
  br label %bb197
bb197:
  %t877 = load i1, ptr %l478, !tbaa !21
  store i1 %t877, ptr %l473, !tbaa !21
  br label %bb198
bb198:
  %t878 = load i1, ptr %l473, !tbaa !21
  store i1 %t878, ptr %l467, !tbaa !21
  br label %bb199
bb199:
  %t879 = load i1, ptr %l467, !tbaa !21
  br i1 %t879, label %bb200, label %bb201
bb200:
  %t880 = load ptr, ptr %l0, !tbaa !29
  %t882 = getelementptr %"compiler/check:Checker", ptr %t880, i32 0, i32 37
  %t884 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t882)
  store i64 %t884, ptr %l481
  br label %bb202
bb201:
  br label %bb239
bb202:
  %t885 = load i64, ptr %l481, !tbaa !24
  store i64 %t885, ptr %l25, !tbaa !24
  %t886 = load ptr, ptr %l0, !tbaa !29
  %t887 = load %"compiler/source:Span", ptr %l1
  %t888 = load i32, ptr %l5, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t889
  %t890 = getelementptr { i64, [1 x i64] }, ptr %t889, i32 0, i32 0
  store i64 4, ptr %t890
  %t891 = load { i64, [1 x i64] }, ptr %t889
  %t897 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t886, i32 0, %"compiler/source:Span" %t887, i32 %t888, i32 1, { i64, [1 x i64] } %t891)
  store i64 %t897, ptr %l487
  br label %bb203
bb203:
  %t898 = load i64, ptr %l487, !tbaa !24
  store i64 %t898, ptr %l26, !tbaa !24
  %t899 = load ptr, ptr %l0, !tbaa !29
  %t901 = getelementptr %"compiler/check:Checker", ptr %t899, i32 0, i32 37
  %t902 = load %"compiler/source:Span", ptr %l1
  %t903 = load i64, ptr %l26, !tbaa !24
  %t905 = trunc i64 %t903 to i32
  %t907 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t908
  %t909 = getelementptr { i64, [3 x i64] }, ptr %t908, i32 0, i32 0
  store i64 0, ptr %t909
  %t911 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t902, 0
  %t913 = insertvalue { %"compiler/source:Span", i32, ptr } %t911, i32 %t905, 1
  %t915 = insertvalue { %"compiler/source:Span", i32, ptr } %t913, ptr %t907, 2
  %t916 = getelementptr { i64, [3 x i64] }, ptr %t908, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t915, ptr %t916
  %t917 = load { i64, [3 x i64] }, ptr %t908
  %t919 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t917, ptr %t919
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t901, ptr %t919)
  br label %bb204
bb204:
  %t922 = load ptr, ptr %l0, !tbaa !29
  %t923 = load %"compiler/source:Span", ptr %l1
  %t924 = load i32, ptr %l6, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t925
  %t926 = getelementptr { i64, [1 x i64] }, ptr %t925, i32 0, i32 0
  store i64 4, ptr %t926
  %t927 = load { i64, [1 x i64] }, ptr %t925
  %t933 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t922, i32 0, %"compiler/source:Span" %t923, i32 %t924, i32 1, { i64, [1 x i64] } %t927)
  store i64 %t933, ptr %l502
  br label %bb205
bb205:
  %t934 = load i64, ptr %l502, !tbaa !24
  store i64 %t934, ptr %l27, !tbaa !24
  %t935 = load ptr, ptr %l0, !tbaa !29
  %t937 = getelementptr %"compiler/check:Checker", ptr %t935, i32 0, i32 37
  %t938 = load %"compiler/source:Span", ptr %l1
  %t939 = load i64, ptr %l27, !tbaa !24
  %t941 = trunc i64 %t939 to i32
  %t943 = load ptr, ptr %l4, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t944
  %t945 = getelementptr { i64, [3 x i64] }, ptr %t944, i32 0, i32 0
  store i64 0, ptr %t945
  %t947 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t938, 0
  %t949 = insertvalue { %"compiler/source:Span", i32, ptr } %t947, i32 %t941, 1
  %t951 = insertvalue { %"compiler/source:Span", i32, ptr } %t949, ptr %t943, 2
  %t952 = getelementptr { i64, [3 x i64] }, ptr %t944, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t951, ptr %t952
  %t953 = load { i64, [3 x i64] }, ptr %t944
  %t955 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t953, ptr %t955
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t937, ptr %t955)
  br label %bb206
bb206:
  %t958 = load ptr, ptr %l0, !tbaa !29
  store ptr %t958, ptr %l512, !tbaa !29
  %t959 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t959, ptr %l513
  %t960 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t960, ptr %l514, !tbaa !23
  store i32 19, ptr %l515
  %t961 = load ptr, ptr %l0, !tbaa !29
  %t962 = load %"compiler/source:Span", ptr %l1
  %t963 = load i64, ptr %l26, !tbaa !24
  %t967 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t961, %"compiler/source:Span" %t962, i64 %t963)
  store ptr %t967, ptr %l519
  br label %bb207
bb207:
  %t968 = load ptr, ptr %l0, !tbaa !29
  %t969 = load %"compiler/source:Span", ptr %l1
  %t970 = load i32, ptr %l5, !tbaa !23
  %t974 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v0, ptr %t968, %"compiler/source:Span" %t969, i32 %t970)
  store ptr %t974, ptr %l523
  br label %bb208
bb208:
  %t975 = load ptr, ptr %l523, !tbaa !29
  %t976 = load ptr, ptr %l512, !tbaa !29
  %t977 = load %"compiler/source:Span", ptr %l513
  %t978 = load i32, ptr %l514, !tbaa !23
  %t979 = load i32, ptr %l515, !range !{i32 0, i32 46}
  %t980 = load ptr, ptr %l519, !tbaa !29
  %t982 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %t976, %"compiler/source:Span" %t977, i32 %t978, i32 %t979, ptr %t980, ptr %t975)
  store ptr %t982, ptr %l525
  br label %bb209
bb209:
  %t983 = load ptr, ptr %l525, !tbaa !29
  store ptr %t983, ptr %l28, !tbaa !29
  %t984 = load ptr, ptr %l0, !tbaa !29
  store ptr %t984, ptr %l526, !tbaa !29
  %t985 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t985, ptr %l527
  %t986 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t986, ptr %l528, !tbaa !23
  store i32 19, ptr %l529
  %t987 = load ptr, ptr %l0, !tbaa !29
  %t988 = load %"compiler/source:Span", ptr %l1
  %t989 = load i64, ptr %l27, !tbaa !24
  %t993 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t987, %"compiler/source:Span" %t988, i64 %t989)
  store ptr %t993, ptr %l533
  br label %bb210
bb210:
  %t994 = load ptr, ptr %l0, !tbaa !29
  %t995 = load %"compiler/source:Span", ptr %l1
  %t996 = load i32, ptr %l6, !tbaa !23
  %t1000 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v0, ptr %t994, %"compiler/source:Span" %t995, i32 %t996)
  store ptr %t1000, ptr %l537
  br label %bb211
bb211:
  %t1001 = load ptr, ptr %l537, !tbaa !29
  %t1002 = load ptr, ptr %l526, !tbaa !29
  %t1003 = load %"compiler/source:Span", ptr %l527
  %t1004 = load i32, ptr %l528, !tbaa !23
  %t1005 = load i32, ptr %l529, !range !{i32 0, i32 46}
  %t1006 = load ptr, ptr %l533, !tbaa !29
  %t1008 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %t1002, %"compiler/source:Span" %t1003, i32 %t1004, i32 %t1005, ptr %t1006, ptr %t1001)
  store ptr %t1008, ptr %l539
  br label %bb212
bb212:
  %t1009 = load ptr, ptr %l539, !tbaa !29
  store ptr %t1009, ptr %l29, !tbaa !29
  %t1010 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1010, ptr %l540, !tbaa !29
  %t1011 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1011, ptr %l541
  %t1012 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1012, ptr %l542, !tbaa !23
  store i32 19, ptr %l543
  %t1013 = load ptr, ptr %l0, !tbaa !29
  %t1014 = load %"compiler/source:Span", ptr %l1
  %t1015 = load i64, ptr %l27, !tbaa !24
  %t1019 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1013, %"compiler/source:Span" %t1014, i64 %t1015)
  store ptr %t1019, ptr %l547
  br label %bb213
bb213:
  %t1020 = load ptr, ptr %l0, !tbaa !29
  %t1021 = load %"compiler/source:Span", ptr %l1
  %t1022 = load i32, ptr %l6, !tbaa !23
  %t1026 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v0, ptr %t1020, %"compiler/source:Span" %t1021, i32 %t1022)
  store ptr %t1026, ptr %l551
  br label %bb214
bb214:
  %t1027 = load ptr, ptr %l551, !tbaa !29
  %t1028 = load ptr, ptr %l540, !tbaa !29
  %t1029 = load %"compiler/source:Span", ptr %l541
  %t1030 = load i32, ptr %l542, !tbaa !23
  %t1031 = load i32, ptr %l543, !range !{i32 0, i32 46}
  %t1032 = load ptr, ptr %l547, !tbaa !29
  %t1034 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %t1028, %"compiler/source:Span" %t1029, i32 %t1030, i32 %t1031, ptr %t1032, ptr %t1027)
  store ptr %t1034, ptr %l553
  br label %bb215
bb215:
  %t1035 = load ptr, ptr %l553, !tbaa !29
  store ptr %t1035, ptr %l30, !tbaa !29
  %t1036 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1036, ptr %l554, !tbaa !29
  %t1037 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1037, ptr %l555
  %t1038 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1038, ptr %l556
  %t1039 = load ptr, ptr %l0, !tbaa !29
  %t1041 = getelementptr %"compiler/check:Checker", ptr %t1039, i32 0, i32 1
  %t1042 = load ptr, ptr %t1041, !tbaa !29
  %t1044 = getelementptr %"compiler/generic:Program", ptr %t1042, i32 0, i32 2
  %t1045 = load i32, ptr %l5, !tbaa !23
  %t1048 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t1044, i32 %t1045)
  store i32 %t1048, ptr %l561
  br label %bb216
bb216:
  %t1049 = load i64, ptr %l26, !tbaa !24
  %t1051 = trunc i64 %t1049 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t1053
  %t1054 = getelementptr { i64, [4 x i64] }, ptr %t1053, i32 0, i32 0
  store i64 0, ptr %t1054
  %t1055 = load %"compiler/source:Span", ptr %l556
  %t1056 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t1055, 0
  %t1057 = load i32, ptr %l561, !tbaa !23
  %t1058 = insertvalue { %"compiler/source:Span", i32, i32 } %t1056, i32 %t1057, 1
  %t1060 = insertvalue { %"compiler/source:Span", i32, i32 } %t1058, i32 %t1051, 2
  %t1061 = getelementptr { i64, [4 x i64] }, ptr %t1053, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t1060, ptr %t1061
  %t1062 = load { i64, [4 x i64] }, ptr %t1053
  %t1064 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t1062, ptr %t1064
  %t1065 = load ptr, ptr %l554, !tbaa !29
  %t1066 = load %"compiler/source:Span", ptr %l555
  %t1068 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t1065, %"compiler/source:Span" %t1066, ptr %t1064)
  store ptr %t1068, ptr %l567
  br label %bb217
bb217:
  %t1069 = load ptr, ptr %l567, !tbaa !29
  store ptr %t1069, ptr %l31, !tbaa !29
  %t1070 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1070, ptr %l568, !tbaa !29
  %t1071 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1071, ptr %l569
  %t1072 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1072, ptr %l570
  %t1073 = load ptr, ptr %l0, !tbaa !29
  %t1075 = getelementptr %"compiler/check:Checker", ptr %t1073, i32 0, i32 1
  %t1076 = load ptr, ptr %t1075, !tbaa !29
  %t1078 = getelementptr %"compiler/generic:Program", ptr %t1076, i32 0, i32 2
  %t1079 = load i32, ptr %l6, !tbaa !23
  %t1082 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t1078, i32 %t1079)
  store i32 %t1082, ptr %l575
  br label %bb218
bb218:
  %t1083 = load i64, ptr %l27, !tbaa !24
  %t1085 = trunc i64 %t1083 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t1087
  %t1088 = getelementptr { i64, [4 x i64] }, ptr %t1087, i32 0, i32 0
  store i64 0, ptr %t1088
  %t1089 = load %"compiler/source:Span", ptr %l570
  %t1090 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t1089, 0
  %t1091 = load i32, ptr %l575, !tbaa !23
  %t1092 = insertvalue { %"compiler/source:Span", i32, i32 } %t1090, i32 %t1091, 1
  %t1094 = insertvalue { %"compiler/source:Span", i32, i32 } %t1092, i32 %t1085, 2
  %t1095 = getelementptr { i64, [4 x i64] }, ptr %t1087, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t1094, ptr %t1095
  %t1096 = load { i64, [4 x i64] }, ptr %t1087
  %t1098 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t1096, ptr %t1098
  %t1099 = load ptr, ptr %l568, !tbaa !29
  %t1100 = load %"compiler/source:Span", ptr %l569
  %t1102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t1099, %"compiler/source:Span" %t1100, ptr %t1098)
  store ptr %t1102, ptr %l581
  br label %bb219
bb219:
  %t1103 = load ptr, ptr %l581, !tbaa !29
  store ptr %t1103, ptr %l32, !tbaa !29
  %t1104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1104, ptr %l582, !tbaa !29
  %t1105 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1105, ptr %l583
  %t1106 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1106, ptr %l584
  %t1107 = load i64, ptr %l24, !tbaa !24
  store i64 %t1107, ptr %l585, !tbaa !24
  %t1108 = load ptr, ptr %l31, !tbaa !29
  store ptr %t1108, ptr %l587, !tbaa !29
  %t1110 = icmp sge i64 0, 0
  br i1 %t1110, label %bb220, label %bb221
bb220:
  %t1112 = icmp sle i64 0, 1152921504606846975
  br i1 %t1112, label %bb222, label %bb223
bb221:
  call void @__olang_check_failed(ptr @olang_loc_1c2cb6c96b4eaee8_c1b953befa7e1dc)
  unreachable
bb222:
  %t1114 = mul i64 0, 8
  %t1115 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1116 = insertvalue { i64, ptr } %t1115, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1116, ptr %l590, !tbaa !27
  %t1117 = load ptr, ptr %l0, !tbaa !29
  %t1118 = load ptr, ptr %l32, !tbaa !29
  %t1121 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v3, ptr %v0, ptr %t1117, ptr %t1118)
  store { i64, ptr } %t1121, ptr %l593
  br label %bb224
bb223:
  call void @__olang_check_failed(ptr @olang_loc_1c2cb6c96b4eaee8_c1b953befa7e1dc)
  unreachable
bb224:
  %t1122 = icmp sge i64 0, 0
  br i1 %t1122, label %bb225, label %bb226
bb225:
  %t1124 = icmp sle i64 0, 2305843009213693951
  br i1 %t1124, label %bb227, label %bb228
bb226:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb227:
  %t1126 = mul i64 0, 4
  %t1127 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1128 = insertvalue { i64, ptr } %t1127, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1129 = load ptr, ptr %l582, !tbaa !29
  %t1130 = load %"compiler/source:Span", ptr %l583
  %t1131 = load %"compiler/source:Span", ptr %l584
  %t1132 = load i64, ptr %l585, !tbaa !24
  %t1133 = load ptr, ptr %l587, !tbaa !29
  %t1134 = load { i64, ptr }, ptr %l590, !tbaa !27
  %t1135 = load { i64, ptr }, ptr %l593, !tbaa !27
  %t1137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v3, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t1129, %"compiler/source:Span" %t1130, %"compiler/source:Span" %t1131, i64 %t1132, ptr %t1133, { i64, ptr } %t1134, { i64, ptr } %t1135, { i64, ptr } %t1128)
  store ptr %t1137, ptr %l597
  br label %bb229
bb228:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb229:
  %t1138 = load ptr, ptr %l597, !tbaa !29
  store ptr %t1138, ptr %l33, !tbaa !29
  %t1139 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1139, ptr %l598
  %t1140 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1140, ptr %l599, !tbaa !23
  %t1141 = load ptr, ptr %l30, !tbaa !29
  store ptr %t1141, ptr %l600, !tbaa !29
  %t1142 = load ptr, ptr %l0, !tbaa !29
  %t1143 = load %"compiler/source:Span", ptr %l1
  %t1144 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t1142, %"compiler/source:Span" %t1143, i32 %t1144, i64 0)
  store ptr %t1148, ptr %l604
  br label %bb230
bb230:
  %t1149 = load ptr, ptr %l604, !tbaa !29
  %t1150 = load ptr, ptr %l33, !tbaa !29
  %t1151 = load ptr, ptr %l600, !tbaa !29
  %t1154 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t1151, ptr %t1149, ptr %t1150)
  store %"compiler/typed:Cond" %t1154, ptr %l607
  br label %bb231
bb231:
  %t1155 = load %"compiler/typed:Cond", ptr %l607
  %t1156 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t1155, ptr %t1156
  store { i64, [5 x i64] } zeroinitializer, ptr %t1157
  %t1158 = getelementptr { i64, [5 x i64] }, ptr %t1157, i32 0, i32 0
  store i64 11, ptr %t1158
  %t1159 = load %"compiler/source:Span", ptr %l598
  %t1160 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1159, 0
  %t1161 = load i32, ptr %l599, !tbaa !23
  %t1162 = insertvalue { %"compiler/source:Span", i32, ptr } %t1160, i32 %t1161, 1
  %t1164 = insertvalue { %"compiler/source:Span", i32, ptr } %t1162, ptr %t1156, 2
  %t1165 = getelementptr { i64, [5 x i64] }, ptr %t1157, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1164, ptr %t1165
  %t1166 = load { i64, [5 x i64] }, ptr %t1157
  %t1167 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store ptr %t1167, ptr %lp34
  %t1169 = load ptr, ptr %lp34
  store { i64, [5 x i64] } %t1166, ptr %t1169
  %t1170 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1170, ptr %l610
  %t1171 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1171, ptr %l611, !tbaa !23
  %t1172 = load ptr, ptr %l0, !tbaa !29
  %t1174 = getelementptr %"compiler/check:Checker", ptr %t1172, i32 0, i32 37
  %t1175 = load i64, ptr %l25, !tbaa !24
  %t1178 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1174, i64 %t1175)
  store { i64, ptr } %t1178, ptr %l615
  br label %bb232
bb232:
  %t1179 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1179, ptr %l616
  %t1180 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1180, ptr %l617, !tbaa !23
  %t1181 = load ptr, ptr %l28, !tbaa !29
  %t1182 = load ptr, ptr %l29, !tbaa !29
  %t1184 = load ptr, ptr %lp34
  %t1188 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t1181, ptr %t1182, ptr %t1184)
  store %"compiler/typed:Cond" %t1188, ptr %l622
  br label %bb233
bb233:
  %t1189 = load %"compiler/typed:Cond", ptr %l622
  %t1190 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t1189, ptr %t1190
  store { i64, [5 x i64] } zeroinitializer, ptr %t1191
  %t1192 = getelementptr { i64, [5 x i64] }, ptr %t1191, i32 0, i32 0
  store i64 11, ptr %t1192
  %t1193 = load %"compiler/source:Span", ptr %l616
  %t1194 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1193, 0
  %t1195 = load i32, ptr %l617, !tbaa !23
  %t1196 = insertvalue { %"compiler/source:Span", i32, ptr } %t1194, i32 %t1195, 1
  %t1198 = insertvalue { %"compiler/source:Span", i32, ptr } %t1196, ptr %t1190, 2
  %t1199 = getelementptr { i64, [5 x i64] }, ptr %t1191, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1198, ptr %t1199
  %t1200 = load { i64, [5 x i64] }, ptr %t1191
  %t1202 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t1200, ptr %t1202
  %t1203 = load { i64, ptr }, ptr %l615, !tbaa !27
  %t1205 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t1203, ptr %t1202, i1 false)
  store %"compiler/typed:Seq" %t1205, ptr %l626
  br label %bb234
bb234:
  %t1206 = load %"compiler/typed:Seq", ptr %l626
  %t1207 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Seq" %t1206, ptr %t1207
  store { i64, [5 x i64] } zeroinitializer, ptr %t1208
  %t1209 = getelementptr { i64, [5 x i64] }, ptr %t1208, i32 0, i32 0
  store i64 12, ptr %t1209
  %t1210 = load %"compiler/source:Span", ptr %l610
  %t1211 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1210, 0
  %t1212 = load i32, ptr %l611, !tbaa !23
  %t1213 = insertvalue { %"compiler/source:Span", i32, ptr } %t1211, i32 %t1212, 1
  %t1215 = insertvalue { %"compiler/source:Span", i32, ptr } %t1213, ptr %t1207, 2
  %t1216 = getelementptr { i64, [5 x i64] }, ptr %t1208, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1215, ptr %t1216
  %t1217 = load { i64, [5 x i64] }, ptr %t1208
  %t1218 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store ptr %t1218, ptr %lp35
  %t1220 = load ptr, ptr %lp35
  store { i64, [5 x i64] } %t1217, ptr %t1220
  %t1221 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1223 = trunc i64 79 to i32
  %t1224 = icmp eq i32 %t1221, %t1223
  br i1 %t1224, label %bb235, label %bb236
bb235:
  %t1226 = load ptr, ptr %l0, !tbaa !29
  %t1227 = load %"compiler/source:Span", ptr %l1
  %t1228 = load ptr, ptr %lp35
  %t1232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t1226, %"compiler/source:Span" %t1227, ptr %t1228)
  store ptr %t1232, ptr %l635
  br label %bb237
bb236:
  %t1233 = load ptr, ptr %lp35
  store ptr %t1233, ptr %l631, !tbaa !29
  br label %bb238
bb237:
  %t1235 = load ptr, ptr %l635, !tbaa !29
  store ptr %t1235, ptr %l631, !tbaa !29
  br label %bb238
bb238:
  %t1236 = load ptr, ptr %l631, !tbaa !29
  store ptr %t1236, ptr %rv
  br label %ret
bb239:
  %t1237 = load i64, ptr %l24, !tbaa !24
  %t1239 = icmp sge i64 %t1237, 0
  br i1 %t1239, label %bb240, label %bb241
bb240:
  %t1241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1241, ptr %l639, !tbaa !29
  %t1242 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1242, ptr %l640
  %t1243 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1243, ptr %l641
  %t1244 = load i64, ptr %l24, !tbaa !24
  store i64 %t1244, ptr %l642, !tbaa !24
  %t1245 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1245, ptr %l644, !tbaa !29
  %t1247 = icmp sge i64 0, 0
  br i1 %t1247, label %bb242, label %bb243
bb241:
  br label %bb256
bb242:
  %t1249 = icmp sle i64 0, 1152921504606846975
  br i1 %t1249, label %bb244, label %bb245
bb243:
  call void @__olang_check_failed(ptr @olang_loc_bc0d2701821819b6_446831e810be806a)
  unreachable
bb244:
  %t1251 = mul i64 0, 8
  %t1252 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1253 = insertvalue { i64, ptr } %t1252, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1253, ptr %l647, !tbaa !27
  %t1254 = load ptr, ptr %l0, !tbaa !29
  %t1255 = load ptr, ptr %l4, !tbaa !29
  %t1258 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v2, ptr %v0, ptr %t1254, ptr %t1255)
  store { i64, ptr } %t1258, ptr %l650
  br label %bb246
bb245:
  call void @__olang_check_failed(ptr @olang_loc_bc0d2701821819b6_446831e810be806a)
  unreachable
bb246:
  %t1259 = icmp sge i64 0, 0
  br i1 %t1259, label %bb247, label %bb248
bb247:
  %t1261 = icmp sle i64 0, 2305843009213693951
  br i1 %t1261, label %bb249, label %bb250
bb248:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb249:
  %t1263 = mul i64 0, 4
  %t1264 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1265 = insertvalue { i64, ptr } %t1264, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1266 = load ptr, ptr %l639, !tbaa !29
  %t1267 = load %"compiler/source:Span", ptr %l640
  %t1268 = load %"compiler/source:Span", ptr %l641
  %t1269 = load i64, ptr %l642, !tbaa !24
  %t1270 = load ptr, ptr %l644, !tbaa !29
  %t1271 = load { i64, ptr }, ptr %l647, !tbaa !27
  %t1272 = load { i64, ptr }, ptr %l650, !tbaa !27
  %t1274 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t1266, %"compiler/source:Span" %t1267, %"compiler/source:Span" %t1268, i64 %t1269, ptr %t1270, { i64, ptr } %t1271, { i64, ptr } %t1272, { i64, ptr } %t1265)
  store ptr %t1274, ptr %l654
  br label %bb251
bb250:
  call void @__olang_check_failed(ptr @olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9)
  unreachable
bb251:
  %t1275 = load ptr, ptr %l654, !tbaa !29
  store ptr %t1275, ptr %l36, !tbaa !29
  %t1276 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1278 = trunc i64 79 to i32
  %t1279 = icmp eq i32 %t1276, %t1278
  br i1 %t1279, label %bb252, label %bb253
bb252:
  %t1281 = load ptr, ptr %l0, !tbaa !29
  %t1282 = load %"compiler/source:Span", ptr %l1
  %t1283 = load ptr, ptr %l36, !tbaa !29
  %t1287 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t1281, %"compiler/source:Span" %t1282, ptr %t1283)
  store ptr %t1287, ptr %l661
  br label %bb254
bb253:
  %t1288 = load ptr, ptr %l36, !tbaa !29
  store ptr %t1288, ptr %l657, !tbaa !29
  br label %bb255
bb254:
  %t1290 = load ptr, ptr %l661, !tbaa !29
  store ptr %t1290, ptr %l657, !tbaa !29
  br label %bb255
bb255:
  %t1291 = load ptr, ptr %l657, !tbaa !29
  store ptr %t1291, ptr %rv
  br label %ret
bb256:
  %t1292 = load ptr, ptr %l0, !tbaa !29
  %t1293 = load i32, ptr %l5, !tbaa !23
  %t1296 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1292, i32 %t1293)
  store i1 %t1296, ptr %l665
  br label %bb257
bb257:
  %t1297 = load i1, ptr %l665, !tbaa !21
  br i1 %t1297, label %bb258, label %bb259
bb258:
  %t1298 = load ptr, ptr %l0, !tbaa !29
  %t1299 = load i32, ptr %l6, !tbaa !23
  %t1302 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1298, i32 %t1299)
  store i1 %t1302, ptr %l669
  br label %bb260
bb259:
  store i1 false, ptr %l666, !tbaa !21
  br label %bb261
bb260:
  %t1303 = load i1, ptr %l669, !tbaa !21
  store i1 %t1303, ptr %l666, !tbaa !21
  br label %bb261
bb261:
  %t1304 = load i1, ptr %l666, !tbaa !21
  br i1 %t1304, label %bb262, label %bb263
bb262:
  %t1305 = load ptr, ptr %l0, !tbaa !29
  %t1306 = load i32, ptr %l9, !tbaa !23
  %t1309 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t1305, i32 %t1306)
  store i1 %t1309, ptr %l673
  br label %bb264
bb263:
  store i1 false, ptr %l670, !tbaa !21
  br label %bb273
bb264:
  %t1310 = load i1, ptr %l673, !tbaa !21
  br i1 %t1310, label %bb265, label %bb266
bb265:
  store i1 true, ptr %l674, !tbaa !21
  br label %bb268
bb266:
  %t1311 = load ptr, ptr %l0, !tbaa !29
  %t1312 = load i32, ptr %l9, !tbaa !23
  %t1315 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t1311, i32 %t1312)
  store i1 %t1315, ptr %l677
  br label %bb267
bb267:
  %t1316 = load i1, ptr %l677, !tbaa !21
  store i1 %t1316, ptr %l674, !tbaa !21
  br label %bb268
bb268:
  %t1317 = load i1, ptr %l674, !tbaa !21
  br i1 %t1317, label %bb269, label %bb270
bb269:
  store i1 true, ptr %l678, !tbaa !21
  br label %bb272
bb270:
  %t1318 = load ptr, ptr %l0, !tbaa !29
  %t1320 = getelementptr %"compiler/check:Checker", ptr %t1318, i32 0, i32 1
  %t1321 = load ptr, ptr %t1320, !tbaa !29
  %t1323 = getelementptr %"compiler/generic:Program", ptr %t1321, i32 0, i32 2
  %t1324 = load i32, ptr %l9, !tbaa !23
  %t1327 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1323, i32 %t1324)
  store i32 %t1327, ptr %l683
  br label %bb271
bb271:
  %t1328 = load i32, ptr %l683, !range !{i32 0, i32 33}
  %t1330 = trunc i64 29 to i32
  %t1331 = icmp eq i32 %t1328, %t1330
  store i1 %t1331, ptr %l678, !tbaa !21
  br label %bb272
bb272:
  %t1333 = load i1, ptr %l678, !tbaa !21
  store i1 %t1333, ptr %l670, !tbaa !21
  br label %bb273
bb273:
  %t1334 = load i1, ptr %l670, !tbaa !21
  br i1 %t1334, label %bb274, label %bb275
bb274:
  %t1335 = load ptr, ptr %l0, !tbaa !29
  %t1336 = load %"compiler/source:Span", ptr %l1
  %t1337 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1338 = load ptr, ptr %l3, !tbaa !29
  %t1339 = load ptr, ptr %l4, !tbaa !29
  %t1347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t1335, %"compiler/source:Span" %t1336, i32 %t1337, i32 19, ptr %t1338, ptr %t1339)
  store ptr %t1347, ptr %l693
  br label %bb276
bb275:
  br label %bb281
bb276:
  %t1348 = load ptr, ptr %l693, !tbaa !29
  store ptr %t1348, ptr %l37, !tbaa !29
  %t1349 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1351 = trunc i64 79 to i32
  %t1352 = icmp eq i32 %t1349, %t1351
  br i1 %t1352, label %bb277, label %bb278
bb277:
  %t1354 = load ptr, ptr %l0, !tbaa !29
  %t1355 = load %"compiler/source:Span", ptr %l1
  %t1356 = load ptr, ptr %l37, !tbaa !29
  %t1360 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t1354, %"compiler/source:Span" %t1355, ptr %t1356)
  store ptr %t1360, ptr %l700
  br label %bb279
bb278:
  %t1361 = load ptr, ptr %l37, !tbaa !29
  store ptr %t1361, ptr %l696, !tbaa !29
  br label %bb280
bb279:
  %t1363 = load ptr, ptr %l700, !tbaa !29
  store ptr %t1363, ptr %l696, !tbaa !29
  br label %bb280
bb280:
  %t1364 = load ptr, ptr %l696, !tbaa !29
  store ptr %t1364, ptr %rv
  br label %ret
bb281:
  %t1365 = load ptr, ptr %l0, !tbaa !29
  %t1366 = load i32, ptr %l9, !tbaa !23
  %t1369 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsHaveEq(ptr %v0, ptr %t1365, i32 %t1366, i64 0)
  store i1 %t1369, ptr %l704
  br label %bb282
bb282:
  %t1370 = load i1, ptr %l704, !tbaa !21
  br i1 %t1370, label %bb283, label %bb284
bb283:
  %t1371 = load ptr, ptr %l0, !tbaa !29
  %t1372 = load %"compiler/source:Span", ptr %l1
  %t1373 = load ptr, ptr %l3, !tbaa !29
  %t1374 = load ptr, ptr %l4, !tbaa !29
  %t1375 = load i32, ptr %l9, !tbaa !23
  %t1381 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t1371, %"compiler/source:Span" %t1372, ptr %t1373, ptr %t1374, i32 %t1375)
  store ptr %t1381, ptr %l710
  br label %bb285
bb284:
  br label %bb295
bb285:
  %t1382 = load ptr, ptr %l710, !tbaa !29
  store ptr %t1382, ptr %l38, !tbaa !29
  %t1383 = load ptr, ptr %l38, !tbaa !29
  %t1385 = icmp eq ptr %t1383, null
  br i1 %t1385, label %bb286, label %bb287
bb286:
  store %olang.scope zeroinitializer, ptr %s22
  %t1387 = load ptr, ptr %l0, !tbaa !29
  %t1388 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s22, ptr %t1387, %"compiler/source:Span" %t1388, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb288
bb287:
  br label %bb290
bb288:
  %t1391 = load ptr, ptr %l0, !tbaa !29
  %t1392 = load %"compiler/source:Span", ptr %l1
  %t1393 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t1397 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t1391, %"compiler/source:Span" %t1392, i32 %t1393, i64 0)
  store ptr %t1397, ptr %l718
  br label %bb289
bb289:
  call void @__olang_scope_close(ptr %s22)
  %t1398 = load ptr, ptr %l718, !tbaa !29
  store ptr %t1398, ptr %rv
  br label %ret
bb290:
  %t1399 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1401 = trunc i64 79 to i32
  %t1402 = icmp eq i32 %t1399, %t1401
  br i1 %t1402, label %bb291, label %bb292
bb291:
  %t1404 = load ptr, ptr %l0, !tbaa !29
  %t1405 = load %"compiler/source:Span", ptr %l1
  %t1406 = load ptr, ptr %l38, !tbaa !29
  %t1410 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t1404, %"compiler/source:Span" %t1405, ptr %t1406)
  store ptr %t1410, ptr %l725
  br label %bb293
bb292:
  %t1411 = load ptr, ptr %l38, !tbaa !29
  store ptr %t1411, ptr %l721, !tbaa !29
  br label %bb294
bb293:
  %t1413 = load ptr, ptr %l725, !tbaa !29
  store ptr %t1413, ptr %l721, !tbaa !29
  br label %bb294
bb294:
  %t1414 = load ptr, ptr %l721, !tbaa !29
  store ptr %t1414, ptr %rv
  br label %ret
bb295:
  %t1415 = load ptr, ptr %l0, !tbaa !29
  %t1416 = load i32, ptr %l5, !tbaa !23
  %t1419 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1415, i32 %t1416)
  store i1 %t1419, ptr %l729
  br label %bb296
bb296:
  %t1420 = load i1, ptr %l729, !tbaa !21
  br i1 %t1420, label %bb297, label %bb298
bb297:
  %t1421 = load ptr, ptr %l0, !tbaa !29
  %t1422 = load i32, ptr %l6, !tbaa !23
  %t1425 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1421, i32 %t1422)
  store i1 %t1425, ptr %l733
  br label %bb299
bb298:
  store i1 false, ptr %l730, !tbaa !21
  br label %bb300
bb299:
  %t1426 = load i1, ptr %l733, !tbaa !21
  store i1 %t1426, ptr %l730, !tbaa !21
  br label %bb300
bb300:
  %t1427 = load i1, ptr %l730, !tbaa !21
  br i1 %t1427, label %bb301, label %bb302
bb301:
  %t1428 = load ptr, ptr %l0, !tbaa !29
  %t1430 = getelementptr %"compiler/check:Checker", ptr %t1428, i32 0, i32 1
  %t1431 = load ptr, ptr %t1430, !tbaa !29
  %t1433 = getelementptr %"compiler/generic:Program", ptr %t1431, i32 0, i32 2
  %t1434 = load i32, ptr %l9, !tbaa !23
  %t1435 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t1439 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1433, i32 %t1434, i64 %t1435)
  store i32 %t1439, ptr %l740
  br label %bb303
bb302:
  %t1440 = load i32, ptr %l9, !tbaa !23
  store i32 %t1440, ptr %l734, !tbaa !23
  br label %bb304
bb303:
  %t1442 = load i32, ptr %l740, !tbaa !23
  store i32 %t1442, ptr %l734, !tbaa !23
  br label %bb304
bb304:
  %t1443 = load i32, ptr %l734, !tbaa !23
  store i32 %t1443, ptr %l39, !tbaa !23
  %t1444 = load ptr, ptr %l0, !tbaa !29
  %t1445 = load i32, ptr %l5, !tbaa !23
  %t1448 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1444, i32 %t1445)
  store i1 %t1448, ptr %l744
  br label %bb305
bb305:
  %t1449 = load i1, ptr %l744, !tbaa !21
  br i1 %t1449, label %bb306, label %bb307
bb306:
  %t1450 = load ptr, ptr %l0, !tbaa !29
  %t1451 = load i32, ptr %l6, !tbaa !23
  %t1454 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1450, i32 %t1451)
  store i1 %t1454, ptr %l748
  br label %bb308
bb307:
  store i1 false, ptr %l745, !tbaa !21
  br label %bb309
bb308:
  %t1455 = load i1, ptr %l748, !tbaa !21
  store i1 %t1455, ptr %l745, !tbaa !21
  br label %bb309
bb309:
  %t1456 = load i1, ptr %l745, !tbaa !21
  br i1 %t1456, label %bb310, label %bb311
bb310:
  %t1457 = load ptr, ptr %l0, !tbaa !29
  %t1459 = getelementptr %"compiler/check:Checker", ptr %t1457, i32 0, i32 1
  %t1460 = load ptr, ptr %t1459, !tbaa !29
  %t1462 = getelementptr %"compiler/generic:Program", ptr %t1460, i32 0, i32 2
  %t1463 = load i32, ptr %l5, !tbaa !23
  %t1466 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t1462, i32 %t1463)
  store i1 %t1466, ptr %l754
  br label %bb312
bb311:
  store i1 false, ptr %l749, !tbaa !21
  br label %bb317
bb312:
  %t1467 = load i1, ptr %l754, !tbaa !21
  br i1 %t1467, label %bb313, label %bb314
bb313:
  store i1 true, ptr %l755, !tbaa !21
  br label %bb316
bb314:
  %t1468 = load ptr, ptr %l0, !tbaa !29
  %t1470 = getelementptr %"compiler/check:Checker", ptr %t1468, i32 0, i32 1
  %t1471 = load ptr, ptr %t1470, !tbaa !29
  %t1473 = getelementptr %"compiler/generic:Program", ptr %t1471, i32 0, i32 2
  %t1474 = load i32, ptr %l6, !tbaa !23
  %t1477 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t1473, i32 %t1474)
  store i1 %t1477, ptr %l760
  br label %bb315
bb315:
  %t1478 = load i1, ptr %l760, !tbaa !21
  store i1 %t1478, ptr %l755, !tbaa !21
  br label %bb316
bb316:
  %t1479 = load i1, ptr %l755, !tbaa !21
  store i1 %t1479, ptr %l749, !tbaa !21
  br label %bb317
bb317:
  %t1480 = load i1, ptr %l749, !tbaa !21
  br i1 %t1480, label %bb318, label %bb319
bb318:
  %t1481 = load ptr, ptr %l0, !tbaa !29
  %t1483 = getelementptr %"compiler/check:Checker", ptr %t1481, i32 0, i32 1
  %t1484 = load ptr, ptr %t1483, !tbaa !29
  %t1486 = getelementptr %"compiler/generic:Program", ptr %t1484, i32 0, i32 2
  %t1487 = load i32, ptr %l39, !tbaa !23
  %t1490 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t1486, i32 %t1487)
  store i32 %t1490, ptr %l765
  br label %bb320
bb319:
  br label %bb321
bb320:
  %t1491 = load i32, ptr %l765, !tbaa !23
  store i32 %t1491, ptr %l39, !tbaa !23
  br label %bb321
bb321:
  %t1492 = load ptr, ptr %l0, !tbaa !29
  %t1493 = load ptr, ptr %l3, !tbaa !29
  %t1494 = load i32, ptr %l39, !tbaa !23
  %t1495 = load %"compiler/source:Span", ptr %l1
  %t1500 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v3, ptr %t1492, ptr %t1493, i32 %t1494, %"compiler/source:Span" %t1495)
  store ptr %t1500, ptr %l770
  br label %bb322
bb322:
  %t1501 = load ptr, ptr %l770, !tbaa !29
  store ptr %t1501, ptr %l40, !tbaa !29
  %t1502 = load ptr, ptr %l0, !tbaa !29
  %t1503 = load ptr, ptr %l4, !tbaa !29
  %t1504 = load i32, ptr %l39, !tbaa !23
  %t1505 = load %"compiler/source:Span", ptr %l1
  %t1510 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v3, ptr %t1502, ptr %t1503, i32 %t1504, %"compiler/source:Span" %t1505)
  store ptr %t1510, ptr %l775
  br label %bb323
bb323:
  %t1511 = load ptr, ptr %l775, !tbaa !29
  store ptr %t1511, ptr %l41, !tbaa !29
  %t1512 = load ptr, ptr %l0, !tbaa !29
  %t1514 = getelementptr %"compiler/check:Checker", ptr %t1512, i32 0, i32 36
  %t1516 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t1514)
  store i64 %t1516, ptr %l778
  br label %bb324
bb324:
  %t1517 = load i64, ptr %l778, !tbaa !24
  store i64 %t1517, ptr %l42, !tbaa !24
  %t1518 = load ptr, ptr %l0, !tbaa !29
  %t1520 = getelementptr %"compiler/check:Checker", ptr %t1518, i32 0, i32 36
  %t1521 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t1520, ptr %t1521)
  br label %bb325
bb325:
  %t1524 = load ptr, ptr %l0, !tbaa !29
  %t1526 = getelementptr %"compiler/check:Checker", ptr %t1524, i32 0, i32 36
  %t1527 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t1526, ptr %t1527)
  br label %bb326
bb326:
  %t1530 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1530, ptr %l785, !tbaa !29
  %t1531 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1531, ptr %l786
  %t1532 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t1532, ptr %l787, !tbaa !23
  %t1533 = load i32, ptr %l39, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t1534
  %t1535 = getelementptr { i64, [3 x i64] }, ptr %t1534, i32 0, i32 0
  store i64 4, ptr %t1535
  %t1537 = insertvalue { i32, i32 } undef, i32 0, 0
  %t1539 = insertvalue { i32, i32 } %t1537, i32 %t1533, 1
  %t1540 = getelementptr { i64, [3 x i64] }, ptr %t1534, i32 0, i32 1
  store { i32, i32 } %t1539, ptr %t1540
  %t1541 = load { i64, [3 x i64] }, ptr %t1534
  %t1543 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store { i64, [3 x i64] } %t1541, ptr %t1543
  store ptr %t1543, ptr %l791, !tbaa !29
  %t1544 = load ptr, ptr %l0, !tbaa !29
  %t1546 = getelementptr %"compiler/check:Checker", ptr %t1544, i32 0, i32 36
  %t1547 = load i64, ptr %l42, !tbaa !24
  %t1550 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t1546, i64 %t1547)
  store { i64, ptr } %t1550, ptr %l795
  br label %bb327
bb327:
  %t1551 = load ptr, ptr %l785, !tbaa !29
  %t1552 = load %"compiler/source:Span", ptr %l786
  %t1553 = load i32, ptr %l787, !tbaa !23
  %t1554 = load ptr, ptr %l791, !tbaa !29
  %t1555 = load { i64, ptr }, ptr %l795, !tbaa !27
  %t1556 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t1551, %"compiler/source:Span" %t1552, i32 %t1553, ptr %t1554, { i64, ptr } %t1555)
  store ptr %t1556, ptr %l796
  br label %bb328
bb328:
  %t1557 = load ptr, ptr %l796, !tbaa !29
  store ptr %t1557, ptr %l43, !tbaa !29
  %t1558 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1560 = trunc i64 79 to i32
  %t1561 = icmp eq i32 %t1558, %t1560
  br i1 %t1561, label %bb329, label %bb330
bb329:
  %t1563 = load ptr, ptr %l0, !tbaa !29
  %t1564 = load %"compiler/source:Span", ptr %l1
  %t1565 = load ptr, ptr %l43, !tbaa !29
  %t1569 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t1563, %"compiler/source:Span" %t1564, ptr %t1565)
  store ptr %t1569, ptr %l803
  br label %bb331
bb330:
  %t1570 = load ptr, ptr %l43, !tbaa !29
  store ptr %t1570, ptr %l799, !tbaa !29
  br label %bb332
bb331:
  %t1572 = load ptr, ptr %l803, !tbaa !29
  store ptr %t1572, ptr %l799, !tbaa !29
  br label %bb332
bb332:
  %t1573 = load ptr, ptr %l799, !tbaa !29
  store ptr %t1573, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l39 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca ptr
  %l60 = alloca i1
  %l73 = alloca { i64, ptr }
  %l79 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l86 = alloca i1
  %l99 = alloca { i64, ptr }
  %l105 = alloca %"compiler/source:Span"
  %l111 = alloca ptr
  %l112 = alloca i1
  %l120 = alloca i1
  %l121 = alloca i1
  %l126 = alloca { i64, ptr }
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 -1, i32 -1)
  store %"compiler/source:Span" %t5, ptr %l22
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t6 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t8 = load ptr, ptr %l23, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l23, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 18}
  %t14 = icmp eq i64 %t12, 2
  store i1 %t14, ptr %l24, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l24, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l2
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb9
bb8:
  br label %bb18
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l33
  br label %bb10
bb10:
  %t33 = load i1, ptr %l33, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb14
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l39
  br label %bb13
bb13:
  %t44 = load i1, ptr %l39, !tbaa !21
  store i1 %t44, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l34, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load %"compiler/source:Span", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t46, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb82
bb18:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t49 = load ptr, ptr %l41, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb19, label %bb20
bb19:
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l42, !tbaa !21
  br label %bb20
bb20:
  %t56 = load i1, ptr %l42, !tbaa !21
  br i1 %t56, label %bb21, label %bb22
bb21:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 0
  %t61 = load %"compiler/source:Span", ptr %t60
  store %"compiler/source:Span" %t61, ptr %l4
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t63 = load %"compiler/source:Span", ptr %l4
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t63, ptr %rv
  br label %ret
bb24:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t66 = load ptr, ptr %l48, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb25, label %bb26
bb25:
  %t69 = load ptr, ptr %l48, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 18}
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t73 = load i1, ptr %l49, !tbaa !21
  br i1 %t73, label %bb27, label %bb28
bb27:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Promote", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t88 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  store %"compiler/source:Span" %t88, ptr %l58
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load %"compiler/source:Span", ptr %l58
  store %"compiler/source:Span" %t89, ptr %rv
  br label %ret
bb31:
  %t90 = load ptr, ptr %l1, !tbaa !29
  store ptr %t90, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t91 = load ptr, ptr %l59, !tbaa !29
  %t92 = icmp ne ptr %t91, null
  br i1 %t92, label %bb32, label %bb33
bb32:
  %t94 = load ptr, ptr %l59, !tbaa !29
  %t95 = load i64, ptr %t94, !range !{i64 0, i64 18}
  %t97 = icmp eq i64 %t95, 6
  store i1 %t97, ptr %l60, !tbaa !21
  br label %bb33
bb33:
  %t98 = load i1, ptr %l60, !tbaa !21
  br i1 %t98, label %bb34, label %bb35
bb34:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  store ptr %t103, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb47
bb36:
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Call", ptr %t105, i32 0, i32 1
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  %t114 = load i64, ptr %l8, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb38, label %bb39
bb38:
  br label %bb46
bb39:
  br label %bb40
bb40:
  %t122 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t122, ptr %l73, !tbaa !27
  %t123 = load i64, ptr %l8, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr ptr, ptr %t126, i64 %t123
  %t128 = load ptr, ptr %t127, !tbaa !39
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t135 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v1, ptr %t130, ptr %t128)
  store %"compiler/source:Span" %t135, ptr %l79
  br label %bb41
bb41:
  %t136 = load %"compiler/source:Span", ptr %l79
  store %"compiler/source:Span" %t136, ptr %l11
  %t137 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t138 = load i32, ptr %t137, !tbaa !23
  %t140 = icmp sge i32 %t138, 0
  br i1 %t140, label %bb42, label %bb43
bb42:
  %t142 = load %"compiler/source:Span", ptr %l11
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t142, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t144 = load i64, ptr %l8, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l8, !tbaa !24
  br label %bb37
bb46:
  br label %bb82
bb47:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t149 = load ptr, ptr %l85, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb48, label %bb49
bb48:
  %t152 = load ptr, ptr %l85, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 18}
  %t155 = icmp eq i64 %t153, 7
  store i1 %t155, ptr %l86, !tbaa !21
  br label %bb49
bb49:
  %t156 = load i1, ptr %l86, !tbaa !21
  br i1 %t156, label %bb50, label %bb51
bb50:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [5 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t159, i32 0, i32 2
  %t161 = load ptr, ptr %t160
  store ptr %t161, ptr %l12, !tbaa !29
  br label %bb52
bb51:
  br label %bb63
bb52:
  %t163 = load ptr, ptr %l12, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Make", ptr %t163, i32 0, i32 2
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l15, !tbaa !24
  br label %bb53
bb53:
  %t172 = load i64, ptr %l14, !tbaa !24
  %t173 = load i64, ptr %l15, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb54, label %bb55
bb54:
  br label %bb62
bb55:
  br label %bb56
bb56:
  %t180 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t180, ptr %l99, !tbaa !27
  %t181 = load i64, ptr %l14, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr ptr, ptr %t184, i64 %t181
  %t186 = load ptr, ptr %t185, !tbaa !39
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t193 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v1, ptr %t188, ptr %t186)
  store %"compiler/source:Span" %t193, ptr %l105
  br label %bb57
bb57:
  %t194 = load %"compiler/source:Span", ptr %l105
  store %"compiler/source:Span" %t194, ptr %l17
  %t195 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t196 = load i32, ptr %t195, !tbaa !23
  %t198 = icmp sge i32 %t196, 0
  br i1 %t198, label %bb58, label %bb59
bb58:
  %t200 = load %"compiler/source:Span", ptr %l17
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t200, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t202 = load i64, ptr %l14, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l14, !tbaa !24
  br label %bb53
bb62:
  br label %bb82
bb63:
  %t206 = load ptr, ptr %l1, !tbaa !29
  store ptr %t206, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t207 = load ptr, ptr %l111, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb64, label %bb65
bb64:
  %t210 = load ptr, ptr %l111, !tbaa !29
  %t211 = load i64, ptr %t210, !range !{i64 0, i64 18}
  %t213 = icmp eq i64 %t211, 9
  store i1 %t213, ptr %l112, !tbaa !21
  br label %bb65
bb65:
  %t214 = load i1, ptr %l112, !tbaa !21
  br i1 %t214, label %bb66, label %bb67
bb66:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr { i64, [5 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t217, i32 0, i32 2
  %t219 = load i32, ptr %t218, !range !{i32 0, i32 46}
  store i32 %t219, ptr %l18
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t223, i32 0, i32 4
  %t225 = load { i64, ptr }, ptr %t224
  store { i64, ptr } %t225, ptr %l19, !tbaa !27
  br label %bb68
bb67:
  br label %bb77
bb68:
  %t227 = load i32, ptr %l18, !range !{i32 0, i32 46}
  %t229 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t227)
  store i1 %t229, ptr %l120
  br label %bb69
bb69:
  %t230 = load i1, ptr %l120, !tbaa !21
  br i1 %t230, label %bb70, label %bb71
bb70:
  %t231 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t235 = icmp sgt i64 %t233, 0
  store i1 %t235, ptr %l121, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb72
bb72:
  %t237 = load i1, ptr %l121, !tbaa !21
  br i1 %t237, label %bb73, label %bb74
bb73:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t239, ptr %l126, !tbaa !27
  %t240 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr ptr, ptr %t241, i64 0
  %t243 = load ptr, ptr %t242, !tbaa !39
  %t247 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexistingIn(ptr %v0, ptr %v1, ptr %t238, ptr %t243)
  store %"compiler/source:Span" %t247, ptr %l129
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t248 = load %"compiler/source:Span", ptr %l129
  store %"compiler/source:Span" %t248, ptr %rv
  br label %ret
bb76:
  br label %bb82
bb77:
  br i1 true, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_4c666a7bbf559bd5_ecdbfd16c5e8809)
  unreachable
bb82:
  %t249 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t249, ptr %l130
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s0)
  %t250 = load %"compiler/source:Span", ptr %l130
  store %"compiler/source:Span" %t250, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l16 = alloca i64
  %l17 = alloca %"compiler/check:litv"
  %l21 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 98}
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t24 = trunc i64 4 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l2
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %t27, %"compiler/source:Span" %t28)
  store i64 %t31, ptr %l16
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t32)
  store %"compiler/check:litv" %t33, ptr %l17
  br label %bb9
bb9:
  %t34 = load %"compiler/check:litv", ptr %l17
  store %"compiler/check:litv" %t34, ptr %rv
  br label %ret
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2bda502508e1b1d_a3083ba563ab0481)
  unreachable
bb16:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t40 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store %"compiler/check:litv" %t40, ptr %l21
  br label %bb17
bb17:
  %t41 = load %"compiler/check:litv", ptr %l21
  store %"compiler/check:litv" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efor3(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, i64, i64 }
  %l37 = alloca ptr
  %t66 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 1, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l15
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l15
  store { i64, i64, i64 } %t13, ptr %l4
  %t14 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l6, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:For3", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/ast:For3", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:For3", ptr %t37, i32 0, i32 3
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/ast:For3", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t31, %"compiler/source:Span" %t32, ptr %t36, { i64, ptr } %t40, ptr %t44)
  br label %bb4
bb4:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l3, !tbaa !24
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t51, i64 %t52, i64 %t53, i64 %t54, i64 %t55)
  store ptr %t61, ptr %l37
  br label %bb5
bb5:
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 0
  store i64 11, ptr %t67
  %t69 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t64, 0
  %t71 = insertvalue { %"compiler/source:Span", ptr } %t69, ptr %t62, 1
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t71, ptr %t72
  %t73 = load { i64, [3 x i64] }, ptr %t66
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t73, ptr %t75
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t63, ptr %t75)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:reflList"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, i64, i64 }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i64
  %l32 = alloca %"compiler/check:reflList"
  %l39 = alloca ptr
  %l42 = alloca i64
  %l45 = alloca i64
  %l53 = alloca { i64, i64, i64 }
  %l61 = alloca ptr
  %l67 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l75 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca %"compiler/diagmsg:Msg"
  %l83 = alloca i64
  %l86 = alloca i1
  %l91 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca %"compiler/diagmsg:Msg"
  %l99 = alloca i64
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca i32
  %l121 = alloca { i64, ptr }
  %l122 = alloca %"compiler/typed:Seq"
  %l126 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l130 = alloca i64
  %l142 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l160 = alloca ptr
  %l163 = alloca i64
  %l166 = alloca i64
  %l167 = alloca i32
  %l168 = alloca i64
  %l171 = alloca i64
  %l172 = alloca i32
  %l177 = alloca i64
  %l178 = alloca ptr
  %l179 = alloca %"compiler/source:Span"
  %l180 = alloca %"compiler/source:Span"
  %l181 = alloca i32
  %l183 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l188 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t176 = alloca { i64, [3 x i64] }, align 8
  %t193 = alloca { i64, [3 x i64] }, align 8
  %t218 = alloca { i64, [5 x i64] }, align 8
  %t357 = alloca { i64, [5 x i64] }, align 8
  %t369 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load %"compiler/source:Span", ptr %l1
  %t8 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeFor(ptr %v0, ptr %v1, ptr %t6, %"compiler/source:Span" %t7, ptr %t8)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:ForIn", ptr %t13, i32 0, i32 2
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t19 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t12, ptr %t16)
  store %"compiler/check:reflList" %t19, ptr %l32
  br label %bb5
bb5:
  %t20 = load %"compiler/check:reflList", ptr %l32
  store %"compiler/check:reflList" %t20, ptr %l3
  %t21 = getelementptr %"compiler/check:reflList", ptr %l3, i32 0, i32 0
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l1
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = load %"compiler/check:reflList", ptr %l3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolled(ptr %v0, ptr %v1, ptr %t24, %"compiler/source:Span" %t25, ptr %t26, %"compiler/check:reflList" %t27)
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t32)
  store ptr %t34, ptr %l39
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l39, !tbaa !29
  store ptr %t35, ptr %l4, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 28
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l42
  br label %bb11
bb11:
  %t41 = load i64, ptr %l42, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 37
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l45
  br label %bb12
bb12:
  %t47 = load i64, ptr %l45, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t48, i32 0, i32 17
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t55 = getelementptr %"compiler/check:frame", ptr %t53, i32 0, i32 16
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l8, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l1
  %t63 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t58, i32 1, %"compiler/source:Span" %t59)
  store { i64, i64, i64 } %t63, ptr %l53
  br label %bb13
bb13:
  %t64 = load { i64, i64, i64 }, ptr %l53
  store { i64, i64, i64 } %t64, ptr %l9
  %t65 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 0
  %t66 = load i64, ptr %t65, !tbaa !24
  store i64 %t66, ptr %l10, !tbaa !24
  %t68 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  store i64 %t69, ptr %l11, !tbaa !24
  %t71 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 2
  %t72 = load i64, ptr %t71, !tbaa !24
  store i64 %t72, ptr %l12, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l1
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v0, ptr %s0, ptr %t74, %"compiler/source:Span" %t75, ptr %t76, ptr null, i32 %t77)
  store ptr %t82, ptr %l61
  br label %bb14
bb14:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l10, !tbaa !24
  %t85 = load i64, ptr %l11, !tbaa !24
  %t86 = load i64, ptr %l12, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t83, i64 %t84, i64 %t85, i64 %t86, i64 %t87)
  store ptr %t93, ptr %l67
  br label %bb15
bb15:
  %t94 = load ptr, ptr %l67, !tbaa !29
  store ptr %t94, ptr %l13, !tbaa !29
  %t95 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t96 = load i32, ptr %t95, !tbaa !23
  %t97 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t98 = load i32, ptr %t97, !tbaa !23
  %t100 = add i32 %t98, 3
  %t103 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t96, i32 %t100)
  store %"compiler/source:Span" %t103, ptr %l71
  br label %bb16
bb16:
  %t104 = load %"compiler/source:Span", ptr %l71
  store %"compiler/source:Span" %t104, ptr %l14
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/ast:ForIn", ptr %t105, i32 0, i32 3
  %t108 = load i1, ptr %t107, !tbaa !21
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb17, label %bb18
bb17:
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t114 = getelementptr %"compiler/check:frame", ptr %t112, i32 0, i32 17
  %t115 = load i64, ptr %t114, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  store i1 %t119, ptr %l75, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb19
bb19:
  %t121 = load i1, ptr %l75, !tbaa !21
  br i1 %t121, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l80, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t123, ptr %l81
  %t124 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInNeedsTry(ptr %s3)
  store %"compiler/diagmsg:Msg" %t124, ptr %l82
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t125 = load ptr, ptr %l80, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l81
  %t127 = load %"compiler/diagmsg:Msg", ptr %l82
  %t128 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t125, %"compiler/source:Span" %t126, %"compiler/diagmsg:Msg" %t127)
  store i64 %t128, ptr %l83
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t131 = getelementptr %"compiler/ast:ForIn", ptr %t129, i32 0, i32 3
  %t132 = load i1, ptr %t131, !tbaa !21
  br i1 %t132, label %bb25, label %bb26
bb25:
  %t134 = load ptr, ptr %l4, !tbaa !29
  %t136 = getelementptr %"compiler/check:frame", ptr %t134, i32 0, i32 17
  %t137 = load i64, ptr %t136, !tbaa !24
  %t138 = load i64, ptr %l7, !tbaa !24
  %t141 = icmp eq i64 %t137, %t138
  store i1 %t141, ptr %l86, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb27
bb27:
  %t143 = load i1, ptr %l86, !tbaa !21
  br i1 %t143, label %bb28, label %bb29
bb28:
  %t144 = load ptr, ptr %l4, !tbaa !29
  %t146 = getelementptr %"compiler/check:frame", ptr %t144, i32 0, i32 16
  %t147 = load i64, ptr %t146, !tbaa !24
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = icmp eq i64 %t147, %t148
  store i1 %t151, ptr %l91, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb30
bb30:
  %t153 = load i1, ptr %l91, !tbaa !21
  br i1 %t153, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l96, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t155, ptr %l97
  %t156 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInTryNothing(ptr %s4)
  store %"compiler/diagmsg:Msg" %t156, ptr %l98
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t157 = load ptr, ptr %l96, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l97
  %t159 = load %"compiler/diagmsg:Msg", ptr %l98
  %t160 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t157, %"compiler/source:Span" %t158, %"compiler/diagmsg:Msg" %t159)
  store i64 %t160, ptr %l99
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t161 = load ptr, ptr %l4, !tbaa !29
  %t162 = load i64, ptr %l7, !tbaa !24
  %t165 = getelementptr %"compiler/check:frame", ptr %t161, i32 0, i32 17
  store i64 %t162, ptr %t165, !tbaa !24
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t168 = getelementptr %"compiler/ast:ForIn", ptr %t166, i32 0, i32 3
  %t169 = load i1, ptr %t168, !tbaa !21
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb36, label %bb37
bb36:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  %t175 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 0
  store i64 11, ptr %t177
  %t179 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t174, 0
  %t181 = insertvalue { %"compiler/source:Span", ptr } %t179, ptr %t175, 1
  %t182 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t181, ptr %t182
  %t183 = load { i64, [3 x i64] }, ptr %t176
  %t185 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t183, ptr %t185
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t173, ptr %t185)
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 37
  %t191 = load %"compiler/source:Span", ptr %l1
  %t192 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 0
  store i64 11, ptr %t194
  %t196 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t191, 0
  %t198 = insertvalue { %"compiler/source:Span", ptr } %t196, ptr %t192, 1
  %t199 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t198, ptr %t199
  %t200 = load { i64, [3 x i64] }, ptr %t193
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t200, ptr %t202
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t190, ptr %t202)
  br label %bb40
bb40:
  %t205 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t205, ptr %l116
  %t206 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t206, ptr %l117, !tbaa !23
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 37
  %t210 = load i64, ptr %l6, !tbaa !24
  %t213 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t209, i64 %t210)
  store { i64, ptr } %t213, ptr %l121
  br label %bb41
bb41:
  %t214 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t215 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t214, ptr null, i1 false)
  store %"compiler/typed:Seq" %t215, ptr %l122
  br label %bb42
bb42:
  %t216 = load %"compiler/typed:Seq", ptr %l122
  %t217 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Seq" %t216, ptr %t217
  store { i64, [5 x i64] } zeroinitializer, ptr %t218
  %t219 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 0
  store i64 12, ptr %t219
  %t220 = load %"compiler/source:Span", ptr %l116
  %t221 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t220, 0
  %t222 = load i32, ptr %l117, !tbaa !23
  %t223 = insertvalue { %"compiler/source:Span", i32, ptr } %t221, i32 %t222, 1
  %t225 = insertvalue { %"compiler/source:Span", i32, ptr } %t223, ptr %t217, 2
  %t226 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t225, ptr %t226
  %t227 = load { i64, [5 x i64] }, ptr %t218
  %t229 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t227, ptr %t229
  store ptr %t229, ptr %l15, !tbaa !29
  %t231 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, ptr %l126
  br label %bb43
bb43:
  %t232 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l126
  %t233 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232, ptr %t233
  store ptr %t233, ptr %l16, !tbaa !29
  %t235 = load ptr, ptr %l4, !tbaa !29
  %t237 = getelementptr %"compiler/check:frame", ptr %t235, i32 0, i32 28
  %t239 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t237)
  store i64 %t239, ptr %l130
  br label %bb44
bb44:
  %t240 = load i64, ptr %l130, !tbaa !24
  store i64 %t240, ptr %l17, !tbaa !24
  %t241 = load ptr, ptr %l2, !tbaa !29
  %t243 = getelementptr %"compiler/ast:ForIn", ptr %t241, i32 0, i32 5
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t248 = icmp sgt i64 %t246, 0
  br i1 %t248, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s6
  %t250 = load ptr, ptr %l4, !tbaa !29
  %t252 = getelementptr %"compiler/check:frame", ptr %t250, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t252, i64 -2)
  br label %bb47
bb46:
  br label %bb66
bb47:
  %t254 = load ptr, ptr %l4, !tbaa !29
  %t256 = getelementptr %"compiler/check:frame", ptr %t254, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t256, i64 -2)
  br label %bb48
bb48:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i64, ptr %l5, !tbaa !24
  %t260 = load i64, ptr %l17, !tbaa !24
  %t264 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %s6, ptr %t258, i64 %t259, i64 %t260)
  store { i64, ptr } %t264, ptr %l142
  br label %bb49
bb49:
  %t265 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t265, ptr %l18, !tbaa !27
  %t266 = load ptr, ptr %l2, !tbaa !29
  %t268 = getelementptr %"compiler/ast:ForIn", ptr %t266, i32 0, i32 5
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  store { i64, ptr } %t269, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t271, 0
  store i64 %t273, ptr %l21, !tbaa !24
  br label %bb50
bb50:
  %t275 = load i64, ptr %l20, !tbaa !24
  %t276 = load i64, ptr %l21, !tbaa !24
  %t279 = icmp slt i64 %t275, %t276
  %t281 = xor i1 %t279, true
  br i1 %t281, label %bb51, label %bb52
bb51:
  br label %bb57
bb52:
  br label %bb53
bb53:
  %t283 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t283, ptr %l151, !tbaa !27
  %t284 = load i64, ptr %l20, !tbaa !24
  %t286 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr ptr, ptr %t287, i64 %t284
  %t289 = load ptr, ptr %t288, !tbaa !39
  %t291 = load ptr, ptr %l16, !tbaa !29
  store ptr %t291, ptr %l154, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t295 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t296 = load ptr, ptr %l16, !tbaa !29
  %t302 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %s6, ptr %v0, ptr %v0, ptr %t292, ptr %t289, i32 %t294, i1 false, { i64, ptr } %t295, ptr %t296)
  store ptr %t302, ptr %l160
  br label %bb54
bb54:
  %t303 = load ptr, ptr %l154, !tbaa !29
  %t304 = load ptr, ptr %l160, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v0, ptr %t303, ptr %t304)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t305 = load i64, ptr %l20, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l20, !tbaa !24
  br label %bb50
bb57:
  %t309 = load ptr, ptr %l4, !tbaa !29
  %t311 = getelementptr %"compiler/check:frame", ptr %t309, i32 0, i32 10
  %t313 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t311)
  %t314 = extractvalue { i32, i64 } %t313, 1
  %t315 = extractvalue { i32, i64 } %t313, 0
  store i32 %t315, ptr %l167
  %t316 = icmp ne i32 %t315, 0
  br i1 %t316, label %bb59, label %ok.317, !prof !99
ok.317:
  store i64 %t314, ptr %l166
  br label %bb58
bb58:
  %t318 = load i64, ptr %l166, !tbaa !24
  store i64 %t318, ptr %l163, !tbaa !24
  br label %bb61
bb59:
  br label %bb60
bb60:
  call void @__olang_ert_req_clear()
  br label %bb61
bb61:
  %t319 = load ptr, ptr %l4, !tbaa !29
  %t321 = getelementptr %"compiler/check:frame", ptr %t319, i32 0, i32 11
  %t323 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t321)
  %t324 = extractvalue { i32, i64 } %t323, 1
  %t325 = extractvalue { i32, i64 } %t323, 0
  store i32 %t325, ptr %l172
  %t326 = icmp ne i32 %t325, 0
  br i1 %t326, label %bb63, label %ok.327, !prof !99
ok.327:
  store i64 %t324, ptr %l171
  br label %bb62
bb62:
  %t328 = load i64, ptr %l171, !tbaa !24
  store i64 %t328, ptr %l168, !tbaa !24
  br label %bb65
bb63:
  br label %bb64
bb64:
  call void @__olang_ert_req_clear()
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb66:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i64, ptr %l5, !tbaa !24
  %t331 = load i64, ptr %l17, !tbaa !24
  %t332 = load ptr, ptr %l16, !tbaa !29
  %t337 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v0, ptr %t329, i64 %t330, i64 %t331, ptr %t332)
  store i64 %t337, ptr %l177
  br label %bb67
bb67:
  %t338 = load i64, ptr %l177, !tbaa !24
  store i64 %t338, ptr %l23, !tbaa !24
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l178, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t340, ptr %l179
  %t341 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t341, ptr %l180
  %t342 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t342, ptr %l181, !tbaa !23
  %t343 = load ptr, ptr %l15, !tbaa !29
  store ptr %t343, ptr %l183, !tbaa !29
  %t345 = load ptr, ptr %l16, !tbaa !29
  %t347 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v0, ptr %t345)
  store { i64, ptr } %t347, ptr %l185
  br label %bb68
bb68:
  %t348 = load i64, ptr %l23, !tbaa !24
  %t350 = icmp sgt i64 %t348, 0
  %t351 = load ptr, ptr %l183, !tbaa !29
  %t352 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t354 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t351, { i64, ptr } %t352, i1 false, i1 false, i1 %t350)
  store %"compiler/typed:Try" %t354, ptr %l188
  br label %bb69
bb69:
  %t355 = load %"compiler/typed:Try", ptr %l188
  %t356 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t355, ptr %t356
  store { i64, [5 x i64] } zeroinitializer, ptr %t357
  %t358 = getelementptr { i64, [5 x i64] }, ptr %t357, i32 0, i32 0
  store i64 14, ptr %t358
  %t359 = load %"compiler/source:Span", ptr %l180
  %t360 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t359, 0
  %t361 = load i32, ptr %l181, !tbaa !23
  %t362 = insertvalue { %"compiler/source:Span", i32, ptr } %t360, i32 %t361, 1
  %t364 = insertvalue { %"compiler/source:Span", i32, ptr } %t362, ptr %t356, 2
  %t365 = getelementptr { i64, [5 x i64] }, ptr %t357, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t364, ptr %t365
  %t366 = load { i64, [5 x i64] }, ptr %t357
  %t368 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t366, ptr %t368
  store { i64, [3 x i64] } zeroinitializer, ptr %t369
  %t370 = getelementptr { i64, [3 x i64] }, ptr %t369, i32 0, i32 0
  store i64 2, ptr %t370
  %t371 = load %"compiler/source:Span", ptr %l179
  %t372 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t371, 0
  %t374 = insertvalue { %"compiler/source:Span", ptr } %t372, ptr %t368, 1
  %t375 = getelementptr { i64, [3 x i64] }, ptr %t369, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t374, ptr %t375
  %t376 = load { i64, [3 x i64] }, ptr %t369
  %t378 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t376, ptr %t378
  %t379 = load ptr, ptr %l178, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t379, ptr %t378)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca i1
  %l43 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l50 = alloca i1
  %l58 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l86 = alloca ptr
  %l88 = alloca i1
  %l90 = alloca i1
  %l91 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l96 = alloca i32
  %l97 = alloca i64
  %l99 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l109 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l124 = alloca i32
  %l125 = alloca i64
  %l138 = alloca ptr
  %rv = alloca ptr
  %t173 = alloca { i64, [3 x i64] }, align 8
  %t231 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l3, !tbaa !21
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t2 = load ptr, ptr %l19, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l19, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l20, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 2 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Make", ptr %t26, i32 0, i32 2
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l29, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l2, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Make", ptr %t38, i32 0, i32 2
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb13, label %bb14
bb13:
  br label %bb25
bb14:
  br label %bb15
bb15:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l43, !tbaa !27
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l8, !tbaa !29
  %t63 = load ptr, ptr %l8, !tbaa !29
  %t65 = call i1 @compiler_2fcheck_2epureRead(ptr %v1, ptr %t63)
  store i1 %t65, ptr %l47
  br label %bb16
bb16:
  %t66 = load i1, ptr %l47, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb18:
  %t67 = load ptr, ptr %l8, !tbaa !29
  %t69 = call i1 @compiler_2fcheck_2eisLit(ptr %v1, ptr %t67)
  store i1 %t69, ptr %l50
  br label %bb19
bb19:
  %t70 = load i1, ptr %l50, !tbaa !21
  store i1 %t70, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l48, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb21, label %bb22
bb21:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb12
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb30:
  call void @__olang_check_failed(ptr @olang_loc_317381e6e3d2ca51_b8977c113f1a9cfd)
  unreachable
bb31:
  store i64 %a1, ptr %l9, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 36
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l58
  br label %bb32
bb32:
  %t87 = load i64, ptr %l58, !tbaa !24
  store i64 %t87, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb33, label %bb34
bb33:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb38
bb35:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l65, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb37
bb37:
  %t114 = load i64, ptr %l65, !tbaa !24
  store i64 %t114, ptr %l62, !tbaa !24
  br label %bb38
bb38:
  %t115 = load i64, ptr %l62, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb39
bb39:
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb40, label %bb41
bb40:
  br label %bb60
bb41:
  br label %bb42
bb42:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 36
  %t137 = load i64, ptr %l14, !tbaa !24
  %t140 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t136, i64 %t137)
  store ptr %t140, ptr %l86
  br label %bb43
bb43:
  %t141 = load ptr, ptr %l86, !tbaa !29
  store ptr %t141, ptr %l15, !tbaa !29
  %t142 = load i1, ptr %l3, !tbaa !21
  br i1 %t142, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb47
bb45:
  %t144 = load ptr, ptr %l15, !tbaa !29
  %t146 = call i1 @compiler_2fcheck_2eisLit(ptr %v0, ptr %t144)
  store i1 %t146, ptr %l90
  br label %bb46
bb46:
  %t147 = load i1, ptr %l90, !tbaa !21
  store i1 %t147, ptr %l88, !tbaa !21
  br label %bb47
bb47:
  %t148 = load i1, ptr %l88, !tbaa !21
  br i1 %t148, label %bb48, label %bb49
bb48:
  br label %bb59
bb49:
  br label %bb50
bb50:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l91, !tbaa !29
  %t150 = load ptr, ptr %l15, !tbaa !29
  %t152 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t150)
  store %"compiler/source:Span" %t152, ptr %l93
  br label %bb51
bb51:
  %t153 = load ptr, ptr %l15, !tbaa !29
  %t156 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t153)
  store i32 %t156, ptr %l96
  br label %bb52
bb52:
  %t157 = load ptr, ptr %l91, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l93
  %t159 = load i32, ptr %l96, !tbaa !23
  %t160 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t157, %"compiler/source:Span" %t158, i32 %t159)
  store i64 %t160, ptr %l97
  br label %bb53
bb53:
  %t161 = load i64, ptr %l97, !tbaa !24
  store i64 %t161, ptr %l16, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 37
  store ptr %t164, ptr %l99, !tbaa !29
  %t165 = load ptr, ptr %l15, !tbaa !29
  %t167 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t165)
  store %"compiler/source:Span" %t167, ptr %l101
  br label %bb54
bb54:
  %t168 = load i64, ptr %l16, !tbaa !24
  %t170 = trunc i64 %t168 to i32
  %t172 = load ptr, ptr %l15, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 0
  store i64 0, ptr %t174
  %t175 = load %"compiler/source:Span", ptr %l101
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t175, 0
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, i32 %t170, 1
  %t180 = insertvalue { %"compiler/source:Span", i32, ptr } %t178, ptr %t172, 2
  %t181 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t180, ptr %t181
  %t182 = load { i64, [3 x i64] }, ptr %t173
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t182, ptr %t184
  %t185 = load ptr, ptr %l99, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t185, ptr %t184)
  br label %bb55
bb55:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 36
  store ptr %t189, ptr %l109, !tbaa !29
  %t190 = load i64, ptr %l14, !tbaa !24
  store i64 %t190, ptr %l110, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l111, !tbaa !29
  %t192 = load ptr, ptr %l15, !tbaa !29
  %t194 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t192)
  store %"compiler/source:Span" %t194, ptr %l113
  br label %bb56
bb56:
  %t195 = load i64, ptr %l16, !tbaa !24
  %t196 = load ptr, ptr %l111, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l113
  %t199 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t196, %"compiler/source:Span" %t197, i64 %t195)
  store ptr %t199, ptr %l115
  br label %bb57
bb57:
  %t200 = load ptr, ptr %l109, !tbaa !29
  %t201 = load i64, ptr %l110, !tbaa !24
  %t202 = load ptr, ptr %l115, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t200, i64 %t201, ptr %t202)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t203 = load i64, ptr %l13, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l13, !tbaa !24
  br label %bb39
bb60:
  %t207 = load ptr, ptr %l2, !tbaa !29
  %t209 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t207)
  store %"compiler/source:Span" %t209, ptr %l119
  br label %bb61
bb61:
  %t210 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t210, ptr %l17
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l120, !tbaa !29
  %t212 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t212, ptr %l121
  %t213 = load ptr, ptr %l2, !tbaa !29
  %t216 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t213)
  store i32 %t216, ptr %l124
  br label %bb62
bb62:
  %t217 = load ptr, ptr %l120, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l121
  %t219 = load i32, ptr %l124, !tbaa !23
  %t220 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t217, %"compiler/source:Span" %t218, i32 %t219)
  store i64 %t220, ptr %l125
  br label %bb63
bb63:
  %t221 = load i64, ptr %l125, !tbaa !24
  store i64 %t221, ptr %l18, !tbaa !24
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 37
  %t225 = load %"compiler/source:Span", ptr %l17
  %t226 = load i64, ptr %l18, !tbaa !24
  %t228 = trunc i64 %t226 to i32
  %t230 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [3 x i64] }, ptr %t231, i32 0, i32 0
  store i64 0, ptr %t232
  %t234 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t225, 0
  %t236 = insertvalue { %"compiler/source:Span", i32, ptr } %t234, i32 %t228, 1
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } %t236, ptr %t230, 2
  %t239 = getelementptr { i64, [3 x i64] }, ptr %t231, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t238, ptr %t239
  %t240 = load { i64, [3 x i64] }, ptr %t231
  %t242 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t240, ptr %t242
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t224, ptr %t242)
  br label %bb64
bb64:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l17
  %t247 = load i64, ptr %l18, !tbaa !24
  %t251 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t245, %"compiler/source:Span" %t246, i64 %t247)
  store ptr %t251, ptr %l138
  br label %bb65
bb65:
  %t252 = load ptr, ptr %l138, !tbaa !29
  store ptr %t252, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l22 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %rv = alloca ptr
  %t28 = alloca { i64, [1 x i64] }, align 8
  %t45 = alloca { i64, [3 x i64] }, align 8
  %t68 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v2, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l3, !tbaa !29
  store ptr %t11, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb15
bb4:
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 8}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t20 = load ptr, ptr %l3, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ab1100555885b989_2cac6a0e3d43e9fd)
  unreachable
bb14:
  br label %bb15
bb15:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t23, ptr %l16
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t27 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t24)
  store i32 %t27, ptr %l19
  br label %bb16
bb16:
  store { i64, [1 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t30 = load { i64, [1 x i64] }, ptr %t28
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l16
  %t33 = load i32, ptr %l19, !tbaa !23
  %t36 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t31, i32 0, %"compiler/source:Span" %t32, i32 %t33, i32 2, { i64, [1 x i64] } %t30)
  store i64 %t36, ptr %l22
  br label %bb17
bb17:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = trunc i64 %t40 to i32
  %t44 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t45
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t45, i32 0, i32 0
  store i64 0, ptr %t46
  %t48 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t39, 0
  %t50 = insertvalue { %"compiler/source:Span", i32, ptr } %t48, i32 %t42, 1
  %t52 = insertvalue { %"compiler/source:Span", i32, ptr } %t50, ptr %t44, 2
  %t53 = getelementptr { i64, [3 x i64] }, ptr %t45, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t52, ptr %t53
  %t54 = load { i64, [3 x i64] }, ptr %t45
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t54, ptr %t56
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t38, ptr %t56)
  br label %bb18
bb18:
  %t59 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t59, ptr %l31
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t63 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t60)
  store i32 %t63, ptr %l34
  br label %bb19
bb19:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t66 = trunc i64 %t64 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 0
  store i64 0, ptr %t69
  %t70 = load %"compiler/source:Span", ptr %l31
  %t71 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t70, 0
  %t72 = load i32, ptr %l34, !tbaa !23
  %t73 = insertvalue { %"compiler/source:Span", i32, i32 } %t71, i32 %t72, 1
  %t75 = insertvalue { %"compiler/source:Span", i32, i32 } %t73, i32 %t66, 2
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t75, ptr %t76
  %t77 = load { i64, [4 x i64] }, ptr %t68
  %t79 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t77, ptr %t79
  store ptr %t79, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejump(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l9 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca %"compiler/diagmsg:Msg"
  %l28 = alloca i64
  %l32 = alloca i1
  %l35 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca %"compiler/diagmsg:Msg"
  %l50 = alloca i64
  %l54 = alloca i1
  %l57 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"compiler/diagmsg:Msg"
  %l68 = alloca i64
  %l71 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l79 = alloca %"compiler/diagmsg:Msg"
  %l80 = alloca i64
  %l82 = alloca ptr
  %l85 = alloca i64
  %l87 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l92 = alloca %"compiler/diagmsg:Msg"
  %l93 = alloca i64
  %l97 = alloca ptr
  %l100 = alloca i64
  %l102 = alloca i64
  %l105 = alloca i32
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca i32
  %l123 = alloca ptr
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t228 = alloca { i64, [3 x i64] }, align 8
  %t254 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t3 = trunc i64 19 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t8 = trunc i64 20 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l9, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t12)
  store ptr %t14, ptr %l13
  br label %bb6
bb5:
  br label %bb65
bb6:
  %t15 = load ptr, ptr %l13, !tbaa !29
  store ptr %t15, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t16, i32 0, i32 10
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l16
  br label %bb7
bb7:
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = icmp eq i64 %t21, 0
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t24, i32 0, i32 32
  %t27 = load i1, ptr %t26, !tbaa !21
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t31, ptr %l22
  %t32 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t34 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t32)
  store { i64, ptr } %t34, ptr %l24
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t35 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t36 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s2, ptr %s2, { i64, ptr } %t35)
  store { i64, ptr } %t36, ptr %l25
  br label %bb14
bb14:
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = mul i64 %t38, 1
  %t41 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  %t45 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskClauseLoopJump(ptr %s2, ptr %s2, { i64, ptr } %t43)
  store %"compiler/diagmsg:Msg" %t45, ptr %l27
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l22
  %t48 = load %"compiler/diagmsg:Msg", ptr %l27
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t46, %"compiler/source:Span" %t47, %"compiler/diagmsg:Msg" %t48)
  store i64 %t49, ptr %l28
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb17:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 35
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp sge i64 %t53, 0
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 10
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t59)
  store i64 %t61, ptr %l35
  br label %bb20
bb19:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb21
bb20:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/check:frame", ptr %t62, i32 0, i32 35
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = load i64, ptr %l35, !tbaa !24
  %t68 = icmp sle i64 %t66, %t65
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t70 = load i1, ptr %l32, !tbaa !21
  br i1 %t70, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t72, ptr %l40
  %t73 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t75 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s3, i32 %t73)
  store { i64, ptr } %t75, ptr %l42
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t76 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t77 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s3, ptr %s3, { i64, ptr } %t76)
  store { i64, ptr } %t77, ptr %l43
  br label %bb25
bb25:
  %t78 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l44, !tbaa !27
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/check:frame", ptr %t86, i32 0, i32 36
  %t89 = load i1, ptr %t88, !tbaa !21
  %t92 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %s3, ptr %t85, i1 %t89)
  store { i64, ptr } %t92, ptr %l48
  br label %bb26
bb26:
  %t93 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t95 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAssertMsgLoopJump(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t93, { i64, ptr } %t94)
  store %"compiler/diagmsg:Msg" %t95, ptr %l49
  br label %bb27
bb27:
  %t96 = load ptr, ptr %l39, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l40
  %t98 = load %"compiler/diagmsg:Msg", ptr %l49
  %t99 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t96, %"compiler/source:Span" %t97, %"compiler/diagmsg:Msg" %t98)
  store i64 %t99, ptr %l50
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb29:
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t102 = getelementptr %"compiler/check:frame", ptr %t100, i32 0, i32 34
  %t103 = load i64, ptr %t102, !tbaa !24
  %t105 = icmp sge i64 %t103, 0
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t107 = load ptr, ptr %l4, !tbaa !29
  %t109 = getelementptr %"compiler/check:frame", ptr %t107, i32 0, i32 10
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l57
  br label %bb32
bb31:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb33
bb32:
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t114 = getelementptr %"compiler/check:frame", ptr %t112, i32 0, i32 34
  %t115 = load i64, ptr %t114, !tbaa !24
  %t116 = load i64, ptr %l57, !tbaa !24
  %t118 = icmp sle i64 %t116, %t115
  store i1 %t118, ptr %l54, !tbaa !21
  br label %bb33
bb33:
  %t120 = load i1, ptr %l54, !tbaa !21
  br i1 %t120, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s4
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l61, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t122, ptr %l62
  %t123 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t125 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s4, i32 %t123)
  store { i64, ptr } %t125, ptr %l64
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t126 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t127 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s4, ptr %s4, { i64, ptr } %t126)
  store { i64, ptr } %t127, ptr %l65
  br label %bb37
bb37:
  %t128 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDeferLoopJump(ptr %s4, ptr %s4, { i64, ptr } %t134)
  store %"compiler/diagmsg:Msg" %t136, ptr %l67
  br label %bb38
bb38:
  %t137 = load ptr, ptr %l61, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l62
  %t139 = load %"compiler/diagmsg:Msg", ptr %l67
  %t140 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t137, %"compiler/source:Span" %t138, %"compiler/diagmsg:Msg" %t139)
  store i64 %t140, ptr %l68
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb40:
  %t141 = load ptr, ptr %l4, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t141, i32 0, i32 10
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t143)
  store i64 %t145, ptr %l71
  br label %bb41
bb41:
  %t146 = load i64, ptr %l71, !tbaa !24
  %t147 = icmp eq i64 %t146, 0
  br i1 %t147, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s5
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l73, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t150, ptr %l74
  %t151 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t153 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s5, i32 %t151)
  store { i64, ptr } %t153, ptr %l76
  br label %bb44
bb43:
  br label %bb48
bb44:
  %t154 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t155 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s5, ptr %s5, { i64, ptr } %t154)
  store { i64, ptr } %t155, ptr %l77
  br label %bb45
bb45:
  %t156 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t164 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBreakOutsideLoop(ptr %s5, ptr %s5, { i64, ptr } %t162)
  store %"compiler/diagmsg:Msg" %t164, ptr %l79
  br label %bb46
bb46:
  %t165 = load ptr, ptr %l73, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l74
  %t167 = load %"compiler/diagmsg:Msg", ptr %l79
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t165, %"compiler/source:Span" %t166, %"compiler/diagmsg:Msg" %t167)
  store i64 %t168, ptr %l80
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %ret
bb48:
  %t169 = load ptr, ptr %l4, !tbaa !29
  %t171 = getelementptr %"compiler/check:frame", ptr %t169, i32 0, i32 10
  store ptr %t171, ptr %l82, !tbaa !29
  %t172 = load ptr, ptr %l4, !tbaa !29
  %t174 = getelementptr %"compiler/check:frame", ptr %t172, i32 0, i32 10
  %t176 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t174)
  store i64 %t176, ptr %l85
  br label %bb49
bb49:
  %t177 = load i64, ptr %l85, !tbaa !24
  %t178 = sub i64 %t177, 1
  %t179 = load ptr, ptr %l82, !tbaa !29
  %t181 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t179, i64 %t178)
  store i64 %t181, ptr %l87
  br label %bb50
bb50:
  %t182 = load i64, ptr %l87, !tbaa !24
  store i64 %t182, ptr %l5, !tbaa !24
  %t183 = load i64, ptr %l5, !tbaa !24
  %t185 = icmp eq i64 %t183, -2
  br i1 %t185, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s6
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l90, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t188, ptr %l91
  %t189 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInClauseExit(ptr %s6)
  store %"compiler/diagmsg:Msg" %t189, ptr %l92
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t190 = load ptr, ptr %l90, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l91
  %t192 = load %"compiler/diagmsg:Msg", ptr %l92
  %t193 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t190, %"compiler/source:Span" %t191, %"compiler/diagmsg:Msg" %t192)
  store i64 %t193, ptr %l93
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb55:
  %t194 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t196 = trunc i64 19 to i32
  %t197 = icmp eq i32 %t194, %t196
  br i1 %t197, label %bb56, label %bb57
bb56:
  %t199 = load ptr, ptr %l4, !tbaa !29
  %t201 = getelementptr %"compiler/check:frame", ptr %t199, i32 0, i32 11
  store ptr %t201, ptr %l97, !tbaa !29
  %t202 = load ptr, ptr %l4, !tbaa !29
  %t204 = getelementptr %"compiler/check:frame", ptr %t202, i32 0, i32 11
  %t206 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t204)
  store i64 %t206, ptr %l100
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t207 = load i64, ptr %l100, !tbaa !24
  %t208 = sub i64 %t207, 1
  %t209 = load ptr, ptr %l97, !tbaa !29
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t209, i64 %t208)
  store i64 %t211, ptr %l102
  br label %bb59
bb59:
  %t212 = load i64, ptr %l102, !tbaa !24
  store i64 %t212, ptr %l5, !tbaa !24
  br label %bb60
bb60:
  %t213 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t215 = trunc i64 19 to i32
  %t216 = icmp eq i32 %t213, %t215
  br i1 %t216, label %bb61, label %bb62
bb61:
  store i32 0, ptr %l105
  br label %bb63
bb62:
  store i32 1, ptr %l105
  br label %bb63
bb63:
  %t220 = load i32, ptr %l105, !range !{i32 0, i32 2}
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load %"compiler/source:Span", ptr %l1
  %t224 = load i64, ptr %l5, !tbaa !24
  %t226 = trunc i64 %t224 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t228
  %t229 = getelementptr { i64, [3 x i64] }, ptr %t228, i32 0, i32 0
  store i64 5, ptr %t229
  %t231 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t222, 0
  %t233 = insertvalue { %"compiler/source:Span", i32, i32 } %t231, i32 %t220, 1
  %t235 = insertvalue { %"compiler/source:Span", i32, i32 } %t233, i32 %t226, 2
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t228, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t235, ptr %t236
  %t237 = load { i64, [3 x i64] }, ptr %t228
  %t239 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t237, ptr %t239
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t221, ptr %t239)
  br label %bb64
bb64:
  br label %ret
bb65:
  %t242 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t244 = trunc i64 21 to i32
  %t245 = icmp eq i32 %t242, %t244
  br i1 %t245, label %bb66, label %bb67
bb66:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l118, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t248, ptr %l119
  store i32 0, ptr %l120
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t253 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v1, ptr %v0, ptr %t249, ptr %a3, i1 true)
  store ptr %t253, ptr %l123
  br label %bb68
bb67:
  br label %bb70
bb68:
  store { i64, [3 x i64] } zeroinitializer, ptr %t254
  %t255 = getelementptr { i64, [3 x i64] }, ptr %t254, i32 0, i32 0
  store i64 9, ptr %t255
  %t256 = load %"compiler/source:Span", ptr %l119
  %t257 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t256, 0
  %t258 = load i32, ptr %l120, !range !{i32 0, i32 2}
  %t259 = insertvalue { %"compiler/source:Span", i32, ptr } %t257, i32 %t258, 1
  %t260 = load ptr, ptr %l123, !tbaa !29
  %t261 = insertvalue { %"compiler/source:Span", i32, ptr } %t259, ptr %t260, 2
  %t262 = getelementptr { i64, [3 x i64] }, ptr %t254, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t261, ptr %t262
  %t263 = load { i64, [3 x i64] }, ptr %t254
  %t265 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t263, ptr %t265
  %t266 = load ptr, ptr %l118, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t266, ptr %t265)
  br label %bb69
bb69:
  br label %bb70
bb70:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t14, ptr %l8
  br label %bb2
bb2:
  %t15 = load i32, ptr %l8, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l7, !tbaa !23
  %t32 = load i32, ptr %l7, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l7, !tbaa !23
  %t41 = add i64 %a3, 1
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t36, i32 %t37, i32 %a2, i64 %t41)
  store i1 %t46, ptr %l30
  br label %bb8
bb7:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  %t47 = load i1, ptr %l30, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb2
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca %"compiler/check:litv"
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/check:litv" %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = getelementptr %"compiler/check:litv", ptr %l8, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t15 = load ptr, ptr %l11, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 30}
  %t18 = icmp eq i64 %t16, 2
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i1 %t30, ptr %l19
  br label %bb10
bb10:
  %t31 = load i1, ptr %l19, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 30}
  %t39 = icmp eq i64 %t37, 8
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l3, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t49, i32 0, i32 3
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  store i1 %t57, ptr %l30
  br label %bb17
bb17:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t63 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t59, ptr %t60)
  store i1 %t63, ptr %l34
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb21
bb20:
  %t64 = load i1, ptr %l34, !tbaa !21
  store i1 %t64, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t65 = load i1, ptr %l31, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_c608509fed4a7aab_41eb2a14c072322f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBinding(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l31 = alloca i64
  %l34 = alloca i64
  %l53 = alloca { i64, ptr }
  %l57 = alloca i1
  %l59 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l73 = alloca i32
  %l75 = alloca { i64, ptr }
  %l78 = alloca i1
  %l93 = alloca i32
  %l99 = alloca i64
  %l102 = alloca i64
  %l127 = alloca i1
  %l129 = alloca { i64, ptr }
  %l132 = alloca i1
  %l134 = alloca { i64, ptr }
  %l141 = alloca i32
  %l145 = alloca i1
  %l150 = alloca i64
  %l153 = alloca i1
  %l158 = alloca i64
  %l162 = alloca { i64, ptr }
  %l166 = alloca i1
  %l171 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca i64
  %l175 = alloca i64
  %l181 = alloca i32
  %l183 = alloca i1
  %l185 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l6, !tbaa !24
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Binding", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t6 = load i64, ptr %l7, !tbaa !24
  %t7 = load i64, ptr %l6, !tbaa !24
  %t10 = icmp sgt i64 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  %t14 = icmp sgt i64 %t12, 0
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb6
bb3:
  %t16 = load i64, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = sub i64 %t16, %t17
  %t21 = load i64, ptr %l8, !tbaa !24
  %t24 = add i64 %t20, %t21
  %t26 = sub i64 %t24, 1
  %t27 = load i64, ptr %l8, !tbaa !24
  %t30 = sdiv i64 %t26, %t27
  store i64 %t30, ptr %l34, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb5
bb5:
  %t32 = load i64, ptr %l34, !tbaa !24
  store i64 %t32, ptr %l31, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l31, !tbaa !24
  store i64 %t33, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l10, !tbaa !24
  %t35 = load i64, ptr %l9, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb8, label %bb9
bb8:
  br label %bb73
bb9:
  br label %bb10
bb10:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l10, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = mul i64 %t43, %t44
  %t50 = add i64 %t42, %t47
  store i64 %t50, ptr %l11, !tbaa !24
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Binding", ptr %t52, i32 0, i32 3
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l53, !tbaa !27
  %t56 = load i64, ptr %l11, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i1, ptr %t59, i64 %t56
  %t61 = load i1, ptr %t60, !tbaa !31
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb13
bb12:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Binding", ptr %t65, i32 0, i32 2
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l59, !tbaa !27
  %t69 = load i64, ptr %l11, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 %t69
  %t74 = load i32, ptr %t73, !tbaa !33
  %t75 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t78 = icmp eq i32 %t74, %t75
  store i1 %t78, ptr %l57, !tbaa !21
  br label %bb13
bb13:
  %t80 = load i1, ptr %l57, !tbaa !21
  br i1 %t80, label %bb14, label %bb15
bb14:
  br label %bb72
bb15:
  br label %bb16
bb16:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  store ptr %t84, ptr %l65, !tbaa !29
  %t85 = load i64, ptr %l1, !tbaa !24
  store i64 %t85, ptr %l66, !tbaa !24
  %t86 = load i64, ptr %l11, !tbaa !24
  store i64 %t86, ptr %l67, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Binding", ptr %t93, i32 0, i32 2
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t92, { i64, ptr } %t96)
  store i32 %t99, ptr %l73
  br label %bb17
bb17:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Binding", ptr %t100, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l75, !tbaa !27
  %t104 = load i64, ptr %l11, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 %t104
  %t109 = load i32, ptr %t108, !tbaa !33
  %t110 = load ptr, ptr %l65, !tbaa !29
  %t111 = load i64, ptr %l66, !tbaa !24
  %t112 = load i64, ptr %l67, !tbaa !24
  %t113 = load i32, ptr %l73, !tbaa !23
  %t115 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeetsBound(ptr %v0, ptr %t110, i64 %t111, i64 %t112, i32 %t113, i32 %t109)
  store i1 %t115, ptr %l78
  br label %bb18
bb18:
  %t116 = load i1, ptr %l78, !tbaa !21
  br i1 %t116, label %bb19, label %bb20
bb19:
  br label %bb72
bb20:
  br label %bb21
bb21:
  store ptr @G_2ecompiler_2fcheck_2eliteralOrder, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  %t118 = load ptr, ptr %l12
  store i64 12, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l13, !tbaa !24
  %t122 = load i64, ptr %l14, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb23, label %bb24
bb23:
  br label %bb71
bb24:
  br label %bb25
bb25:
  %t129 = load ptr, ptr %l12
  %t130 = load i64, ptr %l13, !tbaa !24
  %t133 = getelementptr [12 x { i64, ptr }], ptr %t129, i64 0, i64 %t130
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !37
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  %t143 = load ptr, ptr @__olang_prog_scope
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %t143, ptr %t141, { i64, ptr } %t134)
  store i32 %t146, ptr %l93
  br label %bb26
bb26:
  %t147 = load i32, ptr %l93, !tbaa !23
  store i32 %t147, ptr %l16, !tbaa !23
  store i1 true, ptr %l17, !tbaa !21
  store i64 0, ptr %l18, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  store i64 %t150, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t152 = load i64, ptr %l19, !tbaa !24
  %t153 = load i64, ptr %l18, !tbaa !24
  %t156 = icmp sgt i64 %t152, %t153
  br i1 %t156, label %bb27, label %bb28
bb27:
  %t158 = load i64, ptr %l20, !tbaa !24
  %t160 = icmp sgt i64 %t158, 0
  br i1 %t160, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb32
bb29:
  %t162 = load i64, ptr %l19, !tbaa !24
  %t163 = load i64, ptr %l18, !tbaa !24
  %t166 = sub i64 %t162, %t163
  %t167 = load i64, ptr %l20, !tbaa !24
  %t170 = add i64 %t166, %t167
  %t172 = sub i64 %t170, 1
  %t173 = load i64, ptr %l20, !tbaa !24
  %t176 = sdiv i64 %t172, %t173
  store i64 %t176, ptr %l102, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb31
bb31:
  %t178 = load i64, ptr %l102, !tbaa !24
  store i64 %t178, ptr %l99, !tbaa !24
  br label %bb32
bb32:
  %t179 = load i64, ptr %l99, !tbaa !24
  store i64 %t179, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb33
bb33:
  %t180 = load i64, ptr %l22, !tbaa !24
  %t181 = load i64, ptr %l21, !tbaa !24
  %t184 = icmp slt i64 %t180, %t181
  %t186 = xor i1 %t184, true
  br i1 %t186, label %bb34, label %bb35
bb34:
  br label %bb61
bb35:
  br label %bb36
bb36:
  %t188 = load i64, ptr %l18, !tbaa !24
  %t189 = load i64, ptr %l22, !tbaa !24
  %t190 = load i64, ptr %l20, !tbaa !24
  %t193 = mul i64 %t189, %t190
  %t196 = add i64 %t188, %t193
  store i64 %t196, ptr %l23, !tbaa !24
  %t198 = load i64, ptr %l23, !tbaa !24
  %t202 = add i64 %t198, %a4
  store i64 %t202, ptr %l24, !tbaa !24
  %t204 = load i64, ptr %l24, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t210 = icmp sge i64 %t204, %t207
  br i1 %t210, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb40
bb38:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t213, ptr %l129, !tbaa !27
  %t214 = load i64, ptr %l23, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 %t214
  %t219 = load ptr, ptr %t218, !tbaa !39
  %t222 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t212, ptr %t219)
  store i1 %t222, ptr %l132
  br label %bb39
bb39:
  %t223 = load i1, ptr %l132, !tbaa !21
  %t224 = xor i1 %t223, true
  store i1 %t224, ptr %l127, !tbaa !21
  br label %bb40
bb40:
  %t226 = load i1, ptr %l127, !tbaa !21
  br i1 %t226, label %bb41, label %bb42
bb41:
  br label %bb60
bb42:
  br label %bb43
bb43:
  %t227 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t227, ptr %l134, !tbaa !27
  %t228 = load i64, ptr %l24, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i32, ptr %t231, i64 %t228
  %t233 = load i32, ptr %t232, !tbaa !33
  store i32 %t233, ptr %l25, !tbaa !23
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/generic:Program", ptr %t238, i32 0, i32 2
  %t241 = load i32, ptr %l25, !tbaa !23
  %t244 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t240, i32 %t241)
  store i32 %t244, ptr %l141
  br label %bb44
bb44:
  %t245 = load i32, ptr %l141, !range !{i32 0, i32 33}
  %t247 = trunc i64 25 to i32
  %t248 = icmp eq i32 %t245, %t247
  %t250 = xor i1 %t248, true
  br i1 %t250, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb48
bb46:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = getelementptr %"compiler/generic:Program", ptr %t255, i32 0, i32 2
  %t258 = load i32, ptr %l25, !tbaa !23
  %t261 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t257, i32 %t258)
  store i64 %t261, ptr %l150
  br label %bb47
bb47:
  %t262 = load i64, ptr %l1, !tbaa !24
  %t263 = load i64, ptr %l150, !tbaa !24
  %t265 = icmp ne i64 %t263, %t262
  store i1 %t265, ptr %l145, !tbaa !21
  br label %bb48
bb48:
  %t267 = load i1, ptr %l145, !tbaa !21
  br i1 %t267, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb52
bb50:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 2
  %t274 = load i32, ptr %l25, !tbaa !23
  %t277 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t273, i32 %t274)
  store i64 %t277, ptr %l158
  br label %bb51
bb51:
  %t278 = load i64, ptr %l11, !tbaa !24
  %t279 = load i64, ptr %l158, !tbaa !24
  %t281 = icmp ne i64 %t279, %t278
  store i1 %t281, ptr %l153, !tbaa !21
  br label %bb52
bb52:
  %t283 = load i1, ptr %l153, !tbaa !21
  br i1 %t283, label %bb53, label %bb54
bb53:
  br label %bb60
bb54:
  br label %bb55
bb55:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t285, ptr %l162, !tbaa !27
  %t286 = load i64, ptr %l23, !tbaa !24
  %t288 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr ptr, ptr %t289, i64 %t286
  %t291 = load ptr, ptr %t290, !tbaa !39
  %t292 = load i32, ptr %l16, !tbaa !23
  %t296 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v3, ptr %t284, ptr %t291, i32 %t292)
  store i1 %t296, ptr %l166
  br label %bb56
bb56:
  %t297 = load i1, ptr %l166, !tbaa !21
  %t298 = xor i1 %t297, true
  br i1 %t298, label %bb57, label %bb58
bb57:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb59
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t300 = load i64, ptr %l22, !tbaa !24
  %t302 = add i64 %t300, 1
  store i64 %t302, ptr %l22, !tbaa !24
  br label %bb33
bb61:
  %t304 = load i1, ptr %l17, !tbaa !21
  br i1 %t304, label %bb62, label %bb63
bb62:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/check:Checker", ptr %t306, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !29
  store ptr %t309, ptr %l173, !tbaa !29
  %t310 = load i64, ptr %l1, !tbaa !24
  store i64 %t310, ptr %l174, !tbaa !24
  %t311 = load i64, ptr %l11, !tbaa !24
  store i64 %t311, ptr %l175, !tbaa !24
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/check:Checker", ptr %t312, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 2
  %t318 = load ptr, ptr %l2, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Binding", ptr %t318, i32 0, i32 2
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !27
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t317, { i64, ptr } %t321)
  store i32 %t324, ptr %l181
  br label %bb64
bb63:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb66
bb64:
  %t325 = load i32, ptr %l16, !tbaa !23
  %t326 = load ptr, ptr %l173, !tbaa !29
  %t327 = load i64, ptr %l174, !tbaa !24
  %t328 = load i64, ptr %l175, !tbaa !24
  %t329 = load i32, ptr %l181, !tbaa !23
  %t331 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeetsBound(ptr %v0, ptr %t326, i64 %t327, i64 %t328, i32 %t329, i32 %t325)
  store i1 %t331, ptr %l183
  br label %bb65
bb65:
  %t332 = load i1, ptr %l183, !tbaa !21
  store i1 %t332, ptr %l171, !tbaa !21
  br label %bb66
bb66:
  %t333 = load i1, ptr %l171, !tbaa !21
  br i1 %t333, label %bb67, label %bb68
bb67:
  %t334 = load ptr, ptr %l2, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Binding", ptr %t334, i32 0, i32 2
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l185, !tbaa !27
  %t338 = load i64, ptr %l11, !tbaa !24
  %t339 = load i32, ptr %l16, !tbaa !23
  %t342 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr i32, ptr %t343, i64 %t338
  store i32 %t339, ptr %t344, !tbaa !33
  br label %bb71
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t345 = load i64, ptr %l13, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l13, !tbaa !24
  br label %bb22
bb71:
  br label %bb72
bb72:
  %t349 = load i64, ptr %l10, !tbaa !24
  %t351 = add i64 %t349, 1
  store i64 %t351, ptr %l10, !tbaa !24
  br label %bb7
bb73:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchElse(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, i1 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i1
  %l31 = alloca ptr
  %l35 = alloca i32
  %l39 = alloca { i64, ptr }
  %l40 = alloca %"compiler/typed:Block"
  %l42 = alloca %"compiler/source:Span"
  %l47 = alloca %"compiler/typed:Arm"
  %rv = alloca ptr
  %t19 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l7, !tbaa !24
  %t7 = load i1, ptr %l5, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb4
bb3:
  %t9 = load i1, ptr %l6, !tbaa !21
  store i1 %t9, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  %t11 = load i1, ptr %l13, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 37
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Match", ptr %t15, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store { i64, [3 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 0
  store i64 9, ptr %t20
  %t22 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t18, 0
  %t24 = insertvalue { %"compiler/source:Span", i32, ptr } %t22, i32 0, 1
  %t25 = insertvalue { %"compiler/source:Span", i32, ptr } %t24, ptr null, 2
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t19, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t25, ptr %t26
  %t27 = load { i64, [3 x i64] }, ptr %t19
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t27, ptr %t29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t14, ptr %t29)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t32 = load i1, ptr %l5, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t41 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esayUncovered(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t36, ptr %t37, i32 %a2, ptr %a3, ptr %a4, i1 %t41)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t48)
  store ptr %t50, ptr %l31
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l31, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 7
  %t54 = load i64, ptr %t53, !tbaa !24
  %t56 = trunc i64 %t54 to i32
  store i32 %t56, ptr %l35, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 37
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store { i64, ptr } %t64, ptr %l39
  br label %bb14
bb14:
  %t65 = load i32, ptr %l35, !tbaa !23
  %t66 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t67 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v4, i32 %t65, { i64, ptr } %t66)
  store %"compiler/typed:Block" %t67, ptr %l40
  br label %bb15
bb15:
  %t68 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 24, i64 8)
  store ptr %t68, ptr %lp8
  %t69 = load %"compiler/typed:Block", ptr %l40
  %t70 = load ptr, ptr %lp8
  store %"compiler/typed:Block" %t69, ptr %t70
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Match", ptr %t71, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l42
  %t75 = icmp sge i64 0, 0
  br i1 %t75, label %bb16, label %bb17
bb16:
  %t77 = icmp sle i64 0, 1152921504606846975
  br i1 %t77, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_3cc47694b244d9ce_439392ee5cdf31e2)
  unreachable
bb18:
  %t79 = mul i64 0, 8
  %t80 = insertvalue { i64, ptr } undef, i64 0, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t82 = load ptr, ptr %lp8
  %t83 = load %"compiler/source:Span", ptr %l42
  %t86 = call %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, %"compiler/source:Span" %t83, { i64, ptr } %t81, ptr null, ptr %t82, ptr null)
  store %"compiler/typed:Arm" %t86, ptr %l47
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3cc47694b244d9ce_439392ee5cdf31e2)
  unreachable
bb20:
  %t87 = load %"compiler/typed:Arm", ptr %l47
  %t88 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store %"compiler/typed:Arm" %t87, ptr %t88
  store ptr %t88, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembership(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/generic:Binding"
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l36 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i32
  %l47 = alloca i32
  %l52 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca i64
  %l70 = alloca ptr
  %l73 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i32
  %l79 = alloca { i64, ptr }
  %l81 = alloca i64
  %l85 = alloca i64
  %l91 = alloca { i64, ptr }
  %l93 = alloca i32
  %l98 = alloca { i64, ptr }
  %l100 = alloca i32
  %l106 = alloca %"compiler/generic:Binding"
  %l107 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l112 = alloca i32
  %l117 = alloca i32
  %l122 = alloca ptr
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca i32
  %l132 = alloca i1
  %l133 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l135 = alloca i32
  %l136 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l141 = alloca %"compiler/source:Span"
  %l142 = alloca %"compiler/source:Span"
  %l143 = alloca i64
  %l146 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l154 = alloca %"compiler/source:Span"
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca i1
  %l160 = alloca ptr
  %l163 = alloca ptr
  %l164 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l168 = alloca %"compiler/source:Span"
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca i32
  %l173 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l179 = alloca %"compiler/diagmsg:Msg"
  %l180 = alloca i64
  %l184 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca ptr
  %l190 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l194 = alloca ptr
  %l195 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l199 = alloca %"compiler/source:Span"
  %l200 = alloca %"compiler/source:Span"
  %l201 = alloca ptr
  %l202 = alloca %"compiler/source:Span"
  %l205 = alloca i32
  %l206 = alloca i64
  %l209 = alloca i64
  %l219 = alloca ptr
  %l220 = alloca %"compiler/source:Span"
  %l221 = alloca %"compiler/source:Span"
  %l222 = alloca i64
  %l224 = alloca ptr
  %l227 = alloca { i64, ptr }
  %l228 = alloca ptr
  %l232 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l238 = alloca %"compiler/source:Span"
  %l241 = alloca i32
  %l245 = alloca { i64, ptr }
  %l248 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t415 = alloca { i64, [3 x i64] }, align 8
  %t489 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v3, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l23
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l23, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l24, !tbaa !29
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t11)
  store i32 %t14, ptr %l27
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l24, !tbaa !29
  %t16 = load i32, ptr %l27, !tbaa !23
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t17, ptr %l28
  br label %bb3
bb3:
  %t18 = load i32, ptr %l28, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load i32, ptr %l5, !tbaa !23
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = icmp eq i32 %t19, %t20
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t25, ptr %t26, i32 %t28)
  store ptr %t32, ptr %l36
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t33, %"compiler/source:Span" %t34, i32 %t35, i64 0)
  store ptr %t39, ptr %l40
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load ptr, ptr %l40, !tbaa !29
  store ptr %t40, ptr %rv
  br label %ret
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l43
  br label %bb9
bb9:
  %t46 = load i32, ptr %l43, !tbaa !23
  store i32 %t46, ptr %l6, !tbaa !23
  %t47 = load i32, ptr %l6, !tbaa !23
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t51 = icmp ne i32 %t47, %t48
  br i1 %t51, label %bb10, label %bb11
bb10:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l6, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l52
  br label %bb12
bb11:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t63, ptr %l47, !tbaa !23
  br label %bb13
bb12:
  %t65 = load i32, ptr %l52, !tbaa !23
  store i32 %t65, ptr %l47, !tbaa !23
  br label %bb13
bb13:
  %t66 = load i32, ptr %l47, !tbaa !23
  store i32 %t66, ptr %l7, !tbaa !23
  %t67 = load i32, ptr %l6, !tbaa !23
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t71 = icmp eq i32 %t67, %t68
  br i1 %t71, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l57, !tbaa !29
  %t74 = load i32, ptr %l5, !tbaa !23
  store i32 %t74, ptr %l58, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l59, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t76)
  store %"compiler/source:Span" %t78, ptr %l61
  br label %bb16
bb15:
  br label %bb43
bb16:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t79)
  store %"compiler/source:Span" %t81, ptr %l63
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l59, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l61
  %t84 = load %"compiler/source:Span", ptr %l63
  %t85 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t82, %"compiler/source:Span" %t83, %"compiler/source:Span" %t84, i64 2)
  store %"compiler/source:Span" %t85, ptr %l64
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l57, !tbaa !29
  %t87 = load i32, ptr %l58, !tbaa !23
  %t88 = load %"compiler/source:Span", ptr %l64
  %t89 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s2, ptr %s2, ptr %t86, i32 %t87, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t88, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i64 %t89, ptr %l65
  br label %bb19
bb19:
  %t90 = load i64, ptr %l65, !tbaa !24
  store i64 %t90, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = icmp sge i64 %t91, 0
  br i1 %t93, label %bb20, label %bb21
bb20:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 2
  store ptr %t100, ptr %l70, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l73, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t110, i64 %t111)
  store i32 %t114, ptr %l77
  br label %bb22
bb21:
  br label %bb42
bb22:
  %t115 = load ptr, ptr %l73, !tbaa !29
  %t116 = load i32, ptr %l77, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t117, ptr %l78
  br label %bb23
bb23:
  %t118 = load ptr, ptr %l70, !tbaa !29
  %t119 = load i32, ptr %l78, !tbaa !23
  %t120 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t118, i32 %t119)
  store { i64, ptr } %t120, ptr %l79
  br label %bb24
bb24:
  %t121 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t121, ptr %l9, !tbaa !27
  %t122 = load i64, ptr %l8, !tbaa !24
  %t124 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t122)
  store i64 %t124, ptr %l81
  br label %bb25
bb25:
  %t125 = load i64, ptr %l81, !tbaa !24
  store i64 %t125, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t129, i64 %t130)
  store i64 %t133, ptr %l85
  br label %bb26
bb26:
  %t134 = load i64, ptr %l85, !tbaa !24
  store i64 %t134, ptr %l11, !tbaa !24
  %t135 = load i64, ptr %l11, !tbaa !24
  %t137 = icmp eq i64 %t135, 0
  br i1 %t137, label %bb27, label %bb28
bb27:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t145, ptr %l91, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 1
  %t149 = load i32, ptr %t148, !tbaa !33
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t144, i32 %t149)
  store i32 %t152, ptr %l93
  br label %bb29
bb28:
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t157 = icmp sgt i64 %t155, 1
  br i1 %t157, label %bb34, label %bb35
bb29:
  %t159 = load i32, ptr %l93, !range !{i32 0, i32 33}
  %t161 = trunc i64 25 to i32
  %t162 = icmp eq i32 %t159, %t161
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb30, label %bb31
bb30:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t167, ptr %l98, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i32, ptr %t169, i64 1
  %t171 = load i32, ptr %t170, !tbaa !33
  %t174 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t166, i32 %t171)
  store i32 %t174, ptr %l100
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t175 = load i32, ptr %l100, !tbaa !23
  store i32 %t175, ptr %l7, !tbaa !23
  br label %bb33
bb33:
  br label %bb41
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t176 = load i64, ptr %l10, !tbaa !24
  %t177 = load i64, ptr %l11, !tbaa !24
  %t180 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s7, i64 %t176, i64 %t177)
  store %"compiler/generic:Binding" %t180, ptr %l106
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t181 = load %"compiler/generic:Binding", ptr %l106
  store %"compiler/generic:Binding" %t181, ptr %l12
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l107, !tbaa !29
  %t183 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t183, ptr %l108, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 0
  %t187 = load i32, ptr %t186, !tbaa !33
  store i32 %t187, ptr %l109, !tbaa !23
  %t188 = load ptr, ptr %l4, !tbaa !29
  %t191 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t188)
  store i32 %t191, ptr %l112
  br label %bb37
bb37:
  %t192 = load ptr, ptr %l107, !tbaa !29
  %t193 = load i32, ptr %l109, !tbaa !23
  %t194 = load i32, ptr %l112, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s7, ptr %t192, i32 %t193, i32 %t194, ptr %l12, i1 false, i1 true)
  br label %bb38
bb38:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t201 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v0, ptr %s7, ptr %t196, { i64, ptr } %t197, i64 1, ptr %l12)
  store i32 %t201, ptr %l117
  br label %bb39
bb39:
  %t202 = load i32, ptr %l117, !tbaa !23
  store i32 %t202, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t206 = load i32, ptr %l7, !tbaa !23
  %t210 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t203, ptr %t204, i32 %t206)
  store ptr %t210, ptr %l122
  br label %bb44
bb44:
  %t211 = load ptr, ptr %l122, !tbaa !29
  store ptr %t211, ptr %l13, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 2
  store ptr %t217, ptr %l125, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l126, !tbaa !29
  %t219 = load ptr, ptr %l13, !tbaa !29
  %t222 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t219)
  store i32 %t222, ptr %l129
  br label %bb45
bb45:
  %t223 = load ptr, ptr %l126, !tbaa !29
  %t224 = load i32, ptr %l129, !tbaa !23
  %t225 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t223, i32 %t224)
  store i32 %t225, ptr %l130
  br label %bb46
bb46:
  %t226 = load i32, ptr %l5, !tbaa !23
  %t227 = load ptr, ptr %l125, !tbaa !29
  %t228 = load i32, ptr %l130, !tbaa !23
  %t230 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t227, i32 %t228, i32 %t226)
  store i1 %t230, ptr %l132
  br label %bb47
bb47:
  %t231 = load i1, ptr %l132, !tbaa !21
  br i1 %t231, label %bb48, label %bb49
bb48:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l133, !tbaa !27
  br label %bb50
bb49:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l133, !tbaa !27
  br label %bb50
bb50:
  %t232 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t232, ptr %l14, !tbaa !27
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l134, !tbaa !29
  %t234 = load i32, ptr %l5, !tbaa !23
  store i32 %t234, ptr %l135, !tbaa !23
  %t235 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t235, ptr %l136, !tbaa !27
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l137, !tbaa !29
  %t237 = load ptr, ptr %l2, !tbaa !29
  %t239 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t237)
  store %"compiler/source:Span" %t239, ptr %l139
  br label %bb51
bb51:
  %t240 = load ptr, ptr %l3, !tbaa !29
  %t242 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t240)
  store %"compiler/source:Span" %t242, ptr %l141
  br label %bb52
bb52:
  %t243 = load ptr, ptr %l137, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l139
  %t245 = load %"compiler/source:Span", ptr %l141
  %t246 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t243, %"compiler/source:Span" %t244, %"compiler/source:Span" %t245, i64 2)
  store %"compiler/source:Span" %t246, ptr %l142
  br label %bb53
bb53:
  %t247 = load ptr, ptr @__olang_prog_scope
  %t248 = load ptr, ptr %l134, !tbaa !29
  %t249 = load i32, ptr %l135, !tbaa !23
  %t250 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t251 = load %"compiler/source:Span", ptr %l142
  %t252 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %t247, ptr %s0, ptr %t248, i32 %t249, { i64, ptr } %t250, i64 1, %"compiler/source:Span" %t251, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i64 %t252, ptr %l143
  br label %bb54
bb54:
  %t253 = load i64, ptr %l143, !tbaa !24
  store i64 %t253, ptr %l15, !tbaa !24
  %t254 = load i64, ptr %l15, !tbaa !24
  %t256 = icmp slt i64 %t254, 0
  br i1 %t256, label %bb55, label %bb56
bb55:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l147, !tbaa !29
  %t259 = load i32, ptr %l5, !tbaa !23
  store i32 %t259, ptr %l148, !tbaa !23
  %t260 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t260, ptr %l149, !tbaa !27
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l150, !tbaa !29
  %t262 = load ptr, ptr %l2, !tbaa !29
  %t264 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t262)
  store %"compiler/source:Span" %t264, ptr %l152
  br label %bb57
bb56:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb61
bb57:
  %t265 = load ptr, ptr %l3, !tbaa !29
  %t267 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t265)
  store %"compiler/source:Span" %t267, ptr %l154
  br label %bb58
bb58:
  %t268 = load ptr, ptr %l150, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l152
  %t270 = load %"compiler/source:Span", ptr %l154
  %t271 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t268, %"compiler/source:Span" %t269, %"compiler/source:Span" %t270, i64 2)
  store %"compiler/source:Span" %t271, ptr %l155
  br label %bb59
bb59:
  %t272 = load ptr, ptr @__olang_prog_scope
  %t273 = load ptr, ptr %l147, !tbaa !29
  %t274 = load i32, ptr %l148, !tbaa !23
  %t275 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t276 = load %"compiler/source:Span", ptr %l155
  %t277 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %t272, ptr %s0, ptr %t273, i32 %t274, { i64, ptr } %t275, %"compiler/source:Span" %t276, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d24, i32 0, i32 1) }, i64 1, i1 false)
  store i1 %t277, ptr %l156
  br label %bb60
bb60:
  %t278 = load i1, ptr %l156, !tbaa !21
  store i1 %t278, ptr %l146, !tbaa !21
  br label %bb61
bb61:
  %t279 = load i1, ptr %l146, !tbaa !21
  br i1 %t279, label %bb62, label %bb63
bb62:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load %"compiler/source:Span", ptr %l1
  %t282 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t286 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t280, %"compiler/source:Span" %t281, i32 %t282, i64 0)
  store ptr %t286, ptr %l160
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t287 = load ptr, ptr %l160, !tbaa !29
  store ptr %t287, ptr %rv
  br label %ret
bb65:
  %t288 = load i64, ptr %l15, !tbaa !24
  %t290 = icmp slt i64 %t288, 0
  br i1 %t290, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s9
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l163, !tbaa !29
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l164, !tbaa !29
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t296 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t294)
  store %"compiler/source:Span" %t296, ptr %l166
  br label %bb68
bb67:
  br label %bb75
bb68:
  %t297 = load ptr, ptr %l3, !tbaa !29
  %t299 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t297)
  store %"compiler/source:Span" %t299, ptr %l168
  br label %bb69
bb69:
  %t300 = load ptr, ptr %l164, !tbaa !29
  %t301 = load %"compiler/source:Span", ptr %l166
  %t302 = load %"compiler/source:Span", ptr %l168
  %t303 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t300, %"compiler/source:Span" %t301, %"compiler/source:Span" %t302, i64 2)
  store %"compiler/source:Span" %t303, ptr %l169
  br label %bb70
bb70:
  %t304 = load i32, ptr %l5, !tbaa !23
  store i32 %t304, ptr %l170, !tbaa !23
  %t305 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t305, 1
  %t308 = extractvalue { i64, ptr } %t305, 0
  %t309 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t311 = add i64 %t308, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t307, i64 %t308)
  %t313 = getelementptr i8, ptr %t312, i64 %t308
  call void @olang_textcopy(ptr %t313, ptr %t309, i64 %t310)
  %t314 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t312, 1
  %t317 = extractvalue { i64, ptr } %t315, 0
  %t318 = extractvalue { i64, ptr } %t315, 1
  %t319 = mul i64 %t317, 1
  %t320 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t319)
  call void @llvm.memcpy.p0.p0.i64(ptr %t320, ptr %t318, i64 %t319, i1 false)
  %t321 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t320, 1
  store { i64, ptr } %t322, ptr %l173, !tbaa !27
  %t323 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t323, ptr %l174, !tbaa !27
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load i32, ptr %l5, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t324, i32 %t325)
  store { i64, ptr } %t328, ptr %l177
  br label %bb71
bb71:
  %t329 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t336 = load ptr, ptr @__olang_prog_scope
  %t337 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t339 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMembershipNoMethod(ptr %t336, ptr %s9, ptr %s9, { i64, ptr } %t337, { i64, ptr } %t335)
  store %"compiler/diagmsg:Msg" %t339, ptr %l179
  br label %bb72
bb72:
  %t340 = load ptr, ptr %l163, !tbaa !29
  %t341 = load %"compiler/source:Span", ptr %l169
  %t342 = load i32, ptr %l170, !tbaa !23
  %t343 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t344 = load %"compiler/diagmsg:Msg", ptr %l179
  %t345 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s9, ptr %s9, ptr %t340, %"compiler/source:Span" %t341, i32 %t342, { i64, ptr } %t343, %"compiler/diagmsg:Msg" %t344)
  store i64 %t345, ptr %l180
  br label %bb73
bb73:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load %"compiler/source:Span", ptr %l1
  %t348 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t352 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t346, %"compiler/source:Span" %t347, i32 %t348, i64 0)
  store ptr %t352, ptr %l184
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t353 = load ptr, ptr %l184, !tbaa !29
  store ptr %t353, ptr %rv
  br label %ret
bb75:
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l185, !tbaa !29
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l186, !tbaa !29
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/check:Checker", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t360 = load i64, ptr %l15, !tbaa !24
  %t363 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t359, i64 %t360)
  store ptr %t363, ptr %l190
  br label %bb76
bb76:
  %t364 = load ptr, ptr %l190, !tbaa !29
  %t366 = getelementptr %"compiler/ast:Func", ptr %t364, i32 0, i32 2
  %t367 = load i32, ptr %t366, !tbaa !23
  %t368 = load ptr, ptr %l186, !tbaa !29
  %t370 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t368, i32 %t367)
  store { i64, ptr } %t370, ptr %l193
  br label %bb77
bb77:
  %t371 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t372 = load ptr, ptr %l185, !tbaa !29
  %t373 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 50
  store { i64, ptr } %t371, ptr %t373, !tbaa !27
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l194, !tbaa !29
  %t375 = load ptr, ptr %l0, !tbaa !29
  store ptr %t375, ptr %l195, !tbaa !29
  %t376 = load ptr, ptr %l2, !tbaa !29
  %t378 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t376)
  store %"compiler/source:Span" %t378, ptr %l197
  br label %bb78
bb78:
  %t379 = load ptr, ptr %l3, !tbaa !29
  %t381 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t379)
  store %"compiler/source:Span" %t381, ptr %l199
  br label %bb79
bb79:
  %t382 = load ptr, ptr %l195, !tbaa !29
  %t383 = load %"compiler/source:Span", ptr %l197
  %t384 = load %"compiler/source:Span", ptr %l199
  %t385 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t382, %"compiler/source:Span" %t383, %"compiler/source:Span" %t384, i64 2)
  store %"compiler/source:Span" %t385, ptr %l200
  br label %bb80
bb80:
  %t386 = load %"compiler/source:Span", ptr %l200
  %t387 = load ptr, ptr %l194, !tbaa !29
  %t388 = getelementptr %"compiler/check:Checker", ptr %t387, i32 0, i32 49
  store %"compiler/source:Span" %t386, ptr %t388
  %t389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t389, ptr %l201, !tbaa !29
  %t390 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t390, ptr %l202
  %t391 = load ptr, ptr %l13, !tbaa !29
  %t394 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t391)
  store i32 %t394, ptr %l205
  br label %bb81
bb81:
  %t395 = load ptr, ptr %l201, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l202
  %t397 = load i32, ptr %l205, !tbaa !23
  %t398 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t395, %"compiler/source:Span" %t396, i32 %t397)
  store i64 %t398, ptr %l206
  br label %bb82
bb82:
  %t399 = load i64, ptr %l206, !tbaa !24
  store i64 %t399, ptr %l16, !tbaa !24
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 37
  %t404 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t402)
  store i64 %t404, ptr %l209
  br label %bb83
bb83:
  %t405 = load i64, ptr %l209, !tbaa !24
  store i64 %t405, ptr %l17, !tbaa !24
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/check:Checker", ptr %t406, i32 0, i32 37
  %t409 = load %"compiler/source:Span", ptr %l1
  %t410 = load i64, ptr %l16, !tbaa !24
  %t412 = trunc i64 %t410 to i32
  %t414 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t415
  %t416 = getelementptr { i64, [3 x i64] }, ptr %t415, i32 0, i32 0
  store i64 0, ptr %t416
  %t418 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t409, 0
  %t420 = insertvalue { %"compiler/source:Span", i32, ptr } %t418, i32 %t412, 1
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr } %t420, ptr %t414, 2
  %t423 = getelementptr { i64, [3 x i64] }, ptr %t415, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t422, ptr %t423
  %t424 = load { i64, [3 x i64] }, ptr %t415
  %t426 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t424, ptr %t426
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t408, ptr %t426)
  br label %bb84
bb84:
  %t429 = load ptr, ptr %l0, !tbaa !29
  store ptr %t429, ptr %l219, !tbaa !29
  %t430 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t430, ptr %l220
  %t431 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t431, ptr %l221
  %t432 = load i64, ptr %l15, !tbaa !24
  store i64 %t432, ptr %l222, !tbaa !24
  %t433 = load ptr, ptr %l4, !tbaa !29
  store ptr %t433, ptr %l224, !tbaa !29
  %t435 = icmp sge i64 0, 0
  br i1 %t435, label %bb85, label %bb86
bb85:
  %t437 = icmp sle i64 0, 1152921504606846975
  br i1 %t437, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @olang_loc_1fa90a145069ae20_a62c963c9e2d6294)
  unreachable
bb87:
  %t439 = mul i64 0, 8
  %t440 = insertvalue { i64, ptr } undef, i64 0, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t441, ptr %l227, !tbaa !27
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l228, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load %"compiler/source:Span", ptr %l1
  %t445 = load i64, ptr %l16, !tbaa !24
  %t449 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t443, %"compiler/source:Span" %t444, i64 %t445)
  store ptr %t449, ptr %l232
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_1fa90a145069ae20_a62c963c9e2d6294)
  unreachable
bb89:
  %t450 = load ptr, ptr %l228, !tbaa !29
  %t451 = load ptr, ptr %l232, !tbaa !29
  %t452 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t450, ptr %t451)
  store { i64, ptr } %t452, ptr %l233
  br label %bb90
bb90:
  %t453 = icmp sge i64 0, 0
  br i1 %t453, label %bb91, label %bb92
bb91:
  %t455 = icmp sle i64 0, 2305843009213693951
  br i1 %t455, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_e5386246bf71864d_e9422de20f0d1fa1)
  unreachable
bb93:
  %t457 = mul i64 0, 4
  %t458 = insertvalue { i64, ptr } undef, i64 0, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t460 = load ptr, ptr %l219, !tbaa !29
  %t461 = load %"compiler/source:Span", ptr %l220
  %t462 = load %"compiler/source:Span", ptr %l221
  %t463 = load i64, ptr %l222, !tbaa !24
  %t464 = load ptr, ptr %l224, !tbaa !29
  %t465 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t466 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t468 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v3, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t460, %"compiler/source:Span" %t461, %"compiler/source:Span" %t462, i64 %t463, ptr %t464, { i64, ptr } %t465, { i64, ptr } %t466, { i64, ptr } %t459)
  store ptr %t468, ptr %l237
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_e5386246bf71864d_e9422de20f0d1fa1)
  unreachable
bb95:
  %t469 = load ptr, ptr %l237, !tbaa !29
  store ptr %t469, ptr %l18, !tbaa !29
  %t470 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t470, ptr %l238
  %t471 = load ptr, ptr %l18, !tbaa !29
  %t474 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t471)
  store i32 %t474, ptr %l241
  br label %bb96
bb96:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/check:Checker", ptr %t475, i32 0, i32 37
  %t478 = load i64, ptr %l17, !tbaa !24
  %t481 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t477, i64 %t478)
  store { i64, ptr } %t481, ptr %l245
  br label %bb97
bb97:
  %t482 = load ptr, ptr %l18, !tbaa !29
  %t484 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t486 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t484, ptr %t482, i1 false)
  store %"compiler/typed:Seq" %t486, ptr %l248
  br label %bb98
bb98:
  %t487 = load %"compiler/typed:Seq", ptr %l248
  %t488 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Seq" %t487, ptr %t488
  store { i64, [5 x i64] } zeroinitializer, ptr %t489
  %t490 = getelementptr { i64, [5 x i64] }, ptr %t489, i32 0, i32 0
  store i64 12, ptr %t490
  %t491 = load %"compiler/source:Span", ptr %l238
  %t492 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t491, 0
  %t493 = load i32, ptr %l241, !tbaa !23
  %t494 = insertvalue { %"compiler/source:Span", i32, ptr } %t492, i32 %t493, 1
  %t496 = insertvalue { %"compiler/source:Span", i32, ptr } %t494, ptr %t488, 2
  %t497 = getelementptr { i64, [5 x i64] }, ptr %t489, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t496, ptr %t497
  %t498 = load { i64, [5 x i64] }, ptr %t489
  %t500 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t498, ptr %t500
  call void @__olang_scope_close(ptr %s0)
  store ptr %t500, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedsCopy(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca %"compiler/generic:Origin"
  %l5 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l13 = alloca %"compiler/generic:Origin"
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l28 = alloca i32
  %l32 = alloca ptr
  %l38 = alloca { i64, [3 x i64] }
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/diagmsg:Msg"
  %l45 = alloca i64
  %l47 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l53 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca i64
  %l70 = alloca { i64, [3 x i64] }
  %l72 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  %t64 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t4, i64 %t5)
  store %"compiler/generic:Origin" %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load %"compiler/generic:Origin", ptr %l13
  store %"compiler/generic:Origin" %t9, ptr %l4
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l14, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l16, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l20
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %l20, !tbaa !24
  %t25 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t23, i64 %t24)
  store ptr %t25, ptr %l21
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l21, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %t28, !tbaa !23
  %t30 = load ptr, ptr %l14, !tbaa !29
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t30, i32 %t29)
  store { i64, ptr } %t32, ptr %l24
  br label %bb4
bb4:
  %t33 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t40 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueArg(ptr %v0, ptr %t34, i64 %t35, i32 %a3)
  store i32 %t40, ptr %l28
  br label %bb5
bb5:
  %t41 = load i32, ptr %l28, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/load:Loader", ptr %t48, i32 0, i32 4
  %t51 = load ptr, ptr %t50, !tbaa !29
  store ptr %t51, ptr %l32, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 0
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 1
  %t55 = getelementptr %"compiler/source:Span", ptr %t54, i32 0, i32 0
  %t56 = load i32, ptr %t55, !tbaa !23
  %t58 = sext i32 %t56 to i64
  %t59 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 1
  %t60 = getelementptr %"compiler/source:Span", ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  %t63 = sext i32 %t61 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 0
  store i64 3, ptr %t65
  %t67 = insertvalue { i64, i64, i64 } undef, i64 %t53, 0
  %t69 = insertvalue { i64, i64, i64 } %t67, i64 %t58, 1
  %t71 = insertvalue { i64, i64, i64 } %t69, i64 %t63, 2
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  store { i64, i64, i64 } %t71, ptr %t72
  %t73 = load { i64, [3 x i64] }, ptr %t64
  store { i64, [3 x i64] } %t73, ptr %l38
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t74, ptr %l39, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t79 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t75, i32 %t41)
  store { i64, ptr } %t79, ptr %l42
  br label %bb6
bb6:
  %t80 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t87 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t89 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueNeedsCopy(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t87, { i64, ptr } %t86)
  store %"compiler/diagmsg:Msg" %t89, ptr %l44
  br label %bb7
bb7:
  %t90 = load ptr, ptr %l32, !tbaa !29
  %t91 = load { i64, [3 x i64] }, ptr %l38
  %t92 = load %"compiler/diagmsg:Msg", ptr %l44
  %t93 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBare(ptr %v0, ptr %s0, ptr %t90, { i64, [3 x i64] } %t91, %"compiler/diagmsg:Msg" %t92)
  store i64 %t93, ptr %l45
  br label %bb8
bb8:
  %t94 = load i64, ptr %l45, !tbaa !24
  store i64 %t94, ptr %l7, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l47
  br label %bb9
bb9:
  %t98 = load i64, ptr %l47, !tbaa !24
  store i64 %t98, ptr %l8, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t101 = icmp sge i64 %t99, 0
  br i1 %t101, label %bb10, label %bb11
bb10:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l51, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  store ptr %t107, ptr %l53, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i64, ptr %l8, !tbaa !24
  %t115 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t111, i64 %t112)
  store i64 %t115, ptr %l57
  br label %bb12
bb11:
  %t116 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t116, ptr %l50, !tbaa !27
  br label %bb15
bb12:
  %t118 = load ptr, ptr %l53, !tbaa !29
  %t119 = load i64, ptr %l57, !tbaa !24
  %t120 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t118, i64 %t119)
  store ptr %t120, ptr %l58
  br label %bb13
bb13:
  %t121 = load ptr, ptr %l58, !tbaa !29
  %t123 = getelementptr %"compiler/ast:Func", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %t123, !tbaa !23
  %t125 = load ptr, ptr %l51, !tbaa !29
  %t127 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t125, i32 %t124)
  store { i64, ptr } %t127, ptr %l61
  br label %bb14
bb14:
  %t128 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t128, ptr %l50, !tbaa !27
  br label %bb15
bb15:
  %t129 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t129, ptr %l9, !tbaa !27
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 0
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/load:Loader", ptr %t136, i32 0, i32 4
  %t139 = load ptr, ptr %t138, !tbaa !29
  store ptr %t139, ptr %l66, !tbaa !29
  %t140 = load i64, ptr %l7, !tbaa !24
  store i64 %t140, ptr %l67, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t145 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t141, %"compiler/source:Span" %a2)
  store { i64, [3 x i64] } %t145, ptr %l70
  br label %bb16
bb16:
  %t146 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t148 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteGenericNeeds(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t146, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t148, ptr %l72
  br label %bb17
bb17:
  %t149 = load ptr, ptr %l66, !tbaa !29
  %t150 = load i64, ptr %l67, !tbaa !24
  %t151 = load { i64, [3 x i64] }, ptr %l70
  %t152 = load %"compiler/diagmsg:Msg", ptr %l72
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t149, i64 %t150, { i64, [3 x i64] } %t151, %"compiler/diagmsg:Msg" %t152)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWritable(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/typed:Local"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca %"compiler/typed:Local"
  %l23 = alloca i1
  %l29 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i64
  %l40 = alloca { i64, [3 x i64] }
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l51 = alloca %"compiler/diagmsg:Msg"
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %v1, ptr %a2)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t4)
  store ptr %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l8, !tbaa !29
  store ptr %t6, ptr %l3, !tbaa !29
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l3, !tbaa !29
  store ptr %t11, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l11, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 8}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb31
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t26)
  store ptr %t28, ptr %l18
  br label %bb11
bb11:
  %t29 = load i32, ptr %l4, !tbaa !23
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t32 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t30, i32 %t29)
  store %"compiler/typed:Local" %t32, ptr %l20
  br label %bb12
bb12:
  %t33 = load %"compiler/typed:Local", ptr %l20
  store %"compiler/typed:Local" %t33, ptr %l5
  %t34 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 0
  %t35 = load i32, ptr %t34, !tbaa !23
  %t37 = icmp eq i32 %t35, 0
  br i1 %t37, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb15
bb14:
  %t39 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 5
  %t40 = load { i64, [1 x i64] }, ptr %t39
  %t42 = extractvalue { i64, [1 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 4
  store i1 %t43, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb17:
  br label %bb18
bb18:
  %t46 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t47 = load i32, ptr %t46, !range !{i32 0, i32 7}
  %t49 = trunc i64 1 to i32
  %t50 = icmp eq i32 %t47, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t55 = load i32, ptr %t54, !range !{i32 0, i32 7}
  %t57 = trunc i64 0 to i32
  %t58 = icmp eq i32 %t55, %t57
  %t60 = xor i1 %t58, true
  store i1 %t60, ptr %l29, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb21
bb21:
  %t62 = load i1, ptr %l29, !tbaa !21
  br i1 %t62, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb23:
  br label %bb24
bb24:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/load:Loader", ptr %t69, i32 0, i32 4
  %t72 = load ptr, ptr %t71, !tbaa !29
  store ptr %t72, ptr %l36, !tbaa !29
  store i64 %a1, ptr %l37, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 1
  %t76 = load %"compiler/source:Span", ptr %t75
  %t79 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t74, %"compiler/source:Span" %t76)
  store { i64, [3 x i64] } %t79, ptr %l40
  br label %bb25
bb25:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t80, i32 %t82)
  store { i64, ptr } %t85, ptr %l43
  br label %bb26
bb26:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t86, i32 %t88)
  store { i64, ptr } %t91, ptr %l46
  br label %bb27
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t94 = load i32, ptr %t93, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t92, i32 %t94)
  store { i64, ptr } %t97, ptr %l49
  br label %bb28
bb28:
  %t98 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t108 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteDeclareWritable(ptr %v0, ptr %v0, ptr %s2, ptr %s2, { i64, ptr } %t105, { i64, ptr } %t106, { i64, ptr } %t104)
  store %"compiler/diagmsg:Msg" %t108, ptr %l51
  br label %bb29
bb29:
  %t109 = load ptr, ptr %l36, !tbaa !29
  %t110 = load i64, ptr %l37, !tbaa !24
  %t111 = load { i64, [3 x i64] }, ptr %l40
  %t112 = load %"compiler/diagmsg:Msg", ptr %l51
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s2, ptr %t109, i64 %t110, { i64, [3 x i64] } %t111, %"compiler/diagmsg:Msg" %t112)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_b30cbbdf82dda0cf_ca6a4a064596874b)
  unreachable
bb36:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enothingFails(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/diagmsg:Msg"
  %l8 = alloca i64
  %s0 = alloca %olang.scope
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l2, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = add i32 %t5, 3
  %t10 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t3, i32 %t7)
  store %"compiler/source:Span" %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryNothingFails(ptr %s0, ptr %s0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l6
  %t14 = load %"compiler/diagmsg:Msg", ptr %l7
  %t15 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t12, %"compiler/source:Span" %t13, %"compiler/diagmsg:Msg" %t14)
  store i64 %t15, ptr %l8
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverImmut(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 3
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 4
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t40 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t37, ptr %t34, ptr %t35)
  store i32 %t40, ptr %l23
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l14, !tbaa !29
  %t42 = load i32, ptr %l23, !tbaa !23
  %t43 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t43, ptr %l24
  br label %bb8
bb8:
  %t44 = load i1, ptr %l24, !tbaa !21
  store i1 %t44, ptr %l6, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_e50f118683988667_19bbe448830cf623)
  unreachable
bb14:
  %t45 = load i1, ptr %l6, !tbaa !21
  store i1 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %t11, i64 %t12)
  store i64 %t15, ptr %l11
  br label %bb4
bb3:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb5
bb4:
  %t16 = load i64, ptr %l11, !tbaa !24
  store i64 %t16, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l8, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadPattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, ptr %a5, i32 %a6, ptr %a7, i64 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %lp15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %lp22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l38 = alloca i1
  %l42 = alloca ptr
  %l47 = alloca ptr
  %l50 = alloca ptr
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca %"compiler/source:Span"
  %l66 = alloca i32
  %l70 = alloca ptr
  %l75 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca i32
  %l90 = alloca %"compiler/typed:Payload"
  %l98 = alloca i64
  %l101 = alloca i64
  %l119 = alloca { i64, ptr }
  %l122 = alloca i1
  %l123 = alloca { i64, ptr }
  %l126 = alloca %"compiler/source:Span"
  %l127 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l147 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t98 = alloca { i64, [4 x i64] }, align 8
  %t148 = alloca { i64, [4 x i64] }, align 8
  %t239 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a3, ptr %l3
  store ptr %a5, ptr %l5
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l6, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l25
  br label %bb1
bb1:
  %t6 = load i32, ptr %l25, !tbaa !23
  store i32 %t6, ptr %l9, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l27, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l28
  store { i64, ptr } %a4, ptr %l29, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = load i64, ptr %l3, !tbaa !24
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseFields(ptr %v0, ptr %v1, ptr %v0, ptr %t10, i32 %t11, i64 %t12, ptr %a2)
  store ptr %t18, ptr %l34
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l27, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l28
  %t21 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t22 = load ptr, ptr %l34, !tbaa !29
  %t23 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyField(ptr %v0, ptr %v2, ptr %v0, ptr %v5, ptr %t19, %"compiler/source:Span" %t20, { i64, ptr } %t21, ptr %t22, i1 true)
  %t24 = extractvalue { i32, { i64, ptr } } %t23, 1
  %t25 = extractvalue { i32, { i64, ptr } } %t23, 0
  store i32 %t25, ptr %l36
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb4, label %ok.27, !prof !99
ok.27:
  store { i64, ptr } %t24, ptr %l35
  br label %bb3
bb3:
  %t28 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t28, ptr %l26, !tbaa !27
  br label %bb7
bb4:
  %t29 = load i32, ptr %l36, !tbaa !23
  %t30 = ashr i32 %t29, 16
  %t32 = icmp eq i32 %t30, 1
  store i1 %t32, ptr %l38, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v5, ptr %t33, %"compiler/source:Span" %t34, i32 %t35, i64 0)
  store ptr %t39, ptr %l42
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load ptr, ptr %l42, !tbaa !29
  store ptr %t40, ptr %rv
  br label %ret
bb7:
  %t41 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t41, ptr %l10, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t45 = load i64, ptr %l3, !tbaa !24
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v3, ptr %v5, ptr %t42, %"compiler/source:Span" %t43, ptr %t44, i64 %t45)
  store ptr %t50, ptr %l47
  br label %bb8
bb8:
  %t51 = load ptr, ptr %l47, !tbaa !29
  store ptr %t51, ptr %l11, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  store ptr %t57, ptr %l50, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  store ptr %t63, ptr %l53, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t68 = load i32, ptr %l9, !tbaa !23
  %t69 = load i64, ptr %l3, !tbaa !24
  %t73 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t67, i32 %t68, i64 %t69)
  store i32 %t73, ptr %l58
  br label %bb9
bb9:
  %t74 = load ptr, ptr %l53, !tbaa !29
  %t75 = load i32, ptr %l58, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t76, ptr %l59
  br label %bb10
bb10:
  %t77 = load ptr, ptr %l50, !tbaa !29
  %t78 = load i32, ptr %l59, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t77, i32 %t78)
  store { i64, ptr } %t79, ptr %l60
  br label %bb11
bb11:
  %t80 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t80, ptr %l12, !tbaa !27
  %t81 = load ptr, ptr %l5, !tbaa !29
  store ptr %t81, ptr %l13, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l6, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l64
  br label %bb12
bb12:
  %t88 = load i1, ptr %l64, !tbaa !21
  br i1 %t88, label %bb13, label %bb14
bb13:
  %t89 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t89, ptr %l65
  %t90 = load i32, ptr %l9, !tbaa !23
  store i32 %t90, ptr %l66, !tbaa !23
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t91, %"compiler/source:Span" %t92, ptr %t93)
  store ptr %t97, ptr %l70
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, [4 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 0
  store i64 2, ptr %t99
  %t100 = load %"compiler/source:Span", ptr %l65
  %t101 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t100, 0
  %t102 = load i32, ptr %l66, !tbaa !23
  %t103 = insertvalue { %"compiler/source:Span", i32, ptr } %t101, i32 %t102, 1
  %t104 = load ptr, ptr %l70, !tbaa !29
  %t105 = insertvalue { %"compiler/source:Span", i32, ptr } %t103, ptr %t104, 2
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t105, ptr %t106
  %t107 = load { i64, [4 x i64] }, ptr %t98
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t107, ptr %t109
  store ptr %t109, ptr %l13, !tbaa !29
  br label %bb16
bb16:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  store ptr %t116, ptr %l75, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l9, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l80
  br label %bb17
bb17:
  %t127 = load ptr, ptr %l75, !tbaa !29
  %t128 = load i32, ptr %l80, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t127, i32 %t128)
  store { i64, ptr } %t129, ptr %l81
  br label %bb18
bb18:
  %t130 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t130, ptr %l82, !tbaa !27
  %t131 = load i64, ptr %l3, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i32, ptr %t134, i64 %t131
  %t136 = load i32, ptr %t135, !tbaa !33
  %t138 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t138, ptr %l85
  store i32 %t136, ptr %l86, !tbaa !23
  %t140 = load ptr, ptr %l13, !tbaa !29
  %t141 = load i64, ptr %l3, !tbaa !24
  %t145 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v3, ptr %v5, ptr %t140, i64 %t141, i32 0)
  store %"compiler/typed:Payload" %t145, ptr %l90
  br label %bb19
bb19:
  %t146 = load %"compiler/typed:Payload", ptr %l90
  %t147 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 24, i64 8)
  store %"compiler/typed:Payload" %t146, ptr %t147
  store { i64, [4 x i64] } zeroinitializer, ptr %t148
  %t149 = getelementptr { i64, [4 x i64] }, ptr %t148, i32 0, i32 0
  store i64 5, ptr %t149
  %t150 = load %"compiler/source:Span", ptr %l85
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t150, 0
  %t152 = load i32, ptr %l86, !tbaa !23
  %t153 = insertvalue { %"compiler/source:Span", i32, ptr } %t151, i32 %t152, 1
  %t155 = insertvalue { %"compiler/source:Span", i32, ptr } %t153, ptr %t147, 2
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t148, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t155, ptr %t156
  %t157 = load { i64, [4 x i64] }, ptr %t148
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 40, i64 8)
  store ptr %t158, ptr %lp15
  %t160 = load ptr, ptr %lp15
  store { i64, [4 x i64] } %t157, ptr %t160
  store i64 0, ptr %l16, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  store i64 %t163, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t165 = load i64, ptr %l17, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = icmp sgt i64 %t165, %t166
  br i1 %t169, label %bb20, label %bb21
bb20:
  %t171 = load i64, ptr %l18, !tbaa !24
  %t173 = icmp sgt i64 %t171, 0
  br i1 %t173, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb25
bb22:
  %t175 = load i64, ptr %l17, !tbaa !24
  %t176 = load i64, ptr %l16, !tbaa !24
  %t179 = sub i64 %t175, %t176
  %t180 = load i64, ptr %l18, !tbaa !24
  %t183 = add i64 %t179, %t180
  %t185 = sub i64 %t183, 1
  %t186 = load i64, ptr %l18, !tbaa !24
  %t189 = sdiv i64 %t185, %t186
  store i64 %t189, ptr %l101, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb24
bb24:
  %t191 = load i64, ptr %l101, !tbaa !24
  store i64 %t191, ptr %l98, !tbaa !24
  br label %bb25
bb25:
  %t192 = load i64, ptr %l98, !tbaa !24
  store i64 %t192, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb26
bb26:
  %t193 = load i64, ptr %l20, !tbaa !24
  %t194 = load i64, ptr %l19, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb27, label %bb28
bb27:
  br label %bb38
bb28:
  br label %bb29
bb29:
  %t201 = load i64, ptr %l16, !tbaa !24
  %t202 = load i64, ptr %l20, !tbaa !24
  %t203 = load i64, ptr %l18, !tbaa !24
  %t206 = mul i64 %t202, %t203
  %t209 = add i64 %t201, %t206
  store i64 %t209, ptr %l21, !tbaa !24
  %t211 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t211, ptr %l119, !tbaa !27
  %t212 = load i64, ptr %l21, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr ptr, ptr %t215, i64 %t212
  %t217 = load ptr, ptr %t216, !tbaa !39
  %t219 = call i1 @compiler_2fcheck_2eisWild(ptr %v5, ptr %t217)
  store i1 %t219, ptr %l122
  br label %bb30
bb30:
  %t220 = load i1, ptr %l122, !tbaa !21
  br i1 %t220, label %bb31, label %bb32
bb31:
  br label %bb37
bb32:
  br label %bb33
bb33:
  %t221 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t221, ptr %l123, !tbaa !27
  %t222 = load i64, ptr %l21, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 %t222
  %t227 = load ptr, ptr %t226, !tbaa !39
  %t229 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v5, ptr %t227)
  store %"compiler/source:Span" %t229, ptr %l126
  br label %bb34
bb34:
  %t230 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t230, ptr %l127, !tbaa !27
  %t231 = load i64, ptr %l21, !tbaa !24
  %t233 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i32, ptr %t234, i64 %t231
  %t236 = load i32, ptr %t235, !tbaa !33
  %t237 = load ptr, ptr %lp15
  %t238 = load i64, ptr %l21, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t239
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 0
  store i64 3, ptr %t240
  %t241 = load %"compiler/source:Span", ptr %l126
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t241, 0
  %t244 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t242, i32 %t236, 1
  %t246 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t244, ptr %t237, 2
  %t248 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t246, i64 %t238, 3
  %t249 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t248, ptr %t249
  %t250 = load { i64, [4 x i64] }, ptr %t239
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 40, i64 8)
  store ptr %t251, ptr %lp22
  %t253 = load ptr, ptr %lp22
  store { i64, [4 x i64] } %t250, ptr %t253
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l133, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t255, ptr %l134
  %t256 = load ptr, ptr %l11, !tbaa !29
  store ptr %t256, ptr %l135, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t258, ptr %l137, !tbaa !27
  %t259 = load i64, ptr %l21, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr ptr, ptr %t262, i64 %t259
  %t264 = load ptr, ptr %t263, !tbaa !39
  %t265 = load ptr, ptr %lp22
  %t266 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t266, ptr %l141, !tbaa !27
  %t267 = load i64, ptr %l21, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i32, ptr %t270, i64 %t267
  %t272 = load i32, ptr %t271, !tbaa !33
  %t281 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v5, ptr %v5, ptr %v4, ptr %v5, ptr %t257, ptr %t264, ptr %t265, i32 %t272, ptr %a7, i64 %a8)
  store ptr %t281, ptr %l146
  br label %bb35
bb35:
  %t282 = load ptr, ptr %l133, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l134
  %t284 = load ptr, ptr %l135, !tbaa !29
  %t285 = load ptr, ptr %l146, !tbaa !29
  %t286 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v5, ptr %v5, ptr %v5, ptr %t282, %"compiler/source:Span" %t283, ptr %t284, ptr %t285)
  store ptr %t286, ptr %l147
  br label %bb36
bb36:
  %t287 = load ptr, ptr %l147, !tbaa !29
  store ptr %t287, ptr %l11, !tbaa !29
  br label %bb37
bb37:
  %t288 = load i64, ptr %l20, !tbaa !24
  %t290 = add i64 %t288, 1
  store i64 %t290, ptr %l20, !tbaa !24
  br label %bb26
bb38:
  %t292 = load ptr, ptr %l11, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t292, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l75 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t7)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = load i32, ptr %l12, !tbaa !23
  %t13 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t13, ptr %l13
  br label %bb2
bb2:
  %t14 = load i1, ptr %l13, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l17, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t26 = load ptr, ptr %l20, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l21, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb59
bb15:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t35 = load ptr, ptr %l24, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l24, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l25, !tbaa !21
  br label %bb17
bb17:
  %t42 = load i1, ptr %l25, !tbaa !21
  br i1 %t42, label %bb18, label %bb19
bb18:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l2, !tbaa !29
  br label %bb24
bb19:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb20, label %bb21
bb20:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 18}
  %t56 = icmp eq i64 %t54, 3
  store i1 %t56, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb22, label %bb23
bb22:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l2, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = call i1 @compiler_2fcheck_2eplainPlace(ptr %v1, ptr %t64)
  store i1 %t66, ptr %l37
  br label %bb25
bb25:
  %t67 = load i1, ptr %l37, !tbaa !21
  store i1 %t67, ptr %l15, !tbaa !21
  br label %bb59
bb26:
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t69 = load ptr, ptr %l38, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb27, label %bb28
bb27:
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 18}
  %t75 = icmp eq i64 %t73, 9
  store i1 %t75, ptr %l39, !tbaa !21
  br label %bb28
bb28:
  %t76 = load i1, ptr %l39, !tbaa !21
  br i1 %t76, label %bb29, label %bb30
bb29:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t79, i32 0, i32 2
  %t81 = load i32, ptr %t80, !range !{i32 0, i32 46}
  store i32 %t81, ptr %l3
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t85, i32 0, i32 4
  %t87 = load { i64, ptr }, ptr %t86
  store { i64, ptr } %t87, ptr %l4, !tbaa !27
  br label %bb31
bb30:
  br label %bb36
bb31:
  %t89 = load i32, ptr %l3, !range !{i32 0, i32 46}
  %t91 = trunc i64 29 to i32
  %t92 = icmp eq i32 %t89, %t91
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb32, label %bb33
bb32:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainArgs(ptr %v0, ptr %v1, ptr %t96, { i64, ptr } %t97)
  store i1 %t100, ptr %l52
  br label %bb34
bb33:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb35
bb34:
  %t101 = load i1, ptr %l52, !tbaa !21
  store i1 %t101, ptr %l49, !tbaa !21
  br label %bb35
bb35:
  %t102 = load i1, ptr %l49, !tbaa !21
  store i1 %t102, ptr %l15, !tbaa !21
  br label %bb59
bb36:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t104 = load ptr, ptr %l53, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb37, label %bb38
bb37:
  %t107 = load ptr, ptr %l53, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 18}
  %t110 = icmp eq i64 %t108, 6
  store i1 %t110, ptr %l54, !tbaa !21
  br label %bb38
bb38:
  %t111 = load i1, ptr %l54, !tbaa !21
  br i1 %t111, label %bb39, label %bb40
bb39:
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t114, i32 0, i32 2
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l5, !tbaa !29
  br label %bb41
bb40:
  br label %bb47
bb41:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorCall(ptr %v0, ptr %v1, ptr %t118, ptr %t119)
  store i1 %t122, ptr %l61
  br label %bb42
bb42:
  %t123 = load i1, ptr %l61, !tbaa !21
  br i1 %t123, label %bb43, label %bb44
bb43:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Call", ptr %t125, i32 0, i32 1
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  %t131 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainArgs(ptr %v0, ptr %v1, ptr %t124, { i64, ptr } %t128)
  store i1 %t131, ptr %l66
  br label %bb45
bb44:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb46
bb45:
  %t132 = load i1, ptr %l66, !tbaa !21
  store i1 %t132, ptr %l62, !tbaa !21
  br label %bb46
bb46:
  %t133 = load i1, ptr %l62, !tbaa !21
  store i1 %t133, ptr %l15, !tbaa !21
  br label %bb59
bb47:
  %t134 = load ptr, ptr %l1, !tbaa !29
  store ptr %t134, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t135 = load ptr, ptr %l67, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb48, label %bb49
bb48:
  %t138 = load ptr, ptr %l67, !tbaa !29
  %t139 = load i64, ptr %t138, !range !{i64 0, i64 18}
  %t141 = icmp eq i64 %t139, 17
  store i1 %t141, ptr %l68, !tbaa !21
  br label %bb49
bb49:
  %t142 = load i1, ptr %l68, !tbaa !21
  br i1 %t142, label %bb50, label %bb51
bb50:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t145, i32 0, i32 2
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l6, !tbaa !29
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l6, !tbaa !29
  %t153 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainArg(ptr %v0, ptr %v1, ptr %t149, ptr %t150)
  store i1 %t153, ptr %l75
  br label %bb53
bb53:
  %t154 = load i1, ptr %l75, !tbaa !21
  store i1 %t154, ptr %l15, !tbaa !21
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_225fd1ebbf6099f3_3ca87289db5537)
  unreachable
bb59:
  %t155 = load i1, ptr %l15, !tbaa !21
  store i1 %t155, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca %"compiler/generic:Desc"
  %l11 = alloca i64
  %l12 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i32
  %l21 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l34 = alloca i1
  %l39 = alloca %"compiler/check:reflVal"
  %l41 = alloca i1
  %l46 = alloca { i64, ptr }
  %l48 = alloca %"compiler/check:reflVal"
  %l50 = alloca i1
  %l55 = alloca i64
  %l58 = alloca %"compiler/check:reflVal"
  %l59 = alloca i64
  %l60 = alloca i64
  %l62 = alloca i32
  %l63 = alloca %"compiler/check:reflVal"
  %l65 = alloca i1
  %l66 = alloca i1
  %l68 = alloca i1
  %l73 = alloca i1
  %l75 = alloca %"compiler/check:reflVal"
  %l77 = alloca i1
  %l78 = alloca i64
  %l83 = alloca i64
  %l88 = alloca i64
  %l89 = alloca %"compiler/check:reflVal"
  %l91 = alloca i1
  %l92 = alloca i1
  %l94 = alloca i1
  %l95 = alloca i1
  %l100 = alloca i1
  %l106 = alloca i64
  %l111 = alloca i1
  %l113 = alloca i1
  %l114 = alloca %"compiler/check:reflVal"
  %l117 = alloca %"compiler/check:reflVal"
  %l118 = alloca i64
  %l121 = alloca %"compiler/check:reflVal"
  %l122 = alloca %"compiler/check:reflVal"
  %l125 = alloca %"compiler/check:reflVal"
  %l128 = alloca i64
  %l131 = alloca i64
  %l135 = alloca i1
  %l136 = alloca i64
  %l141 = alloca %"compiler/check:reflVal"
  %l143 = alloca i1
  %l147 = alloca i32
  %l152 = alloca i32
  %l156 = alloca i1
  %l159 = alloca ptr
  %l164 = alloca i32
  %l165 = alloca i32
  %l169 = alloca %"compiler/check:reflVal"
  %l172 = alloca ptr
  %l177 = alloca i32
  %l178 = alloca i64
  %l179 = alloca %"compiler/check:reflVal"
  %l180 = alloca %"compiler/check:reflVal"
  %l183 = alloca i32
  %l186 = alloca %"compiler/check:reflVal"
  %l190 = alloca %"compiler/check:reflVal"
  %l194 = alloca %"compiler/generic:Desc"
  %l197 = alloca i1
  %l200 = alloca { i64, ptr }
  %l202 = alloca %"compiler/check:reflVal"
  %l204 = alloca i1
  %l205 = alloca i1
  %l211 = alloca ptr
  %l214 = alloca %"compiler/check:reflVal"
  %l216 = alloca i1
  %l217 = alloca i1
  %l223 = alloca i64
  %l226 = alloca %"compiler/check:reflVal"
  %l228 = alloca %"compiler/check:reflVal"
  %l229 = alloca %"compiler/check:reflVal"
  %l231 = alloca i1
  %l232 = alloca i1
  %l234 = alloca i1
  %l235 = alloca i1
  %l239 = alloca ptr
  %l240 = alloca %"compiler/generic:Desc"
  %l242 = alloca i1
  %l243 = alloca i64
  %l246 = alloca %"compiler/check:reflVal"
  %l248 = alloca %"compiler/check:reflVal"
  %l249 = alloca %"compiler/check:reflVal"
  %l250 = alloca %"compiler/check:reflVal"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflVal"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  store i32 %t11, ptr %l18
  br label %bb2
bb2:
  %t12 = load i32, ptr %l18, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t13 = load i32, ptr %l4, !tbaa !23
  %t15 = icmp sge i32 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l4, !tbaa !23
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l24
  br label %bb5
bb4:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb5:
  %t22 = load i1, ptr %l24, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i1 %t27, ptr %l28
  br label %bb8
bb7:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb9
bb8:
  %t28 = load i1, ptr %l28, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l25, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l4, !tbaa !23
  %t34 = load i32, ptr %l2, !tbaa !23
  %t38 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t32, i32 %t33, i32 %t34)
  store i1 %t38, ptr %l34
  br label %bb12
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb13
bb12:
  %t39 = load i1, ptr %l34, !tbaa !21
  store i1 %t39, ptr %l30, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l30, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l21, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s1
  %t44 = load i32, ptr %l4, !tbaa !23
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t48 = icmp eq i32 %t44, %t45
  br i1 %t48, label %bb17, label %bb18
bb16:
  br label %bb116
bb17:
  %t50 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t50, ptr %l39
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t51 = load %"compiler/check:reflVal", ptr %l39
  store %"compiler/check:reflVal" %t51, ptr %rv
  br label %ret
bb20:
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t52, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t54, ptr %l41
  br label %bb21
bb21:
  %t55 = load i1, ptr %l41, !tbaa !21
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 136
  store i1 true, ptr %t58, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i32, ptr %l4, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflName(ptr %v0, ptr %v2, ptr %t62, i32 %t63)
  store { i64, ptr } %t66, ptr %l46
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t67 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t69 = extractvalue { i64, ptr } %t67, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t75 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervText(ptr %v2, ptr %v2, { i64, ptr } %t73)
  store %"compiler/check:reflVal" %t75, ptr %l48
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t76 = load %"compiler/check:reflVal", ptr %l48
  store %"compiler/check:reflVal" %t76, ptr %rv
  br label %ret
bb26:
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t77, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t79, ptr %l50
  br label %bb27
bb27:
  %t80 = load i1, ptr %l50, !tbaa !21
  br i1 %t80, label %bb28, label %bb29
bb28:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 136
  store i1 true, ptr %t83, !tbaa !21
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t88 = load i32, ptr %l4, !tbaa !23
  %t91 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflKind(ptr %v0, ptr %t87, i32 %t88)
  store i64 %t91, ptr %l55
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t92 = load i64, ptr %l55, !tbaa !24
  store i64 %t92, ptr %l5, !tbaa !24
  %t93 = load i64, ptr %l5, !tbaa !24
  %t95 = icmp slt i64 %t93, 0
  br i1 %t95, label %bb31, label %bb32
bb31:
  %t97 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t97, ptr %l58
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t98 = load %"compiler/check:reflVal", ptr %l58
  store %"compiler/check:reflVal" %t98, ptr %rv
  br label %ret
bb34:
  %t99 = load i64, ptr @G_2ecompiler_2fcheck_2eRvCase, !tbaa !24
  store i64 %t99, ptr %l59, !tbaa !24
  %t100 = load i64, ptr %l5, !tbaa !24
  store i64 %t100, ptr %l60, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeKindType(ptr %v0, ptr %t101)
  store i32 %t103, ptr %l62
  br label %bb35
bb35:
  %t104 = load i64, ptr %l59, !tbaa !24
  %t105 = load i64, ptr %l60, !tbaa !24
  %t106 = load i32, ptr %l62, !tbaa !23
  %t107 = call %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v2, ptr %v2, i1 true, i64 %t104, i64 %t105, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, i32 %t106)
  store %"compiler/check:reflVal" %t107, ptr %l63
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t108 = load %"compiler/check:reflVal", ptr %l63
  store %"compiler/check:reflVal" %t108, ptr %rv
  br label %ret
bb37:
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t109, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t111, ptr %l65
  br label %bb38
bb38:
  %t112 = load i1, ptr %l65, !tbaa !21
  br i1 %t112, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb42
bb40:
  %t113 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t113, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t115, ptr %l68
  br label %bb41
bb41:
  %t116 = load i1, ptr %l68, !tbaa !21
  store i1 %t116, ptr %l66, !tbaa !21
  br label %bb42
bb42:
  %t117 = load i1, ptr %l66, !tbaa !21
  br i1 %t117, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 136
  store i1 true, ptr %t120, !tbaa !21
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = load i32, ptr %l4, !tbaa !23
  %t128 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t124, i32 %t125)
  store i1 %t128, ptr %l73
  br label %bb45
bb44:
  br label %bb57
bb45:
  %t129 = load i1, ptr %l73, !tbaa !21
  %t130 = xor i1 %t129, true
  br i1 %t130, label %bb46, label %bb47
bb46:
  %t132 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t132, ptr %l75
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t133 = load %"compiler/check:reflVal", ptr %l75
  store %"compiler/check:reflVal" %t133, ptr %rv
  br label %ret
bb49:
  %t134 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t136 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t134, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t136, ptr %l77
  br label %bb50
bb50:
  %t137 = load i1, ptr %l77, !tbaa !21
  br i1 %t137, label %bb51, label %bb52
bb51:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l4, !tbaa !23
  %t147 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t143, i32 %t144)
  store i64 %t147, ptr %l83
  br label %bb53
bb52:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load i32, ptr %l4, !tbaa !23
  %t157 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t153, i32 %t154)
  store i64 %t157, ptr %l88
  br label %bb54
bb53:
  %t158 = load i64, ptr %l83, !tbaa !24
  store i64 %t158, ptr %l78, !tbaa !24
  br label %bb55
bb54:
  %t159 = load i64, ptr %l88, !tbaa !24
  store i64 %t159, ptr %l78, !tbaa !24
  br label %bb55
bb55:
  %t160 = load i64, ptr %l78, !tbaa !24
  %t161 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v2, i64 %t160)
  store %"compiler/check:reflVal" %t161, ptr %l89
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t162 = load %"compiler/check:reflVal", ptr %l89
  store %"compiler/check:reflVal" %t162, ptr %rv
  br label %ret
bb57:
  %t163 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t165 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t163, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t165, ptr %l91
  br label %bb58
bb58:
  %t166 = load i1, ptr %l91, !tbaa !21
  br i1 %t166, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb62
bb60:
  %t167 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t169 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t167, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t169, ptr %l94
  br label %bb61
bb61:
  %t170 = load i1, ptr %l94, !tbaa !21
  store i1 %t170, ptr %l92, !tbaa !21
  br label %bb62
bb62:
  %t171 = load i1, ptr %l92, !tbaa !21
  br i1 %t171, label %bb63, label %bb64
bb63:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/check:Checker", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/generic:Program", ptr %t175, i32 0, i32 2
  %t178 = load i32, ptr %l4, !tbaa !23
  %t181 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t177, i32 %t178)
  store i1 %t181, ptr %l100
  br label %bb65
bb64:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb66
bb65:
  %t182 = load i1, ptr %l100, !tbaa !21
  store i1 %t182, ptr %l95, !tbaa !21
  br label %bb66
bb66:
  %t183 = load i1, ptr %l95, !tbaa !21
  br i1 %t183, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s8
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 136
  store i1 true, ptr %t186, !tbaa !21
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 2
  %t193 = load i32, ptr %l4, !tbaa !23
  %t196 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t192, i32 %t193)
  store i64 %t196, ptr %l106
  br label %bb69
bb68:
  br label %bb96
bb69:
  %t197 = load i64, ptr %l106, !tbaa !24
  store i64 %t197, ptr %l6, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 2
  %t204 = load i32, ptr %l4, !tbaa !23
  %t207 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t203, i32 %t204)
  store i1 %t207, ptr %l111
  br label %bb70
bb70:
  %t208 = load i1, ptr %l111, !tbaa !21
  br i1 %t208, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s9
  %t209 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t211 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s9, { i64, ptr } %t209, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t211, ptr %l113
  br label %bb73
bb72:
  br label %bb83
bb73:
  %t212 = load i1, ptr %l113, !tbaa !21
  br i1 %t212, label %bb74, label %bb75
bb74:
  %t213 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v2, i64 0)
  store %"compiler/check:reflVal" %t213, ptr %l114
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t214 = load %"compiler/check:reflVal", ptr %l114
  store %"compiler/check:reflVal" %t214, ptr %rv
  br label %ret
bb77:
  %t215 = load i64, ptr %l6, !tbaa !24
  %t217 = icmp slt i64 %t215, 64
  br i1 %t217, label %bb78, label %bb79
bb78:
  %t219 = load i64, ptr %l6, !tbaa !24
  store i64 %t219, ptr %l118, !tbaa !24
  %t220 = load i64, ptr %l118, !tbaa !24
  %t221 = load i64, ptr %l118, !tbaa !24
  %t222 = shl i64 1, %t221
  %t224 = sub i64 %t222, 1
  %t226 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v2, i64 %t224)
  store %"compiler/check:reflVal" %t226, ptr %l121
  br label %bb80
bb79:
  %t227 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t227, ptr %l122
  br label %bb81
bb80:
  %t228 = load %"compiler/check:reflVal", ptr %l121
  store %"compiler/check:reflVal" %t228, ptr %l117
  br label %bb82
bb81:
  %t229 = load %"compiler/check:reflVal", ptr %l122
  store %"compiler/check:reflVal" %t229, ptr %l117
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t230 = load %"compiler/check:reflVal", ptr %l117
  store %"compiler/check:reflVal" %t230, ptr %rv
  br label %ret
bb83:
  %t231 = load i64, ptr %l6, !tbaa !24
  %t233 = icmp sgt i64 %t231, 64
  br i1 %t233, label %bb84, label %bb85
bb84:
  %t235 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t235, ptr %l125
  br label %bb86
bb85:
  br label %bb87
bb86:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t236 = load %"compiler/check:reflVal", ptr %l125
  store %"compiler/check:reflVal" %t236, ptr %rv
  br label %ret
bb87:
  %t237 = load i64, ptr %l6, !tbaa !24
  %t239 = icmp eq i64 %t237, 64
  br i1 %t239, label %bb88, label %bb89
bb88:
  %t241 = sub i64 -9223372036854775807, 1
  store i64 %t241, ptr %l128, !tbaa !24
  br label %bb90
bb89:
  %t243 = load i64, ptr %l6, !tbaa !24
  %t245 = sub i64 %t243, 1
  store i64 %t245, ptr %l131, !tbaa !24
  %t246 = load i64, ptr %l131, !tbaa !24
  %t247 = load i64, ptr %l131, !tbaa !24
  %t248 = shl i64 1, %t247
  %t250 = sub i64 0, %t248
  store i64 %t250, ptr %l128, !tbaa !24
  br label %bb90
bb90:
  %t252 = load i64, ptr %l128, !tbaa !24
  store i64 %t252, ptr %l7, !tbaa !24
  %t253 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t255 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s8, { i64, ptr } %t253, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t255, ptr %l135
  br label %bb91
bb91:
  %t256 = load i1, ptr %l135, !tbaa !21
  br i1 %t256, label %bb92, label %bb93
bb92:
  %t257 = load i64, ptr %l7, !tbaa !24
  store i64 %t257, ptr %l136, !tbaa !24
  br label %bb94
bb93:
  %t259 = load i64, ptr %l7, !tbaa !24
  %t261 = add i64 %t259, 1
  %t263 = sub i64 0, %t261
  store i64 %t263, ptr %l136, !tbaa !24
  br label %bb94
bb94:
  %t265 = load i64, ptr %l136, !tbaa !24
  %t266 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v2, i64 %t265)
  store %"compiler/check:reflVal" %t266, ptr %l141
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t267 = load %"compiler/check:reflVal", ptr %l141
  store %"compiler/check:reflVal" %t267, ptr %rv
  br label %ret
bb96:
  %t268 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t270 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t268, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t270, ptr %l143
  br label %bb97
bb97:
  %t271 = load i1, ptr %l143, !tbaa !21
  br i1 %t271, label %bb98, label %bb99
bb98:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t272, i32 0, i32 136
  store i1 true, ptr %t274, !tbaa !21
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load i32, ptr %l4, !tbaa !23
  %t279 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t275, i32 %t276)
  store i32 %t279, ptr %l147
  br label %bb100
bb99:
  br label %bb114
bb100:
  %t280 = load i32, ptr %l147, !tbaa !23
  store i32 %t280, ptr %l8, !tbaa !23
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Program", ptr %t284, i32 0, i32 2
  %t287 = load i32, ptr %l8, !tbaa !23
  %t290 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t286, i32 %t287)
  store i32 %t290, ptr %l152
  br label %bb101
bb101:
  %t291 = load i32, ptr %l152, !range !{i32 0, i32 33}
  %t293 = trunc i64 19 to i32
  %t294 = icmp eq i32 %t291, %t293
  %t296 = xor i1 %t294, true
  br i1 %t296, label %bb102, label %bb103
bb102:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb106
bb103:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/generic:Program", ptr %t301, i32 0, i32 2
  store ptr %t303, ptr %l159, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/check:Checker", ptr %t304, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t309 = getelementptr %"compiler/generic:Program", ptr %t307, i32 0, i32 2
  %t310 = load i32, ptr %l8, !tbaa !23
  %t313 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t309, i32 %t310)
  store i32 %t313, ptr %l164
  br label %bb104
bb104:
  %t314 = load ptr, ptr %l159, !tbaa !29
  %t315 = load i32, ptr %l164, !tbaa !23
  %t316 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t314, i32 %t315)
  store i32 %t316, ptr %l165
  br label %bb105
bb105:
  %t317 = load i32, ptr %l165, !range !{i32 0, i32 33}
  %t319 = trunc i64 26 to i32
  %t320 = icmp eq i32 %t317, %t319
  %t322 = xor i1 %t320, true
  store i1 %t322, ptr %l156, !tbaa !21
  br label %bb106
bb106:
  %t324 = load i1, ptr %l156, !tbaa !21
  br i1 %t324, label %bb107, label %bb108
bb107:
  %t325 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t325, ptr %l169
  br label %bb109
bb108:
  br label %bb110
bb109:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t326 = load %"compiler/check:reflVal", ptr %l169
  store %"compiler/check:reflVal" %t326, ptr %rv
  br label %ret
bb110:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/check:Checker", ptr %t327, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t332 = getelementptr %"compiler/generic:Program", ptr %t330, i32 0, i32 2
  store ptr %t332, ptr %l172, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = getelementptr %"compiler/check:Checker", ptr %t333, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !29
  %t338 = getelementptr %"compiler/generic:Program", ptr %t336, i32 0, i32 2
  %t339 = load i32, ptr %l8, !tbaa !23
  %t342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t338, i32 %t339)
  store i32 %t342, ptr %l177
  br label %bb111
bb111:
  %t343 = load ptr, ptr %l172, !tbaa !29
  %t344 = load i32, ptr %l177, !tbaa !23
  %t345 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t343, i32 %t344)
  store i64 %t345, ptr %l178
  br label %bb112
bb112:
  %t346 = load i64, ptr %l178, !tbaa !24
  %t347 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v2, i64 %t346)
  store %"compiler/check:reflVal" %t347, ptr %l179
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t348 = load %"compiler/check:reflVal", ptr %l179
  store %"compiler/check:reflVal" %t348, ptr %rv
  br label %ret
bb114:
  %t349 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t349, ptr %l180
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t350 = load %"compiler/check:reflVal", ptr %l180
  store %"compiler/check:reflVal" %t350, ptr %rv
  br label %ret
bb116:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t355 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t351, ptr %t352)
  store i32 %t355, ptr %l183
  br label %bb117
bb117:
  %t356 = load i32, ptr %l183, !tbaa !23
  store i32 %t356, ptr %l9, !tbaa !23
  %t357 = load i32, ptr %l9, !tbaa !23
  %t359 = icmp slt i32 %t357, 0
  br i1 %t359, label %bb118, label %bb119
bb118:
  %t361 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t361, ptr %l186
  br label %bb120
bb119:
  br label %bb121
bb120:
  call void @__olang_scope_close(ptr %s0)
  %t362 = load %"compiler/check:reflVal", ptr %l186
  store %"compiler/check:reflVal" %t362, ptr %rv
  br label %ret
bb121:
  %t363 = load i32, ptr %l9, !tbaa !23
  %t364 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t367 = icmp eq i32 %t363, %t364
  br i1 %t367, label %bb122, label %bb123
bb122:
  %t369 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t369, ptr %l190
  br label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_scope_close(ptr %s0)
  %t370 = load %"compiler/check:reflVal", ptr %l190
  store %"compiler/check:reflVal" %t370, ptr %rv
  br label %ret
bb125:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/check:Checker", ptr %t371, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t375 = load i32, ptr %l9, !tbaa !23
  %t378 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t374, i32 %t375)
  store %"compiler/generic:Desc" %t378, ptr %l194
  br label %bb126
bb126:
  %t379 = load %"compiler/generic:Desc", ptr %l194
  store %"compiler/generic:Desc" %t379, ptr %l10
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 136
  store i1 true, ptr %t382, !tbaa !21
  %t383 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t385 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t383, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t385, ptr %l197
  br label %bb127
bb127:
  %t386 = load i1, ptr %l197, !tbaa !21
  br i1 %t386, label %bb128, label %bb129
bb128:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load %"compiler/generic:Desc", ptr %l10
  %t391 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %v2, ptr %t387, %"compiler/generic:Desc" %t388)
  store { i64, ptr } %t391, ptr %l200
  br label %bb130
bb129:
  br label %bb132
bb130:
  %t392 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 0
  %t394 = extractvalue { i64, ptr } %t392, 1
  %t395 = mul i64 %t393, 1
  %t396 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t395)
  call void @llvm.memcpy.p0.p0.i64(ptr %t396, ptr %t394, i64 %t395, i1 false)
  %t397 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  %t400 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervText(ptr %v2, ptr %v2, { i64, ptr } %t398)
  store %"compiler/check:reflVal" %t400, ptr %l202
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s0)
  %t401 = load %"compiler/check:reflVal", ptr %l202
  store %"compiler/check:reflVal" %t401, ptr %rv
  br label %ret
bb132:
  %t402 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t404 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t402, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t404, ptr %l204
  br label %bb133
bb133:
  %t405 = load i1, ptr %l204, !tbaa !21
  br i1 %t405, label %bb134, label %bb135
bb134:
  %t406 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t407 = load i64, ptr %t406, !tbaa !24
  %t408 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t411 = icmp eq i64 %t407, %t408
  store i1 %t411, ptr %l205, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb136
bb136:
  %t413 = load i1, ptr %l205, !tbaa !21
  br i1 %t413, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s17
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load %"compiler/generic:Desc", ptr %l10
  %t418 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %s17, ptr %t414, %"compiler/generic:Desc" %t415)
  store ptr %t418, ptr %l211
  br label %bb139
bb138:
  br label %bb141
bb139:
  %t419 = load ptr, ptr %l211, !tbaa !29
  %t420 = icmp eq ptr %t419, null
  %t422 = xor i1 %t420, true
  %t424 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervBool(ptr %v2, i1 %t422)
  store %"compiler/check:reflVal" %t424, ptr %l214
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t425 = load %"compiler/check:reflVal", ptr %l214
  store %"compiler/check:reflVal" %t425, ptr %rv
  br label %ret
bb141:
  %t426 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t428 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t426, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t428, ptr %l216
  br label %bb142
bb142:
  %t429 = load i1, ptr %l216, !tbaa !21
  br i1 %t429, label %bb143, label %bb144
bb143:
  %t430 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t431 = load i64, ptr %t430, !tbaa !24
  %t432 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t435 = icmp eq i64 %t431, %t432
  store i1 %t435, ptr %l217, !tbaa !21
  br label %bb145
bb144:
  store i1 false, ptr %l217, !tbaa !21
  br label %bb145
bb145:
  %t437 = load i1, ptr %l217, !tbaa !21
  br i1 %t437, label %bb146, label %bb147
bb146:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load %"compiler/generic:Desc", ptr %l10
  %t442 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldOffset(ptr %v0, ptr %t438, %"compiler/generic:Desc" %t439)
  store i64 %t442, ptr %l223
  br label %bb148
bb147:
  br label %bb154
bb148:
  %t443 = load i64, ptr %l223, !tbaa !24
  store i64 %t443, ptr %l11, !tbaa !24
  %t444 = load i64, ptr %l11, !tbaa !24
  %t446 = icmp sge i64 %t444, 0
  br i1 %t446, label %bb149, label %bb150
bb149:
  %t448 = load i64, ptr %l11, !tbaa !24
  %t450 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v2, i64 %t448)
  store %"compiler/check:reflVal" %t450, ptr %l228
  br label %bb151
bb150:
  %t451 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t451, ptr %l229
  br label %bb152
bb151:
  %t452 = load %"compiler/check:reflVal", ptr %l228
  store %"compiler/check:reflVal" %t452, ptr %l226
  br label %bb153
bb152:
  %t453 = load %"compiler/check:reflVal", ptr %l229
  store %"compiler/check:reflVal" %t453, ptr %l226
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s0)
  %t454 = load %"compiler/check:reflVal", ptr %l226
  store %"compiler/check:reflVal" %t454, ptr %rv
  br label %ret
bb154:
  %t455 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t457 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t455, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t457, ptr %l231
  br label %bb155
bb155:
  %t458 = load i1, ptr %l231, !tbaa !21
  br i1 %t458, label %bb156, label %bb157
bb156:
  store i1 true, ptr %l232, !tbaa !21
  br label %bb159
bb157:
  %t459 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t461 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t459, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t461, ptr %l234
  br label %bb158
bb158:
  %t462 = load i1, ptr %l234, !tbaa !21
  store i1 %t462, ptr %l232, !tbaa !21
  br label %bb159
bb159:
  %t463 = load i1, ptr %l232, !tbaa !21
  br i1 %t463, label %bb160, label %bb161
bb160:
  %t464 = getelementptr %"compiler/generic:Desc", ptr %l10, i32 0, i32 0
  %t465 = load i64, ptr %t464, !tbaa !24
  %t466 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t469 = icmp eq i64 %t465, %t466
  store i1 %t469, ptr %l235, !tbaa !21
  br label %bb162
bb161:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb162
bb162:
  %t471 = load i1, ptr %l235, !tbaa !21
  br i1 %t471, label %bb163, label %bb164
bb163:
  store %olang.scope zeroinitializer, ptr %s19
  %t472 = load ptr, ptr %l0, !tbaa !29
  store ptr %t472, ptr %l239, !tbaa !29
  %t473 = load %"compiler/generic:Desc", ptr %l10
  store %"compiler/generic:Desc" %t473, ptr %l240
  %t474 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t476 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s19, { i64, ptr } %t474, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t476, ptr %l242
  br label %bb165
bb164:
  br label %bb172
bb165:
  %t477 = load ptr, ptr %l239, !tbaa !29
  %t478 = load %"compiler/generic:Desc", ptr %l240
  %t479 = load i1, ptr %l242, !tbaa !21
  %t480 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldBits(ptr %v0, ptr %t477, %"compiler/generic:Desc" %t478, i1 %t479)
  store i64 %t480, ptr %l243
  br label %bb166
bb166:
  %t481 = load i64, ptr %l243, !tbaa !24
  store i64 %t481, ptr %l12, !tbaa !24
  %t482 = load i64, ptr %l12, !tbaa !24
  %t484 = icmp sge i64 %t482, 0
  br i1 %t484, label %bb167, label %bb168
bb167:
  %t486 = load i64, ptr %l12, !tbaa !24
  %t488 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v2, i64 %t486)
  store %"compiler/check:reflVal" %t488, ptr %l248
  br label %bb169
bb168:
  %t489 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t489, ptr %l249
  br label %bb170
bb169:
  %t490 = load %"compiler/check:reflVal", ptr %l248
  store %"compiler/check:reflVal" %t490, ptr %l246
  br label %bb171
bb170:
  %t491 = load %"compiler/check:reflVal", ptr %l249
  store %"compiler/check:reflVal" %t491, ptr %l246
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t492 = load %"compiler/check:reflVal", ptr %l246
  store %"compiler/check:reflVal" %t492, ptr %rv
  br label %ret
bb172:
  %t493 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t493, ptr %l250
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s0)
  %t494 = load %"compiler/check:reflVal", ptr %l250
  store %"compiler/check:reflVal" %t494, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflHasAttr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { ptr, { i64, ptr }, %"compiler/source:Span" }
  %l5 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, i32 }
  %l13 = alloca { ptr, { i64, ptr }, %"compiler/source:Span" }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l19 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i1
  %l29 = alloca %"compiler/check:reflVal"
  %l32 = alloca i32
  %l35 = alloca %"compiler/check:reflVal"
  %l40 = alloca %"compiler/check:reflVal"
  %l42 = alloca { i64, ptr }
  %l45 = alloca i32
  %l49 = alloca %"compiler/check:reflVal"
  %l53 = alloca { i64, i32 }
  %l57 = alloca %"compiler/check:reflVal"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflVal"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { ptr, { i64, ptr }, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrCallee(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store { ptr, { i64, ptr }, %"compiler/source:Span" } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l13
  store { ptr, { i64, ptr }, %"compiler/source:Span" } %t6, ptr %l4
  %t7 = getelementptr { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l4, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t10 = getelementptr { ptr, { i64, ptr }, %"compiler/source:Span" }, ptr %l4, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l15, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l16, !tbaa !24
  %t14 = load i64, ptr %l16, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t28, ptr %l19
  br label %bb2
bb2:
  %t29 = load i1, ptr %l19, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t36 = icmp ne i64 %t34, 1
  store i1 %t36, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t41 = extractvalue { i64, ptr } %a3, 0
  %t43 = icmp ne i64 %t41, 0
  store i1 %t43, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t45 = load i1, ptr %l25, !tbaa !21
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t46 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v4)
  store %"compiler/check:reflVal" %t46, ptr %l29
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load %"compiler/check:reflVal", ptr %l29
  store %"compiler/check:reflVal" %t47, ptr %rv
  br label %ret
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t52 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrHolder(ptr %v0, ptr %s0, ptr %t48, ptr %t49)
  store i32 %t52, ptr %l32
  br label %bb13
bb13:
  %t53 = load i32, ptr %l32, !tbaa !23
  store i32 %t53, ptr %l7, !tbaa !23
  %t54 = load i32, ptr %l7, !tbaa !23
  %t56 = icmp slt i32 %t54, 0
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t58 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v4)
  store %"compiler/check:reflVal" %t58, ptr %l35
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load %"compiler/check:reflVal", ptr %l35
  store %"compiler/check:reflVal" %t59, ptr %rv
  br label %ret
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 136
  store i1 true, ptr %t62, !tbaa !21
  %t63 = load i32, ptr %l7, !tbaa !23
  %t64 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t67 = icmp eq i32 %t63, %t64
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v4)
  store %"compiler/check:reflVal" %t69, ptr %l40
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t70 = load %"compiler/check:reflVal", ptr %l40
  store %"compiler/check:reflVal" %t70, ptr %rv
  br label %ret
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t72, ptr %l42, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 0
  %t76 = load ptr, ptr %t75, !tbaa !39
  %t80 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v2, ptr %t71, ptr %t76)
  store i32 %t80, ptr %l45
  br label %bb22
bb22:
  %t81 = load i32, ptr %l45, !tbaa !23
  store i32 %t81, ptr %l8, !tbaa !23
  %t82 = load i32, ptr %l8, !tbaa !23
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t86 = icmp eq i32 %t82, %t83
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t88 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v4)
  store %"compiler/check:reflVal" %t88, ptr %l49
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load %"compiler/check:reflVal", ptr %l49
  store %"compiler/check:reflVal" %t89, ptr %rv
  br label %ret
bb26:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l7, !tbaa !23
  %t92 = load i32, ptr %l8, !tbaa !23
  %t96 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrFound(ptr %v0, ptr %t90, i32 %t91, i32 %t92)
  store { i64, i32 } %t96, ptr %l53
  br label %bb27
bb27:
  %t97 = load { i64, i32 }, ptr %l53
  store { i64, i32 } %t97, ptr %l9
  %t98 = getelementptr { i64, i32 }, ptr %l9, i32 0, i32 0
  %t99 = load i64, ptr %t98, !tbaa !24
  %t103 = icmp sge i64 %t99, 0
  %t105 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervBool(ptr %v4, i1 %t103)
  store %"compiler/check:reflVal" %t105, ptr %l57
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t106 = load %"compiler/check:reflVal", ptr %l57
  store %"compiler/check:reflVal" %t106, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflLen(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca %"compiler/check:reflList"
  %l5 = alloca { { i64, ptr }, { i64, ptr } }
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l13 = alloca i1
  %l17 = alloca %"compiler/check:reflVal"
  %l20 = alloca %"compiler/check:reflList"
  %l23 = alloca %"compiler/check:reflVal"
  %l28 = alloca %"compiler/check:reflVal"
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca { { i64, ptr }, { i64, ptr } }
  %l42 = alloca i1
  %l43 = alloca %"compiler/check:reflVal"
  %l46 = alloca %"compiler/check:reflVal"
  %l47 = alloca %"compiler/check:reflVal"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflVal"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %a2)
  store { i64, ptr } %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i1, ptr %l11, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  %t13 = extractvalue { i64, ptr } %a3, 0
  %t15 = icmp ne i64 %t13, 0
  store i1 %t15, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v3)
  store %"compiler/check:reflVal" %t18, ptr %l17
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load %"compiler/check:reflVal", ptr %l17
  store %"compiler/check:reflVal" %t19, ptr %rv
  br label %ret
bb9:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t24 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t20, ptr %a1)
  store %"compiler/check:reflList" %t24, ptr %l20
  br label %bb10
bb10:
  %t25 = load %"compiler/check:reflList", ptr %l20
  store %"compiler/check:reflList" %t25, ptr %l4
  %t26 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 0
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v3)
  store %"compiler/check:reflVal" %t31, ptr %l23
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load %"compiler/check:reflVal", ptr %l23
  store %"compiler/check:reflVal" %t32, ptr %rv
  br label %ret
bb14:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 136
  store i1 true, ptr %t35, !tbaa !21
  %t36 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 1
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t41 = icmp eq i32 %t37, %t38
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v3)
  store %"compiler/check:reflVal" %t43, ptr %l28
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load %"compiler/check:reflVal", ptr %l28
  store %"compiler/check:reflVal" %t44, ptr %rv
  br label %ret
bb18:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l30, !tbaa !29
  %t49 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  store i32 %t50, ptr %l31, !tbaa !23
  %t51 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 2
  %t52 = load i64, ptr %t51, !tbaa !24
  store i64 %t52, ptr %l32, !tbaa !24
  %t53 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 3
  %t54 = load i64, ptr %t53, !tbaa !24
  store i64 %t54, ptr %l33, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t55)
  store ptr %t57, ptr %l35
  br label %bb19
bb19:
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t60 = getelementptr %"compiler/check:frame", ptr %t58, i32 0, i32 1
  %t61 = load i64, ptr %t60, !tbaa !24
  %t62 = load ptr, ptr %l30, !tbaa !29
  %t63 = load i32, ptr %l31, !tbaa !23
  %t64 = load i64, ptr %l32, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t67 = call { { i64, ptr }, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflItems(ptr %v0, ptr %s0, ptr %t62, i32 %t63, i64 %t64, i64 %t65, i64 %t61)
  store { { i64, ptr }, { i64, ptr } } %t67, ptr %l38
  br label %bb20
bb20:
  %t68 = load { { i64, ptr }, { i64, ptr } }, ptr %l38
  store { { i64, ptr }, { i64, ptr } } %t68, ptr %l5
  %t69 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l5, i32 0, i32 0
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l6, !tbaa !27
  %t72 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l5, i32 0, i32 1
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t77, ptr %l42
  br label %bb21
bb21:
  %t78 = load i1, ptr %l42, !tbaa !21
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t79 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t83 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v3, i64 %t81)
  store %"compiler/check:reflVal" %t83, ptr %l46
  br label %bb24
bb23:
  %t84 = call %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v3)
  store %"compiler/check:reflVal" %t84, ptr %l47
  br label %bb25
bb24:
  %t85 = load %"compiler/check:reflVal", ptr %l46
  store %"compiler/check:reflVal" %t85, ptr %l43
  br label %bb26
bb25:
  %t86 = load %"compiler/check:reflVal", ptr %l47
  store %"compiler/check:reflVal" %t86, ptr %l43
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load %"compiler/check:reflVal", ptr %l43
  store %"compiler/check:reflVal" %t87, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflName(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l6 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l19 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l33 = alloca i64
  %l34 = alloca ptr
  %l39 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 4
  %t7 = getelementptr %"compiler/generic:Context", ptr %t6, i32 0, i32 3
  %t11 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t7, i32 %a2)
  %t12 = extractvalue { i32, i32 } %t11, 1
  %t13 = extractvalue { i32, i32 } %t11, 0
  store i32 %t13, ptr %l11
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store i32 %t12, ptr %l10
  br label %bb2
bb2:
  %t16 = load i32, ptr %l10, !tbaa !23
  store i32 %t16, ptr %l4, !tbaa !23
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l4, !tbaa !23
  br label %bb5
bb5:
  %t17 = load i32, ptr %l4, !tbaa !23
  store i32 %t17, ptr %l3, !tbaa !23
  %t18 = load i32, ptr %l3, !tbaa !23
  %t20 = icmp slt i32 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb6:
  store ptr null, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l19
  br label %bb9
bb9:
  %t33 = load i32, ptr %l19, !range !{i32 0, i32 33}
  %t35 = trunc i64 26 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t39, ptr %l23
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l3, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l28
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t55, i32 %t56)
  store i64 %t59, ptr %l33
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l22, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l23
  %t62 = load i32, ptr %l28, !tbaa !23
  %t63 = load i64, ptr %l33, !tbaa !24
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t60, %"compiler/source:Span" %t61, i32 %t62, i64 %t63)
  store ptr %t64, ptr %l34
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l34, !tbaa !29
  store ptr %t65, ptr %rv
  br label %ret
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l1
  %t69 = load i32, ptr %l3, !tbaa !23
  %t73 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %t67, %"compiler/source:Span" %t68, i32 %t69)
  store ptr %t73, ptr %l39
  br label %bb16
bb16:
  %t74 = load ptr, ptr %l39, !tbaa !29
  store ptr %t74, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 74
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t4, i64 %a1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l6
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H77423593ceb02e5da917ccb6013316ec(ptr %v0, ptr %t9, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10)
  store i1 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i1, ptr %l7, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i1
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t21)
  store i32 %t24, ptr %l16
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l16, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t27, ptr %l17
  br label %bb9
bb9:
  %t28 = load i1, ptr %l17, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l12, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 83
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t35)
  store ptr %t37, ptr %l22
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t45 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, ptr %v0, i64 %t41, ptr %t42)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t45, ptr %l26
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v0, ptr %t46, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t47)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/diagmsg:Msg"
  %l10 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca %"compiler/diagmsg:Msg"
  %l53 = alloca { i64, ptr }
  %l56 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca { i64, ptr }
  %l64 = alloca %"compiler/diagmsg:Msg"
  %l69 = alloca { i64, ptr }
  %l72 = alloca %"compiler/diagmsg:Msg"
  %l76 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca i64
  %l82 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i1, ptr %l10, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb19
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l16, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t16)
  store i32 %t19, ptr %l19
  br label %bb6
bb5:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i32, ptr %l19, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l20
  br label %bb7
bb7:
  %t23 = load i1, ptr %l20, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l22, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t28)
  store ptr %t30, ptr %l24
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t31 = load ptr, ptr %l22, !tbaa !29
  %t32 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load i64, ptr @G_2ecompiler_2fcheck_2eRoReturned, !tbaa !24
  %t37 = icmp eq i64 %t33, %t34
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroResult(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb16
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb19:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t48)
  store i32 %t50, ptr %l34
  br label %bb20
bb20:
  %t51 = load i32, ptr %l34, !tbaa !23
  store i32 %t51, ptr %l4, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l35, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l36, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  br i1 %t56, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_57dc1f8c088d198a_6c44e525bc3c6ade)
  unreachable
bb22:
  br label %bb23
bb23:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load ptr, ptr %l36, !tbaa !29
  %t61 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t59, ptr %t58)
  store i32 %t61, ptr %l40
  br label %bb24
bb24:
  %t62 = load i32, ptr %l4, !tbaa !23
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t64 = load i32, ptr %l40, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %s0, ptr %t63, i32 %t64, i32 %t62)
  store { i64, ptr } %t66, ptr %l42
  br label %bb25
bb25:
  %t67 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t67, ptr %l5, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l4, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l45
  br label %bb26
bb26:
  %t73 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = extractvalue { i64, ptr } %t73, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t83 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyStored(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t79, { i64, ptr } %t80)
  store %"compiler/diagmsg:Msg" %t83, ptr %l48
  br label %bb27
bb27:
  %t84 = load %"compiler/diagmsg:Msg", ptr %l48
  store %"compiler/diagmsg:Msg" %t84, ptr %l6
  %t85 = load i64, ptr %l3, !tbaa !24
  %t87 = icmp eq i64 %t85, 1
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l4, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t89, i32 %t90)
  store { i64, ptr } %t93, ptr %l53
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t94 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t101 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t104 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyDecl(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t100, { i64, ptr } %t101)
  store %"compiler/diagmsg:Msg" %t104, ptr %l56
  br label %bb31
bb31:
  %t105 = load %"compiler/diagmsg:Msg", ptr %l56
  store %"compiler/diagmsg:Msg" %t105, ptr %l6
  br label %bb32
bb32:
  %t106 = load i64, ptr %l3, !tbaa !24
  %t108 = icmp eq i64 %t106, 2
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i32, ptr %l4, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t110, i32 %t111)
  store { i64, ptr } %t114, ptr %l61
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t115 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  %t117 = extractvalue { i64, ptr } %t115, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t122 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t125 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyReturned(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t121, { i64, ptr } %t122)
  store %"compiler/diagmsg:Msg" %t125, ptr %l64
  br label %bb36
bb36:
  %t126 = load %"compiler/diagmsg:Msg", ptr %l64
  store %"compiler/diagmsg:Msg" %t126, ptr %l6
  br label %bb37
bb37:
  %t127 = load i64, ptr %l3, !tbaa !24
  %t129 = icmp eq i64 %t127, 3
  br i1 %t129, label %bb38, label %bb39
bb38:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l4, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t131, i32 %t132)
  store { i64, ptr } %t135, ptr %l69
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t136 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t138 = extractvalue { i64, ptr } %t136, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t143 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t146 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyGlobal(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t142, { i64, ptr } %t143)
  store %"compiler/diagmsg:Msg" %t146, ptr %l72
  br label %bb41
bb41:
  %t147 = load %"compiler/diagmsg:Msg", ptr %l72
  store %"compiler/diagmsg:Msg" %t147, ptr %l6
  br label %bb42
bb42:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = load %"compiler/diagmsg:Msg", ptr %l6
  %t154 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t148, %"compiler/source:Span" %a2, %"compiler/diagmsg:Msg" %t150)
  store i64 %t154, ptr %l76
  br label %bb43
bb43:
  %t155 = load i64, ptr %l76, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l77, !tbaa !29
  store i64 %t155, ptr %l78, !tbaa !24
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = icmp eq ptr %t158, null
  br i1 %t160, label %bb44, label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_658c1f9b991d3291_83ad80e13fec4285)
  unreachable
bb45:
  br label %bb46
bb46:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %s0, ptr %t162)
  store ptr %t164, ptr %l82
  br label %bb47
bb47:
  %t165 = load ptr, ptr %l77, !tbaa !29
  %t166 = load i64, ptr %l78, !tbaa !24
  %t167 = load ptr, ptr %l82, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %s0, ptr %t165, i64 %t166, ptr %t167)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 3
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t26, ptr %l19
  br label %bb9
bb9:
  %t27 = load i1, ptr %l19, !tbaa !21
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb36
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 4
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Elem", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t43, ptr %t47)
  store i1 %t51, ptr %l30
  br label %bb16
bb16:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %l9, !tbaa !21
  br label %bb36
bb17:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 8}
  %t60 = icmp eq i64 %t58, 5
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l32, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Payload", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t68, ptr %t72)
  store i1 %t76, ptr %l41
  br label %bb23
bb23:
  %t77 = load i1, ptr %l41, !tbaa !21
  store i1 %t77, ptr %l9, !tbaa !21
  br label %bb36
bb24:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t79 = load ptr, ptr %l42, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb25, label %bb26
bb25:
  %t82 = load ptr, ptr %l42, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 6
  store i1 %t85, ptr %l43, !tbaa !21
  br label %bb26
bb26:
  %t86 = load i1, ptr %l43, !tbaa !21
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t98 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  store i1 %t98, ptr %l51
  br label %bb30
bb30:
  %t99 = load i1, ptr %l51, !tbaa !21
  store i1 %t99, ptr %l9, !tbaa !21
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_19fb235390dd08bf_74b3a6d5c5264653)
  unreachable
bb36:
  %t100 = load i1, ptr %l9, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t7 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t14 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l12
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  %t36 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t36, i32 %t34)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l4, !tbaa !24
  br label %bb3
bb9:
  %t44 = load ptr, ptr %lp2
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l15 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 142
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t3)
  br label %bb1
bb1:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 %t20
  %t25 = load i64, ptr %t24, !tbaa !34
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 142
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t29, i64 %t25)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %l49 = alloca i1
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca { i64, ptr }
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i1
  %l171 = alloca ptr
  %l172 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca i1
  %l207 = alloca ptr
  %l208 = alloca i1
  %l218 = alloca ptr
  %l219 = alloca i1
  %l229 = alloca ptr
  %l230 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i1
  %l254 = alloca ptr
  %l255 = alloca i1
  %l263 = alloca ptr
  %l270 = alloca ptr
  %l271 = alloca i1
  %l284 = alloca ptr
  %l285 = alloca i1
  %l295 = alloca ptr
  %l296 = alloca i1
  %l309 = alloca ptr
  %l310 = alloca i1
  %l317 = alloca ptr
  %l318 = alloca %"compiler/source:Span"
  %l323 = alloca ptr
  %l326 = alloca ptr
  %l327 = alloca i1
  %l337 = alloca ptr
  %l338 = alloca i1
  %l351 = alloca ptr
  %l353 = alloca %"compiler/source:Span"
  %s25 = alloca %olang.scope
  %t651 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t6 = load ptr, ptr %l59, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l59, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 22}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l60, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l60, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l2
  %t28 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %t26, %"compiler/source:Span" %t27, ptr %t28)
  br label %bb9
bb9:
  br label %bb175
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t33 = load ptr, ptr %l70, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l70, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 22}
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l71, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l71, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr }, ptr %t43, i32 0, i32 0
  %t45 = load %"compiler/source:Span", ptr %t44
  store %"compiler/source:Span" %t45, ptr %l4
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l4
  %t55 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarDecl(ptr %v0, ptr %v1, ptr %t53, %"compiler/source:Span" %t54, ptr %t55)
  br label %bb16
bb16:
  br label %bb175
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t60 = load ptr, ptr %l81, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l81, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 22}
  %t66 = icmp eq i64 %t64, 2
  store i1 %t66, ptr %l82, !tbaa !21
  br label %bb19
bb19:
  %t67 = load i1, ptr %l82, !tbaa !21
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr }, ptr %t70, i32 0, i32 0
  %t72 = load %"compiler/source:Span", ptr %t71
  store %"compiler/source:Span" %t72, ptr %l6
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l6
  %t82 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emulti(ptr %v0, ptr %v1, ptr %t80, %"compiler/source:Span" %t81, ptr %t82)
  br label %bb23
bb23:
  br label %bb175
bb24:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t87 = load ptr, ptr %l92, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l92, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 22}
  %t93 = icmp eq i64 %t91, 3
  store i1 %t93, ptr %l93, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l93, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t97, i32 0, i32 0
  %t99 = load %"compiler/source:Span", ptr %t98
  store %"compiler/source:Span" %t99, ptr %l8
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t103, i32 0, i32 1
  %t105 = load i32, ptr %t104, !range !{i32 0, i32 98}
  store i32 %t105, ptr %l9
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [4 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l10, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t115, i32 0, i32 3
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l11, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l8
  %t121 = load i32, ptr %l9, !range !{i32 0, i32 98}
  %t122 = load ptr, ptr %l10, !tbaa !29
  %t123 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %t119, %"compiler/source:Span" %t120, i32 %t121, ptr %t122, ptr %t123)
  br label %bb30
bb30:
  br label %bb175
bb31:
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t130 = load ptr, ptr %l109, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t133 = load ptr, ptr %l109, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 22}
  %t136 = icmp eq i64 %t134, 4
  store i1 %t136, ptr %l110, !tbaa !21
  br label %bb33
bb33:
  %t137 = load i1, ptr %l110, !tbaa !21
  br i1 %t137, label %bb34, label %bb35
bb34:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t140, i32 0, i32 0
  %t142 = load %"compiler/source:Span", ptr %t141
  store %"compiler/source:Span" %t142, ptr %l12
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t146, i32 0, i32 1
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l13, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t152, i32 0, i32 2
  %t154 = load { i64, ptr }, ptr %t153
  store { i64, ptr } %t154, ptr %l14, !tbaa !27
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l12
  %t158 = load ptr, ptr %l13, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryStore(ptr %v0, ptr %v1, ptr %v1, ptr %t156, %"compiler/source:Span" %t157, ptr %t158, { i64, ptr } %t159)
  br label %bb37
bb37:
  br label %bb175
bb38:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t165 = load ptr, ptr %l123, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb39, label %bb40
bb39:
  %t168 = load ptr, ptr %l123, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 22}
  %t171 = icmp eq i64 %t169, 5
  store i1 %t171, ptr %l124, !tbaa !21
  br label %bb40
bb40:
  %t172 = load i1, ptr %l124, !tbaa !21
  br i1 %t172, label %bb41, label %bb42
bb41:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 0
  %t177 = load %"compiler/source:Span", ptr %t176
  store %"compiler/source:Span" %t177, ptr %l15
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", ptr }, ptr %t181, i32 0, i32 1
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l16, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l15
  %t187 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifStmt(ptr %v0, ptr %v1, ptr %t185, %"compiler/source:Span" %t186, ptr %t187)
  br label %bb44
bb44:
  br label %bb175
bb45:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t192 = load ptr, ptr %l134, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb46, label %bb47
bb46:
  %t195 = load ptr, ptr %l134, !tbaa !29
  %t196 = load i64, ptr %t195, !range !{i64 0, i64 22}
  %t198 = icmp eq i64 %t196, 6
  store i1 %t198, ptr %l135, !tbaa !21
  br label %bb47
bb47:
  %t199 = load i1, ptr %l135, !tbaa !21
  br i1 %t199, label %bb48, label %bb49
bb48:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t202, i32 0, i32 0
  %t204 = load %"compiler/source:Span", ptr %t203
  store %"compiler/source:Span" %t204, ptr %l17
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t208, i32 0, i32 1
  %t210 = load { i64, ptr }, ptr %t209
  store { i64, ptr } %t210, ptr %l18, !tbaa !27
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l17
  %t214 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v0, ptr %v1, ptr %v0, ptr %t212, %"compiler/source:Span" %t213, ptr null, { i64, ptr } %t214, ptr null)
  br label %bb51
bb51:
  br label %bb175
bb52:
  %t218 = load ptr, ptr %l1, !tbaa !29
  store ptr %t218, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t219 = load ptr, ptr %l145, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb53, label %bb54
bb53:
  %t222 = load ptr, ptr %l145, !tbaa !29
  %t223 = load i64, ptr %t222, !range !{i64 0, i64 22}
  %t225 = icmp eq i64 %t223, 7
  store i1 %t225, ptr %l146, !tbaa !21
  br label %bb54
bb54:
  %t226 = load i1, ptr %l146, !tbaa !21
  br i1 %t226, label %bb55, label %bb56
bb55:
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr { i64, [4 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t229, i32 0, i32 0
  %t231 = load %"compiler/source:Span", ptr %t230
  store %"compiler/source:Span" %t231, ptr %l19
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t235, i32 0, i32 1
  %t237 = load ptr, ptr %t236
  store ptr %t237, ptr %l20, !tbaa !29
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t241, i32 0, i32 2
  %t243 = load { i64, ptr }, ptr %t242
  store { i64, ptr } %t243, ptr %l21, !tbaa !27
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l19
  %t247 = load ptr, ptr %l20, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %v0, ptr %t245, %"compiler/source:Span" %t246, ptr %t247, { i64, ptr } %t249, ptr null)
  br label %bb58
bb58:
  br label %bb175
bb59:
  %t254 = load ptr, ptr %l1, !tbaa !29
  store ptr %t254, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t255 = load ptr, ptr %l160, !tbaa !29
  %t256 = icmp ne ptr %t255, null
  br i1 %t256, label %bb60, label %bb61
bb60:
  %t258 = load ptr, ptr %l160, !tbaa !29
  %t259 = load i64, ptr %t258, !range !{i64 0, i64 22}
  %t261 = icmp eq i64 %t259, 8
  store i1 %t261, ptr %l161, !tbaa !21
  br label %bb61
bb61:
  %t262 = load i1, ptr %l161, !tbaa !21
  br i1 %t262, label %bb62, label %bb63
bb62:
  %t263 = load ptr, ptr %l1, !tbaa !29
  %t265 = getelementptr { i64, [4 x i64] }, ptr %t263, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", ptr }, ptr %t265, i32 0, i32 0
  %t267 = load %"compiler/source:Span", ptr %t266
  store %"compiler/source:Span" %t267, ptr %l22
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr { i64, [4 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { %"compiler/source:Span", ptr }, ptr %t271, i32 0, i32 1
  %t273 = load ptr, ptr %t272
  store ptr %t273, ptr %l23, !tbaa !29
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l22
  %t277 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efor3(ptr %v0, ptr %v1, ptr %t275, %"compiler/source:Span" %t276, ptr %t277)
  br label %bb65
bb65:
  br label %bb175
bb66:
  %t281 = load ptr, ptr %l1, !tbaa !29
  store ptr %t281, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t282 = load ptr, ptr %l171, !tbaa !29
  %t283 = icmp ne ptr %t282, null
  br i1 %t283, label %bb67, label %bb68
bb67:
  %t285 = load ptr, ptr %l171, !tbaa !29
  %t286 = load i64, ptr %t285, !range !{i64 0, i64 22}
  %t288 = icmp eq i64 %t286, 9
  store i1 %t288, ptr %l172, !tbaa !21
  br label %bb68
bb68:
  %t289 = load i1, ptr %l172, !tbaa !21
  br i1 %t289, label %bb69, label %bb70
bb69:
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t290, i32 0, i32 1
  %t293 = getelementptr { %"compiler/source:Span", ptr }, ptr %t292, i32 0, i32 0
  %t294 = load %"compiler/source:Span", ptr %t293
  store %"compiler/source:Span" %t294, ptr %l24
  %t296 = load ptr, ptr %l1, !tbaa !29
  %t298 = getelementptr { i64, [4 x i64] }, ptr %t296, i32 0, i32 1
  %t299 = getelementptr { %"compiler/source:Span", ptr }, ptr %t298, i32 0, i32 1
  %t300 = load ptr, ptr %t299
  store ptr %t300, ptr %l25, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load %"compiler/source:Span", ptr %l24
  %t304 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforIn(ptr %v0, ptr %v1, ptr %t302, %"compiler/source:Span" %t303, ptr %t304)
  br label %bb72
bb72:
  br label %bb175
bb73:
  %t308 = load ptr, ptr %l1, !tbaa !29
  store ptr %t308, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t309 = load ptr, ptr %l182, !tbaa !29
  %t310 = icmp ne ptr %t309, null
  br i1 %t310, label %bb74, label %bb75
bb74:
  %t312 = load ptr, ptr %l182, !tbaa !29
  %t313 = load i64, ptr %t312, !range !{i64 0, i64 22}
  %t315 = icmp eq i64 %t313, 10
  store i1 %t315, ptr %l183, !tbaa !21
  br label %bb75
bb75:
  %t316 = load i1, ptr %l183, !tbaa !21
  br i1 %t316, label %bb76, label %bb77
bb76:
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = getelementptr { i64, [4 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t319, i32 0, i32 0
  %t321 = load %"compiler/source:Span", ptr %t320
  store %"compiler/source:Span" %t321, ptr %l26
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr { i64, [4 x i64] }, ptr %t323, i32 0, i32 1
  %t326 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t325, i32 0, i32 1
  %t327 = load { i64, ptr }, ptr %t326
  store { i64, ptr } %t327, ptr %l27, !tbaa !27
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t331 = getelementptr { i64, [4 x i64] }, ptr %t329, i32 0, i32 1
  %t332 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t331, i32 0, i32 2
  %t333 = load ptr, ptr %t332
  store ptr %t333, ptr %l28, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load %"compiler/source:Span", ptr %l26
  %t337 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t338 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edoFor(ptr %v0, ptr %v1, ptr %v1, ptr %t335, %"compiler/source:Span" %t336, { i64, ptr } %t337, ptr %t338)
  br label %bb79
bb79:
  br label %bb175
bb80:
  %t343 = load ptr, ptr %l1, !tbaa !29
  store ptr %t343, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t344 = load ptr, ptr %l196, !tbaa !29
  %t345 = icmp ne ptr %t344, null
  br i1 %t345, label %bb81, label %bb82
bb81:
  %t347 = load ptr, ptr %l196, !tbaa !29
  %t348 = load i64, ptr %t347, !range !{i64 0, i64 22}
  %t350 = icmp eq i64 %t348, 12
  store i1 %t350, ptr %l197, !tbaa !21
  br label %bb82
bb82:
  %t351 = load i1, ptr %l197, !tbaa !21
  br i1 %t351, label %bb83, label %bb84
bb83:
  %t352 = load ptr, ptr %l1, !tbaa !29
  %t354 = getelementptr { i64, [4 x i64] }, ptr %t352, i32 0, i32 1
  %t355 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t354, i32 0, i32 0
  %t356 = load %"compiler/source:Span", ptr %t355
  store %"compiler/source:Span" %t356, ptr %l29
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t360, i32 0, i32 1
  %t362 = load { i64, ptr }, ptr %t361
  store { i64, ptr } %t362, ptr %l30, !tbaa !27
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l29
  %t366 = load { i64, ptr }, ptr %l30, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereturnStmt(ptr %v0, ptr %v1, ptr %t364, %"compiler/source:Span" %t365, { i64, ptr } %t366)
  br label %bb86
bb86:
  br label %bb175
bb87:
  %t370 = load ptr, ptr %l1, !tbaa !29
  store ptr %t370, ptr %l207, !tbaa !29
  store i1 false, ptr %l208, !tbaa !21
  %t371 = load ptr, ptr %l207, !tbaa !29
  %t372 = icmp ne ptr %t371, null
  br i1 %t372, label %bb88, label %bb89
bb88:
  %t374 = load ptr, ptr %l207, !tbaa !29
  %t375 = load i64, ptr %t374, !range !{i64 0, i64 22}
  %t377 = icmp eq i64 %t375, 15
  store i1 %t377, ptr %l208, !tbaa !21
  br label %bb89
bb89:
  %t378 = load i1, ptr %l208, !tbaa !21
  br i1 %t378, label %bb90, label %bb91
bb90:
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [4 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", ptr }, ptr %t381, i32 0, i32 0
  %t383 = load %"compiler/source:Span", ptr %t382
  store %"compiler/source:Span" %t383, ptr %l31
  %t385 = load ptr, ptr %l1, !tbaa !29
  %t387 = getelementptr { i64, [4 x i64] }, ptr %t385, i32 0, i32 1
  %t388 = getelementptr { %"compiler/source:Span", ptr }, ptr %t387, i32 0, i32 1
  %t389 = load ptr, ptr %t388
  store ptr %t389, ptr %l32, !tbaa !29
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load %"compiler/source:Span", ptr %l31
  %t393 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebecomeStmt(ptr %v0, ptr %v1, ptr %t391, %"compiler/source:Span" %t392, ptr %t393)
  br label %bb93
bb93:
  br label %bb175
bb94:
  %t397 = load ptr, ptr %l1, !tbaa !29
  store ptr %t397, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t398 = load ptr, ptr %l218, !tbaa !29
  %t399 = icmp ne ptr %t398, null
  br i1 %t399, label %bb95, label %bb96
bb95:
  %t401 = load ptr, ptr %l218, !tbaa !29
  %t402 = load i64, ptr %t401, !range !{i64 0, i64 22}
  %t404 = icmp eq i64 %t402, 21
  store i1 %t404, ptr %l219, !tbaa !21
  br label %bb96
bb96:
  %t405 = load i1, ptr %l219, !tbaa !21
  br i1 %t405, label %bb97, label %bb98
bb97:
  %t406 = load ptr, ptr %l1, !tbaa !29
  %t408 = getelementptr { i64, [4 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", ptr }, ptr %t408, i32 0, i32 0
  %t410 = load %"compiler/source:Span", ptr %t409
  store %"compiler/source:Span" %t410, ptr %l33
  %t412 = load ptr, ptr %l1, !tbaa !29
  %t414 = getelementptr { i64, [4 x i64] }, ptr %t412, i32 0, i32 1
  %t415 = getelementptr { %"compiler/source:Span", ptr }, ptr %t414, i32 0, i32 1
  %t416 = load ptr, ptr %t415
  store ptr %t416, ptr %l34, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load %"compiler/source:Span", ptr %l33
  %t420 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eyieldStmt(ptr %v0, ptr %v1, ptr %t418, %"compiler/source:Span" %t419, ptr %t420)
  br label %bb100
bb100:
  br label %bb175
bb101:
  %t424 = load ptr, ptr %l1, !tbaa !29
  store ptr %t424, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t425 = load ptr, ptr %l229, !tbaa !29
  %t426 = icmp ne ptr %t425, null
  br i1 %t426, label %bb102, label %bb103
bb102:
  %t428 = load ptr, ptr %l229, !tbaa !29
  %t429 = load i64, ptr %t428, !range !{i64 0, i64 22}
  %t431 = icmp eq i64 %t429, 11
  store i1 %t431, ptr %l230, !tbaa !21
  br label %bb103
bb103:
  %t432 = load i1, ptr %l230, !tbaa !21
  br i1 %t432, label %bb104, label %bb105
bb104:
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t435 = getelementptr { i64, [4 x i64] }, ptr %t433, i32 0, i32 1
  %t436 = getelementptr { %"compiler/source:Span", ptr }, ptr %t435, i32 0, i32 0
  %t437 = load %"compiler/source:Span", ptr %t436
  store %"compiler/source:Span" %t437, ptr %l35
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr { i64, [4 x i64] }, ptr %t439, i32 0, i32 1
  %t442 = getelementptr { %"compiler/source:Span", ptr }, ptr %t441, i32 0, i32 1
  %t443 = load ptr, ptr %t442
  store ptr %t443, ptr %l36, !tbaa !29
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l35
  %t447 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchStmt(ptr %v0, ptr %v1, ptr %t445, %"compiler/source:Span" %t446, ptr %t447)
  br label %bb107
bb107:
  br label %bb175
bb108:
  %t451 = load ptr, ptr %l1, !tbaa !29
  store ptr %t451, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t452 = load ptr, ptr %l240, !tbaa !29
  %t453 = icmp ne ptr %t452, null
  br i1 %t453, label %bb109, label %bb110
bb109:
  %t455 = load ptr, ptr %l240, !tbaa !29
  %t456 = load i64, ptr %t455, !range !{i64 0, i64 22}
  %t458 = icmp eq i64 %t456, 13
  store i1 %t458, ptr %l241, !tbaa !21
  br label %bb110
bb110:
  %t459 = load i1, ptr %l241, !tbaa !21
  br i1 %t459, label %bb111, label %bb112
bb111:
  %t460 = load ptr, ptr %l1, !tbaa !29
  %t462 = getelementptr { i64, [4 x i64] }, ptr %t460, i32 0, i32 1
  %t463 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t462, i32 0, i32 0
  %t464 = load %"compiler/source:Span", ptr %t463
  store %"compiler/source:Span" %t464, ptr %l37
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [4 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t468, i32 0, i32 1
  %t470 = load i32, ptr %t469, !range !{i32 0, i32 98}
  store i32 %t470, ptr %l38
  %t472 = load ptr, ptr %l1, !tbaa !29
  %t474 = getelementptr { i64, [4 x i64] }, ptr %t472, i32 0, i32 1
  %t475 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t474, i32 0, i32 2
  %t476 = load ptr, ptr %t475
  store ptr %t476, ptr %l39, !tbaa !29
  br label %bb113
bb112:
  br label %bb115
bb113:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l37
  %t480 = load i32, ptr %l38, !range !{i32 0, i32 98}
  %t481 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejump(ptr %v0, ptr %v1, ptr %t478, %"compiler/source:Span" %t479, i32 %t480, ptr %t481)
  br label %bb114
bb114:
  br label %bb175
bb115:
  %t486 = load ptr, ptr %l1, !tbaa !29
  store ptr %t486, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t487 = load ptr, ptr %l254, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  br i1 %t488, label %bb116, label %bb117
bb116:
  %t490 = load ptr, ptr %l254, !tbaa !29
  %t491 = load i64, ptr %t490, !range !{i64 0, i64 22}
  %t493 = icmp eq i64 %t491, 14
  store i1 %t493, ptr %l255, !tbaa !21
  br label %bb117
bb117:
  %t494 = load i1, ptr %l255, !tbaa !21
  br i1 %t494, label %bb118, label %bb119
bb118:
  %t495 = load ptr, ptr %l1, !tbaa !29
  %t497 = getelementptr { i64, [4 x i64] }, ptr %t495, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t497, i32 0, i32 0
  %t499 = load %"compiler/source:Span", ptr %t498
  store %"compiler/source:Span" %t499, ptr %l40
  %t501 = load ptr, ptr %l1, !tbaa !29
  %t503 = getelementptr { i64, [4 x i64] }, ptr %t501, i32 0, i32 1
  %t504 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t503, i32 0, i32 1
  %t505 = load ptr, ptr %t504
  store ptr %t505, ptr %l41, !tbaa !29
  br label %bb120
bb119:
  br label %bb125
bb120:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t507)
  store ptr %t509, ptr %l263
  br label %bb121
bb121:
  %t510 = load ptr, ptr %l263, !tbaa !29
  %t512 = getelementptr %"compiler/check:frame", ptr %t510, i32 0, i32 53
  %t513 = load i64, ptr %t512, !tbaa !24
  %t515 = icmp ne i64 %t513, 0
  br i1 %t515, label %bb122, label %bb123
bb122:
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t518 = load %"compiler/source:Span", ptr %l40
  %t519 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectCond(ptr %v0, ptr %v1, ptr %t517, %"compiler/source:Span" %t518, ptr %t519)
  br label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb175
bb125:
  %t523 = load ptr, ptr %l1, !tbaa !29
  store ptr %t523, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t524 = load ptr, ptr %l270, !tbaa !29
  %t525 = icmp ne ptr %t524, null
  br i1 %t525, label %bb126, label %bb127
bb126:
  %t527 = load ptr, ptr %l270, !tbaa !29
  %t528 = load i64, ptr %t527, !range !{i64 0, i64 22}
  %t530 = icmp eq i64 %t528, 14
  store i1 %t530, ptr %l271, !tbaa !21
  br label %bb127
bb127:
  %t531 = load i1, ptr %l271, !tbaa !21
  br i1 %t531, label %bb128, label %bb129
bb128:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr { i64, [4 x i64] }, ptr %t532, i32 0, i32 1
  %t535 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t534, i32 0, i32 0
  %t536 = load %"compiler/source:Span", ptr %t535
  store %"compiler/source:Span" %t536, ptr %l42
  %t538 = load ptr, ptr %l1, !tbaa !29
  %t540 = getelementptr { i64, [4 x i64] }, ptr %t538, i32 0, i32 1
  %t541 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t540, i32 0, i32 1
  %t542 = load ptr, ptr %t541
  store ptr %t542, ptr %l43, !tbaa !29
  %t544 = load ptr, ptr %l1, !tbaa !29
  %t546 = getelementptr { i64, [4 x i64] }, ptr %t544, i32 0, i32 1
  %t547 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t546, i32 0, i32 2
  %t548 = load ptr, ptr %t547
  store ptr %t548, ptr %l44, !tbaa !29
  br label %bb130
bb129:
  br label %bb132
bb130:
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = load %"compiler/source:Span", ptr %l42
  %t552 = load ptr, ptr %l43, !tbaa !29
  %t553 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassertStmt(ptr %v0, ptr %v1, ptr %v1, ptr %t550, %"compiler/source:Span" %t551, ptr %t552, ptr %t553)
  br label %bb131
bb131:
  br label %bb175
bb132:
  %t558 = load ptr, ptr %l1, !tbaa !29
  store ptr %t558, ptr %l284, !tbaa !29
  store i1 false, ptr %l285, !tbaa !21
  %t559 = load ptr, ptr %l284, !tbaa !29
  %t560 = icmp ne ptr %t559, null
  br i1 %t560, label %bb133, label %bb134
bb133:
  %t562 = load ptr, ptr %l284, !tbaa !29
  %t563 = load i64, ptr %t562, !range !{i64 0, i64 22}
  %t565 = icmp eq i64 %t563, 16
  store i1 %t565, ptr %l285, !tbaa !21
  br label %bb134
bb134:
  %t566 = load i1, ptr %l285, !tbaa !21
  br i1 %t566, label %bb135, label %bb136
bb135:
  %t567 = load ptr, ptr %l1, !tbaa !29
  %t569 = getelementptr { i64, [4 x i64] }, ptr %t567, i32 0, i32 1
  %t570 = getelementptr { %"compiler/source:Span", ptr }, ptr %t569, i32 0, i32 0
  %t571 = load %"compiler/source:Span", ptr %t570
  store %"compiler/source:Span" %t571, ptr %l45
  %t573 = load ptr, ptr %l1, !tbaa !29
  %t575 = getelementptr { i64, [4 x i64] }, ptr %t573, i32 0, i32 1
  %t576 = getelementptr { %"compiler/source:Span", ptr }, ptr %t575, i32 0, i32 1
  %t577 = load ptr, ptr %t576
  store ptr %t577, ptr %l46, !tbaa !29
  br label %bb137
bb136:
  br label %bb139
bb137:
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t580 = load %"compiler/source:Span", ptr %l45
  %t581 = load ptr, ptr %l46, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraise(ptr %v0, ptr %v1, ptr %t579, %"compiler/source:Span" %t580, ptr %t581)
  br label %bb138
bb138:
  br label %bb175
bb139:
  %t585 = load ptr, ptr %l1, !tbaa !29
  store ptr %t585, ptr %l295, !tbaa !29
  store i1 false, ptr %l296, !tbaa !21
  %t586 = load ptr, ptr %l295, !tbaa !29
  %t587 = icmp ne ptr %t586, null
  br i1 %t587, label %bb140, label %bb141
bb140:
  %t589 = load ptr, ptr %l295, !tbaa !29
  %t590 = load i64, ptr %t589, !range !{i64 0, i64 22}
  %t592 = icmp eq i64 %t590, 19
  store i1 %t592, ptr %l296, !tbaa !21
  br label %bb141
bb141:
  %t593 = load i1, ptr %l296, !tbaa !21
  br i1 %t593, label %bb142, label %bb143
bb142:
  %t594 = load ptr, ptr %l1, !tbaa !29
  %t596 = getelementptr { i64, [4 x i64] }, ptr %t594, i32 0, i32 1
  %t597 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t596, i32 0, i32 0
  %t598 = load %"compiler/source:Span", ptr %t597
  store %"compiler/source:Span" %t598, ptr %l47
  %t600 = load ptr, ptr %l1, !tbaa !29
  %t602 = getelementptr { i64, [4 x i64] }, ptr %t600, i32 0, i32 1
  %t603 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t602, i32 0, i32 1
  %t604 = load ptr, ptr %t603
  store ptr %t604, ptr %l48, !tbaa !29
  %t606 = load ptr, ptr %l1, !tbaa !29
  %t608 = getelementptr { i64, [4 x i64] }, ptr %t606, i32 0, i32 1
  %t609 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t608, i32 0, i32 2
  %t610 = load i1, ptr %t609
  store i1 %t610, ptr %l49, !tbaa !21
  br label %bb144
bb143:
  br label %bb146
bb144:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = load %"compiler/source:Span", ptr %l47
  %t614 = load ptr, ptr %l48, !tbaa !29
  %t615 = load i1, ptr %l49, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeferStmt(ptr %v0, ptr %v1, ptr %t612, %"compiler/source:Span" %t613, ptr %t614, i1 %t615)
  br label %bb145
bb145:
  br label %bb175
bb146:
  %t620 = load ptr, ptr %l1, !tbaa !29
  store ptr %t620, ptr %l309, !tbaa !29
  store i1 false, ptr %l310, !tbaa !21
  %t621 = load ptr, ptr %l309, !tbaa !29
  %t622 = icmp ne ptr %t621, null
  br i1 %t622, label %bb147, label %bb148
bb147:
  %t624 = load ptr, ptr %l309, !tbaa !29
  %t625 = load i64, ptr %t624, !range !{i64 0, i64 22}
  %t627 = icmp eq i64 %t625, 20
  store i1 %t627, ptr %l310, !tbaa !21
  br label %bb148
bb148:
  %t628 = load i1, ptr %l310, !tbaa !21
  br i1 %t628, label %bb149, label %bb150
bb149:
  %t629 = load ptr, ptr %l1, !tbaa !29
  %t631 = getelementptr { i64, [4 x i64] }, ptr %t629, i32 0, i32 1
  %t632 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t631, i32 0, i32 0
  %t633 = load %"compiler/source:Span", ptr %t632
  store %"compiler/source:Span" %t633, ptr %l50
  %t635 = load ptr, ptr %l1, !tbaa !29
  %t637 = getelementptr { i64, [4 x i64] }, ptr %t635, i32 0, i32 1
  %t638 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t637, i32 0, i32 1
  %t639 = load { i64, ptr }, ptr %t638
  store { i64, ptr } %t639, ptr %l51, !tbaa !27
  br label %bb151
bb150:
  br label %bb154
bb151:
  %t641 = load ptr, ptr %l0, !tbaa !29
  store ptr %t641, ptr %l317, !tbaa !29
  %t642 = load %"compiler/source:Span", ptr %l50
  store %"compiler/source:Span" %t642, ptr %l318
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t644 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t645 = load %"compiler/source:Span", ptr %l50
  %t650 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v0, ptr %t643, { i64, ptr } %t644, i32 1, %"compiler/source:Span" %t645)
  store ptr %t650, ptr %l323
  br label %bb152
bb152:
  store { i64, [3 x i64] } zeroinitializer, ptr %t651
  %t652 = getelementptr { i64, [3 x i64] }, ptr %t651, i32 0, i32 0
  store i64 11, ptr %t652
  %t653 = load %"compiler/source:Span", ptr %l318
  %t654 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t653, 0
  %t655 = load ptr, ptr %l323, !tbaa !29
  %t656 = insertvalue { %"compiler/source:Span", ptr } %t654, ptr %t655, 1
  %t657 = getelementptr { i64, [3 x i64] }, ptr %t651, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t656, ptr %t657
  %t658 = load { i64, [3 x i64] }, ptr %t651
  %t660 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t658, ptr %t660
  %t661 = load ptr, ptr %l317, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t661, ptr %t660)
  br label %bb153
bb153:
  br label %bb175
bb154:
  %t663 = load ptr, ptr %l1, !tbaa !29
  store ptr %t663, ptr %l326, !tbaa !29
  store i1 false, ptr %l327, !tbaa !21
  %t664 = load ptr, ptr %l326, !tbaa !29
  %t665 = icmp ne ptr %t664, null
  br i1 %t665, label %bb155, label %bb156
bb155:
  %t667 = load ptr, ptr %l326, !tbaa !29
  %t668 = load i64, ptr %t667, !range !{i64 0, i64 22}
  %t670 = icmp eq i64 %t668, 18
  store i1 %t670, ptr %l327, !tbaa !21
  br label %bb156
bb156:
  %t671 = load i1, ptr %l327, !tbaa !21
  br i1 %t671, label %bb157, label %bb158
bb157:
  %t672 = load ptr, ptr %l1, !tbaa !29
  %t674 = getelementptr { i64, [4 x i64] }, ptr %t672, i32 0, i32 1
  %t675 = getelementptr { %"compiler/source:Span", ptr }, ptr %t674, i32 0, i32 0
  %t676 = load %"compiler/source:Span", ptr %t675
  store %"compiler/source:Span" %t676, ptr %l52
  %t678 = load ptr, ptr %l1, !tbaa !29
  %t680 = getelementptr { i64, [4 x i64] }, ptr %t678, i32 0, i32 1
  %t681 = getelementptr { %"compiler/source:Span", ptr }, ptr %t680, i32 0, i32 1
  %t682 = load ptr, ptr %t681
  store ptr %t682, ptr %l53, !tbaa !29
  br label %bb159
bb158:
  br label %bb161
bb159:
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t685 = load %"compiler/source:Span", ptr %l52
  %t686 = load ptr, ptr %l53, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoinStmt(ptr %v0, ptr %v1, ptr %t684, %"compiler/source:Span" %t685, ptr %t686)
  br label %bb160
bb160:
  br label %bb175
bb161:
  %t690 = load ptr, ptr %l1, !tbaa !29
  store ptr %t690, ptr %l337, !tbaa !29
  store i1 false, ptr %l338, !tbaa !21
  %t691 = load ptr, ptr %l337, !tbaa !29
  %t692 = icmp ne ptr %t691, null
  br i1 %t692, label %bb162, label %bb163
bb162:
  %t694 = load ptr, ptr %l337, !tbaa !29
  %t695 = load i64, ptr %t694, !range !{i64 0, i64 22}
  %t697 = icmp eq i64 %t695, 17
  store i1 %t697, ptr %l338, !tbaa !21
  br label %bb163
bb163:
  %t698 = load i1, ptr %l338, !tbaa !21
  br i1 %t698, label %bb164, label %bb165
bb164:
  %t699 = load ptr, ptr %l1, !tbaa !29
  %t701 = getelementptr { i64, [4 x i64] }, ptr %t699, i32 0, i32 1
  %t702 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t701, i32 0, i32 0
  %t703 = load %"compiler/source:Span", ptr %t702
  store %"compiler/source:Span" %t703, ptr %l54
  %t705 = load ptr, ptr %l1, !tbaa !29
  %t707 = getelementptr { i64, [4 x i64] }, ptr %t705, i32 0, i32 1
  %t708 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t707, i32 0, i32 1
  %t709 = load { i64, ptr }, ptr %t708
  store { i64, ptr } %t709, ptr %l55, !tbaa !27
  %t711 = load ptr, ptr %l1, !tbaa !29
  %t713 = getelementptr { i64, [4 x i64] }, ptr %t711, i32 0, i32 1
  %t714 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t713, i32 0, i32 2
  %t715 = load ptr, ptr %t714
  store ptr %t715, ptr %l56, !tbaa !29
  br label %bb166
bb165:
  br label %bb168
bb166:
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t718 = load %"compiler/source:Span", ptr %l54
  %t719 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t720 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnStmt(ptr %v0, ptr %v1, ptr %v1, ptr %t717, %"compiler/source:Span" %t718, { i64, ptr } %t719, ptr %t720)
  br label %bb167
bb167:
  br label %bb175
bb168:
  br i1 true, label %bb169, label %bb170
bb169:
  br label %bb171
bb170:
  br label %bb174
bb171:
  store %olang.scope zeroinitializer, ptr %s25
  %t725 = load ptr, ptr %l0, !tbaa !29
  store ptr %t725, ptr %l351, !tbaa !29
  %t726 = load ptr, ptr %l1, !tbaa !29
  %t728 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t726)
  store %"compiler/source:Span" %t728, ptr %l353
  br label %bb172
bb172:
  %t729 = load ptr, ptr %l351, !tbaa !29
  %t730 = load %"compiler/source:Span", ptr %l353
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s25, ptr %t729, %"compiler/source:Span" %t730, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s25)
  br label %bb175
bb174:
  call void @__olang_check_failed(ptr @olang_loc_97a078c1fd6401ad_6b439c1864d584b1)
  unreachable
bb175:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l11 = alloca ptr
  %l16 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/load:Loader", ptr %t9, i32 0, i32 10
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store ptr %t15, ptr %l11
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 8
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t23 = load i64, ptr %l5, !tbaa !24
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIn(ptr %v0, ptr %v0, ptr %v1, ptr %t22, i64 %t23, { i64, ptr } %t19, i32 %a2, %"compiler/source:Span" %a3, i1 false)
  store ptr %t27, ptr %l16
  br label %bb2
bb2:
  %t28 = load ptr, ptr %l16, !tbaa !29
  store ptr %t28, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSets(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l11 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l5, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 10
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l11
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l11, !tbaa !29
  %t20 = getelementptr %"compiler/load:Module", ptr %t18, i32 0, i32 8
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t23 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetDecls(ptr %v0, ptr %v0, ptr %s0, ptr %t22, i64 %t23, { i64, ptr } %t21, i1 false, i1 true, ptr %l2)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, ptr %a5, i32 %a6, ptr %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l19 = alloca ptr
  %l24 = alloca i32
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca ptr
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca i32
  %l69 = alloca i64
  %l73 = alloca ptr
  %l78 = alloca %"compiler/typed:Bind"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t101 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  store ptr %a5, ptr %l5
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l6, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t7, %"compiler/source:Span" %t8, i32 %t9, i64 0)
  store ptr %t13, ptr %l19
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load ptr, ptr %l19, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t17 = load i32, ptr %l6, !tbaa !23
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %t15, %"compiler/source:Span" %t16, i32 %t17, ptr %a2)
  store i32 %t23, ptr %l24
  br label %bb5
bb5:
  %t24 = load i32, ptr %l24, !tbaa !23
  store i32 %t24, ptr %l8, !tbaa !23
  %t25 = load i32, ptr %l8, !tbaa !23
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t29 = icmp eq i32 %t25, %t26
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t31, %"compiler/source:Span" %t32, i32 %t33, i64 0)
  store ptr %t37, ptr %l31
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load ptr, ptr %l31, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v4, ptr %t39, %"compiler/source:Span" %t40, ptr %t41)
  store ptr %t45, ptr %l35
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l35, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l36, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l37
  %t49 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t49, ptr %l38, !tbaa !23
  store i32 45, ptr %l39
  store ptr %t46, ptr %l40, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  %t53 = load i32, ptr %l8, !tbaa !23
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t51, %"compiler/source:Span" %t52, i32 %t53, i64 0)
  store ptr %t57, ptr %l44
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l44, !tbaa !29
  %t59 = load ptr, ptr %l36, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l37
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = load i32, ptr %l39, !range !{i32 0, i32 46}
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v4, ptr %v0, ptr %v4, ptr %t59, %"compiler/source:Span" %t60, i32 %t61, i32 %t62, ptr %t63, ptr %t58)
  store ptr %t65, ptr %l46
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l46, !tbaa !29
  store ptr %t66, ptr %l10, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t71, ptr %l49
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t73, ptr %l50
  br label %bb14
bb14:
  %t74 = load i1, ptr %l50, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l52, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t78, ptr %l53
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t85 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t79, %"compiler/source:Span" %t80, ptr %t81)
  store ptr %t85, ptr %l57
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l53
  %t89 = load ptr, ptr %l57, !tbaa !29
  %t92 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v2, ptr %v0, ptr %t87, %"compiler/source:Span" %t88, ptr %t89, i32 %t86, i32 0)
  store ptr %t92, ptr %l60
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l60, !tbaa !29
  store ptr %t93, ptr %l11, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l61, !tbaa !29
  %t95 = load i32, ptr %l3, !tbaa !23
  store i32 %t95, ptr %l62, !tbaa !23
  store %"compiler/source:Span" %a4, ptr %l63
  %t97 = load ptr, ptr %l11, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t97)
  store i32 %t100, ptr %l66
  br label %bb19
bb19:
  store { i64, [1 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [1 x i64] }, ptr %t101, i32 0, i32 0
  store i64 4, ptr %t102
  %t103 = load { i64, [1 x i64] }, ptr %t101
  %t104 = load ptr, ptr %l61, !tbaa !29
  %t105 = load i32, ptr %l62, !tbaa !23
  %t106 = load %"compiler/source:Span", ptr %l63
  %t107 = load i32, ptr %l66, !tbaa !23
  %t110 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t104, i32 %t105, %"compiler/source:Span" %t106, i32 %t107, i32 4, { i64, [1 x i64] } %t103)
  store i64 %t110, ptr %l69
  br label %bb20
bb20:
  %t111 = load i64, ptr %l69, !tbaa !24
  store i64 %t111, ptr %l12, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l12, !tbaa !24
  %t114 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t112, i64 %t113, ptr %t114)
  br label %bb21
bb21:
  store ptr %a7, ptr %l73, !tbaa !29
  %t119 = load i64, ptr %l12, !tbaa !24
  %t121 = trunc i64 %t119 to i32
  %t123 = load ptr, ptr %l11, !tbaa !29
  %t126 = call %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v3, i32 %t121, ptr %t123)
  store %"compiler/typed:Bind" %t126, ptr %l78
  br label %bb22
bb22:
  %t127 = load %"compiler/typed:Bind", ptr %l78
  %t128 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store %"compiler/typed:Bind" %t127, ptr %t128
  %t129 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v3, ptr %v3, ptr %t129, ptr %t128)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l10, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t131, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeHasEq(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i32
  %l33 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %t13, i32 %t14)
  store i64 %t17, ptr %l13
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t18 = load i64, ptr %l13, !tbaa !24
  %t19 = icmp ne i64 %t18, -1
  store i1 %t19, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l18
  br label %bb10
bb10:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l3, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l24
  br label %bb13
bb12:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb14
bb13:
  %t39 = load i32, ptr %l24, !range !{i32 0, i32 33}
  %t41 = trunc i64 19 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  store i1 %t44, ptr %l19, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l19, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = add i64 %a2, 1
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsHaveEq(ptr %v0, ptr %t48, i32 %t49, i64 %t52)
  store i1 %t56, ptr %l33
  br label %bb18
bb18:
  %t57 = load i1, ptr %l33, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypedHole(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l5 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/names:Entry"
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca %"compiler/diagmsg:Msg"
  %l19 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca ptr
  %l28 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l29 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l31 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l32 = alloca i32
  %l34 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l46 = alloca i1
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l64 = alloca ptr
  %l68 = alloca %"compiler/typed:Local"
  %l70 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l80 = alloca ptr
  %l83 = alloca ptr
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca %"compiler/names:Entry"
  %l96 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca ptr
  %l100 = alloca ptr
  %l104 = alloca i32
  %l106 = alloca i1
  %l107 = alloca ptr
  %l110 = alloca { i64, ptr }
  %l116 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca %"compiler/source:Span"
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l128 = alloca %"compiler/diagmsg:Msg"
  %l129 = alloca i64
  %l132 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l16, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l17
  %t9 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHoleUntyped(ptr %s1)
  store %"compiler/diagmsg:Msg" %t9, ptr %l18
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l17
  %t12 = load %"compiler/diagmsg:Msg", ptr %l18
  %t13 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t10, %"compiler/source:Span" %t11, %"compiler/diagmsg:Msg" %t12)
  store i64 %t13, ptr %l19
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l1
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t14, %"compiler/source:Span" %t15)
  store ptr %t18, ptr %l22
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t19 = load ptr, ptr %l22, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l23
  br label %bb7
bb7:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l3
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t22)
  store ptr %t24, ptr %l25
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l25, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 8
  %t29 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v0, ptr %t27)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t29, ptr %l28
  br label %bb9
bb9:
  %t30 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l28
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t30, ptr %l4
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %l4)
  %t33 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t32, 1
  %t34 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t32, 0
  store i32 %t34, ptr %l32
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb12, label %ok.36, !prof !99
ok.36:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t33, ptr %l31
  br label %bb11
bb11:
  %t37 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l31
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t37, ptr %l29
  br label %bb14
bb12:
  %t38 = load i32, ptr %l32, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  store i1 %t41, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb14:
  %t42 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l29
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t42, ptr %l5
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t43, i32 %t45)
  store { i64, ptr } %t48, ptr %l37
  br label %bb15
bb15:
  %t49 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t49, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t50, ptr %l38
  br label %bb16
bb16:
  %t51 = load i1, ptr %l38, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l41, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 1
  %t57 = load i64, ptr %t56, !tbaa !24
  %t60 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t55, i64 %t57)
  store i32 %t60, ptr %l44
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb21
bb19:
  %t61 = load i32, ptr %l2, !tbaa !23
  %t62 = load ptr, ptr %l41, !tbaa !29
  %t63 = load i32, ptr %l44, !tbaa !23
  %t65 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholeFits(ptr %v0, ptr %t62, i32 %t63, i32 %t61)
  store i1 %t65, ptr %l46
  br label %bb20
bb20:
  %t66 = load i1, ptr %l46, !tbaa !21
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb21
bb21:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb22, label %bb23
bb22:
  %t68 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l5, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t69)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  br label %bb10
bb27:
  %t72 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_51, 0
  %t73 = insertvalue { ptr, ptr } %t72, ptr null, 1
  %t76 = extractvalue { ptr, ptr } %t73, 0
  %t77 = extractvalue { ptr, ptr } %t73, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l3, ptr %t76, ptr %t77)
  br label %bb28
bb28:
  %t78 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l51
  br label %bb29
bb29:
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l6
  store ptr %l3, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t81 = load i64, ptr %l8, !tbaa !24
  store i64 %t81, ptr %l53, !tbaa !24
  %t82 = load ptr, ptr %l7, !tbaa !29
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t82)
  store i64 %t84, ptr %l55
  br label %bb31
bb31:
  %t85 = load i64, ptr %l53, !tbaa !24
  %t86 = load i64, ptr %l55, !tbaa !24
  %t87 = icmp slt i64 %t85, %t86
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb41
bb33:
  br label %bb34
bb34:
  %t91 = load ptr, ptr %l7, !tbaa !29
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l60
  br label %bb35
bb35:
  %t96 = load i64, ptr %l60, !tbaa !24
  store i64 %t96, ptr %l9, !tbaa !24
  store ptr %l6, ptr %l61, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l62, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t98)
  store ptr %t100, ptr %l64
  br label %bb36
bb36:
  %t101 = load ptr, ptr %l64, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Body", ptr %t101, i32 0, i32 7
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t103, i64 %t104)
  store %"compiler/typed:Local" %t107, ptr %l68
  br label %bb37
bb37:
  %t108 = getelementptr %"compiler/typed:Local", ptr %l68, i32 0, i32 0
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = load ptr, ptr %l62, !tbaa !29
  %t112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s6, ptr %t110, i32 %t109)
  store { i64, ptr } %t112, ptr %l70
  br label %bb38
bb38:
  %t113 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  call void @olang_textcopy(ptr %t116, ptr %t114, i64 %t115)
  %t117 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = extractvalue { i64, ptr } %t118, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t126 = load ptr, ptr %l61, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t126, { i64, ptr } %t125)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb40:
  %t128 = load i64, ptr %l8, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l8, !tbaa !24
  br label %bb30
bb41:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/names:Resolver", ptr %t138, i32 0, i32 1
  store ptr %t140, ptr %l78, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t141)
  store ptr %t143, ptr %l80
  br label %bb42
bb42:
  %t144 = load ptr, ptr %l80, !tbaa !29
  %t146 = getelementptr %"compiler/check:frame", ptr %t144, i32 0, i32 1
  %t147 = load i64, ptr %t146, !tbaa !24
  %t148 = load ptr, ptr %l78, !tbaa !29
  %t150 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t148, i64 %t147)
  store ptr %t150, ptr %l83
  br label %bb43
bb43:
  %t151 = load ptr, ptr %l83, !tbaa !29
  %t153 = getelementptr %"compiler/names:Table", ptr %t151, i32 0, i32 0
  store ptr %t153, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb44
bb44:
  %t155 = load i64, ptr %l11, !tbaa !24
  store i64 %t155, ptr %l86, !tbaa !24
  %t156 = load ptr, ptr %l10, !tbaa !29
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t156)
  store i64 %t158, ptr %l88
  br label %bb45
bb45:
  %t159 = load i64, ptr %l86, !tbaa !24
  %t160 = load i64, ptr %l88, !tbaa !24
  %t161 = icmp slt i64 %t159, %t160
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb46, label %bb47
bb46:
  br label %bb62
bb47:
  br label %bb48
bb48:
  %t165 = load ptr, ptr %l10, !tbaa !29
  %t166 = load i64, ptr %l11, !tbaa !24
  %t169 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t165, i64 %t166)
  store %"compiler/names:Entry" %t169, ptr %l93
  br label %bb49
bb49:
  %t170 = load %"compiler/names:Entry", ptr %l93
  store %"compiler/names:Entry" %t170, ptr %l12
  %t171 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 2
  %t172 = load i32, ptr %t171, !range !{i32 0, i32 9}
  %t174 = trunc i64 2 to i32
  %t175 = icmp eq i32 %t172, %t174
  br i1 %t175, label %bb50, label %bb51
bb50:
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l97, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l98, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t179)
  store ptr %t181, ptr %l100
  br label %bb52
bb51:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb55
bb52:
  %t182 = load ptr, ptr %l100, !tbaa !29
  %t184 = getelementptr %"compiler/check:frame", ptr %t182, i32 0, i32 1
  %t185 = load i64, ptr %t184, !tbaa !24
  %t186 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 0
  %t187 = load i32, ptr %t186, !tbaa !23
  %t188 = load ptr, ptr %l98, !tbaa !29
  %t191 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t188, i64 %t185, i32 %t187)
  store i32 %t191, ptr %l104
  br label %bb53
bb53:
  %t192 = load i32, ptr %l2, !tbaa !23
  %t193 = load ptr, ptr %l97, !tbaa !29
  %t194 = load i32, ptr %l104, !tbaa !23
  %t196 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholeFits(ptr %v0, ptr %t193, i32 %t194, i32 %t192)
  store i1 %t196, ptr %l106
  br label %bb54
bb54:
  %t197 = load i1, ptr %l106, !tbaa !21
  store i1 %t197, ptr %l96, !tbaa !21
  br label %bb55
bb55:
  %t198 = load i1, ptr %l96, !tbaa !21
  br i1 %t198, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s11
  store ptr %l6, ptr %l107, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/names:Entry", ptr %l12, i32 0, i32 0
  %t201 = load i32, ptr %t200, !tbaa !23
  %t204 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s11, ptr %t199, i32 %t201)
  store { i64, ptr } %t204, ptr %l110
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t205 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t206, i64 %t207)
  %t209 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = extractvalue { i64, ptr } %t210, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t218 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t218, { i64, ptr } %t217)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t220 = load i64, ptr %l11, !tbaa !24
  %t222 = add i64 %t220, 1
  store i64 %t222, ptr %l11, !tbaa !24
  br label %bb44
bb62:
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l6)
  store i64 %t225, ptr %l116
  br label %bb63
bb63:
  %t226 = load i64, ptr %l116, !tbaa !24
  %t227 = icmp sgt i64 %t226, 8
  br i1 %t227, label %bb64, label %bb65
bb64:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H88f30ae03b1b7707751e39c47edff247(ptr %s0, ptr %l6, i64 8)
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb67
bb67:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l119, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t231, ptr %l120
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr %l2, !tbaa !23
  %t236 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t232, i32 %t233)
  store { i64, ptr } %t236, ptr %l123
  br label %bb68
bb68:
  %t237 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l124, !tbaa !27
  %t245 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store { i64, ptr } %t245, ptr %l126
  br label %bb69
bb69:
  %t246 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t246, 0
  %t248 = extractvalue { i64, ptr } %t246, 1
  %t249 = mul i64 %t247, 1
  %t250 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t249)
  call void @llvm.memcpy.p0.p0.i64(ptr %t250, ptr %t248, i64 %t249, i1 false)
  %t251 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  %t253 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t255 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHole(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t253, { i64, ptr } %t252)
  store %"compiler/diagmsg:Msg" %t255, ptr %l128
  br label %bb70
bb70:
  %t256 = load ptr, ptr %l119, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l120
  %t258 = load %"compiler/diagmsg:Msg", ptr %l128
  %t259 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t256, %"compiler/source:Span" %t257, %"compiler/diagmsg:Msg" %t258)
  store i64 %t259, ptr %l129
  br label %bb71
bb71:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l1
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t260, %"compiler/source:Span" %t261)
  store ptr %t264, ptr %l132
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t265 = load ptr, ptr %l132, !tbaa !29
  store ptr %t265, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i32, ptr %l5, !tbaa !23
  store i32 %t5, ptr %l2, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i1, ptr %l8, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i32, ptr %l2, !tbaa !23
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t18 = icmp ne i32 %t14, %t15
  store i1 %t18, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l10, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t29 = load i1, ptr %l18, !tbaa !21
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v1, ptr %t31)
  store i1 %t33, ptr %l21
  br label %bb12
bb11:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb13
bb12:
  %t34 = load i1, ptr %l21, !tbaa !21
  store i1 %t34, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l19, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l2 = alloca ptr
  %rv = alloca ptr
  %t12 = alloca { i64, [5 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 126
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 126
  store i64 %t6, ptr %t9, !tbaa !24
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [5 x i64] }, ptr %t12, i32 0, i32 0
  store i64 0, ptr %t13
  %t15 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %a1, 0
  %t17 = insertvalue { %"compiler/source:Span", i32, i64 } %t15, i32 %t11, 1
  %t18 = insertvalue { %"compiler/source:Span", i32, i64 } %t17, i64 0, 2
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t12, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t18, ptr %t19
  %t20 = load { i64, [5 x i64] }, ptr %t12
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t20, ptr %t22
  store ptr %t22, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l13 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l14 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l15 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l16 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l17 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l18 = alloca i64
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l29 = alloca i64
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca i32
  %l39 = alloca i1
  %l41 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l42 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca ptr
  %l48 = alloca { i64, [2 x i64] }
  %l53 = alloca i32
  %l56 = alloca i64
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l71 = alloca %"compiler/generic:Context"
  %l74 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l75 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l77 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l78 = alloca i32
  %l80 = alloca i1
  %l87 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l88 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l90 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l91 = alloca i32
  %l93 = alloca i1
  %l99 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l100 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l102 = alloca %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed"
  %l103 = alloca i32
  %l105 = alloca i1
  %l113 = alloca ptr
  %l116 = alloca i32
  %l119 = alloca i64
  %l120 = alloca ptr
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca ptr
  %l140 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca i32
  %l153 = alloca ptr
  %l154 = alloca ptr
  %l158 = alloca { i64, ptr }
  %l159 = alloca %"compiler/typed:Block"
  %l166 = alloca i64
  %l169 = alloca i1
  %l172 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t57 = alloca { i64, [2 x i64] }, align 8
  %t112 = alloca %"compiler/generic:Context", align 8
  %t283 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l21
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l21, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 4
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l5, !tbaa !29
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t23 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l29
  br label %bb2
bb2:
  %t24 = load i64, ptr %l29, !tbaa !24
  store i64 %t24, ptr %l6, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 131
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t27)
  br label %bb3
bb3:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t34 = call { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %s0, ptr %t29, ptr %t30)
  %t35 = extractvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t34, 1
  %t36 = extractvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t34, 0
  store i32 %t36, ptr %l37
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb5, label %ok.38, !prof !99
ok.38:
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %l36
  br label %bb4
bb4:
  %t40 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %s0, ptr %l36)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t40, ptr %l41
  br label %bb7
bb5:
  %t41 = load i32, ptr %l37, !tbaa !23
  %t42 = ashr i32 %t41, 16
  %t44 = icmp eq i32 %t42, 1
  store i1 %t44, ptr %l39, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  %t45 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t45, ptr %l42
  br label %bb8
bb7:
  %t46 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l41
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t46, ptr %l32
  br label %bb9
bb8:
  %t47 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l42
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t47, ptr %l32
  br label %bb9
bb9:
  %t48 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t48, ptr %l7
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t49)
  store %"compiler/source:Span" %t51, ptr %l44
  br label %bb10
bb10:
  %t52 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t52, ptr %l8
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l45, !tbaa !29
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t56 = load i32, ptr %t55, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t57, i32 0, i32 0
  store i64 7, ptr %t58
  %t60 = insertvalue { i64, i32 } undef, i64 %t54, 0
  %t62 = insertvalue { i64, i32 } %t60, i32 %t56, 1
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t57, i32 0, i32 1
  store { i64, i32 } %t62, ptr %t63
  %t64 = load { i64, [2 x i64] }, ptr %t57
  store { i64, [2 x i64] } %t64, ptr %l48
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l2, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t70, i32 0, i32 %t71, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t74, ptr %l53
  br label %bb11
bb11:
  %t75 = load i64, ptr %l4, !tbaa !24
  %t76 = load %"compiler/source:Span", ptr %l8
  %t77 = load ptr, ptr %l45, !tbaa !29
  %t78 = load { i64, [2 x i64] }, ptr %l48
  %t79 = load i32, ptr %l53, !tbaa !23
  %t82 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t77, { i64, [2 x i64] } %t78, i32 %t79, i64 %t75, %"compiler/source:Span" %t76)
  store i64 %t82, ptr %l56
  br label %bb12
bb12:
  %t83 = load i64, ptr %l56, !tbaa !24
  store i64 %t83, ptr %l9, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 19
  %t87 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t86, i64 %t87, i64 1)
  br label %bb13
bb13:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr %"compiler/check:frame", ptr %t90, i32 0, i32 0
  %t93 = load i64, ptr %t92, !tbaa !24
  store i64 %t93, ptr %l10, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l4, !tbaa !24
  %t98 = load i32, ptr %l2, !tbaa !23
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t95, i64 %t96, i64 %t97, i32 %t98, i32 0)
  store ptr %t103, ptr %l66
  br label %bb14
bb14:
  %t104 = load ptr, ptr %l66, !tbaa !29
  store ptr %t104, ptr %l11, !tbaa !29
  %t105 = load ptr, ptr %l11, !tbaa !29
  store ptr %t105, ptr %l67, !tbaa !29
  %t106 = load i64, ptr %l4, !tbaa !24
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = getelementptr %"compiler/check:frame", ptr %t107, i32 0, i32 4
  %t110 = getelementptr %"compiler/generic:Context", ptr %t109, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t112, ptr %v0, i64 %t106, i64 %t111)
  call void @llvm.memmove.p0.p0.i64(ptr %l71, ptr %t112, i64 160, i1 false)
  br label %bb15
bb15:
  %t115 = load ptr, ptr %l67, !tbaa !29
  %t116 = getelementptr %"compiler/check:frame", ptr %t115, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t116, ptr %l71, i64 160, i1 false)
  %t117 = load ptr, ptr %l3, !tbaa !29
  %t119 = getelementptr %"compiler/check:frame", ptr %t117, i32 0, i32 4
  %t120 = getelementptr %"compiler/generic:Context", ptr %t119, i32 0, i32 2
  %t122 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t120)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t122, ptr %l74
  br label %bb16
bb16:
  %t123 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l74
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t123, ptr %l12
  br label %bb17
bb17:
  %t125 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l12)
  %t126 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t125, 1
  %t127 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t125, 0
  store i32 %t127, ptr %l78
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb19, label %ok.129, !prof !99
ok.129:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t126, ptr %l77
  br label %bb18
bb18:
  %t130 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l77
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t130, ptr %l75
  br label %bb21
bb19:
  %t131 = load i32, ptr %l78, !tbaa !23
  %t132 = ashr i32 %t131, 16
  %t134 = icmp eq i32 %t132, 1
  store i1 %t134, ptr %l80, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  br label %bb24
bb21:
  %t135 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l75
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t135, ptr %l13
  %t136 = load ptr, ptr %l11, !tbaa !29
  %t138 = getelementptr %"compiler/check:frame", ptr %t136, i32 0, i32 4
  %t139 = getelementptr %"compiler/generic:Context", ptr %t138, i32 0, i32 2
  %t140 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l13, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  %t142 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l13, i32 0, i32 1
  %t143 = load i32, ptr %t142, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %t139, i32 %t141, i32 %t143)
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb17
bb24:
  %t147 = load ptr, ptr %l3, !tbaa !29
  %t149 = getelementptr %"compiler/check:frame", ptr %t147, i32 0, i32 4
  %t150 = getelementptr %"compiler/generic:Context", ptr %t149, i32 0, i32 3
  %t152 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t150)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t152, ptr %l87
  br label %bb25
bb25:
  %t153 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l87
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t153, ptr %l14
  br label %bb26
bb26:
  %t155 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l14)
  %t156 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t155, 1
  %t157 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t155, 0
  store i32 %t157, ptr %l91
  %t158 = icmp ne i32 %t157, 0
  br i1 %t158, label %bb28, label %ok.159, !prof !99
ok.159:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t156, ptr %l90
  br label %bb27
bb27:
  %t160 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l90
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t160, ptr %l88
  br label %bb30
bb28:
  %t161 = load i32, ptr %l91, !tbaa !23
  %t162 = ashr i32 %t161, 16
  %t164 = icmp eq i32 %t162, 1
  store i1 %t164, ptr %l93, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  br label %bb33
bb30:
  %t165 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l88
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t165, ptr %l15
  %t166 = load ptr, ptr %l11, !tbaa !29
  %t168 = getelementptr %"compiler/check:frame", ptr %t166, i32 0, i32 4
  %t169 = getelementptr %"compiler/generic:Context", ptr %t168, i32 0, i32 3
  %t170 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l15, i32 0, i32 0
  %t171 = load i32, ptr %t170, !tbaa !23
  %t172 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l15, i32 0, i32 1
  %t173 = load i32, ptr %t172, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %t169, i32 %t171, i32 %t173)
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb26
bb33:
  %t178 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %s0, ptr %s0, ptr %l7)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t178, ptr %l99
  br label %bb34
bb34:
  %t179 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l99
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t179, ptr %l16
  br label %bb35
bb35:
  %t181 = call { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %s0, ptr %l16)
  %t182 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t181, 1
  %t183 = extractvalue { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } %t181, 0
  store i32 %t183, ptr %l103
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb37, label %ok.185, !prof !99
ok.185:
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t182, ptr %l102
  br label %bb36
bb36:
  %t186 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l102
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t186, ptr %l100
  br label %bb39
bb37:
  %t187 = load i32, ptr %l103, !tbaa !23
  %t188 = ashr i32 %t187, 16
  %t190 = icmp eq i32 %t188, 1
  store i1 %t190, ptr %l105, !tbaa !21
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  br label %bb42
bb39:
  %t191 = load %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l100
  store %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" %t191, ptr %l17
  %t192 = load ptr, ptr %l11, !tbaa !29
  %t194 = getelementptr %"compiler/check:frame", ptr %t192, i32 0, i32 44
  %t195 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l17, i32 0, i32 0
  %t196 = load i32, ptr %t195, !tbaa !23
  %t197 = getelementptr %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed", ptr %l17, i32 0, i32 1
  %t198 = load i64, ptr %t197, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t194, i32 %t196, i64 %t198)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb35
bb42:
  %t202 = load ptr, ptr %l11, !tbaa !29
  %t203 = load i64, ptr %l10, !tbaa !24
  %t206 = getelementptr %"compiler/check:frame", ptr %t202, i32 0, i32 45
  store i64 %t203, ptr %t206, !tbaa !24
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t207)
  store ptr %t209, ptr %l113
  br label %bb43
bb43:
  %t210 = load %"compiler/source:Span", ptr %l8
  %t211 = load ptr, ptr %l113, !tbaa !29
  %t214 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t211, i32 -1, i32 0, %"compiler/source:Span" %t210)
  store i32 %t214, ptr %l116
  br label %bb44
bb44:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/check:Checker", ptr %t215, i32 0, i32 37
  %t219 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t217)
  store i64 %t219, ptr %l119
  br label %bb45
bb45:
  %t220 = load i64, ptr %l119, !tbaa !24
  store i64 %t220, ptr %l18, !tbaa !24
  %t221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t221, ptr %l120, !tbaa !29
  %t222 = load ptr, ptr %l120, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 123
  %t224 = load i64, ptr %t223, !tbaa !24
  %t226 = add i64 %t224, 1
  %t228 = load ptr, ptr %l120, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 123
  store i64 %t226, ptr %t229, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l1, !tbaa !29
  %t232 = load i32, ptr %l2, !tbaa !23
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t230, ptr %t231, i32 %t232)
  store ptr %t236, ptr %l126
  br label %bb46
bb46:
  %t237 = load ptr, ptr %l126, !tbaa !29
  store ptr %t237, ptr %l19, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l127, !tbaa !29
  %t239 = load ptr, ptr %l127, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 123
  %t241 = load i64, ptr %t240, !tbaa !24
  %t243 = sub i64 %t241, 1
  %t245 = load ptr, ptr %l127, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 123
  store i64 %t243, ptr %t246, !tbaa !24
  %t247 = load i32, ptr %l2, !tbaa !23
  %t248 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t251 = icmp eq i32 %t247, %t248
  br i1 %t251, label %bb47, label %bb48
bb47:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 14
  %t256 = load i64, ptr %l9, !tbaa !24
  %t259 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t255, i64 %t256)
  store ptr %t259, ptr %l136
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t260 = load ptr, ptr %l136, !tbaa !29
  store ptr %t260, ptr %l137, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 2
  store ptr %t266, ptr %l140, !tbaa !29
  %t267 = load ptr, ptr %l19, !tbaa !29
  %t270 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t267)
  store i32 %t270, ptr %l143
  br label %bb50
bb50:
  %t271 = load ptr, ptr %l140, !tbaa !29
  %t272 = load i32, ptr %l143, !tbaa !23
  %t273 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t271, i32 0, i32 %t272, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t273, ptr %l144
  br label %bb51
bb51:
  %t274 = load i32, ptr %l144, !tbaa !23
  %t275 = load ptr, ptr %l137, !tbaa !29
  %t276 = getelementptr %"compiler/typed:Body", ptr %t275, i32 0, i32 2
  store i32 %t274, ptr %t276, !tbaa !23
  br label %bb52
bb52:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/check:Checker", ptr %t277, i32 0, i32 37
  %t280 = load %"compiler/source:Span", ptr %l8
  %t281 = load ptr, ptr %l19, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t283
  %t284 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 0
  store i64 6, ptr %t284
  %t286 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t280, 0
  %t288 = insertvalue { %"compiler/source:Span", ptr } %t286, ptr %t281, 1
  %t289 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t288, ptr %t289
  %t290 = load { i64, [3 x i64] }, ptr %t283
  %t292 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t290, ptr %t292
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t279, ptr %t292)
  br label %bb53
bb53:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t295)
  store ptr %t297, ptr %l153
  br label %bb54
bb54:
  %t298 = load ptr, ptr %l153, !tbaa !29
  store ptr %t298, ptr %l154, !tbaa !29
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 37
  %t302 = load i64, ptr %l18, !tbaa !24
  %t305 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t301, i64 %t302)
  store { i64, ptr } %t305, ptr %l158
  br label %bb55
bb55:
  %t306 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t307 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t306)
  store %"compiler/typed:Block" %t307, ptr %l159
  br label %bb56
bb56:
  %t308 = load %"compiler/typed:Block", ptr %l159
  %t309 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t308, ptr %t309
  %t311 = load ptr, ptr %l154, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Body", ptr %t311, i32 0, i32 11
  store ptr %t309, ptr %t312, !tbaa !29
  %t313 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t313)
  br label %bb57
bb57:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 19
  %t318 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t317, i64 %t318, i64 2)
  br label %bb58
bb58:
  %t321 = load ptr, ptr %l5, !tbaa !29
  %t323 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t321)
  store i64 %t323, ptr %l166
  br label %bb59
bb59:
  %t324 = load i64, ptr %l6, !tbaa !24
  %t325 = load i64, ptr %l166, !tbaa !24
  %t327 = icmp sgt i64 %t325, %t324
  br i1 %t327, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l169, !tbaa !21
  br label %bb63
bb61:
  %t329 = load ptr, ptr %l19, !tbaa !29
  %t332 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t329)
  store i32 %t332, ptr %l172
  br label %bb62
bb62:
  %t333 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t334 = load i32, ptr %l172, !tbaa !23
  %t336 = icmp eq i32 %t334, %t333
  store i1 %t336, ptr %l169, !tbaa !21
  br label %bb63
bb63:
  %t338 = load i1, ptr %l169, !tbaa !21
  br i1 %t338, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb65:
  br label %bb66
bb66:
  %t340 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t340, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l11 = alloca ptr
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t5, i32 %t6)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t11, ptr %l9
  br label %bb4
bb4:
  %t12 = load i1, ptr %l9, !tbaa !21
  store i1 %t12, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t14)
  store ptr %t16, ptr %l11
  br label %bb9
bb9:
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 4
  %t20 = getelementptr %"compiler/generic:Context", ptr %t19, i32 0, i32 2
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H2c4b9eb360b9a0ada2008890a467b28d(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l15
  br label %bb10
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t25, i32 %t26, i32 %a2)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i64
  %l43 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 16
  store ptr %t55, ptr %l36, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 16
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l39
  br label %bb12
bb12:
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = sub i64 %t61, 1
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load ptr, ptr %l36, !tbaa !29
  %t69 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t67, i64 %t66)
  store ptr %t69, ptr %l43
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l43, !tbaa !29
  store ptr %t70, ptr %l7, !tbaa !29
  %t71 = load ptr, ptr %l7, !tbaa !29
  %t73 = getelementptr %"compiler/check:frame", ptr %t71, i32 0, i32 27
  %t74 = load i1, ptr %t73, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 57
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t81 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t78, i64 %t82, i1 true)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %ret
bb17:
  br label %bb18
bb18:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l5, !tbaa !24
  br label %bb8
bb19:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviewElig(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca %"compiler/typed:Local"
  %l49 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l55 = alloca i1
  %l58 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 5
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t3)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t7 = load i64, ptr %l13, !tbaa !24
  %t9 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t7, i64 %t6)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l9, !tbaa !24
  store i64 %a2, ptr %l40, !tbaa !24
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %l41, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Body", ptr %t59, i32 0, i32 5
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t61, i64 %t62)
  store i32 %t65, ptr %l45
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l41, !tbaa !29
  %t67 = load i32, ptr %l45, !tbaa !23
  %t68 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v1, ptr %t66, i32 %t67)
  store %"compiler/typed:Local" %t68, ptr %l46
  br label %bb14
bb14:
  %t69 = getelementptr %"compiler/typed:Local", ptr %l46, i32 0, i32 1
  %t70 = getelementptr %"compiler/source:Span", ptr %t69, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = sext i32 %t71 to i64
  %t74 = load i64, ptr %l40, !tbaa !24
  %t76 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t74, i64 %t73)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t76, ptr %l49
  br label %bb15
bb15:
  %t77 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l49
  %t80 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/load:Loader", ptr %t84, i32 0, i32 5
  %t90 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t86, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t77)
  store i1 %t90, ptr %l55
  br label %bb16
bb16:
  %t91 = load i1, ptr %l55, !tbaa !21
  %t92 = xor i1 %t91, true
  br i1 %t92, label %bb17, label %bb18
bb17:
  %t94 = load i64, ptr %l3, !tbaa !24
  %t95 = load i64, ptr %l9, !tbaa !24
  store i64 %t95, ptr %l58, !tbaa !24
  %t96 = load i64, ptr %l58, !tbaa !24
  %t97 = load i64, ptr %l58, !tbaa !24
  %t98 = shl i64 1, %t97
  %t101 = or i64 %t94, %t98
  store i64 %t101, ptr %l3, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l8, !tbaa !24
  br label %bb9
bb21:
  %t107 = load i64, ptr %l3, !tbaa !24
  store i64 %t107, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBackNoNumber(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca i64
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l51 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca { i64, ptr }
  %l68 = alloca %"compiler/diagmsg:Msg"
  %l69 = alloca i64
  %l71 = alloca i32
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i64
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l97 = alloca i32
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l111 = alloca ptr
  %l113 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l126 = alloca %"compiler/diagmsg:Msg"
  %l127 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t253 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t3 = trunc i64 65 to i32
  %t4 = icmp eq i32 %t1, %t3
  store i1 %t4, ptr %l6, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l13, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l14, !tbaa !24
  %t9 = load i64, ptr %l14, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l15, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l14, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %l7, !tbaa !27
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l20
  br label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s6
  %t30 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t32 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t30)
  store i32 %t32, ptr %l71
  br label %bb37
bb3:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t34 = load i1, ptr %l6, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb5:
  br label %bb29
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  br label %bb8
bb8:
  %t40 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l28, !tbaa !24
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = icmp eq i64 %t41, %t45
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = mul i64 %t52, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %t51, i64 %t53, i1 false)
  br label %bb11
bb10:
  %t54 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l30, !tbaa !24
  %t56 = load i64, ptr %l30, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l31, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l30, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t67, ptr %l7, !tbaa !27
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t74 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t68, i32 %t69, { i64, ptr } %t70, i64 0)
  store i64 %t74, ptr %l35
  br label %bb12
bb12:
  %t75 = load i64, ptr %l35, !tbaa !24
  %t76 = icmp slt i64 %t75, 0
  br i1 %t76, label %bb13, label %bb14
bb13:
  %t78 = load i1, ptr %l6, !tbaa !21
  br i1 %t78, label %bb15, label %bb16
bb14:
  br label %bb28
bb15:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t80, ptr %l38, !tbaa !27
  br label %bb17
bb16:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  br label %bb17
bb17:
  %t84 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l44, !tbaa !24
  %t89 = load i64, ptr %l44, !tbaa !24
  %t90 = icmp eq i64 %t85, %t89
  br i1 %t90, label %bb18, label %bb19
bb18:
  %t92 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l44, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  br label %bb20
bb19:
  %t98 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l46, !tbaa !24
  %t100 = load i64, ptr %l46, !tbaa !24
  %t101 = mul i64 %t100, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l47, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l46, !tbaa !24
  %t110 = mul i64 %t109, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  %t111 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t111, ptr %l7, !tbaa !27
  br label %bb20
bb20:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l3, !tbaa !23
  %t114 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t112, i32 %t113, { i64, ptr } %t114, i64 1)
  store i64 %t118, ptr %l51
  br label %bb21
bb21:
  %t119 = load i64, ptr %l51, !tbaa !24
  %t120 = icmp slt i64 %t119, 0
  br i1 %t120, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l53, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t122, ptr %l54, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l56, !tbaa !24
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = icmp eq i64 %t124, %t128
  br i1 %t129, label %bb24, label %bb25
bb23:
  br label %bb27
bb24:
  %t131 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l56, !tbaa !24
  %t136 = mul i64 %t135, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t132, ptr %t134, i64 %t136, i1 false)
  br label %bb26
bb25:
  %t137 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l58, !tbaa !24
  %t139 = load i64, ptr %l58, !tbaa !24
  %t140 = mul i64 %t139, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l59, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = mul i64 %t148, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %t147, i64 %t149, i1 false)
  %t150 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t150, ptr %l7, !tbaa !27
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t153 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s1, { i64, ptr } %t151, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t153, ptr %l61
  br label %bb30
bb30:
  %t154 = load i1, ptr %l61, !tbaa !21
  br i1 %t154, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l62, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t156, ptr %l63
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i32, ptr %l3, !tbaa !23
  %t161 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t157, i32 %t158)
  store { i64, ptr } %t161, ptr %l66
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t162 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  %t164 = extractvalue { i64, ptr } %t162, 1
  %t165 = mul i64 %t163, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t166, ptr %t164, i64 %t165, i1 false)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  %t170 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %s5, ptr %s5, { i64, ptr } %t168)
  store %"compiler/diagmsg:Msg" %t170, ptr %l68
  br label %bb34
bb34:
  %t171 = load ptr, ptr %l62, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l63
  %t173 = load %"compiler/diagmsg:Msg", ptr %l68
  %t174 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t171, %"compiler/source:Span" %t172, %"compiler/diagmsg:Msg" %t173)
  store i64 %t174, ptr %l69
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s1)
  br label %bb62
bb37:
  %t175 = load i32, ptr %l71, !range !{i32 0, i32 98}
  store i32 %t175, ptr %l8
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l3, !tbaa !23
  %t180 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t176, i32 %t177)
  store i1 %t180, ptr %l74
  br label %bb38
bb38:
  %t181 = load i1, ptr %l74, !tbaa !21
  br i1 %t181, label %bb39, label %bb40
bb39:
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l76, !tbaa !29
  %t183 = load i32, ptr %l3, !tbaa !23
  store i32 %t183, ptr %l77, !tbaa !23
  %t184 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t186 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s6, i32 %t184)
  store { i64, ptr } %t186, ptr %l79
  br label %bb41
bb40:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb43
bb41:
  %t187 = load ptr, ptr %l76, !tbaa !29
  %t188 = load i32, ptr %l77, !tbaa !23
  %t189 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t190 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s6, ptr %t187, i32 %t188, { i64, ptr } %t189, i64 1)
  store i64 %t190, ptr %l80
  br label %bb42
bb42:
  %t191 = load i64, ptr %l80, !tbaa !24
  %t192 = icmp sge i64 %t191, 0
  store i1 %t192, ptr %l75, !tbaa !21
  br label %bb43
bb43:
  %t194 = load i1, ptr %l75, !tbaa !21
  br i1 %t194, label %bb44, label %bb45
bb44:
  %t195 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t197 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t195)
  store { i64, ptr } %t197, ptr %l83
  br label %bb46
bb45:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l4, !tbaa !29
  %t201 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t198, ptr %t199, i32 %t201)
  store ptr %t205, ptr %l94
  br label %bb50
bb46:
  %t206 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t206, ptr %l84, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l86, !tbaa !24
  %t212 = load i64, ptr %l86, !tbaa !24
  %t213 = icmp eq i64 %t208, %t212
  br i1 %t213, label %bb47, label %bb48
bb47:
  %t215 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = load i64, ptr %l86, !tbaa !24
  %t220 = mul i64 %t219, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t216, ptr %t218, i64 %t220, i1 false)
  br label %bb49
bb48:
  %t221 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l88, !tbaa !24
  %t223 = load i64, ptr %l88, !tbaa !24
  %t224 = mul i64 %t223, 1
  %t225 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t224)
  %t226 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  store { i64, ptr } %t227, ptr %l89, !tbaa !27
  %t228 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = load i64, ptr %l88, !tbaa !24
  %t233 = mul i64 %t232, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t229, ptr %t231, i64 %t233, i1 false)
  %t234 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t234, ptr %l7, !tbaa !27
  br label %bb49
bb49:
  br label %bb61
bb50:
  %t235 = load ptr, ptr %l94, !tbaa !29
  store ptr %t235, ptr %l9, !tbaa !29
  %t236 = load ptr, ptr %l9, !tbaa !29
  %t239 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t236)
  store i32 %t239, ptr %l97
  br label %bb51
bb51:
  %t240 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t241 = load i32, ptr %l97, !tbaa !23
  %t243 = icmp ne i32 %t241, %t240
  br i1 %t243, label %bb52, label %bb53
bb52:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l101, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t246, ptr %l102
  %t247 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t247, ptr %l103
  %t248 = load i32, ptr %l8, !range !{i32 0, i32 98}
  store i32 %t248, ptr %l104
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l1
  %t251 = load %"compiler/source:Span", ptr %l1
  %t252 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 0
  store i64 7, ptr %t254
  %t256 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t251, 0
  %t258 = insertvalue { %"compiler/source:Span", i32 } %t256, i32 %t252, 1
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t258, ptr %t259
  %t260 = load { i64, [4 x i64] }, ptr %t253
  %t262 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t260, ptr %t262
  %t266 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t249, %"compiler/source:Span" %t250, ptr %t262)
  store ptr %t266, ptr %l111
  br label %bb54
bb53:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb56
bb54:
  %t267 = load ptr, ptr %l9, !tbaa !29
  %t268 = load ptr, ptr %l101, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l102
  %t270 = load %"compiler/source:Span", ptr %l103
  %t271 = load i32, ptr %l104, !range !{i32 0, i32 98}
  %t272 = load ptr, ptr %l111, !tbaa !29
  %t274 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t268, %"compiler/source:Span" %t269, %"compiler/source:Span" %t270, i32 %t271, ptr %t272, ptr %t267)
  store ptr %t274, ptr %l113
  br label %bb55
bb55:
  %t275 = load ptr, ptr %l113, !tbaa !29
  %t276 = icmp eq ptr %t275, null
  store i1 %t276, ptr %l100, !tbaa !21
  br label %bb56
bb56:
  %t278 = load i1, ptr %l100, !tbaa !21
  br i1 %t278, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s9
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s9, ptr %t279, %"compiler/source:Span" %t280, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d61, i32 0, i32 1) })
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb61:
  call void @__olang_scope_close(ptr %s6)
  br label %bb62
bb62:
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l117, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t284, ptr %l118
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load i32, ptr %l3, !tbaa !23
  %t289 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t285, i32 %t286)
  store { i64, ptr } %t289, ptr %l121
  br label %bb63
bb63:
  %t290 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 0
  %t292 = extractvalue { i64, ptr } %t290, 1
  %t293 = mul i64 %t291, 1
  %t294 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  %t297 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t298 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t301 = extractvalue { i64, ptr } %t297, 1
  %t302 = extractvalue { i64, ptr } %t297, 0
  %t303 = add i64 %t299, %t302
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t306 = add i64 %t303, %t305
  %t307 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t306)
  call void @olang_textcopy(ptr %t307, ptr %t298, i64 %t299)
  %t308 = getelementptr i8, ptr %t307, i64 %t299
  call void @olang_textcopy(ptr %t308, ptr %t301, i64 %t302)
  %t309 = getelementptr i8, ptr %t308, i64 %t302
  call void @olang_textcopy(ptr %t309, ptr %t304, i64 %t305)
  %t310 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t307, 1
  %t313 = extractvalue { i64, ptr } %t311, 0
  %t314 = extractvalue { i64, ptr } %t311, 1
  %t315 = mul i64 %t313, 1
  %t316 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t315)
  call void @llvm.memcpy.p0.p0.i64(ptr %t316, ptr %t314, i64 %t315, i1 false)
  %t317 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t316, 1
  %t321 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWriteThroughAtOperator(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t296, { i64, ptr } %t318)
  store %"compiler/diagmsg:Msg" %t321, ptr %l126
  br label %bb64
bb64:
  %t322 = load ptr, ptr %l117, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l118
  %t324 = load %"compiler/diagmsg:Msg", ptr %l126
  %t325 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t322, %"compiler/source:Span" %t323, %"compiler/diagmsg:Msg" %t324)
  store i64 %t325, ptr %l127
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenEnum(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca i32
  %l19 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb15
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i32 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i32, ptr %l13, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load i32, ptr %l3, !tbaa !23
  %t24 = icmp sge i32 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load i32, ptr %l3, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i32 %t32, ptr %l19
  br label %bb10
bb10:
  %t33 = load i32, ptr %l19, !tbaa !23
  store i32 %t33, ptr %l4, !tbaa !23
  %t34 = load i32, ptr %l4, !tbaa !23
  %t36 = icmp sge i32 %t34, 0
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i32, ptr %l4, !tbaa !23
  %t45 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l25
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t46 = load i32, ptr %l25, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_dcc186c1d376e3fb_9ec0343880193f07)
  unreachable
bb20:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCasePath(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l29 = alloca i32
  %l34 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"compiler/source:Span"
  %l46 = alloca %"compiler/diagmsg:Msg"
  %l47 = alloca i64
  %l51 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l64 = alloca i32
  %l69 = alloca i32
  %l74 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l83 = alloca %"compiler/source:Span"
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l87 = alloca %"compiler/diagmsg:Msg"
  %l88 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l5, !tbaa !23
  br label %bb5
bb4:
  br label %bb46
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t26 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  store i32 %t26, ptr %l17
  br label %bb6
bb6:
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l20
  br label %bb7
bb7:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load i32, ptr %l6, !tbaa !23
  %t36 = icmp sge i32 %t34, 0
  store i1 %t36, ptr %l21, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l6, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l29
  br label %bb13
bb12:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb15
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l34
  br label %bb14
bb14:
  %t59 = load i32, ptr %l29, !tbaa !23
  %t60 = load i32, ptr %l34, !tbaa !23
  %t61 = icmp eq i32 %t59, %t60
  store i1 %t61, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t63 = load i1, ptr %l24, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l36, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l37
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i32, ptr %l5, !tbaa !23
  %t70 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t66, i32 %t67)
  store { i64, ptr } %t70, ptr %l40
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t71 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  %t73 = load %"compiler/source:Span", ptr %l37
  %t75 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t73, i64 %t72)
  store %"compiler/source:Span" %t75, ptr %l42
  br label %bb19
bb19:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l3, !tbaa !23
  %t78 = load i32, ptr %l5, !tbaa !23
  %t82 = call %"compiler/diagmsg:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %s2, ptr %t76, i32 %t77, i32 %t78)
  store %"compiler/diagmsg:Msg" %t82, ptr %l46
  br label %bb20
bb20:
  %t83 = load ptr, ptr %l36, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l42
  %t85 = load %"compiler/diagmsg:Msg", ptr %l46
  %t86 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t83, %"compiler/source:Span" %t84, %"compiler/diagmsg:Msg" %t85)
  store i64 %t86, ptr %l47
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb22:
  %t88 = load i32, ptr %l6, !tbaa !23
  %t90 = icmp sge i32 %t88, 0
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l6, !tbaa !23
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t92, i32 %t93)
  store i1 %t96, ptr %l54
  br label %bb25
bb24:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb26
bb25:
  %t97 = load i1, ptr %l54, !tbaa !21
  store i1 %t97, ptr %l51, !tbaa !21
  br label %bb26
bb26:
  %t98 = load i1, ptr %l51, !tbaa !21
  br i1 %t98, label %bb27, label %bb28
bb27:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l3, !tbaa !23
  %t103 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t99, i32 %t100)
  store i1 %t103, ptr %l58
  br label %bb29
bb28:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb35
bb29:
  %t104 = load i1, ptr %l58, !tbaa !21
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l6, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l64
  br label %bb32
bb31:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb34
bb32:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l3, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l69
  br label %bb33
bb33:
  %t125 = load i32, ptr %l64, !tbaa !23
  %t126 = load i32, ptr %l69, !tbaa !23
  %t127 = icmp eq i32 %t125, %t126
  store i1 %t127, ptr %l59, !tbaa !21
  br label %bb34
bb34:
  %t129 = load i1, ptr %l59, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l55, !tbaa !21
  br label %bb35
bb35:
  %t132 = load i1, ptr %l55, !tbaa !21
  %t133 = xor i1 %t132, true
  br i1 %t133, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l74, !tbaa !29
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t137)
  store %"compiler/source:Span" %t139, ptr %l76
  br label %bb39
bb39:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l3, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l79
  br label %bb40
bb40:
  %t145 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l80, !tbaa !27
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l81, !tbaa !29
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t155 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t153)
  store %"compiler/source:Span" %t155, ptr %l83
  br label %bb41
bb41:
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l83
  %t158 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t156, %"compiler/source:Span" %t157)
  store { i64, ptr } %t158, ptr %l84
  br label %bb42
bb42:
  %t159 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t160 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s1, { i64, ptr } %t159)
  store { i64, ptr } %t160, ptr %l85
  br label %bb43
bb43:
  %t161 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 0
  %t163 = extractvalue { i64, ptr } %t161, 1
  %t164 = mul i64 %t162, 1
  %t165 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t165, ptr %t163, i64 %t164, i1 false)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  %t168 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t170 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatternType(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t168, { i64, ptr } %t167)
  store %"compiler/diagmsg:Msg" %t170, ptr %l87
  br label %bb44
bb44:
  %t171 = load ptr, ptr %l74, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l76
  %t173 = load %"compiler/diagmsg:Msg", ptr %l87
  %t174 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t171, %"compiler/source:Span" %t172, %"compiler/diagmsg:Msg" %t173)
  store i64 %t174, ptr %l88
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i1 false, ptr %rv
  br label %ret
bb50:
  call void @__olang_check_failed(ptr @olang_loc_3377d0df2c72c56f_fd113dcd8b508953)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %lp11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca { i64, [3 x i64] }
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i64
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca i64
  %l53 = alloca ptr
  %l56 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca i1
  %l66 = alloca i64
  %l70 = alloca i32
  %l74 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l93 = alloca i32
  %l94 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l117 = alloca i64
  %l120 = alloca ptr
  %l133 = alloca i64
  %l136 = alloca i64
  %l157 = alloca i1
  %l162 = alloca i1
  %l163 = alloca { i64, ptr }
  %l174 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l182 = alloca ptr
  %l187 = alloca i32
  %l188 = alloca i64
  %l189 = alloca { i64, ptr }
  %l193 = alloca { i64, [3 x i64] }
  %l194 = alloca i64
  %l196 = alloca ptr
  %l200 = alloca { i64, ptr }
  %l203 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l209 = alloca ptr
  %l221 = alloca ptr
  %l224 = alloca i1
  %l225 = alloca i1
  %l228 = alloca i1
  %l233 = alloca i32
  %l239 = alloca ptr
  %l244 = alloca i32
  %l245 = alloca { i64, ptr }
  %l252 = alloca { i64, ptr }
  %l257 = alloca i1
  %l258 = alloca ptr
  %l259 = alloca %"compiler/source:Span"
  %l262 = alloca { i64, ptr }
  %l263 = alloca { i64, ptr }
  %l264 = alloca ptr
  %l269 = alloca i32
  %l270 = alloca { i64, ptr }
  %l272 = alloca %"compiler/diagmsg:Msg"
  %l273 = alloca i64
  %l278 = alloca ptr
  %l285 = alloca ptr
  %l292 = alloca i1
  %l295 = alloca i64
  %l298 = alloca ptr
  %l301 = alloca ptr
  %l305 = alloca i32
  %l306 = alloca i32
  %l307 = alloca { i64, ptr }
  %l308 = alloca { i64, ptr }
  %l310 = alloca ptr
  %l311 = alloca %"compiler/source:Span"
  %l312 = alloca i32
  %l313 = alloca i64
  %l314 = alloca ptr
  %l318 = alloca ptr
  %l319 = alloca { i64, ptr }
  %l320 = alloca ptr
  %l324 = alloca ptr
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t215 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l32
  br label %bb1
bb1:
  %t6 = load i1, ptr %l32, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l33, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l34
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t9, i32 %t10)
  store { i64, ptr } %t13, ptr %l37
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t14 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l38, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l39, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l44
  br label %bb5
bb5:
  %t32 = load ptr, ptr %l39, !tbaa !29
  %t33 = load i32, ptr %l44, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l45
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t44 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoZeroNonNull(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t42, { i64, ptr } %t41)
  store %"compiler/diagmsg:Msg" %t44, ptr %l47
  br label %bb7
bb7:
  %t45 = load ptr, ptr %l33, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l34
  %t47 = load %"compiler/diagmsg:Msg", ptr %l47
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t45, %"compiler/source:Span" %t46, %"compiler/diagmsg:Msg" %t47)
  store i64 %t48, ptr %l48
  br label %bb8
bb8:
  %t49 = load i64, ptr %l48, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %t50, i64 %t49)
  br label %bb9
bb9:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t54, %"compiler/source:Span" %t55)
  store ptr %t58, ptr %l53
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  %t59 = load ptr, ptr %l53, !tbaa !29
  store ptr %t59, ptr %rv
  br label %ret
bb11:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l2, !tbaa !23
  %t64 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullableArray(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l56
  br label %bb12
bb12:
  %t65 = load i1, ptr %l56, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  %t68 = load i32, ptr %l2, !tbaa !23
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %t66, %"compiler/source:Span" %t67, i32 %t68)
  store ptr %t72, ptr %l60
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t73 = load ptr, ptr %l60, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t78, ptr %l63
  br label %bb17
bb17:
  %t79 = load i1, ptr %l63, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t80, i32 %t81)
  store i64 %t84, ptr %l66
  br label %bb20
bb19:
  br label %bb92
bb20:
  %t85 = load i64, ptr %l66, !tbaa !24
  store i64 %t85, ptr %l4, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i32, ptr %l2, !tbaa !23
  %t93 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l70
  br label %bb21
bb21:
  %t94 = load i32, ptr %l70, !tbaa !23
  store i32 %t94, ptr %l5, !tbaa !23
  %t95 = load i32, ptr %l5, !tbaa !23
  %t96 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t99 = icmp ne i32 %t95, %t96
  br i1 %t99, label %bb22, label %bb23
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l77, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %l5, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l82
  br label %bb24
bb23:
  %t117 = icmp sge i64 0, 0
  br i1 %t117, label %bb26, label %bb27
bb24:
  %t119 = load ptr, ptr %l77, !tbaa !29
  %t120 = load i32, ptr %l82, !tbaa !23
  %t121 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t119, i32 %t120)
  store { i64, ptr } %t121, ptr %l83
  br label %bb25
bb25:
  %t122 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t122, ptr %l74, !tbaa !27
  br label %bb30
bb26:
  %t123 = icmp sle i64 0, 2305843009213693951
  br i1 %t123, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_39114b2b59f3c1de_f97787d703923df2)
  unreachable
bb28:
  %t125 = mul i64 0, 4
  %t126 = insertvalue { i64, ptr } undef, i64 0, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t127, ptr %l74, !tbaa !27
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_39114b2b59f3c1de_f97787d703923df2)
  unreachable
bb30:
  %t129 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t129, ptr %l6, !tbaa !27
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  store ptr %t133, ptr %l88, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l2, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l93
  br label %bb31
bb31:
  %t144 = load ptr, ptr %l88, !tbaa !29
  %t145 = load i32, ptr %l93, !tbaa !23
  %t146 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t144, i32 %t145)
  store ptr %t146, ptr %l94
  br label %bb32
bb32:
  %t147 = load ptr, ptr %l94, !tbaa !29
  store ptr %t147, ptr %l7, !tbaa !29
  %t148 = icmp sge i64 0, 0
  br i1 %t148, label %bb33, label %bb34
bb33:
  %t150 = icmp sle i64 0, 1152921504606846975
  br i1 %t150, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_bfa34a8929429713_51639094391671e7)
  unreachable
bb35:
  %t152 = mul i64 0, 8
  %t153 = insertvalue { i64, ptr } undef, i64 0, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t154, ptr %l8, !tbaa !27
  %t156 = load ptr, ptr %l7, !tbaa !29
  %t158 = icmp eq ptr %t156, null
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_bfa34a8929429713_51639094391671e7)
  unreachable
bb37:
  %t162 = load ptr, ptr %l7, !tbaa !29
  %t164 = getelementptr %"compiler/ast:TypeDecl", ptr %t162, i32 0, i32 3
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = icmp eq ptr %t165, null
  %t169 = xor i1 %t167, true
  store i1 %t169, ptr %l101, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb39
bb39:
  %t171 = load i1, ptr %l101, !tbaa !21
  br i1 %t171, label %bb40, label %bb41
bb40:
  %t172 = load ptr, ptr %l7, !tbaa !29
  %t174 = getelementptr %"compiler/ast:TypeDecl", ptr %t172, i32 0, i32 3
  %t175 = load ptr, ptr %t174, !tbaa !29
  store ptr %t175, ptr %l9, !tbaa !29
  %t177 = load ptr, ptr %l9, !tbaa !29
  store ptr %t177, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t178 = load ptr, ptr %l108, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb42, label %bb43
bb41:
  br label %bb53
bb42:
  %t181 = load ptr, ptr %l108, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 5}
  %t184 = icmp eq i64 %t182, 0
  store i1 %t184, ptr %l109, !tbaa !21
  br label %bb43
bb43:
  %t185 = load i1, ptr %l109, !tbaa !21
  br i1 %t185, label %bb44, label %bb45
bb44:
  %t186 = load ptr, ptr %l9, !tbaa !29
  %t188 = getelementptr { i64, [6 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { ptr }, ptr %t188, i32 0, i32 0
  %t190 = load ptr, ptr %t189
  store ptr %t190, ptr %l10, !tbaa !29
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t192 = load ptr, ptr %l10, !tbaa !29
  %t194 = getelementptr %"compiler/ast:StructBody", ptr %t192, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l8, !tbaa !27
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_37a2617a6fdca52f_9113ce984ee2ba6b)
  unreachable
bb52:
  br label %bb53
bb53:
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  store i64 %t199, ptr %l117, !tbaa !24
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v1, ptr %t200, %"compiler/source:Span" %t201)
  store ptr %t204, ptr %l120
  br label %bb54
bb54:
  %t205 = load i64, ptr %l117, !tbaa !24
  %t206 = icmp sge i64 %t205, 0
  br i1 %t206, label %bb55, label %bb56
bb55:
  %t208 = load i64, ptr %l117, !tbaa !24
  %t209 = icmp sle i64 %t208, 1152921504606846975
  br i1 %t209, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_cffeba9c7beed71d_692ce8f7e2902011)
  unreachable
bb57:
  %t211 = load i64, ptr %l117, !tbaa !24
  %t212 = mul i64 %t211, 8
  %t213 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t212)
  %t214 = load ptr, ptr %l120, !tbaa !29
  store i64 0, ptr %t215
  br label %fill.216
fill.216:
  %t219 = load i64, ptr %t215
  %t220 = icmp slt i64 %t219, %t211
  br i1 %t220, label %fillb.217, label %filld.218
fillb.217:
  %t221 = getelementptr ptr, ptr %t213, i64 %t219
  store ptr %t214, ptr %t221
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %t215
  br label %fill.216
filld.218:
  %t223 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t213, 1
  %t225 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t225, ptr %lp11
  %t227 = load ptr, ptr %lp11
  store { i64, ptr } %t224, ptr %t227, !tbaa !27
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 23
  %t231 = load i32, ptr %t230, !tbaa !23
  store i32 %t231, ptr %l12, !tbaa !23
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l2, !tbaa !23
  %t237 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 23
  store i32 %t234, ptr %t237, !tbaa !23
  store i64 0, ptr %l13, !tbaa !24
  %t238 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t238, 0
  store i64 %t240, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t242 = load i64, ptr %l14, !tbaa !24
  %t243 = load i64, ptr %l13, !tbaa !24
  %t246 = icmp sgt i64 %t242, %t243
  br i1 %t246, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_cffeba9c7beed71d_692ce8f7e2902011)
  unreachable
bb59:
  %t248 = load i64, ptr %l15, !tbaa !24
  %t250 = icmp sgt i64 %t248, 0
  br i1 %t250, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb64
bb61:
  %t252 = load i64, ptr %l14, !tbaa !24
  %t253 = load i64, ptr %l13, !tbaa !24
  %t256 = sub i64 %t252, %t253
  %t257 = load i64, ptr %l15, !tbaa !24
  %t260 = add i64 %t256, %t257
  %t262 = sub i64 %t260, 1
  %t263 = load i64, ptr %l15, !tbaa !24
  %t266 = sdiv i64 %t262, %t263
  store i64 %t266, ptr %l136, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb63
bb63:
  %t268 = load i64, ptr %l136, !tbaa !24
  store i64 %t268, ptr %l133, !tbaa !24
  br label %bb64
bb64:
  %t269 = load i64, ptr %l133, !tbaa !24
  store i64 %t269, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb65
bb65:
  %t270 = load i64, ptr %l17, !tbaa !24
  %t271 = load i64, ptr %l16, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb66, label %bb67
bb66:
  br label %bb90
bb67:
  br label %bb68
bb68:
  %t278 = load i64, ptr %l13, !tbaa !24
  %t279 = load i64, ptr %l17, !tbaa !24
  %t280 = load i64, ptr %l15, !tbaa !24
  %t283 = mul i64 %t279, %t280
  %t286 = add i64 %t278, %t283
  store i64 %t286, ptr %l18, !tbaa !24
  %t288 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t292 = icmp sgt i64 %t290, 0
  br i1 %t292, label %bb69, label %bb70
bb69:
  %t294 = load i64, ptr %l18, !tbaa !24
  %t295 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t295, 0
  %t300 = icmp slt i64 %t294, %t297
  store i1 %t300, ptr %l157, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb71
bb71:
  %t302 = load i1, ptr %l157, !tbaa !21
  br i1 %t302, label %bb72, label %bb73
bb72:
  %t303 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t303, ptr %l163, !tbaa !27
  %t304 = load i64, ptr %l18, !tbaa !24
  %t306 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr ptr, ptr %t307, i64 %t304
  %t309 = load ptr, ptr %t308, !tbaa !39
  %t311 = getelementptr %"compiler/ast:Param", ptr %t309, i32 0, i32 3
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = icmp eq ptr %t312, null
  %t316 = xor i1 %t314, true
  store i1 %t316, ptr %l162, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb74
bb74:
  %t318 = load i1, ptr %l162, !tbaa !21
  store i1 %t318, ptr %l19, !tbaa !21
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 13
  %t322 = load { i64, [3 x i64] }, ptr %t321
  store { i64, [3 x i64] } %t322, ptr %l20
  %t324 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t328 = icmp sgt i64 %t326, 0
  br i1 %t328, label %bb75, label %bb76
bb75:
  %t330 = load i64, ptr %l18, !tbaa !24
  %t331 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t331, 0
  %t336 = icmp slt i64 %t330, %t333
  store i1 %t336, ptr %l174, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb77
bb77:
  %t338 = load i1, ptr %l174, !tbaa !21
  br i1 %t338, label %bb78, label %bb79
bb78:
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l179, !tbaa !29
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l180, !tbaa !29
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !29
  store ptr %t344, ptr %l182, !tbaa !29
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t350 = getelementptr %"compiler/generic:Program", ptr %t348, i32 0, i32 2
  %t351 = load i32, ptr %l2, !tbaa !23
  %t354 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t350, i32 %t351)
  store i32 %t354, ptr %l187
  br label %bb80
bb79:
  br label %bb83
bb80:
  %t355 = load ptr, ptr %l182, !tbaa !29
  %t356 = load i32, ptr %l187, !tbaa !23
  %t357 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t355, i32 %t356)
  store i64 %t357, ptr %l188
  br label %bb81
bb81:
  %t358 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t358, ptr %l189, !tbaa !27
  %t359 = load i64, ptr %l18, !tbaa !24
  %t361 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr ptr, ptr %t362, i64 %t359
  %t364 = load ptr, ptr %t363, !tbaa !39
  %t366 = getelementptr %"compiler/ast:Param", ptr %t364, i32 0, i32 2
  %t367 = load ptr, ptr %t366, !tbaa !29
  %t368 = load ptr, ptr %l180, !tbaa !29
  %t369 = load i64, ptr %l188, !tbaa !24
  %t371 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t368, i64 %t369, ptr %t367)
  store { i64, [3 x i64] } %t371, ptr %l193
  br label %bb82
bb82:
  %t372 = load { i64, [3 x i64] }, ptr %l193
  %t373 = load ptr, ptr %l179, !tbaa !29
  %t374 = getelementptr %"compiler/check:Checker", ptr %t373, i32 0, i32 13
  store { i64, [3 x i64] } %t372, ptr %t374
  br label %bb83
bb83:
  %t375 = load i64, ptr %l18, !tbaa !24
  store i64 %t375, ptr %l194, !tbaa !24
  %t376 = load i1, ptr %l19, !tbaa !21
  br i1 %t376, label %bb84, label %bb85
bb84:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load %"compiler/source:Span", ptr %l1
  %t380 = load i64, ptr %l18, !tbaa !24
  %t381 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t381, ptr %l200, !tbaa !27
  %t382 = load i64, ptr %l18, !tbaa !24
  %t384 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr i32, ptr %t385, i64 %t382
  %t387 = load i32, ptr %t386, !tbaa !33
  %t392 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %t378, %"compiler/source:Span" %t379, i64 %t380, i32 %t387)
  store ptr %t392, ptr %l203
  br label %bb86
bb85:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l1
  %t395 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t395, ptr %l206, !tbaa !27
  %t396 = load i64, ptr %l18, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i32, ptr %t399, i64 %t396
  %t401 = load i32, ptr %t400, !tbaa !33
  %t405 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %t393, %"compiler/source:Span" %t394, i32 %t401)
  store ptr %t405, ptr %l209
  br label %bb87
bb86:
  %t406 = load ptr, ptr %l203, !tbaa !29
  store ptr %t406, ptr %l196, !tbaa !29
  br label %bb88
bb87:
  %t407 = load ptr, ptr %l209, !tbaa !29
  store ptr %t407, ptr %l196, !tbaa !29
  br label %bb88
bb88:
  %t408 = load ptr, ptr %l196, !tbaa !29
  %t409 = load ptr, ptr %lp11
  %t410 = load i64, ptr %l194, !tbaa !24
  %t411 = getelementptr { i64, ptr }, ptr %t409, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = getelementptr ptr, ptr %t412, i64 %t410
  store ptr %t408, ptr %t413, !tbaa !39
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load { i64, [3 x i64] }, ptr %l20
  %t418 = getelementptr %"compiler/check:Checker", ptr %t414, i32 0, i32 13
  store { i64, [3 x i64] } %t415, ptr %t418
  br label %bb89
bb89:
  %t419 = load i64, ptr %l17, !tbaa !24
  %t421 = add i64 %t419, 1
  store i64 %t421, ptr %l17, !tbaa !24
  br label %bb65
bb90:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load i32, ptr %l12, !tbaa !23
  %t427 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 23
  store i32 %t424, ptr %t427, !tbaa !23
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load %"compiler/source:Span", ptr %l1
  %t430 = load i32, ptr %l2, !tbaa !23
  %t431 = load i64, ptr %l4, !tbaa !24
  %t432 = load ptr, ptr %lp11
  %t433 = load { i64, ptr }, ptr %t432, !tbaa !27
  %t439 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v1, ptr %v1, ptr %t428, %"compiler/source:Span" %t429, i32 %t430, i64 %t431, { i64, ptr } %t433, i1 true)
  store ptr %t439, ptr %l221
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s3)
  %t440 = load ptr, ptr %l221, !tbaa !29
  store ptr %t440, ptr %rv
  br label %ret
bb92:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load i32, ptr %l2, !tbaa !23
  %t445 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t441, i32 %t442)
  store i1 %t445, ptr %l224
  br label %bb93
bb93:
  %t446 = load i1, ptr %l224, !tbaa !21
  br i1 %t446, label %bb94, label %bb95
bb94:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load i32, ptr %l2, !tbaa !23
  %t451 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t447, i32 %t448)
  store i1 %t451, ptr %l228
  br label %bb96
bb95:
  store i1 false, ptr %l225, !tbaa !21
  br label %bb97
bb96:
  %t452 = load i1, ptr %l228, !tbaa !21
  %t453 = xor i1 %t452, true
  store i1 %t453, ptr %l225, !tbaa !21
  br label %bb97
bb97:
  %t455 = load i1, ptr %l225, !tbaa !21
  br i1 %t455, label %bb98, label %bb99
bb98:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/check:Checker", ptr %t456, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !29
  %t460 = load i32, ptr %l2, !tbaa !23
  %t463 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t459, i32 %t460, i64 0)
  store i32 %t463, ptr %l233
  br label %bb100
bb99:
  br label %bb127
bb100:
  %t464 = load i32, ptr %l233, !tbaa !23
  store i32 %t464, ptr %l21, !tbaa !23
  %t465 = load i32, ptr %l21, !tbaa !23
  %t466 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t469 = icmp ne i32 %t465, %t466
  br i1 %t469, label %bb101, label %bb102
bb101:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr %"compiler/check:Checker", ptr %t471, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !29
  %t476 = getelementptr %"compiler/generic:Program", ptr %t474, i32 0, i32 2
  store ptr %t476, ptr %l239, !tbaa !29
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/check:Checker", ptr %t477, i32 0, i32 1
  %t480 = load ptr, ptr %t479, !tbaa !29
  %t482 = getelementptr %"compiler/generic:Program", ptr %t480, i32 0, i32 2
  %t483 = load i32, ptr %l21, !tbaa !23
  %t486 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t482, i32 %t483)
  store i32 %t486, ptr %l244
  br label %bb103
bb102:
  br label %bb126
bb103:
  %t487 = load ptr, ptr %l239, !tbaa !29
  %t488 = load i32, ptr %l244, !tbaa !23
  %t489 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t487, i32 %t488)
  store { i64, ptr } %t489, ptr %l245
  br label %bb104
bb104:
  %t490 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t490, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 0
  store i64 %t493, ptr %l24, !tbaa !24
  br label %bb105
bb105:
  %t495 = load i64, ptr %l23, !tbaa !24
  %t496 = load i64, ptr %l24, !tbaa !24
  %t499 = icmp slt i64 %t495, %t496
  %t501 = xor i1 %t499, true
  br i1 %t501, label %bb106, label %bb107
bb106:
  br label %bb121
bb107:
  br label %bb108
bb108:
  %t503 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t503, ptr %l252, !tbaa !27
  %t504 = load i64, ptr %l23, !tbaa !24
  %t506 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr i32, ptr %t507, i64 %t504
  %t509 = load i32, ptr %t508, !tbaa !33
  store i32 %t509, ptr %l25, !tbaa !23
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load i32, ptr %l25, !tbaa !23
  %t515 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t511, i32 %t512)
  store i1 %t515, ptr %l257
  br label %bb109
bb109:
  %t516 = load i1, ptr %l257, !tbaa !21
  br i1 %t516, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s15
  %t517 = load ptr, ptr %l0, !tbaa !29
  store ptr %t517, ptr %l258, !tbaa !29
  %t518 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t518, ptr %l259
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load i32, ptr %l25, !tbaa !23
  %t523 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t519, i32 %t520)
  store { i64, ptr } %t523, ptr %l262
  br label %bb112
bb111:
  br label %bb119
bb112:
  %t524 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t525 = extractvalue { i64, ptr } %t524, 0
  %t526 = extractvalue { i64, ptr } %t524, 1
  %t527 = mul i64 %t525, 1
  %t528 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t527)
  call void @llvm.memcpy.p0.p0.i64(ptr %t528, ptr %t526, i64 %t527, i1 false)
  %t529 = insertvalue { i64, ptr } undef, i64 %t525, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t528, 1
  store { i64, ptr } %t530, ptr %l263, !tbaa !27
  %t531 = load ptr, ptr %l0, !tbaa !29
  store ptr %t531, ptr %l264, !tbaa !29
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t534 = getelementptr %"compiler/check:Checker", ptr %t532, i32 0, i32 1
  %t535 = load ptr, ptr %t534, !tbaa !29
  %t537 = getelementptr %"compiler/generic:Program", ptr %t535, i32 0, i32 2
  %t538 = load i32, ptr %l25, !tbaa !23
  %t541 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t537, i32 %t538)
  store i32 %t541, ptr %l269
  br label %bb113
bb113:
  %t542 = load ptr, ptr %l264, !tbaa !29
  %t543 = load i32, ptr %l269, !tbaa !23
  %t544 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t542, i32 %t543)
  store { i64, ptr } %t544, ptr %l270
  br label %bb114
bb114:
  %t545 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t546 = extractvalue { i64, ptr } %t545, 0
  %t547 = extractvalue { i64, ptr } %t545, 1
  %t548 = mul i64 %t546, 1
  %t549 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t548)
  call void @llvm.memcpy.p0.p0.i64(ptr %t549, ptr %t547, i64 %t548, i1 false)
  %t550 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t549, 1
  %t552 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t554 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoZeroNonNull(ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t552, { i64, ptr } %t551)
  store %"compiler/diagmsg:Msg" %t554, ptr %l272
  br label %bb115
bb115:
  %t555 = load ptr, ptr %l258, !tbaa !29
  %t556 = load %"compiler/source:Span", ptr %l259
  %t557 = load %"compiler/diagmsg:Msg", ptr %l272
  %t558 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t555, %"compiler/source:Span" %t556, %"compiler/diagmsg:Msg" %t557)
  store i64 %t558, ptr %l273
  br label %bb116
bb116:
  %t559 = load i64, ptr %l273, !tbaa !24
  %t560 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %t560, i64 %t559)
  br label %bb117
bb117:
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t565 = load %"compiler/source:Span", ptr %l1
  %t568 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t564, %"compiler/source:Span" %t565)
  store ptr %t568, ptr %l278
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s15)
  %t569 = load ptr, ptr %l278, !tbaa !29
  store ptr %t569, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t570 = load i64, ptr %l23, !tbaa !24
  %t572 = add i64 %t570, 1
  store i64 %t572, ptr %l23, !tbaa !24
  br label %bb105
bb121:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load %"compiler/source:Span", ptr %l1
  %t576 = load i32, ptr %l2, !tbaa !23
  %t577 = load i32, ptr %l21, !tbaa !23
  %t582 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseZero(ptr %v0, ptr %v1, ptr %t574, %"compiler/source:Span" %t575, i32 %t576, i32 %t577)
  store ptr %t582, ptr %l285
  br label %bb122
bb122:
  %t583 = load ptr, ptr %l285, !tbaa !29
  store ptr %t583, ptr %l27, !tbaa !29
  %t584 = load ptr, ptr %l27, !tbaa !29
  %t586 = icmp eq ptr %t584, null
  %t588 = xor i1 %t586, true
  br i1 %t588, label %bb123, label %bb124
bb123:
  %t590 = load ptr, ptr %l27, !tbaa !29
  store ptr %t590, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load i32, ptr %l2, !tbaa !23
  %t596 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %t592, i32 %t593)
  store i1 %t596, ptr %l292
  br label %bb128
bb128:
  %t597 = load i1, ptr %l292, !tbaa !21
  br i1 %t597, label %bb129, label %bb130
bb129:
  store %olang.scope zeroinitializer, ptr %s18
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load i32, ptr %l2, !tbaa !23
  %t602 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t598, i32 %t599)
  store i64 %t602, ptr %l295
  br label %bb131
bb130:
  br label %bb138
bb131:
  %t603 = load i64, ptr %l295, !tbaa !24
  store i64 %t603, ptr %l28, !tbaa !24
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = getelementptr %"compiler/check:Checker", ptr %t604, i32 0, i32 1
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t609 = getelementptr %"compiler/generic:Program", ptr %t607, i32 0, i32 2
  store ptr %t609, ptr %l298, !tbaa !29
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t612 = getelementptr %"compiler/check:Checker", ptr %t610, i32 0, i32 1
  %t613 = load ptr, ptr %t612, !tbaa !29
  %t615 = getelementptr %"compiler/generic:Program", ptr %t613, i32 0, i32 2
  store ptr %t615, ptr %l301, !tbaa !29
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t618 = getelementptr %"compiler/check:Checker", ptr %t616, i32 0, i32 1
  %t619 = load ptr, ptr %t618, !tbaa !29
  %t620 = load i32, ptr %l2, !tbaa !23
  %t623 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t619, i32 %t620)
  store i32 %t623, ptr %l305
  br label %bb132
bb132:
  %t624 = load ptr, ptr %l301, !tbaa !29
  %t625 = load i32, ptr %l305, !tbaa !23
  %t626 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t624, i32 %t625)
  store i32 %t626, ptr %l306
  br label %bb133
bb133:
  %t627 = load ptr, ptr %l298, !tbaa !29
  %t628 = load i32, ptr %l306, !tbaa !23
  %t629 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s18, ptr %t627, i32 %t628)
  store { i64, ptr } %t629, ptr %l307
  br label %bb134
bb134:
  %t630 = load { i64, ptr }, ptr %l307, !tbaa !27
  store { i64, ptr } %t630, ptr %l308, !tbaa !27
  %t631 = getelementptr { i64, ptr }, ptr %l308, i32 0, i32 1
  %t632 = load ptr, ptr %t631, !tbaa !27
  %t633 = getelementptr i32, ptr %t632, i64 0
  %t634 = load i32, ptr %t633, !tbaa !33
  %t636 = load ptr, ptr %l0, !tbaa !29
  store ptr %t636, ptr %l310, !tbaa !29
  %t637 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t637, ptr %l311
  %t638 = load i32, ptr %l2, !tbaa !23
  store i32 %t638, ptr %l312, !tbaa !23
  %t639 = load i64, ptr %l28, !tbaa !24
  store i64 %t639, ptr %l313, !tbaa !24
  %t640 = load ptr, ptr %l0, !tbaa !29
  store ptr %t640, ptr %l314, !tbaa !29
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load %"compiler/source:Span", ptr %l1
  %t647 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t641, %"compiler/source:Span" %t642, i32 %t634)
  store ptr %t647, ptr %l318
  br label %bb135
bb135:
  %t648 = load ptr, ptr %l314, !tbaa !29
  %t649 = load ptr, ptr %l318, !tbaa !29
  %t650 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t648, ptr %t649)
  store { i64, ptr } %t650, ptr %l319
  br label %bb136
bb136:
  %t651 = load ptr, ptr %l310, !tbaa !29
  %t652 = load %"compiler/source:Span", ptr %l311
  %t653 = load i32, ptr %l312, !tbaa !23
  %t654 = load i64, ptr %l313, !tbaa !24
  %t655 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t656 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v0, ptr %v1, ptr %t651, %"compiler/source:Span" %t652, i32 %t653, i64 %t654, { i64, ptr } %t655, i1 true)
  store ptr %t656, ptr %l320
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s18)
  %t657 = load ptr, ptr %l320, !tbaa !29
  store ptr %t657, ptr %rv
  br label %ret
bb138:
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t659 = load %"compiler/source:Span", ptr %l1
  %t660 = load i32, ptr %l2, !tbaa !23
  %t664 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t658, %"compiler/source:Span" %t659, i32 %t660, i64 0)
  store ptr %t664, ptr %l324
  br label %bb139
bb139:
  %t665 = load ptr, ptr %l324, !tbaa !29
  store ptr %t665, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esome(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  store i32 %t21, ptr %l5, !tbaa !23
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = icmp ne i32 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2ereaches(ptr %v0, ptr %a0, i32 %t28)
  store i1 %t31, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2edeclNames(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb36
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l19, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l5, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load ptr, ptr %l22, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 11}
  %t36 = icmp eq i64 %t34, 8
  store i1 %t36, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr { i64, [6 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t40, i32 0, i32 1
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = call i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %t44)
  store i32 %t46, ptr %l29
  br label %bb13
bb13:
  %t47 = load i32, ptr %l29, !tbaa !23
  store i32 %t47, ptr %l7, !tbaa !23
  %t48 = load i32, ptr %l7, !tbaa !23
  %t50 = icmp ne i32 %t48, 0
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t53 = load i32, ptr %l7, !tbaa !23
  %t56 = call i1 @compiler_2fcheck_2ehasName(ptr %v1, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l35
  br label %bb16
bb15:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb17
bb16:
  %t57 = load i1, ptr %l35, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t60 = load i1, ptr %l32, !tbaa !21
  br i1 %t60, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load i32, ptr %l7, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t61, i32 %t62)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb34
bb22:
  %t65 = load ptr, ptr %l5, !tbaa !29
  store ptr %t65, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t66 = load ptr, ptr %l39, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l39, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 11}
  %t72 = icmp eq i64 %t70, 7
  store i1 %t72, ptr %l40, !tbaa !21
  br label %bb24
bb24:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t74 = load ptr, ptr %l5, !tbaa !29
  %t76 = getelementptr { i64, [6 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t80 = load ptr, ptr %l8, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2echainNames(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_bae3cd237d905c4d_ccae9f7ce38212b9)
  unreachable
bb34:
  br label %bb35
bb35:
  %t84 = load i64, ptr %l3, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l3, !tbaa !24
  br label %bb4
bb36:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2edeclaredFact(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load i1, ptr %l9, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisRest(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_69063e233c23bbc5_4e0c3b9f00520e59)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2elambdaOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 22
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_94831dcf6c50df99_e0fe015107062615)
  unreachable
bb11:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l72 = alloca i1
  %l83 = alloca { i64, ptr }
  %l88 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l106 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l122 = alloca i32
  %l126 = alloca ptr
  %l127 = alloca i1
  %l130 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i1
  %l147 = alloca { i64, ptr }
  %l152 = alloca i1
  %l164 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t12 = load ptr, ptr %l21, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l21, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 17}
  %t18 = icmp eq i64 %t16, 7
  store i1 %t18, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l22, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t21 = load ptr, ptr %l25, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l25, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 17}
  %t27 = icmp eq i64 %t25, 8
  store i1 %t27, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l26, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t31 = load ptr, ptr %l30, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb17, label %bb18
bb17:
  %t34 = load ptr, ptr %l30, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 17}
  %t37 = icmp eq i64 %t35, 9
  store i1 %t37, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t38 = load i1, ptr %l31, !tbaa !21
  br i1 %t38, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 true, ptr %rv
  br label %ret
bb22:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t41 = load ptr, ptr %l35, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb23, label %bb24
bb23:
  %t44 = load ptr, ptr %l35, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 17}
  %t47 = icmp eq i64 %t45, 3
  store i1 %t47, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t48 = load i1, ptr %l36, !tbaa !21
  br i1 %t48, label %bb25, label %bb26
bb25:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", ptr }, ptr %t51, i32 0, i32 1
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l1, !tbaa !29
  br label %bb27
bb26:
  br label %bb36
bb27:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/typed:If", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb28, label %bb29
bb28:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/typed:If", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t70 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t67)
  store i1 %t70, ptr %l49
  br label %bb30
bb29:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb31
bb30:
  %t71 = load i1, ptr %l49, !tbaa !21
  store i1 %t71, ptr %l45, !tbaa !21
  br label %bb31
bb31:
  %t72 = load i1, ptr %l45, !tbaa !21
  br i1 %t72, label %bb32, label %bb33
bb32:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/typed:If", ptr %t73, i32 0, i32 2
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t76)
  store i1 %t78, ptr %l53
  br label %bb34
bb33:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb35
bb34:
  %t79 = load i1, ptr %l53, !tbaa !21
  store i1 %t79, ptr %l50, !tbaa !21
  br label %bb35
bb35:
  %t80 = load i1, ptr %l50, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
bb36:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t82 = load ptr, ptr %l54, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb37, label %bb38
bb37:
  %t85 = load ptr, ptr %l54, !tbaa !29
  %t86 = load i64, ptr %t85, !range !{i64 0, i64 17}
  %t88 = icmp eq i64 %t86, 11
  store i1 %t88, ptr %l55, !tbaa !21
  br label %bb38
bb38:
  %t89 = load i1, ptr %l55, !tbaa !21
  br i1 %t89, label %bb39, label %bb40
bb39:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l2, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t99 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t96)
  store i1 %t99, ptr %l62
  br label %bb42
bb42:
  %t100 = load i1, ptr %l62, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
bb43:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb44, label %bb45
bb44:
  %t105 = load ptr, ptr %l63, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 17}
  %t108 = icmp eq i64 %t106, 13
  store i1 %t108, ptr %l64, !tbaa !21
  br label %bb45
bb45:
  %t109 = load i1, ptr %l64, !tbaa !21
  br i1 %t109, label %bb46, label %bb47
bb46:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr { i64, [3 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", ptr }, ptr %t112, i32 0, i32 1
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l3, !tbaa !29
  br label %bb48
bb47:
  br label %bb63
bb48:
  %t116 = load ptr, ptr %l3, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Join", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t119)
  store i1 %t122, ptr %l72
  br label %bb49
bb49:
  %t123 = load i1, ptr %l72, !tbaa !21
  %t124 = xor i1 %t123, true
  br i1 %t124, label %bb50, label %bb51
bb50:
  store i1 false, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Join", ptr %t127, i32 0, i32 2
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  store i64 %t134, ptr %l6, !tbaa !24
  br label %bb53
bb53:
  %t136 = load i64, ptr %l5, !tbaa !24
  %t137 = load i64, ptr %l6, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb54, label %bb55
bb54:
  br label %bb62
bb55:
  br label %bb56
bb56:
  %t144 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t144, ptr %l83, !tbaa !27
  %t145 = load i64, ptr %l5, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr ptr, ptr %t148, i64 %t145
  %t150 = load ptr, ptr %t149, !tbaa !39
  %t154 = getelementptr %"compiler/typed:Clause", ptr %t150, i32 0, i32 3
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t155)
  store i1 %t157, ptr %l88
  br label %bb57
bb57:
  %t158 = load i1, ptr %l88, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb58, label %bb59
bb58:
  store i1 false, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t162 = load i64, ptr %l5, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l5, !tbaa !24
  br label %bb53
bb62:
  store i1 true, ptr %rv
  br label %ret
bb63:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t168 = load ptr, ptr %l94, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb64, label %bb65
bb64:
  %t171 = load ptr, ptr %l94, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 17}
  %t174 = icmp eq i64 %t172, 4
  store i1 %t174, ptr %l95, !tbaa !21
  br label %bb65
bb65:
  %t175 = load i1, ptr %l95, !tbaa !21
  br i1 %t175, label %bb66, label %bb67
bb66:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l8, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l9, !tbaa !29
  br label %bb68
bb67:
  br label %bb74
bb68:
  %t188 = load ptr, ptr %l8, !tbaa !29
  %t190 = load ptr, ptr %l8, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Block", ptr %t190, i32 0, i32 0
  %t193 = load i32, ptr %t192, !tbaa !23
  %t196 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t188, i32 %t193)
  store i1 %t196, ptr %l106
  br label %bb69
bb69:
  %t197 = load i1, ptr %l106, !tbaa !21
  %t198 = xor i1 %t197, true
  br i1 %t198, label %bb70, label %bb71
bb70:
  %t200 = load ptr, ptr %l9, !tbaa !29
  %t201 = load ptr, ptr %l8, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Block", ptr %t201, i32 0, i32 0
  %t204 = load i32, ptr %t203, !tbaa !23
  %t207 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t200, i32 %t204)
  store i1 %t207, ptr %l112
  br label %bb72
bb71:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb73
bb72:
  %t208 = load i1, ptr %l112, !tbaa !21
  %t209 = xor i1 %t208, true
  store i1 %t209, ptr %l108, !tbaa !21
  br label %bb73
bb73:
  %t211 = load i1, ptr %l108, !tbaa !21
  store i1 %t211, ptr %rv
  br label %ret
bb74:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t213 = load ptr, ptr %l114, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb75, label %bb76
bb75:
  %t216 = load ptr, ptr %l114, !tbaa !29
  %t217 = load i64, ptr %t216, !range !{i64 0, i64 17}
  %t219 = icmp eq i64 %t217, 2
  store i1 %t219, ptr %l115, !tbaa !21
  br label %bb76
bb76:
  %t220 = load i1, ptr %l115, !tbaa !21
  br i1 %t220, label %bb77, label %bb78
bb77:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr { i64, [3 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", ptr }, ptr %t223, i32 0, i32 1
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l10, !tbaa !29
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t227 = load ptr, ptr %l10, !tbaa !29
  %t230 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t227)
  store i32 %t230, ptr %l122
  br label %bb80
bb80:
  %t231 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t232 = load i32, ptr %l122, !tbaa !23
  %t234 = icmp eq i32 %t232, %t231
  br i1 %t234, label %bb81, label %bb82
bb81:
  store i1 true, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t238 = load ptr, ptr %l126, !tbaa !29
  %t239 = icmp ne ptr %t238, null
  br i1 %t239, label %bb84, label %bb85
bb84:
  %t241 = load ptr, ptr %l126, !tbaa !29
  %t242 = load i64, ptr %t241, !range !{i64 0, i64 17}
  %t244 = icmp eq i64 %t242, 2
  store i1 %t244, ptr %l127, !tbaa !21
  br label %bb85
bb85:
  %t245 = load i1, ptr %l127, !tbaa !21
  br i1 %t245, label %bb86, label %bb87
bb86:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", ptr }, ptr %t248, i32 0, i32 1
  %t250 = load ptr, ptr %t249
  store ptr %t250, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t251 = load ptr, ptr %l132, !tbaa !29
  %t252 = icmp ne ptr %t251, null
  br i1 %t252, label %bb88, label %bb89
bb87:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb90
bb88:
  %t254 = load ptr, ptr %l132, !tbaa !29
  %t255 = load i64, ptr %t254, !range !{i64 0, i64 18}
  %t257 = icmp eq i64 %t255, 13
  store i1 %t257, ptr %l133, !tbaa !21
  br label %bb89
bb89:
  %t258 = load i1, ptr %l133, !tbaa !21
  store i1 %t258, ptr %l130, !tbaa !21
  br label %bb90
bb90:
  %t259 = load i1, ptr %l130, !tbaa !21
  br i1 %t259, label %bb91, label %bb92
bb91:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr { i64, [3 x i64] }, ptr %t260, i32 0, i32 1
  %t263 = getelementptr { %"compiler/source:Span", ptr }, ptr %t262, i32 0, i32 1
  %t264 = load ptr, ptr %t263
  %t266 = getelementptr { i64, [5 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t266, i32 0, i32 2
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l11, !tbaa !29
  br label %bb93
bb92:
  br label %bb108
bb93:
  %t270 = load ptr, ptr %l11, !tbaa !29
  %t272 = getelementptr %"compiler/typed:Match", ptr %t270, i32 0, i32 1
  %t273 = load { i64, ptr }, ptr %t272, !tbaa !27
  store { i64, ptr } %t273, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t275 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  store i64 %t277, ptr %l14, !tbaa !24
  br label %bb94
bb94:
  %t279 = load i64, ptr %l13, !tbaa !24
  %t280 = load i64, ptr %l14, !tbaa !24
  %t283 = icmp slt i64 %t279, %t280
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb95, label %bb96
bb95:
  br label %bb103
bb96:
  br label %bb97
bb97:
  %t287 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t287, ptr %l147, !tbaa !27
  %t288 = load i64, ptr %l13, !tbaa !24
  %t290 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr ptr, ptr %t291, i64 %t288
  %t293 = load ptr, ptr %t292, !tbaa !39
  %t297 = getelementptr %"compiler/typed:Arm", ptr %t293, i32 0, i32 3
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t298)
  store i1 %t300, ptr %l152
  br label %bb98
bb98:
  %t301 = load i1, ptr %l152, !tbaa !21
  %t302 = xor i1 %t301, true
  br i1 %t302, label %bb99, label %bb100
bb99:
  store i1 false, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t305 = load i64, ptr %l13, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l13, !tbaa !24
  br label %bb94
bb103:
  %t309 = load ptr, ptr %l11, !tbaa !29
  %t311 = getelementptr %"compiler/typed:Match", ptr %t309, i32 0, i32 2
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = icmp eq ptr %t312, null
  br i1 %t314, label %bb104, label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_eb3e4e8f3f96f0ec_5bc3fc9686c42b70)
  unreachable
bb105:
  br label %bb106
bb106:
  %t316 = load ptr, ptr %l11, !tbaa !29
  %t318 = getelementptr %"compiler/typed:Match", ptr %t316, i32 0, i32 2
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Arm", ptr %t319, i32 0, i32 3
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t325 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t323)
  store i1 %t325, ptr %l164
  br label %bb107
bb107:
  %t326 = load i1, ptr %l164, !tbaa !21
  store i1 %t326, ptr %rv
  br label %ret
bb108:
  br i1 true, label %bb109, label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  store i1 false, ptr %rv
  br label %ret
bb112:
  call void @__olang_check_failed(ptr @olang_loc_bad8a01556e87002_6e42cd1773855696)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t5 = trunc i64 %a1 to i32
  %t8 = sub i32 %t2, %t5
  %t9 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t13 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t8, i32 %t10)
  store %"compiler/source:Span" %t13, ptr %l7
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2enullValue(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l20 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:Match", ptr %a0, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l4, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Case", ptr %t26, i32 0, i32 5
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Case", ptr %t35, i32 0, i32 5
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_29f8057051902f50_e91b4d9ed5822c7c)
  unreachable
bb8:
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Case", ptr %t42, i32 0, i32 5
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %t45)
  store i1 %t47, ptr %l26
  br label %bb10
bb10:
  %t48 = load i1, ptr %l26, !tbaa !21
  store i1 %t48, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t49 = load i1, ptr %l20, !tbaa !21
  br i1 %t49, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l2, !tbaa !24
  br label %bb1
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i32
  %l59 = alloca i64
  %l62 = alloca i64
  %l81 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t24 = alloca i64
  %t109 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l19, !tbaa !23
  %t17 = icmp sge i64 1, 0
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = icmp sle i64 1, 2305843009213693951
  br i1 %t19, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a)
  unreachable
bb8:
  %t21 = mul i64 1, 4
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  %t23 = load i32, ptr %l19, !tbaa !23
  store i64 0, ptr %t24
  br label %fill.25
fill.25:
  %t28 = load i64, ptr %t24
  %t29 = icmp slt i64 %t28, 1
  br i1 %t29, label %fillb.26, label %filld.27
fillb.26:
  %t30 = getelementptr i32, ptr %t22, i64 %t28
  store i32 %t23, ptr %t30
  %t31 = add i64 %t28, 1
  store i64 %t31, ptr %t24
  br label %fill.25
filld.27:
  %t32 = insertvalue { i64, ptr } undef, i64 1, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t22, 1
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a)
  unreachable
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 30}
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %v1, ptr %t50)
  store { i64, ptr } %t52, ptr %l30
  br label %bb16
bb16:
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 30}
  %t61 = icmp eq i64 %t59, 14
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb20, label %bb21
bb20:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t71, i32 0, i32 2
  %t73 = load i32, ptr %t72
  store i32 %t73, ptr %l4, !tbaa !23
  br label %bb22
bb21:
  br label %bb47
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %s3, ptr %t75)
  store { i64, ptr } %t77, ptr %l40
  br label %bb23
bb23:
  %t78 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t78, ptr %l5, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t85 = icmp sge i64 0, 0
  br i1 %t85, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  %t87 = icmp sle i64 0, 2305843009213693951
  br i1 %t87, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf)
  unreachable
bb28:
  %t89 = mul i64 0, 4
  %t90 = insertvalue { i64, ptr } undef, i64 0, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t91, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf)
  unreachable
bb30:
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l49, !tbaa !24
  %t98 = load i32, ptr %l4, !tbaa !23
  store i32 %t98, ptr %l50, !tbaa !23
  %t99 = load i64, ptr %l49, !tbaa !24
  %t100 = icmp sge i64 %t99, 0
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t102 = load i64, ptr %l49, !tbaa !24
  %t103 = icmp sle i64 %t102, 2305843009213693951
  br i1 %t103, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5df9bd969218a728_7fa184e5bc45956c)
  unreachable
bb33:
  %t105 = load i64, ptr %l49, !tbaa !24
  %t106 = mul i64 %t105, 4
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  %t108 = load i32, ptr %l50, !tbaa !23
  store i64 0, ptr %t109
  br label %fill.110
fill.110:
  %t113 = load i64, ptr %t109
  %t114 = icmp slt i64 %t113, %t105
  br i1 %t114, label %fillb.111, label %filld.112
fillb.111:
  %t115 = getelementptr i32, ptr %t107, i64 %t113
  store i32 %t108, ptr %t115
  %t116 = add i64 %t113, 1
  store i64 %t116, ptr %t109
  br label %fill.110
filld.112:
  %t117 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t107, 1
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t119, ptr %lp6
  %t121 = load ptr, ptr %lp6
  store { i64, ptr } %t118, ptr %t121, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  store i64 %t124, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load i64, ptr %l7, !tbaa !24
  %t130 = icmp sgt i64 %t126, %t127
  br i1 %t130, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_5df9bd969218a728_7fa184e5bc45956c)
  unreachable
bb35:
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = icmp sgt i64 %t132, 0
  br i1 %t134, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb40
bb37:
  %t136 = load i64, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l7, !tbaa !24
  %t140 = sub i64 %t136, %t137
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = add i64 %t140, %t141
  %t146 = sub i64 %t144, 1
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = sdiv i64 %t146, %t147
  store i64 %t150, ptr %l62, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb39
bb39:
  %t152 = load i64, ptr %l62, !tbaa !24
  store i64 %t152, ptr %l59, !tbaa !24
  br label %bb40
bb40:
  %t153 = load i64, ptr %l59, !tbaa !24
  store i64 %t153, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb41
bb41:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t155 = load i64, ptr %l10, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb44
bb44:
  %t162 = load i64, ptr %l7, !tbaa !24
  %t163 = load i64, ptr %l11, !tbaa !24
  %t164 = load i64, ptr %l9, !tbaa !24
  %t167 = mul i64 %t163, %t164
  %t170 = add i64 %t162, %t167
  store i64 %t170, ptr %l12, !tbaa !24
  %t172 = load i64, ptr %l12, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t173, ptr %l81, !tbaa !27
  %t174 = load i64, ptr %l12, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i32, ptr %t177, i64 %t174
  %t179 = load i32, ptr %t178, !tbaa !33
  %t181 = load ptr, ptr %lp6
  %t183 = getelementptr { i64, ptr }, ptr %t181, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i32, ptr %t184, i64 %t172
  store i32 %t179, ptr %t185, !tbaa !33
  br label %bb45
bb45:
  %t186 = load i64, ptr %l11, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l11, !tbaa !24
  br label %bb41
bb46:
  %t190 = load ptr, ptr %lp6
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t191, ptr %rv
  br label %ret
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb55
bb50:
  %t193 = icmp sge i64 0, 0
  br i1 %t193, label %bb51, label %bb52
bb51:
  %t195 = icmp sle i64 0, 2305843009213693951
  br i1 %t195, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_69c4f09cb804b315_a031ca4d3ae928f9)
  unreachable
bb53:
  %t197 = mul i64 0, 4
  %t198 = insertvalue { i64, ptr } undef, i64 0, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t199, ptr %rv
  br label %ret
bb54:
  call void @__olang_check_failed(ptr @olang_loc_69c4f09cb804b315_a031ca4d3ae928f9)
  unreachable
bb55:
  call void @__olang_check_failed(ptr @olang_loc_81e6157a61b9a5f1_a0e5ca59452f2055)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2eplainIndex(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb36
bb10:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 2
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l1, !tbaa !29
  br label %bb19
bb14:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb15, label %bb16
bb15:
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 3
  store i1 %t41, ptr %l20, !tbaa !21
  br label %bb16
bb16:
  %t42 = load i1, ptr %l20, !tbaa !21
  br i1 %t42, label %bb17, label %bb18
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l1, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = call i1 @compiler_2fcheck_2eplainPlace(ptr %v0, ptr %t49)
  store i1 %t51, ptr %l26
  br label %bb20
bb20:
  %t52 = load i1, ptr %l26, !tbaa !21
  store i1 %t52, ptr %l4, !tbaa !21
  br label %bb36
bb21:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t54 = load ptr, ptr %l27, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 9
  store i1 %t60, ptr %l28, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l28, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t64, i32 0, i32 2
  %t66 = load i32, ptr %t65, !range !{i32 0, i32 46}
  store i32 %t66, ptr %l2
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t70, i32 0, i32 4
  %t72 = load { i64, ptr }, ptr %t71
  store { i64, ptr } %t72, ptr %l3, !tbaa !27
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t74 = load i32, ptr %l2, !range !{i32 0, i32 46}
  %t76 = trunc i64 29 to i32
  %t77 = icmp eq i32 %t74, %t76
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t81 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t83 = call i1 @compiler_2fcheck_2eplainIndexes(ptr %v0, { i64, ptr } %t81)
  store i1 %t83, ptr %l40
  br label %bb29
bb28:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb30
bb29:
  %t84 = load i1, ptr %l40, !tbaa !21
  store i1 %t84, ptr %l38, !tbaa !21
  br label %bb30
bb30:
  %t85 = load i1, ptr %l38, !tbaa !21
  store i1 %t85, ptr %l4, !tbaa !21
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_5e0248e79c45fbe7_9eea68ca563d9803)
  unreachable
bb36:
  %t86 = load i1, ptr %l4, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2erebased(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca i32
  %l25 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %rv = alloca ptr
  %t42 = alloca { i64, [4 x i64] }, align 8
  %t81 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 3
  %t32 = load i64, ptr %t31
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t34 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t34, ptr %l21
  %t35 = load i32, ptr %l3, !tbaa !23
  store i32 %t35, ptr %l22, !tbaa !23
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t40 = call ptr @compiler_2fcheck_2erebased(ptr %v0, ptr %v1, ptr %v0, ptr %t36, ptr %t37)
  store ptr %t40, ptr %l25
  br label %bb6
bb6:
  %t41 = load i64, ptr %l5, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 0
  store i64 3, ptr %t43
  %t44 = load %"compiler/source:Span", ptr %l21
  %t45 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t44, 0
  %t46 = load i32, ptr %l22, !tbaa !23
  %t47 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t45, i32 %t46, 1
  %t48 = load ptr, ptr %l25, !tbaa !29
  %t49 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t47, ptr %t48, 2
  %t51 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t49, i64 %t41, 3
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t51, ptr %t52
  %t53 = load { i64, [4 x i64] }, ptr %t42
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t53, ptr %t55
  store ptr %t55, ptr %l8, !tbaa !29
  br label %bb18
bb7:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb8, label %bb9
bb8:
  %t61 = load ptr, ptr %l29, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 8}
  %t64 = icmp eq i64 %t62, 6
  store i1 %t64, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb10, label %bb11
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t68, i32 0, i32 0
  %t70 = load %"compiler/source:Span", ptr %t69
  store %"compiler/source:Span" %t70, ptr %l6
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l7, !tbaa !23
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t78 = load %"compiler/source:Span", ptr %l6
  %t79 = load i32, ptr %l7, !tbaa !23
  %t80 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 0
  store i64 2, ptr %t82
  %t84 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t78, 0
  %t86 = insertvalue { %"compiler/source:Span", i32, ptr } %t84, i32 %t79, 1
  %t88 = insertvalue { %"compiler/source:Span", i32, ptr } %t86, ptr %t80, 2
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t88, ptr %t89
  %t90 = load { i64, [4 x i64] }, ptr %t81
  %t92 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t90, ptr %t92
  store ptr %t92, ptr %l8, !tbaa !29
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l8, !tbaa !29
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_241a90e95a4894c9_a3a560eaba438c2d)
  unreachable
bb18:
  %t96 = load ptr, ptr %l8, !tbaa !29
  store ptr %t96, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l4 = alloca %"compiler/check:signMag"
  %l9 = alloca %"compiler/check:signMag"
  %l16 = alloca %"compiler/check:signMag"
  %l20 = alloca %"compiler/check:signMag"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/check:signMag"
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 6
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t4 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 7
  %t5 = load i1, ptr %t4, !tbaa !21
  %t6 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 8
  %t7 = load i128, ptr %t6
  %t10 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s1, i1 %t5, i128 %t7)
  store %"compiler/check:signMag" %t10, ptr %l4
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load %"compiler/check:signMag", ptr %l4
  store %"compiler/check:signMag" %t11, ptr %rv
  br label %ret
bb4:
  %t12 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 2
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t19 = zext i64 %t16 to i128
  %t21 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s2, i1 false, i128 %t19)
  store %"compiler/check:signMag" %t21, ptr %l9
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t22 = load %"compiler/check:signMag", ptr %l9
  store %"compiler/check:signMag" %t22, ptr %rv
  br label %ret
bb8:
  %t23 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = icmp slt i64 %t24, 0
  br i1 %t26, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = sub i64 0, %t29
  %t34 = zext i64 %t32 to i128
  %t36 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s3, i1 true, i128 %t34)
  store %"compiler/check:signMag" %t36, ptr %l16
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t37 = load %"compiler/check:signMag", ptr %l16
  store %"compiler/check:signMag" %t37, ptr %rv
  br label %ret
bb12:
  %t38 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = zext i64 %t39 to i128
  %t44 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s0, i1 false, i128 %t42)
  store %"compiler/check:signMag" %t44, ptr %l20
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load %"compiler/check:signMag", ptr %l20
  store %"compiler/check:signMag" %t45, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:signMag", ptr %rv
  ret %"compiler/check:signMag" %rr
}

define dso_local ptr @compiler_2fcheck_2etempUnder(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  br label %bb18
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 3
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2etempUnder(ptr %v0, ptr %v1, ptr %t34)
  store ptr %t36, ptr %l19
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l19, !tbaa !29
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store ptr null, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_74af738f4d64f689_e986ed633af561bd)
  unreachable
bb18:
  %t38 = load ptr, ptr %l3, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2etryExisting(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i1
  %l19 = alloca i1
  %l29 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Try", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Try", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_fa22773c0ed7d28e_9744d977b6aff1d2)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Try", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t20)
  store i1 %t22, ptr %l19
  br label %bb6
bb6:
  %t23 = load i1, ptr %l19, !tbaa !21
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Try", ptr %t26, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t35 = load i64, ptr %l2, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  br label %bb26
bb13:
  br label %bb14
bb14:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t43, ptr %l29, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 %t44
  %t49 = load ptr, ptr %t48, !tbaa !39
  %t53 = getelementptr %"compiler/typed:Clause", ptr %t49, i32 0, i32 4
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t68, ptr %l40, !tbaa !27
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t78 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t74)
  store i1 %t78, ptr %l44
  br label %bb19
bb19:
  %t79 = load i1, ptr %l44, !tbaa !21
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb15
bb24:
  br label %bb25
bb25:
  %t85 = load i64, ptr %l2, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l2, !tbaa !24
  br label %bb11
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_3aContractAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, { i64, ptr } %a9) #0 {
entry:
  %l30 = alloca %"compiler/check:ContractAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t21 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 0
  store i64 %a0, ptr %t21, !tbaa !24
  %t23 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 1
  store i64 %a1, ptr %t23, !tbaa !24
  %t25 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 2
  store %"compiler/source:Span" %a2, ptr %t25
  %t27 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 3
  store i64 %a3, ptr %t27, !tbaa !24
  %t29 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 4
  store %"compiler/source:Span" %a4, ptr %t29
  %t31 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 5
  store { i64, ptr } %a5, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 6
  store { i64, ptr } %a6, ptr %t33, !tbaa !27
  %t35 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 7
  store { i64, [3 x i64] } %a7, ptr %t35
  %t37 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 8
  store { i64, ptr } %a8, ptr %t37, !tbaa !27
  %t39 = getelementptr %"compiler/check:ContractAsk", ptr %l30, i32 0, i32 9
  store { i64, ptr } %a9, ptr %t39, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l30, i64 136, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4) #0 {
entry:
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:litv" undef, i1 %a0, 0
  %t14 = insertvalue %"compiler/check:litv" %t12, i1 %a1, 1
  %t16 = insertvalue %"compiler/check:litv" %t14, i1 %a2, 2
  %t18 = insertvalue %"compiler/check:litv" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/check:litv" %t18, double %a4, 4
  %t22 = insertvalue %"compiler/check:litv" %t20, i1 false, 5
  %t24 = insertvalue %"compiler/check:litv" %t22, i1 false, 6
  %t26 = insertvalue %"compiler/check:litv" %t24, i1 false, 7
  %t28 = insertvalue %"compiler/check:litv" %t26, i128 0, 8
  store %"compiler/check:litv" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
@.d0 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"OLANG_HANDLES" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H7f6fc75342dba0a5a8ac6e31960b7ffa(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d3 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d10 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/generic:Context"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 160, i1 false)
  %t2 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  %t4 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  %t6 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %t6
  %t7 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t11 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_bang_failed_plain(ptr) cold noreturn
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d11 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"NoReturn" }>, align 8
@.d12 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Exported" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Extern" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d14 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"'==' between null and a value" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'=='" }>, align 8
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d18 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"'==' on an array or enum whose parts declare Eq (E10a)" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Has" }>, align 8
@.d20 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'in'" }>, align 8
@.d21 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Contains" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Has" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'in'" }>, align 8
@.d24 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'x in c'" }>, align 8
@.d25 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" ('in')" }>, align 8
@.d26 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a copy" }>, align 8
@.d27 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"try" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Name" }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d32 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Max" }>, align 8
@.d36 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d38 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Name" }>, align 8
@.d40 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"HasDefault" }>, align 8
@.d41 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Offset" }>, align 8
@.d42 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"BitOffset" }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d45 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"HasAttr" }>, align 8
@.d46 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a statement of this kind" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
define internal i1 @olang_lambda_51(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = icmp slt i64 %a0, %a1
  store i1 %t5, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d52 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d56 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d58 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a compound assignment to what has no operator method (E31)" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d63 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"NoReturn" }>, align 8
@.d64 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Exported" }>, align 8
@.d65 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Extern" }>, align 8
@.d66 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Commutes" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRecordCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattempt(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnset(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleLandings(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleHeldWalks(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleIdle(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnread(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFacts(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleInPlace(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsUndecided(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlaceUndecided(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFixed(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleDropOrder(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyEffects(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderGlobals(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleAllViews(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutStorage(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandleReport(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereset(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawned(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawnedResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eNewAnyTable(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteAnyMethod(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/diagmsg:Msg" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H0986089bcad3c266fbd2f46fa03b07d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emessage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_3aAssertAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, i1 %a9, { i64, ptr } %a10, { i64, ptr } %a11)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aAssertAsk_3e_2ePush_Hbdaad063a73077b3b5842d615b8c1d82(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_3bfc508877dabbdc_ae4b6eee9a4b2328 = external constant [0 x i8]
@olang_loc_37018c2ebf0da22a_371c8892c4c63a5e = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4153f13b2b5ba70f_539dcb5badf9f963 = external constant [0 x i8]
declare %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuilderOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderVisible(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3)
@olang_loc_82b0d2a61edf3c68_78216e4ccea776dc = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnerBinding(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_e54de2b85f89ec55_546f3093ddc3c1a9 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderNotValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_687718fa9f832d83_eed198ed3faef857 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrPinned(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunpin(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtLast(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtMatchBlock(ptr %v0)
@olang_loc_45128824b39ec212_7869548692a04306 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCaseTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, ptr %a4)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwind(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLast_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
@olang_loc_f3fef639868d2bb5_dd9676d0e98a8921 = external constant [0 x i8]
declare { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2ePop_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
@olang_loc_df1f5fd28061949_6fd2bc487e6b648d = external constant [0 x i8]
@olang_loc_adf1079d57e55808_9269da6a723799fc = external constant [0 x i8]
@olang_loc_4fa1eeadbabe5a66_3dfbfb89ab758d6a = external constant [0 x i8]
@olang_loc_92a21335b7ae999a_7e07c1814bb2a646 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLas_H41327bbfea6c01118b477d23a6e2def2(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_abe1ff4556bedc08_80ba96099639cb2c = external constant [0 x i8]
declare { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePop_H59a749d10c64cd066029408cbe89e7b7(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLast_He310b7451e653469b2155498b3293ff7(ptr %v0, ptr %a0)
@olang_loc_7a4929889a701fe3_96d6f303ecd0d8a7 = external constant [0 x i8]
declare { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2ePop__He4c3571ab54dd9fc34e0d36cd7afb0ff(ptr %v0, ptr %a0)
@olang_loc_b4897252f2a0467_e1365b27726b9d63 = external constant [0 x i8]
@olang_loc_b02f2e0c8b90d83e_466afc0716e3b9a2 = external constant [0 x i8]
@olang_loc_e882b6948f69dce8_e6367676615923ec = external constant [0 x i8]
@olang_loc_9e6114e2cf841093_fa90ce222875bd2f = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLast_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_c349e4c9332250dd_9daf9d91ff07ef41 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_90c216d2a7707e63_13ebc04feeb9a31f = external constant [0 x i8]
@olang_loc_e7cf760e54914750_8299ab19ca729e9c = external constant [0 x i8]
@olang_loc_2de9afb4b96dcf94_71a46e56f9644858 = external constant [0 x i8]
@olang_loc_6d051d6c732886d2_d9cb433bcdc0e6 = external constant [0 x i8]
@olang_loc_fd3792a3478c708a_bd2f712e645466e6 = external constant [0 x i8]
@olang_loc_12b3dc107423b434_482fbf8ad69d32f8 = external constant [0 x i8]
@olang_loc_4090f31281295d0b_b76133cd00d27c97 = external constant [0 x i8]
@olang_loc_ee572ef2923bf685_6f413c271381cde1 = external constant [0 x i8]
@olang_loc_ff67d74e2821509e_7f8039e3a9b6d64a = external constant [0 x i8]
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i1 %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bdeebae2e62e4381_d7e2b33750a898f5 = external constant [0 x i8]
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflInt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItem(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2, i64 %a3)
@olang_loc_b90f60f44557575f_8372487000419b6b = external constant [0 x i8]
@olang_loc_721d232fa5d325a7_d23ce00c5b55667b = external constant [0 x i8]
@olang_loc_ab50fa771a5bafc6_239e772f46bf41fa = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFuncTag(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUntagged(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextBeside(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeqMethod(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1c2cb6c96b4eaee8_c1b953befa7e1dc = external constant [0 x i8]
@olang_loc_7ec9c6dbabf95ed5_e8695782fec42ca9 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_bc0d2701821819b6_446831e810be806a = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsHaveEq(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_4c666a7bbf559bd5_ecdbfd16c5e8809 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %a0)
@olang_loc_2bda502508e1b1d_a3083ba563ab0481 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeFor(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolled(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInNeedsTry(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInTryNothing(ptr %v0)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i1 %a3, { i64, ptr } %a4, ptr %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eisLit(ptr %v0, ptr %a0)
@olang_loc_317381e6e3d2ca51_b8977c113f1a9cfd = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_ab1100555885b989_2cac6a0e3d43e9fd = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTaskClauseLoopJump(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAssertMsgLoopJump(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDeferLoopJump(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBreakOutsideLoop(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInClauseExit(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
@olang_loc_c608509fed4a7aab_41eb2a14c072322f = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeetsBound(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
@G_2ecompiler_2fcheck_2eliteralOrder = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esayUncovered(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, i1 %a5)
@olang_loc_3cc47694b244d9ce_439392ee5cdf31e2 = external constant [0 x i8]
declare %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, ptr %a4)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMembershipNoMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/diagmsg:Msg" %a4)
@olang_loc_1fa90a145069ae20_a62c963c9e2d6294 = external constant [0 x i8]
@olang_loc_e5386246bf71864d_e9422de20f0d1fa1 = external constant [0 x i8]
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueArg(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueNeedsCopy(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBare(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteGenericNeeds(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
declare ptr @compiler_2fcheck_2eunwrapped(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteDeclareWritable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_b30cbbdf82dda0cf_ca6a4a064596874b = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTryNothingFails(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e50f118683988667_19bbe448830cf623 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseFields(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, i64 %a2, ptr %a3)
declare { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyField(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3, i1 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2eplainPlace(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_225fd1ebbf6099f3_3ca87289db5537 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflName(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervText(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflKind(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fcheck_2eRvCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeKindType(ptr %v0, ptr %a0)
declare %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervInt(ptr %v0, i64 %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2ervBool(ptr %v0, i1 %a0)
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldOffset(ptr %v0, ptr %a0, %"compiler/generic:Desc" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldBits(ptr %v0, ptr %a0, %"compiler/generic:Desc" %a1, i1 %a2)
declare { ptr, { i64, ptr }, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrCallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattrFound(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { { i64, ptr }, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstType(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H77423593ceb02e5da917ccb6013316ec(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRoReturned = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_57dc1f8c088d198a_6c44e525bc3c6ade = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyStored(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyDecl(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyReturned(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyGlobal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_658c1f9b991d3291_83ad80e13fec4285 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_19fb235390dd08bf_74b3a6d5c5264653 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarDecl(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emulti(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryStore(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edoFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereturnStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebecomeStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eyieldStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectCond(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraise(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeferStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoinStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_97a078c1fd6401ad_6b439c1864d584b1 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3, %"compiler/source:Span" %a4, i1 %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetDecls(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i1 %a3, i1 %a4, ptr %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBind_26_3e_2ePush_3ccompiler_2ftyped_3aBind_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHoleUntyped(ptr %v0)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hda627d7755eecb5b938ca977110d67b2(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.ee791c76fa337c2e45b252e8964cf3ed" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20I6_Hd1b8e91149b724287340e79c8c928444(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholeFits(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H88f30ae03b1b7707751e39c47edff247(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypedHole(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %a0)
declare { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H943a9bb03970f71acf57214091669a7d(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H2c4b9eb360b9a0ada2008890a467b28d(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i32 @compiler_2fcheck_2ecompoundOp(i32 %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWriteThroughAtOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_dcc186c1d376e3fb_9ec0343880193f07 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatternType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_3377d0df2c72c56f_fd113dcd8b508953 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoZeroNonNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullableArray(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_39114b2b59f3c1de_f97787d703923df2 = external constant [0 x i8]
@olang_loc_bfa34a8929429713_51639094391671e7 = external constant [0 x i8]
@olang_loc_37a2617a6fdca52f_9113ce984ee2ba6b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_cffeba9c7beed71d_692ce8f7e2902011 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, { i64, ptr } %a4, i1 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseZero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2ereaches(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ehasName(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2echainNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_bae3cd237d905c4d_ccae9f7ce38212b9 = external constant [0 x i8]
@olang_loc_69063e233c23bbc5_4e0c3b9f00520e59 = external constant [0 x i8]
@olang_loc_94831dcf6c50df99_e0fe015107062615 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@olang_loc_eb3e4e8f3f96f0ec_5bc3fc9686c42b70 = external constant [0 x i8]
@olang_loc_bad8a01556e87002_6e42cd1773855696 = external constant [0 x i8]
@olang_loc_29f8057051902f50_e91b4d9ed5822c7c = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
@olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a = external constant [0 x i8]
@olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf = external constant [0 x i8]
@olang_loc_5df9bd969218a728_7fa184e5bc45956c = external constant [0 x i8]
@olang_loc_69c4f09cb804b315_a031ca4d3ae928f9 = external constant [0 x i8]
@olang_loc_81e6157a61b9a5f1_a0e5ca59452f2055 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eplainIndexes(ptr %v0, { i64, ptr } %a0)
@olang_loc_5e0248e79c45fbe7_9eea68ca563d9803 = external constant [0 x i8]
@olang_loc_241a90e95a4894c9_a3a560eaba438c2d = external constant [0 x i8]
declare %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %v0, i1 %a0, i128 %a1)
@olang_loc_74af738f4d64f689_e986ed633af561bd = external constant [0 x i8]
@olang_loc_fa22773c0ed7d28e_9744d977b6aff1d2 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
