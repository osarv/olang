; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1, { i64, ptr } }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:fieldSet" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/check:factsCopy" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:factsMark" = type { i64, i64, i64 }
%"compiler/check:factRead" = type { i64, { i64, ptr }, i1, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:ownerAt" = type { i32, i1 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:payloadItem" = type { i32, ptr }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/check:roArg" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.b139c4f75a6545712256427180a82a06" = type { %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" }
%"compiler/check:roDeepArg" = type { i64, ptr, i64, i64 }
%"compiler/check:elemsShape" = type { { i64, ptr }, i64 }
%"compiler/check:seqOf" = type { i32, i64, i64, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" = type { { ptr, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/check:TopAssertAsk" = type { i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/check:altsCovered" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1 }
%"compiler/check:landing" = type { i64, i64, %"compiler/source:Span", i32, i64 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
define dso_local i1 @compiler_2fcheck_2ecompares(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t3 = trunc i64 93 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t8 = trunc i64 94 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t14 = trunc i64 96 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t20 = trunc i64 97 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t26 = trunc i64 98 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0, !range !{i32 0, i32 113}
  %t32 = trunc i64 99 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %lp3 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l25 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 7
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 16
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l10
  br label %bb3
bb3:
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = icmp sgt i64 %t13, 0
  store i1 %t14, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t17, i32 %t18)
  store { i64, ptr } %t21, ptr %l14
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 7
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t23, i64 -1, i64 %t27, i32 %t28, i32 0)
  store ptr %t32, ptr %l19
  br label %bb9
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 5
  %t36 = load i1, ptr %t35, !tbaa !21
  store i1 %t36, ptr %l2, !tbaa !21
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 5
  store i1 true, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t41, i32 %t42)
  store { i64, ptr } %t45, ptr %l25
  br label %bb10
bb10:
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t46, ptr %lp3
  %t47 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t48 = load ptr, ptr %lp3
  store { i64, ptr } %t47, ptr %t48, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i1, ptr %l2, !tbaa !21
  %t53 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 5
  store i1 %t50, ptr %t53, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t54)
  br label %bb11
bb11:
  %t56 = load ptr, ptr %lp3
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/generic:AnySlot"
  %l25 = alloca i32
  %l30 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l48 = alloca %"compiler/diagmsg:Msg"
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca ptr
  %l61 = alloca i32
  %l66 = alloca i32
  %l70 = alloca { i64, ptr }
  %l76 = alloca i64
  %l79 = alloca i64
  %l97 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l114 = alloca i1
  %l115 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l135 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l137 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l140 = alloca i32
  %l143 = alloca { i64, ptr }
  %l147 = alloca ptr
  %l149 = alloca ptr
  %l150 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l163 = alloca i64
  %l166 = alloca i1
  %l169 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca %"compiler/source:Span"
  %l174 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l180 = alloca %"compiler/diagmsg:Msg"
  %l181 = alloca i64
  %l186 = alloca ptr
  %l189 = alloca ptr
  %l190 = alloca %"compiler/source:Span"
  %l191 = alloca %"compiler/source:Span"
  %l192 = alloca i64
  %l194 = alloca ptr
  %l195 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l203 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l207 = alloca %"compiler/msgs:Nearest"
  %l216 = alloca { i64, ptr }
  %l219 = alloca ptr
  %l222 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l226 = alloca %"compiler/source:Span"
  %l229 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l238 = alloca %"compiler/diagmsg:Msg"
  %l239 = alloca i64
  %l244 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  %t267 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1)
  store i32 %t4, ptr %l25
  br label %bb1
bb1:
  %t5 = load i32, ptr %l25, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l7, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l30
  br label %bb2
bb2:
  %t16 = load i1, ptr %l30, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l31, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t18)
  store %"compiler/source:Span" %t20, ptr %l33
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l34, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t22)
  store %"compiler/source:Span" %t24, ptr %l36
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l34, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l36
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t25, %"compiler/source:Span" %t26)
  store { i64, ptr } %t27, ptr %l37
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l7, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l40
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l41, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l42, !tbaa !29
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t41)
  store %"compiler/source:Span" %t43, ptr %l44
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l42, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l44
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t44, %"compiler/source:Span" %t45)
  store { i64, ptr } %t46, ptr %l45
  br label %bb10
bb10:
  %t47 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t48 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s1, { i64, ptr } %t47)
  store { i64, ptr } %t48, ptr %l46
  br label %bb11
bb11:
  %t49 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t59 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t56, { i64, ptr } %t57, { i64, ptr } %t55)
  store %"compiler/diagmsg:Msg" %t59, ptr %l48
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l31, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l33
  %t62 = load %"compiler/diagmsg:Msg", ptr %l48
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t60, %"compiler/source:Span" %t61, %"compiler/diagmsg:Msg" %t62)
  store i64 %t63, ptr %l49
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l50, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l51
  %t66 = load ptr, ptr %l3, !tbaa !29
  store ptr %t66, ptr %l52, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l7, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l57
  br label %bb14
bb14:
  %t77 = load ptr, ptr %l50, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l51
  %t79 = load ptr, ptr %l52, !tbaa !29
  %t80 = load i32, ptr %l57, !tbaa !23
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v2, ptr %v0, ptr %t77, %"compiler/source:Span" %t78, ptr %t79, i32 %t80)
  store ptr %t81, ptr %l58
  br label %bb15
bb15:
  %t82 = load ptr, ptr %l58, !tbaa !29
  store ptr %t82, ptr %l3, !tbaa !29
  %t83 = load ptr, ptr %l3, !tbaa !29
  %t86 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t83)
  store i32 %t86, ptr %l61
  br label %bb16
bb16:
  %t87 = load i32, ptr %l61, !tbaa !23
  store i32 %t87, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l7, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l66
  br label %bb18
bb18:
  %t98 = load i32, ptr %l66, !tbaa !23
  store i32 %t98, ptr %l8, !tbaa !23
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i32, ptr %l8, !tbaa !23
  %t106 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t102, i32 %t103)
  store { i64, ptr } %t106, ptr %l70
  br label %bb19
bb19:
  %t107 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t107, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = icmp sgt i64 %t112, %t113
  br i1 %t116, label %bb20, label %bb21
bb20:
  %t118 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp sgt i64 %t118, 0
  br i1 %t120, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb25
bb22:
  %t122 = load i64, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = sub i64 %t122, %t123
  %t127 = load i64, ptr %l12, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t132 = sub i64 %t130, 1
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = sdiv i64 %t132, %t133
  store i64 %t136, ptr %l79, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb24
bb24:
  %t138 = load i64, ptr %l79, !tbaa !24
  store i64 %t138, ptr %l76, !tbaa !24
  br label %bb25
bb25:
  %t139 = load i64, ptr %l76, !tbaa !24
  store i64 %t139, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb26
bb26:
  %t140 = load i64, ptr %l14, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = icmp slt i64 %t140, %t141
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb27, label %bb28
bb27:
  br label %bb55
bb28:
  br label %bb29
bb29:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t150 = load i64, ptr %l12, !tbaa !24
  %t153 = mul i64 %t149, %t150
  %t156 = add i64 %t148, %t153
  store i64 %t156, ptr %l15, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t158, ptr %l97, !tbaa !27
  %t159 = load i64, ptr %l15, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr %"compiler/generic:AnySlot", ptr %t162, i64 %t159
  %t164 = getelementptr %"compiler/generic:AnySlot", ptr %t163, i32 0, i32 0
  %t165 = load i32, ptr %t164, !tbaa !23
  %t166 = load i32, ptr %l4, !tbaa !23
  %t169 = icmp ne i32 %t165, %t166
  br i1 %t169, label %bb30, label %bb31
bb30:
  br label %bb54
bb31:
  br label %bb32
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l8, !tbaa !23
  %t173 = load i64, ptr %l15, !tbaa !24
  %t174 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %t171, i32 %t172, i64 %t173, %"compiler/source:Span" %t174)
  br label %bb33
bb33:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t180, ptr %l107, !tbaa !27
  %t181 = load i64, ptr %l15, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr %"compiler/generic:AnySlot", ptr %t184, i64 %t181
  %t186 = load %"compiler/generic:AnySlot", ptr %t185
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v0, ptr %t179, %"compiler/generic:AnySlot" %t186)
  store ptr %t189, ptr %l110
  br label %bb34
bb34:
  %t190 = load ptr, ptr %l110, !tbaa !29
  store ptr %t190, ptr %l16, !tbaa !29
  %t191 = load ptr, ptr %l16, !tbaa !29
  %t193 = icmp eq ptr %t191, null
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb35, label %bb36
bb35:
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t197, ptr %l115, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 1
  %t200 = call ptr @__olang_scope_of(ptr %t199, ptr null)
  %t201 = ptrtoint ptr %t200 to i64
  %t203 = inttoptr i64 %t201 to ptr
  %t204 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t205 = call i1 @compiler_2fcheck_2ehasNamed(ptr %t203, { i64, ptr } %t204)
  store i1 %t205, ptr %l117
  br label %bb37
bb36:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb38
bb37:
  %t206 = load i1, ptr %l117, !tbaa !21
  store i1 %t206, ptr %l114, !tbaa !21
  br label %bb38
bb38:
  %t207 = load i1, ptr %l114, !tbaa !21
  br i1 %t207, label %bb39, label %bb40
bb39:
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l118, !tbaa !29
  %t209 = load ptr, ptr %l16, !tbaa !29
  %t211 = getelementptr %"compiler/ast:Func", ptr %t209, i32 0, i32 3
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/ast:Sig", ptr %t212, i32 0, i32 0
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l121, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t216, ptr %l122, !tbaa !27
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l4, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t217, i32 %t218)
  store { i64, ptr } %t221, ptr %l125
  br label %bb41
bb40:
  br label %bb48
bb41:
  %t222 = load ptr, ptr %l118, !tbaa !29
  %t223 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t226 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v0, ptr %v3, ptr %v0, ptr %v0, ptr %t222, { i64, ptr } %t223, { i64, ptr } %t224, { i64, ptr } %t225)
  store { i64, ptr } %t226, ptr %l126
  br label %bb42
bb42:
  %t227 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t227, ptr %l6, !tbaa !27
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 146
  %t231 = load i1, ptr %t230, !tbaa !21
  br i1 %t231, label %bb43, label %bb44
bb43:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 146
  store i1 false, ptr %t235, !tbaa !21
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v0, ptr %t236, { i64, ptr } %t237)
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l1
  %t244 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t240, %"compiler/source:Span" %t241)
  store ptr %t244, ptr %l134
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t245 = load ptr, ptr %l134, !tbaa !29
  store ptr %t245, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l135, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t247, ptr %l136
  %t248 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t248, ptr %l137
  %t249 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t249, ptr %l138, !tbaa !27
  %t250 = load i64, ptr %l15, !tbaa !24
  %t252 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr %"compiler/generic:AnySlot", ptr %t253, i64 %t250
  %t255 = getelementptr %"compiler/generic:AnySlot", ptr %t254, i32 0, i32 5
  %t256 = load i32, ptr %t255, !tbaa !23
  store i32 %t256, ptr %l140, !tbaa !23
  %t257 = load i32, ptr %l8, !tbaa !23
  %t258 = load i64, ptr %l15, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t259, ptr %l143, !tbaa !27
  %t260 = load i64, ptr %l15, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr %"compiler/generic:AnySlot", ptr %t263, i64 %t260
  %t265 = getelementptr %"compiler/generic:AnySlot", ptr %t264, i32 0, i32 5
  %t266 = load i32, ptr %t265, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t267
  %t268 = getelementptr { i64, [3 x i64] }, ptr %t267, i32 0, i32 0
  store i64 3, ptr %t268
  %t270 = insertvalue { i32, i64, i32 } undef, i32 %t257, 0
  %t272 = insertvalue { i32, i64, i32 } %t270, i64 %t258, 1
  %t274 = insertvalue { i32, i64, i32 } %t272, i32 %t266, 2
  %t275 = getelementptr { i64, [3 x i64] }, ptr %t267, i32 0, i32 1
  store { i32, i64, i32 } %t274, ptr %t275
  %t276 = load { i64, [3 x i64] }, ptr %t267
  %t278 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store { i64, [3 x i64] } %t276, ptr %t278
  store ptr %t278, ptr %l147, !tbaa !29
  %t279 = load ptr, ptr %l3, !tbaa !29
  store ptr %t279, ptr %l149, !tbaa !29
  %t281 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t281, ptr %l150, !tbaa !27
  %t282 = icmp sge i64 0, 0
  br i1 %t282, label %bb49, label %bb50
bb49:
  %t284 = icmp sle i64 0, 1152921504606846975
  br i1 %t284, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_e1138a3bee8dfd28_1d9c93b07a3bbf3c)
  unreachable
bb51:
  %t286 = mul i64 0, 8
  %t287 = insertvalue { i64, ptr } undef, i64 0, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t289 = load ptr, ptr %l149, !tbaa !29
  %t290 = call ptr @__olang_scope_of(ptr %t289, ptr null)
  %t291 = ptrtoint ptr %t290 to i64
  %t292 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t292, 1
  %t294 = call ptr @__olang_scope_of(ptr %t293, ptr null)
  %t295 = ptrtoint ptr %t294 to i64
  %t297 = inttoptr i64 %t291 to ptr
  %t299 = inttoptr i64 %t295 to ptr
  %t300 = load ptr, ptr %l135, !tbaa !29
  %t301 = load %"compiler/source:Span", ptr %l136
  %t302 = load %"compiler/source:Span", ptr %l137
  %t303 = load i32, ptr %l140, !tbaa !23
  %t304 = load ptr, ptr %l147, !tbaa !29
  %t305 = load ptr, ptr %l149, !tbaa !29
  %t306 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v4, ptr %t297, ptr %t299, ptr %v0, ptr %v4, ptr %t300, %"compiler/source:Span" %t301, %"compiler/source:Span" %t302, i32 %t303, ptr %t304, i64 -1, ptr %t305, { i64, ptr } %t306, { i64, ptr } %t288)
  store ptr %t308, ptr %l156
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_e1138a3bee8dfd28_1d9c93b07a3bbf3c)
  unreachable
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t309 = load ptr, ptr %l156, !tbaa !29
  store ptr %t309, ptr %rv
  br label %ret
bb54:
  %t310 = load i64, ptr %l14, !tbaa !24
  %t312 = add i64 %t310, 1
  store i64 %t312, ptr %l14, !tbaa !24
  br label %bb26
bb55:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/check:Checker", ptr %t314, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t318 = load i32, ptr %l8, !tbaa !23
  %t319 = load i32, ptr %l4, !tbaa !23
  %t323 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyDefault(ptr %v0, ptr %t317, i32 %t318, i32 %t319)
  store i64 %t323, ptr %l163
  br label %bb56
bb56:
  %t324 = load i64, ptr %l163, !tbaa !24
  store i64 %t324, ptr %l17, !tbaa !24
  %t325 = load i64, ptr %l17, !tbaa !24
  %t327 = icmp sge i64 %t325, 0
  br i1 %t327, label %bb57, label %bb58
bb57:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i64, ptr %l17, !tbaa !24
  %t333 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultCopiesRecv(ptr %v0, ptr %t329, i64 %t330)
  store i1 %t333, ptr %l169
  br label %bb59
bb58:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb60
bb59:
  %t334 = load i1, ptr %l169, !tbaa !21
  store i1 %t334, ptr %l166, !tbaa !21
  br label %bb60
bb60:
  %t335 = load i1, ptr %l166, !tbaa !21
  br i1 %t335, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s8
  %t336 = load ptr, ptr %l0, !tbaa !29
  store ptr %t336, ptr %l170, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t337, ptr %l171
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i32, ptr %l4, !tbaa !23
  %t342 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t338, i32 %t339)
  store { i64, ptr } %t342, ptr %l174
  br label %bb63
bb62:
  br label %bb69
bb63:
  %t343 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  %t345 = extractvalue { i64, ptr } %t343, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  store { i64, ptr } %t349, ptr %l175, !tbaa !27
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load i32, ptr %l7, !tbaa !23
  %t354 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t350, i32 %t351)
  store { i64, ptr } %t354, ptr %l178
  br label %bb64
bb64:
  %t355 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t356 = extractvalue { i64, ptr } %t355, 0
  %t357 = extractvalue { i64, ptr } %t355, 1
  %t358 = mul i64 %t356, 1
  %t359 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t358)
  call void @llvm.memcpy.p0.p0.i64(ptr %t359, ptr %t357, i64 %t358, i1 false)
  %t360 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t359, 1
  %t362 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t364 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNoCopy(ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t362, { i64, ptr } %t361)
  store %"compiler/diagmsg:Msg" %t364, ptr %l180
  br label %bb65
bb65:
  %t365 = load ptr, ptr %l170, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l171
  %t367 = load %"compiler/diagmsg:Msg", ptr %l180
  %t368 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t365, %"compiler/source:Span" %t366, %"compiler/diagmsg:Msg" %t367)
  store i64 %t368, ptr %l181
  br label %bb66
bb66:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t369, { i64, ptr } %t370)
  br label %bb67
bb67:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load %"compiler/source:Span", ptr %l1
  %t377 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t373, %"compiler/source:Span" %t374)
  store ptr %t377, ptr %l186
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t378 = load ptr, ptr %l186, !tbaa !29
  store ptr %t378, ptr %rv
  br label %ret
bb69:
  %t379 = load i64, ptr %l17, !tbaa !24
  %t381 = icmp sge i64 %t379, 0
  br i1 %t381, label %bb70, label %bb71
bb70:
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l189, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t384, ptr %l190
  %t385 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t385, ptr %l191
  %t386 = load i64, ptr %l17, !tbaa !24
  store i64 %t386, ptr %l192, !tbaa !24
  %t387 = load ptr, ptr %l3, !tbaa !29
  store ptr %t387, ptr %l194, !tbaa !29
  %t389 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t389, ptr %l195, !tbaa !27
  %t390 = icmp sge i64 0, 0
  br i1 %t390, label %bb72, label %bb73
bb71:
  br label %bb81
bb72:
  %t392 = icmp sle i64 0, 1152921504606846975
  br i1 %t392, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @olang_loc_ecdebd42147a0915_28ece6113815da89)
  unreachable
bb74:
  %t394 = mul i64 0, 8
  %t395 = insertvalue { i64, ptr } undef, i64 0, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t396, ptr %l198, !tbaa !27
  %t397 = icmp sge i64 0, 0
  br i1 %t397, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_ecdebd42147a0915_28ece6113815da89)
  unreachable
bb76:
  %t399 = icmp sle i64 0, 2305843009213693951
  br i1 %t399, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_b35cdd4155941ff6_f61ebbb89c67ebca)
  unreachable
bb78:
  %t401 = mul i64 0, 4
  %t402 = insertvalue { i64, ptr } undef, i64 0, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t404 = load ptr, ptr %l194, !tbaa !29
  %t405 = call ptr @__olang_scope_of(ptr %t404, ptr null)
  %t406 = ptrtoint ptr %t405 to i64
  %t408 = inttoptr i64 %t406 to ptr
  %t409 = load ptr, ptr %l189, !tbaa !29
  %t410 = load %"compiler/source:Span", ptr %l190
  %t411 = load %"compiler/source:Span", ptr %l191
  %t412 = load i64, ptr %l192, !tbaa !24
  %t413 = load ptr, ptr %l194, !tbaa !29
  %t414 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t415 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t417 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %t408, ptr %v3, ptr %v0, ptr %v4, ptr %v4, ptr %t409, %"compiler/source:Span" %t410, %"compiler/source:Span" %t411, i64 %t412, ptr %t413, { i64, ptr } %t414, { i64, ptr } %t415, { i64, ptr } %t403)
  store ptr %t417, ptr %l203
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_b35cdd4155941ff6_f61ebbb89c67ebca)
  unreachable
bb80:
  call void @__olang_scope_close(ptr %s0)
  %t418 = load ptr, ptr %l203, !tbaa !29
  store ptr %t418, ptr %rv
  br label %ret
bb81:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load i32, ptr %l4, !tbaa !23
  %t423 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t419, i32 %t420)
  store { i64, ptr } %t423, ptr %l206
  br label %bb82
bb82:
  %t424 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t425 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t424)
  store %"compiler/msgs:Nearest" %t425, ptr %l207
  br label %bb83
bb83:
  %t426 = load %"compiler/msgs:Nearest", ptr %l207
  %t427 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t426, ptr %t427
  store ptr %t427, ptr %l18, !tbaa !29
  %t429 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t429, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t431 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t431, 0
  store i64 %t433, ptr %l21, !tbaa !24
  br label %bb84
bb84:
  %t435 = load i64, ptr %l20, !tbaa !24
  %t436 = load i64, ptr %l21, !tbaa !24
  %t439 = icmp slt i64 %t435, %t436
  %t441 = xor i1 %t439, true
  br i1 %t441, label %bb85, label %bb86
bb85:
  br label %bb91
bb86:
  br label %bb87
bb87:
  %t443 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t443, ptr %l216, !tbaa !27
  %t444 = load i64, ptr %l20, !tbaa !24
  %t446 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr %"compiler/generic:AnySlot", ptr %t447, i64 %t444
  %t449 = load %"compiler/generic:AnySlot", ptr %t448
  store %"compiler/generic:AnySlot" %t449, ptr %l22
  %t451 = load ptr, ptr %l18, !tbaa !29
  store ptr %t451, ptr %l219, !tbaa !29
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/generic:AnySlot", ptr %l22, i32 0, i32 0
  %t454 = load i32, ptr %t453, !tbaa !23
  %t457 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t452, i32 %t454)
  store { i64, ptr } %t457, ptr %l222
  br label %bb88
bb88:
  %t458 = load ptr, ptr %l219, !tbaa !29
  %t459 = load { i64, ptr }, ptr %l222, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t458, { i64, ptr } %t459)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t460 = load i64, ptr %l20, !tbaa !24
  %t462 = add i64 %t460, 1
  store i64 %t462, ptr %l20, !tbaa !24
  br label %bb84
bb91:
  %t464 = load ptr, ptr %l0, !tbaa !29
  store ptr %t464, ptr %l225, !tbaa !29
  %t465 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t465, ptr %l226
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load i32, ptr %l7, !tbaa !23
  %t470 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t466, i32 %t467)
  store { i64, ptr } %t470, ptr %l229
  br label %bb92
bb92:
  %t471 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t471, 0
  %t473 = extractvalue { i64, ptr } %t471, 1
  %t474 = mul i64 %t472, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t474)
  call void @llvm.memcpy.p0.p0.i64(ptr %t475, ptr %t473, i64 %t474, i1 false)
  %t476 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  store { i64, ptr } %t477, ptr %l230, !tbaa !27
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load i32, ptr %l4, !tbaa !23
  %t482 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t478, i32 %t479)
  store { i64, ptr } %t482, ptr %l233
  br label %bb93
bb93:
  %t483 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t484 = extractvalue { i64, ptr } %t483, 0
  %t485 = extractvalue { i64, ptr } %t483, 1
  %t486 = mul i64 %t484, 1
  %t487 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t486)
  call void @llvm.memcpy.p0.p0.i64(ptr %t487, ptr %t485, i64 %t486, i1 false)
  %t488 = insertvalue { i64, ptr } undef, i64 %t484, 0
  %t489 = insertvalue { i64, ptr } %t488, ptr %t487, 1
  store { i64, ptr } %t489, ptr %l234, !tbaa !27
  %t490 = load ptr, ptr %l18, !tbaa !29
  %t492 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s0, ptr %s0, ptr %t490)
  store { i64, ptr } %t492, ptr %l236
  br label %bb94
bb94:
  %t493 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t493, 0
  %t495 = extractvalue { i64, ptr } %t493, 1
  %t496 = mul i64 %t494, 1
  %t497 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t496)
  call void @llvm.memcpy.p0.p0.i64(ptr %t497, ptr %t495, i64 %t496, i1 false)
  %t498 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr %t497, 1
  %t500 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t501 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t503 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNoMethod(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t500, { i64, ptr } %t501, { i64, ptr } %t499)
  store %"compiler/diagmsg:Msg" %t503, ptr %l238
  br label %bb95
bb95:
  %t504 = load ptr, ptr %l225, !tbaa !29
  %t505 = load %"compiler/source:Span", ptr %l226
  %t506 = load %"compiler/diagmsg:Msg", ptr %l238
  %t507 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t504, %"compiler/source:Span" %t505, %"compiler/diagmsg:Msg" %t506)
  store i64 %t507, ptr %l239
  br label %bb96
bb96:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t508, { i64, ptr } %t509)
  br label %bb97
bb97:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t513 = load %"compiler/source:Span", ptr %l1
  %t516 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t512, %"compiler/source:Span" %t513)
  store ptr %t516, ptr %l244
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s0)
  %t517 = load ptr, ptr %l244, !tbaa !29
  store ptr %t517, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyTable(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"compiler/generic:AnySlot"
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/generic:AnySlot"
  %l30 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l49 = alloca ptr
  %l53 = alloca i64
  %l57 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca i32
  %l71 = alloca i64
  %l74 = alloca i64
  %l92 = alloca { i64, ptr }
  %l99 = alloca i64
  %l107 = alloca i32
  %l109 = alloca ptr
  %l111 = alloca i64
  %l112 = alloca i64
  %l117 = alloca i32
  %l124 = alloca i32
  %l128 = alloca i1
  %l132 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l148 = alloca %"compiler/diagmsg:Msg"
  %l149 = alloca i64
  %l152 = alloca ptr
  %l153 = alloca i64
  %l154 = alloca i64
  %l157 = alloca { i64, ptr }
  %l159 = alloca %"compiler/diagmsg:Msg"
  %l170 = alloca ptr
  %l172 = alloca ptr
  %l180 = alloca i64
  %l183 = alloca i64
  %l201 = alloca { i64, ptr }
  %l206 = alloca ptr
  %l211 = alloca i32
  %l212 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l218 = alloca i64
  %l221 = alloca ptr
  %l222 = alloca i32
  %l228 = alloca i32
  %l229 = alloca i32
  %l231 = alloca ptr
  %l239 = alloca i64
  %l242 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i64
  %t446 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  %t10 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableOf(ptr %v0, ptr %t4, i32 %t5, i32 %t6)
  store i64 %t10, ptr %l35
  br label %bb1
bb1:
  %t11 = load i64, ptr %l35, !tbaa !24
  store i64 %t11, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 139
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l41
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t23 = load i1, ptr %l41, !tbaa !21
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i64 -1, ptr %l42, !tbaa !24
  br label %bb7
bb6:
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l42, !tbaa !24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i64, ptr %l42, !tbaa !24
  store i64 %t26, ptr %rv
  br label %ret
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l45, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  store i32 %t31, ptr %l46, !tbaa !23
  %t32 = load i32, ptr %l2, !tbaa !23
  store i32 %t32, ptr %l47, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t33)
  store ptr %t35, ptr %l49
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l49, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 2
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = load %"compiler/source:Span", ptr %l3
  %t41 = load ptr, ptr %l45, !tbaa !29
  %t42 = load i32, ptr %l46, !tbaa !23
  %t43 = load i32, ptr %l47, !tbaa !23
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eNewAnyTable(ptr %v0, ptr %t41, i32 %t42, i32 %t43, i64 %t39, %"compiler/source:Span" %t40)
  store i64 %t46, ptr %l53
  br label %bb10
bb10:
  %t47 = load i64, ptr %l53, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t51, i32 %t52)
  store { i64, ptr } %t55, ptr %l57
  br label %bb11
bb11:
  %t56 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  store ptr %t60, ptr %l59, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %l1, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l64
  br label %bb12
bb12:
  %t71 = load ptr, ptr %l59, !tbaa !29
  %t72 = load i32, ptr %l64, !tbaa !23
  %t73 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t73, ptr %l65
  br label %bb13
bb13:
  %t74 = load i32, ptr %l65, !tbaa !23
  store i32 %t74, ptr %l7, !tbaa !23
  store i64 0, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = icmp sgt i64 %t79, %t80
  br i1 %t83, label %bb14, label %bb15
bb14:
  %t85 = load i64, ptr %l10, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb19
bb16:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = sub i64 %t89, %t90
  %t94 = load i64, ptr %l10, !tbaa !24
  %t97 = add i64 %t93, %t94
  %t99 = sub i64 %t97, 1
  %t100 = load i64, ptr %l10, !tbaa !24
  %t103 = sdiv i64 %t99, %t100
  store i64 %t103, ptr %l74, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb18
bb18:
  %t105 = load i64, ptr %l74, !tbaa !24
  store i64 %t105, ptr %l71, !tbaa !24
  br label %bb19
bb19:
  %t106 = load i64, ptr %l71, !tbaa !24
  store i64 %t106, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb20
bb20:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb21, label %bb22
bb21:
  br label %bb59
bb22:
  br label %bb23
bb23:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l10, !tbaa !24
  %t120 = mul i64 %t116, %t117
  %t123 = add i64 %t115, %t120
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t125, ptr %l92, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/generic:AnySlot", ptr %t129, i64 %t123
  %t131 = load %"compiler/generic:AnySlot", ptr %t130
  store %"compiler/generic:AnySlot" %t131, ptr %l14
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load i32, ptr %l1, !tbaa !23
  %t138 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t139 = load i32, ptr %t138, !tbaa !23
  %t143 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t136, i32 %t137, i32 %t139)
  store i64 %t143, ptr %l99
  br label %bb24
bb24:
  %t144 = load i64, ptr %l99, !tbaa !24
  store i64 %t144, ptr %l15, !tbaa !24
  %t145 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t145, ptr %l16, !tbaa !23
  %t147 = load i64, ptr %l15, !tbaa !24
  %t149 = icmp sge i64 %t147, 0
  br i1 %t149, label %bb25, label %bb26
bb25:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i32, ptr %l1, !tbaa !23
  %t160 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t154, i64 %t155, i32 %t156)
  store i32 %t160, ptr %l107
  br label %bb27
bb26:
  %t161 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 3
  %t162 = load i64, ptr %t161, !tbaa !24
  %t164 = icmp sge i64 %t162, 0
  br i1 %t164, label %bb34, label %bb35
bb27:
  %t166 = load i32, ptr %l107, !tbaa !23
  store i32 %t166, ptr %l16, !tbaa !23
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  store ptr %t170, ptr %l109, !tbaa !29
  %t171 = load i64, ptr %l15, !tbaa !24
  %t173 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t171)
  store i64 %t173, ptr %l111
  br label %bb28
bb28:
  %t174 = load ptr, ptr %l109, !tbaa !29
  %t175 = load i64, ptr %l111, !tbaa !24
  %t176 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t174, i64 %t175)
  store i64 %t176, ptr %l112
  br label %bb29
bb29:
  %t177 = load i64, ptr %l112, !tbaa !24
  %t178 = icmp sgt i64 %t177, 0
  br i1 %t178, label %bb30, label %bb31
bb30:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l15, !tbaa !24
  %t182 = load i32, ptr %l1, !tbaa !23
  %t186 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %t180, i64 %t181, i32 %t182)
  store i32 %t186, ptr %l117
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t187 = load i32, ptr %l117, !tbaa !23
  store i32 %t187, ptr %l16, !tbaa !23
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 3
  %t193 = load i64, ptr %t192, !tbaa !24
  %t194 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %t191, i64 %t193, i32 %t194)
  store i32 %t198, ptr %l124
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t199 = load i32, ptr %l124, !tbaa !23
  store i32 %t199, ptr %l16, !tbaa !23
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t200 = load i32, ptr %l16, !tbaa !23
  %t201 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t204 = icmp ne i32 %t200, %t201
  br i1 %t204, label %bb39, label %bb40
bb39:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i32, ptr %l16, !tbaa !23
  %t208 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 5
  %t209 = load i32, ptr %t208, !tbaa !23
  %t213 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %t206, i32 %t207, i32 %t209)
  store i1 %t213, ptr %l132
  br label %bb41
bb40:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb42
bb41:
  %t214 = load i1, ptr %l132, !tbaa !21
  %t215 = xor i1 %t214, true
  store i1 %t215, ptr %l128, !tbaa !21
  br label %bb42
bb42:
  %t217 = load i1, ptr %l128, !tbaa !21
  br i1 %t217, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l134, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t219, ptr %l135
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l1, !tbaa !23
  %t224 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t220, i32 %t221)
  store { i64, ptr } %t224, ptr %l138
  br label %bb45
bb44:
  br label %bb57
bb45:
  %t225 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  %t227 = extractvalue { i64, ptr } %t225, 1
  %t228 = mul i64 %t226, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t229, ptr %t227, i64 %t228, i1 false)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l139, !tbaa !27
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t234 = load i32, ptr %t233, !tbaa !23
  %t237 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t232, i32 %t234)
  store { i64, ptr } %t237, ptr %l142
  br label %bb46
bb46:
  %t238 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 0
  %t240 = extractvalue { i64, ptr } %t238, 1
  %t241 = mul i64 %t239, 1
  %t242 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t241)
  call void @llvm.memcpy.p0.p0.i64(ptr %t242, ptr %t240, i64 %t241, i1 false)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  store { i64, ptr } %t244, ptr %l143, !tbaa !27
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i32, ptr %l2, !tbaa !23
  %t249 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t245, i32 %t246)
  store { i64, ptr } %t249, ptr %l146
  br label %bb47
bb47:
  %t250 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t257 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t260 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %s8, ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t257, { i64, ptr } %t258, { i64, ptr } %t256)
  store %"compiler/diagmsg:Msg" %t260, ptr %l148
  br label %bb48
bb48:
  %t261 = load ptr, ptr %l134, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l135
  %t263 = load %"compiler/diagmsg:Msg", ptr %l148
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t261, %"compiler/source:Span" %t262, %"compiler/diagmsg:Msg" %t263)
  store i64 %t264, ptr %l149
  br label %bb49
bb49:
  %t265 = load i64, ptr %l149, !tbaa !24
  store i64 %t265, ptr %l17, !tbaa !24
  %t266 = load i64, ptr %l15, !tbaa !24
  %t268 = icmp sge i64 %t266, 0
  br i1 %t268, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l152, !tbaa !29
  %t271 = load i64, ptr %l17, !tbaa !24
  store i64 %t271, ptr %l153, !tbaa !24
  %t272 = load i64, ptr %l15, !tbaa !24
  store i64 %t272, ptr %l154, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/generic:AnySlot", ptr %l14, i32 0, i32 0
  %t275 = load i32, ptr %t274, !tbaa !23
  %t278 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t273, i32 %t275)
  store { i64, ptr } %t278, ptr %l157
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t279 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 0
  %t281 = extractvalue { i64, ptr } %t279, 1
  %t282 = mul i64 %t280, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t282)
  call void @llvm.memcpy.p0.p0.i64(ptr %t283, ptr %t281, i64 %t282, i1 false)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  %t287 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteAnyMethod(ptr %s9, ptr %s9, { i64, ptr } %t285)
  store %"compiler/diagmsg:Msg" %t287, ptr %l159
  br label %bb53
bb53:
  %t288 = load ptr, ptr %l152, !tbaa !29
  %t289 = load i64, ptr %l153, !tbaa !24
  %t290 = load i64, ptr %l154, !tbaa !24
  %t291 = load %"compiler/diagmsg:Msg", ptr %l159
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %s9, ptr %t288, i64 %t289, i64 %t290, %"compiler/diagmsg:Msg" %t291)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 139
  %t295 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t294, i64 %t295, i1 true)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t299 = load i64, ptr %l12, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l12, !tbaa !24
  br label %bb20
bb59:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = getelementptr %"compiler/generic:Program", ptr %t306, i32 0, i32 56
  %t309 = load i64, ptr %l5, !tbaa !24
  %t312 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H0986089bcad3c266fbd2f46fa03b07d1(ptr %v0, ptr %v0, ptr %t308, i64 %t309)
  store ptr %t312, ptr %l170
  br label %bb60
bb60:
  %t313 = load ptr, ptr %l170, !tbaa !29
  store ptr %t313, ptr %l18, !tbaa !29
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t314)
  store ptr %t316, ptr %l172
  br label %bb61
bb61:
  %t317 = load ptr, ptr %l172, !tbaa !29
  %t319 = getelementptr %"compiler/check:frame", ptr %t317, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  store i64 %t320, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  %t322 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t322, 0
  store i64 %t324, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t326 = load i64, ptr %l21, !tbaa !24
  %t327 = load i64, ptr %l20, !tbaa !24
  %t330 = icmp sgt i64 %t326, %t327
  br i1 %t330, label %bb62, label %bb63
bb62:
  %t332 = load i64, ptr %l22, !tbaa !24
  %t334 = icmp sgt i64 %t332, 0
  br i1 %t334, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb67
bb64:
  %t336 = load i64, ptr %l21, !tbaa !24
  %t337 = load i64, ptr %l20, !tbaa !24
  %t340 = sub i64 %t336, %t337
  %t341 = load i64, ptr %l22, !tbaa !24
  %t344 = add i64 %t340, %t341
  %t346 = sub i64 %t344, 1
  %t347 = load i64, ptr %l22, !tbaa !24
  %t350 = sdiv i64 %t346, %t347
  store i64 %t350, ptr %l183, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb66
bb66:
  %t352 = load i64, ptr %l183, !tbaa !24
  store i64 %t352, ptr %l180, !tbaa !24
  br label %bb67
bb67:
  %t353 = load i64, ptr %l180, !tbaa !24
  store i64 %t353, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb68
bb68:
  %t354 = load i64, ptr %l24, !tbaa !24
  %t355 = load i64, ptr %l23, !tbaa !24
  %t358 = icmp slt i64 %t354, %t355
  %t360 = xor i1 %t358, true
  br i1 %t360, label %bb69, label %bb70
bb69:
  br label %bb80
bb70:
  br label %bb71
bb71:
  %t362 = load i64, ptr %l20, !tbaa !24
  %t363 = load i64, ptr %l24, !tbaa !24
  %t364 = load i64, ptr %l22, !tbaa !24
  %t367 = mul i64 %t363, %t364
  %t370 = add i64 %t362, %t367
  store i64 %t370, ptr %l25, !tbaa !24
  %t372 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t372, ptr %l201, !tbaa !27
  %t373 = load i64, ptr %l25, !tbaa !24
  %t375 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr %"compiler/generic:AnySlot", ptr %t376, i64 %t373
  %t378 = load %"compiler/generic:AnySlot", ptr %t377
  store %"compiler/generic:AnySlot" %t378, ptr %l26
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t385 = getelementptr %"compiler/generic:Program", ptr %t383, i32 0, i32 2
  store ptr %t385, ptr %l206, !tbaa !29
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/check:Checker", ptr %t386, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !29
  %t391 = getelementptr %"compiler/generic:Program", ptr %t389, i32 0, i32 2
  %t392 = getelementptr %"compiler/generic:AnySlot", ptr %l26, i32 0, i32 5
  %t393 = load i32, ptr %t392, !tbaa !23
  %t396 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t391, i32 %t393)
  store i32 %t396, ptr %l211
  br label %bb72
bb72:
  %t397 = load ptr, ptr %l206, !tbaa !29
  %t398 = load i32, ptr %l211, !tbaa !23
  %t399 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t397, i32 %t398)
  store { i64, ptr } %t399, ptr %l212
  br label %bb73
bb73:
  %t400 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/check:Checker", ptr %t401, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/generic:Program", ptr %t404, i32 0, i32 2
  store { i64, ptr } %t400, ptr %l216, !tbaa !27
  %t408 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = getelementptr i32, ptr %t409, i64 0
  %t411 = load i32, ptr %t410, !tbaa !33
  %t414 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t406, i32 %t411)
  store i64 %t414, ptr %l218
  br label %bb74
bb74:
  %t415 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t416 = load i64, ptr %l218, !tbaa !24
  %t418 = and i64 %t416, %t415
  %t420 = load ptr, ptr %l0, !tbaa !29
  store ptr %t420, ptr %l221, !tbaa !29
  %t421 = getelementptr %"compiler/generic:AnySlot", ptr %l26, i32 0, i32 5
  %t422 = load i32, ptr %t421, !tbaa !23
  store i32 %t422, ptr %l222, !tbaa !23
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !29
  %t428 = getelementptr %"compiler/generic:Program", ptr %t426, i32 0, i32 2
  %t429 = load i32, ptr %l7, !tbaa !23
  %t434 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t428, i32 %t429, i64 %t418)
  store i32 %t434, ptr %l228
  br label %bb75
bb75:
  %t435 = load ptr, ptr %l221, !tbaa !29
  %t436 = load i32, ptr %l222, !tbaa !23
  %t437 = load i32, ptr %l228, !tbaa !23
  %t438 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %t435, i32 %t436, i32 %t437)
  store i32 %t438, ptr %l229
  br label %bb76
bb76:
  %t439 = load i32, ptr %l229, !tbaa !23
  %t440 = load ptr, ptr %l18, !tbaa !29
  %t442 = getelementptr %"compiler/generic:AnyTable", ptr %t440, i32 0, i32 5
  store ptr %t442, ptr %l231, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load i64, ptr %l5, !tbaa !24
  %t445 = load i64, ptr %l25, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t446
  %t447 = getelementptr { i64, [2 x i64] }, ptr %t446, i32 0, i32 0
  store i64 9, ptr %t447
  %t449 = insertvalue { i64, i64 } undef, i64 %t444, 0
  %t451 = insertvalue { i64, i64 } %t449, i64 %t445, 1
  %t452 = getelementptr { i64, [2 x i64] }, ptr %t446, i32 0, i32 1
  store { i64, i64 } %t451, ptr %t452
  %t453 = load { i64, [2 x i64] }, ptr %t446
  %t455 = load i64, ptr %l19, !tbaa !24
  %t456 = load %"compiler/source:Span", ptr %l3
  %t462 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t443, { i64, [2 x i64] } %t453, i32 %t439, i64 %t455, %"compiler/source:Span" %t456)
  store i64 %t462, ptr %l239
  br label %bb77
bb77:
  %t463 = load ptr, ptr %l231, !tbaa !29
  %t464 = load i64, ptr %l239, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t463, i64 %t464)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t465 = load i64, ptr %l24, !tbaa !24
  %t467 = add i64 %t465, 1
  store i64 %t467, ptr %l24, !tbaa !24
  br label %bb68
bb80:
  %t469 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t469, ptr %l242
  br label %bb81
bb81:
  %t470 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l242
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t470, ptr %l30
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %s0, ptr %t471, i32 %t472, ptr %l30, i64 0)
  br label %bb82
bb82:
  %t476 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t476, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatTemp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l33 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l41 = alloca i1
  %l44 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2epastAway(ptr %v1, ptr %v2, ptr %a1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l11, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 3
  store i1 %t12, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l12, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritableTemp(ptr %v0, ptr %v2, ptr %v2, ptr %t26, i32 %t27, ptr %t28)
  store ptr %t32, ptr %l22
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l22, !tbaa !29
  store ptr %t33, ptr %l10, !tbaa !29
  br label %bb24
bb8:
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t35 = load ptr, ptr %l23, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l23, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 5
  store i1 %t41, ptr %l24, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l24, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t45, i32 0, i32 1
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l5, !tbaa !23
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l6, !tbaa !29
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l5, !tbaa !23
  %t59 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l33
  br label %bb14
bb14:
  %t60 = load i1, ptr %l33, !tbaa !21
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t61 = load ptr, ptr %l6, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Promote", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = call ptr @compiler_2fcheck_2epastAway(ptr %v2, ptr %v2, ptr %t64)
  store ptr %t66, ptr %l37
  br label %bb17
bb16:
  store ptr null, ptr %l34, !tbaa !29
  br label %bb18
bb17:
  %t67 = load ptr, ptr %l37, !tbaa !29
  store ptr %t67, ptr %l34, !tbaa !29
  br label %bb18
bb18:
  %t69 = load ptr, ptr %l34, !tbaa !29
  store ptr %t69, ptr %l10, !tbaa !29
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store ptr null, ptr %l10, !tbaa !29
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_1698deca837a7d96_de8e9bfeb7067cd2)
  unreachable
bb24:
  %t70 = load ptr, ptr %l10, !tbaa !29
  store ptr %t70, ptr %l7, !tbaa !29
  %t71 = load ptr, ptr %l7, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb28
bb26:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t79 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatCallee(ptr %v0, ptr %v2, ptr %t75, ptr %t76)
  store i1 %t79, ptr %l44
  br label %bb27
bb27:
  %t80 = load i1, ptr %l44, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l41, !tbaa !21
  br label %bb28
bb28:
  %t83 = load i1, ptr %l41, !tbaa !21
  br i1 %t83, label %bb29, label %bb30
bb29:
  store ptr null, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t85 = load ptr, ptr %l7, !tbaa !29
  store ptr %t85, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l66 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l153 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca i1
  %l176 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l190 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca i1
  %l217 = alloca { i64, ptr }
  %l226 = alloca ptr
  %l227 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i1
  %l267 = alloca ptr
  %l268 = alloca i1
  %l281 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l295 = alloca i1
  %l308 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l338 = alloca ptr
  %l339 = alloca i1
  %l356 = alloca { i64, ptr }
  %l371 = alloca { i64, ptr }
  %l382 = alloca ptr
  %l383 = alloca i1
  %l388 = alloca ptr
  %l389 = alloca i1
  %l398 = alloca ptr
  %l399 = alloca i1
  %l417 = alloca { i64, ptr }
  %l427 = alloca ptr
  %l428 = alloca i1
  %l443 = alloca ptr
  %l444 = alloca i1
  %l457 = alloca { i64, ptr }
  %l465 = alloca ptr
  %l466 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t6 = load ptr, ptr %l69, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l69, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l70, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l70, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t20, ptr %t21, ptr %t22)
  br label %bb9
bb9:
  br label %bb239
bb10:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t28 = load ptr, ptr %l79, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l79, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 3
  store i1 %t34, ptr %l80, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l80, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t42, ptr %t43, ptr %t44)
  br label %bb16
bb16:
  br label %bb239
bb17:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t50 = load ptr, ptr %l89, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb18, label %bb19
bb18:
  %t53 = load ptr, ptr %l89, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 18}
  %t56 = icmp eq i64 %t54, 4
  store i1 %t56, ptr %l90, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l90, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t64, ptr %t65, ptr %t66)
  br label %bb23
bb23:
  br label %bb239
bb24:
  %t71 = load ptr, ptr %l2, !tbaa !29
  store ptr %t71, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t72 = load ptr, ptr %l99, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t75 = load ptr, ptr %l99, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 18}
  %t78 = icmp eq i64 %t76, 5
  store i1 %t78, ptr %l100, !tbaa !21
  br label %bb26
bb26:
  %t79 = load i1, ptr %l100, !tbaa !21
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t86, ptr %t87, ptr %t91)
  br label %bb30
bb30:
  br label %bb239
bb31:
  %t96 = load ptr, ptr %l2, !tbaa !29
  store ptr %t96, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t97 = load ptr, ptr %l110, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb32, label %bb33
bb32:
  %t100 = load ptr, ptr %l110, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 18}
  %t103 = icmp eq i64 %t101, 6
  store i1 %t103, ptr %l111, !tbaa !21
  br label %bb33
bb33:
  %t104 = load i1, ptr %l111, !tbaa !21
  br i1 %t104, label %bb34, label %bb35
bb34:
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  br label %bb69
bb36:
  %t111 = load ptr, ptr %l7, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Call", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  store ptr %t114, ptr %l8, !tbaa !29
  %t116 = load ptr, ptr %l8, !tbaa !29
  store ptr %t116, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t117 = load ptr, ptr %l118, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb37, label %bb38
bb37:
  %t120 = load ptr, ptr %l118, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 5}
  %t123 = icmp eq i64 %t121, 0
  store i1 %t123, ptr %l119, !tbaa !21
  br label %bb38
bb38:
  %t124 = load i1, ptr %l119, !tbaa !21
  br i1 %t124, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %l8, !tbaa !29
  %t127 = getelementptr { i64, [3 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { i32 }, ptr %t127, i32 0, i32 0
  %t129 = load i32, ptr %t128
  store i32 %t129, ptr %l9, !tbaa !23
  br label %bb41
bb40:
  br label %bb46
bb41:
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr %"compiler/check:b5aWalk", ptr %t131, i32 0, i32 6
  %t134 = load i1, ptr %t133, !tbaa !21
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb42, label %bb43
bb42:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t140 = load i32, ptr %l9, !tbaa !23
  %t142 = sext i32 %t140 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t138, ptr %t139, i64 %t142)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb61
bb46:
  %t146 = load ptr, ptr %l8, !tbaa !29
  store ptr %t146, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t147 = load ptr, ptr %l131, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb47, label %bb48
bb47:
  %t150 = load ptr, ptr %l131, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 5}
  %t153 = icmp eq i64 %t151, 2
  store i1 %t153, ptr %l132, !tbaa !21
  br label %bb48
bb48:
  %t154 = load i1, ptr %l132, !tbaa !21
  br i1 %t154, label %bb49, label %bb50
bb49:
  %t155 = load ptr, ptr %l8, !tbaa !29
  %t157 = getelementptr { i64, [3 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { ptr }, ptr %t157, i32 0, i32 0
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l10, !tbaa !29
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/check:b5aWalk", ptr %t161, i32 0, i32 6
  %t164 = load i1, ptr %t163, !tbaa !21
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb52, label %bb53
bb52:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/check:b5aWalk", ptr %t168, i32 0, i32 7
  store i1 true, ptr %t170, !tbaa !21
  br label %bb54
bb53:
  br label %bb54
bb54:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t173 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t171, ptr %t172, ptr %t173)
  br label %bb55
bb55:
  br label %bb61
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_94214b31169ec8c4_68c852e51d74cc68)
  unreachable
bb61:
  %t178 = load ptr, ptr %l7, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Call", ptr %t178, i32 0, i32 1
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  store i64 %t185, ptr %l13, !tbaa !24
  br label %bb62
bb62:
  %t187 = load i64, ptr %l12, !tbaa !24
  %t188 = load i64, ptr %l13, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb63, label %bb64
bb63:
  br label %bb68
bb64:
  br label %bb65
bb65:
  %t195 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t195, ptr %l153, !tbaa !27
  %t196 = load i64, ptr %l12, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr ptr, ptr %t199, i64 %t196
  %t201 = load ptr, ptr %t200, !tbaa !39
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t203, ptr %t204, ptr %t201)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t210 = load i64, ptr %l12, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l12, !tbaa !24
  br label %bb62
bb68:
  br label %bb239
bb69:
  %t214 = load ptr, ptr %l2, !tbaa !29
  store ptr %t214, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t215 = load ptr, ptr %l162, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb70, label %bb71
bb70:
  %t218 = load ptr, ptr %l162, !tbaa !29
  %t219 = load i64, ptr %t218, !range !{i64 0, i64 18}
  %t221 = icmp eq i64 %t219, 7
  store i1 %t221, ptr %l163, !tbaa !21
  br label %bb71
bb71:
  %t222 = load i1, ptr %l163, !tbaa !21
  br i1 %t222, label %bb72, label %bb73
bb72:
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t225, i32 0, i32 2
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l15, !tbaa !29
  br label %bb74
bb73:
  br label %bb83
bb74:
  %t229 = load ptr, ptr %l15, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Make", ptr %t229, i32 0, i32 2
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  store { i64, ptr } %t232, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  store i64 %t236, ptr %l18, !tbaa !24
  br label %bb75
bb75:
  %t238 = load i64, ptr %l17, !tbaa !24
  %t239 = load i64, ptr %l18, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb76, label %bb77
bb76:
  br label %bb81
bb77:
  br label %bb78
bb78:
  %t246 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t246, ptr %l176, !tbaa !27
  %t247 = load i64, ptr %l17, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr ptr, ptr %t250, i64 %t247
  %t252 = load ptr, ptr %t251, !tbaa !39
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t254, ptr %t255, ptr %t252)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t261 = load i64, ptr %l17, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l17, !tbaa !24
  br label %bb75
bb81:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t267 = load ptr, ptr %l15, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Make", ptr %t267, i32 0, i32 3
  %t270 = load ptr, ptr %t269, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t265, ptr %t266, ptr %t270)
  br label %bb82
bb82:
  br label %bb239
bb83:
  %t274 = load ptr, ptr %l2, !tbaa !29
  store ptr %t274, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t275 = load ptr, ptr %l189, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb84, label %bb85
bb84:
  %t278 = load ptr, ptr %l189, !tbaa !29
  %t279 = load i64, ptr %t278, !range !{i64 0, i64 18}
  %t281 = icmp eq i64 %t279, 8
  store i1 %t281, ptr %l190, !tbaa !21
  br label %bb85
bb85:
  %t282 = load i1, ptr %l190, !tbaa !21
  br i1 %t282, label %bb86, label %bb87
bb86:
  %t283 = load ptr, ptr %l2, !tbaa !29
  %t285 = getelementptr { i64, [5 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t285, i32 0, i32 2
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l20, !tbaa !29
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t291 = load ptr, ptr %l20, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Collect", ptr %t291, i32 0, i32 0
  %t294 = load ptr, ptr %t293, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t289, ptr %t290, ptr %t294)
  br label %bb89
bb89:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t300 = load ptr, ptr %l20, !tbaa !29
  %t302 = getelementptr %"compiler/typed:Collect", ptr %t300, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t298, ptr %t299, ptr %t303)
  br label %bb90
bb90:
  br label %bb239
bb91:
  %t308 = load ptr, ptr %l2, !tbaa !29
  store ptr %t308, ptr %l204, !tbaa !29
  store i1 false, ptr %l205, !tbaa !21
  %t309 = load ptr, ptr %l204, !tbaa !29
  %t310 = icmp ne ptr %t309, null
  br i1 %t310, label %bb92, label %bb93
bb92:
  %t312 = load ptr, ptr %l204, !tbaa !29
  %t313 = load i64, ptr %t312, !range !{i64 0, i64 18}
  %t315 = icmp eq i64 %t313, 9
  store i1 %t315, ptr %l205, !tbaa !21
  br label %bb93
bb93:
  %t316 = load i1, ptr %l205, !tbaa !21
  br i1 %t316, label %bb94, label %bb95
bb94:
  %t317 = load ptr, ptr %l2, !tbaa !29
  %t319 = getelementptr { i64, [5 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t319, i32 0, i32 4
  %t321 = load { i64, ptr }, ptr %t320
  store { i64, ptr } %t321, ptr %l21, !tbaa !27
  br label %bb96
bb95:
  br label %bb104
bb96:
  %t323 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t323, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t325 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t325, 0
  store i64 %t327, ptr %l24, !tbaa !24
  br label %bb97
bb97:
  %t329 = load i64, ptr %l23, !tbaa !24
  %t330 = load i64, ptr %l24, !tbaa !24
  %t333 = icmp slt i64 %t329, %t330
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t337 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t337, ptr %l217, !tbaa !27
  %t338 = load i64, ptr %l23, !tbaa !24
  %t340 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr ptr, ptr %t341, i64 %t338
  %t343 = load ptr, ptr %t342, !tbaa !39
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t345, ptr %t346, ptr %t343)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t352 = load i64, ptr %l23, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l23, !tbaa !24
  br label %bb97
bb103:
  br label %bb239
bb104:
  %t356 = load ptr, ptr %l2, !tbaa !29
  store ptr %t356, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t357 = load ptr, ptr %l226, !tbaa !29
  %t358 = icmp ne ptr %t357, null
  br i1 %t358, label %bb105, label %bb106
bb105:
  %t360 = load ptr, ptr %l226, !tbaa !29
  %t361 = load i64, ptr %t360, !range !{i64 0, i64 18}
  %t363 = icmp eq i64 %t361, 10
  store i1 %t363, ptr %l227, !tbaa !21
  br label %bb106
bb106:
  %t364 = load i1, ptr %l227, !tbaa !21
  br i1 %t364, label %bb107, label %bb108
bb107:
  %t365 = load ptr, ptr %l2, !tbaa !29
  %t367 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t367, i32 0, i32 2
  %t369 = load ptr, ptr %t368
  store ptr %t369, ptr %l26, !tbaa !29
  br label %bb109
bb108:
  br label %bb113
bb109:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t373 = load ptr, ptr %l26, !tbaa !29
  %t375 = getelementptr %"compiler/typed:Slice", ptr %t373, i32 0, i32 0
  %t376 = load ptr, ptr %t375, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t371, ptr %t372, ptr %t376)
  br label %bb110
bb110:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t383 = load ptr, ptr %l26, !tbaa !29
  %t385 = getelementptr %"compiler/typed:Slice", ptr %t383, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t381, ptr %t382, ptr %t386)
  br label %bb111
bb111:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t393 = load ptr, ptr %l26, !tbaa !29
  %t395 = getelementptr %"compiler/typed:Slice", ptr %t393, i32 0, i32 2
  %t396 = load ptr, ptr %t395, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t391, ptr %t392, ptr %t396)
  br label %bb112
bb112:
  br label %bb239
bb113:
  %t401 = load ptr, ptr %l2, !tbaa !29
  store ptr %t401, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t402 = load ptr, ptr %l247, !tbaa !29
  %t403 = icmp ne ptr %t402, null
  br i1 %t403, label %bb114, label %bb115
bb114:
  %t405 = load ptr, ptr %l247, !tbaa !29
  %t406 = load i64, ptr %t405, !range !{i64 0, i64 18}
  %t408 = icmp eq i64 %t406, 11
  store i1 %t408, ptr %l248, !tbaa !21
  br label %bb115
bb115:
  %t409 = load i1, ptr %l248, !tbaa !21
  br i1 %t409, label %bb116, label %bb117
bb116:
  %t410 = load ptr, ptr %l2, !tbaa !29
  %t412 = getelementptr { i64, [5 x i64] }, ptr %t410, i32 0, i32 1
  %t413 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t412, i32 0, i32 2
  %t414 = load ptr, ptr %t413
  store ptr %t414, ptr %l27, !tbaa !29
  br label %bb118
bb117:
  br label %bb122
bb118:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t418 = load ptr, ptr %l27, !tbaa !29
  %t420 = getelementptr %"compiler/typed:Cond", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t416, ptr %t417, ptr %t421)
  br label %bb119
bb119:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l1, !tbaa !29
  %t428 = load ptr, ptr %l27, !tbaa !29
  %t430 = getelementptr %"compiler/typed:Cond", ptr %t428, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t426, ptr %t427, ptr %t431)
  br label %bb120
bb120:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t437 = load ptr, ptr %l27, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Cond", ptr %t437, i32 0, i32 2
  %t440 = load ptr, ptr %t439, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t435, ptr %t436, ptr %t440)
  br label %bb121
bb121:
  br label %bb239
bb122:
  %t445 = load ptr, ptr %l2, !tbaa !29
  store ptr %t445, ptr %l267, !tbaa !29
  store i1 false, ptr %l268, !tbaa !21
  %t446 = load ptr, ptr %l267, !tbaa !29
  %t447 = icmp ne ptr %t446, null
  br i1 %t447, label %bb123, label %bb124
bb123:
  %t449 = load ptr, ptr %l267, !tbaa !29
  %t450 = load i64, ptr %t449, !range !{i64 0, i64 18}
  %t452 = icmp eq i64 %t450, 12
  store i1 %t452, ptr %l268, !tbaa !21
  br label %bb124
bb124:
  %t453 = load i1, ptr %l268, !tbaa !21
  br i1 %t453, label %bb125, label %bb126
bb125:
  %t454 = load ptr, ptr %l2, !tbaa !29
  %t456 = getelementptr { i64, [5 x i64] }, ptr %t454, i32 0, i32 1
  %t457 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t456, i32 0, i32 2
  %t458 = load ptr, ptr %t457
  store ptr %t458, ptr %l28, !tbaa !29
  br label %bb127
bb126:
  br label %bb136
bb127:
  %t460 = load ptr, ptr %l28, !tbaa !29
  %t462 = getelementptr %"compiler/typed:Seq", ptr %t460, i32 0, i32 0
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  store { i64, ptr } %t463, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t465 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t465, 0
  store i64 %t467, ptr %l31, !tbaa !24
  br label %bb128
bb128:
  %t469 = load i64, ptr %l30, !tbaa !24
  %t470 = load i64, ptr %l31, !tbaa !24
  %t473 = icmp slt i64 %t469, %t470
  %t475 = xor i1 %t473, true
  br i1 %t475, label %bb129, label %bb130
bb129:
  br label %bb134
bb130:
  br label %bb131
bb131:
  %t477 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t477, ptr %l281, !tbaa !27
  %t478 = load i64, ptr %l30, !tbaa !24
  %t480 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = getelementptr ptr, ptr %t481, i64 %t478
  %t483 = load ptr, ptr %t482, !tbaa !39
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t485, ptr %t486, ptr %t483)
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t492 = load i64, ptr %l30, !tbaa !24
  %t494 = add i64 %t492, 1
  store i64 %t494, ptr %l30, !tbaa !24
  br label %bb128
bb134:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t498 = load ptr, ptr %l28, !tbaa !29
  %t500 = getelementptr %"compiler/typed:Seq", ptr %t498, i32 0, i32 1
  %t501 = load ptr, ptr %t500, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t496, ptr %t497, ptr %t501)
  br label %bb135
bb135:
  br label %bb239
bb136:
  %t505 = load ptr, ptr %l2, !tbaa !29
  store ptr %t505, ptr %l294, !tbaa !29
  store i1 false, ptr %l295, !tbaa !21
  %t506 = load ptr, ptr %l294, !tbaa !29
  %t507 = icmp ne ptr %t506, null
  br i1 %t507, label %bb137, label %bb138
bb137:
  %t509 = load ptr, ptr %l294, !tbaa !29
  %t510 = load i64, ptr %t509, !range !{i64 0, i64 18}
  %t512 = icmp eq i64 %t510, 13
  store i1 %t512, ptr %l295, !tbaa !21
  br label %bb138
bb138:
  %t513 = load i1, ptr %l295, !tbaa !21
  br i1 %t513, label %bb139, label %bb140
bb139:
  %t514 = load ptr, ptr %l2, !tbaa !29
  %t516 = getelementptr { i64, [5 x i64] }, ptr %t514, i32 0, i32 1
  %t517 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t516, i32 0, i32 2
  %t518 = load ptr, ptr %t517
  store ptr %t518, ptr %l33, !tbaa !29
  br label %bb141
bb140:
  br label %bb157
bb141:
  %t520 = load ptr, ptr %l33, !tbaa !29
  %t522 = getelementptr %"compiler/typed:Match", ptr %t520, i32 0, i32 0
  %t523 = load { i64, ptr }, ptr %t522, !tbaa !27
  store { i64, ptr } %t523, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t525 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t527 = extractvalue { i64, ptr } %t525, 0
  store i64 %t527, ptr %l36, !tbaa !24
  br label %bb142
bb142:
  %t529 = load i64, ptr %l35, !tbaa !24
  %t530 = load i64, ptr %l36, !tbaa !24
  %t533 = icmp slt i64 %t529, %t530
  %t535 = xor i1 %t533, true
  br i1 %t535, label %bb143, label %bb144
bb143:
  br label %bb148
bb144:
  br label %bb145
bb145:
  %t537 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t537, ptr %l308, !tbaa !27
  %t538 = load i64, ptr %l35, !tbaa !24
  %t540 = getelementptr { i64, ptr }, ptr %l308, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr ptr, ptr %t541, i64 %t538
  %t543 = load ptr, ptr %t542, !tbaa !39
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t545, ptr %t546, ptr %t543)
  br label %bb146
bb146:
  br label %bb147
bb147:
  %t552 = load i64, ptr %l35, !tbaa !24
  %t554 = add i64 %t552, 1
  store i64 %t554, ptr %l35, !tbaa !24
  br label %bb142
bb148:
  %t556 = load ptr, ptr %l33, !tbaa !29
  %t558 = getelementptr %"compiler/typed:Match", ptr %t556, i32 0, i32 1
  %t559 = load { i64, ptr }, ptr %t558, !tbaa !27
  store { i64, ptr } %t559, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t561 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t563 = extractvalue { i64, ptr } %t561, 0
  store i64 %t563, ptr %l40, !tbaa !24
  br label %bb149
bb149:
  %t565 = load i64, ptr %l39, !tbaa !24
  %t566 = load i64, ptr %l40, !tbaa !24
  %t569 = icmp slt i64 %t565, %t566
  %t571 = xor i1 %t569, true
  br i1 %t571, label %bb150, label %bb151
bb150:
  br label %bb155
bb151:
  br label %bb152
bb152:
  %t573 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t573, ptr %l325, !tbaa !27
  %t574 = load i64, ptr %l39, !tbaa !24
  %t576 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr ptr, ptr %t577, i64 %t574
  %t579 = load ptr, ptr %t578, !tbaa !39
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %t581, ptr %t582, ptr %t579)
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t588 = load i64, ptr %l39, !tbaa !24
  %t590 = add i64 %t588, 1
  store i64 %t590, ptr %l39, !tbaa !24
  br label %bb149
bb155:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load ptr, ptr %l1, !tbaa !29
  %t594 = load ptr, ptr %l33, !tbaa !29
  %t596 = getelementptr %"compiler/typed:Match", ptr %t594, i32 0, i32 2
  %t597 = load ptr, ptr %t596, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %t592, ptr %t593, ptr %t597)
  br label %bb156
bb156:
  br label %bb239
bb157:
  %t601 = load ptr, ptr %l2, !tbaa !29
  store ptr %t601, ptr %l338, !tbaa !29
  store i1 false, ptr %l339, !tbaa !21
  %t602 = load ptr, ptr %l338, !tbaa !29
  %t603 = icmp ne ptr %t602, null
  br i1 %t603, label %bb158, label %bb159
bb158:
  %t605 = load ptr, ptr %l338, !tbaa !29
  %t606 = load i64, ptr %t605, !range !{i64 0, i64 18}
  %t608 = icmp eq i64 %t606, 14
  store i1 %t608, ptr %l339, !tbaa !21
  br label %bb159
bb159:
  %t609 = load i1, ptr %l339, !tbaa !21
  br i1 %t609, label %bb160, label %bb161
bb160:
  %t610 = load ptr, ptr %l2, !tbaa !29
  %t612 = getelementptr { i64, [5 x i64] }, ptr %t610, i32 0, i32 1
  %t613 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t612, i32 0, i32 2
  %t614 = load ptr, ptr %t613
  store ptr %t614, ptr %l42, !tbaa !29
  br label %bb162
bb161:
  br label %bb178
bb162:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t617 = load ptr, ptr %l1, !tbaa !29
  %t618 = load ptr, ptr %l42, !tbaa !29
  %t620 = getelementptr %"compiler/typed:Try", ptr %t618, i32 0, i32 0
  %t621 = load ptr, ptr %t620, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t616, ptr %t617, ptr %t621)
  br label %bb163
bb163:
  %t625 = load ptr, ptr %l42, !tbaa !29
  %t627 = getelementptr %"compiler/typed:Try", ptr %t625, i32 0, i32 1
  %t628 = load { i64, ptr }, ptr %t627, !tbaa !27
  store { i64, ptr } %t628, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t630 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t632 = extractvalue { i64, ptr } %t630, 0
  store i64 %t632, ptr %l45, !tbaa !24
  br label %bb164
bb164:
  %t634 = load i64, ptr %l44, !tbaa !24
  %t635 = load i64, ptr %l45, !tbaa !24
  %t638 = icmp slt i64 %t634, %t635
  %t640 = xor i1 %t638, true
  br i1 %t640, label %bb165, label %bb166
bb165:
  br label %bb177
bb166:
  br label %bb167
bb167:
  %t642 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t642, ptr %l356, !tbaa !27
  %t643 = load i64, ptr %l44, !tbaa !24
  %t645 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t646 = load ptr, ptr %t645, !tbaa !27
  %t647 = getelementptr ptr, ptr %t646, i64 %t643
  %t648 = load ptr, ptr %t647, !tbaa !39
  store ptr %t648, ptr %l46, !tbaa !29
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load ptr, ptr %l1, !tbaa !29
  %t652 = load ptr, ptr %l46, !tbaa !29
  %t654 = getelementptr %"compiler/typed:Clause", ptr %t652, i32 0, i32 3
  %t655 = load ptr, ptr %t654, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t650, ptr %t651, ptr %t655)
  br label %bb168
bb168:
  %t659 = load ptr, ptr %l46, !tbaa !29
  %t661 = getelementptr %"compiler/typed:Clause", ptr %t659, i32 0, i32 4
  %t662 = load { i64, ptr }, ptr %t661, !tbaa !27
  store { i64, ptr } %t662, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  %t664 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t664, 0
  store i64 %t666, ptr %l49, !tbaa !24
  br label %bb169
bb169:
  %t668 = load i64, ptr %l48, !tbaa !24
  %t669 = load i64, ptr %l49, !tbaa !24
  %t672 = icmp slt i64 %t668, %t669
  %t674 = xor i1 %t672, true
  br i1 %t674, label %bb170, label %bb171
bb170:
  br label %bb175
bb171:
  br label %bb172
bb172:
  %t676 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t676, ptr %l371, !tbaa !27
  %t677 = load i64, ptr %l48, !tbaa !24
  %t679 = getelementptr { i64, ptr }, ptr %l371, i32 0, i32 1
  %t680 = load ptr, ptr %t679, !tbaa !27
  %t681 = getelementptr ptr, ptr %t680, i64 %t677
  %t682 = load ptr, ptr %t681, !tbaa !39
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t685 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t684, ptr %t685, ptr %t682)
  br label %bb173
bb173:
  br label %bb174
bb174:
  %t691 = load i64, ptr %l48, !tbaa !24
  %t693 = add i64 %t691, 1
  store i64 %t693, ptr %l48, !tbaa !24
  br label %bb169
bb175:
  br label %bb176
bb176:
  %t695 = load i64, ptr %l44, !tbaa !24
  %t697 = add i64 %t695, 1
  store i64 %t697, ptr %l44, !tbaa !24
  br label %bb164
bb177:
  br label %bb239
bb178:
  %t699 = load ptr, ptr %l2, !tbaa !29
  store ptr %t699, ptr %l382, !tbaa !29
  store i1 false, ptr %l383, !tbaa !21
  %t700 = load ptr, ptr %l382, !tbaa !29
  %t701 = icmp ne ptr %t700, null
  br i1 %t701, label %bb179, label %bb180
bb179:
  %t703 = load ptr, ptr %l382, !tbaa !29
  %t704 = load i64, ptr %t703, !range !{i64 0, i64 18}
  %t706 = icmp eq i64 %t704, 15
  store i1 %t706, ptr %l383, !tbaa !21
  br label %bb180
bb180:
  %t707 = load i1, ptr %l383, !tbaa !21
  br i1 %t707, label %bb181, label %bb182
bb181:
  %t708 = load ptr, ptr %l2, !tbaa !29
  %t710 = getelementptr { i64, [5 x i64] }, ptr %t708, i32 0, i32 1
  %t711 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t710, i32 0, i32 2
  %t712 = load ptr, ptr %t711
  store ptr %t712, ptr %l51, !tbaa !29
  br label %bb183
bb182:
  br label %bb214
bb183:
  %t714 = load ptr, ptr %l51, !tbaa !29
  store ptr %t714, ptr %l388, !tbaa !29
  store i1 false, ptr %l389, !tbaa !21
  %t715 = load ptr, ptr %l388, !tbaa !29
  %t716 = icmp ne ptr %t715, null
  br i1 %t716, label %bb184, label %bb185
bb184:
  %t718 = load ptr, ptr %l388, !tbaa !29
  %t719 = load i64, ptr %t718, !range !{i64 0, i64 3}
  %t721 = icmp eq i64 %t719, 0
  store i1 %t721, ptr %l389, !tbaa !21
  br label %bb185
bb185:
  %t722 = load i1, ptr %l389, !tbaa !21
  br i1 %t722, label %bb186, label %bb187
bb186:
  %t723 = load ptr, ptr %l51, !tbaa !29
  %t725 = getelementptr { i64, [4 x i64] }, ptr %t723, i32 0, i32 1
  %t726 = getelementptr { i32 }, ptr %t725, i32 0, i32 0
  %t727 = load i32, ptr %t726
  store i32 %t727, ptr %l52, !tbaa !23
  br label %bb188
bb187:
  br label %bb190
bb188:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t730 = load ptr, ptr %l1, !tbaa !29
  %t731 = load i32, ptr %l52, !tbaa !23
  %t733 = sext i32 %t731 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t729, ptr %t730, i64 %t733)
  br label %bb189
bb189:
  br label %bb213
bb190:
  %t737 = load ptr, ptr %l51, !tbaa !29
  store ptr %t737, ptr %l398, !tbaa !29
  store i1 false, ptr %l399, !tbaa !21
  %t738 = load ptr, ptr %l398, !tbaa !29
  %t739 = icmp ne ptr %t738, null
  br i1 %t739, label %bb191, label %bb192
bb191:
  %t741 = load ptr, ptr %l398, !tbaa !29
  %t742 = load i64, ptr %t741, !range !{i64 0, i64 3}
  %t744 = icmp eq i64 %t742, 1
  store i1 %t744, ptr %l399, !tbaa !21
  br label %bb192
bb192:
  %t745 = load i1, ptr %l399, !tbaa !21
  br i1 %t745, label %bb193, label %bb194
bb193:
  %t746 = load ptr, ptr %l51, !tbaa !29
  %t748 = getelementptr { i64, [4 x i64] }, ptr %t746, i32 0, i32 1
  %t749 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t748, i32 0, i32 0
  %t750 = load i32, ptr %t749
  store i32 %t750, ptr %l53, !tbaa !23
  %t752 = load ptr, ptr %l51, !tbaa !29
  %t754 = getelementptr { i64, [4 x i64] }, ptr %t752, i32 0, i32 1
  %t755 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t754, i32 0, i32 1
  %t756 = load { i64, ptr }, ptr %t755
  store { i64, ptr } %t756, ptr %l54, !tbaa !27
  br label %bb195
bb194:
  br label %bb204
bb195:
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t759 = load ptr, ptr %l1, !tbaa !29
  %t760 = load i32, ptr %l53, !tbaa !23
  %t762 = sext i32 %t760 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t758, ptr %t759, i64 %t762)
  br label %bb196
bb196:
  %t766 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t766, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t768 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t768, 0
  store i64 %t770, ptr %l57, !tbaa !24
  br label %bb197
bb197:
  %t772 = load i64, ptr %l56, !tbaa !24
  %t773 = load i64, ptr %l57, !tbaa !24
  %t776 = icmp slt i64 %t772, %t773
  %t778 = xor i1 %t776, true
  br i1 %t778, label %bb198, label %bb199
bb198:
  br label %bb203
bb199:
  br label %bb200
bb200:
  %t780 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t780, ptr %l417, !tbaa !27
  %t781 = load i64, ptr %l56, !tbaa !24
  %t783 = getelementptr { i64, ptr }, ptr %l417, i32 0, i32 1
  %t784 = load ptr, ptr %t783, !tbaa !27
  %t785 = getelementptr ptr, ptr %t784, i64 %t781
  %t786 = load ptr, ptr %t785, !tbaa !39
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t789 = load ptr, ptr %l1, !tbaa !29
  %t792 = getelementptr %"compiler/typed:Capture", ptr %t786, i32 0, i32 1
  %t793 = load ptr, ptr %t792, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t788, ptr %t789, ptr %t793)
  br label %bb201
bb201:
  br label %bb202
bb202:
  %t798 = load i64, ptr %l56, !tbaa !24
  %t800 = add i64 %t798, 1
  store i64 %t800, ptr %l56, !tbaa !24
  br label %bb197
bb203:
  br label %bb213
bb204:
  %t802 = load ptr, ptr %l51, !tbaa !29
  store ptr %t802, ptr %l427, !tbaa !29
  store i1 false, ptr %l428, !tbaa !21
  %t803 = load ptr, ptr %l427, !tbaa !29
  %t804 = icmp ne ptr %t803, null
  br i1 %t804, label %bb205, label %bb206
bb205:
  %t806 = load ptr, ptr %l427, !tbaa !29
  %t807 = load i64, ptr %t806, !range !{i64 0, i64 3}
  %t809 = icmp eq i64 %t807, 2
  store i1 %t809, ptr %l428, !tbaa !21
  br label %bb206
bb206:
  %t810 = load i1, ptr %l428, !tbaa !21
  br i1 %t810, label %bb207, label %bb208
bb207:
  %t811 = load ptr, ptr %l51, !tbaa !29
  %t813 = getelementptr { i64, [4 x i64] }, ptr %t811, i32 0, i32 1
  %t814 = getelementptr { i32, ptr, i32 }, ptr %t813, i32 0, i32 0
  %t815 = load i32, ptr %t814
  store i32 %t815, ptr %l59, !tbaa !23
  %t817 = load ptr, ptr %l51, !tbaa !29
  %t819 = getelementptr { i64, [4 x i64] }, ptr %t817, i32 0, i32 1
  %t820 = getelementptr { i32, ptr, i32 }, ptr %t819, i32 0, i32 1
  %t821 = load ptr, ptr %t820
  store ptr %t821, ptr %l60, !tbaa !29
  br label %bb209
bb208:
  br label %bb212
bb209:
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t824 = load ptr, ptr %l1, !tbaa !29
  %t825 = load i32, ptr %l59, !tbaa !23
  %t827 = sext i32 %t825 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t823, ptr %t824, i64 %t827)
  br label %bb210
bb210:
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t832 = load ptr, ptr %l1, !tbaa !29
  %t833 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t831, ptr %t832, ptr %t833)
  br label %bb211
bb211:
  br label %bb213
bb212:
  call void @__olang_check_failed(ptr @olang_loc_d48ba9fb56fa57b5_9836703f13f4bc39)
  unreachable
bb213:
  br label %bb239
bb214:
  %t838 = load ptr, ptr %l2, !tbaa !29
  store ptr %t838, ptr %l443, !tbaa !29
  store i1 false, ptr %l444, !tbaa !21
  %t839 = load ptr, ptr %l443, !tbaa !29
  %t840 = icmp ne ptr %t839, null
  br i1 %t840, label %bb215, label %bb216
bb215:
  %t842 = load ptr, ptr %l443, !tbaa !29
  %t843 = load i64, ptr %t842, !range !{i64 0, i64 18}
  %t845 = icmp eq i64 %t843, 16
  store i1 %t845, ptr %l444, !tbaa !21
  br label %bb216
bb216:
  %t846 = load i1, ptr %l444, !tbaa !21
  br i1 %t846, label %bb217, label %bb218
bb217:
  %t847 = load ptr, ptr %l2, !tbaa !29
  %t849 = getelementptr { i64, [5 x i64] }, ptr %t847, i32 0, i32 1
  %t850 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t849, i32 0, i32 2
  %t851 = load ptr, ptr %t850
  store ptr %t851, ptr %l61, !tbaa !29
  br label %bb219
bb218:
  br label %bb227
bb219:
  %t853 = load ptr, ptr %l61, !tbaa !29
  %t855 = getelementptr %"compiler/typed:Text", ptr %t853, i32 0, i32 0
  %t856 = load { i64, ptr }, ptr %t855, !tbaa !27
  store { i64, ptr } %t856, ptr %l62, !tbaa !27
  store i64 0, ptr %l63, !tbaa !24
  %t858 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t860 = extractvalue { i64, ptr } %t858, 0
  store i64 %t860, ptr %l64, !tbaa !24
  br label %bb220
bb220:
  %t862 = load i64, ptr %l63, !tbaa !24
  %t863 = load i64, ptr %l64, !tbaa !24
  %t866 = icmp slt i64 %t862, %t863
  %t868 = xor i1 %t866, true
  br i1 %t868, label %bb221, label %bb222
bb221:
  br label %bb226
bb222:
  br label %bb223
bb223:
  %t870 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t870, ptr %l457, !tbaa !27
  %t871 = load i64, ptr %l63, !tbaa !24
  %t873 = getelementptr { i64, ptr }, ptr %l457, i32 0, i32 1
  %t874 = load ptr, ptr %t873, !tbaa !27
  %t875 = getelementptr ptr, ptr %t874, i64 %t871
  %t876 = load ptr, ptr %t875, !tbaa !39
  %t878 = load ptr, ptr %l0, !tbaa !29
  %t879 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPiece(ptr %v0, ptr %v1, ptr %v2, ptr %t878, ptr %t879, ptr %t876)
  br label %bb224
bb224:
  br label %bb225
bb225:
  %t884 = load i64, ptr %l63, !tbaa !24
  %t886 = add i64 %t884, 1
  store i64 %t886, ptr %l63, !tbaa !24
  br label %bb220
bb226:
  br label %bb239
bb227:
  %t888 = load ptr, ptr %l2, !tbaa !29
  store ptr %t888, ptr %l465, !tbaa !29
  store i1 false, ptr %l466, !tbaa !21
  %t889 = load ptr, ptr %l465, !tbaa !29
  %t890 = icmp ne ptr %t889, null
  br i1 %t890, label %bb228, label %bb229
bb228:
  %t892 = load ptr, ptr %l465, !tbaa !29
  %t893 = load i64, ptr %t892, !range !{i64 0, i64 18}
  %t895 = icmp eq i64 %t893, 17
  store i1 %t895, ptr %l466, !tbaa !21
  br label %bb229
bb229:
  %t896 = load i1, ptr %l466, !tbaa !21
  br i1 %t896, label %bb230, label %bb231
bb230:
  %t897 = load ptr, ptr %l2, !tbaa !29
  %t899 = getelementptr { i64, [5 x i64] }, ptr %t897, i32 0, i32 1
  %t900 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t899, i32 0, i32 2
  %t901 = load ptr, ptr %t900
  store ptr %t901, ptr %l66, !tbaa !29
  br label %bb232
bb231:
  br label %bb234
bb232:
  %t903 = load ptr, ptr %l0, !tbaa !29
  %t904 = load ptr, ptr %l1, !tbaa !29
  %t905 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t903, ptr %t904, ptr %t905)
  br label %bb233
bb233:
  br label %bb239
bb234:
  br i1 true, label %bb235, label %bb236
bb235:
  br label %bb237
bb236:
  br label %bb238
bb237:
  br label %bb239
bb238:
  call void @__olang_check_failed(ptr @olang_loc_964ce48e3719b9fe_ecf9d1875d849bc2)
  unreachable
bb239:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderVisible(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i1
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l8, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l12
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t18)
  store ptr %t20, ptr %l14
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load i64, ptr %l12, !tbaa !24
  %t27 = icmp eq i64 %t25, %t24
  br i1 %t27, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb8
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Func", ptr %t30, i32 0, i32 10
  %t33 = load i32, ptr %t32, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t29, i32 %t33)
  store { i64, ptr } %t36, ptr %l22
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t38 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t37)
  store i1 %t38, ptr %l23
  br label %bb7
bb7:
  %t39 = load i1, ptr %l23, !tbaa !21
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l18, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 10
  store ptr %t49, ptr %l27, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load i64, ptr %l1, !tbaa !24
  %t57 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t53, i64 %t54)
  store i64 %t57, ptr %l31
  br label %bb12
bb12:
  %t58 = load ptr, ptr %l27, !tbaa !29
  %t59 = load i64, ptr %l31, !tbaa !24
  %t60 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t58, i64 %t59)
  store ptr %t60, ptr %l32
  br label %bb13
bb13:
  %t61 = load ptr, ptr %l32, !tbaa !29
  %t63 = getelementptr %"compiler/load:Module", ptr %t61, i32 0, i32 3
  %t64 = load i1, ptr %t63, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/load:Loader", ptr %t72, i32 0, i32 10
  store ptr %t74, ptr %l39, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t75)
  store ptr %t77, ptr %l41
  br label %bb16
bb15:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb18
bb16:
  %t78 = load ptr, ptr %l41, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t78, i32 0, i32 1
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load ptr, ptr %l39, !tbaa !29
  %t84 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t82, i64 %t81)
  store ptr %t84, ptr %l44
  br label %bb17
bb17:
  %t85 = load ptr, ptr %l44, !tbaa !29
  %t87 = getelementptr %"compiler/load:Module", ptr %t85, i32 0, i32 3
  %t88 = load i1, ptr %t87, !tbaa !21
  store i1 %t88, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t90 = load i1, ptr %l35, !tbaa !21
  br i1 %t90, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l47, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l48
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t93, i32 %a3)
  store { i64, ptr } %t97, ptr %l51
  br label %bb22
bb22:
  %t98 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l52, !tbaa !27
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Func", ptr %t106, i32 0, i32 10
  %t109 = load i32, ptr %t108, !tbaa !23
  %t112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t105, i32 %t109)
  store { i64, ptr } %t112, ptr %l56
  br label %bb23
bb23:
  %t113 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t120 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t122 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderPrivate(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t120, { i64, ptr } %t119)
  store %"compiler/diagmsg:Msg" %t122, ptr %l58
  br label %bb24
bb24:
  %t123 = load ptr, ptr %l47, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l48
  %t125 = load %"compiler/diagmsg:Msg", ptr %l58
  %t126 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t123, %"compiler/source:Span" %t124, %"compiler/diagmsg:Msg" %t125)
  store i64 %t126, ptr %l59
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyField(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i32, ptr }
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca i64
  %l38 = alloca { i64, ptr }
  %l44 = alloca { i32, ptr }
  %l52 = alloca ptr
  %l53 = alloca i1
  %l55 = alloca %"compiler/source:Span"
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l60 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca i1
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/diagmsg:Msg"
  %l69 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca i1
  %l87 = alloca %"compiler/source:Span"
  %l92 = alloca %"compiler/diagmsg:Msg"
  %l94 = alloca i32
  %l99 = alloca i64
  %l102 = alloca i1
  %l106 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l112 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %l117 = alloca i32
  %l121 = alloca ptr
  %l122 = alloca i1
  %l125 = alloca %"compiler/source:Span"
  %l129 = alloca ptr
  %l132 = alloca { i64, ptr }
  %l133 = alloca %"compiler/diagmsg:Msg"
  %l137 = alloca { i64, ptr }
  %l138 = alloca %"compiler/diagmsg:Msg"
  %l140 = alloca i32
  %l150 = alloca i1
  %l153 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca i64
  %l163 = alloca { i64, ptr }
  %l165 = alloca %"compiler/diagmsg:Msg"
  %l167 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t10 = alloca { i64, [4 x i64] }, align 8
  %t28 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/check:fieldSet", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  store i64 %t8, ptr %l21, !tbaa !24
  %t9 = load %"compiler/source:Span", ptr %l1
  store { i64, [4 x i64] } zeroinitializer, ptr %t10
  %t11 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 0
  store i64 0, ptr %t11
  %t13 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t9, 0
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  store { %"compiler/source:Span" } %t13, ptr %t14
  %t15 = load { i64, [4 x i64] }, ptr %t10
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t15, ptr %t17
  store ptr %t17, ptr %l24, !tbaa !29
  %t18 = load i64, ptr %l21, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load i64, ptr %l21, !tbaa !24
  %t22 = icmp sle i64 %t21, 1152921504606846975
  br i1 %t22, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_7e33472f03e5a723_adcfc8d4e22973ef)
  unreachable
bb3:
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t25)
  %t27 = load ptr, ptr %l24, !tbaa !29
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, %t24
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr ptr, ptr %t26, i64 %t32
  store ptr %t27, ptr %t34
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t26, 1
  %t38 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t38, ptr %lp6
  %t40 = load ptr, ptr %lp6
  store { i64, ptr } %t37, ptr %t40, !tbaa !27
  %t41 = load i64, ptr %l5, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_7e33472f03e5a723_adcfc8d4e22973ef)
  unreachable
bb5:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = mul i64 %t45, 1
  %t47 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t46)
  %t48 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  store i1 false, ptr %l9, !tbaa !21
  store { i64, ptr } %a2, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l12, !tbaa !24
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d27f09f1ed434aae_8d18f82803f9a31a)
  unreachable
bb7:
  %t57 = load i64, ptr %l11, !tbaa !24
  %t58 = load i64, ptr %l12, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb8, label %bb9
bb8:
  br label %bb70
bb9:
  br label %bb10
bb10:
  %t65 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t65, ptr %l38, !tbaa !27
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr ptr, ptr %t69, i64 %t66
  %t71 = load ptr, ptr %t70, !tbaa !39
  store ptr %t71, ptr %l13, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l13, !tbaa !29
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t79 = call { i32, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eitemOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t73, ptr %t74, ptr %t75)
  store { i32, ptr } %t79, ptr %l44
  br label %bb11
bb11:
  %t80 = load { i32, ptr }, ptr %l44
  store { i32, ptr } %t80, ptr %l14
  %t81 = getelementptr { i32, ptr }, ptr %l14, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l15, !tbaa !23
  %t84 = getelementptr { i32, ptr }, ptr %l14, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l16, !tbaa !29
  %t87 = load i32, ptr %l15, !tbaa !23
  %t89 = icmp eq i32 %t87, 0
  br i1 %t89, label %bb12, label %bb13
bb12:
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/check:fieldSet", ptr %t91, i32 0, i32 1
  %t94 = load i32, ptr %t93, !tbaa !23
  %t96 = icmp sge i32 %t94, 0
  br i1 %t96, label %bb14, label %bb15
bb13:
  br label %bb33
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l52, !tbaa !29
  %t99 = load i1, ptr %l4, !tbaa !21
  store i1 %t99, ptr %l53, !tbaa !21
  %t100 = load ptr, ptr %l13, !tbaa !29
  %t102 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t100)
  store %"compiler/source:Span" %t102, ptr %l55
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t105 = getelementptr %"compiler/check:fieldSet", ptr %t103, i32 0, i32 2
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStructPatPositional(ptr %v2, ptr %s4, { i64, ptr } %t106)
  store %"compiler/diagmsg:Msg" %t108, ptr %l58
  br label %bb17
bb17:
  %t109 = load ptr, ptr %l52, !tbaa !29
  %t110 = load i1, ptr %l53, !tbaa !21
  %t111 = load %"compiler/source:Span", ptr %l55
  %t113 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %s4, ptr %t109, i1 %t110, %"compiler/source:Span" %t111, ptr %l58)
  store i32 %t113, ptr %l60
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb19, label %ok.115, !prof !99
ok.115:
  br label %bb18
bb18:
  br label %bb20
bb19:
  %t116 = load i32, ptr %l60, !tbaa !23
  %t117 = lshr i32 %t116, 16
  %t118 = and i32 %t116, 65535
  %t119 = icmp eq i32 %t117, 1
  %t120 = select i1 %t119, i32 1, i32 0
  %t121 = icmp eq i32 %t116, 0
  %t122 = shl i32 %t120, 16
  %t123 = or i32 %t122, %t118
  %t124 = select i1 %t121, i32 0, i32 %t123
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t126 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t124, 0
  store { i32, { i64, ptr } } %t126, ptr %rv
  br label %ret
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t127 = load i1, ptr %l9, !tbaa !21
  br i1 %t127, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l63, !tbaa !29
  %t130 = load i1, ptr %l4, !tbaa !21
  store i1 %t130, ptr %l64, !tbaa !21
  %t131 = load ptr, ptr %l13, !tbaa !29
  %t133 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t131)
  store %"compiler/source:Span" %t133, ptr %l66
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t134 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatPositionAfterName(ptr %s5)
  store %"compiler/diagmsg:Msg" %t134, ptr %l67
  br label %bb25
bb25:
  %t135 = load ptr, ptr %l63, !tbaa !29
  %t136 = load i1, ptr %l64, !tbaa !21
  %t137 = load %"compiler/source:Span", ptr %l66
  %t139 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %s5, ptr %t135, i1 %t136, %"compiler/source:Span" %t137, ptr %l67)
  store i32 %t139, ptr %l69
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb27, label %ok.141, !prof !99
ok.141:
  br label %bb26
bb26:
  br label %bb28
bb27:
  %t142 = load i32, ptr %l69, !tbaa !23
  %t143 = lshr i32 %t142, 16
  %t144 = and i32 %t142, 65535
  %t145 = icmp eq i32 %t143, 1
  %t146 = select i1 %t145, i32 1, i32 0
  %t147 = icmp eq i32 %t142, 0
  %t148 = shl i32 %t146, 16
  %t149 = or i32 %t148, %t144
  %t150 = select i1 %t147, i32 0, i32 %t149
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t152 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t150, 0
  store { i32, { i64, ptr } } %t152, ptr %rv
  br label %ret
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t153 = load i64, ptr %l8, !tbaa !24
  %t154 = load i64, ptr %l5, !tbaa !24
  %t157 = icmp slt i64 %t153, %t154
  br i1 %t157, label %bb30, label %bb31
bb30:
  %t159 = load i64, ptr %l8, !tbaa !24
  %t160 = load ptr, ptr %l13, !tbaa !29
  %t162 = load ptr, ptr %lp6
  %t164 = getelementptr { i64, ptr }, ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr ptr, ptr %t165, i64 %t159
  store ptr %t160, ptr %t166, !tbaa !39
  %t167 = load i64, ptr %l8, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i1, ptr %t170, i64 %t167
  store i1 true, ptr %t171, !tbaa !31
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l8, !tbaa !24
  br label %bb69
bb33:
  store i1 true, ptr %l9, !tbaa !21
  %t176 = load ptr, ptr %l3, !tbaa !29
  %t178 = getelementptr %"compiler/check:fieldSet", ptr %t176, i32 0, i32 3
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t183 = icmp sgt i64 %t181, 0
  br i1 %t183, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l83, !tbaa !29
  %t186 = load i1, ptr %l4, !tbaa !21
  store i1 %t186, ptr %l84, !tbaa !21
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l13, !tbaa !29
  %t191 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %t187, ptr %t188)
  store %"compiler/source:Span" %t191, ptr %l87
  br label %bb36
bb35:
  br label %bb41
bb36:
  %t192 = load ptr, ptr %l3, !tbaa !29
  %t194 = getelementptr %"compiler/check:fieldSet", ptr %t192, i32 0, i32 2
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  %t196 = load ptr, ptr %l3, !tbaa !29
  %t198 = getelementptr %"compiler/check:fieldSet", ptr %t196, i32 0, i32 3
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  %t202 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWholeCaseNamed(ptr %v2, ptr %v2, ptr %s7, { i64, ptr } %t195, { i64, ptr } %t199)
  store %"compiler/diagmsg:Msg" %t202, ptr %l92
  br label %bb37
bb37:
  %t203 = load ptr, ptr %l83, !tbaa !29
  %t204 = load i1, ptr %l84, !tbaa !21
  %t205 = load %"compiler/source:Span", ptr %l87
  %t207 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %s7, ptr %t203, i1 %t204, %"compiler/source:Span" %t205, ptr %l92)
  store i32 %t207, ptr %l94
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb39, label %ok.209, !prof !99
ok.209:
  br label %bb38
bb38:
  br label %bb40
bb39:
  %t210 = load i32, ptr %l94, !tbaa !23
  %t211 = lshr i32 %t210, 16
  %t212 = and i32 %t210, 65535
  %t213 = icmp eq i32 %t211, 1
  %t214 = select i1 %t213, i32 1, i32 0
  %t215 = icmp eq i32 %t210, 0
  %t216 = shl i32 %t214, 16
  %t217 = or i32 %t216, %t212
  %t218 = select i1 %t215, i32 0, i32 %t217
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t220 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t218, 0
  store { i32, { i64, ptr } } %t220, ptr %rv
  br label %ret
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  %t221 = load ptr, ptr %l3, !tbaa !29
  %t223 = getelementptr %"compiler/check:fieldSet", ptr %t221, i32 0, i32 0
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  %t225 = load i32, ptr %l15, !tbaa !23
  %t228 = call i64 @compiler_2fcheck_2enameIndex(ptr %v2, { i64, ptr } %t224, i32 %t225)
  store i64 %t228, ptr %l99
  br label %bb42
bb42:
  %t229 = load i64, ptr %l99, !tbaa !24
  store i64 %t229, ptr %l17, !tbaa !24
  %t230 = load i64, ptr %l17, !tbaa !24
  %t232 = icmp slt i64 %t230, 0
  br i1 %t232, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb46
bb44:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l3, !tbaa !29
  %t236 = load i32, ptr %l15, !tbaa !23
  %t240 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldReadable(ptr %v0, ptr %v2, ptr %t234, ptr %t235, i32 %t236)
  store i1 %t240, ptr %l106
  br label %bb45
bb45:
  %t241 = load i1, ptr %l106, !tbaa !21
  %t242 = xor i1 %t241, true
  store i1 %t242, ptr %l102, !tbaa !21
  br label %bb46
bb46:
  %t244 = load i1, ptr %l102, !tbaa !21
  br i1 %t244, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s8
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l108, !tbaa !29
  %t246 = load i1, ptr %l4, !tbaa !21
  store i1 %t246, ptr %l109, !tbaa !21
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l13, !tbaa !29
  %t251 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %t247, ptr %t248)
  store %"compiler/source:Span" %t251, ptr %l112
  br label %bb49
bb48:
  br label %bb54
bb49:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load ptr, ptr %l3, !tbaa !29
  %t254 = load i32, ptr %l15, !tbaa !23
  %t258 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoItemField(ptr %v0, ptr %v2, ptr %s8, ptr %t252, ptr %t253, i32 %t254)
  store ptr %t258, ptr %l116
  br label %bb50
bb50:
  %t259 = load ptr, ptr %l108, !tbaa !29
  %t260 = load i1, ptr %l109, !tbaa !21
  %t261 = load %"compiler/source:Span", ptr %l112
  %t262 = load ptr, ptr %l116, !tbaa !29
  %t263 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %s8, ptr %t259, i1 %t260, %"compiler/source:Span" %t261, ptr %t262)
  store i32 %t263, ptr %l117
  %t264 = icmp ne i32 %t263, 0
  br i1 %t264, label %bb52, label %ok.265, !prof !99
ok.265:
  br label %bb51
bb51:
  br label %bb53
bb52:
  %t266 = load i32, ptr %l117, !tbaa !23
  %t267 = lshr i32 %t266, 16
  %t268 = and i32 %t266, 65535
  %t269 = icmp eq i32 %t267, 1
  %t270 = select i1 %t269, i32 1, i32 0
  %t271 = icmp eq i32 %t266, 0
  %t272 = shl i32 %t270, 16
  %t273 = or i32 %t272, %t268
  %t274 = select i1 %t271, i32 0, i32 %t273
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t276 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t274, 0
  store { i32, { i64, ptr } } %t276, ptr %rv
  br label %ret
bb53:
  call void @__olang_scope_close(ptr %s8)
  br label %bb54
bb54:
  %t277 = load i64, ptr %l17, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr i1, ptr %t280, i64 %t277
  %t282 = load i1, ptr %t281, !tbaa !31
  br i1 %t282, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l121, !tbaa !29
  %t285 = load i1, ptr %l4, !tbaa !21
  store i1 %t285, ptr %l122, !tbaa !21
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load ptr, ptr %l13, !tbaa !29
  %t290 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %t286, ptr %t287)
  store %"compiler/source:Span" %t290, ptr %l125
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t291 = load i64, ptr %l17, !tbaa !24
  %t292 = load i64, ptr %l8, !tbaa !24
  %t295 = icmp slt i64 %t291, %t292
  br i1 %t295, label %bb58, label %bb59
bb58:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i32, ptr %l15, !tbaa !23
  %t301 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t297, i32 %t298)
  store { i64, ptr } %t301, ptr %l132
  br label %bb60
bb59:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i32, ptr %l15, !tbaa !23
  %t306 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t302, i32 %t303)
  store { i64, ptr } %t306, ptr %l137
  br label %bb62
bb60:
  %t307 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t308 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldBothWays(ptr %v0, ptr %s9, { i64, ptr } %t307)
  store %"compiler/diagmsg:Msg" %t308, ptr %l133
  br label %bb61
bb61:
  %t309 = load %"compiler/diagmsg:Msg", ptr %l133
  %t310 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 40, i64 8)
  store %"compiler/diagmsg:Msg" %t309, ptr %t310
  store ptr %t310, ptr %l129, !tbaa !29
  br label %bb64
bb62:
  %t312 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t313 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldTwice(ptr %v0, ptr %s9, { i64, ptr } %t312)
  store %"compiler/diagmsg:Msg" %t313, ptr %l138
  br label %bb63
bb63:
  %t314 = load %"compiler/diagmsg:Msg", ptr %l138
  %t315 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 40, i64 8)
  store %"compiler/diagmsg:Msg" %t314, ptr %t315
  store ptr %t315, ptr %l129, !tbaa !29
  br label %bb64
bb64:
  %t317 = load ptr, ptr %l121, !tbaa !29
  %t318 = load i1, ptr %l122, !tbaa !21
  %t319 = load %"compiler/source:Span", ptr %l125
  %t320 = load ptr, ptr %l129, !tbaa !29
  %t321 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %s9, ptr %t317, i1 %t318, %"compiler/source:Span" %t319, ptr %t320)
  store i32 %t321, ptr %l140
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb66, label %ok.323, !prof !99
ok.323:
  br label %bb65
bb65:
  br label %bb67
bb66:
  %t324 = load i32, ptr %l140, !tbaa !23
  %t325 = lshr i32 %t324, 16
  %t326 = and i32 %t324, 65535
  %t327 = icmp eq i32 %t325, 1
  %t328 = select i1 %t327, i32 1, i32 0
  %t329 = icmp eq i32 %t324, 0
  %t330 = shl i32 %t328, 16
  %t331 = or i32 %t330, %t326
  %t332 = select i1 %t329, i32 0, i32 %t331
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t334 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t332, 0
  store { i32, { i64, ptr } } %t334, ptr %rv
  br label %ret
bb67:
  call void @__olang_scope_close(ptr %s9)
  br label %bb68
bb68:
  %t335 = load i64, ptr %l17, !tbaa !24
  %t336 = load ptr, ptr %l16, !tbaa !29
  %t338 = load ptr, ptr %lp6
  %t340 = getelementptr { i64, ptr }, ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr ptr, ptr %t341, i64 %t335
  store ptr %t336, ptr %t342, !tbaa !39
  %t343 = load i64, ptr %l17, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr i1, ptr %t346, i64 %t343
  store i1 true, ptr %t347, !tbaa !31
  br label %bb69
bb69:
  %t348 = load i64, ptr %l11, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l11, !tbaa !24
  br label %bb7
bb70:
  %t352 = load i64, ptr %l8, !tbaa !24
  %t353 = load i64, ptr %l5, !tbaa !24
  %t356 = icmp sgt i64 %t352, %t353
  br i1 %t356, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb76
bb72:
  %t358 = load i1, ptr %l9, !tbaa !21
  %t360 = xor i1 %t358, true
  br i1 %t360, label %bb73, label %bb74
bb73:
  %t362 = load i64, ptr %l8, !tbaa !24
  %t363 = load i64, ptr %l5, !tbaa !24
  %t366 = icmp ne i64 %t362, %t363
  store i1 %t366, ptr %l153, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb75
bb75:
  %t368 = load i1, ptr %l153, !tbaa !21
  store i1 %t368, ptr %l150, !tbaa !21
  br label %bb76
bb76:
  %t369 = load i1, ptr %l150, !tbaa !21
  br i1 %t369, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s11
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l157, !tbaa !29
  %t371 = load i1, ptr %l4, !tbaa !21
  store i1 %t371, ptr %l158, !tbaa !21
  %t372 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t372, ptr %l159
  %t373 = load i64, ptr %l5, !tbaa !24
  store i64 %t373, ptr %l160, !tbaa !24
  %t374 = load i64, ptr %l5, !tbaa !24
  %t376 = icmp eq i64 %t374, 1
  br i1 %t376, label %bb79, label %bb80
bb78:
  br label %bb86
bb79:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l163, !tbaa !27
  br label %bb81
bb80:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l163, !tbaa !27
  br label %bb81
bb81:
  %t378 = load i64, ptr %l8, !tbaa !24
  %t379 = load i64, ptr %l160, !tbaa !24
  %t380 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t382 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s11, ptr %s11, i64 %t379, { i64, ptr } %t380, i64 %t378)
  store %"compiler/diagmsg:Msg" %t382, ptr %l165
  br label %bb82
bb82:
  %t383 = load ptr, ptr %l157, !tbaa !29
  %t384 = load i1, ptr %l158, !tbaa !21
  %t385 = load %"compiler/source:Span", ptr %l159
  %t387 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %s11, ptr %t383, i1 %t384, %"compiler/source:Span" %t385, ptr %l165)
  store i32 %t387, ptr %l167
  %t388 = icmp ne i32 %t387, 0
  br i1 %t388, label %bb84, label %ok.389, !prof !99
ok.389:
  br label %bb83
bb83:
  br label %bb85
bb84:
  %t390 = load i32, ptr %l167, !tbaa !23
  %t391 = lshr i32 %t390, 16
  %t392 = and i32 %t390, 65535
  %t393 = icmp eq i32 %t391, 1
  %t394 = select i1 %t393, i32 1, i32 0
  %t395 = icmp eq i32 %t390, 0
  %t396 = shl i32 %t394, 16
  %t397 = or i32 %t396, %t392
  %t398 = select i1 %t395, i32 0, i32 %t397
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t400 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t398, 0
  store { i32, { i64, ptr } } %t400, ptr %rv
  br label %ret
bb85:
  call void @__olang_scope_close(ptr %s11)
  br label %bb86
bb86:
  %t401 = load ptr, ptr %lp6
  %t402 = load { i64, ptr }, ptr %t401, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t404 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t402, 1
  store { i32, { i64, ptr } } %t404, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyFieldRow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l16 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca { i64, ptr }
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l7, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t2, ptr %l8, !tbaa !27
  %t3 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !27
  %t5 = getelementptr ptr, ptr %t4, i64 0
  %t6 = load ptr, ptr %t5, !tbaa !39
  %t8 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v2, ptr %t6)
  store %"compiler/source:Span" %t8, ptr %l10
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l10
  %t15 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebyField(ptr %v0, ptr %v3, ptr %v4, ptr %v3, ptr %t11, %"compiler/source:Span" %t12, { i64, ptr } %a3, ptr %a4, i1 false)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l14
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store { i64, ptr } %t16, ptr %l13
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  br label %bb5
bb3:
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb4
bb4:
  br label %ret
bb5:
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  store ptr %a1, ptr %l17, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = call { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v2, ptr %v3, ptr %v1, { i64, ptr } %t27, { i64, ptr } %t25, i64 0)
  store { i64, ptr } %t31, ptr %l20
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l20, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v1, ptr %v1, ptr %t32, { i64, ptr } %t33)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca ptr
  %l24 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 14
  %t19 = load i32, ptr %l2, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t18, i64 %t21)
  store ptr %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 1
  %t28 = load { i64, [2 x i64] }, ptr %t27
  store { i64, [2 x i64] } %t28, ptr %l3
  %t30 = load { i64, [2 x i64] }, ptr %l3
  %t32 = extractvalue { i64, [2 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t36 = getelementptr { i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t42, i64 %t43)
  store i32 %t46, ptr %l24
  br label %bb10
bb10:
  %t47 = load i32, ptr %l24, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_7fe1bea66cf2144e_3863a3a9e6f6a662)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b79520aaecc0f88f_d487c78520878463)
  unreachable
bb22:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/generic:Desc"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %lp17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %lp24 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/generic:Desc"
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i1
  %l64 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca i1
  %l83 = alloca i64
  %l90 = alloca ptr
  %l93 = alloca ptr
  %l96 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l103 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l112 = alloca i64
  %l116 = alloca { i64, ptr }
  %l119 = alloca %"compiler/diagmsg:Msg"
  %l120 = alloca i64
  %l124 = alloca ptr
  %l128 = alloca i1
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca i32
  %l134 = alloca ptr
  %l139 = alloca ptr
  %l144 = alloca i32
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l149 = alloca %"compiler/source:Span"
  %l150 = alloca i32
  %l151 = alloca ptr
  %l155 = alloca %"compiler/typed:Payload"
  %l163 = alloca i64
  %l166 = alloca i64
  %l184 = alloca { i64, ptr }
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca { i64, ptr }
  %l194 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca ptr
  %l198 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l205 = alloca ptr
  %l206 = alloca ptr
  %l215 = alloca ptr
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  %t232 = alloca { i64, [4 x i64] }, align 8
  %t287 = alloca { i64, [4 x i64] }, align 8
  %t368 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l27
  br label %bb1
bb1:
  %t6 = load i32, ptr %l27, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l29
  br label %bb2
bb2:
  %t10 = load %"compiler/source:Span", ptr %l29
  store %"compiler/source:Span" %t10, ptr %l5
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  store %"compiler/generic:Desc" %t15, ptr %l32
  br label %bb3
bb3:
  %t16 = load %"compiler/generic:Desc", ptr %l32
  store %"compiler/generic:Desc" %t16, ptr %l6
  %t17 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t22 = icmp eq i64 %t18, %t19
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l5
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 2
  %t28 = load i64, ptr %t27, !tbaa !24
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v2, ptr %v3, ptr %t24, %"compiler/source:Span" %t25, ptr %t26, i64 %t28)
  store ptr %t33, ptr %l40
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t34 = load ptr, ptr %l40, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t36 = load ptr, ptr %l41, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l41, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 30}
  %t42 = icmp eq i64 %t40, 0
  store i1 %t42, ptr %l42, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l42, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32 }, ptr %t46, i32 0, i32 0
  %t48 = load %"compiler/source:Span", ptr %t47
  store %"compiler/source:Span" %t48, ptr %l7
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32 }, ptr %t52, i32 0, i32 1
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l8, !tbaa !23
  br label %bb12
bb11:
  br label %bb19
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l8, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t56, i32 %t57)
  store { i64, ptr } %t60, ptr %l51
  br label %bb13
bb13:
  %t61 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t61, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t62, ptr %l52
  br label %bb14
bb14:
  %t63 = load i1, ptr %l52, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l7
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t64, %"compiler/source:Span" %t65, i32 %t66, i64 1)
  store ptr %t70, ptr %l56
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t71 = load ptr, ptr %l56, !tbaa !29
  store ptr %t71, ptr %rv
  br label %ret
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb81
bb19:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t73 = load ptr, ptr %l57, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb20, label %bb21
bb20:
  %t76 = load ptr, ptr %l57, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 30}
  %t79 = icmp eq i64 %t77, 14
  store i1 %t79, ptr %l58, !tbaa !21
  br label %bb21
bb21:
  %t80 = load i1, ptr %l58, !tbaa !21
  br i1 %t80, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb30
bb24:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t83 = load i32, ptr %l4, !tbaa !23
  %t87 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t81, ptr %t82, i32 %t83)
  store i64 %t87, ptr %l64
  br label %bb25
bb25:
  %t88 = load i64, ptr %l64, !tbaa !24
  store i64 %t88, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = icmp sge i64 %t89, 0
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l5
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t96 = load i64, ptr %l9, !tbaa !24
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v2, ptr %v3, ptr %t93, %"compiler/source:Span" %t94, ptr %t95, i64 %t96)
  store ptr %t101, ptr %l71
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t102 = load ptr, ptr %l71, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
bb29:
  br label %bb81
bb30:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t104 = load ptr, ptr %l72, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb31, label %bb32
bb31:
  %t107 = load ptr, ptr %l72, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 30}
  %t110 = icmp eq i64 %t108, 12
  store i1 %t110, ptr %l73, !tbaa !21
  br label %bb32
bb32:
  %t111 = load i1, ptr %l73, !tbaa !21
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l10, !tbaa !29
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t120, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l11, !tbaa !27
  br label %bb35
bb34:
  br label %bb76
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l10, !tbaa !29
  %t126 = load i32, ptr %l4, !tbaa !23
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t124, ptr %t125, i32 %t126)
  store i64 %t130, ptr %l83
  br label %bb36
bb36:
  %t131 = load i64, ptr %l83, !tbaa !24
  store i64 %t131, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l12, !tbaa !24
  %t134 = icmp sge i64 %t132, 0
  br i1 %t134, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l5
  %t138 = load ptr, ptr %l2, !tbaa !29
  %t139 = load i64, ptr %l12, !tbaa !24
  %t144 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v2, ptr %v3, ptr %t136, %"compiler/source:Span" %t137, ptr %t138, i64 %t139)
  store ptr %t144, ptr %l90
  br label %bb39
bb38:
  br label %bb75
bb39:
  %t145 = load ptr, ptr %l90, !tbaa !29
  store ptr %t145, ptr %l13, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  store ptr %t151, ptr %l93, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  store ptr %t157, ptr %l96, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load i32, ptr %l4, !tbaa !23
  %t163 = load i64, ptr %l12, !tbaa !24
  %t167 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t161, i32 %t162, i64 %t163)
  store i32 %t167, ptr %l101
  br label %bb40
bb40:
  %t168 = load ptr, ptr %l96, !tbaa !29
  %t169 = load i32, ptr %l101, !tbaa !23
  %t170 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t168, i32 %t169)
  store i32 %t170, ptr %l102
  br label %bb41
bb41:
  %t171 = load ptr, ptr %l93, !tbaa !29
  %t172 = load i32, ptr %l102, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t171, i32 %t172)
  store { i64, ptr } %t173, ptr %l103
  br label %bb42
bb42:
  %t174 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t174, ptr %l14, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp ne i64 %t177, %t180
  br i1 %t183, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l109, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t186, ptr %l110
  %t187 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l112, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t194 = icmp eq i64 %t192, 1
  br i1 %t194, label %bb45, label %bb46
bb44:
  br label %bb51
bb45:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l116, !tbaa !27
  br label %bb47
bb46:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l116, !tbaa !27
  br label %bb47
bb47:
  %t196 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = load i64, ptr %l112, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t202 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s8, ptr %s8, i64 %t199, { i64, ptr } %t200, i64 %t198)
  store %"compiler/diagmsg:Msg" %t202, ptr %l119
  br label %bb48
bb48:
  %t203 = load ptr, ptr %l109, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l110
  %t205 = load %"compiler/diagmsg:Msg", ptr %l119
  %t206 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t203, %"compiler/source:Span" %t204, %"compiler/diagmsg:Msg" %t205)
  store i64 %t206, ptr %l120
  br label %bb49
bb49:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l5
  %t209 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t207, %"compiler/source:Span" %t208, i32 %t209, i64 0)
  store ptr %t213, ptr %l124
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  %t214 = load ptr, ptr %l124, !tbaa !29
  store ptr %t214, ptr %rv
  br label %ret
bb51:
  %t215 = load ptr, ptr %l2, !tbaa !29
  store ptr %t215, ptr %l15, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l3, !tbaa !23
  %t221 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t217, i32 %t218)
  store i1 %t221, ptr %l128
  br label %bb52
bb52:
  %t222 = load i1, ptr %l128, !tbaa !21
  br i1 %t222, label %bb53, label %bb54
bb53:
  %t223 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t223, ptr %l129
  %t224 = load i32, ptr %l4, !tbaa !23
  store i32 %t224, ptr %l130, !tbaa !23
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l5
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v3, ptr %t225, %"compiler/source:Span" %t226, ptr %t227)
  store ptr %t231, ptr %l134
  br label %bb55
bb54:
  br label %bb56
bb55:
  store { i64, [4 x i64] } zeroinitializer, ptr %t232
  %t233 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 0
  store i64 2, ptr %t233
  %t234 = load %"compiler/source:Span", ptr %l129
  %t235 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t234, 0
  %t236 = load i32, ptr %l130, !tbaa !23
  %t237 = insertvalue { %"compiler/source:Span", i32, ptr } %t235, i32 %t236, 1
  %t238 = load ptr, ptr %l134, !tbaa !29
  %t239 = insertvalue { %"compiler/source:Span", i32, ptr } %t237, ptr %t238, 2
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t239, ptr %t240
  %t241 = load { i64, [4 x i64] }, ptr %t232
  %t243 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t241, ptr %t243
  store ptr %t243, ptr %l15, !tbaa !29
  br label %bb56
bb56:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = getelementptr %"compiler/generic:Program", ptr %t248, i32 0, i32 2
  store ptr %t250, ptr %l139, !tbaa !29
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/check:Checker", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = getelementptr %"compiler/generic:Program", ptr %t254, i32 0, i32 2
  %t257 = load i32, ptr %l4, !tbaa !23
  %t260 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t256, i32 %t257)
  store i32 %t260, ptr %l144
  br label %bb57
bb57:
  %t261 = load ptr, ptr %l139, !tbaa !29
  %t262 = load i32, ptr %l144, !tbaa !23
  %t263 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s7, ptr %t261, i32 %t262)
  store { i64, ptr } %t263, ptr %l145
  br label %bb58
bb58:
  %t264 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t264, ptr %l146, !tbaa !27
  %t265 = load i64, ptr %l12, !tbaa !24
  %t267 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr i32, ptr %t268, i64 %t265
  %t270 = load i32, ptr %t269, !tbaa !33
  %t272 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t272, ptr %l149
  store i32 %t270, ptr %l150, !tbaa !23
  %t274 = load ptr, ptr %l15, !tbaa !29
  store ptr %t274, ptr %l151, !tbaa !29
  %t275 = load i64, ptr %l12, !tbaa !24
  %t276 = load ptr, ptr %l151, !tbaa !29
  %t277 = call ptr @__olang_scope_of(ptr %t276, ptr null)
  %t278 = ptrtoint ptr %t277 to i64
  %t280 = inttoptr i64 %t278 to ptr
  %t281 = load ptr, ptr %l151, !tbaa !29
  %t284 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %t280, ptr %v3, ptr %t281, i64 %t275, i32 0)
  store %"compiler/typed:Payload" %t284, ptr %l155
  br label %bb59
bb59:
  %t285 = load %"compiler/typed:Payload", ptr %l155
  %t286 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Payload" %t285, ptr %t286
  store { i64, [4 x i64] } zeroinitializer, ptr %t287
  %t288 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 0
  store i64 5, ptr %t288
  %t289 = load %"compiler/source:Span", ptr %l149
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t289, 0
  %t291 = load i32, ptr %l150, !tbaa !23
  %t292 = insertvalue { %"compiler/source:Span", i32, ptr } %t290, i32 %t291, 1
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr } %t292, ptr %t286, 2
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t294, ptr %t295
  %t296 = load { i64, [4 x i64] }, ptr %t287
  %t297 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t297, ptr %lp17
  %t299 = load ptr, ptr %lp17
  store { i64, [4 x i64] } %t296, ptr %t299
  store i64 0, ptr %l18, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  store i64 %t302, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t304 = load i64, ptr %l19, !tbaa !24
  %t305 = load i64, ptr %l18, !tbaa !24
  %t308 = icmp sgt i64 %t304, %t305
  br i1 %t308, label %bb60, label %bb61
bb60:
  %t310 = load i64, ptr %l20, !tbaa !24
  %t312 = icmp sgt i64 %t310, 0
  br i1 %t312, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb65
bb62:
  %t314 = load i64, ptr %l19, !tbaa !24
  %t315 = load i64, ptr %l18, !tbaa !24
  %t318 = sub i64 %t314, %t315
  %t319 = load i64, ptr %l20, !tbaa !24
  %t322 = add i64 %t318, %t319
  %t324 = sub i64 %t322, 1
  %t325 = load i64, ptr %l20, !tbaa !24
  %t328 = sdiv i64 %t324, %t325
  store i64 %t328, ptr %l166, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb64
bb64:
  %t330 = load i64, ptr %l166, !tbaa !24
  store i64 %t330, ptr %l163, !tbaa !24
  br label %bb65
bb65:
  %t331 = load i64, ptr %l163, !tbaa !24
  store i64 %t331, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb66
bb66:
  %t332 = load i64, ptr %l22, !tbaa !24
  %t333 = load i64, ptr %l21, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb67, label %bb68
bb67:
  br label %bb74
bb68:
  br label %bb69
bb69:
  %t340 = load i64, ptr %l18, !tbaa !24
  %t341 = load i64, ptr %l22, !tbaa !24
  %t342 = load i64, ptr %l20, !tbaa !24
  %t345 = mul i64 %t341, %t342
  %t348 = add i64 %t340, %t345
  store i64 %t348, ptr %l23, !tbaa !24
  %t350 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t350, ptr %l184, !tbaa !27
  %t351 = load i64, ptr %l23, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 %t351
  %t356 = load ptr, ptr %t355, !tbaa !39
  %t358 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t356)
  store %"compiler/source:Span" %t358, ptr %l187
  br label %bb70
bb70:
  %t359 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t359, ptr %l188, !tbaa !27
  %t360 = load i64, ptr %l23, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr i32, ptr %t363, i64 %t360
  %t365 = load i32, ptr %t364, !tbaa !33
  %t366 = load ptr, ptr %lp17
  %t367 = load i64, ptr %l23, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t368
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 0
  store i64 3, ptr %t369
  %t370 = load %"compiler/source:Span", ptr %l187
  %t371 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t370, 0
  %t373 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t371, i32 %t365, 1
  %t375 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t373, ptr %t366, 2
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t375, i64 %t367, 3
  %t378 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t377, ptr %t378
  %t379 = load { i64, [4 x i64] }, ptr %t368
  %t380 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store ptr %t380, ptr %lp24
  %t382 = load ptr, ptr %lp24
  store { i64, [4 x i64] } %t379, ptr %t382
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l194, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t384, ptr %l195
  %t385 = load ptr, ptr %l13, !tbaa !29
  store ptr %t385, ptr %l196, !tbaa !29
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t387, ptr %l198, !tbaa !27
  %t388 = load i64, ptr %l23, !tbaa !24
  %t390 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr ptr, ptr %t391, i64 %t388
  %t393 = load ptr, ptr %t392, !tbaa !39
  %t394 = load ptr, ptr %lp24
  %t395 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t395, ptr %l202, !tbaa !27
  %t396 = load i64, ptr %l23, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i32, ptr %t399, i64 %t396
  %t401 = load i32, ptr %t400, !tbaa !33
  %t406 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTest(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %t386, ptr %t393, ptr %t394, i32 %t401)
  store ptr %t406, ptr %l205
  br label %bb71
bb71:
  %t407 = load ptr, ptr %l194, !tbaa !29
  %t408 = load %"compiler/source:Span", ptr %l195
  %t409 = load ptr, ptr %l196, !tbaa !29
  %t410 = load ptr, ptr %l205, !tbaa !29
  %t411 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v3, ptr %v0, ptr %v3, ptr %t407, %"compiler/source:Span" %t408, ptr %t409, ptr %t410)
  store ptr %t411, ptr %l206
  br label %bb72
bb72:
  %t412 = load ptr, ptr %l206, !tbaa !29
  store ptr %t412, ptr %l13, !tbaa !29
  br label %bb73
bb73:
  %t413 = load i64, ptr %l22, !tbaa !24
  %t415 = add i64 %t413, 1
  store i64 %t415, ptr %l22, !tbaa !24
  br label %bb66
bb74:
  %t417 = load ptr, ptr %l13, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  store ptr %t417, ptr %rv
  br label %ret
bb75:
  br label %bb81
bb76:
  br i1 true, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_82b73da87554a50f_4f07d83e7e807a5b)
  unreachable
bb81:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load %"compiler/source:Span", ptr %l5
  %t421 = load ptr, ptr %l2, !tbaa !29
  %t422 = load ptr, ptr %l1, !tbaa !29
  %t423 = load i32, ptr %l3, !tbaa !23
  %t429 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %t419, %"compiler/source:Span" %t420, ptr %t421, ptr %t422, i32 %t423)
  store ptr %t429, ptr %l215
  br label %bb82
bb82:
  %t430 = load ptr, ptr %l215, !tbaa !29
  store ptr %t430, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCaseTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l28 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca i32
  %l56 = alloca ptr
  %rv = alloca ptr
  %t51 = alloca { i64, [4 x i64] }, align 8
  %t79 = alloca { i64, [4 x i64] }, align 8
  %t119 = alloca { i64, [4 x i64] }, align 8
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store ptr null, ptr %l3, !tbaa !29
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Case", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l6, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %t24)
  store ptr %t32, ptr %l23
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l23, !tbaa !29
  store ptr %t33, ptr %l8, !tbaa !29
  %t34 = load ptr, ptr %l8, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l8, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  br label %bb11
bb10:
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/ast:Case", ptr %t45, i32 0, i32 0
  %t48 = load %"compiler/source:Span", ptr %t47
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t50 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 0
  store i64 5, ptr %t52
  %t54 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t48, 0
  %t56 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t54, i32 46, 1
  %t58 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t56, ptr %t49, 2
  %t60 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t58, ptr %t50, 3
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t60, ptr %t61
  %t62 = load { i64, [4 x i64] }, ptr %t51
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t62, ptr %t64
  store ptr %t64, ptr %l28, !tbaa !29
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l28, !tbaa !29
  store ptr %t66, ptr %l3, !tbaa !29
  br label %bb12
bb12:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l5, !tbaa !24
  br label %bb1
bb13:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Case", ptr %t75, i32 0, i32 0
  %t78 = load %"compiler/source:Span", ptr %t77
  store { i64, [4 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 0
  store i64 1, ptr %t80
  %t82 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t78, 0
  %t84 = insertvalue { %"compiler/source:Span", i32 } %t82, i32 6, 1
  %t85 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t84, ptr %t85
  %t86 = load { i64, [4 x i64] }, ptr %t79
  %t88 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t86, ptr %t88
  store ptr %t88, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t92 = getelementptr %"compiler/ast:Case", ptr %t90, i32 0, i32 3
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = icmp eq ptr %t93, null
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb17, label %bb18
bb17:
  %t99 = load ptr, ptr %l2, !tbaa !29
  %t101 = getelementptr %"compiler/ast:Case", ptr %t99, i32 0, i32 0
  %t102 = load %"compiler/source:Span", ptr %t101
  store %"compiler/source:Span" %t102, ptr %l52
  store i32 45, ptr %l53
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t105 = icmp eq ptr %t103, null
  br i1 %t105, label %bb19, label %bb20
bb18:
  br label %bb25
bb19:
  call void @__olang_check_failed(ptr @olang_loc_da99cffe6602dc08_7fa7c9f5ef49167c)
  unreachable
bb20:
  br label %bb21
bb21:
  %t107 = load ptr, ptr %l3, !tbaa !29
  store ptr %t107, ptr %l56, !tbaa !29
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Case", ptr %t108, i32 0, i32 3
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_da99cffe6602dc08_7fa7c9f5ef49167c)
  unreachable
bb23:
  br label %bb24
bb24:
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t117 = getelementptr %"compiler/ast:Case", ptr %t115, i32 0, i32 3
  %t118 = load ptr, ptr %t117, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t119
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t119, i32 0, i32 0
  store i64 5, ptr %t120
  %t121 = load %"compiler/source:Span", ptr %l52
  %t122 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t121, 0
  %t123 = load i32, ptr %l53, !range !{i32 0, i32 113}
  %t124 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t122, i32 %t123, 1
  %t125 = load ptr, ptr %l56, !tbaa !29
  %t126 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t124, ptr %t125, 2
  %t128 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t126, ptr %t118, 3
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t119, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t128, ptr %t129
  %t130 = load { i64, [4 x i64] }, ptr %t119
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t130, ptr %t132
  store ptr %t132, ptr %l3, !tbaa !29
  br label %bb25
bb25:
  %t134 = load ptr, ptr %l3, !tbaa !29
  %t136 = icmp eq ptr %t134, null
  br i1 %t136, label %bb26, label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ddff752a05460a27_f846f4bbf4f845eb)
  unreachable
bb27:
  br label %bb28
bb28:
  %t138 = load ptr, ptr %l3, !tbaa !29
  store ptr %t138, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %lp12 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca i32
  %l51 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca %"compiler/typed:Cond"
  %l75 = alloca ptr
  %l77 = alloca i32
  %l81 = alloca i64
  %l84 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l90 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca ptr
  %l103 = alloca i64
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca i32
  %l116 = alloca { i64, ptr }
  %l119 = alloca %"compiler/typed:Seq"
  %l122 = alloca ptr
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %l128 = alloca i64
  %l132 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca i32
  %l137 = alloca ptr
  %l139 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca %"compiler/typed:Cond"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t106 = alloca { i64, [5 x i64] }, align 8
  %t171 = alloca { i64, [3 x i64] }, align 8
  %t222 = alloca { i64, [5 x i64] }, align 8
  %t278 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i64 %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = load i64, ptr %l5, !tbaa !24
  %t10 = add i64 %t8, 2
  %t14 = icmp sge i64 %t10, %t6
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l21, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t17, ptr %l22
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l23, !tbaa !29
  %t19 = load i64, ptr %l5, !tbaa !24
  store i64 %t19, ptr %l24, !tbaa !24
  %t20 = load ptr, ptr %l6, !tbaa !29
  store ptr %t20, ptr %l25, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l26, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i1, ptr %t27, i64 %t24
  %t29 = load i1, ptr %t28, !tbaa !31
  br i1 %t29, label %bb3, label %bb4
bb2:
  br label %bb8
bb3:
  store ptr null, ptr %l30, !tbaa !29
  br label %bb6
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 36
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = add i64 %t38, 1
  %t43 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t33, i64 %t40)
  store ptr %t43, ptr %l37
  br label %bb5
bb5:
  %t44 = load ptr, ptr %l37, !tbaa !29
  store ptr %t44, ptr %l30, !tbaa !29
  br label %bb6
bb6:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l22
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load i64, ptr %l24, !tbaa !24
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %v4, ptr %t46, %"compiler/source:Span" %t47, ptr %t48, i64 %t49, ptr %t50, ptr %t51)
  store ptr %t52, ptr %l39
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load ptr, ptr %l39, !tbaa !29
  store ptr %t53, ptr %rv
  br label %ret
bb8:
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t54, ptr %l40, !tbaa !27
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t55, 1
  %t59 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i1, ptr %t60, i64 %t57
  %t62 = load i1, ptr %t61, !tbaa !31
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t64, ptr %l44
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t65, ptr %l45, !tbaa !23
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = load ptr, ptr %l6, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %v0, ptr %t66, %"compiler/source:Span" %t67, ptr %t68, i64 %t69, ptr %t70, ptr null)
  store ptr %t76, ptr %l51
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = load i64, ptr %l5, !tbaa !24
  %t84 = add i64 %t82, 1
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %v4, ptr %t77, %"compiler/source:Span" %t78, ptr %t79, i64 %t80, { i64, ptr } %t81, i64 %t84, ptr null)
  store ptr %t91, ptr %l59
  br label %bb12
bb12:
  %t92 = load ptr, ptr %l59, !tbaa !29
  store ptr %t92, ptr %l60, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t93, %"compiler/source:Span" %t94, i32 %t95, i64 0)
  store ptr %t99, ptr %l64
  br label %bb13
bb13:
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = load ptr, ptr %l60, !tbaa !29
  %t102 = load ptr, ptr %l64, !tbaa !29
  %t103 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v4, ptr %v4, ptr %v4, ptr %t100, ptr %t101, ptr %t102)
  store %"compiler/typed:Cond" %t103, ptr %l65
  br label %bb14
bb14:
  %t104 = load %"compiler/typed:Cond", ptr %l65
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 24, i64 8)
  store %"compiler/typed:Cond" %t104, ptr %t105
  store { i64, [5 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 0
  store i64 11, ptr %t107
  %t108 = load %"compiler/source:Span", ptr %l44
  %t109 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t108, 0
  %t110 = load i32, ptr %l45, !tbaa !23
  %t111 = insertvalue { %"compiler/source:Span", i32, ptr } %t109, i32 %t110, 1
  %t113 = insertvalue { %"compiler/source:Span", i32, ptr } %t111, ptr %t105, 2
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t113, ptr %t114
  %t115 = load { i64, [5 x i64] }, ptr %t106
  %t117 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t115, ptr %t117
  call void @__olang_scope_close(ptr %s0)
  store ptr %t117, ptr %rv
  br label %ret
bb15:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 36
  %t122 = load i64, ptr %l3, !tbaa !24
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = add i64 %t126, 1
  %t131 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s0, ptr %t121, i64 %t128)
  store ptr %t131, ptr %l75
  br label %bb16
bb16:
  %t132 = load ptr, ptr %l75, !tbaa !29
  %t134 = call i32 @compiler_2fcheck_2etypeOf(ptr %s0, ptr %t132)
  store i32 %t134, ptr %l77
  br label %bb17
bb17:
  %t135 = load i32, ptr %l77, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  %t142 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t136, %"compiler/source:Span" %t137, i32 %t135)
  store i64 %t142, ptr %l81
  br label %bb18
bb18:
  %t143 = load i64, ptr %l81, !tbaa !24
  store i64 %t143, ptr %l9, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 37
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l84
  br label %bb19
bb19:
  %t149 = load i64, ptr %l84, !tbaa !24
  store i64 %t149, ptr %l10, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 37
  store ptr %t152, ptr %l86, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l87
  %t154 = load i64, ptr %l9, !tbaa !24
  %t156 = trunc i64 %t154 to i32
  store i32 %t156, ptr %l90, !tbaa !23
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 36
  %t161 = load i64, ptr %l3, !tbaa !24
  %t162 = load i64, ptr %l5, !tbaa !24
  %t165 = add i64 %t161, %t162
  %t167 = add i64 %t165, 1
  %t170 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t160, i64 %t167)
  store ptr %t170, ptr %l97
  br label %bb20
bb20:
  store { i64, [3 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 0
  store i64 0, ptr %t172
  %t173 = load %"compiler/source:Span", ptr %l87
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t173, 0
  %t175 = load i32, ptr %l90, !tbaa !23
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } %t174, i32 %t175, 1
  %t177 = load ptr, ptr %l97, !tbaa !29
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, ptr %t177, 2
  %t179 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t178, ptr %t179
  %t180 = load { i64, [3 x i64] }, ptr %t171
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t180, ptr %t182
  %t183 = load ptr, ptr %l86, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t183, ptr %t182)
  br label %bb21
bb21:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l100, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t186, ptr %l101
  %t187 = load ptr, ptr %l2, !tbaa !29
  store ptr %t187, ptr %l102, !tbaa !29
  %t188 = load i64, ptr %l5, !tbaa !24
  store i64 %t188, ptr %l103, !tbaa !24
  %t189 = load ptr, ptr %l6, !tbaa !29
  store ptr %t189, ptr %l104, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t192 = load i64, ptr %l9, !tbaa !24
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t190, %"compiler/source:Span" %t191, i64 %t192)
  store ptr %t196, ptr %l108
  br label %bb22
bb22:
  %t197 = load ptr, ptr %l108, !tbaa !29
  %t198 = load ptr, ptr %l100, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l101
  %t200 = load ptr, ptr %l102, !tbaa !29
  %t201 = load i64, ptr %l103, !tbaa !24
  %t202 = load ptr, ptr %l104, !tbaa !29
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %v3, ptr %v0, ptr %v4, ptr %t198, %"compiler/source:Span" %t199, ptr %t200, i64 %t201, ptr %t202, ptr %t197)
  store ptr %t204, ptr %l110
  br label %bb23
bb23:
  %t205 = load ptr, ptr %l110, !tbaa !29
  store ptr %t205, ptr %l11, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t206, ptr %l111
  %t207 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t207, ptr %l112, !tbaa !23
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 37
  %t211 = load i64, ptr %l10, !tbaa !24
  %t214 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t210, i64 %t211)
  store { i64, ptr } %t214, ptr %l116
  br label %bb24
bb24:
  %t215 = load ptr, ptr %l11, !tbaa !29
  %t217 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t219 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v4, ptr %v4, { i64, ptr } %t217, ptr %t215, i1 false)
  store %"compiler/typed:Seq" %t219, ptr %l119
  br label %bb25
bb25:
  %t220 = load %"compiler/typed:Seq", ptr %l119
  %t221 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"compiler/typed:Seq" %t220, ptr %t221
  store { i64, [5 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 0
  store i64 12, ptr %t223
  %t224 = load %"compiler/source:Span", ptr %l111
  %t225 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t224, 0
  %t226 = load i32, ptr %l112, !tbaa !23
  %t227 = insertvalue { %"compiler/source:Span", i32, ptr } %t225, i32 %t226, 1
  %t229 = insertvalue { %"compiler/source:Span", i32, ptr } %t227, ptr %t221, 2
  %t230 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t229, ptr %t230
  %t231 = load { i64, [5 x i64] }, ptr %t222
  %t232 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store ptr %t232, ptr %lp12
  %t234 = load ptr, ptr %lp12
  store { i64, [5 x i64] } %t231, ptr %t234
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l122, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t236, ptr %l123
  %t237 = load ptr, ptr %l2, !tbaa !29
  store ptr %t237, ptr %l124, !tbaa !29
  %t238 = load i64, ptr %l3, !tbaa !24
  store i64 %t238, ptr %l125, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t239, ptr %l126, !tbaa !27
  %t240 = load i64, ptr %l5, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l128, !tbaa !24
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l1
  %t245 = load i64, ptr %l9, !tbaa !24
  %t249 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t243, %"compiler/source:Span" %t244, i64 %t245)
  store ptr %t249, ptr %l132
  br label %bb26
bb26:
  %t250 = load ptr, ptr %l132, !tbaa !29
  %t251 = load ptr, ptr %l122, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l123
  %t253 = load ptr, ptr %l124, !tbaa !29
  %t254 = load i64, ptr %l125, !tbaa !24
  %t255 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t256 = load i64, ptr %l128, !tbaa !24
  %t258 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %v4, ptr %t251, %"compiler/source:Span" %t252, ptr %t253, i64 %t254, { i64, ptr } %t255, i64 %t256, ptr %t250)
  store ptr %t258, ptr %l134
  br label %bb27
bb27:
  %t259 = load ptr, ptr %l134, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t260, ptr %l135
  %t261 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t261, ptr %l136, !tbaa !23
  %t262 = load ptr, ptr %lp12
  store ptr %t262, ptr %l137, !tbaa !29
  store ptr %t259, ptr %l139, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  %t267 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t271 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v4, ptr %t265, %"compiler/source:Span" %t266, i32 %t267, i64 0)
  store ptr %t271, ptr %l143
  br label %bb28
bb28:
  %t272 = load ptr, ptr %l137, !tbaa !29
  %t273 = load ptr, ptr %l139, !tbaa !29
  %t274 = load ptr, ptr %l143, !tbaa !29
  %t275 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %t272, ptr %t273, ptr %t274)
  store %"compiler/typed:Cond" %t275, ptr %l144
  br label %bb29
bb29:
  %t276 = load %"compiler/typed:Cond", ptr %l144
  %t277 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 24, i64 8)
  store %"compiler/typed:Cond" %t276, ptr %t277
  store { i64, [5 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 0
  store i64 11, ptr %t279
  %t280 = load %"compiler/source:Span", ptr %l135
  %t281 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t280, 0
  %t282 = load i32, ptr %l136, !tbaa !23
  %t283 = insertvalue { %"compiler/source:Span", i32, ptr } %t281, i32 %t282, 1
  %t285 = insertvalue { %"compiler/source:Span", i32, ptr } %t283, ptr %t277, 2
  %t286 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t285, ptr %t286
  %t287 = load { i64, [5 x i64] }, ptr %t278
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t287, ptr %t289
  call void @__olang_scope_close(ptr %s0)
  store ptr %t289, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckCtor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca %"compiler/generic:Origin"
  %l5 = alloca i1
  %l9 = alloca %"compiler/generic:Origin"
  %l12 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l25 = alloca i32
  %l31 = alloca ptr
  %l37 = alloca { i64, [3 x i64] }
  %l40 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %t69 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %t4, i32 %t5)
  store %"compiler/generic:Origin" %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load %"compiler/generic:Origin", ptr %l9
  store %"compiler/generic:Origin" %t9, ptr %l4
  %t10 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %l2, !tbaa !23
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l17
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t25 = load i32, ptr %l17, !range !{i32 0, i32 33}
  %t27 = trunc i64 18 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t30 = load i1, ptr %l12, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l2, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l25
  br label %bb8
bb7:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t41 = load i32, ptr %l25, !tbaa !23
  %t42 = icmp ne i32 %t41, 0
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t44 = load i1, ptr %l20, !tbaa !21
  store i1 %t44, ptr %l5, !tbaa !21
  %t45 = load i1, ptr %l5, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/load:Loader", ptr %t53, i32 0, i32 4
  %t56 = load ptr, ptr %t55, !tbaa !29
  store ptr %t56, ptr %l31, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 0
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 1
  %t60 = getelementptr %"compiler/source:Span", ptr %t59, i32 0, i32 0
  %t61 = load i32, ptr %t60, !tbaa !23
  %t63 = sext i32 %t61 to i64
  %t64 = getelementptr %"compiler/generic:Origin", ptr %l4, i32 0, i32 1
  %t65 = getelementptr %"compiler/source:Span", ptr %t64, i32 0, i32 1
  %t66 = load i32, ptr %t65, !tbaa !23
  %t68 = sext i32 %t66 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t69
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t69, i32 0, i32 0
  store i64 3, ptr %t70
  %t72 = insertvalue { i64, i64, i64 } undef, i64 %t58, 0
  %t74 = insertvalue { i64, i64, i64 } %t72, i64 %t63, 1
  %t76 = insertvalue { i64, i64, i64 } %t74, i64 %t68, 2
  %t77 = getelementptr { i64, [3 x i64] }, ptr %t69, i32 0, i32 1
  store { i64, i64, i64 } %t76, ptr %t77
  %t78 = load { i64, [3 x i64] }, ptr %t69
  store { i64, [3 x i64] } %t78, ptr %l37
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeInstNote(ptr %v0, ptr %s1, ptr %t79, i32 %t80)
  store { i64, ptr } %t83, ptr %l40
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t84 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load ptr, ptr %l31, !tbaa !29
  %t92 = load { i64, [3 x i64] }, ptr %l37
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %s1, ptr %t91, { i64, [3 x i64] } %t92, { i64, ptr } %t90)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorChecked(ptr %v0, ptr %t94, i64 %a1, i32 %t96, i32 %a3)
  br label %bb15
bb15:
  %t102 = load i1, ptr %l5, !tbaa !21
  br i1 %t102, label %bb16, label %bb17
bb16:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/load:Loader", ptr %t110, i32 0, i32 4
  %t113 = load ptr, ptr %t112, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %t113)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecolumnsFields(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %lp17 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca i32
  %l24 = alloca ptr
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i32
  %l47 = alloca i32
  %l50 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca %"compiler/typed:Local"
  %l57 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l81 = alloca i64
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca { i64, ptr }
  %l114 = alloca i32
  %l115 = alloca %"compiler/source:Span"
  %l118 = alloca i32
  %l127 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l132 = alloca i1
  %l139 = alloca i1
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca { i64, ptr }
  %l143 = alloca i32
  %l144 = alloca i32
  %l147 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca ptr
  %l156 = alloca i32
  %l158 = alloca %"compiler/typed:Make"
  %l165 = alloca { i64, ptr }
  %l170 = alloca i64
  %l180 = alloca ptr
  %s0 = alloca %olang.scope
  %t198 = alloca { i64, [4 x i64] }, align 8
  %t211 = alloca { i64, [4 x i64] }, align 8
  %t289 = alloca { i64, [5 x i64] }, align 8
  %t317 = alloca { i64, [1 x i64] }, align 8
  %t335 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %t4, i32 %t5)
  store i32 %t8, ptr %l22
  br label %bb1
bb1:
  %t9 = load i32, ptr %l22, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l24
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l24, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 5
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l26
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l28
  br label %bb3
bb3:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l3
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t21, ptr %l30
  br label %bb4
bb4:
  %t22 = load i64, ptr %l30, !tbaa !24
  %t23 = icmp slt i64 %t22, 2
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb8
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l35
  br label %bb7
bb7:
  %t30 = load i1, ptr %l35, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l32, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l32, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb12
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l41
  br label %bb11
bb11:
  %t42 = load i1, ptr %l41, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l37, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t47 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 0)
  store i32 %t47, ptr %l44
  br label %bb16
bb16:
  %t48 = load i32, ptr %l44, !tbaa !23
  %t49 = sext i32 %t48 to i64
  store i64 %t49, ptr %l4, !tbaa !24
  %t52 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 1)
  store i32 %t52, ptr %l47
  br label %bb17
bb17:
  %t53 = load i32, ptr %l47, !tbaa !23
  %t54 = sext i32 %t53 to i64
  store i64 %t54, ptr %l5, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t56)
  store ptr %t58, ptr %l50
  br label %bb18
bb18:
  %t60 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 0)
  store i32 %t60, ptr %l52
  br label %bb19
bb19:
  %t61 = load ptr, ptr %l50, !tbaa !29
  %t62 = load i32, ptr %l52, !tbaa !23
  %t63 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t61, i32 %t62)
  store %"compiler/typed:Local" %t63, ptr %l53
  br label %bb20
bb20:
  %t64 = getelementptr %"compiler/typed:Local", ptr %l53, i32 0, i32 1
  %t65 = load %"compiler/source:Span", ptr %t64
  store %"compiler/source:Span" %t65, ptr %l6
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  store ptr %t72, ptr %l57, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l1, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t82, ptr %l62
  br label %bb21
bb21:
  %t83 = load ptr, ptr %l57, !tbaa !29
  %t84 = load i32, ptr %l62, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t83, i32 %t84)
  store { i64, ptr } %t85, ptr %l63
  br label %bb22
bb22:
  %t86 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t91 = load i32, ptr %l1, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %s0, ptr %t90, i32 %t91)
  store { i64, ptr } %t94, ptr %l67
  br label %bb23
bb23:
  %t95 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t95, ptr %l8, !tbaa !27
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l70, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l2, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l75
  br label %bb24
bb24:
  %t112 = load ptr, ptr %l70, !tbaa !29
  %t113 = load i32, ptr %l75, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t112, i32 %t113)
  store { i64, ptr } %t114, ptr %l76
  br label %bb25
bb25:
  %t115 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t115, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t118, i64 %t121)
  store i64 %t124, ptr %l81
  br label %bb26
bb26:
  %t125 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t128 = load i64, ptr %l81, !tbaa !24
  %t130 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t128, i64 %t127)
  store i64 %t130, ptr %l84
  br label %bb27
bb27:
  %t131 = load i64, ptr %l84, !tbaa !24
  store i64 %t131, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = icmp sgt i64 %t132, %t133
  br i1 %t136, label %bb28, label %bb29
bb28:
  %t138 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb33
bb30:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t143 = load i64, ptr %l10, !tbaa !24
  %t146 = sub i64 %t142, %t143
  %t147 = load i64, ptr %l12, !tbaa !24
  %t150 = add i64 %t146, %t147
  %t152 = sub i64 %t150, 1
  %t153 = load i64, ptr %l12, !tbaa !24
  %t156 = sdiv i64 %t152, %t153
  store i64 %t156, ptr %l91, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb32
bb32:
  %t158 = load i64, ptr %l91, !tbaa !24
  store i64 %t158, ptr %l88, !tbaa !24
  br label %bb33
bb33:
  %t159 = load i64, ptr %l88, !tbaa !24
  store i64 %t159, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb34
bb34:
  %t160 = load i64, ptr %l14, !tbaa !24
  %t161 = load i64, ptr %l13, !tbaa !24
  %t164 = icmp slt i64 %t160, %t161
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb35, label %bb36
bb35:
  br label %bb55
bb36:
  br label %bb37
bb37:
  %t168 = load i64, ptr %l10, !tbaa !24
  %t169 = load i64, ptr %l14, !tbaa !24
  %t170 = load i64, ptr %l12, !tbaa !24
  %t173 = mul i64 %t169, %t170
  %t176 = add i64 %t168, %t173
  store i64 %t176, ptr %l15, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l109, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t179, ptr %l110
  %t180 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t180, ptr %l111
  %t181 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t181, ptr %l112, !tbaa !27
  %t182 = load i64, ptr %l15, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i32, ptr %t185, i64 %t182
  %t187 = load i32, ptr %t186, !tbaa !33
  store i32 %t187, ptr %l114, !tbaa !23
  %t188 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t188, ptr %l115
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i64, ptr %l5, !tbaa !24
  %t193 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t189, i64 %t190)
  store i32 %t193, ptr %l118
  br label %bb38
bb38:
  %t194 = load i64, ptr %l5, !tbaa !24
  %t196 = trunc i64 %t194 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t198, i32 0, i32 0
  store i64 0, ptr %t199
  %t200 = load %"compiler/source:Span", ptr %l115
  %t201 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t200, 0
  %t202 = load i32, ptr %l118, !tbaa !23
  %t203 = insertvalue { %"compiler/source:Span", i32, i32 } %t201, i32 %t202, 1
  %t205 = insertvalue { %"compiler/source:Span", i32, i32 } %t203, i32 %t196, 2
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t198, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t205, ptr %t206
  %t207 = load { i64, [4 x i64] }, ptr %t198
  %t209 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t207, ptr %t209
  %t210 = load i64, ptr %l15, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t211
  %t212 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 0
  store i64 3, ptr %t212
  %t213 = load %"compiler/source:Span", ptr %l111
  %t214 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t213, 0
  %t215 = load i32, ptr %l114, !tbaa !23
  %t216 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t214, i32 %t215, 1
  %t218 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t216, ptr %t209, 2
  %t220 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t218, i64 %t210, 3
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t220, ptr %t221
  %t222 = load { i64, [4 x i64] }, ptr %t211
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t222, ptr %t224
  %t225 = load ptr, ptr %l109, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l110
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t225, %"compiler/source:Span" %t226, ptr %t224)
  store ptr %t228, ptr %l127
  br label %bb39
bb39:
  %t229 = load ptr, ptr %l127, !tbaa !29
  store ptr %t229, ptr %l16, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t231, ptr %l129, !tbaa !27
  %t232 = load i64, ptr %l15, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i32, ptr %t235, i64 %t232
  %t237 = load i32, ptr %t236, !tbaa !33
  %t240 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t230, i32 %t237)
  store i1 %t240, ptr %l132
  br label %bb40
bb40:
  %t241 = load i1, ptr %l132, !tbaa !21
  %t242 = xor i1 %t241, true
  br i1 %t242, label %bb41, label %bb42
bb41:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l16, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l6
  %t248 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t253 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t244, ptr %t245, %"compiler/source:Span" %t247, i64 %t248)
  store i1 %t253, ptr %l139
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  %t254 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t254, ptr %l140
  %t255 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t255, ptr %l141, !tbaa !27
  %t256 = load i64, ptr %l15, !tbaa !24
  %t258 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i32, ptr %t259, i64 %t256
  %t261 = load i32, ptr %t260, !tbaa !33
  store i32 %t261, ptr %l143, !tbaa !23
  store i32 3, ptr %l144
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l16, !tbaa !29
  %t266 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t262, ptr %t263)
  store { i64, ptr } %t266, ptr %l147
  br label %bb45
bb45:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l6
  %t269 = load i64, ptr %l4, !tbaa !24
  %t273 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t267, %"compiler/source:Span" %t268, i64 %t269)
  store ptr %t273, ptr %l151
  br label %bb46
bb46:
  %t274 = load ptr, ptr %l151, !tbaa !29
  store ptr %t274, ptr %l152, !tbaa !29
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l6
  %t280 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t275, i32 1, %"compiler/source:Span" %t276)
  store i32 %t280, ptr %l156
  br label %bb47
bb47:
  %t281 = load i32, ptr %l144, !range !{i32 0, i32 5}
  %t282 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t283 = load ptr, ptr %l152, !tbaa !29
  %t284 = load i32, ptr %l156, !tbaa !23
  %t286 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t281, i64 0, { i64, ptr } %t282, ptr %t283, i32 %t284, i32 1, i1 false)
  store %"compiler/typed:Make" %t286, ptr %l158
  br label %bb48
bb48:
  %t287 = load %"compiler/typed:Make", ptr %l158
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t287, ptr %t288
  store { i64, [5 x i64] } zeroinitializer, ptr %t289
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 0
  store i64 7, ptr %t290
  %t291 = load %"compiler/source:Span", ptr %l140
  %t292 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t291, 0
  %t293 = load i32, ptr %l143, !tbaa !23
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr } %t292, i32 %t293, 1
  %t296 = insertvalue { %"compiler/source:Span", i32, ptr } %t294, ptr %t288, 2
  %t297 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t296, ptr %t297
  %t298 = load { i64, [5 x i64] }, ptr %t289
  %t299 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t299, ptr %lp17
  %t301 = load ptr, ptr %lp17
  store { i64, [5 x i64] } %t298, ptr %t301
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i64, ptr %l15, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr i32, ptr %t306, i64 %t303
  %t308 = load i32, ptr %t307, !tbaa !33
  %t309 = load %"compiler/source:Span", ptr %l6
  %t310 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t310, ptr %l165, !tbaa !27
  %t311 = load i64, ptr %l15, !tbaa !24
  %t313 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr i32, ptr %t314, i64 %t311
  %t316 = load i32, ptr %t315, !tbaa !33
  store { i64, [1 x i64] } zeroinitializer, ptr %t317
  %t318 = getelementptr { i64, [1 x i64] }, ptr %t317, i32 0, i32 0
  store i64 4, ptr %t318
  %t319 = load { i64, [1 x i64] }, ptr %t317
  %t326 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t302, i32 %t308, %"compiler/source:Span" %t309, i32 %t316, i32 6, { i64, [1 x i64] } %t319)
  store i64 %t326, ptr %l170
  br label %bb49
bb49:
  %t327 = load i64, ptr %l170, !tbaa !24
  store i64 %t327, ptr %l18, !tbaa !24
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load %"compiler/source:Span", ptr %l6
  %t330 = load i64, ptr %l18, !tbaa !24
  %t332 = trunc i64 %t330 to i32
  %t334 = load ptr, ptr %lp17
  store { i64, [3 x i64] } zeroinitializer, ptr %t335
  %t336 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 0
  store i64 0, ptr %t336
  %t338 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t329, 0
  %t340 = insertvalue { %"compiler/source:Span", i32, ptr } %t338, i32 %t332, 1
  %t342 = insertvalue { %"compiler/source:Span", i32, ptr } %t340, ptr %t334, 2
  %t343 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t342, ptr %t343
  %t344 = load { i64, [3 x i64] }, ptr %t335
  %t346 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t344, ptr %t346
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t328, ptr %t346)
  br label %bb50
bb50:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t349)
  store ptr %t351, ptr %l180
  br label %bb51
bb51:
  %t352 = load ptr, ptr %l180, !tbaa !29
  %t354 = getelementptr %"compiler/typed:Body", ptr %t352, i32 0, i32 10
  %t355 = load i64, ptr %l18, !tbaa !24
  %t357 = trunc i64 %t355 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t354, i32 %t357)
  br label %bb52
bb52:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i64, ptr %l18, !tbaa !24
  %t363 = load %"compiler/source:Span", ptr %l6
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %t361, i64 %t362, %"compiler/source:Span" %t363, i1 true)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t367 = load i64, ptr %l14, !tbaa !24
  %t369 = add i64 %t367, 1
  store i64 %t369, ptr %l14, !tbaa !24
  br label %bb34
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/check:reflList"
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %lp8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i1
  %lp42 = alloca ptr
  %l46 = alloca %"compiler/check:reflList"
  %l53 = alloca ptr
  %l59 = alloca i32
  %l63 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i1
  %l72 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca %"compiler/diagmsg:Msg"
  %l83 = alloca i64
  %l86 = alloca ptr
  %l93 = alloca i32
  %l95 = alloca i32
  %l97 = alloca i32
  %l99 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l106 = alloca %"compiler/ast:ForIn"
  %l109 = alloca i64
  %l111 = alloca ptr
  %l144 = alloca ptr
  %l187 = alloca ptr
  %l192 = alloca i1
  %l194 = alloca ptr
  %l198 = alloca i64
  %l201 = alloca { i64, ptr }
  %l202 = alloca i64
  %l203 = alloca i32
  %l204 = alloca ptr
  %l207 = alloca %"compiler/source:Span"
  %l218 = alloca %"compiler/source:Span"
  %l220 = alloca %"compiler/diagmsg:Msg"
  %l221 = alloca i64
  %l223 = alloca ptr
  %l228 = alloca i1
  %l232 = alloca i1
  %l236 = alloca ptr
  %l244 = alloca ptr
  %l245 = alloca %"compiler/source:Span"
  %l248 = alloca i32
  %l252 = alloca { i64, ptr }
  %l255 = alloca %"compiler/typed:Seq"
  %l266 = alloca ptr
  %l270 = alloca i1
  %l274 = alloca %"compiler/source:Span"
  %l275 = alloca i32
  %l276 = alloca ptr
  %l277 = alloca ptr
  %l281 = alloca i32
  %l284 = alloca %"compiler/typed:Collect"
  %l293 = alloca %"compiler/source:Span"
  %l294 = alloca i32
  %l298 = alloca { i64, ptr }
  %l300 = alloca %"compiler/typed:Seq"
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t465 = alloca { i64, [5 x i64] }, align 8
  %t528 = alloca { i64, [5 x i64] }, align 8
  %t569 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Compr", ptr %t2, i32 0, i32 4
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store %"compiler/check:reflList" %t8, ptr %l46
  br label %bb1
bb1:
  %t9 = load %"compiler/check:reflList", ptr %l46
  store %"compiler/check:reflList" %t9, ptr %l4
  %t10 = getelementptr %"compiler/check:reflList", ptr %l4, i32 0, i32 0
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load %"compiler/check:reflList", ptr %l4
  %t17 = load i32, ptr %l3, !tbaa !23
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolledCompr(ptr %v0, ptr %v1, ptr %v2, ptr %t13, %"compiler/source:Span" %t14, ptr %t15, %"compiler/check:reflList" %t16, i32 %t17)
  store ptr %t23, ptr %l53
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t24 = load ptr, ptr %l53, !tbaa !29
  store ptr %t24, ptr %rv
  br label %ret
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 118
  %t28 = load i1, ptr %t27, !tbaa !21
  store i1 %t28, ptr %l5, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 118
  store i1 false, ptr %t32, !tbaa !21
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValueType(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l59
  br label %bb6
bb6:
  %t38 = load i32, ptr %l59, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  %t39 = load i32, ptr %l6, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp ne i32 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l6, !tbaa !23
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t45, i32 %t46)
  store i1 %t49, ptr %l66
  br label %bb9
bb8:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb14
bb9:
  %t50 = load i1, ptr %l66, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb13
bb11:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load i32, ptr %l6, !tbaa !23
  %t60 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l72
  br label %bb12
bb12:
  %t61 = load i1, ptr %l72, !tbaa !21
  store i1 %t61, ptr %l67, !tbaa !21
  br label %bb13
bb13:
  %t62 = load i1, ptr %l67, !tbaa !21
  store i1 %t62, ptr %l63, !tbaa !21
  br label %bb14
bb14:
  %t63 = load i1, ptr %l63, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l73, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l74, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Compr", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb17, label %bb18
bb16:
  br label %bb25
bb17:
  call void @__olang_check_failed(ptr @olang_loc_cdb7af735b0e96fc_7d1f1dd52d37eb88)
  unreachable
bb18:
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Compr", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t76)
  store %"compiler/source:Span" %t78, ptr %l80
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l74, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l80
  %t81 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t79, %"compiler/source:Span" %t80, i64 1)
  store %"compiler/source:Span" %t81, ptr %l81
  br label %bb21
bb21:
  %t82 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eComprehensionReferences(ptr %s2)
  store %"compiler/diagmsg:Msg" %t82, ptr %l82
  br label %bb22
bb22:
  %t83 = load ptr, ptr %l73, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l81
  %t85 = load %"compiler/diagmsg:Msg", ptr %l82
  %t86 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t83, %"compiler/source:Span" %t84, %"compiler/diagmsg:Msg" %t85)
  store i64 %t86, ptr %l83
  br label %bb23
bb23:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t87, %"compiler/source:Span" %t88)
  store ptr %t91, ptr %l86
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i1, ptr %l5, !tbaa !21
  %t96 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 118
  store i1 %t93, ptr %t96, !tbaa !21
  %t97 = load ptr, ptr %l86, !tbaa !29
  store ptr %t97, ptr %rv
  br label %ret
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 2
  %t104 = load i32, ptr %l6, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t103, i32 %t104, i32 0)
  store i32 %t107, ptr %l93
  br label %bb26
bb26:
  %t108 = load i32, ptr %l93, !tbaa !23
  store i32 %t108, ptr %l7, !tbaa !23
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Compr", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %t111, !tbaa !23
  store i32 %t112, ptr %l95, !tbaa !23
  %t113 = load ptr, ptr %l2, !tbaa !29
  %t115 = getelementptr %"compiler/ast:Compr", ptr %t113, i32 0, i32 3
  %t116 = load i32, ptr %t115, !tbaa !23
  store i32 %t116, ptr %l97, !tbaa !23
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t119 = getelementptr %"compiler/ast:Compr", ptr %t117, i32 0, i32 4
  %t120 = load ptr, ptr %t119, !tbaa !29
  store ptr %t120, ptr %l99, !tbaa !29
  %t121 = icmp sge i64 0, 0
  br i1 %t121, label %bb27, label %bb28
bb27:
  %t123 = icmp sle i64 0, 1152921504606846975
  br i1 %t123, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_e6a78b702db91f09_a31c62fb59cc1eed)
  unreachable
bb29:
  %t125 = mul i64 0, 8
  %t126 = insertvalue { i64, ptr } undef, i64 0, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t127, ptr %l102, !tbaa !27
  %t128 = icmp sge i64 0, 0
  br i1 %t128, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_e6a78b702db91f09_a31c62fb59cc1eed)
  unreachable
bb31:
  %t130 = icmp sle i64 0, 1152921504606846975
  br i1 %t130, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e6a78b702db91f09_a31c62fb59cc1eed)
  unreachable
bb33:
  %t132 = mul i64 0, 8
  %t133 = insertvalue { i64, ptr } undef, i64 0, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t135 = load i32, ptr %l95, !tbaa !23
  %t136 = load i32, ptr %l97, !tbaa !23
  %t137 = load ptr, ptr %l99, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t140 = call %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v1, ptr %v2, ptr %v2, ptr %v2, i32 %t135, i32 %t136, ptr %t137, i1 false, { i64, ptr } %t138, { i64, ptr } %t134, i1 false)
  store %"compiler/ast:ForIn" %t140, ptr %l106
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e6a78b702db91f09_a31c62fb59cc1eed)
  unreachable
bb35:
  %t141 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 64, i64 8)
  store ptr %t141, ptr %lp8
  %t142 = load %"compiler/ast:ForIn", ptr %l106
  %t143 = load ptr, ptr %lp8
  store %"compiler/ast:ForIn" %t142, ptr %t143
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 37
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l109
  br label %bb36
bb36:
  %t149 = load i64, ptr %l109, !tbaa !24
  store i64 %t149, ptr %l9, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t150)
  store ptr %t152, ptr %l111
  br label %bb37
bb37:
  %t153 = load ptr, ptr %l111, !tbaa !29
  %t155 = getelementptr %"compiler/check:frame", ptr %t153, i32 0, i32 17
  %t156 = load i64, ptr %t155, !tbaa !24
  store i64 %t156, ptr %l10, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 110
  %t161 = load i64, ptr %t160, !tbaa !24
  store i64 %t161, ptr %l11, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 111
  %t166 = load i64, ptr %t165, !tbaa !24
  store i64 %t166, ptr %l12, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 112
  %t171 = load i64, ptr %t170, !tbaa !24
  store i64 %t171, ptr %l13, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 113
  %t176 = load i64, ptr %t175, !tbaa !24
  store i64 %t176, ptr %l14, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 114
  %t181 = load i64, ptr %t180, !tbaa !24
  store i64 %t181, ptr %l15, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 115
  %t186 = load i64, ptr %t185, !tbaa !24
  store i64 %t186, ptr %l16, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 116
  %t191 = load i64, ptr %t190, !tbaa !24
  store i64 %t191, ptr %l17, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 117
  %t196 = load i64, ptr %t195, !tbaa !24
  store i64 %t196, ptr %l18, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 110
  store i64 1, ptr %t202, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 115
  store i64 -1, ptr %t207, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 116
  store i64 -1, ptr %t212, !tbaa !24
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 117
  store i64 -1, ptr %t217, !tbaa !24
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l1
  %t220 = load ptr, ptr %lp8
  %t221 = load ptr, ptr %l2, !tbaa !29
  %t223 = load i32, ptr %l6, !tbaa !23
  %t229 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v2, ptr %v1, ptr %v2, ptr %t218, %"compiler/source:Span" %t219, ptr %t220, ptr %t221, i32 %t223)
  store ptr %t229, ptr %l144
  br label %bb38
bb38:
  %t230 = load ptr, ptr %l144, !tbaa !29
  store ptr %t230, ptr %l23, !tbaa !29
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/check:Checker", ptr %t231, i32 0, i32 110
  %t234 = load i64, ptr %t233, !tbaa !24
  %t236 = icmp eq i64 %t234, 1
  br i1 %t236, label %bb39, label %bb40
bb39:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %t238, %"compiler/source:Span" %t239)
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/check:Checker", ptr %t242, i32 0, i32 110
  %t245 = load i64, ptr %t244, !tbaa !24
  store i64 %t245, ptr %l24, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t247, i32 0, i32 111
  %t250 = load i64, ptr %t249, !tbaa !24
  store i64 %t250, ptr %l25, !tbaa !24
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 112
  %t255 = load i64, ptr %t254, !tbaa !24
  store i64 %t255, ptr %l26, !tbaa !24
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 113
  %t260 = load i64, ptr %t259, !tbaa !24
  store i64 %t260, ptr %l27, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/check:Checker", ptr %t262, i32 0, i32 114
  %t265 = load i64, ptr %t264, !tbaa !24
  store i64 %t265, ptr %l28, !tbaa !24
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 115
  %t270 = load i64, ptr %t269, !tbaa !24
  store i64 %t270, ptr %l29, !tbaa !24
  %t272 = load i64, ptr %l11, !tbaa !24
  %t274 = load i64, ptr %l12, !tbaa !24
  %t276 = load i64, ptr %l13, !tbaa !24
  %t278 = load i64, ptr %l14, !tbaa !24
  %t280 = load i64, ptr %l15, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/check:Checker", ptr %t282, i32 0, i32 110
  store i64 %t272, ptr %t286, !tbaa !24
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/check:Checker", ptr %t287, i32 0, i32 111
  store i64 %t274, ptr %t291, !tbaa !24
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 112
  store i64 %t276, ptr %t296, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t297, i32 0, i32 113
  store i64 %t278, ptr %t301, !tbaa !24
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/check:Checker", ptr %t302, i32 0, i32 114
  store i64 %t280, ptr %t306, !tbaa !24
  %t307 = load i64, ptr %l16, !tbaa !24
  %t309 = load i64, ptr %l17, !tbaa !24
  %t311 = load i64, ptr %l18, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t313, i32 0, i32 115
  store i64 %t307, ptr %t317, !tbaa !24
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/check:Checker", ptr %t318, i32 0, i32 116
  store i64 %t309, ptr %t322, !tbaa !24
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/check:Checker", ptr %t323, i32 0, i32 117
  store i64 %t311, ptr %t327, !tbaa !24
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t328)
  store ptr %t330, ptr %l187
  br label %bb43
bb43:
  %t331 = load ptr, ptr %l187, !tbaa !29
  %t333 = getelementptr %"compiler/check:frame", ptr %t331, i32 0, i32 17
  %t334 = load i64, ptr %t333, !tbaa !24
  %t335 = load i64, ptr %l10, !tbaa !24
  %t338 = icmp sgt i64 %t334, %t335
  br i1 %t338, label %bb44, label %bb45
bb44:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t340)
  store ptr %t342, ptr %l194
  br label %bb46
bb45:
  store i1 false, ptr %l192, !tbaa !21
  br label %bb47
bb46:
  %t343 = load ptr, ptr %l194, !tbaa !29
  %t345 = getelementptr %"compiler/check:frame", ptr %t343, i32 0, i32 15
  %t346 = load i64, ptr %t345, !tbaa !24
  %t348 = icmp eq i64 %t346, 0
  store i1 %t348, ptr %l192, !tbaa !21
  br label %bb47
bb47:
  %t350 = load i1, ptr %l192, !tbaa !21
  br i1 %t350, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s6
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load %"compiler/source:Span", ptr %l1
  %t355 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t351, %"compiler/source:Span" %t352)
  store { i64, ptr } %t355, ptr %l201
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t356 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t357 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t356, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) })
  %t358 = extractvalue { i32, i64 } %t357, 1
  %t359 = extractvalue { i32, i64 } %t357, 0
  store i32 %t359, ptr %l203
  %t360 = icmp ne i32 %t359, 0
  br i1 %t360, label %bb52, label %ok.361, !prof !99
ok.361:
  store i64 %t358, ptr %l202
  br label %bb51
bb51:
  %t362 = load i64, ptr %l202, !tbaa !24
  store i64 %t362, ptr %l198, !tbaa !24
  br label %bb54
bb52:
  br label %bb53
bb53:
  store i64 -1, ptr %l198, !tbaa !24
  br label %bb54
bb54:
  %t363 = load i64, ptr %l198, !tbaa !24
  store i64 %t363, ptr %l38, !tbaa !24
  %t364 = load ptr, ptr %l0, !tbaa !29
  store ptr %t364, ptr %l204, !tbaa !29
  %t365 = load i64, ptr %l38, !tbaa !24
  %t367 = icmp sge i64 %t365, 0
  br i1 %t367, label %bb55, label %bb56
bb55:
  %t369 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t370 = load i32, ptr %t369, !tbaa !23
  %t371 = load i64, ptr %l38, !tbaa !24
  %t373 = add i64 %t371, 1
  %t375 = trunc i64 %t373 to i32
  %t378 = add i32 %t370, %t375
  %t379 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t380 = load i32, ptr %t379, !tbaa !23
  %t381 = load i64, ptr %l38, !tbaa !24
  %t383 = add i64 %t381, 4
  %t385 = trunc i64 %t383 to i32
  %t388 = add i32 %t380, %t385
  %t391 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t378, i32 %t388)
  store %"compiler/source:Span" %t391, ptr %l218
  br label %bb57
bb56:
  %t392 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t392, ptr %l207
  br label %bb58
bb57:
  %t394 = load %"compiler/source:Span", ptr %l218
  store %"compiler/source:Span" %t394, ptr %l207
  br label %bb58
bb58:
  %t395 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eComprNeedsTry(ptr %s6)
  store %"compiler/diagmsg:Msg" %t395, ptr %l220
  br label %bb59
bb59:
  %t396 = load ptr, ptr %l204, !tbaa !29
  %t397 = load %"compiler/source:Span", ptr %l207
  %t398 = load %"compiler/diagmsg:Msg", ptr %l220
  %t399 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t396, %"compiler/source:Span" %t397, %"compiler/diagmsg:Msg" %t398)
  store i64 %t399, ptr %l221
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s6)
  br label %bb61
bb61:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t400)
  store ptr %t402, ptr %l223
  br label %bb62
bb62:
  %t403 = load ptr, ptr %l223, !tbaa !29
  %t404 = load i64, ptr %l10, !tbaa !24
  %t407 = getelementptr %"compiler/check:frame", ptr %t403, i32 0, i32 17
  store i64 %t404, ptr %t407, !tbaa !24
  %t408 = load i64, ptr %l24, !tbaa !24
  %t410 = icmp ne i64 %t408, 3
  br i1 %t410, label %bb63, label %bb64
bb63:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load i32, ptr %l7, !tbaa !23
  %t414 = load %"compiler/source:Span", ptr %l1
  %t418 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayEnds(ptr %v0, ptr %t412, i32 %t413, %"compiler/source:Span" %t414)
  store i1 %t418, ptr %l232
  br label %bb65
bb64:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb66
bb65:
  %t419 = load i1, ptr %l232, !tbaa !21
  %t420 = xor i1 %t419, true
  store i1 %t420, ptr %l228, !tbaa !21
  br label %bb66
bb66:
  %t422 = load i1, ptr %l228, !tbaa !21
  br i1 %t422, label %bb67, label %bb68
bb67:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load %"compiler/source:Span", ptr %l1
  %t427 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t423, %"compiler/source:Span" %t424)
  store ptr %t427, ptr %l236
  br label %bb69
bb68:
  br label %bb70
bb69:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load i1, ptr %l5, !tbaa !21
  %t432 = getelementptr %"compiler/check:Checker", ptr %t428, i32 0, i32 118
  store i1 %t429, ptr %t432, !tbaa !21
  %t433 = load ptr, ptr %l236, !tbaa !29
  store ptr %t433, ptr %rv
  br label %ret
bb70:
  %t434 = load i64, ptr %l24, !tbaa !24
  %t436 = icmp eq i64 %t434, 3
  br i1 %t436, label %bb71, label %bb72
bb71:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load %"compiler/source:Span", ptr %l1
  %t440 = load i64, ptr %l29, !tbaa !24
  %t444 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v2, ptr %t438, %"compiler/source:Span" %t439, i64 %t440)
  store ptr %t444, ptr %l244
  br label %bb73
bb72:
  br label %bb77
bb73:
  %t445 = load ptr, ptr %l244, !tbaa !29
  store ptr %t445, ptr %l39, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t446, ptr %l245
  %t447 = load ptr, ptr %l39, !tbaa !29
  %t450 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t447)
  store i32 %t450, ptr %l248
  br label %bb74
bb74:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/check:Checker", ptr %t451, i32 0, i32 37
  %t454 = load i64, ptr %l9, !tbaa !24
  %t457 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t453, i64 %t454)
  store { i64, ptr } %t457, ptr %l252
  br label %bb75
bb75:
  %t458 = load ptr, ptr %l39, !tbaa !29
  %t460 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t462 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t460, ptr %t458, i1 false)
  store %"compiler/typed:Seq" %t462, ptr %l255
  br label %bb76
bb76:
  %t463 = load %"compiler/typed:Seq", ptr %l255
  %t464 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t463, ptr %t464
  store { i64, [5 x i64] } zeroinitializer, ptr %t465
  %t466 = getelementptr { i64, [5 x i64] }, ptr %t465, i32 0, i32 0
  store i64 12, ptr %t466
  %t467 = load %"compiler/source:Span", ptr %l245
  %t468 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t467, 0
  %t469 = load i32, ptr %l248, !tbaa !23
  %t470 = insertvalue { %"compiler/source:Span", i32, ptr } %t468, i32 %t469, 1
  %t472 = insertvalue { %"compiler/source:Span", i32, ptr } %t470, ptr %t464, 2
  %t473 = getelementptr { i64, [5 x i64] }, ptr %t465, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t472, ptr %t473
  %t474 = load { i64, [5 x i64] }, ptr %t465
  %t476 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t474, ptr %t476
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t478 = load i1, ptr %l5, !tbaa !21
  %t481 = getelementptr %"compiler/check:Checker", ptr %t477, i32 0, i32 118
  store i1 %t478, ptr %t481, !tbaa !21
  store ptr %t476, ptr %rv
  br label %ret
bb77:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load i64, ptr %l25, !tbaa !24
  %t485 = load i64, ptr %l26, !tbaa !24
  %t486 = load i64, ptr %l27, !tbaa !24
  %t487 = load i64, ptr %l28, !tbaa !24
  %t493 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v2, ptr %t483, i64 %t484, i64 %t485, i64 %t486, i64 %t487)
  store ptr %t493, ptr %l266
  br label %bb78
bb78:
  %t494 = load ptr, ptr %l266, !tbaa !29
  store ptr %t494, ptr %l40, !tbaa !29
  %t495 = load ptr, ptr %l23, !tbaa !29
  %t497 = icmp eq ptr %t495, null
  %t499 = xor i1 %t497, true
  br i1 %t499, label %bb79, label %bb80
bb79:
  %t501 = load ptr, ptr %l2, !tbaa !29
  %t503 = getelementptr %"compiler/ast:Compr", ptr %t501, i32 0, i32 5
  %t504 = load ptr, ptr %t503, !tbaa !29
  %t506 = icmp eq ptr %t504, null
  store i1 %t506, ptr %l270, !tbaa !21
  br label %bb81
bb80:
  store i1 false, ptr %l270, !tbaa !21
  br label %bb81
bb81:
  %t508 = load i1, ptr %l270, !tbaa !21
  store i1 %t508, ptr %l41, !tbaa !21
  %t509 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t509, ptr %l274
  %t510 = load i32, ptr %l7, !tbaa !23
  store i32 %t510, ptr %l275, !tbaa !23
  %t511 = load ptr, ptr %l23, !tbaa !29
  store ptr %t511, ptr %l276, !tbaa !29
  %t512 = load ptr, ptr %l40, !tbaa !29
  store ptr %t512, ptr %l277, !tbaa !29
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load %"compiler/source:Span", ptr %l1
  %t518 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t513, i32 3, %"compiler/source:Span" %t514)
  store i32 %t518, ptr %l281
  br label %bb82
bb82:
  %t519 = load i1, ptr %l41, !tbaa !21
  %t520 = load ptr, ptr %l276, !tbaa !29
  %t521 = load ptr, ptr %l277, !tbaa !29
  %t522 = load i32, ptr %l281, !tbaa !23
  %t525 = call %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %t520, ptr %t521, i32 %t522, i32 0, i1 %t519)
  store %"compiler/typed:Collect" %t525, ptr %l284
  br label %bb83
bb83:
  %t526 = load %"compiler/typed:Collect", ptr %l284
  %t527 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Collect" %t526, ptr %t527
  store { i64, [5 x i64] } zeroinitializer, ptr %t528
  %t529 = getelementptr { i64, [5 x i64] }, ptr %t528, i32 0, i32 0
  store i64 8, ptr %t529
  %t530 = load %"compiler/source:Span", ptr %l274
  %t531 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t530, 0
  %t532 = load i32, ptr %l275, !tbaa !23
  %t533 = insertvalue { %"compiler/source:Span", i32, ptr } %t531, i32 %t532, 1
  %t535 = insertvalue { %"compiler/source:Span", i32, ptr } %t533, ptr %t527, 2
  %t536 = getelementptr { i64, [5 x i64] }, ptr %t528, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t535, ptr %t536
  %t537 = load { i64, [5 x i64] }, ptr %t528
  %t538 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t538, ptr %lp42
  %t540 = load ptr, ptr %lp42
  store { i64, [5 x i64] } %t537, ptr %t540
  %t541 = load i64, ptr %l28, !tbaa !24
  %t542 = load i64, ptr %l9, !tbaa !24
  %t545 = icmp eq i64 %t541, %t542
  br i1 %t545, label %bb84, label %bb85
bb84:
  %t547 = load ptr, ptr %lp42
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t549 = load i1, ptr %l5, !tbaa !21
  %t552 = getelementptr %"compiler/check:Checker", ptr %t548, i32 0, i32 118
  store i1 %t549, ptr %t552, !tbaa !21
  store ptr %t547, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t554 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t554, ptr %l293
  %t555 = load i32, ptr %l7, !tbaa !23
  store i32 %t555, ptr %l294, !tbaa !23
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/check:Checker", ptr %t556, i32 0, i32 37
  %t559 = load i64, ptr %l9, !tbaa !24
  %t562 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t558, i64 %t559)
  store { i64, ptr } %t562, ptr %l298
  br label %bb87
bb87:
  %t563 = load ptr, ptr %lp42
  %t564 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t566 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t564, ptr %t563, i1 false)
  store %"compiler/typed:Seq" %t566, ptr %l300
  br label %bb88
bb88:
  %t567 = load %"compiler/typed:Seq", ptr %l300
  %t568 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t567, ptr %t568
  store { i64, [5 x i64] } zeroinitializer, ptr %t569
  %t570 = getelementptr { i64, [5 x i64] }, ptr %t569, i32 0, i32 0
  store i64 12, ptr %t570
  %t571 = load %"compiler/source:Span", ptr %l293
  %t572 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t571, 0
  %t573 = load i32, ptr %l294, !tbaa !23
  %t574 = insertvalue { %"compiler/source:Span", i32, ptr } %t572, i32 %t573, 1
  %t576 = insertvalue { %"compiler/source:Span", i32, ptr } %t574, ptr %t568, 2
  %t577 = getelementptr { i64, [5 x i64] }, ptr %t569, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t576, ptr %t577
  %t578 = load { i64, [5 x i64] }, ptr %t569
  %t580 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t578, ptr %t580
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load i1, ptr %l5, !tbaa !21
  %t585 = getelementptr %"compiler/check:Checker", ptr %t581, i32 0, i32 118
  store i1 %t582, ptr %t585, !tbaa !21
  store ptr %t580, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %lp6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i32
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l41 = alloca i64
  %l46 = alloca i64
  %l48 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l66 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l77 = alloca i32
  %l83 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %a2)
  store i32 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i32, ptr %l12, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d6, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i32 %t15, ptr %l14
  br label %bb3
bb3:
  %t16 = load i32, ptr %l14, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 0, i64 8)
  store ptr %t17, ptr %lp6
  %t19 = load ptr, ptr %lp6
  store [0 x i32] zeroinitializer, ptr %t19
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l20
  br label %bb4
bb4:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l4, !tbaa !23
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l26
  br label %bb7
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t41 = load i1, ptr %l26, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l21, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %t45, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d9, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i32 %t47, ptr %l29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = mul i64 2, 4
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 2, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l31, !tbaa !27
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 0
  store i32 %t53, ptr %t56, !tbaa !33
  %t58 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 1
  store i32 %t48, ptr %t60, !tbaa !33
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t71, ptr %l36
  br label %bb13
bb13:
  %t72 = load i1, ptr %l36, !tbaa !21
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l4, !tbaa !23
  %t82 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t78, i32 %t79)
  store i64 %t82, ptr %l41
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l3, !tbaa !23
  %t92 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t88, i32 %t89)
  store i64 %t92, ptr %l46
  br label %bb17
bb17:
  %t93 = load i64, ptr %l41, !tbaa !24
  %t94 = load i64, ptr %l46, !tbaa !24
  %t95 = icmp slt i64 %t93, %t94
  br i1 %t95, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  %t97 = load i32, ptr %l4, !tbaa !23
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = icmp ne i32 %t97, %t98
  store i1 %t101, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t103 = load i1, ptr %l48, !tbaa !21
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t104 = load i32, ptr %l5, !tbaa !23
  %t105 = mul i64 1, 4
  %t106 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 1, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l54, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 0
  store i32 %t104, ptr %t112, !tbaa !33
  %t113 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  br label %bb23
bb22:
  %t114 = load ptr, ptr %lp6
  %t116 = insertvalue { i64, ptr } undef, i64 0, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t114, 1
  store { i64, ptr } %t117, ptr %l52, !tbaa !27
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t119, ptr %rv
  br label %ret
bb24:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l4, !tbaa !23
  %t129 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t125, i32 %t126)
  store i1 %t129, ptr %l61
  br label %bb25
bb25:
  %t130 = load i1, ptr %l61, !tbaa !21
  br i1 %t130, label %bb26, label %bb27
bb26:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l4, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t136, i32 %t137)
  store i64 %t140, ptr %l66
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t141 = load i64, ptr %l66, !tbaa !24
  %t142 = icmp sle i64 %t141, 16
  br i1 %t142, label %bb29, label %bb30
bb29:
  %t144 = load i32, ptr %l5, !tbaa !23
  %t145 = mul i64 1, 4
  %t146 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 1, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l70, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 0
  store i32 %t144, ptr %t152, !tbaa !33
  %t153 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t153, ptr %l68, !tbaa !27
  br label %bb31
bb30:
  %t154 = load ptr, ptr %lp6
  %t156 = insertvalue { i64, ptr } undef, i64 0, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  store { i64, ptr } %t157, ptr %l68, !tbaa !27
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t159 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t159, ptr %rv
  br label %ret
bb32:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t164 = load i32, ptr %l3, !tbaa !23
  %t165 = load i32, ptr %l4, !tbaa !23
  %t169 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t163, i32 %t164, i32 %t165)
  store i32 %t169, ptr %l77
  br label %bb33
bb33:
  %t170 = load i32, ptr %l4, !tbaa !23
  %t171 = load i32, ptr %l77, !tbaa !23
  %t173 = icmp eq i32 %t171, %t170
  br i1 %t173, label %bb34, label %bb35
bb34:
  %t175 = load ptr, ptr %lp6
  %t177 = insertvalue { i64, ptr } undef, i64 0, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t178, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t180 = load i32, ptr %l5, !tbaa !23
  %t181 = mul i64 1, 4
  %t182 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t181)
  %t183 = insertvalue { i64, ptr } undef, i64 1, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l83, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr i32, ptr %t187, i64 0
  store i32 %t180, ptr %t188, !tbaa !33
  call void @__olang_scope_close(ptr %s0)
  %t189 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t189, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca i1
  %l13 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @compiler_2fcheck_2ehasNamed(ptr %v1, { i64, ptr } %t1)
  store i1 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i1, ptr %l7, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store ptr %t16, ptr %l13
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l13, !tbaa !29
  store ptr %t17, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/ast:TypeDecl", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  %t31 = xor i1 %t29, true
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeDecl", ptr %t34, i32 0, i32 3
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l4, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  store ptr %t39, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t40 = load ptr, ptr %l24, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb11, label %bb12
bb10:
  br label %bb25
bb11:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 5}
  %t46 = icmp eq i64 %t44, 0
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l25, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr { i64, [6 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { ptr }, ptr %t50, i32 0, i32 0
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb19
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l30, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:StructBody", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l32, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t59, ptr %l33, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l34, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %l1, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l39
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l34, !tbaa !29
  %t72 = load i32, ptr %l39, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t71, i32 %t72)
  store { i64, ptr } %t73, ptr %l40
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l30, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t78 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t74, { i64, ptr } %t75, { i64, ptr } %t76, { i64, ptr } %t77)
  store { i64, ptr } %t78, ptr %l41
  br label %bb18
bb18:
  %t79 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_7f8223142f689eb4_f934e4a817092f38)
  unreachable
bb24:
  br label %bb25
bb25:
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 14
  store ptr %t13, ptr %l7, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t14)
  store ptr %t16, ptr %l9
  br label %bb4
bb3:
  %t17 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t19 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  call void @__olang_check_failed_text(ptr @olang_loc_43d20343d6f566de_136f8b7be912828a, { i64, ptr } %t20)
  unreachable
bb4:
  %t21 = load ptr, ptr %l9, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 0
  %t24 = load i64, ptr %t23, !tbaa !24
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t27 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %t25, i64 %t24)
  store ptr %t27, ptr %l12
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l12, !tbaa !29
  store ptr %t28, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaredCtor(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i1
  %l13 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l48 = alloca i64
  %l51 = alloca ptr
  %l54 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i32
  %l61 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp sgt i64 %t18, 0
  store i1 %t20, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TypeDecl", ptr %t23, i32 0, i32 3
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 5}
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr { i64, [6 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { ptr }, ptr %t39, i32 0, i32 0
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t45 = getelementptr %"compiler/ast:StructBody", ptr %t43, i32 0, i32 5
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb35
bb18:
  %t52 = load ptr, ptr %l3, !tbaa !29
  store ptr %t52, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb19, label %bb20
bb19:
  %t56 = load ptr, ptr %l30, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 5}
  %t59 = icmp eq i64 %t57, 3
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb21, label %bb22
bb21:
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr { i64, [6 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { ptr, ptr }, ptr %t63, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb30
bb23:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb26
bb25:
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Func", ptr %t71, i32 0, i32 5
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t78 = icmp sgt i64 %t76, 0
  store i1 %t78, ptr %l38, !tbaa !21
  br label %bb26
bb26:
  %t80 = load i1, ptr %l38, !tbaa !21
  br i1 %t80, label %bb27, label %bb28
bb27:
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_f558fce6a2b003e7_933c1b66dd113bdb)
  unreachable
bb35:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load i64, ptr %l1, !tbaa !24
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/ast:TypeDecl", ptr %t86, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t93 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t84, i64 %t85, i32 %t89)
  store i64 %t93, ptr %l48
  br label %bb36
bb36:
  %t94 = load i64, ptr %l48, !tbaa !24
  store i64 %t94, ptr %l6, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = icmp slt i64 %t95, 0
  br i1 %t97, label %bb37, label %bb38
bb37:
  br label %ret
bb38:
  br label %bb39
bb39:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t105, ptr %l54, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l1, !tbaa !24
  %t111 = load i64, ptr %l6, !tbaa !24
  %t115 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t109, i64 %t110, i64 %t111)
  store i32 %t115, ptr %l59
  br label %bb40
bb40:
  %t116 = load ptr, ptr %l54, !tbaa !29
  %t117 = load i32, ptr %l59, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t116, i32 %t117, i32 0)
  store i32 %t118, ptr %l60
  br label %bb41
bb41:
  %t119 = load ptr, ptr %l51, !tbaa !29
  %t120 = load i32, ptr %l60, !tbaa !23
  %t121 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t119, i32 %t120)
  store i64 %t121, ptr %l61
  br label %bb42
bb42:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeferStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %lp4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca %"compiler/check:factsCopy"
  %l25 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca %"compiler/check:factsMark"
  %l57 = alloca i64
  %l58 = alloca ptr
  %l60 = alloca i32
  %l64 = alloca { i64, i64, i64 }
  %l69 = alloca ptr
  %l73 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l80 = alloca ptr
  %l83 = alloca i64
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l88 = alloca ptr
  %l91 = alloca i64
  %l96 = alloca ptr
  %l100 = alloca ptr
  %l108 = alloca ptr
  %s1 = alloca %olang.scope
  %t206 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l15, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 22
  store ptr %t6, ptr %l17, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t7)
  store ptr %t9, ptr %l19
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 7
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t14, i64 %t13)
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call %"compiler/check:factsCopy" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsCopied(ptr %v0, ptr %v0, ptr %t16)
  store %"compiler/check:factsCopy" %t18, ptr %l23
  br label %bb4
bb4:
  %t19 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 96, i64 8)
  store ptr %t19, ptr %lp4
  %t20 = load %"compiler/check:factsCopy", ptr %l23
  %t21 = load ptr, ptr %lp4
  store %"compiler/check:factsCopy" %t20, ptr %t21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t22)
  store ptr %t24, ptr %l25
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l25, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 52
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l27, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l29
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l29, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 51
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = load i64, ptr %l27, !tbaa !24
  %t40 = icmp slt i64 %t38, %t37
  br i1 %t40, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t42)
  store ptr %t44, ptr %l35
  br label %bb9
bb8:
  br label %bb20
bb9:
  %t45 = load ptr, ptr %l35, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 51
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l37, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t49)
  store ptr %t51, ptr %l39
  br label %bb10
bb10:
  %t52 = load ptr, ptr %l39, !tbaa !29
  %t54 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 52
  %t55 = load i64, ptr %t54, !tbaa !24
  store i64 %t55, ptr %l41, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t56)
  store ptr %t58, ptr %l43
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l43, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t59, i32 0, i32 51
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l46, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l47, !tbaa !24
  %t67 = load i64, ptr %l41, !tbaa !24
  %t68 = icmp sge i64 %t67, 0
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load i64, ptr %l41, !tbaa !24
  %t71 = load i64, ptr %l46, !tbaa !24
  %t72 = icmp sle i64 %t70, %t71
  br i1 %t72, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_45d73a08c1eee64c_a811f88d32b1fa78)
  unreachable
bb14:
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = load i64, ptr %l47, !tbaa !24
  %t76 = icmp sle i64 %t74, %t75
  br i1 %t76, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_45d73a08c1eee64c_a811f88d32b1fa78)
  unreachable
bb16:
  %t78 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l41, !tbaa !24
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = getelementptr ptr, ptr %t79, i64 %t80
  %t83 = sub i64 %t81, %t80
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l5, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l52, !tbaa !29
  %t88 = call %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %s1, i64 0, i64 0, i64 0)
  store %"compiler/check:factsMark" %t88, ptr %l53
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_45d73a08c1eee64c_a811f88d32b1fa78)
  unreachable
bb18:
  %t89 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t90 = load ptr, ptr %l52, !tbaa !29
  %t91 = load %"compiler/check:factsMark", ptr %l53
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ekillAssigned(ptr %v0, ptr %v0, ptr %t90, %"compiler/check:factsMark" %t91, { i64, ptr } %t89)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 37
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l57
  br label %bb21
bb21:
  %t98 = load i64, ptr %l57, !tbaa !24
  store i64 %t98, ptr %l6, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l58, !tbaa !29
  br i1 %a3, label %bb22, label %bb23
bb22:
  store i32 7, ptr %l60
  br label %bb24
bb23:
  store i32 6, ptr %l60
  br label %bb24
bb24:
  %t104 = load %"compiler/source:Span", ptr %l1
  %t105 = load ptr, ptr %l58, !tbaa !29
  %t106 = load i32, ptr %l60, !range !{i32 0, i32 10}
  %t108 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t105, i32 %t106, %"compiler/source:Span" %t104)
  store { i64, i64, i64 } %t108, ptr %l64
  br label %bb25
bb25:
  %t109 = load { i64, i64, i64 }, ptr %l64
  store { i64, i64, i64 } %t109, ptr %l7
  %t110 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  %t113 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  store i64 %t114, ptr %l9, !tbaa !24
  %t116 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t117 = load i64, ptr %t116, !tbaa !24
  store i64 %t117, ptr %l10, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t119)
  store ptr %t121, ptr %l69
  br label %bb26
bb26:
  %t122 = load ptr, ptr %l69, !tbaa !29
  %t124 = getelementptr %"compiler/check:frame", ptr %t122, i32 0, i32 34
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %l11, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t127)
  store ptr %t129, ptr %l73
  br label %bb27
bb27:
  %t130 = load ptr, ptr %l73, !tbaa !29
  %t132 = getelementptr %"compiler/check:frame", ptr %t130, i32 0, i32 37
  %t133 = load i64, ptr %t132, !tbaa !24
  store i64 %t133, ptr %l12, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t135)
  store ptr %t137, ptr %l77
  br label %bb28
bb28:
  %t138 = load ptr, ptr %l77, !tbaa !29
  store ptr %t138, ptr %l78, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t139)
  store ptr %t141, ptr %l80
  br label %bb29
bb29:
  %t142 = load ptr, ptr %l80, !tbaa !29
  %t144 = getelementptr %"compiler/check:frame", ptr %t142, i32 0, i32 10
  %t146 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t144)
  store i64 %t146, ptr %l83
  br label %bb30
bb30:
  %t147 = load i64, ptr %l83, !tbaa !24
  %t148 = load ptr, ptr %l78, !tbaa !29
  %t149 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 34
  store i64 %t147, ptr %t149, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t150)
  store ptr %t152, ptr %l85
  br label %bb31
bb31:
  %t153 = load ptr, ptr %l85, !tbaa !29
  store ptr %t153, ptr %l86, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t154)
  store ptr %t156, ptr %l88
  br label %bb32
bb32:
  %t157 = load ptr, ptr %l88, !tbaa !29
  %t159 = getelementptr %"compiler/check:frame", ptr %t157, i32 0, i32 38
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t159)
  store i64 %t161, ptr %l91
  br label %bb33
bb33:
  %t162 = load i64, ptr %l91, !tbaa !24
  %t163 = load ptr, ptr %l86, !tbaa !29
  %t164 = getelementptr %"compiler/check:frame", ptr %t163, i32 0, i32 37
  store i64 %t162, ptr %t164, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t165, ptr %a2)
  br label %bb34
bb34:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t170)
  store ptr %t172, ptr %l96
  br label %bb35
bb35:
  %t173 = load ptr, ptr %l96, !tbaa !29
  %t174 = load i64, ptr %l11, !tbaa !24
  %t177 = getelementptr %"compiler/check:frame", ptr %t173, i32 0, i32 34
  store i64 %t174, ptr %t177, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t178)
  store ptr %t180, ptr %l100
  br label %bb36
bb36:
  %t181 = load ptr, ptr %l100, !tbaa !29
  %t182 = load i64, ptr %l12, !tbaa !24
  %t185 = getelementptr %"compiler/check:frame", ptr %t181, i32 0, i32 37
  store i64 %t182, ptr %t185, !tbaa !24
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i64, ptr %l8, !tbaa !24
  %t188 = load i64, ptr %l9, !tbaa !24
  %t189 = load i64, ptr %l10, !tbaa !24
  %t190 = load i64, ptr %l6, !tbaa !24
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t186, i64 %t187, i64 %t188, i64 %t189, i64 %t190)
  store ptr %t196, ptr %l108
  br label %bb37
bb37:
  %t197 = load ptr, ptr %l108, !tbaa !29
  store ptr %t197, ptr %l13, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %lp4
  %t200 = load %"compiler/check:factsCopy", ptr %t199
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsRestored(ptr %v0, ptr %v0, ptr %t198, %"compiler/check:factsCopy" %t200)
  br label %bb38
bb38:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l1
  %t205 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t206
  %t207 = getelementptr { i64, [3 x i64] }, ptr %t206, i32 0, i32 0
  store i64 12, ptr %t207
  %t209 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t204, 0
  %t211 = insertvalue { %"compiler/source:Span", ptr } %t209, ptr %t205, 1
  %t212 = getelementptr { i64, [3 x i64] }, ptr %t206, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t211, ptr %t212
  %t213 = load { i64, [3 x i64] }, ptr %t206
  %t215 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t213, ptr %t215
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t203, ptr %t215)
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edtorWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t16, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb9, label %bb10
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l17, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l18, !tbaa !27
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t32)
  store ptr %t34, ptr %l22
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 4
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = load ptr, ptr %l20, !tbaa !29
  %t43 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t40, ptr %t37, ptr %t38)
  store i32 %t43, ptr %l27
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l17, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t46 = load i32, ptr %l27, !tbaa !23
  %t47 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunendedArgs(ptr %v0, ptr %v1, ptr %t44, { i64, ptr } %t45, i32 %t46)
  store i1 %t47, ptr %l28
  br label %bb13
bb13:
  br label %bb14
bb14:
  br label %bb41
bb15:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t49 = load ptr, ptr %l29, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb16, label %bb17
bb16:
  %t52 = load ptr, ptr %l29, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 8}
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t56 = load i1, ptr %l30, !tbaa !21
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t59, i32 0, i32 1
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l3, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edtorWritten(ptr %v0, ptr %v1, ptr %t63, ptr %t64)
  br label %bb21
bb21:
  br label %bb41
bb22:
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t69 = load ptr, ptr %l38, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb23, label %bb24
bb23:
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 8}
  %t75 = icmp eq i64 %t73, 4
  store i1 %t75, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t76 = load i1, ptr %l39, !tbaa !21
  br i1 %t76, label %bb25, label %bb26
bb25:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t79, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l4, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edtorWritten(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  br label %bb28
bb28:
  br label %bb41
bb29:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t88 = load ptr, ptr %l46, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb30, label %bb31
bb30:
  %t91 = load ptr, ptr %l46, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 8}
  %t94 = icmp eq i64 %t92, 7
  store i1 %t94, ptr %l47, !tbaa !21
  br label %bb31
bb31:
  %t95 = load i1, ptr %l47, !tbaa !21
  br i1 %t95, label %bb32, label %bb33
bb32:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l5, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edtorWritten(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  br label %bb35
bb35:
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_ebc2467d8a71e8b5_ca2d5a069c6cca29)
  unreachable
bb41:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l103 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l126 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l135 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i1
  %l159 = alloca { i64, ptr }
  %l165 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l180 = alloca i1
  %l184 = alloca i1
  %l188 = alloca i1
  %l198 = alloca { i64, ptr }
  %l204 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i1
  %l221 = alloca i1
  %l223 = alloca i1
  %l232 = alloca { i64, ptr }
  %l238 = alloca i1
  %l243 = alloca ptr
  %l244 = alloca i1
  %l252 = alloca i1
  %l256 = alloca i1
  %l257 = alloca i1
  %l262 = alloca i1
  %l263 = alloca i1
  %l268 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca i1
  %l279 = alloca i1
  %l280 = alloca i1
  %l284 = alloca i1
  %l285 = alloca i1
  %l290 = alloca i1
  %l291 = alloca ptr
  %l292 = alloca i1
  %l300 = alloca i1
  %l301 = alloca i1
  %l305 = alloca i1
  %l306 = alloca ptr
  %l307 = alloca i1
  %l315 = alloca i1
  %l325 = alloca { i64, ptr }
  %l330 = alloca i1
  %l338 = alloca i1
  %l339 = alloca ptr
  %l345 = alloca i1
  %l346 = alloca ptr
  %l347 = alloca i1
  %l354 = alloca i1
  %l358 = alloca i1
  %l368 = alloca { i64, ptr }
  %l374 = alloca i1
  %l384 = alloca { i64, ptr }
  %l390 = alloca i1
  %l397 = alloca ptr
  %l398 = alloca i1
  %l406 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t7 = load ptr, ptr %l46, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l46, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l47, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l47, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t16 = load ptr, ptr %l50, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l50, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l51, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l51, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t25 = load ptr, ptr %l54, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l54, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 15
  store i1 %t31, ptr %l55, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l55, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t35 = load ptr, ptr %l59, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb18, label %bb19
bb18:
  %t38 = load ptr, ptr %l59, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l60, !tbaa !21
  br label %bb19
bb19:
  %t42 = load i1, ptr %l60, !tbaa !21
  br i1 %t42, label %bb20, label %bb21
bb20:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l2, !tbaa !29
  br label %bb30
bb21:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t50 = load ptr, ptr %l65, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb22, label %bb23
bb22:
  %t53 = load ptr, ptr %l65, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 18}
  %t56 = icmp eq i64 %t54, 3
  store i1 %t56, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t57 = load i1, ptr %l66, !tbaa !21
  br i1 %t57, label %bb24, label %bb25
bb24:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l2, !tbaa !29
  br label %bb30
bb25:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t65 = load ptr, ptr %l71, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb26, label %bb27
bb26:
  %t68 = load ptr, ptr %l71, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 4
  store i1 %t71, ptr %l72, !tbaa !21
  br label %bb27
bb27:
  %t72 = load i1, ptr %l72, !tbaa !21
  br i1 %t72, label %bb28, label %bb29
bb28:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l2, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t79, ptr %t80, i1 false)
  store i1 %t83, ptr %l79
  br label %bb31
bb31:
  %t84 = load i1, ptr %l79, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb32:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t86 = load ptr, ptr %l80, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t89 = load ptr, ptr %l80, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 5
  store i1 %t92, ptr %l81, !tbaa !21
  br label %bb34
bb34:
  %t93 = load i1, ptr %l81, !tbaa !21
  br i1 %t93, label %bb35, label %bb36
bb35:
  br label %bb45
bb36:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t95 = load ptr, ptr %l84, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb37, label %bb38
bb37:
  %t98 = load ptr, ptr %l84, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 18}
  %t101 = icmp eq i64 %t99, 16
  store i1 %t101, ptr %l85, !tbaa !21
  br label %bb38
bb38:
  %t102 = load i1, ptr %l85, !tbaa !21
  br i1 %t102, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t104 = load ptr, ptr %l88, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb41, label %bb42
bb41:
  %t107 = load ptr, ptr %l88, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 18}
  %t110 = icmp eq i64 %t108, 8
  store i1 %t110, ptr %l89, !tbaa !21
  br label %bb42
bb42:
  %t111 = load i1, ptr %l89, !tbaa !21
  br i1 %t111, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store i1 true, ptr %rv
  br label %ret
bb46:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t114 = load ptr, ptr %l93, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb47, label %bb48
bb47:
  %t117 = load ptr, ptr %l93, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 18}
  %t120 = icmp eq i64 %t118, 6
  store i1 %t120, ptr %l94, !tbaa !21
  br label %bb48
bb48:
  %t121 = load i1, ptr %l94, !tbaa !21
  br i1 %t121, label %bb49, label %bb50
bb49:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 1
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l3, !tbaa !23
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t130, i32 0, i32 2
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l4, !tbaa !29
  br label %bb51
bb50:
  br label %bb102
bb51:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l3, !tbaa !23
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l103
  br label %bb52
bb52:
  %t139 = load i1, ptr %l103, !tbaa !21
  br i1 %t139, label %bb53, label %bb54
bb53:
  store i1 true, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t141 = load ptr, ptr %l4, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Call", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  store ptr %t144, ptr %l5, !tbaa !29
  %t146 = load ptr, ptr %l5, !tbaa !29
  store ptr %t146, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t147 = load ptr, ptr %l107, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb56, label %bb57
bb56:
  %t150 = load ptr, ptr %l107, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 5}
  %t153 = icmp eq i64 %t151, 0
  store i1 %t153, ptr %l108, !tbaa !21
  br label %bb57
bb57:
  %t154 = load i1, ptr %l108, !tbaa !21
  br i1 %t154, label %bb58, label %bb59
bb58:
  %t155 = load ptr, ptr %l5, !tbaa !29
  %t157 = getelementptr { i64, [3 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { i32 }, ptr %t157, i32 0, i32 0
  %t159 = load i32, ptr %t158
  store i32 %t159, ptr %l6, !tbaa !23
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 108
  %t164 = load i32, ptr %l6, !tbaa !23
  %t166 = sext i32 %t164 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t163, i64 %t166)
  br label %bb61
bb61:
  br label %bb91
bb62:
  %t169 = load ptr, ptr %l5, !tbaa !29
  store ptr %t169, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t170 = load ptr, ptr %l117, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb63, label %bb64
bb63:
  %t173 = load ptr, ptr %l117, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 5}
  %t176 = icmp eq i64 %t174, 1
  store i1 %t176, ptr %l118, !tbaa !21
  br label %bb64
bb64:
  %t177 = load i1, ptr %l118, !tbaa !21
  br i1 %t177, label %bb65, label %bb66
bb65:
  %t178 = load ptr, ptr %l5, !tbaa !29
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { i64 }, ptr %t180, i32 0, i32 0
  %t182 = load i64, ptr %t181
  store i64 %t182, ptr %l7, !tbaa !24
  br label %bb67
bb66:
  br label %bb74
bb67:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t188 = load i64, ptr %l7, !tbaa !24
  %t191 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t187, i64 %t188)
  store ptr %t191, ptr %l126
  br label %bb68
bb68:
  %t192 = load ptr, ptr %l126, !tbaa !29
  store ptr %t192, ptr %l8, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr %"compiler/ast:Func", ptr %t194, i32 0, i32 2
  %t197 = load i32, ptr %t196, !tbaa !23
  %t200 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t193, i32 %t197)
  store { i64, ptr } %t200, ptr %l130
  br label %bb69
bb69:
  %t201 = load ptr, ptr %l8, !tbaa !29
  %t203 = getelementptr %"compiler/ast:Func", ptr %t201, i32 0, i32 3
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Sig", ptr %t204, i32 0, i32 0
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t212 = call i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %t210, i64 %t209)
  store i1 %t212, ptr %l135
  br label %bb70
bb70:
  %t213 = load i1, ptr %l135, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb71, label %bb72
bb71:
  store i1 true, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  br label %bb91
bb74:
  %t217 = load ptr, ptr %l5, !tbaa !29
  store ptr %t217, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t218 = load ptr, ptr %l138, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb75, label %bb76
bb75:
  %t221 = load ptr, ptr %l138, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 5}
  %t224 = icmp eq i64 %t222, 2
  store i1 %t224, ptr %l139, !tbaa !21
  br label %bb76
bb76:
  %t225 = load i1, ptr %l139, !tbaa !21
  br i1 %t225, label %bb77, label %bb78
bb77:
  br label %bb83
bb78:
  %t226 = load ptr, ptr %l5, !tbaa !29
  store ptr %t226, ptr %l142, !tbaa !29
  store i1 false, ptr %l143, !tbaa !21
  %t227 = load ptr, ptr %l142, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb79, label %bb80
bb79:
  %t230 = load ptr, ptr %l142, !tbaa !29
  %t231 = load i64, ptr %t230, !range !{i64 0, i64 5}
  %t233 = icmp eq i64 %t231, 3
  store i1 %t233, ptr %l143, !tbaa !21
  br label %bb80
bb80:
  %t234 = load i1, ptr %l143, !tbaa !21
  br i1 %t234, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  store i1 true, ptr %rv
  br label %ret
bb84:
  %t236 = load ptr, ptr %l5, !tbaa !29
  store ptr %t236, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t237 = load ptr, ptr %l147, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb85, label %bb86
bb85:
  %t240 = load ptr, ptr %l147, !tbaa !29
  %t241 = load i64, ptr %t240, !range !{i64 0, i64 5}
  %t243 = icmp eq i64 %t241, 4
  store i1 %t243, ptr %l148, !tbaa !21
  br label %bb86
bb86:
  %t244 = load i1, ptr %l148, !tbaa !21
  br i1 %t244, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_d97e23b04dcff800_367dc3876d150fb4)
  unreachable
bb91:
  %t245 = load ptr, ptr %l4, !tbaa !29
  %t247 = getelementptr %"compiler/typed:Call", ptr %t245, i32 0, i32 1
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  store i64 %t252, ptr %l11, !tbaa !24
  br label %bb92
bb92:
  %t254 = load i64, ptr %l10, !tbaa !24
  %t255 = load i64, ptr %l11, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb93, label %bb94
bb93:
  br label %bb101
bb94:
  br label %bb95
bb95:
  %t262 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t262, ptr %l159, !tbaa !27
  %t263 = load i64, ptr %l10, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr ptr, ptr %t266, i64 %t263
  %t268 = load ptr, ptr %t267, !tbaa !39
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t275 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t270, ptr %t268)
  store i1 %t275, ptr %l165
  br label %bb96
bb96:
  %t276 = load i1, ptr %l165, !tbaa !21
  br i1 %t276, label %bb97, label %bb98
bb97:
  store i1 true, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t278 = load i64, ptr %l10, !tbaa !24
  %t280 = add i64 %t278, 1
  store i64 %t280, ptr %l10, !tbaa !24
  br label %bb92
bb101:
  store i1 false, ptr %rv
  br label %ret
bb102:
  %t283 = load ptr, ptr %l1, !tbaa !29
  store ptr %t283, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t284 = load ptr, ptr %l170, !tbaa !29
  %t285 = icmp ne ptr %t284, null
  br i1 %t285, label %bb103, label %bb104
bb103:
  %t287 = load ptr, ptr %l170, !tbaa !29
  %t288 = load i64, ptr %t287, !range !{i64 0, i64 18}
  %t290 = icmp eq i64 %t288, 7
  store i1 %t290, ptr %l171, !tbaa !21
  br label %bb104
bb104:
  %t291 = load i1, ptr %l171, !tbaa !21
  br i1 %t291, label %bb105, label %bb106
bb105:
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr { i64, [5 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t294, i32 0, i32 2
  %t296 = load ptr, ptr %t295
  store ptr %t296, ptr %l13, !tbaa !29
  br label %bb107
bb106:
  br label %bb128
bb107:
  %t298 = load ptr, ptr %l13, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Make", ptr %t298, i32 0, i32 4
  %t301 = load i32, ptr %t300, !tbaa !23
  %t303 = sext i32 %t301 to i64
  %t305 = icmp sge i64 %t303, 0
  br i1 %t305, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l180, !tbaa !21
  br label %bb110
bb109:
  %t307 = load ptr, ptr %l13, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Make", ptr %t307, i32 0, i32 5
  %t310 = load i32, ptr %t309, !range !{i32 0, i32 3}
  %t312 = trunc i64 1 to i32
  %t313 = icmp eq i32 %t310, %t312
  store i1 %t313, ptr %l180, !tbaa !21
  br label %bb110
bb110:
  %t315 = load i1, ptr %l180, !tbaa !21
  br i1 %t315, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l184, !tbaa !21
  br label %bb114
bb112:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l13, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Make", ptr %t317, i32 0, i32 3
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t323 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t316, ptr %t320)
  store i1 %t323, ptr %l188
  br label %bb113
bb113:
  %t324 = load i1, ptr %l188, !tbaa !21
  store i1 %t324, ptr %l184, !tbaa !21
  br label %bb114
bb114:
  %t325 = load i1, ptr %l184, !tbaa !21
  br i1 %t325, label %bb115, label %bb116
bb115:
  store i1 true, ptr %rv
  br label %ret
bb116:
  br label %bb117
bb117:
  %t327 = load ptr, ptr %l13, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Make", ptr %t327, i32 0, i32 2
  %t330 = load { i64, ptr }, ptr %t329, !tbaa !27
  store { i64, ptr } %t330, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t332 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t332, 0
  store i64 %t334, ptr %l16, !tbaa !24
  br label %bb118
bb118:
  %t336 = load i64, ptr %l15, !tbaa !24
  %t337 = load i64, ptr %l16, !tbaa !24
  %t340 = icmp slt i64 %t336, %t337
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb119, label %bb120
bb119:
  br label %bb127
bb120:
  br label %bb121
bb121:
  %t344 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t344, ptr %l198, !tbaa !27
  %t345 = load i64, ptr %l15, !tbaa !24
  %t347 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr ptr, ptr %t348, i64 %t345
  %t350 = load ptr, ptr %t349, !tbaa !39
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t357 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t352, ptr %t350)
  store i1 %t357, ptr %l204
  br label %bb122
bb122:
  %t358 = load i1, ptr %l204, !tbaa !21
  br i1 %t358, label %bb123, label %bb124
bb123:
  store i1 true, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  %t360 = load i64, ptr %l15, !tbaa !24
  %t362 = add i64 %t360, 1
  store i64 %t362, ptr %l15, !tbaa !24
  br label %bb118
bb127:
  store i1 false, ptr %rv
  br label %ret
bb128:
  %t365 = load ptr, ptr %l1, !tbaa !29
  store ptr %t365, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t366 = load ptr, ptr %l209, !tbaa !29
  %t367 = icmp ne ptr %t366, null
  br i1 %t367, label %bb129, label %bb130
bb129:
  %t369 = load ptr, ptr %l209, !tbaa !29
  %t370 = load i64, ptr %t369, !range !{i64 0, i64 18}
  %t372 = icmp eq i64 %t370, 9
  store i1 %t372, ptr %l210, !tbaa !21
  br label %bb130
bb130:
  %t373 = load i1, ptr %l210, !tbaa !21
  br i1 %t373, label %bb131, label %bb132
bb131:
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t376 = getelementptr { i64, [5 x i64] }, ptr %t374, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t376, i32 0, i32 2
  %t378 = load i32, ptr %t377, !range !{i32 0, i32 52}
  store i32 %t378, ptr %l18
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t382, i32 0, i32 3
  %t384 = load i32, ptr %t383, !range !{i32 0, i32 3}
  store i32 %t384, ptr %l19
  %t386 = load ptr, ptr %l1, !tbaa !29
  %t388 = getelementptr { i64, [5 x i64] }, ptr %t386, i32 0, i32 1
  %t389 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t388, i32 0, i32 4
  %t390 = load { i64, ptr }, ptr %t389
  store { i64, ptr } %t390, ptr %l20, !tbaa !27
  br label %bb133
bb132:
  br label %bb151
bb133:
  %t392 = load i32, ptr %l19, !range !{i32 0, i32 3}
  %t394 = trunc i64 1 to i32
  %t395 = icmp eq i32 %t392, %t394
  br i1 %t395, label %bb134, label %bb135
bb134:
  store i1 true, ptr %l221, !tbaa !21
  br label %bb137
bb135:
  %t397 = load i32, ptr %l18, !range !{i32 0, i32 52}
  %t399 = call i1 @compiler_2fcheck_2eeffectOp(i32 %t397)
  store i1 %t399, ptr %l223
  br label %bb136
bb136:
  %t400 = load i1, ptr %l223, !tbaa !21
  store i1 %t400, ptr %l221, !tbaa !21
  br label %bb137
bb137:
  %t401 = load i1, ptr %l221, !tbaa !21
  br i1 %t401, label %bb138, label %bb139
bb138:
  store i1 true, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  %t403 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t403, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t405 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t405, 0
  store i64 %t407, ptr %l23, !tbaa !24
  br label %bb141
bb141:
  %t409 = load i64, ptr %l22, !tbaa !24
  %t410 = load i64, ptr %l23, !tbaa !24
  %t413 = icmp slt i64 %t409, %t410
  %t415 = xor i1 %t413, true
  br i1 %t415, label %bb142, label %bb143
bb142:
  br label %bb150
bb143:
  br label %bb144
bb144:
  %t417 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t417, ptr %l232, !tbaa !27
  %t418 = load i64, ptr %l22, !tbaa !24
  %t420 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr ptr, ptr %t421, i64 %t418
  %t423 = load ptr, ptr %t422, !tbaa !39
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t430 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t425, ptr %t423)
  store i1 %t430, ptr %l238
  br label %bb145
bb145:
  %t431 = load i1, ptr %l238, !tbaa !21
  br i1 %t431, label %bb146, label %bb147
bb146:
  store i1 true, ptr %rv
  br label %ret
bb147:
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t433 = load i64, ptr %l22, !tbaa !24
  %t435 = add i64 %t433, 1
  store i64 %t435, ptr %l22, !tbaa !24
  br label %bb141
bb150:
  store i1 false, ptr %rv
  br label %ret
bb151:
  %t438 = load ptr, ptr %l1, !tbaa !29
  store ptr %t438, ptr %l243, !tbaa !29
  store i1 false, ptr %l244, !tbaa !21
  %t439 = load ptr, ptr %l243, !tbaa !29
  %t440 = icmp ne ptr %t439, null
  br i1 %t440, label %bb152, label %bb153
bb152:
  %t442 = load ptr, ptr %l243, !tbaa !29
  %t443 = load i64, ptr %t442, !range !{i64 0, i64 18}
  %t445 = icmp eq i64 %t443, 10
  store i1 %t445, ptr %l244, !tbaa !21
  br label %bb153
bb153:
  %t446 = load i1, ptr %l244, !tbaa !21
  br i1 %t446, label %bb154, label %bb155
bb154:
  %t447 = load ptr, ptr %l1, !tbaa !29
  %t449 = getelementptr { i64, [5 x i64] }, ptr %t447, i32 0, i32 1
  %t450 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t449, i32 0, i32 2
  %t451 = load ptr, ptr %t450
  store ptr %t451, ptr %l25, !tbaa !29
  br label %bb156
bb155:
  br label %bb169
bb156:
  %t453 = load ptr, ptr %l25, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Slice", ptr %t453, i32 0, i32 3
  %t456 = load i32, ptr %t455, !range !{i32 0, i32 3}
  %t458 = trunc i64 1 to i32
  %t459 = icmp eq i32 %t456, %t458
  br i1 %t459, label %bb157, label %bb158
bb157:
  store i1 true, ptr %l252, !tbaa !21
  br label %bb160
bb158:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load ptr, ptr %l25, !tbaa !29
  %t464 = getelementptr %"compiler/typed:Slice", ptr %t462, i32 0, i32 0
  %t465 = load ptr, ptr %t464, !tbaa !29
  %t468 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %t461, ptr %t465, i1 false)
  store i1 %t468, ptr %l256
  br label %bb159
bb159:
  %t469 = load i1, ptr %l256, !tbaa !21
  store i1 %t469, ptr %l252, !tbaa !21
  br label %bb160
bb160:
  %t470 = load i1, ptr %l252, !tbaa !21
  br i1 %t470, label %bb161, label %bb162
bb161:
  store i1 true, ptr %l257, !tbaa !21
  br label %bb164
bb162:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load ptr, ptr %l25, !tbaa !29
  %t474 = getelementptr %"compiler/typed:Slice", ptr %t472, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t479 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t471, ptr %t475)
  store i1 %t479, ptr %l262
  br label %bb163
bb163:
  %t480 = load i1, ptr %l262, !tbaa !21
  store i1 %t480, ptr %l257, !tbaa !21
  br label %bb164
bb164:
  %t481 = load i1, ptr %l257, !tbaa !21
  br i1 %t481, label %bb165, label %bb166
bb165:
  store i1 true, ptr %l263, !tbaa !21
  br label %bb168
bb166:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load ptr, ptr %l25, !tbaa !29
  %t485 = getelementptr %"compiler/typed:Slice", ptr %t483, i32 0, i32 2
  %t486 = load ptr, ptr %t485, !tbaa !29
  %t490 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t482, ptr %t486)
  store i1 %t490, ptr %l268
  br label %bb167
bb167:
  %t491 = load i1, ptr %l268, !tbaa !21
  store i1 %t491, ptr %l263, !tbaa !21
  br label %bb168
bb168:
  %t492 = load i1, ptr %l263, !tbaa !21
  store i1 %t492, ptr %rv
  br label %ret
bb169:
  %t493 = load ptr, ptr %l1, !tbaa !29
  store ptr %t493, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t494 = load ptr, ptr %l269, !tbaa !29
  %t495 = icmp ne ptr %t494, null
  br i1 %t495, label %bb170, label %bb171
bb170:
  %t497 = load ptr, ptr %l269, !tbaa !29
  %t498 = load i64, ptr %t497, !range !{i64 0, i64 18}
  %t500 = icmp eq i64 %t498, 11
  store i1 %t500, ptr %l270, !tbaa !21
  br label %bb171
bb171:
  %t501 = load i1, ptr %l270, !tbaa !21
  br i1 %t501, label %bb172, label %bb173
bb172:
  %t502 = load ptr, ptr %l1, !tbaa !29
  %t504 = getelementptr { i64, [5 x i64] }, ptr %t502, i32 0, i32 1
  %t505 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t504, i32 0, i32 2
  %t506 = load ptr, ptr %t505
  store ptr %t506, ptr %l26, !tbaa !29
  br label %bb174
bb173:
  br label %bb184
bb174:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load ptr, ptr %l26, !tbaa !29
  %t511 = getelementptr %"compiler/typed:Cond", ptr %t509, i32 0, i32 0
  %t512 = load ptr, ptr %t511, !tbaa !29
  %t516 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t508, ptr %t512)
  store i1 %t516, ptr %l279
  br label %bb175
bb175:
  %t517 = load i1, ptr %l279, !tbaa !21
  br i1 %t517, label %bb176, label %bb177
bb176:
  store i1 true, ptr %l280, !tbaa !21
  br label %bb179
bb177:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load ptr, ptr %l26, !tbaa !29
  %t521 = getelementptr %"compiler/typed:Cond", ptr %t519, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t525 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t518, ptr %t522)
  store i1 %t525, ptr %l284
  br label %bb178
bb178:
  %t526 = load i1, ptr %l284, !tbaa !21
  store i1 %t526, ptr %l280, !tbaa !21
  br label %bb179
bb179:
  %t527 = load i1, ptr %l280, !tbaa !21
  br i1 %t527, label %bb180, label %bb181
bb180:
  store i1 true, ptr %l285, !tbaa !21
  br label %bb183
bb181:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load ptr, ptr %l26, !tbaa !29
  %t531 = getelementptr %"compiler/typed:Cond", ptr %t529, i32 0, i32 2
  %t532 = load ptr, ptr %t531, !tbaa !29
  %t536 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t528, ptr %t532)
  store i1 %t536, ptr %l290
  br label %bb182
bb182:
  %t537 = load i1, ptr %l290, !tbaa !21
  store i1 %t537, ptr %l285, !tbaa !21
  br label %bb183
bb183:
  %t538 = load i1, ptr %l285, !tbaa !21
  store i1 %t538, ptr %rv
  br label %ret
bb184:
  %t539 = load ptr, ptr %l1, !tbaa !29
  store ptr %t539, ptr %l291, !tbaa !29
  store i1 false, ptr %l292, !tbaa !21
  %t540 = load ptr, ptr %l291, !tbaa !29
  %t541 = icmp ne ptr %t540, null
  br i1 %t541, label %bb185, label %bb186
bb185:
  %t543 = load ptr, ptr %l291, !tbaa !29
  %t544 = load i64, ptr %t543, !range !{i64 0, i64 18}
  %t546 = icmp eq i64 %t544, 12
  store i1 %t546, ptr %l292, !tbaa !21
  br label %bb186
bb186:
  %t547 = load i1, ptr %l292, !tbaa !21
  br i1 %t547, label %bb187, label %bb188
bb187:
  %t548 = load ptr, ptr %l1, !tbaa !29
  %t550 = getelementptr { i64, [5 x i64] }, ptr %t548, i32 0, i32 1
  %t551 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t550, i32 0, i32 2
  %t552 = load ptr, ptr %t551
  store ptr %t552, ptr %l27, !tbaa !29
  br label %bb189
bb188:
  br label %bb195
bb189:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load ptr, ptr %l27, !tbaa !29
  %t557 = getelementptr %"compiler/typed:Seq", ptr %t555, i32 0, i32 0
  %t558 = load { i64, ptr }, ptr %t557, !tbaa !27
  %t561 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %t554, { i64, ptr } %t558)
  store i1 %t561, ptr %l300
  br label %bb190
bb190:
  %t562 = load i1, ptr %l300, !tbaa !21
  br i1 %t562, label %bb191, label %bb192
bb191:
  store i1 true, ptr %l301, !tbaa !21
  br label %bb194
bb192:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load ptr, ptr %l27, !tbaa !29
  %t566 = getelementptr %"compiler/typed:Seq", ptr %t564, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !29
  %t570 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t563, ptr %t567)
  store i1 %t570, ptr %l305
  br label %bb193
bb193:
  %t571 = load i1, ptr %l305, !tbaa !21
  store i1 %t571, ptr %l301, !tbaa !21
  br label %bb194
bb194:
  %t572 = load i1, ptr %l301, !tbaa !21
  store i1 %t572, ptr %rv
  br label %ret
bb195:
  %t573 = load ptr, ptr %l1, !tbaa !29
  store ptr %t573, ptr %l306, !tbaa !29
  store i1 false, ptr %l307, !tbaa !21
  %t574 = load ptr, ptr %l306, !tbaa !29
  %t575 = icmp ne ptr %t574, null
  br i1 %t575, label %bb196, label %bb197
bb196:
  %t577 = load ptr, ptr %l306, !tbaa !29
  %t578 = load i64, ptr %t577, !range !{i64 0, i64 18}
  %t580 = icmp eq i64 %t578, 13
  store i1 %t580, ptr %l307, !tbaa !21
  br label %bb197
bb197:
  %t581 = load i1, ptr %l307, !tbaa !21
  br i1 %t581, label %bb198, label %bb199
bb198:
  %t582 = load ptr, ptr %l1, !tbaa !29
  %t584 = getelementptr { i64, [5 x i64] }, ptr %t582, i32 0, i32 1
  %t585 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t584, i32 0, i32 2
  %t586 = load ptr, ptr %t585
  store ptr %t586, ptr %l28, !tbaa !29
  br label %bb200
bb199:
  br label %bb222
bb200:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load ptr, ptr %l28, !tbaa !29
  %t591 = getelementptr %"compiler/typed:Match", ptr %t589, i32 0, i32 0
  %t592 = load { i64, ptr }, ptr %t591, !tbaa !27
  %t595 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %t588, { i64, ptr } %t592)
  store i1 %t595, ptr %l315
  br label %bb201
bb201:
  %t596 = load i1, ptr %l315, !tbaa !21
  br i1 %t596, label %bb202, label %bb203
bb202:
  store i1 true, ptr %rv
  br label %ret
bb203:
  br label %bb204
bb204:
  %t598 = load ptr, ptr %l28, !tbaa !29
  %t600 = getelementptr %"compiler/typed:Match", ptr %t598, i32 0, i32 1
  %t601 = load { i64, ptr }, ptr %t600, !tbaa !27
  store { i64, ptr } %t601, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t603 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t605 = extractvalue { i64, ptr } %t603, 0
  store i64 %t605, ptr %l31, !tbaa !24
  br label %bb205
bb205:
  %t607 = load i64, ptr %l30, !tbaa !24
  %t608 = load i64, ptr %l31, !tbaa !24
  %t611 = icmp slt i64 %t607, %t608
  %t613 = xor i1 %t611, true
  br i1 %t613, label %bb206, label %bb207
bb206:
  br label %bb214
bb207:
  br label %bb208
bb208:
  %t615 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t615, ptr %l325, !tbaa !27
  %t616 = load i64, ptr %l30, !tbaa !24
  %t618 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t619 = load ptr, ptr %t618, !tbaa !27
  %t620 = getelementptr ptr, ptr %t619, i64 %t616
  %t621 = load ptr, ptr %t620, !tbaa !39
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t627 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %t623, ptr %t621)
  store i1 %t627, ptr %l330
  br label %bb209
bb209:
  %t628 = load i1, ptr %l330, !tbaa !21
  br i1 %t628, label %bb210, label %bb211
bb210:
  store i1 true, ptr %rv
  br label %ret
bb211:
  br label %bb212
bb212:
  br label %bb213
bb213:
  %t630 = load i64, ptr %l30, !tbaa !24
  %t632 = add i64 %t630, 1
  store i64 %t632, ptr %l30, !tbaa !24
  br label %bb205
bb214:
  %t634 = load ptr, ptr %l28, !tbaa !29
  %t636 = getelementptr %"compiler/typed:Match", ptr %t634, i32 0, i32 2
  %t637 = load ptr, ptr %t636, !tbaa !29
  %t639 = icmp eq ptr %t637, null
  %t641 = xor i1 %t639, true
  br i1 %t641, label %bb215, label %bb216
bb215:
  %t643 = load ptr, ptr %l0, !tbaa !29
  store ptr %t643, ptr %l339, !tbaa !29
  %t644 = load ptr, ptr %l28, !tbaa !29
  %t646 = getelementptr %"compiler/typed:Match", ptr %t644, i32 0, i32 2
  %t647 = load ptr, ptr %t646, !tbaa !29
  %t649 = icmp eq ptr %t647, null
  br i1 %t649, label %bb217, label %bb218
bb216:
  store i1 false, ptr %l338, !tbaa !21
  br label %bb221
bb217:
  call void @__olang_check_failed(ptr @olang_loc_ad4dc9fe288360e2_6bae22496d237a26)
  unreachable
bb218:
  br label %bb219
bb219:
  %t651 = load ptr, ptr %l28, !tbaa !29
  %t653 = getelementptr %"compiler/typed:Match", ptr %t651, i32 0, i32 2
  %t654 = load ptr, ptr %t653, !tbaa !29
  %t655 = load ptr, ptr %l339, !tbaa !29
  %t657 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %t655, ptr %t654)
  store i1 %t657, ptr %l345
  br label %bb220
bb220:
  %t658 = load i1, ptr %l345, !tbaa !21
  store i1 %t658, ptr %l338, !tbaa !21
  br label %bb221
bb221:
  %t659 = load i1, ptr %l338, !tbaa !21
  store i1 %t659, ptr %rv
  br label %ret
bb222:
  %t660 = load ptr, ptr %l1, !tbaa !29
  store ptr %t660, ptr %l346, !tbaa !29
  store i1 false, ptr %l347, !tbaa !21
  %t661 = load ptr, ptr %l346, !tbaa !29
  %t662 = icmp ne ptr %t661, null
  br i1 %t662, label %bb223, label %bb224
bb223:
  %t664 = load ptr, ptr %l346, !tbaa !29
  %t665 = load i64, ptr %t664, !range !{i64 0, i64 18}
  %t667 = icmp eq i64 %t665, 14
  store i1 %t667, ptr %l347, !tbaa !21
  br label %bb224
bb224:
  %t668 = load i1, ptr %l347, !tbaa !21
  br i1 %t668, label %bb225, label %bb226
bb225:
  %t669 = load ptr, ptr %l1, !tbaa !29
  %t671 = getelementptr { i64, [5 x i64] }, ptr %t669, i32 0, i32 1
  %t672 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t671, i32 0, i32 2
  %t673 = load ptr, ptr %t672
  store ptr %t673, ptr %l33, !tbaa !29
  br label %bb227
bb226:
  br label %bb255
bb227:
  %t675 = load ptr, ptr %l33, !tbaa !29
  %t677 = getelementptr %"compiler/typed:Try", ptr %t675, i32 0, i32 2
  %t678 = load i1, ptr %t677, !tbaa !21
  br i1 %t678, label %bb228, label %bb229
bb228:
  store i1 true, ptr %l354, !tbaa !21
  br label %bb231
bb229:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load ptr, ptr %l33, !tbaa !29
  %t683 = getelementptr %"compiler/typed:Try", ptr %t681, i32 0, i32 0
  %t684 = load ptr, ptr %t683, !tbaa !29
  %t687 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t680, ptr %t684)
  store i1 %t687, ptr %l358
  br label %bb230
bb230:
  %t688 = load i1, ptr %l358, !tbaa !21
  store i1 %t688, ptr %l354, !tbaa !21
  br label %bb231
bb231:
  %t689 = load i1, ptr %l354, !tbaa !21
  br i1 %t689, label %bb232, label %bb233
bb232:
  store i1 true, ptr %rv
  br label %ret
bb233:
  br label %bb234
bb234:
  %t691 = load ptr, ptr %l33, !tbaa !29
  %t693 = getelementptr %"compiler/typed:Try", ptr %t691, i32 0, i32 1
  %t694 = load { i64, ptr }, ptr %t693, !tbaa !27
  store { i64, ptr } %t694, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t696 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t698 = extractvalue { i64, ptr } %t696, 0
  store i64 %t698, ptr %l36, !tbaa !24
  br label %bb235
bb235:
  %t700 = load i64, ptr %l35, !tbaa !24
  %t701 = load i64, ptr %l36, !tbaa !24
  %t704 = icmp slt i64 %t700, %t701
  %t706 = xor i1 %t704, true
  br i1 %t706, label %bb236, label %bb237
bb236:
  br label %bb254
bb237:
  br label %bb238
bb238:
  %t708 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t708, ptr %l368, !tbaa !27
  %t709 = load i64, ptr %l35, !tbaa !24
  %t711 = getelementptr { i64, ptr }, ptr %l368, i32 0, i32 1
  %t712 = load ptr, ptr %t711, !tbaa !27
  %t713 = getelementptr ptr, ptr %t712, i64 %t709
  %t714 = load ptr, ptr %t713, !tbaa !39
  store ptr %t714, ptr %l37, !tbaa !29
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = load ptr, ptr %l37, !tbaa !29
  %t719 = getelementptr %"compiler/typed:Clause", ptr %t717, i32 0, i32 3
  %t720 = load ptr, ptr %t719, !tbaa !29
  %t723 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %t716, ptr %t720)
  store i1 %t723, ptr %l374
  br label %bb239
bb239:
  %t724 = load i1, ptr %l374, !tbaa !21
  br i1 %t724, label %bb240, label %bb241
bb240:
  store i1 true, ptr %rv
  br label %ret
bb241:
  br label %bb242
bb242:
  %t726 = load ptr, ptr %l37, !tbaa !29
  %t728 = getelementptr %"compiler/typed:Clause", ptr %t726, i32 0, i32 4
  %t729 = load { i64, ptr }, ptr %t728, !tbaa !27
  store { i64, ptr } %t729, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t731 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t733 = extractvalue { i64, ptr } %t731, 0
  store i64 %t733, ptr %l40, !tbaa !24
  br label %bb243
bb243:
  %t735 = load i64, ptr %l39, !tbaa !24
  %t736 = load i64, ptr %l40, !tbaa !24
  %t739 = icmp slt i64 %t735, %t736
  %t741 = xor i1 %t739, true
  br i1 %t741, label %bb244, label %bb245
bb244:
  br label %bb252
bb245:
  br label %bb246
bb246:
  %t743 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t743, ptr %l384, !tbaa !27
  %t744 = load i64, ptr %l39, !tbaa !24
  %t746 = getelementptr { i64, ptr }, ptr %l384, i32 0, i32 1
  %t747 = load ptr, ptr %t746, !tbaa !27
  %t748 = getelementptr ptr, ptr %t747, i64 %t744
  %t749 = load ptr, ptr %t748, !tbaa !39
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t756 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t751, ptr %t749)
  store i1 %t756, ptr %l390
  br label %bb247
bb247:
  %t757 = load i1, ptr %l390, !tbaa !21
  br i1 %t757, label %bb248, label %bb249
bb248:
  store i1 true, ptr %rv
  br label %ret
bb249:
  br label %bb250
bb250:
  br label %bb251
bb251:
  %t759 = load i64, ptr %l39, !tbaa !24
  %t761 = add i64 %t759, 1
  store i64 %t761, ptr %l39, !tbaa !24
  br label %bb243
bb252:
  br label %bb253
bb253:
  %t763 = load i64, ptr %l35, !tbaa !24
  %t765 = add i64 %t763, 1
  store i64 %t765, ptr %l35, !tbaa !24
  br label %bb235
bb254:
  store i1 false, ptr %rv
  br label %ret
bb255:
  %t768 = load ptr, ptr %l1, !tbaa !29
  store ptr %t768, ptr %l397, !tbaa !29
  store i1 false, ptr %l398, !tbaa !21
  %t769 = load ptr, ptr %l397, !tbaa !29
  %t770 = icmp ne ptr %t769, null
  br i1 %t770, label %bb256, label %bb257
bb256:
  %t772 = load ptr, ptr %l397, !tbaa !29
  %t773 = load i64, ptr %t772, !range !{i64 0, i64 18}
  %t775 = icmp eq i64 %t773, 17
  store i1 %t775, ptr %l398, !tbaa !21
  br label %bb257
bb257:
  %t776 = load i1, ptr %l398, !tbaa !21
  br i1 %t776, label %bb258, label %bb259
bb258:
  %t777 = load ptr, ptr %l1, !tbaa !29
  %t779 = getelementptr { i64, [5 x i64] }, ptr %t777, i32 0, i32 1
  %t780 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t779, i32 0, i32 2
  %t781 = load ptr, ptr %t780
  store ptr %t781, ptr %l42, !tbaa !29
  br label %bb260
bb259:
  br label %bb262
bb260:
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load ptr, ptr %l42, !tbaa !29
  %t788 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t783, ptr %t784)
  store i1 %t788, ptr %l406
  br label %bb261
bb261:
  %t789 = load i1, ptr %l406, !tbaa !21
  store i1 %t789, ptr %rv
  br label %ret
bb262:
  call void @__olang_check_failed(ptr @olang_loc_29ea0c7d0dcef6fa_322b22c08f06752e)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrBefore(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l28 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l40 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca ptr
  %l51 = alloca i1
  %l55 = alloca i1
  %l56 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l70 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l14
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l15
  br label %bb2
bb2:
  %t20 = load i32, ptr %l15, !tbaa !23
  store i32 %t20, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t32, i32 %a2)
  store i32 %t36, ptr %l23
  br label %bb3
bb3:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l23, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l24
  br label %bb4
bb4:
  %t40 = load i32, ptr %l24, !tbaa !23
  store i32 %t40, ptr %l4, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 10
  store ptr %t49, ptr %l28, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t55, i32 %t56)
  store i64 %t59, ptr %l33
  br label %bb5
bb5:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %l33, !tbaa !24
  %t62 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store ptr %t62, ptr %l34
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t65 = getelementptr %"compiler/load:Module", ptr %t63, i32 0, i32 2
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l5, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/load:Loader", ptr %t74, i32 0, i32 10
  store ptr %t76, ptr %l40, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t82, i32 %t83)
  store i64 %t86, ptr %l45
  br label %bb7
bb7:
  %t87 = load ptr, ptr %l40, !tbaa !29
  %t88 = load i64, ptr %l45, !tbaa !24
  %t89 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t87, i64 %t88)
  store ptr %t89, ptr %l46
  br label %bb8
bb8:
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t92 = getelementptr %"compiler/load:Module", ptr %t90, i32 0, i32 2
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l6, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t95, { i64, ptr } %t96)
  store i1 %t99, ptr %l51
  br label %bb9
bb9:
  %t100 = load i1, ptr %l51, !tbaa !21
  %t101 = xor i1 %t100, true
  br i1 %t101, label %bb10, label %bb11
bb10:
  %t103 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v0, { i64, ptr } %t103, { i64, ptr } %t104)
  store i1 %t107, ptr %l55
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t108 = load i1, ptr %l55, !tbaa !21
  store i1 %t108, ptr %rv
  br label %ret
bb13:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l56, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l3, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l61
  br label %bb14
bb14:
  %t120 = load ptr, ptr %l56, !tbaa !29
  %t121 = load i32, ptr %l61, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t120, i32 %t121)
  store { i64, ptr } %t122, ptr %l62
  br label %bb15
bb15:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l63, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l4, !tbaa !23
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t133, ptr %l68
  br label %bb16
bb16:
  %t134 = load ptr, ptr %l63, !tbaa !29
  %t135 = load i32, ptr %l68, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t134, i32 %t135)
  store { i64, ptr } %t136, ptr %l69
  br label %bb17
bb17:
  %t137 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v0, { i64, ptr } %t137, { i64, ptr } %t138)
  store i1 %t139, ptr %l70
  br label %bb18
bb18:
  %t140 = load i1, ptr %l70, !tbaa !21
  store i1 %t140, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l47 = alloca i32
  %l49 = alloca i64
  %l51 = alloca i64
  %l56 = alloca i32
  %l61 = alloca i32
  %l67 = alloca i64
  %l70 = alloca i64
  %l91 = alloca { i64, ptr }
  %l94 = alloca i32
  %l105 = alloca { i64, ptr }
  %l108 = alloca i64
  %l111 = alloca i64
  %l117 = alloca i64
  %l122 = alloca ptr
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca i32
  %l125 = alloca i32
  %l126 = alloca ptr
  %l130 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca i32
  %l136 = alloca i32
  %l137 = alloca ptr
  %l143 = alloca ptr
  %l145 = alloca ptr
  %l151 = alloca i64
  %l157 = alloca i64
  %l160 = alloca i64
  %l179 = alloca i64
  %l183 = alloca ptr
  %l184 = alloca %"compiler/source:Span"
  %l185 = alloca i32
  %l186 = alloca i32
  %l187 = alloca ptr
  %l188 = alloca ptr
  %l189 = alloca %"compiler/source:Span"
  %l192 = alloca i32
  %l198 = alloca ptr
  %l200 = alloca ptr
  %l203 = alloca ptr
  %l213 = alloca ptr
  %l221 = alloca ptr
  %l228 = alloca ptr
  %l232 = alloca ptr
  %l241 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l32, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l35, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t13)
  store i32 %t16, ptr %l38
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l35, !tbaa !29
  %t18 = load i32, ptr %l38, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l39
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l32, !tbaa !29
  %t21 = load i32, ptr %l39, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t20, i32 %t21)
  store { i64, ptr } %t22, ptr %l40
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCode(ptr %v0, ptr %v1, ptr %v3, ptr %t24, ptr %t25)
  store ptr %t28, ptr %l43
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l43, !tbaa !29
  store ptr %t29, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t35, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i32 %t37, ptr %l47
  br label %bb5
bb5:
  %t38 = load i32, ptr %l47, !tbaa !23
  store i32 %t38, ptr %l6, !tbaa !23
  store ptr null, ptr %l7, !tbaa !29
  store ptr %a3, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t41 = load i64, ptr %l9, !tbaa !24
  store i64 %t41, ptr %l49, !tbaa !24
  %t42 = load ptr, ptr %l8, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t42)
  store i64 %t44, ptr %l51
  br label %bb7
bb7:
  %t45 = load i64, ptr %l49, !tbaa !24
  %t46 = load i64, ptr %l51, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  br label %bb73
bb9:
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l8, !tbaa !29
  %t52 = load i64, ptr %l9, !tbaa !24
  %t55 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t51, i64 %t52)
  store i32 %t55, ptr %l56
  br label %bb11
bb11:
  %t56 = load i32, ptr %l56, !tbaa !23
  store i32 %t56, ptr %l10, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l10, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l61
  br label %bb12
bb12:
  %t67 = load i32, ptr %l61, !tbaa !23
  store i32 %t67, ptr %l11, !tbaa !23
  store i64 -1, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t72 = load i64, ptr %l14, !tbaa !24
  %t73 = load i64, ptr %l13, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb13, label %bb14
bb13:
  %t78 = load i64, ptr %l15, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb18
bb15:
  %t82 = load i64, ptr %l14, !tbaa !24
  %t83 = load i64, ptr %l13, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l15, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l15, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l70, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb17
bb17:
  %t98 = load i64, ptr %l70, !tbaa !24
  store i64 %t98, ptr %l67, !tbaa !24
  br label %bb18
bb18:
  %t99 = load i64, ptr %l67, !tbaa !24
  store i64 %t99, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb19
bb19:
  %t100 = load i64, ptr %l17, !tbaa !24
  %t101 = load i64, ptr %l16, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb20, label %bb21
bb20:
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t108 = load i64, ptr %l13, !tbaa !24
  %t109 = load i64, ptr %l17, !tbaa !24
  %t110 = load i64, ptr %l15, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l18, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t124, ptr %l91, !tbaa !27
  %t125 = load i64, ptr %l18, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i32, ptr %t128, i64 %t125
  %t130 = load i32, ptr %t129, !tbaa !33
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t123, i32 %t130)
  store i32 %t133, ptr %l94
  br label %bb23
bb23:
  %t134 = load i32, ptr %l11, !tbaa !23
  %t135 = load i32, ptr %l94, !tbaa !23
  %t137 = icmp eq i32 %t135, %t134
  br i1 %t137, label %bb24, label %bb25
bb24:
  %t139 = load i64, ptr %l18, !tbaa !24
  store i64 %t139, ptr %l12, !tbaa !24
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t141 = load i64, ptr %l17, !tbaa !24
  %t143 = add i64 %t141, 1
  store i64 %t143, ptr %l17, !tbaa !24
  br label %bb19
bb28:
  %t145 = load i64, ptr %l12, !tbaa !24
  %t147 = icmp slt i64 %t145, 0
  br i1 %t147, label %bb29, label %bb30
bb29:
  br label %bb72
bb30:
  br label %bb31
bb31:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t155, ptr %l105, !tbaa !27
  %t156 = load i64, ptr %l12, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr i32, ptr %t159, i64 %t156
  %t161 = load i32, ptr %t160, !tbaa !33
  %t164 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t154, i32 %t161)
  store i64 %t164, ptr %l108
  br label %bb32
bb32:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i32, ptr %l11, !tbaa !23
  %t169 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %t165, i32 %t166)
  store i64 %t169, ptr %l111
  br label %bb33
bb33:
  %t170 = load i64, ptr %l108, !tbaa !65
  %t171 = load i64, ptr %l111, !tbaa !65
  %t172 = and i64 %t170, %t171
  store i64 %t172, ptr %l19, !tbaa !65
  store ptr null, ptr %l20, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %l10, !tbaa !23
  %t183 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t179, i32 %t180)
  store i64 %t183, ptr %l117
  br label %bb34
bb34:
  %t184 = load i64, ptr %l19, !tbaa !65
  %t185 = load i64, ptr %l117, !tbaa !65
  %t187 = and i64 %t185, %t184
  %t188 = load i64, ptr %l19, !tbaa !65
  %t191 = icmp eq i64 %t187, %t188
  br i1 %t191, label %bb35, label %bb36
bb35:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l122, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t194, ptr %l123
  %t195 = load i32, ptr %l6, !tbaa !23
  store i32 %t195, ptr %l124, !tbaa !23
  store i32 9, ptr %l125
  %t196 = load ptr, ptr %l5, !tbaa !29
  store ptr %t196, ptr %l126, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l1
  %t199 = load i32, ptr %l6, !tbaa !23
  %t203 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t197, %"compiler/source:Span" %t198, i32 %t199, i64 16)
  store ptr %t203, ptr %l130
  br label %bb37
bb36:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/check:Checker", ptr %t204, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = getelementptr %"compiler/generic:Program", ptr %t207, i32 0, i32 2
  %t210 = load i32, ptr %l10, !tbaa !23
  %t213 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t209, i32 %t210)
  store i64 %t213, ptr %l151
  br label %bb41
bb37:
  %t214 = load ptr, ptr %l130, !tbaa !29
  %t215 = load ptr, ptr %l122, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l123
  %t217 = load i32, ptr %l124, !tbaa !23
  %t218 = load i32, ptr %l125, !range !{i32 0, i32 52}
  %t219 = load ptr, ptr %l126, !tbaa !29
  %t221 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v0, ptr %t215, %"compiler/source:Span" %t216, i32 %t217, i32 %t218, ptr %t219, ptr %t214)
  store ptr %t221, ptr %l132
  br label %bb38
bb38:
  %t222 = load ptr, ptr %l132, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l133, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t224, ptr %l134
  %t225 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t225, ptr %l135, !tbaa !23
  store i32 13, ptr %l136
  store ptr %t222, ptr %l137, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l1
  %t229 = load i32, ptr %l6, !tbaa !23
  %t230 = load i64, ptr %l12, !tbaa !24
  %t232 = add i64 %t230, 1
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t227, %"compiler/source:Span" %t228, i32 %t229, i64 %t232)
  store ptr %t237, ptr %l143
  br label %bb39
bb39:
  %t238 = load ptr, ptr %l143, !tbaa !29
  %t239 = load ptr, ptr %l133, !tbaa !29
  %t240 = load %"compiler/source:Span", ptr %l134
  %t241 = load i32, ptr %l135, !tbaa !23
  %t242 = load i32, ptr %l136, !range !{i32 0, i32 52}
  %t243 = load ptr, ptr %l137, !tbaa !29
  %t245 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t239, %"compiler/source:Span" %t240, i32 %t241, i32 %t242, ptr %t243, ptr %t238)
  store ptr %t245, ptr %l145
  br label %bb40
bb40:
  %t246 = load ptr, ptr %l145, !tbaa !29
  store ptr %t246, ptr %l20, !tbaa !29
  br label %bb64
bb41:
  %t248 = load i64, ptr %l19, !tbaa !65
  %t249 = load i64, ptr %l151, !tbaa !65
  %t251 = and i64 %t249, %t248
  store i64 %t251, ptr %l22, !tbaa !65
  store i64 0, ptr %l23, !tbaa !24
  store i64 64, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t253 = load i64, ptr %l24, !tbaa !24
  %t254 = load i64, ptr %l23, !tbaa !24
  %t257 = icmp sgt i64 %t253, %t254
  br i1 %t257, label %bb42, label %bb43
bb42:
  %t259 = load i64, ptr %l25, !tbaa !24
  %t261 = icmp sgt i64 %t259, 0
  br i1 %t261, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l157, !tbaa !24
  br label %bb47
bb44:
  %t263 = load i64, ptr %l24, !tbaa !24
  %t264 = load i64, ptr %l23, !tbaa !24
  %t267 = sub i64 %t263, %t264
  %t268 = load i64, ptr %l25, !tbaa !24
  %t271 = add i64 %t267, %t268
  %t273 = sub i64 %t271, 1
  %t274 = load i64, ptr %l25, !tbaa !24
  %t277 = sdiv i64 %t273, %t274
  store i64 %t277, ptr %l160, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb46
bb46:
  %t279 = load i64, ptr %l160, !tbaa !24
  store i64 %t279, ptr %l157, !tbaa !24
  br label %bb47
bb47:
  %t280 = load i64, ptr %l157, !tbaa !24
  store i64 %t280, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb48
bb48:
  %t281 = load i64, ptr %l27, !tbaa !24
  %t282 = load i64, ptr %l26, !tbaa !24
  %t285 = icmp slt i64 %t281, %t282
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb49, label %bb50
bb49:
  br label %bb63
bb50:
  br label %bb51
bb51:
  %t289 = load i64, ptr %l23, !tbaa !24
  %t290 = load i64, ptr %l27, !tbaa !24
  %t291 = load i64, ptr %l25, !tbaa !24
  %t294 = mul i64 %t290, %t291
  %t297 = add i64 %t289, %t294
  store i64 %t297, ptr %l28, !tbaa !24
  %t299 = load i64, ptr %l22, !tbaa !65
  %t300 = load i64, ptr %l28, !tbaa !24
  store i64 %t300, ptr %l179, !tbaa !24
  %t301 = load i64, ptr %l179, !tbaa !24
  %t302 = load i64, ptr %l179, !tbaa !24
  %t303 = shl i64 1, %t302
  %t306 = and i64 %t299, %t303
  %t308 = icmp eq i64 %t306, 0
  br i1 %t308, label %bb52, label %bb53
bb52:
  br label %bb62
bb53:
  br label %bb54
bb54:
  %t310 = load ptr, ptr %l0, !tbaa !29
  store ptr %t310, ptr %l183, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t311, ptr %l184
  %t312 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t312, ptr %l185, !tbaa !23
  store i32 13, ptr %l186
  %t313 = load ptr, ptr %l5, !tbaa !29
  store ptr %t313, ptr %l187, !tbaa !29
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l188, !tbaa !29
  %t315 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t315, ptr %l189
  %t316 = load ptr, ptr %l5, !tbaa !29
  %t319 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t316)
  store i32 %t319, ptr %l192
  br label %bb55
bb55:
  %t320 = load i64, ptr %l12, !tbaa !24
  %t322 = add i64 %t320, 1
  %t324 = shl i64 %t322, 16
  %t325 = load i64, ptr %l28, !tbaa !24
  %t328 = or i64 %t324, %t325
  %t329 = load ptr, ptr %l188, !tbaa !29
  %t330 = load %"compiler/source:Span", ptr %l189
  %t331 = load i32, ptr %l192, !tbaa !23
  %t333 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t329, %"compiler/source:Span" %t330, i32 %t331, i64 %t328)
  store ptr %t333, ptr %l198
  br label %bb56
bb56:
  %t334 = load ptr, ptr %l198, !tbaa !29
  %t335 = load ptr, ptr %l183, !tbaa !29
  %t336 = load %"compiler/source:Span", ptr %l184
  %t337 = load i32, ptr %l185, !tbaa !23
  %t338 = load i32, ptr %l186, !range !{i32 0, i32 52}
  %t339 = load ptr, ptr %l187, !tbaa !29
  %t341 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v3, ptr %v0, ptr %v0, ptr %t335, %"compiler/source:Span" %t336, i32 %t337, i32 %t338, ptr %t339, ptr %t334)
  store ptr %t341, ptr %l200
  br label %bb57
bb57:
  %t342 = load ptr, ptr %l200, !tbaa !29
  store ptr %t342, ptr %l29, !tbaa !29
  %t343 = load ptr, ptr %l20, !tbaa !29
  %t345 = icmp eq ptr %t343, null
  br i1 %t345, label %bb58, label %bb59
bb58:
  %t347 = load ptr, ptr %l29, !tbaa !29
  store ptr %t347, ptr %l203, !tbaa !29
  br label %bb61
bb59:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load %"compiler/source:Span", ptr %l1
  %t352 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t353 = load ptr, ptr %l20, !tbaa !29
  %t354 = load ptr, ptr %l29, !tbaa !29
  %t362 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t350, %"compiler/source:Span" %t351, i32 %t352, i32 11, ptr %t353, ptr %t354)
  store ptr %t362, ptr %l213
  br label %bb60
bb60:
  %t363 = load ptr, ptr %l213, !tbaa !29
  store ptr %t363, ptr %l203, !tbaa !29
  br label %bb61
bb61:
  %t365 = load ptr, ptr %l203, !tbaa !29
  store ptr %t365, ptr %l20, !tbaa !29
  br label %bb62
bb62:
  %t366 = load i64, ptr %l27, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l27, !tbaa !24
  br label %bb48
bb63:
  br label %bb64
bb64:
  %t370 = load ptr, ptr %l20, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  br i1 %t372, label %bb65, label %bb66
bb65:
  br label %bb72
bb66:
  br label %bb67
bb67:
  %t374 = load ptr, ptr %l7, !tbaa !29
  %t376 = icmp eq ptr %t374, null
  br i1 %t376, label %bb68, label %bb69
bb68:
  %t378 = load ptr, ptr %l20, !tbaa !29
  store ptr %t378, ptr %l221, !tbaa !29
  br label %bb71
bb69:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load %"compiler/source:Span", ptr %l1
  %t383 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t384 = load ptr, ptr %l7, !tbaa !29
  store ptr %t384, ptr %l228, !tbaa !29
  %t385 = load ptr, ptr %l20, !tbaa !29
  %t387 = load ptr, ptr %l228, !tbaa !29
  %t388 = call ptr @__olang_scope_of(ptr %t387, ptr null)
  %t389 = ptrtoint ptr %t388 to i64
  %t391 = inttoptr i64 %t389 to ptr
  %t396 = load ptr, ptr %l228, !tbaa !29
  %t398 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t391, ptr %v0, ptr %v3, ptr %t381, %"compiler/source:Span" %t382, i32 %t383, i32 11, ptr %t396, ptr %t385)
  store ptr %t398, ptr %l232
  br label %bb70
bb70:
  %t399 = load ptr, ptr %l232, !tbaa !29
  store ptr %t399, ptr %l221, !tbaa !29
  br label %bb71
bb71:
  %t401 = load ptr, ptr %l221, !tbaa !29
  store ptr %t401, ptr %l7, !tbaa !29
  br label %bb72
bb72:
  %t402 = load i64, ptr %l9, !tbaa !24
  %t404 = add i64 %t402, 1
  store i64 %t404, ptr %l9, !tbaa !24
  br label %bb6
bb73:
  %t406 = load ptr, ptr %l7, !tbaa !29
  %t408 = icmp eq ptr %t406, null
  br i1 %t408, label %bb74, label %bb75
bb74:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load %"compiler/source:Span", ptr %l1
  %t412 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t416 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t410, %"compiler/source:Span" %t411, i32 %t412, i64 0)
  store ptr %t416, ptr %l241
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_scope_close(ptr %s0)
  %t417 = load ptr, ptr %l241, !tbaa !29
  store ptr %t417, ptr %rv
  br label %ret
bb77:
  %t418 = load ptr, ptr %l7, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t418, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l30 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca i64
  %l42 = alloca i64
  %l46 = alloca i64
  %l51 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca %"compiler/source:Span"
  %l60 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca i64
  %l67 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca %"compiler/diagmsg:Msg"
  %l76 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l86 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/diagmsg:Msg"
  %l91 = alloca i64
  %l98 = alloca i64
  %l100 = alloca i64
  %l105 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i32
  %l123 = alloca i64
  %l126 = alloca i64
  %l145 = alloca { i64, ptr }
  %l149 = alloca i32
  %l156 = alloca { i64, ptr }
  %l159 = alloca i64
  %l167 = alloca { i64, ptr }
  %l168 = alloca i64
  %l170 = alloca ptr
  %l172 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l178 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t208 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sge i64 0, 0
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t7 = icmp sle i64 0, 2305843009213693951
  br i1 %t7, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb5:
  %t9 = mul i64 0, 4
  %t10 = insertvalue { i64, ptr } undef, i64 0, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t11, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb7:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l30
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l30, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Func", ptr %t21, i32 0, i32 2
  %t26 = load i32, ptr %t25, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t22, i32 %t26)
  store { i64, ptr } %t29, ptr %l34
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %s0, ptr %t34, i64 %t35)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l38
  br label %bb10
bb10:
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l6
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t41, ptr %l40
  br label %bb11
bb11:
  %t42 = load i64, ptr %l40, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t43)
  store i64 %t45, ptr %l42
  br label %bb12
bb12:
  %t46 = load i64, ptr %l42, !tbaa !24
  store i64 %t46, ptr %l8, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarIndex(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l46
  br label %bb13
bb13:
  %t55 = load i64, ptr %l46, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = icmp sgt i64 %t58, %t59
  br i1 %t62, label %bb14, label %bb15
bb14:
  %t64 = load i64, ptr %l9, !tbaa !24
  %t66 = icmp slt i64 %t64, 0
  store i1 %t66, ptr %l51, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb16
bb16:
  %t68 = load i1, ptr %l51, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l54, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t70, ptr %l55, !tbaa !27
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr ptr, ptr %t74, i64 %t71
  %t76 = load ptr, ptr %t75, !tbaa !39
  %t78 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t76)
  store %"compiler/source:Span" %t78, ptr %l58
  br label %bb19
bb18:
  br label %bb26
bb19:
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrSetArgUnwanted(ptr %v0, ptr %s2, { i64, ptr } %t79)
  store %"compiler/diagmsg:Msg" %t81, ptr %l60
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l54, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l58
  %t84 = load %"compiler/diagmsg:Msg", ptr %l60
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t82, %"compiler/source:Span" %t83, %"compiler/diagmsg:Msg" %t84)
  store i64 %t85, ptr %l61
  br label %bb21
bb21:
  %t86 = icmp sge i64 0, 0
  br i1 %t86, label %bb22, label %bb23
bb22:
  %t88 = icmp sle i64 0, 2305843009213693951
  br i1 %t88, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb24:
  %t90 = mul i64 0, 4
  %t91 = insertvalue { i64, ptr } undef, i64 0, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t92, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb26:
  %t94 = load i64, ptr %l7, !tbaa !24
  %t96 = icmp eq i64 %t94, 0
  br i1 %t96, label %bb27, label %bb28
bb27:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t100 = icmp sgt i64 %t98, 0
  store i1 %t100, ptr %l67, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb29
bb29:
  %t102 = load i1, ptr %l67, !tbaa !21
  br i1 %t102, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l70, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t104, ptr %l71, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 0
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t110 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t108)
  store %"compiler/source:Span" %t110, ptr %l73
  br label %bb32
bb31:
  br label %bb39
bb32:
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t113 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %s3, { i64, ptr } %t111)
  store %"compiler/diagmsg:Msg" %t113, ptr %l75
  br label %bb33
bb33:
  %t114 = load ptr, ptr %l70, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l73
  %t116 = load %"compiler/diagmsg:Msg", ptr %l75
  %t117 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t114, %"compiler/source:Span" %t115, %"compiler/diagmsg:Msg" %t116)
  store i64 %t117, ptr %l76
  br label %bb34
bb34:
  %t118 = icmp sge i64 0, 0
  br i1 %t118, label %bb35, label %bb36
bb35:
  %t120 = icmp sle i64 0, 2305843009213693951
  br i1 %t120, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb37:
  %t122 = mul i64 0, 4
  %t123 = insertvalue { i64, ptr } undef, i64 0, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t124, ptr %rv
  br label %ret
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb39:
  %t126 = load i64, ptr %l7, !tbaa !24
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = icmp ne i64 %t126, %t127
  br i1 %t130, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l83, !tbaa !29
  %t133 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t133, ptr %l84, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr ptr, ptr %t135, i64 0
  %t137 = load ptr, ptr %t136, !tbaa !39
  %t139 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t137)
  store %"compiler/source:Span" %t139, ptr %l86
  br label %bb42
bb41:
  br label %bb49
bb42:
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t141 = load i64, ptr %l7, !tbaa !24
  %t142 = load i64, ptr %l8, !tbaa !24
  %t146 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s4, { i64, ptr } %t140, i64 %t141, i64 %t142)
  store %"compiler/diagmsg:Msg" %t146, ptr %l90
  br label %bb43
bb43:
  %t147 = load ptr, ptr %l83, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l86
  %t149 = load %"compiler/diagmsg:Msg", ptr %l90
  %t150 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t147, %"compiler/source:Span" %t148, %"compiler/diagmsg:Msg" %t149)
  store i64 %t150, ptr %l91
  br label %bb44
bb44:
  %t151 = icmp sge i64 0, 0
  br i1 %t151, label %bb45, label %bb46
bb45:
  %t153 = icmp sle i64 0, 2305843009213693951
  br i1 %t153, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_c902484ee6860410_648a649019eab164)
  unreachable
bb47:
  %t155 = mul i64 0, 4
  %t156 = insertvalue { i64, ptr } undef, i64 0, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t157, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_c902484ee6860410_648a649019eab164)
  unreachable
bb49:
  %t159 = load i64, ptr %l9, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l10, !tbaa !24
  store ptr %l6, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb50
bb50:
  %t164 = load i64, ptr %l12, !tbaa !24
  store i64 %t164, ptr %l98, !tbaa !24
  %t165 = load ptr, ptr %l11, !tbaa !29
  %t167 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t165)
  store i64 %t167, ptr %l100
  br label %bb51
bb51:
  %t168 = load i64, ptr %l98, !tbaa !24
  %t169 = load i64, ptr %l100, !tbaa !24
  %t170 = icmp slt i64 %t168, %t169
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb52, label %bb53
bb52:
  br label %bb60
bb53:
  br label %bb54
bb54:
  %t174 = load ptr, ptr %l11, !tbaa !29
  %t175 = load i64, ptr %l12, !tbaa !24
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t174, i64 %t175)
  store i64 %t178, ptr %l105
  br label %bb55
bb55:
  %t179 = load i64, ptr %l105, !tbaa !24
  store i64 %t179, ptr %l13, !tbaa !24
  %t180 = load i64, ptr %l13, !tbaa !24
  %t182 = add i64 %t180, 1
  %t183 = load i64, ptr %l10, !tbaa !24
  %t186 = icmp sgt i64 %t182, %t183
  br i1 %t186, label %bb56, label %bb57
bb56:
  %t188 = load i64, ptr %l13, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l10, !tbaa !24
  br label %bb58
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t192 = load i64, ptr %l12, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l12, !tbaa !24
  br label %bb50
bb60:
  %t196 = load i64, ptr %l10, !tbaa !24
  store i64 %t196, ptr %l114, !tbaa !24
  %t197 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t197, ptr %l115, !tbaa !23
  %t198 = load i64, ptr %l114, !tbaa !24
  %t199 = icmp sge i64 %t198, 0
  br i1 %t199, label %bb61, label %bb62
bb61:
  %t201 = load i64, ptr %l114, !tbaa !24
  %t202 = icmp sle i64 %t201, 2305843009213693951
  br i1 %t202, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_e4324c4b30f6563f_ec149b7f01d5683b)
  unreachable
bb63:
  %t204 = load i64, ptr %l114, !tbaa !24
  %t205 = mul i64 %t204, 4
  %t206 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t205)
  %t207 = load i32, ptr %l115, !tbaa !23
  store i64 0, ptr %t208
  br label %fill.209
fill.209:
  %t212 = load i64, ptr %t208
  %t213 = icmp slt i64 %t212, %t204
  br i1 %t213, label %fillb.210, label %filld.211
fillb.210:
  %t214 = getelementptr i32, ptr %t206, i64 %t212
  store i32 %t207, ptr %t214
  %t215 = add i64 %t212, 1
  store i64 %t215, ptr %t208
  br label %fill.209
filld.211:
  %t216 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t206, 1
  store { i64, ptr } %t217, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t219 = load i64, ptr %l7, !tbaa !24
  store i64 %t219, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t221 = load i64, ptr %l16, !tbaa !24
  %t222 = load i64, ptr %l15, !tbaa !24
  %t225 = icmp sgt i64 %t221, %t222
  br i1 %t225, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_e4324c4b30f6563f_ec149b7f01d5683b)
  unreachable
bb65:
  %t227 = load i64, ptr %l17, !tbaa !24
  %t229 = icmp sgt i64 %t227, 0
  br i1 %t229, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb70
bb67:
  %t231 = load i64, ptr %l16, !tbaa !24
  %t232 = load i64, ptr %l15, !tbaa !24
  %t235 = sub i64 %t231, %t232
  %t236 = load i64, ptr %l17, !tbaa !24
  %t239 = add i64 %t235, %t236
  %t241 = sub i64 %t239, 1
  %t242 = load i64, ptr %l17, !tbaa !24
  %t245 = sdiv i64 %t241, %t242
  store i64 %t245, ptr %l126, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb69
bb69:
  %t247 = load i64, ptr %l126, !tbaa !24
  store i64 %t247, ptr %l123, !tbaa !24
  br label %bb70
bb70:
  %t248 = load i64, ptr %l123, !tbaa !24
  store i64 %t248, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb71
bb71:
  %t249 = load i64, ptr %l19, !tbaa !24
  %t250 = load i64, ptr %l18, !tbaa !24
  %t253 = icmp slt i64 %t249, %t250
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb72, label %bb73
bb72:
  br label %bb85
bb73:
  br label %bb74
bb74:
  %t257 = load i64, ptr %l15, !tbaa !24
  %t258 = load i64, ptr %l19, !tbaa !24
  %t259 = load i64, ptr %l17, !tbaa !24
  %t262 = mul i64 %t258, %t259
  %t265 = add i64 %t257, %t262
  store i64 %t265, ptr %l20, !tbaa !24
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t268, ptr %l145, !tbaa !27
  %t269 = load i64, ptr %l20, !tbaa !24
  %t271 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr ptr, ptr %t272, i64 %t269
  %t274 = load ptr, ptr %t273, !tbaa !39
  %t278 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t267, ptr %t274)
  store i32 %t278, ptr %l149
  br label %bb75
bb75:
  %t279 = load i32, ptr %l149, !tbaa !23
  store i32 %t279, ptr %l21, !tbaa !23
  %t280 = load i32, ptr %l21, !tbaa !23
  %t281 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t284 = icmp eq i32 %t280, %t281
  br i1 %t284, label %bb76, label %bb77
bb76:
  %t286 = icmp sge i64 0, 0
  br i1 %t286, label %bb78, label %bb79
bb77:
  br label %bb82
bb78:
  %t288 = icmp sle i64 0, 2305843009213693951
  br i1 %t288, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6)
  unreachable
bb80:
  %t290 = mul i64 0, 4
  %t291 = insertvalue { i64, ptr } undef, i64 0, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t292, ptr %rv
  br label %ret
bb81:
  call void @__olang_check_failed(ptr @olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6)
  unreachable
bb82:
  %t294 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t294, ptr %l156, !tbaa !27
  %t295 = load i64, ptr %l20, !tbaa !24
  %t298 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t295)
  store i64 %t298, ptr %l159
  br label %bb83
bb83:
  %t299 = load i32, ptr %l21, !tbaa !23
  %t301 = load i64, ptr %l159, !tbaa !24
  %t302 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr i32, ptr %t303, i64 %t301
  store i32 %t299, ptr %t304, !tbaa !33
  br label %bb84
bb84:
  %t305 = load i64, ptr %l19, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l19, !tbaa !24
  br label %bb71
bb85:
  %t309 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = load i64, ptr %l8, !tbaa !24
  %t315 = icmp sgt i64 %t311, %t312
  br i1 %t315, label %bb86, label %bb87
bb86:
  %t317 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t317, ptr %l167, !tbaa !27
  %t318 = load i64, ptr %l9, !tbaa !24
  store i64 %t318, ptr %l168, !tbaa !24
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !29
  store ptr %t322, ptr %l170, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t323)
  store ptr %t325, ptr %l172
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t326 = load ptr, ptr %l172, !tbaa !29
  %t328 = getelementptr %"compiler/check:frame", ptr %t326, i32 0, i32 4
  %t329 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t329, ptr %l175, !tbaa !27
  %t330 = load i64, ptr %l8, !tbaa !24
  %t332 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr ptr, ptr %t333, i64 %t330
  %t335 = load ptr, ptr %t334, !tbaa !39
  %t336 = load ptr, ptr %l170, !tbaa !29
  %t339 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsArgOf(ptr %v0, ptr %v0, ptr %v1, ptr %t336, ptr %t328, ptr %t335)
  store i32 %t339, ptr %l178
  br label %bb89
bb89:
  %t340 = load i32, ptr %l178, !tbaa !23
  %t341 = load i64, ptr %l168, !tbaa !24
  %t342 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr i32, ptr %t343, i64 %t341
  store i32 %t340, ptr %t344, !tbaa !33
  br label %bb90
bb90:
  %t345 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t345, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/check:factsCopy" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsCopied(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"compiler/check:factsCopy"
  %l18 = alloca %"compiler/check:factsCopy"
  %rv = alloca %"compiler/check:factsCopy"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 50
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e(ptr %v1, ptr %l5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l7
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 46
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l9
  %t16 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e(ptr %v1, ptr %l9)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l11
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 59
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l13
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v1, ptr %l13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l15
  br label %bb4
bb4:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t26 = call %"compiler/check:factsCopy" @compiler_2fcheck_3afactsCopy_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25)
  store %"compiler/check:factsCopy" %t26, ptr %l16
  br label %bb5
bb5:
  %t28 = call %"compiler/check:factsCopy" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3afactsCopy(ptr %v1, ptr %l16)
  store %"compiler/check:factsCopy" %t28, ptr %l18
  br label %bb6
bb6:
  %t29 = load %"compiler/check:factsCopy", ptr %l18
  store %"compiler/check:factsCopy" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factsCopy", ptr %rv
  ret %"compiler/check:factsCopy" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsUndecided(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/check:factRead"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca %"compiler/check:factRead"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca %"compiler/effects:Facts"
  %l24 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i1
  %l34 = alloca ptr
  %l40 = alloca { i64, [3 x i64] }
  %l42 = alloca %"compiler/diagmsg:Msg"
  %l43 = alloca i64
  %s2 = alloca %olang.scope
  %t77 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 60
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2eLen_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb2
bb2:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/check:factRead" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2eAt_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/check:factRead" %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load %"compiler/check:factRead", ptr %l14
  store %"compiler/check:factRead" %t20, ptr %l3
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v0, ptr %t21)
  store ptr %t23, ptr %l16
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 20
  %t27 = getelementptr %"compiler/check:factRead", ptr %l3, i32 0, i32 0
  %t28 = load i64, ptr %t27, !tbaa !24
  %t31 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t26, i64 %t28)
  %t32 = extractvalue { i32, i64 } %t31, 1
  %t33 = extractvalue { i32, i64 } %t31, 0
  store i32 %t33, ptr %l22
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb9, label %ok.35, !prof !99
ok.35:
  store i64 %t32, ptr %l21
  br label %bb8
bb8:
  %t36 = load i64, ptr %l21, !tbaa !24
  store i64 %t36, ptr %l17, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t37, i64 %t38)
  store %"compiler/effects:Facts" %t39, ptr %l23
  br label %bb12
bb12:
  store ptr %l23, ptr %l24, !tbaa !29
  %t40 = getelementptr %"compiler/check:factRead", ptr %l3, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = call i32 @compiler_2feffects_2eFact_2eNamed(ptr %v0, { i64, ptr } %t41)
  store i32 %t43, ptr %l26
  br label %bb13
bb13:
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = load i32, ptr %l26, !range !{i32 0, i32 10}
  %t46 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %s2, ptr %t44, i32 %t45)
  store i1 %t46, ptr %l27
  br label %bb14
bb14:
  %t47 = load i1, ptr %l27, !tbaa !21
  %t49 = getelementptr %"compiler/check:factRead", ptr %l3, i32 0, i32 2
  %t50 = load i1, ptr %t49, !tbaa !21
  %t53 = icmp eq i1 %t47, %t50
  br i1 %t53, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb16:
  br label %bb17
bb17:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/load:Loader", ptr %t61, i32 0, i32 4
  %t64 = load ptr, ptr %t63, !tbaa !29
  store ptr %t64, ptr %l34, !tbaa !29
  %t65 = getelementptr %"compiler/check:factRead", ptr %l3, i32 0, i32 3
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = getelementptr %"compiler/check:factRead", ptr %l3, i32 0, i32 4
  %t68 = getelementptr %"compiler/source:Span", ptr %t67, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t71 = sext i32 %t69 to i64
  %t72 = getelementptr %"compiler/check:factRead", ptr %l3, i32 0, i32 4
  %t73 = getelementptr %"compiler/source:Span", ptr %t72, i32 0, i32 1
  %t74 = load i32, ptr %t73, !tbaa !23
  %t76 = sext i32 %t74 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 0
  store i64 3, ptr %t78
  %t80 = insertvalue { i64, i64, i64 } undef, i64 %t66, 0
  %t82 = insertvalue { i64, i64, i64 } %t80, i64 %t71, 1
  %t84 = insertvalue { i64, i64, i64 } %t82, i64 %t76, 2
  %t85 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 1
  store { i64, i64, i64 } %t84, ptr %t85
  %t86 = load { i64, [3 x i64] }, ptr %t77
  store { i64, [3 x i64] } %t86, ptr %l40
  %t87 = getelementptr %"compiler/check:factRead", ptr %l3, i32 0, i32 5
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFactUndecided(ptr %v0, ptr %s2, { i64, ptr } %t88)
  store %"compiler/diagmsg:Msg" %t90, ptr %l42
  br label %bb18
bb18:
  %t91 = load ptr, ptr %l34, !tbaa !29
  %t92 = load { i64, [3 x i64] }, ptr %l40
  %t93 = load %"compiler/diagmsg:Msg", ptr %l42
  %t94 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t91, { i64, [3 x i64] } %t92, %"compiler/diagmsg:Msg" %t93)
  store i64 %t94, ptr %l43
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l2, !tbaa !24
  br label %bb1
bb21:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldBits(ptr %v0, ptr %a0, %"compiler/generic:Desc" %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/generic:Desc"
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l15 = alloca i32
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l58 = alloca i1
  %l60 = alloca i64
  %l64 = alloca { i64, ptr }
  %l67 = alloca i64
  %l72 = alloca { i64, ptr }
  %l76 = alloca i64
  %l80 = alloca { i64, ptr }
  %l83 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/generic:Desc" %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/generic:Desc", ptr %l1
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldOffset(ptr %v0, ptr %t1, %"compiler/generic:Desc" %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t17 = load i32, ptr %t16, !tbaa !23
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %t15, i32 %t17)
  store i32 %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load i32, ptr %l15, !tbaa !23
  store i32 %t21, ptr %l4, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l4, !tbaa !23
  %t26 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l18
  br label %bb6
bb6:
  %t27 = load i1, ptr %l18, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  store ptr %t33, ptr %l22, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l4, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l27
  br label %bb9
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  store ptr %t49, ptr %l31, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  store ptr %t55, ptr %l34, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  store ptr %t61, ptr %l37, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l42
  br label %bb11
bb9:
  %t72 = load ptr, ptr %l22, !tbaa !29
  %t73 = load i32, ptr %l27, !tbaa !23
  %t74 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t72, i32 %t73)
  store { i64, ptr } %t74, ptr %l28
  br label %bb10
bb10:
  %t75 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t75, ptr %l19, !tbaa !27
  br label %bb15
bb11:
  %t76 = load ptr, ptr %l37, !tbaa !29
  %t77 = load i32, ptr %l42, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t76, i32 %t77)
  store { i64, ptr } %t78, ptr %l43
  br label %bb12
bb12:
  %t79 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t79, ptr %l44, !tbaa !27
  %t80 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 2
  %t81 = load i64, ptr %t80, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i32, ptr %t84, i64 %t81
  %t86 = load i32, ptr %t85, !tbaa !33
  %t87 = load ptr, ptr %l34, !tbaa !29
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t87, i32 %t86)
  store i32 %t89, ptr %l47
  br label %bb13
bb13:
  %t90 = load ptr, ptr %l31, !tbaa !29
  %t91 = load i32, ptr %l47, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t90, i32 %t91)
  store { i64, ptr } %t92, ptr %l48
  br label %bb14
bb14:
  %t93 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t93, ptr %l19, !tbaa !27
  br label %bb15
bb15:
  %t94 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t94, ptr %l5, !tbaa !27
  %t95 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t96 = load i64, ptr %t95, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t102 = icmp sge i64 %t96, %t99
  br i1 %t102, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l4, !tbaa !23
  %t114 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %t110, i32 %t111)
  store i1 %t114, ptr %l58
  br label %bb19
bb19:
  %t115 = load i1, ptr %l58, !tbaa !21
  br i1 %t115, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t116 = load i1, ptr %l2, !tbaa !21
  br i1 %t116, label %bb22, label %bb23
bb21:
  br label %bb27
bb22:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t124, ptr %l64, !tbaa !27
  %t125 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t126 = load i64, ptr %t125, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i32, ptr %t129, i64 %t126
  %t131 = load i32, ptr %t130, !tbaa !33
  %t134 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %v0, ptr %t123, i32 %t131)
  store i64 %t134, ptr %l67
  br label %bb24
bb23:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l4, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBitOffsets(ptr %v0, ptr %s3, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l72
  br label %bb25
bb24:
  %t145 = load i64, ptr %l67, !tbaa !24
  store i64 %t145, ptr %l60, !tbaa !24
  br label %bb26
bb25:
  %t146 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t147 = load i64, ptr %t146, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i64, ptr %t150, i64 %t147
  %t152 = load i64, ptr %t151, !tbaa !34
  store i64 %t152, ptr %l60, !tbaa !24
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t154 = load i64, ptr %l60, !tbaa !24
  store i64 %t154, ptr %rv
  br label %ret
bb27:
  %t155 = load i1, ptr %l2, !tbaa !21
  br i1 %t155, label %bb28, label %bb29
bb28:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 2
  %t163 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t163, ptr %l80, !tbaa !27
  %t164 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t165 = load i64, ptr %t164, !tbaa !24
  %t167 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr i32, ptr %t168, i64 %t165
  %t170 = load i32, ptr %t169, !tbaa !33
  %t173 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t162, i32 %t170)
  store i64 %t173, ptr %l83
  br label %bb30
bb29:
  %t174 = load i64, ptr %l3, !tbaa !24
  %t176 = mul i64 8, %t174
  store i64 %t176, ptr %l76, !tbaa !24
  br label %bb31
bb30:
  %t178 = load i64, ptr %l83, !tbaa !24
  %t179 = mul i64 8, %t178
  store i64 %t179, ptr %l76, !tbaa !24
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t181 = load i64, ptr %l76, !tbaa !24
  store i64 %t181, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i32, ptr %l12, !tbaa !23
  store i32 %t20, ptr %l2, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l15
  br label %bb6
bb6:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb9
bb8:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb10
bb9:
  %t32 = load i32, ptr %l19, !range !{i32 0, i32 6}
  %t34 = trunc i64 5 to i32
  %t35 = icmp eq i32 %t32, %t34
  store i1 %t35, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l16, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca %"compiler/names:Ref"
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca %"compiler/names:Ref"
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca ptr
  %l44 = alloca ptr
  %l48 = alloca %"compiler/names:Ref"
  %l55 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l20
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l24
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t42, ptr %l4
  %t43 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t44 = load i32, ptr %t43, !range !{i32 0, i32 9}
  %t46 = trunc i64 3 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load i32, ptr %l3, !tbaa !23
  %t59 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t52, i64 %t54, i32 %t55)
  store i64 %t59, ptr %l31
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t60 = load i64, ptr %l31, !tbaa !24
  store i64 %t60, ptr %rv
  br label %ret
bb11:
  br label %bb29
bb12:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l32, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 30}
  %t68 = icmp eq i64 %t66, 14
  store i1 %t68, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t69 = load i1, ptr %l33, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l5
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t78, i32 0, i32 2
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l6, !tbaa !23
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l42, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t89)
  store ptr %t91, ptr %l44
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l44, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 2
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t97 = load i32, ptr %t96, !tbaa !23
  %t98 = load ptr, ptr %l42, !tbaa !29
  %t101 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t98, i64 %t95, i32 %t97)
  store %"compiler/names:Ref" %t101, ptr %l48
  br label %bb19
bb19:
  %t102 = load %"compiler/names:Ref", ptr %l48
  store %"compiler/names:Ref" %t102, ptr %l7
  %t103 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t104 = load i32, ptr %t103, !range !{i32 0, i32 9}
  %t106 = trunc i64 3 to i32
  %t107 = icmp eq i32 %t104, %t106
  br i1 %t107, label %bb20, label %bb21
bb20:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = load i32, ptr %l6, !tbaa !23
  %t119 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t112, i64 %t114, i32 %t115)
  store i64 %t119, ptr %l55
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t120 = load i64, ptr %l55, !tbaa !24
  store i64 %t120, ptr %rv
  br label %ret
bb23:
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_2ff0d7eb2fd53f26_264ec5bdf8203eea)
  unreachable
bb29:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"compiler/check:b5aWalk"
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t2 = alloca %"compiler/check:b5aWalk", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_3ab5aWalk_2ector(ptr %t2, ptr %v1, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t2, i64 296, i1 false)
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 296, i64 8)
  store ptr %t4, ptr %lp3
  %t5 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t5, ptr %l6, i64 296, i1 false)
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %lp3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %t6, ptr %t7, i64 %a2)
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t12 = load ptr, ptr %lp3
  %t13 = getelementptr %"compiler/check:b5aWalk", ptr %t12, i32 0, i32 7
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l12, !tbaa !24
  %t17 = load ptr, ptr %lp3
  %t18 = getelementptr %"compiler/check:b5aWalk", ptr %t17, i32 0, i32 2
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t18)
  store i64 %t20, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = icmp slt i64 %t21, %t22
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %lp3
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %lp3
  %t31 = getelementptr %"compiler/check:b5aWalk", ptr %t30, i32 0, i32 2
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l21
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t36, ptr %t37, i64 %t38)
  br label %bb12
bb12:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t43 = load ptr, ptr %lp3
  %t44 = getelementptr %"compiler/check:b5aWalk", ptr %t43, i32 0, i32 3
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l24
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v1, ptr %l24)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l26
  br label %bb15
bb15:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l24
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasZero(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca ptr
  %l35 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t12, i64 -1, i64 %a1, i32 %t14, i32 0)
  store ptr %t18, ptr %l16
  br label %bb1
bb1:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l18
  br label %bb2
bb2:
  %t22 = load i64, ptr %l18, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l20
  br label %bb3
bb3:
  %t26 = load i64, ptr %l20, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 15
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l23
  br label %bb4
bb4:
  %t32 = load i64, ptr %l23, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 126
  %t36 = load i1, ptr %t35, !tbaa !21
  store i1 %t36, ptr %l7, !tbaa !21
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 126
  store i1 true, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l27, !tbaa !29
  %t42 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t42, ptr %l28
  br label %bb5
bb5:
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l28
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t44, %"compiler/source:Span" %t45, i32 %a2)
  store ptr %t47, ptr %l30
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i1, ptr %l7, !tbaa !21
  %t52 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 126
  store i1 %t49, ptr %t52, !tbaa !21
  %t53 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t53)
  br label %bb7
bb7:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t55)
  store i64 %t57, ptr %l35
  br label %bb8
bb8:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l35, !tbaa !24
  %t61 = icmp eq i64 %t59, %t58
  store i1 %t61, ptr %l8, !tbaa !21
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t64 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t63, i64 %t64)
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t68 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t67, i64 %t68)
  br label %bb10
bb10:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 15
  %t74 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eTruncate_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t73, i64 %t74)
  br label %bb11
bb11:
  %t77 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t77)
  br label %bb12
bb12:
  %t79 = load i1, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t79, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimmutHoldsUnique(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca i1
  %l29 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l41 = alloca i64
  %l44 = alloca i64
  %l62 = alloca i64
  %l64 = alloca i64
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca i1
  %l75 = alloca { i64, ptr }
  %l78 = alloca i1
  %l80 = alloca ptr
  %l83 = alloca %"compiler/source:Span"
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca %"compiler/diagmsg:Msg"
  %l95 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l12, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l17
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = load i32, ptr %l17, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l18
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb6
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l25
  br label %bb5
bb5:
  %t33 = load i1, ptr %l25, !tbaa !21
  %t34 = xor i1 %t33, true
  store i1 %t34, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l29, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l34
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = load i32, ptr %l34, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t53, i32 %t54)
  store { i64, ptr } %t55, ptr %l35
  br label %bb11
bb11:
  %t56 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = icmp sgt i64 %t61, %t62
  br i1 %t65, label %bb12, label %bb13
bb12:
  %t67 = load i64, ptr %l6, !tbaa !24
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb17
bb14:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t72 = load i64, ptr %l4, !tbaa !24
  %t75 = sub i64 %t71, %t72
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t75, %t76
  %t81 = sub i64 %t79, 1
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = sdiv i64 %t81, %t82
  store i64 %t85, ptr %l44, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb16
bb16:
  %t87 = load i64, ptr %l44, !tbaa !24
  store i64 %t87, ptr %l41, !tbaa !24
  br label %bb17
bb17:
  %t88 = load i64, ptr %l41, !tbaa !24
  store i64 %t88, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t89 = load i64, ptr %l8, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb20:
  br label %bb21
bb21:
  %t97 = load i64, ptr %l4, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = mul i64 %t98, %t99
  %t105 = add i64 %t97, %t102
  store i64 %t105, ptr %l9, !tbaa !24
  %t107 = load i64, ptr %l9, !tbaa !24
  store i64 %t107, ptr %l62, !tbaa !24
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t110 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v1, ptr %t108)
  store i64 %t110, ptr %l64
  br label %bb22
bb22:
  %t111 = load i64, ptr %l62, !tbaa !24
  %t112 = load i64, ptr %l64, !tbaa !24
  %t113 = icmp sge i64 %t111, %t112
  br i1 %t113, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb26
bb24:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t116, ptr %l68, !tbaa !27
  %t117 = load i64, ptr %l9, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i32, ptr %t120, i64 %t117
  %t122 = load i32, ptr %t121, !tbaa !33
  %t125 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t115, i32 %t122)
  store i1 %t125, ptr %l71
  br label %bb25
bb25:
  %t126 = load i1, ptr %l71, !tbaa !21
  store i1 %t126, ptr %l66, !tbaa !21
  br label %bb26
bb26:
  %t127 = load i1, ptr %l66, !tbaa !21
  br i1 %t127, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb30
bb28:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t132, ptr %l75, !tbaa !27
  %t133 = load i64, ptr %l9, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i32, ptr %t136, i64 %t133
  %t138 = load i32, ptr %t137, !tbaa !33
  %t141 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t131, i32 %t138)
  store i1 %t141, ptr %l78
  br label %bb29
bb29:
  %t142 = load i1, ptr %l78, !tbaa !21
  %t143 = xor i1 %t142, true
  store i1 %t143, ptr %l72, !tbaa !21
  br label %bb30
bb30:
  %t145 = load i1, ptr %l72, !tbaa !21
  br i1 %t145, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb32:
  br label %bb33
bb33:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l80, !tbaa !29
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t148 = load i64, ptr %l9, !tbaa !24
  %t151 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v1, ptr %t147, i64 %t148)
  store %"compiler/source:Span" %t151, ptr %l83
  br label %bb34
bb34:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l1, !tbaa !23
  %t156 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t152, i32 %t153)
  store { i64, ptr } %t156, ptr %l86
  br label %bb35
bb35:
  %t157 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t159 = extractvalue { i64, ptr } %t157, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, ptr } %t163, ptr %l87, !tbaa !27
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t165, ptr %l89, !tbaa !27
  %t166 = load i64, ptr %l9, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i32, ptr %t169, i64 %t166
  %t171 = load i32, ptr %t170, !tbaa !33
  %t174 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t164, i32 %t171)
  store { i64, ptr } %t174, ptr %l92
  br label %bb36
bb36:
  %t175 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t177 = extractvalue { i64, ptr } %t175, 1
  %t178 = mul i64 %t176, 1
  %t179 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t177, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  %t182 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t184 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueImmutPart(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t182, { i64, ptr } %t181)
  store %"compiler/diagmsg:Msg" %t184, ptr %l94
  br label %bb37
bb37:
  %t185 = load ptr, ptr %l80, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l83
  %t187 = load %"compiler/diagmsg:Msg", ptr %l94
  %t188 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t185, %"compiler/source:Span" %t186, %"compiler/diagmsg:Msg" %t187)
  store i64 %t188, ptr %l95
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  %t189 = load i64, ptr %l8, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l8, !tbaa !24
  br label %bb18
bb40:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:ownerAt"
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca %"compiler/check:ownerAt"
  %l14 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 13
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 -1, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_fee5565d650674df_3b318d0e6ee4625b)
  unreachable
bb11:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %t11, ptr %t12)
  store %"compiler/check:ownerAt" %t15, ptr %l10
  br label %bb12
bb12:
  %t16 = load %"compiler/check:ownerAt", ptr %l10
  store %"compiler/check:ownerAt" %t16, ptr %l2
  %t17 = getelementptr %"compiler/check:ownerAt", ptr %l2, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  %t19 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t22 = icmp eq i32 %t18, %t19
  br i1 %t22, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb15
bb14:
  %t24 = getelementptr %"compiler/check:ownerAt", ptr %l2, i32 0, i32 1
  %t25 = load i1, ptr %t24, !tbaa !21
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb15
bb15:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb19
bb17:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:ownerAt", ptr %l2, i32 0, i32 0
  %t30 = load i32, ptr %t29, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t28, i32 %t30)
  store i1 %t33, ptr %l19
  br label %bb18
bb18:
  %t34 = load i1, ptr %l19, !tbaa !21
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb19
bb19:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb20, label %bb21
bb20:
  store i32 -1, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t37 = getelementptr %"compiler/check:ownerAt", ptr %l2, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisGlobalBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l6 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  %t15 = extractvalue { i64, [2 x i64] } %t11, 0
  %t16 = icmp eq i64 %t15, 6
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4bb92e4e6aa9fa92_ae49a41c9a1a92ee)
  unreachable
bb10:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, ptr %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca [2 x i64]
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca [3 x i64]
  %l24 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l36 = alloca %"compiler/check:laneNode"
  %l38 = alloca ptr
  %l41 = alloca i64
  %l45 = alloca %"compiler/check:laneNode"
  %l50 = alloca %"compiler/check:laneNode"
  %l55 = alloca i1
  %l59 = alloca i32
  %l63 = alloca i1
  %l64 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca ptr
  %l73 = alloca i64
  %l74 = alloca i32
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i32
  %l84 = alloca i64
  %l86 = alloca %"compiler/check:laneNode"
  %l87 = alloca i64
  %l88 = alloca ptr
  %l90 = alloca i1
  %l94 = alloca %"compiler/check:laneNode"
  %l98 = alloca i1
  %l102 = alloca %"compiler/check:laneNode"
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca ptr
  %l112 = alloca %"compiler/check:laneNode"
  %l114 = alloca { i64, ptr }
  %l116 = alloca %"compiler/diagmsg:Msg"
  %l117 = alloca i64
  %l119 = alloca { i64, ptr }
  %l121 = alloca i1
  %l124 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l132 = alloca i1
  %l135 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca ptr
  %l160 = alloca ptr
  %l164 = alloca i64
  %l165 = alloca ptr
  %l169 = alloca i64
  %l173 = alloca %"compiler/check:laneNode"
  %l178 = alloca %"compiler/check:laneNode"
  %l184 = alloca i1
  %l193 = alloca i1
  %l197 = alloca i1
  %l198 = alloca i1
  %l201 = alloca i1
  %l202 = alloca i1
  %l207 = alloca i32
  %l213 = alloca i32
  %l214 = alloca ptr
  %l215 = alloca %"compiler/source:Span"
  %l218 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l224 = alloca %"compiler/diagmsg:Msg"
  %l225 = alloca i64
  %l230 = alloca ptr
  %l231 = alloca %"compiler/source:Span"
  %l232 = alloca ptr
  %l233 = alloca i64
  %l234 = alloca i32
  %l235 = alloca %"compiler/source:Span"
  %l236 = alloca %"compiler/source:Span"
  %l237 = alloca i64
  %l238 = alloca i64
  %l239 = alloca i64
  %l240 = alloca i32
  %l245 = alloca i64
  %l249 = alloca { i64, ptr }
  %l251 = alloca i32
  %l252 = alloca %"compiler/check:laneNode"
  %l253 = alloca i64
  %l254 = alloca ptr
  %l260 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v2, ptr %t1, ptr %a4)
  store i64 %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load i64, ptr %l24, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t9, ptr %l26
  br label %bb2
bb2:
  %t10 = load i1, ptr %l26, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb6
bb4:
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t13, ptr %l29
  br label %bb5
bb5:
  %t14 = load i1, ptr %l29, !tbaa !21
  store i1 %t14, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l27, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l30, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t17, ptr %l31, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 0
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l32, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 39
  %t25 = load i64, ptr %l6, !tbaa !24
  %t28 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s1, ptr %t24, i64 %t25)
  store %"compiler/check:laneNode" %t28, ptr %l36
  br label %bb9
bb8:
  br label %bb28
bb9:
  %t29 = getelementptr %"compiler/check:laneNode", ptr %l36, i32 0, i32 8
  %t30 = load i32, ptr %t29, !tbaa !23
  %t31 = load ptr, ptr %l30, !tbaa !29
  %t32 = load ptr, ptr %l32, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v3, ptr %v0, ptr %t31, ptr %t32, i32 %t30)
  store ptr %t34, ptr %l38
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l38, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v0, ptr %t36, ptr %t35)
  store i64 %t40, ptr %l41
  br label %bb11
bb11:
  %t41 = load i64, ptr %l41, !tbaa !24
  store i64 %t41, ptr %l8, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 39
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s1, ptr %t44, i64 %t45)
  store %"compiler/check:laneNode" %t48, ptr %l45
  br label %bb12
bb12:
  %t49 = getelementptr %"compiler/check:laneNode", ptr %l45, i32 0, i32 8
  %t50 = load i32, ptr %t49, !tbaa !23
  store i32 %t50, ptr %l9, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 39
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s1, ptr %t54, i64 %t55)
  store %"compiler/check:laneNode" %t58, ptr %l50
  br label %bb13
bb13:
  %t59 = getelementptr %"compiler/check:laneNode", ptr %l50, i32 0, i32 8
  %t60 = load i32, ptr %t59, !tbaa !23
  store i32 %t60, ptr %l10, !tbaa !23
  %t62 = load i32, ptr %l9, !tbaa !23
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t66 = icmp ne i32 %t62, %t63
  br i1 %t66, label %bb14, label %bb15
bb14:
  %t68 = load i32, ptr %l10, !tbaa !23
  %t69 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t72 = icmp ne i32 %t68, %t69
  store i1 %t72, ptr %l55, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb16
bb16:
  %t74 = load i1, ptr %l55, !tbaa !21
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t75 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t75, ptr %l59, !tbaa !23
  br label %bb19
bb18:
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t77, ptr %l59, !tbaa !23
  br label %bb19
bb19:
  %t79 = load i32, ptr %l59, !tbaa !23
  store i32 %t79, ptr %l11, !tbaa !23
  %t80 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t82 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t80, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t82, ptr %l63
  br label %bb20
bb20:
  %t83 = load i1, ptr %l63, !tbaa !21
  br i1 %t83, label %bb21, label %bb22
bb21:
  store i32 93, ptr %l64
  br label %bb23
bb22:
  store i32 96, ptr %l64
  br label %bb23
bb23:
  %t86 = load i32, ptr %l64, !range !{i32 0, i32 113}
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t90 = insertvalue [2 x i64] undef, i64 %t87, 0
  %t92 = insertvalue [2 x i64] %t90, i64 %t88, 1
  store [2 x i64] %t92, ptr %l13
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l70, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t95, ptr %l71
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l72, !tbaa !29
  %t97 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneCmp, !tbaa !24
  store i64 %t97, ptr %l73, !tbaa !24
  store i32 %t86, ptr %l74
  %t99 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t99, ptr %l75
  %t100 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t100, ptr %l76
  %t101 = load i64, ptr %l6, !tbaa !24
  store i64 %t101, ptr %l77, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  store i64 %t102, ptr %l78, !tbaa !24
  %t103 = load i32, ptr %l11, !tbaa !23
  store i32 %t103, ptr %l79, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = insertvalue { i64, ptr } undef, i64 2, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %l13, 1
  %t108 = load %"compiler/source:Span", ptr %l2
  %t112 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %s1, ptr %t104, { i64, ptr } %t107, %"compiler/source:Span" %t108)
  store i64 %t112, ptr %l84
  br label %bb24
bb24:
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t114 = load i64, ptr %l73, !tbaa !24
  %t115 = load i32, ptr %l74, !range !{i32 0, i32 113}
  %t116 = load %"compiler/source:Span", ptr %l75
  %t117 = load %"compiler/source:Span", ptr %l76
  %t118 = load i64, ptr %l77, !tbaa !24
  %t119 = load i64, ptr %l78, !tbaa !24
  %t120 = load i32, ptr %l79, !tbaa !23
  %t121 = load i64, ptr %l84, !tbaa !24
  %t123 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t114, i32 %t115, %"compiler/source:Span" %t116, %"compiler/source:Span" %t117, i64 %t118, i64 %t119, i64 -1, ptr null, i32 %t120, i64 %t121, i32 %t113)
  store %"compiler/check:laneNode" %t123, ptr %l86
  br label %bb25
bb25:
  %t124 = load ptr, ptr %l72, !tbaa !29
  %t125 = load %"compiler/check:laneNode", ptr %l86
  %t126 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t124, %"compiler/check:laneNode" %t125)
  store i64 %t126, ptr %l87
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l71
  %t129 = load i64, ptr %l87, !tbaa !24
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v4, ptr %t127, %"compiler/source:Span" %t128, i64 %t129)
  store ptr %t130, ptr %l88
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t131 = load ptr, ptr %l88, !tbaa !29
  store ptr %t131, ptr %rv
  br label %ret
bb28:
  %t132 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t134 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t132, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t134, ptr %l90
  br label %bb29
bb29:
  %t135 = load i1, ptr %l90, !tbaa !21
  br i1 %t135, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s2
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 39
  %t139 = load i64, ptr %l6, !tbaa !24
  %t142 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t138, i64 %t139)
  store %"compiler/check:laneNode" %t142, ptr %l94
  br label %bb32
bb31:
  br label %bb106
bb32:
  %t143 = getelementptr %"compiler/check:laneNode", ptr %l94, i32 0, i32 8
  %t144 = load i32, ptr %t143, !tbaa !23
  %t145 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t148 = icmp ne i32 %t144, %t145
  br i1 %t148, label %bb33, label %bb34
bb33:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 39
  %t153 = load i64, ptr %l6, !tbaa !24
  %t156 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t152, i64 %t153)
  store %"compiler/check:laneNode" %t156, ptr %l102
  br label %bb35
bb34:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb36
bb35:
  %t157 = getelementptr %"compiler/check:laneNode", ptr %l102, i32 0, i32 8
  %t158 = load i32, ptr %t157, !tbaa !23
  %t159 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t162 = icmp ne i32 %t158, %t159
  store i1 %t162, ptr %l98, !tbaa !21
  br label %bb36
bb36:
  %t164 = load i1, ptr %l98, !tbaa !21
  br i1 %t164, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s3
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l106, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t166, ptr %l107
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l108, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 39
  %t171 = load i64, ptr %l6, !tbaa !24
  %t174 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s3, ptr %t170, i64 %t171)
  store %"compiler/check:laneNode" %t174, ptr %l112
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t175 = getelementptr %"compiler/check:laneNode", ptr %l112, i32 0, i32 8
  %t176 = load i32, ptr %t175, !tbaa !23
  %t177 = load ptr, ptr %l108, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t177, i32 %t176)
  store { i64, ptr } %t179, ptr %l114
  br label %bb40
bb40:
  %t180 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  %t182 = extractvalue { i64, ptr } %t180, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  %t188 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneMaskBool(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d18, i32 0, i32 1) }, { i64, ptr } %t186)
  store %"compiler/diagmsg:Msg" %t188, ptr %l116
  br label %bb41
bb41:
  %t189 = load ptr, ptr %l106, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l107
  %t191 = load %"compiler/diagmsg:Msg", ptr %l116
  %t192 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t189, %"compiler/source:Span" %t190, %"compiler/diagmsg:Msg" %t191)
  store i64 %t192, ptr %l117
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  store ptr null, ptr %l14, !tbaa !29
  store ptr null, ptr %l15, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t194, ptr %l119, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr ptr, ptr %t196, i64 0
  %t198 = load ptr, ptr %t197, !tbaa !39
  %t201 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t193, ptr %t198)
  store i1 %t201, ptr %l121
  br label %bb44
bb44:
  %t202 = load i1, ptr %l121, !tbaa !21
  %t203 = xor i1 %t202, true
  br i1 %t203, label %bb45, label %bb46
bb45:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t206, ptr %l124, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr ptr, ptr %t208, i64 0
  %t210 = load ptr, ptr %t209, !tbaa !39
  %t211 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v3, ptr %v0, ptr %t205, ptr %t210, i32 %t211)
  store ptr %t215, ptr %l127
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t216 = load ptr, ptr %l127, !tbaa !29
  store ptr %t216, ptr %l14, !tbaa !29
  br label %bb48
bb48:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t219, ptr %l130, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr ptr, ptr %t221, i64 1
  %t223 = load ptr, ptr %t222, !tbaa !39
  %t226 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t218, ptr %t223)
  store i1 %t226, ptr %l132
  br label %bb49
bb49:
  %t227 = load i1, ptr %l132, !tbaa !21
  %t228 = xor i1 %t227, true
  br i1 %t228, label %bb50, label %bb51
bb50:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t231, ptr %l135, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr ptr, ptr %t233, i64 1
  %t235 = load ptr, ptr %t234, !tbaa !39
  %t236 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t240 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v3, ptr %v0, ptr %t230, ptr %t235, i32 %t236)
  store ptr %t240, ptr %l138
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t241 = load ptr, ptr %l138, !tbaa !29
  store ptr %t241, ptr %l15, !tbaa !29
  br label %bb53
bb53:
  %t243 = load ptr, ptr %l14, !tbaa !29
  %t245 = icmp eq ptr %t243, null
  br i1 %t245, label %bb54, label %bb55
bb54:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l142, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t248, ptr %l143, !tbaa !27
  %t249 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr ptr, ptr %t250, i64 0
  %t252 = load ptr, ptr %t251, !tbaa !39
  store ptr %t252, ptr %l144, !tbaa !29
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load ptr, ptr %l15, !tbaa !29
  %t257 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v0, ptr %t253, ptr %t254)
  store i32 %t257, ptr %l147
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t258 = load ptr, ptr %l142, !tbaa !29
  %t259 = load ptr, ptr %l144, !tbaa !29
  %t260 = load i32, ptr %l147, !tbaa !23
  %t261 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v3, ptr %v0, ptr %t258, ptr %t259, i32 %t260)
  store ptr %t261, ptr %l148
  br label %bb57
bb57:
  %t262 = load ptr, ptr %l148, !tbaa !29
  store ptr %t262, ptr %l14, !tbaa !29
  br label %bb58
bb58:
  %t264 = load ptr, ptr %l15, !tbaa !29
  %t266 = icmp eq ptr %t264, null
  br i1 %t266, label %bb59, label %bb60
bb59:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l152, !tbaa !29
  %t269 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t269, ptr %l153, !tbaa !27
  %t270 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr ptr, ptr %t271, i64 1
  %t273 = load ptr, ptr %t272, !tbaa !39
  store ptr %t273, ptr %l154, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l14, !tbaa !29
  %t278 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v0, ptr %t274, ptr %t275)
  store i32 %t278, ptr %l157
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t279 = load ptr, ptr %l152, !tbaa !29
  %t280 = load ptr, ptr %l154, !tbaa !29
  %t281 = load i32, ptr %l157, !tbaa !23
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v3, ptr %v0, ptr %t279, ptr %t280, i32 %t281)
  store ptr %t282, ptr %l158
  br label %bb62
bb62:
  %t283 = load ptr, ptr %l158, !tbaa !29
  store ptr %t283, ptr %l15, !tbaa !29
  br label %bb63
bb63:
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l160, !tbaa !29
  %t286 = load ptr, ptr %l14, !tbaa !29
  %t288 = icmp eq ptr %t286, null
  br i1 %t288, label %bb64, label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_f29deef1411bcac7_1d318aa8f75ec9a3)
  unreachable
bb65:
  br label %bb66
bb66:
  %t290 = load ptr, ptr %l14, !tbaa !29
  %t291 = load ptr, ptr %l160, !tbaa !29
  %t293 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v0, ptr %t291, ptr %t290)
  store i64 %t293, ptr %l164
  br label %bb67
bb67:
  %t294 = load i64, ptr %l164, !tbaa !24
  store i64 %t294, ptr %l16, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l165, !tbaa !29
  %t296 = load ptr, ptr %l15, !tbaa !29
  %t298 = icmp eq ptr %t296, null
  br i1 %t298, label %bb68, label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_15db60dea160a9a8_613bb3b113b67e94)
  unreachable
bb69:
  br label %bb70
bb70:
  %t300 = load ptr, ptr %l15, !tbaa !29
  %t301 = load ptr, ptr %l165, !tbaa !29
  %t303 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v0, ptr %t301, ptr %t300)
  store i64 %t303, ptr %l169
  br label %bb71
bb71:
  %t304 = load i64, ptr %l169, !tbaa !24
  store i64 %t304, ptr %l17, !tbaa !24
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/check:Checker", ptr %t305, i32 0, i32 39
  %t308 = load i64, ptr %l16, !tbaa !24
  %t311 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t307, i64 %t308)
  store %"compiler/check:laneNode" %t311, ptr %l173
  br label %bb72
bb72:
  %t312 = getelementptr %"compiler/check:laneNode", ptr %l173, i32 0, i32 8
  %t313 = load i32, ptr %t312, !tbaa !23
  store i32 %t313, ptr %l18, !tbaa !23
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 39
  %t318 = load i64, ptr %l17, !tbaa !24
  %t321 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t317, i64 %t318)
  store %"compiler/check:laneNode" %t321, ptr %l178
  br label %bb73
bb73:
  %t322 = getelementptr %"compiler/check:laneNode", ptr %l178, i32 0, i32 8
  %t323 = load i32, ptr %t322, !tbaa !23
  store i32 %t323, ptr %l19, !tbaa !23
  %t325 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t325, ptr %l20, !tbaa !23
  %t327 = load i32, ptr %l18, !tbaa !23
  %t328 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t331 = icmp ne i32 %t327, %t328
  br i1 %t331, label %bb74, label %bb75
bb74:
  %t333 = load i32, ptr %l19, !tbaa !23
  %t334 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t337 = icmp ne i32 %t333, %t334
  store i1 %t337, ptr %l184, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb76
bb76:
  %t339 = load i1, ptr %l184, !tbaa !21
  br i1 %t339, label %bb77, label %bb78
bb77:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/check:Checker", ptr %t340, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t345 = getelementptr %"compiler/generic:Program", ptr %t343, i32 0, i32 2
  %t346 = load i32, ptr %l18, !tbaa !23
  %t347 = load i32, ptr %l19, !tbaa !23
  %t351 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t345, i32 %t346, i32 %t347)
  store i1 %t351, ptr %l193
  br label %bb79
bb78:
  br label %bb100
bb79:
  %t352 = load i1, ptr %l193, !tbaa !21
  br i1 %t352, label %bb80, label %bb81
bb80:
  %t353 = load i32, ptr %l18, !tbaa !23
  store i32 %t353, ptr %l20, !tbaa !23
  br label %bb99
bb81:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i32, ptr %l18, !tbaa !23
  %t359 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t355, i32 %t356)
  store i1 %t359, ptr %l197
  br label %bb82
bb82:
  %t360 = load i1, ptr %l197, !tbaa !21
  br i1 %t360, label %bb83, label %bb84
bb83:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr %l19, !tbaa !23
  %t365 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t361, i32 %t362)
  store i1 %t365, ptr %l201
  br label %bb85
bb84:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb86
bb85:
  %t366 = load i1, ptr %l201, !tbaa !21
  store i1 %t366, ptr %l198, !tbaa !21
  br label %bb86
bb86:
  %t367 = load i1, ptr %l198, !tbaa !21
  br i1 %t367, label %bb87, label %bb88
bb87:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/check:Checker", ptr %t368, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !29
  %t372 = load i32, ptr %l18, !tbaa !23
  %t373 = load i32, ptr %l19, !tbaa !23
  %t377 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t371, i32 %t372, i32 %t373)
  store i32 %t377, ptr %l207
  br label %bb89
bb88:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb90
bb89:
  %t378 = load i32, ptr %l207, !tbaa !23
  %t379 = icmp sge i32 %t378, 0
  store i1 %t379, ptr %l202, !tbaa !21
  br label %bb90
bb90:
  %t381 = load i1, ptr %l202, !tbaa !21
  br i1 %t381, label %bb91, label %bb92
bb91:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/check:Checker", ptr %t382, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !29
  %t386 = load i32, ptr %l18, !tbaa !23
  %t387 = load i32, ptr %l19, !tbaa !23
  %t391 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t385, i32 %t386, i32 %t387)
  store i32 %t391, ptr %l213
  br label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s12
  %t392 = load ptr, ptr %l0, !tbaa !29
  store ptr %t392, ptr %l214, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t393, ptr %l215
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load i32, ptr %l18, !tbaa !23
  %t398 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t394, i32 %t395)
  store { i64, ptr } %t398, ptr %l218
  br label %bb94
bb93:
  %t399 = load i32, ptr %l213, !tbaa !23
  store i32 %t399, ptr %l20, !tbaa !23
  br label %bb98
bb94:
  %t400 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t400, 0
  %t402 = extractvalue { i64, ptr } %t400, 1
  %t403 = mul i64 %t401, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t403)
  call void @llvm.memcpy.p0.p0.i64(ptr %t404, ptr %t402, i64 %t403, i1 false)
  %t405 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  store { i64, ptr } %t406, ptr %l219, !tbaa !27
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t408 = load i32, ptr %l19, !tbaa !23
  %t411 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t407, i32 %t408)
  store { i64, ptr } %t411, ptr %l222
  br label %bb95
bb95:
  %t412 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t412, 0
  %t414 = extractvalue { i64, ptr } %t412, 1
  %t415 = mul i64 %t413, 1
  %t416 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t415)
  call void @llvm.memcpy.p0.p0.i64(ptr %t416, ptr %t414, i64 %t415, i1 false)
  %t417 = insertvalue { i64, ptr } undef, i64 %t413, 0
  %t418 = insertvalue { i64, ptr } %t417, ptr %t416, 1
  %t419 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t421 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %s12, ptr %s12, ptr %s12, ptr %s12, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d19, i32 0, i32 1) }, { i64, ptr } %t419, { i64, ptr } %t418)
  store %"compiler/diagmsg:Msg" %t421, ptr %l224
  br label %bb96
bb96:
  %t422 = load ptr, ptr %l214, !tbaa !29
  %t423 = load %"compiler/source:Span", ptr %l215
  %t424 = load %"compiler/diagmsg:Msg", ptr %l224
  %t425 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t422, %"compiler/source:Span" %t423, %"compiler/diagmsg:Msg" %t424)
  store i64 %t425, ptr %l225
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s12)
  br label %bb98
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t426 = load i64, ptr %l6, !tbaa !24
  %t427 = load i64, ptr %l16, !tbaa !24
  %t428 = load i64, ptr %l17, !tbaa !24
  %t430 = insertvalue [3 x i64] undef, i64 %t426, 0
  %t432 = insertvalue [3 x i64] %t430, i64 %t427, 1
  %t434 = insertvalue [3 x i64] %t432, i64 %t428, 2
  store [3 x i64] %t434, ptr %l21
  %t436 = load ptr, ptr %l0, !tbaa !29
  store ptr %t436, ptr %l230, !tbaa !29
  %t437 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t437, ptr %l231
  %t438 = load ptr, ptr %l0, !tbaa !29
  store ptr %t438, ptr %l232, !tbaa !29
  %t439 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneSel, !tbaa !24
  store i64 %t439, ptr %l233, !tbaa !24
  store i32 67, ptr %l234
  %t440 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t440, ptr %l235
  %t441 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t441, ptr %l236
  %t442 = load i64, ptr %l6, !tbaa !24
  store i64 %t442, ptr %l237, !tbaa !24
  %t443 = load i64, ptr %l16, !tbaa !24
  store i64 %t443, ptr %l238, !tbaa !24
  %t444 = load i64, ptr %l17, !tbaa !24
  store i64 %t444, ptr %l239, !tbaa !24
  %t445 = load i32, ptr %l20, !tbaa !23
  store i32 %t445, ptr %l240, !tbaa !23
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = insertvalue { i64, ptr } undef, i64 3, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %l21, 1
  %t450 = load %"compiler/source:Span", ptr %l2
  %t454 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %s2, ptr %t446, { i64, ptr } %t449, %"compiler/source:Span" %t450)
  store i64 %t454, ptr %l245
  br label %bb101
bb101:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load i64, ptr %l16, !tbaa !24
  %t457 = load i64, ptr %l17, !tbaa !24
  %t458 = mul i64 2, 8
  %t459 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t458)
  %t460 = insertvalue { i64, ptr } undef, i64 2, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t459, 1
  store { i64, ptr } %t461, ptr %l249, !tbaa !27
  %t463 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !27
  %t465 = getelementptr i64, ptr %t464, i64 0
  store i64 %t456, ptr %t465, !tbaa !34
  %t467 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr i64, ptr %t468, i64 1
  store i64 %t457, ptr %t469, !tbaa !34
  %t470 = load i32, ptr %l20, !tbaa !23
  %t472 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t474 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %s2, ptr %t455, { i64, ptr } %t472, i32 %t470)
  store i32 %t474, ptr %l251
  br label %bb102
bb102:
  %t475 = load i64, ptr %l233, !tbaa !24
  %t476 = load i32, ptr %l234, !range !{i32 0, i32 113}
  %t477 = load %"compiler/source:Span", ptr %l235
  %t478 = load %"compiler/source:Span", ptr %l236
  %t479 = load i64, ptr %l237, !tbaa !24
  %t480 = load i64, ptr %l238, !tbaa !24
  %t481 = load i64, ptr %l239, !tbaa !24
  %t482 = load i32, ptr %l240, !tbaa !23
  %t483 = load i64, ptr %l245, !tbaa !24
  %t484 = load i32, ptr %l251, !tbaa !23
  %t485 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t475, i32 %t476, %"compiler/source:Span" %t477, %"compiler/source:Span" %t478, i64 %t479, i64 %t480, i64 %t481, ptr null, i32 %t482, i64 %t483, i32 %t484)
  store %"compiler/check:laneNode" %t485, ptr %l252
  br label %bb103
bb103:
  %t486 = load ptr, ptr %l232, !tbaa !29
  %t487 = load %"compiler/check:laneNode", ptr %l252
  %t488 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t486, %"compiler/check:laneNode" %t487)
  store i64 %t488, ptr %l253
  br label %bb104
bb104:
  %t489 = load ptr, ptr %l230, !tbaa !29
  %t490 = load %"compiler/source:Span", ptr %l231
  %t491 = load i64, ptr %l253, !tbaa !24
  %t492 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v4, ptr %t489, %"compiler/source:Span" %t490, i64 %t491)
  store ptr %t492, ptr %l254
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t493 = load ptr, ptr %l254, !tbaa !29
  store ptr %t493, ptr %rv
  br label %ret
bb106:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load %"compiler/source:Span", ptr %l1
  %t496 = load %"compiler/source:Span", ptr %l2
  %t497 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t498 = load i64, ptr %l6, !tbaa !24
  %t504 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTotal(ptr %v0, ptr %v1, ptr %v4, ptr %t494, %"compiler/source:Span" %t495, %"compiler/source:Span" %t496, { i64, ptr } %t497, i64 %t498)
  store ptr %t504, ptr %l260
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s0)
  %t505 = load ptr, ptr %l260, !tbaa !29
  store ptr %t505, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca ptr
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t3 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l3, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t7, ptr %l14
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l14, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 %a1, ptr %l5, !tbaa !24
  store i64 %a2, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l7, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  %t59 = load ptr, ptr %l3, !tbaa !29
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 28
  %t66 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t62, i64 %t57)
  store i32 %t66, ptr %l45
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l41, !tbaa !29
  %t68 = load i32, ptr %l45, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t67, i32 %t68)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t69 = load i64, ptr %l9, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l9, !tbaa !24
  br label %bb9
bb16:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %v1, ptr %t73)
  store { i64, ptr } %t75, ptr %l49
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t76 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i32
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca i32
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 28
  store ptr %t7, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l12, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t10)
  store i64 %t12, ptr %l14
  br label %bb3
bb3:
  %t13 = load i64, ptr %l12, !tbaa !24
  %t14 = load i64, ptr %l14, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t19, i64 %t20)
  store i32 %t23, ptr %l19
  br label %bb7
bb7:
  %t24 = load i32, ptr %l19, !tbaa !23
  %t25 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t25, i32 %t24)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t29, 1
  store i64 %t31, ptr %l4, !tbaa !24
  br label %bb2
bb10:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr %"compiler/check:frame", ptr %t33, i32 0, i32 29
  store ptr %t35, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t37 = load i64, ptr %l7, !tbaa !24
  store i64 %t37, ptr %l26, !tbaa !24
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t38)
  store i64 %t40, ptr %l28
  br label %bb12
bb12:
  %t41 = load i64, ptr %l26, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t47, i64 %t48)
  store i32 %t51, ptr %l33
  br label %bb16
bb16:
  %t52 = load i32, ptr %l33, !tbaa !23
  %t53 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t53, i32 %t52)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l7, !tbaa !24
  br label %bb11
bb19:
  %t61 = load ptr, ptr %lp2
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l22 = alloca i32
  %l26 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i32
  %l40 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca i32
  %l46 = alloca ptr
  %l50 = alloca ptr
  %rv = alloca ptr
  %t86 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l5, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l12
  br label %bb6
bb6:
  %t17 = load i1, ptr %l12, !tbaa !21
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb11
bb9:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t25, ptr %l17
  br label %bb10
bb10:
  %t26 = load i1, ptr %l17, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  store ptr null, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l22
  br label %bb15
bb15:
  %t36 = load i32, ptr %l22, !range !{i32 0, i32 6}
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb19
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l30
  br label %bb18
bb18:
  %t51 = load i1, ptr %l30, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l26, !tbaa !21
  br label %bb19
bb19:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb23
bb21:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l36
  br label %bb22
bb22:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t64 = load i32, ptr %l36, !tbaa !23
  %t66 = icmp eq i32 %t64, %t63
  store i1 %t66, ptr %l32, !tbaa !21
  br label %bb23
bb23:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb24, label %bb25
bb24:
  store ptr null, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l40, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t71)
  store %"compiler/source:Span" %t73, ptr %l42
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t74)
  store %"compiler/source:Span" %t76, ptr %l44
  br label %bb28
bb28:
  %t77 = load i32, ptr %l2, !tbaa !23
  store i32 %t77, ptr %l45, !tbaa !23
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l46, !tbaa !29
  %t79 = icmp sge i64 1, 0
  br i1 %t79, label %bb29, label %bb30
bb29:
  %t81 = icmp sle i64 1, 1152921504606846975
  br i1 %t81, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_89233ed815a81c43_385dc0f6d58c413f)
  unreachable
bb31:
  %t83 = mul i64 1, 8
  %t84 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t83)
  %t85 = load ptr, ptr %l46, !tbaa !29
  store i64 0, ptr %t86
  br label %fill.87
fill.87:
  %t90 = load i64, ptr %t86
  %t91 = icmp slt i64 %t90, 1
  br i1 %t91, label %fillb.88, label %filld.89
fillb.88:
  %t92 = getelementptr ptr, ptr %t84, i64 %t90
  store ptr %t85, ptr %t92
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %t86
  br label %fill.87
filld.89:
  %t94 = insertvalue { i64, ptr } undef, i64 1, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t84, 1
  %t96 = load ptr, ptr %l40, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l42
  %t98 = load %"compiler/source:Span", ptr %l44
  %t99 = load i32, ptr %l45, !tbaa !23
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v0, ptr %v2, ptr %t96, %"compiler/source:Span" %t97, %"compiler/source:Span" %t98, i32 %t99, { i64, ptr } %t95)
  store ptr %t101, ptr %l50
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_89233ed815a81c43_385dc0f6d58c413f)
  unreachable
bb33:
  %t102 = load ptr, ptr %l50, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l39 = alloca %"compiler/check:litv"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 30}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t35, ptr %l20
  br label %bb10
bb10:
  %t36 = load i1, ptr %l20, !tbaa !21
  store i1 %t36, ptr %l5, !tbaa !21
  br label %bb28
bb11:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 30}
  %t44 = icmp eq i64 %t42, 5
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l3, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t54, i32 0, i32 3
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  store i1 %t62, ptr %l31
  br label %bb17
bb17:
  %t63 = load i1, ptr %l31, !tbaa !21
  br i1 %t63, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb21
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  store i1 %t68, ptr %l35
  br label %bb20
bb20:
  %t69 = load i1, ptr %l35, !tbaa !21
  store i1 %t69, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t70 = load i1, ptr %l32, !tbaa !21
  store i1 %t70, ptr %l5, !tbaa !21
  br label %bb28
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t76 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t71, ptr %t72)
  store %"compiler/check:litv" %t76, ptr %l39
  br label %bb26
bb26:
  %t77 = getelementptr %"compiler/check:litv", ptr %l39, i32 0, i32 2
  %t78 = load i1, ptr %t77, !tbaa !21
  store i1 %t78, ptr %l5, !tbaa !21
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_a9a2c4034b6e08dd_84116590a5e4e601)
  unreachable
bb28:
  %t80 = load i1, ptr %l5, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca %"compiler/names:Ref"
  %l32 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 5
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Catch", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp ne i64 %t13, 1
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Catch", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr ptr, ptr %t23, i64 0
  %t25 = load ptr, ptr %t24, !tbaa !39
  %t27 = getelementptr %"compiler/ast:Path", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp ne i64 %t30, 1
  store i1 %t32, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l10, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l18, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l21, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t44)
  store ptr %t46, ptr %l23
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t49 = getelementptr %"compiler/check:frame", ptr %t47, i32 0, i32 2
  %t50 = load i64, ptr %t49, !tbaa !24
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Catch", ptr %t51, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l27, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr ptr, ptr %t56, i64 0
  %t58 = load ptr, ptr %t57, !tbaa !39
  %t60 = getelementptr %"compiler/ast:Path", ptr %t58, i32 0, i32 0
  %t61 = getelementptr %"compiler/source:Span", ptr %t60, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load ptr, ptr %l21, !tbaa !29
  %t66 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t63, i64 %t50, i32 %t62)
  store %"compiler/names:Ref" %t66, ptr %l30
  br label %bb11
bb11:
  %t67 = getelementptr %"compiler/names:Ref", ptr %l30, i32 0, i32 0
  %t68 = load i32, ptr %t67, !range !{i32 0, i32 9}
  %t69 = load ptr, ptr %l18, !tbaa !29
  %t71 = call i1 @compiler_2fnames_2eLoneCatchName(ptr %v1, ptr %t69, i32 %t68)
  store i1 %t71, ptr %l32
  br label %bb12
bb12:
  %t72 = load i1, ptr %l32, !tbaa !21
  store i1 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodOverlap(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l10 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l50 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l54 = alloca i32
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %l58 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca i64
  %l77 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca { i64, [3 x i64] }
  %l85 = alloca { i64, ptr }
  %l88 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOverlap(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i64, ptr %l10, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l16, !tbaa !29
  store ptr %t22, ptr %l3, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l19, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t38, i64 %t39)
  store i32 %t42, ptr %l26
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = load i32, ptr %l26, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t45, ptr %l27
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = load i32, ptr %l27, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t46, i32 %t47)
  store { i64, ptr } %t48, ptr %l28
  br label %bb8
bb8:
  %t49 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t49, ptr %l4, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t54 = icmp eq i64 %t52, 0
  br i1 %t54, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l32, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l36
  br label %bb12
bb12:
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t66 = load ptr, ptr %l32, !tbaa !29
  %t67 = load i64, ptr %l36, !tbaa !24
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t66, i64 -1, i64 %t67, i32 %t65, i32 0)
  store ptr %t69, ptr %l38
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t75 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t71, ptr %t72)
  store %"compiler/source:Span" %t75, ptr %l42
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t76, i32 %t80)
  store { i64, ptr } %t83, ptr %l46
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l47, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  store ptr %t90, ptr %l50, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t92, ptr %l52, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 0
  %t96 = load i32, ptr %t95, !tbaa !33
  %t99 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t91, i32 %t96)
  store i32 %t99, ptr %l54
  br label %bb16
bb16:
  %t100 = load ptr, ptr %l50, !tbaa !29
  %t101 = load i32, ptr %l54, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t102, ptr %l55
  br label %bb17
bb17:
  %t103 = load ptr, ptr %l47, !tbaa !29
  %t104 = load i32, ptr %l55, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l56
  br label %bb18
bb18:
  %t106 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  %t108 = extractvalue { i64, ptr } %t106, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  %t113 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t115 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOverlap(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t113, { i64, ptr } %t112)
  store %"compiler/diagmsg:Msg" %t115, ptr %l58
  br label %bb19
bb19:
  %t116 = load ptr, ptr %l39, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l42
  %t118 = load %"compiler/diagmsg:Msg", ptr %l58
  %t119 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t116, %"compiler/source:Span" %t117, %"compiler/diagmsg:Msg" %t118)
  store i64 %t119, ptr %l59
  br label %bb20
bb20:
  %t120 = load i64, ptr %l59, !tbaa !24
  store i64 %t120, ptr %l5, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t121)
  br label %bb21
bb21:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t127 = load i64, ptr %l2, !tbaa !24
  %t130 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t126, i64 %t127)
  store ptr %t130, ptr %l64
  br label %bb22
bb22:
  %t131 = load ptr, ptr %l64, !tbaa !29
  store ptr %t131, ptr %l6, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l65, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load i64, ptr %l2, !tbaa !24
  %t140 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l69
  br label %bb23
bb23:
  %t141 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t142 = load ptr, ptr %l65, !tbaa !29
  %t143 = load i64, ptr %l69, !tbaa !24
  %t145 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t142, i64 -1, i64 %t143, i32 %t141, i32 0)
  store ptr %t145, ptr %l71
  br label %bb24
bb24:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/load:Loader", ptr %t152, i32 0, i32 4
  %t155 = load ptr, ptr %t154, !tbaa !29
  store ptr %t155, ptr %l75, !tbaa !29
  %t156 = load i64, ptr %l5, !tbaa !24
  store i64 %t156, ptr %l76, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l77, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l6, !tbaa !29
  %t162 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t158, ptr %t159)
  store %"compiler/source:Span" %t162, ptr %l80
  br label %bb25
bb25:
  %t163 = load ptr, ptr %l77, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l80
  %t165 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t163, %"compiler/source:Span" %t164)
  store { i64, [3 x i64] } %t165, ptr %l81
  br label %bb26
bb26:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l6, !tbaa !29
  %t169 = getelementptr %"compiler/ast:Func", ptr %t167, i32 0, i32 2
  %t170 = load i32, ptr %t169, !tbaa !23
  %t173 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t166, i32 %t170)
  store { i64, ptr } %t173, ptr %l85
  br label %bb27
bb27:
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t176 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = add i64 %t175, %t178
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t182 = add i64 %t179, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t174, i64 %t175)
  %t184 = getelementptr i8, ptr %t183, i64 %t175
  call void @olang_textcopy(ptr %t184, ptr %t177, i64 %t178)
  %t185 = getelementptr i8, ptr %t184, i64 %t178
  call void @olang_textcopy(ptr %t185, ptr %t180, i64 %t181)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t183, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = extractvalue { i64, ptr } %t187, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  %t196 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s0, ptr %s0, { i64, ptr } %t194)
  store %"compiler/diagmsg:Msg" %t196, ptr %l88
  br label %bb28
bb28:
  %t197 = load ptr, ptr %l75, !tbaa !29
  %t198 = load i64, ptr %l76, !tbaa !24
  %t199 = load { i64, [3 x i64] }, ptr %l81
  %t200 = load %"compiler/diagmsg:Msg", ptr %l88
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t197, i64 %t198, { i64, [3 x i64] } %t199, %"compiler/diagmsg:Msg" %t200)
  br label %bb29
bb29:
  %t201 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t201)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutOnValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l22 = alloca i1
  %l24 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"compiler/diagmsg:Msg"
  %l41 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t24, i32 0, i32 2
  %t26 = load i1, ptr %t25
  store i1 %t26, ptr %l4, !tbaa !21
  br label %bb5
bb4:
  br label %bb22
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load i1, ptr %l4, !tbaa !21
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb12
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3bd31798abdf2684_ea9ddda83177a8c8)
  unreachable
bb9:
  br label %bb10
bb10:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erefWritten(ptr %v0, ptr %v1, ptr %t38, ptr %t37)
  store i1 %t40, ptr %l22
  br label %bb11
bb11:
  %t41 = load i1, ptr %l22, !tbaa !21
  store i1 %t41, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l17, !tbaa !21
  br i1 %t42, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l24, !tbaa !29
  %t45 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t46 = load i32, ptr %t45, !tbaa !23
  %t47 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = add i32 %t48, 3
  %t53 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t46, i32 %t50)
  store %"compiler/source:Span" %t53, ptr %l28
  br label %bb16
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l29, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l31, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t59)
  store ptr %t61, ptr %l33
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l33, !tbaa !29
  %t64 = getelementptr %"compiler/check:frame", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t69 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t66, ptr %t64, ptr %t65)
  store i32 %t69, ptr %l37
  br label %bb18
bb18:
  %t70 = load ptr, ptr %l29, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t70, i32 %t71)
  store { i64, ptr } %t72, ptr %l38
  br label %bb19
bb19:
  %t73 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = extractvalue { i64, ptr } %t73, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t81 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMutOnValueType(ptr %s1, ptr %s1, { i64, ptr } %t79)
  store %"compiler/diagmsg:Msg" %t81, ptr %l40
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l24, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l28
  %t84 = load %"compiler/diagmsg:Msg", ptr %l40
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t82, %"compiler/source:Span" %t83, %"compiler/diagmsg:Msg" %t84)
  store i64 %t85, ptr %l41
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7a28fcbf35f9c2ea_43c4b143baba89fe)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgUnknown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/msgs:Nearest"
  %l22 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca %"compiler/diagmsg:Msg"
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca %"compiler/diagmsg:Msg"
  %l63 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t7 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store %"compiler/msgs:Nearest" %t7, ptr %l13
  br label %bb2
bb2:
  %t8 = load %"compiler/msgs:Nearest", ptr %l13
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t8, ptr %t9
  store ptr %t9, ptr %l5, !tbaa !29
  store { i64, ptr } %a3, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l8, !tbaa !24
  br label %bb3
bb3:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l8, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb4, label %bb5
bb4:
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t25, ptr %l22, !tbaa !27
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l9, !tbaa !29
  %t33 = load ptr, ptr %l9, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Param", ptr %t33, i32 0, i32 3
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load ptr, ptr %l5, !tbaa !29
  store ptr %t42, ptr %l29, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l9, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Param", ptr %t44, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t43, i32 %t47)
  store { i64, ptr } %t50, ptr %l33
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t51, { i64, ptr } %t52)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb3
bb13:
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/msgs:Nearest", ptr %t57, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t64 = icmp sgt i64 %t62, 0
  br i1 %t64, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l40, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t67, ptr %l41
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s5, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l44
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l53, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t74, ptr %l54
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l2, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t75, i32 %t76)
  store { i64, ptr } %t79, ptr %l57
  br label %bb20
bb16:
  %t80 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l45, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t89 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v2, ptr %s5, { i64, ptr } %t87)
  store { i64, ptr } %t89, ptr %l47
  br label %bb17
bb17:
  %t90 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/msgs:Nearest", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t104 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknownMeant(ptr %s5, ptr %s5, ptr %s0, ptr %s5, { i64, ptr } %t101, { i64, ptr } %t96, { i64, ptr } %t100)
  store %"compiler/diagmsg:Msg" %t104, ptr %l51
  br label %bb18
bb18:
  %t105 = load ptr, ptr %l40, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l41
  %t107 = load %"compiler/diagmsg:Msg", ptr %l51
  %t108 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t105, %"compiler/source:Span" %t106, %"compiler/diagmsg:Msg" %t107)
  store i64 %t108, ptr %l52
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb20:
  %t109 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l58, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t118 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v2, ptr %s6, { i64, ptr } %t116)
  store { i64, ptr } %t118, ptr %l60
  br label %bb21
bb21:
  %t119 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  %t121 = extractvalue { i64, ptr } %t119, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  %t126 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t128 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknown(ptr %s6, ptr %s6, ptr %s6, { i64, ptr } %t126, { i64, ptr } %t125)
  store %"compiler/diagmsg:Msg" %t128, ptr %l62
  br label %bb22
bb22:
  %t129 = load ptr, ptr %l53, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l54
  %t131 = load %"compiler/diagmsg:Msg", ptr %l62
  %t132 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t129, %"compiler/source:Span" %t130, %"compiler/diagmsg:Msg" %t131)
  store i64 %t132, ptr %l63
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedBranch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l21 = alloca i64
  %l26 = alloca { i64, i64, i64 }
  %l46 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t17, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 37
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l21
  br label %bb5
bb5:
  %t29 = load i64, ptr %l21, !tbaa !24
  store i64 %t29, ptr %l4, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Branch", ptr %t31, i32 0, i32 0
  %t34 = load %"compiler/source:Span", ptr %t33
  %t38 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t30, i32 1, %"compiler/source:Span" %t34)
  store { i64, i64, i64 } %t38, ptr %l26
  br label %bb6
bb6:
  %t39 = load { i64, i64, i64 }, ptr %l26
  store { i64, i64, i64 } %t39, ptr %l5
  %t40 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  %t43 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  %t46 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t47 = load i64, ptr %t46, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Branch", ptr %t49, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb7, label %bb8
bb7:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v2, ptr %t58, ptr %a2, i1 %a3, i64 %t61)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/ast:Branch", ptr %t67, i32 0, i32 1
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t66, { i64, ptr } %t70)
  br label %bb11
bb11:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l4, !tbaa !24
  %t83 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v3, ptr %t73, i64 %t74, i64 %t75, i64 %t76, i64 %t77)
  store ptr %t83, ptr %l46
  br label %bb12
bb12:
  %t84 = load ptr, ptr %l46, !tbaa !29
  store ptr %t84, ptr %l9, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/ast:Branch", ptr %t85, i32 0, i32 2
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = icmp sge i64 %t88, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/load:Loader", ptr %t98, i32 0, i32 4
  %t101 = load ptr, ptr %t100, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t101)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t103 = load ptr, ptr %l9, !tbaa !29
  store ptr %t103, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb9
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 135
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t19)
  store ptr %t21, ptr %l12
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i32, ptr %l2, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s1, i64 %t25, i64 %t28)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, ptr %l17
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l10, !tbaa !29
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33, i1 true)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_bb9360f661a84828_a83eb458d7764d44)
  unreachable
bb14:
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca i1
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca ptr
  %l21 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l23 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 109
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l4
  %t6 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v2, ptr %l4)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store ptr %t7, ptr %lp2
  %t8 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l6
  %t9 = load ptr, ptr %lp2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t8, ptr %t9
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 109
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t12, ptr %t14
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsFixed(ptr %v0, ptr %v1, ptr %t15, ptr %a1)
  store i1 %t19, ptr %l11
  br label %bb3
bb3:
  %t20 = load i1, ptr %l11, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i32 65536, ptr %l13, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  %t24 = load ptr, ptr %lp2
  %t25 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %l15
  %t27 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0, ptr %l15)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t27, ptr %l17
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t28 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  %t29 = load ptr, ptr %l14, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 109
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t28, ptr %t30
  %t31 = load i32, ptr %l13, !tbaa !23
  %t32 = insertvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } zeroinitializer, i32 %t31, 0
  store { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t32, ptr %rv
  br label %ret
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 109
  %t36 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t35
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t36, ptr %l19
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l20, !tbaa !29
  %t38 = load ptr, ptr %lp2
  %t39 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t38
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t39, ptr %l21
  %t41 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0, ptr %l21)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t41, ptr %l23
  br label %bb8
bb8:
  %t42 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l23
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 109
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t42, ptr %t44
  %t45 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  %t46 = insertvalue { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } zeroinitializer, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t45, 1
  store { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %t46, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }, ptr %rv
  ret { i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store %"compiler/source:Span" %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 30}
  %t29 = icmp eq i64 %t27, 5
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 113}
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l25, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t50)
  store %"compiler/source:Span" %t52, ptr %l27
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l29
  br label %bb14
bb14:
  %t56 = load i32, ptr %l3, !range !{i32 0, i32 113}
  %t58 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t56)
  store { i64, ptr } %t58, ptr %l31
  br label %bb15
bb15:
  %t59 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = load ptr, ptr %l25, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l27
  %t63 = load %"compiler/source:Span", ptr %l29
  %t65 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t61, %"compiler/source:Span" %t62, %"compiler/source:Span" %t63, i64 %t60)
  store %"compiler/source:Span" %t65, ptr %l33
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  %t66 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t66, ptr %rv
  br label %ret
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t67)
  store %"compiler/source:Span" %t69, ptr %l35
  br label %bb21
bb21:
  %t70 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t70, ptr %rv
  br label %ret
bb22:
  call void @__olang_check_failed(ptr @olang_loc_354044a632a7444d_aa07af71c262dc01)
  unreachable
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/check:ownerAt" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownerOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l22 = alloca { i64, ptr }
  %l27 = alloca %"compiler/check:ownerAt"
  %l37 = alloca i32
  %l38 = alloca %"compiler/check:ownerAt"
  %l41 = alloca i32
  %l45 = alloca %"compiler/check:ownerAt"
  %l50 = alloca i32
  %l51 = alloca %"compiler/check:ownerAt"
  %l54 = alloca i32
  %l60 = alloca i32
  %l61 = alloca %"compiler/check:ownerAt"
  %l64 = alloca i32
  %l68 = alloca %"compiler/check:ownerAt"
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca { i64, ptr }
  %l78 = alloca i1
  %l81 = alloca i32
  %l85 = alloca %"compiler/check:ownerAt"
  %l87 = alloca %"compiler/check:ownerAt"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"compiler/check:ownerAt"
  %t52 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 13
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb23
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v1, ptr %s1, ptr %t28)
  store { i64, ptr } %t30, ptr %l22
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t36 = icmp eq i64 %t34, 0
  br i1 %t36, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s2, i32 %t38, i1 false)
  store %"compiler/check:ownerAt" %t40, ptr %l27
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/check:ownerAt", ptr %l27
  store %"compiler/check:ownerAt" %t41, ptr %rv
  br label %ret
bb10:
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = icmp eq i64 %t44, 1
  br i1 %t46, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load %"compiler/source:Span", ptr %l2
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t52
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 0
  store i64 0, ptr %t53
  %t55 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t49, 0
  %t57 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t55, { i64, ptr } %t50, 1
  %t59 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t57, { i64, ptr } %t51, 2
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t59, ptr %t60
  %t61 = load { i64, [5 x i64] }, ptr %t52
  %t63 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 48, i64 8)
  store { i64, [5 x i64] } %t61, ptr %t63
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %s3, ptr %t48, ptr %t63)
  store i32 %t66, ptr %l37
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s3, i32 %t67, i1 false)
  store %"compiler/check:ownerAt" %t68, ptr %l38
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t69 = load %"compiler/check:ownerAt", ptr %l38
  store %"compiler/check:ownerAt" %t69, ptr %rv
  br label %ret
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t70, ptr %t71)
  store i32 %t74, ptr %l41
  br label %bb16
bb16:
  %t75 = load i32, ptr %l41, !tbaa !23
  store i32 %t75, ptr %l6, !tbaa !23
  %t76 = load i32, ptr %l6, !tbaa !23
  %t78 = icmp slt i32 %t76, 0
  br i1 %t78, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s4, i32 %t80, i1 false)
  store %"compiler/check:ownerAt" %t82, ptr %l45
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t83 = load %"compiler/check:ownerAt", ptr %l45
  store %"compiler/check:ownerAt" %t83, ptr %rv
  br label %ret
bb20:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l2
  %t86 = load i32, ptr %l6, !tbaa !23
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t92 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eapplyAt(ptr %v0, ptr %v1, ptr %t84, %"compiler/source:Span" %t85, i32 %t86, { i64, ptr } %t87)
  store i32 %t92, ptr %l50
  br label %bb21
bb21:
  %t93 = load i32, ptr %l50, !tbaa !23
  %t94 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s1, i32 %t93, i1 false)
  store %"compiler/check:ownerAt" %t94, ptr %l51
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t95 = load %"compiler/check:ownerAt", ptr %l51
  store %"compiler/check:ownerAt" %t95, ptr %rv
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_25badba18653f983_c74616522228d697)
  unreachable
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i32 %t100, ptr %l54
  br label %bb29
bb29:
  %t101 = load i32, ptr %l54, !tbaa !23
  store i32 %t101, ptr %l7, !tbaa !23
  %t102 = load i32, ptr %l7, !tbaa !23
  %t104 = icmp sge i32 %t102, 0
  br i1 %t104, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i32, ptr %l7, !tbaa !23
  %t113 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l60
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t114 = load i32, ptr %l60, !tbaa !23
  %t115 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s6, i32 %t114, i1 true)
  store %"compiler/check:ownerAt" %t115, ptr %l61
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t116 = load %"compiler/check:ownerAt", ptr %l61
  store %"compiler/check:ownerAt" %t116, ptr %rv
  br label %ret
bb34:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t121 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  store i32 %t121, ptr %l64
  br label %bb35
bb35:
  %t122 = load i32, ptr %l64, !tbaa !23
  store i32 %t122, ptr %l8, !tbaa !23
  %t123 = load i32, ptr %l8, !tbaa !23
  %t125 = icmp sge i32 %t123, 0
  br i1 %t125, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t127 = load i32, ptr %l8, !tbaa !23
  %t129 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s7, i32 %t127, i1 false)
  store %"compiler/check:ownerAt" %t129, ptr %l68
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load %"compiler/check:ownerAt", ptr %l68
  store %"compiler/check:ownerAt" %t130, ptr %rv
  br label %ret
bb39:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t132 = load ptr, ptr %l69, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb40, label %bb41
bb40:
  %t135 = load ptr, ptr %l69, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 30}
  %t138 = icmp eq i64 %t136, 14
  store i1 %t138, ptr %l70, !tbaa !21
  br label %bb41
bb41:
  %t139 = load i1, ptr %l70, !tbaa !21
  br i1 %t139, label %bb42, label %bb43
bb42:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t142, i32 0, i32 2
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l9, !tbaa !23
  br label %bb44
bb43:
  br label %bb54
bb44:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l9, !tbaa !23
  %t150 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t146, i32 %t147)
  store { i64, ptr } %t150, ptr %l77
  br label %bb45
bb45:
  %t151 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t152 = call i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %t151)
  store i1 %t152, ptr %l78
  br label %bb46
bb46:
  %t153 = load i1, ptr %l78, !tbaa !21
  br i1 %t153, label %bb47, label %bb48
bb47:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t158 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t154, ptr %t155)
  store i32 %t158, ptr %l81
  br label %bb49
bb48:
  br label %bb54
bb49:
  %t159 = load i32, ptr %l81, !tbaa !23
  store i32 %t159, ptr %l10, !tbaa !23
  %t160 = load i32, ptr %l10, !tbaa !23
  %t162 = icmp sge i32 %t160, 0
  br i1 %t162, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t164 = load i32, ptr %l10, !tbaa !23
  %t166 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s9, i32 %t164, i1 false)
  store %"compiler/check:ownerAt" %t166, ptr %l85
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t167 = load %"compiler/check:ownerAt", ptr %l85
  store %"compiler/check:ownerAt" %t167, ptr %rv
  br label %ret
bb53:
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_6168eeb228a64802_deceb7d8f3c3ddf6)
  unreachable
bb59:
  %t168 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t170 = call %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %s0, i32 %t168, i1 false)
  store %"compiler/check:ownerAt" %t170, ptr %l87
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  %t171 = load %"compiler/check:ownerAt", ptr %l87
  store %"compiler/check:ownerAt" %t171, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:ownerAt", ptr %rv
  ret %"compiler/check:ownerAt" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l9 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i64
  %l18 = alloca i32
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i1
  %l38 = alloca i32
  %l47 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLenKey(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t4, ptr %a1, { i64, ptr } %a2)
  store { i64, ptr } %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i1 %t14, ptr %l11
  br label %bb2
bb2:
  %t15 = load i1, ptr %l11, !tbaa !21
  br i1 %t15, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 16
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load i64, ptr %l15, !tbaa !24
  %t22 = icmp eq i64 %t21, 0
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t26)
  store ptr %t28, ptr %l20
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t31 = getelementptr %"compiler/check:frame", ptr %t29, i32 0, i32 4
  %t32 = getelementptr %"compiler/generic:Context", ptr %t31, i32 0, i32 2
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/load:Loader", ptr %t39, i32 0, i32 3
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t42, { i64, ptr } %t43)
  store i32 %t46, ptr %l28
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = load i32, ptr %l28, !tbaa !23
  %t49 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t47, i32 %t48)
  %t50 = extractvalue { i32, i32 } %t49, 1
  %t51 = extractvalue { i32, i32 } %t49, 0
  store i32 %t51, ptr %l30
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb13, label %ok.53, !prof !99
ok.53:
  store i32 %t50, ptr %l29
  br label %bb12
bb12:
  %t54 = load i32, ptr %l29, !tbaa !23
  store i32 %t54, ptr %l18, !tbaa !23
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i32 -1, ptr %l18, !tbaa !23
  br label %bb15
bb15:
  %t55 = load i32, ptr %l18, !tbaa !23
  store i32 %t55, ptr %l4, !tbaa !23
  %t56 = load i32, ptr %l4, !tbaa !23
  %t58 = icmp slt i32 %t56, 0
  br i1 %t58, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb19
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l4, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l38
  br label %bb18
bb18:
  %t70 = load i32, ptr %l38, !range !{i32 0, i32 33}
  %t72 = trunc i64 26 to i32
  %t73 = icmp eq i32 %t70, %t72
  %t75 = xor i1 %t73, true
  store i1 %t75, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t77 = load i1, ptr %l33, !tbaa !21
  br i1 %t77, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t84, i32 %t85)
  store i64 %t88, ptr %l47
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load i64, ptr %l47, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadPatternOk(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, i32 }
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca %"compiler/check:payloadItem"
  %l19 = alloca ptr
  %l20 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca %"compiler/diagmsg:Msg"
  %l40 = alloca i64
  %l44 = alloca { i64, i32 }
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca %"compiler/diagmsg:Msg"
  %l52 = alloca i64
  %l55 = alloca ptr
  %l60 = alloca i32
  %l62 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/diagmsg:Msg"
  %l74 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l86 = alloca { i64, ptr }
  %l92 = alloca %"compiler/diagmsg:Msg"
  %l93 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l100 = alloca %"compiler/diagmsg:Msg"
  %l101 = alloca i64
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l106 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l108 = alloca i64
  %l110 = alloca i64
  %l115 = alloca %"compiler/check:payloadItem"
  %l126 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t2 = load ptr, ptr %l19, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l19, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l20, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [4 x i64] }, ptr %t13, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t21, i32 0, i32 1
  %t23 = load ptr, ptr %t22
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t27, i32 0, i32 2
  %t29 = load { i64, ptr }, ptr %t28
  store %"compiler/source:Span" %t17, ptr %l8
  store { i64, ptr } %t29, ptr %l9, !tbaa !27
  %t37 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %t23)
  store ptr %t37, ptr %l34
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l34, !tbaa !29
  store ptr %t38, ptr %l10, !tbaa !29
  %t39 = load ptr, ptr %l10, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l37, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t44, ptr %l38
  %t45 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %s2)
  store %"compiler/diagmsg:Msg" %t45, ptr %l39
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t46 = load ptr, ptr %l37, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l38
  %t48 = load %"compiler/diagmsg:Msg", ptr %l39
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t46, %"compiler/source:Span" %t47, %"compiler/diagmsg:Msg" %t48)
  store i64 %t49, ptr %l40
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l10, !tbaa !29
  %t55 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %s0, ptr %t51, ptr %t52)
  store { i64, i32 } %t55, ptr %l44
  br label %bb12
bb12:
  %t56 = load { i64, i32 }, ptr %l44
  store { i64, i32 } %t56, ptr %l11
  %t57 = getelementptr { i64, i32 }, ptr %l11, i32 0, i32 0
  %t58 = load i64, ptr %t57, !tbaa !24
  store i64 %t58, ptr %l12, !tbaa !24
  %t60 = getelementptr { i64, i32 }, ptr %l11, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l13, !tbaa !23
  %t63 = load i64, ptr %l12, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l49, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t68, ptr %l50
  %t69 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %s3)
  store %"compiler/diagmsg:Msg" %t69, ptr %l51
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t70 = load ptr, ptr %l49, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l50
  %t72 = load %"compiler/diagmsg:Msg", ptr %l51
  %t73 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t70, %"compiler/source:Span" %t71, %"compiler/diagmsg:Msg" %t72)
  store i64 %t73, ptr %l52
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  store ptr %t78, ptr %l55, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l13, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l60
  br label %bb18
bb18:
  %t89 = load i64, ptr %l12, !tbaa !24
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t91 = load i32, ptr %l60, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %s0, ptr %t90, i32 %t91, i64 %t89)
  store { i64, ptr } %t93, ptr %l62
  br label %bb19
bb19:
  %t94 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t94, ptr %l14, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = icmp eq i64 %t97, 0
  br i1 %t99, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l66, !tbaa !29
  %t102 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t102, ptr %l67
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l13, !tbaa !23
  %t105 = load i64, ptr %l12, !tbaa !24
  %t109 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %s4, ptr %t103, i32 %t104, i64 %t105)
  store { i64, ptr } %t109, ptr %l71
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t110 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t118 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %s4, ptr %s4, { i64, ptr } %t116)
  store %"compiler/diagmsg:Msg" %t118, ptr %l73
  br label %bb23
bb23:
  %t119 = load ptr, ptr %l66, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l67
  %t121 = load %"compiler/diagmsg:Msg", ptr %l73
  %t122 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t119, %"compiler/source:Span" %t120, %"compiler/diagmsg:Msg" %t121)
  store i64 %t122, ptr %l74
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb25:
  %t124 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t132 = icmp sgt i64 %t126, %t129
  br i1 %t132, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l81, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t135, ptr %l82
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l13, !tbaa !23
  %t138 = load i64, ptr %l12, !tbaa !24
  %t142 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %s5, ptr %t136, i32 %t137, i64 %t138)
  store { i64, ptr } %t142, ptr %l86
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t143 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  %t145 = extractvalue { i64, ptr } %t143, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  %t150 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t159 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %s5, ptr %s5, { i64, ptr } %t149, i64 %t152, i64 %t155)
  store %"compiler/diagmsg:Msg" %t159, ptr %l92
  br label %bb29
bb29:
  %t160 = load ptr, ptr %l81, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l82
  %t162 = load %"compiler/diagmsg:Msg", ptr %l92
  %t163 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t160, %"compiler/source:Span" %t161, %"compiler/diagmsg:Msg" %t162)
  store i64 %t163, ptr %l93
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb31:
  %t167 = xor i1 %a3, true
  br i1 %t167, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l97, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t170, ptr %l98
  %t173 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrPatternNeedsName(ptr %v2, ptr %s6, { i64, ptr } %a2)
  store %"compiler/diagmsg:Msg" %t173, ptr %l100
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t174 = load ptr, ptr %l97, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l98
  %t176 = load %"compiler/diagmsg:Msg", ptr %l100
  %t177 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t174, %"compiler/source:Span" %t175, %"compiler/diagmsg:Msg" %t176)
  store i64 %t177, ptr %l101
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb36:
  %t179 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t179, ptr %l103
  br label %bb37
bb37:
  %t180 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, ptr %l15
  store %olang.scope zeroinitializer, ptr %s7
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t185 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %s7, ptr %t181, ptr %t182)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t185, ptr %l106
  br label %bb38
bb38:
  %t186 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106
  %t187 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t186, ptr %t187
  store ptr %t187, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t189 = load i64, ptr %l17, !tbaa !24
  store i64 %t189, ptr %l108, !tbaa !24
  %t190 = load ptr, ptr %l16, !tbaa !29
  %t192 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eLe_Hf8109b64a4e45220d0da36a987cf38b1(ptr %s7, ptr %t190)
  store i64 %t192, ptr %l110
  br label %bb40
bb40:
  %t193 = load i64, ptr %l108, !tbaa !24
  %t194 = load i64, ptr %l110, !tbaa !24
  %t195 = icmp slt i64 %t193, %t194
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb42:
  br label %bb43
bb43:
  %t199 = load ptr, ptr %l16, !tbaa !29
  %t200 = load i64, ptr %l17, !tbaa !24
  %t203 = call %"compiler/check:payloadItem" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eAt_H64f851f610dd8566f1d7651b626ec99d(ptr %s7, ptr %s7, ptr %t199, i64 %t200)
  store %"compiler/check:payloadItem" %t203, ptr %l115
  br label %bb44
bb44:
  %t204 = load %"compiler/check:payloadItem", ptr %l115
  store %"compiler/check:payloadItem" %t204, ptr %l18
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l8
  %t207 = load i32, ptr %l13, !tbaa !23
  %t208 = load i64, ptr %l12, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t223 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItemOk(ptr %v0, ptr %s8, ptr %s0, ptr %s0, ptr %t205, ptr %l18, %"compiler/source:Span" %t206, i32 %t207, i64 %t208, { i64, ptr } %t209, i64 %t212, ptr %l15, i64 %a4)
  store i1 %t223, ptr %l126
  br label %bb45
bb45:
  %t224 = load i1, ptr %l126, !tbaa !21
  %t225 = xor i1 %t224, true
  br i1 %t225, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t228 = getelementptr %"compiler/check:payloadItem", ptr %l18, i32 0, i32 0
  %t229 = load i32, ptr %t228, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l15, i32 %t229)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  %t232 = load i64, ptr %l17, !tbaa !24
  %t234 = add i64 %t232, 1
  store i64 %t234, ptr %l17, !tbaa !24
  br label %bb39
bb51:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l19 = alloca i64
  %l27 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 27
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettle(ptr %v0, ptr %v0, ptr %t10, ptr %t11)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 0
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 18
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb12
bb8:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/load:Loader", ptr %t32, i32 0, i32 4
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l19
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 42
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr %l19, !tbaa !24
  %t44 = icmp sgt i64 %t42, %t41
  store i1 %t44, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t46 = load i1, ptr %l14, !tbaa !21
  store i1 %t46, ptr %l11, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l11, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 133
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 0
  %t54 = load i64, ptr %t53, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t50, i64 %t54, i1 true)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 16
  %t61 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc78234e963d75e4843d79dfd3cff7b8f(ptr %v0, ptr %v0, ptr %t59)
  %t62 = extractvalue { i32, ptr } %t61, 1
  %t63 = extractvalue { i32, ptr } %t61, 0
  store i32 %t63, ptr %l31
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb18, label %ok.65, !prof !99
ok.65:
  store ptr %t62, ptr %l30
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l30, !tbaa !29
  store ptr %t66, ptr %l27, !tbaa !29
  br label %bb20
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load i1, ptr %l2, !tbaa !21
  %t4 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i1 %t3, i64 %t4)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t11 = load i1, ptr %l2, !tbaa !21
  %t12 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushErrNarrow(ptr %v0, ptr %v1, ptr %t9, ptr %t10, i1 %t11, i64 %t12)
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t19 = load i1, ptr %l2, !tbaa !21
  %t20 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushCases(ptr %v0, ptr %v1, ptr %t17, ptr %t18, i1 %t19, i64 %t20)
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawTable(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca { i64, ptr }
  %l15 = alloca %"compiler/check:rawTable"
  %l19 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l42 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1, ptr %l8, !tbaa !23
  %t2 = icmp sge i64 0, 0
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = icmp sle i64 0, 1152921504606846975
  br i1 %t4, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_ec8a21dbb084e216_fbcda7bc6021fa9a)
  unreachable
bb3:
  %t6 = mul i64 0, 8
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t8, ptr %l11, !tbaa !27
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_ec8a21dbb084e216_fbcda7bc6021fa9a)
  unreachable
bb5:
  %t11 = icmp sle i64 0, 576460752303423487
  br i1 %t11, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_ec8a21dbb084e216_fbcda7bc6021fa9a)
  unreachable
bb7:
  %t13 = mul i64 0, 16
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t19 = call %"compiler/check:rawTable" @compiler_2fcheck_3arawTable_2ector(ptr %v1, ptr %v1, ptr %v1, i32 %t16, i1 false, { i64, ptr } %t17, { i64, ptr } %t15)
  store %"compiler/check:rawTable" %t19, ptr %l15
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ec8a21dbb084e216_fbcda7bc6021fa9a)
  unreachable
bb9:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t20, ptr %lp3
  %t21 = load %"compiler/check:rawTable", ptr %l15
  %t22 = load ptr, ptr %lp3
  store %"compiler/check:rawTable" %t21, ptr %t22
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store ptr %t30, ptr %l19
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l19, !tbaa !29
  store ptr %t31, ptr %l4, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = icmp eq ptr %t32, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb13
bb12:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr %"compiler/ast:TypeDecl", ptr %t36, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  store i1 %t41, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %lp3
  store ptr %t44, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TypeDecl", ptr %t46, i32 0, i32 3
  %t49 = load ptr, ptr %t48, !tbaa !29
  store ptr %t49, ptr %l5, !tbaa !29
  %t51 = load ptr, ptr %l5, !tbaa !29
  store ptr %t51, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t52 = load ptr, ptr %l29, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 5}
  %t58 = icmp eq i64 %t56, 1
  store i1 %t58, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t59 = load i1, ptr %l30, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l5, !tbaa !29
  %t62 = getelementptr { i64, [6 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { { i64, ptr }, ptr }, ptr %t62, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  store { i64, ptr } %t64, ptr %l6, !tbaa !27
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr { i64, [6 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { { i64, ptr }, ptr }, ptr %t68, i32 0, i32 1
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l7, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l1, !tbaa !23
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawEnum(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %t72, i32 %t73, { i64, ptr } %t74, ptr %t75, i1 %a2)
  store ptr %t82, ptr %l42
  br label %bb22
bb22:
  %t83 = load ptr, ptr %l42, !tbaa !29
  store ptr %t83, ptr %rv
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t84 = load ptr, ptr %lp3
  store ptr %t84, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @olang_loc_89ab76664fe93b5c_2e5cefefce25c48)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/check:reflVal"
  %l13 = alloca %"compiler/check:reflVal"
  %l20 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 141
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l2, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 141
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %s0, ptr %t14, ptr %t15)
  store %"compiler/check:reflVal" %t18, ptr %l13
  br label %bb4
bb4:
  %t19 = load %"compiler/check:reflVal", ptr %l13
  store %"compiler/check:reflVal" %t19, ptr %l3
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 141
  %t23 = load i1, ptr %t22, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i1, ptr %l2, !tbaa !21
  %t29 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 141
  store i1 %t26, ptr %t29, !tbaa !21
  %t32 = xor i1 %t23, true
  br i1 %t32, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  %t34 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 0
  %t35 = load i1, ptr %t34, !tbaa !21
  %t37 = xor i1 %t35, true
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  %t40 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t45 = icmp ne i64 %t41, %t42
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t49 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 2
  %t50 = load i64, ptr %t49, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i32, { i64, ptr } }
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i32
  %l52 = alloca i32
  %l64 = alloca { i32, { i64, ptr } }
  %l68 = alloca i1
  %l70 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l81 = alloca %"compiler/diagmsg:Msg"
  %l82 = alloca i64
  %l85 = alloca ptr
  %l86 = alloca i1
  %l93 = alloca i32
  %l94 = alloca ptr
  %l95 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i1
  %l112 = alloca ptr
  %l114 = alloca ptr
  %l118 = alloca %"compiler/names:Ref"
  %l122 = alloca { i64, ptr }
  %l126 = alloca i1
  %l129 = alloca i1
  %l132 = alloca i32
  %l144 = alloca i32
  %l147 = alloca i32
  %l152 = alloca i1
  %l154 = alloca ptr
  %l158 = alloca %"compiler/source:Span"
  %l159 = alloca { i64, ptr }
  %l161 = alloca %"compiler/source:Span"
  %l164 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l173 = alloca i64
  %l175 = alloca i64
  %l176 = alloca %"compiler/diagmsg:Msg"
  %l177 = alloca i64
  %l183 = alloca i32
  %l187 = alloca i1
  %l191 = alloca i1
  %l193 = alloca i1
  %l197 = alloca i1
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i32
  %t268 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i32, ptr %l22, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t9 = icmp sge i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i32, ptr %l2, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t14 = load ptr, ptr %l26, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l26, !tbaa !29
  %t18 = load i64, ptr %t17, !range !{i64 0, i64 30}
  %t20 = icmp eq i64 %t18, 14
  store i1 %t20, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l27, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t24, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  store %"compiler/source:Span" %t26, ptr %l3
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t30, i32 0, i32 1
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l4, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l5, !tbaa !23
  br label %bb9
bb8:
  br label %bb39
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l5, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l38
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = call i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %t46)
  store i1 %t48, ptr %l40
  br label %bb11
bb11:
  %t49 = load i1, ptr %l40, !tbaa !21
  %t50 = xor i1 %t49, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  store i32 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  store i32 -1, ptr %l7, !tbaa !23
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t53, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t55, ptr %l44
  br label %bb15
bb15:
  %t56 = load i1, ptr %l44, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t61 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t57, ptr %t58)
  store i32 %t61, ptr %l47
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t62 = load i32, ptr %l47, !tbaa !23
  store i32 %t62, ptr %l7, !tbaa !23
  br label %bb19
bb19:
  %t63 = load i32, ptr %l7, !tbaa !23
  %t65 = icmp slt i32 %t63, 0
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t71 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  store i32 %t71, ptr %l52
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t72 = load i32, ptr %l52, !tbaa !23
  store i32 %t72, ptr %l7, !tbaa !23
  br label %bb23
bb23:
  %t73 = load i32, ptr %l7, !tbaa !23
  %t75 = icmp slt i32 %t73, 0
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t77 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t77, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t79 = load i32, ptr %l7, !tbaa !23
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t83 = icmp eq i32 %t79, %t80
  br i1 %t83, label %bb27, label %bb28
bb27:
  %t85 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t85, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t91 = load i32, ptr %l7, !tbaa !23
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eProject(ptr %v0, ptr %v0, ptr %s2, ptr %t90, i32 %t91, { i64, ptr } %t92)
  store { i32, { i64, ptr } } %t96, ptr %l64
  br label %bb30
bb30:
  %t97 = load { i32, { i64, ptr } }, ptr %l64
  store { i32, { i64, ptr } } %t97, ptr %l8
  %t98 = getelementptr { i32, { i64, ptr } }, ptr %l8, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  store i32 %t99, ptr %l9, !tbaa !23
  %t101 = getelementptr { i32, { i64, ptr } }, ptr %l8, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  store { i64, ptr } %t102, ptr %l10, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t104, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t106, ptr %l68
  br label %bb31
bb31:
  %t107 = load i1, ptr %l68, !tbaa !21
  %t108 = xor i1 %t107, true
  br i1 %t108, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s8
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l70, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l3
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t111, i64 %t114)
  store %"compiler/source:Span" %t117, ptr %l74
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t118 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t118, ptr %l75, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l7, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l78
  br label %bb35
bb35:
  %t124 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t126 = extractvalue { i64, ptr } %t124, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t131 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t135 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoType(ptr %v0, ptr %s8, ptr %s2, ptr %s8, { i64, ptr } %t132, { i64, ptr } %t130, { i64, ptr } %t131)
  store %"compiler/diagmsg:Msg" %t135, ptr %l81
  br label %bb36
bb36:
  %t136 = load ptr, ptr %l70, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l74
  %t138 = load %"compiler/diagmsg:Msg", ptr %l81
  %t139 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t136, %"compiler/source:Span" %t137, %"compiler/diagmsg:Msg" %t138)
  store i64 %t139, ptr %l82
  br label %bb37
bb37:
  %t140 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s2)
  store i32 %t140, ptr %rv
  br label %ret
bb38:
  %t142 = load i32, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t142, ptr %rv
  br label %ret
bb39:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t145 = load ptr, ptr %l85, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb40, label %bb41
bb40:
  %t148 = load ptr, ptr %l85, !tbaa !29
  %t149 = load i64, ptr %t148, !range !{i64 0, i64 30}
  %t151 = icmp eq i64 %t149, 2
  store i1 %t151, ptr %l86, !tbaa !21
  br label %bb41
bb41:
  %t152 = load i1, ptr %l86, !tbaa !21
  br i1 %t152, label %bb42, label %bb43
bb42:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", ptr }, ptr %t155, i32 0, i32 1
  %t157 = load ptr, ptr %t156
  store ptr %t157, ptr %l11, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l11, !tbaa !29
  %t163 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t159, ptr %t160)
  store i32 %t163, ptr %l93
  br label %bb45
bb45:
  %t164 = load i32, ptr %l93, !tbaa !23
  store i32 %t164, ptr %rv
  br label %ret
bb46:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t166 = load ptr, ptr %l94, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb47, label %bb48
bb47:
  %t169 = load ptr, ptr %l94, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 30}
  %t172 = icmp eq i64 %t170, 13
  store i1 %t172, ptr %l95, !tbaa !21
  br label %bb48
bb48:
  %t173 = load i1, ptr %l95, !tbaa !21
  br i1 %t173, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [4 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t176, i32 0, i32 0
  %t178 = load %"compiler/source:Span", ptr %t177
  store %"compiler/source:Span" %t178, ptr %l12
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t182, i32 0, i32 1
  %t184 = load ptr, ptr %t183
  store ptr %t184, ptr %l13, !tbaa !29
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t188, i32 0, i32 2
  %t190 = load { i64, ptr }, ptr %t189
  store { i64, ptr } %t190, ptr %l14, !tbaa !27
  br label %bb51
bb50:
  br label %bb106
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  store i1 false, ptr %l15, !tbaa !21
  %t192 = load ptr, ptr %l13, !tbaa !29
  store ptr %t192, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t193 = load ptr, ptr %l104, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb52, label %bb53
bb52:
  %t196 = load ptr, ptr %l104, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 30}
  %t199 = icmp eq i64 %t197, 0
  store i1 %t199, ptr %l105, !tbaa !21
  br label %bb53
bb53:
  %t200 = load i1, ptr %l105, !tbaa !21
  br i1 %t200, label %bb54, label %bb55
bb54:
  %t201 = load ptr, ptr %l13, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", i32 }, ptr %t203, i32 0, i32 0
  %t205 = load %"compiler/source:Span", ptr %t204
  store %"compiler/source:Span" %t205, ptr %l16
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = getelementptr %"compiler/generic:Program", ptr %t210, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !29
  store ptr %t213, ptr %l112, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t214)
  store ptr %t216, ptr %l114
  br label %bb57
bb57:
  %t217 = load ptr, ptr %l114, !tbaa !29
  %t219 = getelementptr %"compiler/check:frame", ptr %t217, i32 0, i32 2
  %t220 = load i64, ptr %t219, !tbaa !24
  %t221 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t222 = load i32, ptr %t221, !tbaa !23
  %t223 = load ptr, ptr %l112, !tbaa !29
  %t226 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t223, i64 %t220, i32 %t222)
  store %"compiler/names:Ref" %t226, ptr %l118
  br label %bb58
bb58:
  %t227 = getelementptr %"compiler/names:Ref", ptr %l118, i32 0, i32 0
  %t228 = load i32, ptr %t227, !range !{i32 0, i32 9}
  %t230 = trunc i64 7 to i32
  %t231 = icmp eq i32 %t228, %t230
  store i1 %t231, ptr %l15, !tbaa !21
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_492feac3979049da_7a1ccb679ec95f6e)
  unreachable
bb64:
  %t233 = load ptr, ptr %l13, !tbaa !29
  %t235 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v1, ptr %s10, ptr %t233)
  store { i64, ptr } %t235, ptr %l122
  br label %bb65
bb65:
  %t236 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t236, ptr %l17, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t241 = icmp eq i64 %t239, 0
  br i1 %t241, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb72
bb67:
  %t243 = load i1, ptr %l15, !tbaa !21
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb68, label %bb69
bb68:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l13, !tbaa !29
  %t251 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t247, ptr %t248)
  store i32 %t251, ptr %l132
  br label %bb70
bb69:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb71
bb70:
  %t252 = load i32, ptr %l132, !tbaa !23
  %t253 = icmp slt i32 %t252, 0
  store i1 %t253, ptr %l129, !tbaa !21
  br label %bb71
bb71:
  %t255 = load i1, ptr %l129, !tbaa !21
  store i1 %t255, ptr %l126, !tbaa !21
  br label %bb72
bb72:
  %t256 = load i1, ptr %l126, !tbaa !21
  br i1 %t256, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s10)
  store i32 -1, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t258 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t262 = icmp eq i64 %t260, 1
  br i1 %t262, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s14
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load %"compiler/source:Span", ptr %l12
  %t266 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t268
  %t269 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 0
  store i64 0, ptr %t269
  %t271 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t265, 0
  %t273 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t271, { i64, ptr } %t266, 1
  %t275 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t273, { i64, ptr } %t267, 2
  %t276 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t275, ptr %t276
  %t277 = load { i64, [5 x i64] }, ptr %t268
  %t279 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 48, i64 8)
  store { i64, [5 x i64] } %t277, ptr %t279
  %t282 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %s14, ptr %t264, ptr %t279)
  store i32 %t282, ptr %l144
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s10)
  %t283 = load i32, ptr %l144, !tbaa !23
  store i32 %t283, ptr %rv
  br label %ret
bb79:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l13, !tbaa !29
  %t288 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t284, ptr %t285)
  store i32 %t288, ptr %l147
  br label %bb80
bb80:
  %t289 = load i32, ptr %l147, !tbaa !23
  store i32 %t289, ptr %l18, !tbaa !23
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/check:Checker", ptr %t290, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t294 = load i32, ptr %l18, !tbaa !23
  %t295 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t299 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t293, i32 %t294, { i64, ptr } %t295)
  store i1 %t299, ptr %l152
  br label %bb81
bb81:
  %t300 = load i1, ptr %l152, !tbaa !21
  %t301 = xor i1 %t300, true
  br i1 %t301, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s15
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l154, !tbaa !29
  %t304 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t308 = icmp sgt i64 %t306, 0
  br i1 %t308, label %bb84, label %bb85
bb83:
  br label %bb93
bb84:
  %t310 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t310, ptr %l159, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr ptr, ptr %t312, i64 0
  %t314 = load ptr, ptr %t313, !tbaa !39
  %t316 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t314)
  store %"compiler/source:Span" %t316, ptr %l161
  br label %bb86
bb85:
  %t317 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t317, ptr %l158
  br label %bb87
bb86:
  %t319 = load %"compiler/source:Span", ptr %l161
  store %"compiler/source:Span" %t319, ptr %l158
  br label %bb87
bb87:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t321, ptr %l164, !tbaa !27
  %t322 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t326 = sub i64 %t324, 1
  %t328 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr i32, ptr %t329, i64 %t326
  %t331 = load i32, ptr %t330, !tbaa !33
  %t334 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t320, i32 %t331)
  store { i64, ptr } %t334, ptr %l169
  br label %bb88
bb88:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/check:Checker", ptr %t335, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t339 = load i32, ptr %l18, !tbaa !23
  %t342 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t338, i32 %t339)
  store i64 %t342, ptr %l173
  br label %bb89
bb89:
  %t343 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t345 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t343)
  store i64 %t345, ptr %l175
  br label %bb90
bb90:
  %t346 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t347 = load i64, ptr %l173, !tbaa !24
  %t348 = load i64, ptr %l175, !tbaa !24
  %t349 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s15, { i64, ptr } %t346, i64 %t347, i64 %t348)
  store %"compiler/diagmsg:Msg" %t349, ptr %l176
  br label %bb91
bb91:
  %t350 = load ptr, ptr %l154, !tbaa !29
  %t351 = load %"compiler/source:Span", ptr %l158
  %t352 = load %"compiler/diagmsg:Msg", ptr %l176
  %t353 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t350, %"compiler/source:Span" %t351, %"compiler/diagmsg:Msg" %t352)
  store i64 %t353, ptr %l177
  br label %bb92
bb92:
  %t354 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s10)
  store i32 %t354, ptr %rv
  br label %ret
bb93:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l12
  %t358 = load i32, ptr %l18, !tbaa !23
  %t359 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t364 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eapplyAt(ptr %v0, ptr %v1, ptr %t356, %"compiler/source:Span" %t357, i32 %t358, { i64, ptr } %t359)
  store i32 %t364, ptr %l183
  br label %bb94
bb94:
  %t365 = load i32, ptr %l183, !tbaa !23
  store i32 %t365, ptr %l19, !tbaa !23
  %t366 = load i32, ptr %l19, !tbaa !23
  %t367 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t370 = icmp eq i32 %t366, %t367
  br i1 %t370, label %bb95, label %bb96
bb95:
  store i1 true, ptr %l187, !tbaa !21
  br label %bb98
bb96:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i32, ptr %l19, !tbaa !23
  %t374 = load %"compiler/source:Span", ptr %l12
  %t378 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t372, i32 %t373, %"compiler/source:Span" %t374)
  store i1 %t378, ptr %l191
  br label %bb97
bb97:
  %t379 = load i1, ptr %l191, !tbaa !21
  %t380 = xor i1 %t379, true
  store i1 %t380, ptr %l187, !tbaa !21
  br label %bb98
bb98:
  %t382 = load i1, ptr %l187, !tbaa !21
  br i1 %t382, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb102
bb100:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/check:Checker", ptr %t383, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !29
  %t387 = load i32, ptr %l19, !tbaa !23
  %t390 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t386, i32 %t387)
  store i1 %t390, ptr %l197
  br label %bb101
bb101:
  %t391 = load i1, ptr %l197, !tbaa !21
  %t392 = xor i1 %t391, true
  store i1 %t392, ptr %l193, !tbaa !21
  br label %bb102
bb102:
  %t394 = load i1, ptr %l193, !tbaa !21
  br i1 %t394, label %bb103, label %bb104
bb103:
  %t395 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  store i32 %t395, ptr %rv
  br label %ret
bb104:
  br label %bb105
bb105:
  %t397 = load i32, ptr %l19, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  store i32 %t397, ptr %rv
  br label %ret
bb106:
  br i1 true, label %bb107, label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb110
bb109:
  store i32 -1, ptr %rv
  br label %ret
bb110:
  call void @__olang_check_failed(ptr @olang_loc_42af232d2840e8db_efcef566740b002f)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroArgFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %l28 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i32
  %l53 = alloca i1
  %l58 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca %"compiler/check:roArg"
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l91 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l92 = alloca %"std/pair:Pair.b139c4f75a6545712256427180a82a06"
  %l95 = alloca i1
  %l97 = alloca ptr
  %l102 = alloca %"compiler/check:roDeepArg"
  %l103 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca i1
  %l112 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i64
  %l116 = alloca i64
  %l119 = alloca { i64, [3 x i64] }
  %l120 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l124 = alloca i32
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l130 = alloca i32
  %l133 = alloca i32
  %l134 = alloca { i64, ptr }
  %l136 = alloca %"compiler/check:roArg"
  %l137 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca i64
  %l144 = alloca ptr
  %l147 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l150 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l151 = alloca %"std/pair:Pair.b139c4f75a6545712256427180a82a06"
  %l154 = alloca i1
  %l156 = alloca ptr
  %l161 = alloca %"compiler/check:roDeepArg"
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  store i1 %t7, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l17
  br label %bb7
bb7:
  %t13 = load ptr, ptr %l17, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l20, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t22 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t19)
  store i32 %t22, ptr %l23
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = load i32, ptr %l23, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t25, ptr %l24
  br label %bb9
bb9:
  %t26 = load i1, ptr %l24, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t27, i64 %t28, i64 %t29)
  store i1 %t33, ptr %l28
  br label %bb12
bb11:
  br label %bb57
bb12:
  %t34 = load i1, ptr %l28, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l32, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  store ptr %t48, ptr %l35, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l38, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 14
  %t58 = load i64, ptr %l1, !tbaa !24
  %t61 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t57, i64 %t58)
  store ptr %t61, ptr %l42
  br label %bb16
bb16:
  %t62 = load ptr, ptr %l42, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %t64, !tbaa !23
  %t66 = load ptr, ptr %l38, !tbaa !29
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t66, i32 %t65)
  store i32 %t68, ptr %l45
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t70 = load i32, ptr %l45, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t69, i32 %t70)
  store { i64, ptr } %t71, ptr %l46
  br label %bb18
bb18:
  %t72 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t72, ptr %l47, !tbaa !27
  %t73 = load i64, ptr %l2, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i32, ptr %t76, i64 %t73
  %t78 = load i32, ptr %t77, !tbaa !33
  %t79 = load ptr, ptr %l32, !tbaa !29
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t79, i32 %t78)
  store i32 %t81, ptr %l50
  br label %bb19
bb19:
  %t82 = load i32, ptr %l50, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l7, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l53
  br label %bb20
bb20:
  %t88 = load i1, ptr %l53, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store i1 %t96, ptr %l58
  br label %bb24
bb24:
  %t97 = load i1, ptr %l58, !tbaa !21
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 89
  store ptr %t100, ptr %l60, !tbaa !29
  %t101 = load i64, ptr %l1, !tbaa !24
  store i64 %t101, ptr %l61, !tbaa !24
  %t102 = load i64, ptr %l2, !tbaa !24
  store i64 %t102, ptr %l62, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l4
  %t107 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t103, %"compiler/source:Span" %t104)
  store { i64, [3 x i64] } %t107, ptr %l65
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t108 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t108, ptr %l66, !tbaa !27
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l7, !tbaa !23
  %t113 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t109, i32 %t110)
  store { i64, ptr } %t113, ptr %l69
  br label %bb28
bb28:
  %t114 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  %t116 = extractvalue { i64, ptr } %t114, 1
  %t117 = mul i64 %t115, 1
  %t118 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t117)
  call void @llvm.memcpy.p0.p0.i64(ptr %t118, ptr %t116, i64 %t117, i1 false)
  %t119 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  %t121 = load i64, ptr %l61, !tbaa !24
  %t122 = load i64, ptr %l62, !tbaa !24
  %t123 = load { i64, [3 x i64] }, ptr %l65
  %t124 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t126 = call %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, i64 %t121, i64 %t122, { i64, [3 x i64] } %t123, { i64, ptr } %t124, { i64, ptr } %t120, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store %"compiler/check:roArg" %t126, ptr %l71
  br label %bb29
bb29:
  %t127 = load ptr, ptr %l60, !tbaa !29
  %t128 = load %"compiler/check:roArg", ptr %l71
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v0, ptr %t127, %"compiler/check:roArg" %t128)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb31:
  %t129 = load ptr, ptr %l3, !tbaa !29
  store ptr %t129, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t130 = load ptr, ptr %l72, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t133 = load ptr, ptr %l72, !tbaa !29
  %t134 = load i64, ptr %t133, !range !{i64 0, i64 18}
  %t136 = icmp eq i64 %t134, 3
  store i1 %t136, ptr %l73, !tbaa !21
  br label %bb33
bb33:
  %t137 = load i1, ptr %l73, !tbaa !21
  br i1 %t137, label %bb34, label %bb35
bb34:
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = getelementptr { i64, [5 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l8, !tbaa !29
  br label %bb36
bb35:
  br label %bb45
bb36:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l8, !tbaa !29
  %t149 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t144, ptr %t145)
  store i64 %t149, ptr %l81
  br label %bb37
bb37:
  %t150 = load i64, ptr %l81, !tbaa !24
  store i64 %t150, ptr %l9, !tbaa !24
  %t151 = load i64, ptr %l9, !tbaa !24
  %t153 = icmp sge i64 %t151, 0
  br i1 %t153, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 81
  store ptr %t157, ptr %l85, !tbaa !29
  %t158 = load i64, ptr %l6, !tbaa !24
  %t159 = load i64, ptr %l9, !tbaa !24
  %t162 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t158, i64 %t159)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t162, ptr %l88
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t163 = load i64, ptr %l1, !tbaa !24
  %t164 = load i64, ptr %l2, !tbaa !24
  %t167 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t163, i64 %t164)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t167, ptr %l91
  br label %bb41
bb41:
  %t168 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l88
  %t169 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l91
  %t170 = call %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s7, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t168, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t169)
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t170, ptr %l92
  br label %bb42
bb42:
  %t171 = load ptr, ptr %l85, !tbaa !29
  %t172 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l92
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %t171, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t172)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_3ba07a3e63e86523_b4e2f85113e27c0f)
  unreachable
bb50:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l6, !tbaa !24
  %t177 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t173, i64 %t174)
  store i1 %t177, ptr %l95
  br label %bb51
bb51:
  %t178 = load i1, ptr %l95, !tbaa !21
  br i1 %t178, label %bb52, label %bb53
bb52:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 88
  store ptr %t181, ptr %l97, !tbaa !29
  %t182 = load i64, ptr %l6, !tbaa !24
  %t183 = load ptr, ptr %l3, !tbaa !29
  %t184 = load i64, ptr %l1, !tbaa !24
  %t185 = load i64, ptr %l2, !tbaa !24
  %t190 = call %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v1, ptr %v0, i64 %t182, ptr %t183, i64 %t184, i64 %t185)
  store %"compiler/check:roDeepArg" %t190, ptr %l102
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t191 = load ptr, ptr %l97, !tbaa !29
  %t192 = load %"compiler/check:roDeepArg", ptr %l102
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v0, ptr %t191, %"compiler/check:roDeepArg" %t192)
  br label %bb55
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb57:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l103, !tbaa !29
  %t194 = load ptr, ptr %l3, !tbaa !29
  %t197 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t194)
  store i32 %t197, ptr %l106
  br label %bb58
bb58:
  %t198 = load ptr, ptr %l103, !tbaa !29
  %t199 = load i32, ptr %l106, !tbaa !23
  %t200 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t198, i32 %t199)
  store i1 %t200, ptr %l107
  br label %bb59
bb59:
  %t201 = load i1, ptr %l107, !tbaa !21
  %t202 = xor i1 %t201, true
  br i1 %t202, label %bb60, label %bb61
bb60:
  br label %ret
bb61:
  br label %bb62
bb62:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l3, !tbaa !29
  %t209 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t204, ptr %t205)
  store i1 %t209, ptr %l112
  br label %bb63
bb63:
  %t210 = load i1, ptr %l112, !tbaa !21
  br i1 %t210, label %bb64, label %bb65
bb64:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 82
  store ptr %t213, ptr %l114, !tbaa !29
  %t214 = load i64, ptr %l1, !tbaa !24
  store i64 %t214, ptr %l115, !tbaa !24
  %t215 = load i64, ptr %l2, !tbaa !24
  store i64 %t215, ptr %l116, !tbaa !24
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l4
  %t220 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t216, %"compiler/source:Span" %t217)
  store { i64, [3 x i64] } %t220, ptr %l119
  br label %bb66
bb65:
  br label %bb74
bb66:
  %t221 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t221, ptr %l120, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l121, !tbaa !29
  %t223 = load ptr, ptr %l3, !tbaa !29
  %t226 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t223)
  store i32 %t226, ptr %l124
  br label %bb67
bb67:
  %t227 = load ptr, ptr %l121, !tbaa !29
  %t228 = load i32, ptr %l124, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t227, i32 %t228)
  store { i64, ptr } %t229, ptr %l125
  br label %bb68
bb68:
  %t230 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  store { i64, ptr } %t236, ptr %l126, !tbaa !27
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l127, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l3, !tbaa !29
  %t242 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t238, ptr %t239)
  store i32 %t242, ptr %l130
  br label %bb69
bb69:
  %t243 = load ptr, ptr %l3, !tbaa !29
  %t246 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t243)
  store i32 %t246, ptr %l133
  br label %bb70
bb70:
  %t247 = load ptr, ptr %l127, !tbaa !29
  %t248 = load i32, ptr %l130, !tbaa !23
  %t249 = load i32, ptr %l133, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v0, ptr %t247, i32 %t248, i32 %t249)
  store { i64, ptr } %t250, ptr %l134
  br label %bb71
bb71:
  %t251 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t253 = extractvalue { i64, ptr } %t251, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  %t258 = load i64, ptr %l115, !tbaa !24
  %t259 = load i64, ptr %l116, !tbaa !24
  %t260 = load { i64, [3 x i64] }, ptr %l119
  %t261 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t264 = call %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v2, ptr %v0, ptr %v0, ptr %v0, i64 %t258, i64 %t259, { i64, [3 x i64] } %t260, { i64, ptr } %t261, { i64, ptr } %t262, { i64, ptr } %t257)
  store %"compiler/check:roArg" %t264, ptr %l136
  br label %bb72
bb72:
  %t265 = load ptr, ptr %l114, !tbaa !29
  %t266 = load %"compiler/check:roArg", ptr %l136
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v0, ptr %t265, %"compiler/check:roArg" %t266)
  br label %bb73
bb73:
  br label %ret
bb74:
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l137, !tbaa !29
  %t268 = load ptr, ptr %l3, !tbaa !29
  %t270 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t268)
  store ptr %t270, ptr %l139
  br label %bb75
bb75:
  %t271 = load ptr, ptr %l137, !tbaa !29
  %t272 = load ptr, ptr %l139, !tbaa !29
  %t273 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t271, ptr %t272)
  store i64 %t273, ptr %l140
  br label %bb76
bb76:
  %t274 = load i64, ptr %l140, !tbaa !24
  store i64 %t274, ptr %l10, !tbaa !24
  %t275 = load i64, ptr %l10, !tbaa !24
  %t277 = icmp sge i64 %t275, 0
  br i1 %t277, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s12
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 81
  store ptr %t281, ptr %l144, !tbaa !29
  %t282 = load i64, ptr %l6, !tbaa !24
  %t283 = load i64, ptr %l10, !tbaa !24
  %t286 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t282, i64 %t283)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t286, ptr %l147
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t287 = load i64, ptr %l1, !tbaa !24
  %t288 = load i64, ptr %l2, !tbaa !24
  %t291 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s12, i64 %t287, i64 %t288)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t291, ptr %l150
  br label %bb80
bb80:
  %t292 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l147
  %t293 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l150
  %t294 = call %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s12, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t292, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t293)
  store %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t294, ptr %l151
  br label %bb81
bb81:
  %t295 = load ptr, ptr %l144, !tbaa !29
  %t296 = load %"std/pair:Pair.b139c4f75a6545712256427180a82a06", ptr %l151
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %t295, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %t296)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s12)
  br label %bb83
bb83:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i64, ptr %l6, !tbaa !24
  %t301 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t297, i64 %t298)
  store i1 %t301, ptr %l154
  br label %bb84
bb84:
  %t302 = load i1, ptr %l154, !tbaa !21
  br i1 %t302, label %bb85, label %bb86
bb85:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 88
  store ptr %t305, ptr %l156, !tbaa !29
  %t306 = load i64, ptr %l6, !tbaa !24
  %t307 = load ptr, ptr %l3, !tbaa !29
  %t308 = load i64, ptr %l1, !tbaa !24
  %t309 = load i64, ptr %l2, !tbaa !24
  %t314 = call %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v1, ptr %v0, i64 %t306, ptr %t307, i64 %t308, i64 %t309)
  store %"compiler/check:roDeepArg" %t314, ptr %l161
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t315 = load ptr, ptr %l156, !tbaa !29
  %t316 = load %"compiler/check:roDeepArg", ptr %l161
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v0, ptr %t315, %"compiler/check:roDeepArg" %t316)
  br label %bb88
bb88:
  br label %bb89
bb89:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLend(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l15 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %t9, ptr %t10, %"compiler/source:Span" %a2)
  store %"compiler/source:Span" %t15, ptr %l11
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store i32 %t21, ptr %l15
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t22)
  store i32 %t25, ptr %l18
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i32, ptr %l15, !tbaa !23
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %s1, ptr %t26, i32 %t27, i32 %t28)
  store { i64, ptr } %t29, ptr %l19
  br label %bb7
bb7:
  %t30 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %s1, ptr %s1, { i64, ptr } %t36)
  store %"compiler/diagmsg:Msg" %t38, ptr %l21
  br label %bb8
bb8:
  %t39 = load ptr, ptr %l7, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l11
  %t41 = load %"compiler/diagmsg:Msg", ptr %l21
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t39, %"compiler/source:Span" %t40, %"compiler/diagmsg:Msg" %t41)
  store i64 %t42, ptr %l22
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqLongest(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l23 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l10
  br label %bb2
bb2:
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = load i64, ptr %l10, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t13, i64 %t14)
  store { i64, ptr } %t17, ptr %l15
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 0
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeOf(ptr %v0, ptr %v1, ptr %s2, ptr %a0, ptr %t24)
  store ptr %t27, ptr %l19
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l19, !tbaa !29
  store ptr %t28, ptr %l6, !tbaa !29
  %t29 = load ptr, ptr %l6, !tbaa !29
  %t31 = getelementptr %"compiler/check:elemsShape", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp sge i64 %t32, -1
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t38 = getelementptr %"compiler/check:elemsShape", ptr %t36, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = getelementptr %"compiler/check:elemsShape", ptr %t48, i32 0, i32 0
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l2, !tbaa !24
  br label %bb13
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l4, !tbaa !24
  br label %bb1
bb15:
  %t59 = load i64, ptr %l2, !tbaa !24
  store i64 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqSlice(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l15 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i64
  %l53 = alloca i1
  %l54 = alloca i32
  %l61 = alloca i32
  %l62 = alloca %"compiler/source:Span"
  %l68 = alloca i32
  %l73 = alloca %"compiler/typed:Slice"
  %rv = alloca ptr
  %t133 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/check:seqOf", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 36
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l15
  br label %bb3
bb2:
  br label %bb17
bb3:
  %t13 = load i64, ptr %l15, !tbaa !24
  store i64 %t13, ptr %l6, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 36
  %t17 = load ptr, ptr %l4, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t16, ptr %t17)
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 36
  %t23 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v4, ptr %t22, ptr %t23)
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l22, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t27, ptr %l23
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l24
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/check:seqOf", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l26, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v0, ptr %t33, %"compiler/source:Span" %t34, ptr %t35)
  store ptr %t39, ptr %l30
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l30, !tbaa !29
  store ptr %t40, ptr %l31, !tbaa !29
  %t41 = icmp sge i64 0, 0
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = icmp sle i64 0, 1152921504606846975
  br i1 %t43, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b8e2733ff2674fd_52419f97eade6699)
  unreachable
bb9:
  %t45 = mul i64 0, 8
  %t46 = insertvalue { i64, ptr } undef, i64 0, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t47, ptr %l34, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 36
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t50, i64 %t51)
  store { i64, ptr } %t54, ptr %l38
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_b8e2733ff2674fd_52419f97eade6699)
  unreachable
bb11:
  %t55 = icmp sge i64 0, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = icmp sle i64 0, 2305843009213693951
  br i1 %t57, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4fb1ec40319fc7d0_191a57ffdbf9a78c)
  unreachable
bb14:
  %t59 = mul i64 0, 4
  %t60 = insertvalue { i64, ptr } undef, i64 0, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t62 = load ptr, ptr %l22, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l23
  %t64 = load %"compiler/source:Span", ptr %l24
  %t65 = load i64, ptr %l26, !tbaa !24
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t67 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v5, ptr %v5, ptr %t62, %"compiler/source:Span" %t63, %"compiler/source:Span" %t64, i64 %t65, ptr %t66, { i64, ptr } %t67, { i64, ptr } %t68, { i64, ptr } %t61)
  store ptr %t70, ptr %l42
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4fb1ec40319fc7d0_191a57ffdbf9a78c)
  unreachable
bb16:
  %t71 = load ptr, ptr %l42, !tbaa !29
  store ptr %t71, ptr %rv
  br label %ret
bb17:
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t72)
  store i32 %t74, ptr %l44
  br label %bb18
bb18:
  %t75 = load i32, ptr %l44, !tbaa !23
  store i32 %t75, ptr %l7, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i1 %t80, ptr %l47
  br label %bb19
bb19:
  %t81 = load i1, ptr %l47, !tbaa !21
  br i1 %t81, label %bb20, label %bb21
bb20:
  %t82 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t82, ptr %l48, !tbaa !24
  br label %bb22
bb21:
  %t84 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t84, ptr %l48, !tbaa !24
  br label %bb22
bb22:
  %t86 = load i64, ptr %l48, !tbaa !24
  store i64 %t86, ptr %l8, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l7, !tbaa !23
  %t91 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t87, i32 %t88)
  store i1 %t91, ptr %l53
  br label %bb23
bb23:
  %t92 = load i1, ptr %l53, !tbaa !21
  br i1 %t92, label %bb24, label %bb25
bb24:
  %t93 = load i32, ptr %l7, !tbaa !23
  store i32 %t93, ptr %l54, !tbaa !23
  br label %bb27
bb25:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %l3, !tbaa !29
  %t103 = getelementptr %"compiler/check:seqOf", ptr %t101, i32 0, i32 0
  %t104 = load i32, ptr %t103, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t100, i32 %t104, i32 0)
  store i32 %t107, ptr %l61
  br label %bb26
bb26:
  %t108 = load i32, ptr %l61, !tbaa !23
  store i32 %t108, ptr %l54, !tbaa !23
  br label %bb27
bb27:
  %t109 = load i32, ptr %l54, !tbaa !23
  %t110 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t110, ptr %l62
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t118 = load i64, ptr %l8, !tbaa !24
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t116, i32 %t109, i64 %t118)
  store i32 %t122, ptr %l68
  br label %bb28
bb28:
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t124 = load ptr, ptr %l4, !tbaa !29
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t130 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %t123, ptr %t124, ptr %t125, i32 0)
  store %"compiler/typed:Slice" %t130, ptr %l73
  br label %bb29
bb29:
  %t131 = load %"compiler/typed:Slice", ptr %l73
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store %"compiler/typed:Slice" %t131, ptr %t132
  store { i64, [5 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 0
  store i64 10, ptr %t134
  %t135 = load %"compiler/source:Span", ptr %l62
  %t136 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t135, 0
  %t137 = load i32, ptr %l68, !tbaa !23
  %t138 = insertvalue { %"compiler/source:Span", i32, ptr } %t136, i32 %t137, 1
  %t140 = insertvalue { %"compiler/source:Span", i32, ptr } %t138, ptr %t132, 2
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t140, ptr %t141
  %t142 = load { i64, [5 x i64] }, ptr %t133
  %t144 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 48, i64 8)
  store { i64, [5 x i64] } %t142, ptr %t144
  store ptr %t144, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetOrder(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l15 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 147
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t3)
  br label %bb1
bb1:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i64, ptr %t23, i64 %t20
  %t25 = load i64, ptr %t24, !tbaa !34
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 147
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t29, i64 %t25)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l27 = alloca i1
  %l33 = alloca %"compiler/check:litv"
  %l35 = alloca i1
  %l39 = alloca %"compiler/check:litv"
  %l44 = alloca i1
  %l45 = alloca i1
  %l49 = alloca %"compiler/check:litv"
  %l51 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l63 = alloca %"compiler/check:litv"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load i1, ptr %l14, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 30}
  %t29 = icmp eq i64 %t27, 5
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 113}
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb41
bb12:
  %t49 = load i32, ptr %l3, !range !{i32 0, i32 113}
  %t51 = trunc i64 105 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb15
bb14:
  %t54 = load i32, ptr %l3, !range !{i32 0, i32 113}
  %t56 = trunc i64 106 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t65 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store %"compiler/check:litv" %t65, ptr %l33
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t66 = getelementptr %"compiler/check:litv", ptr %l33, i32 0, i32 0
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t74 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  store %"compiler/check:litv" %t74, ptr %l39
  br label %bb21
bb20:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb21:
  %t75 = getelementptr %"compiler/check:litv", ptr %l39, i32 0, i32 0
  %t76 = load i1, ptr %t75, !tbaa !21
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l35, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l4, !tbaa !29
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  store i1 %t85, ptr %l44
  br label %bb24
bb24:
  %t86 = load i1, ptr %l44, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t92 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  store %"compiler/check:litv" %t92, ptr %l49
  br label %bb27
bb26:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb27:
  %t93 = getelementptr %"compiler/check:litv", ptr %l49, i32 0, i32 0
  %t94 = load i1, ptr %t93, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb31
bb29:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i1 %t100, ptr %l54
  br label %bb30
bb30:
  %t101 = load i1, ptr %l54, !tbaa !21
  store i1 %t101, ptr %l51, !tbaa !21
  br label %bb31
bb31:
  %t102 = load i1, ptr %l51, !tbaa !21
  store i1 %t102, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t103 = load i1, ptr %l45, !tbaa !21
  br i1 %t103, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb40
bb34:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t108 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  store i1 %t108, ptr %l58
  br label %bb35
bb35:
  %t109 = load i1, ptr %l58, !tbaa !21
  br i1 %t109, label %bb36, label %bb37
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t115 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  store %"compiler/check:litv" %t115, ptr %l63
  br label %bb38
bb37:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb39
bb38:
  %t116 = getelementptr %"compiler/check:litv", ptr %l63, i32 0, i32 0
  %t117 = load i1, ptr %t116, !tbaa !21
  store i1 %t117, ptr %l59, !tbaa !21
  br label %bb39
bb39:
  %t119 = load i1, ptr %l59, !tbaa !21
  store i1 %t119, ptr %l55, !tbaa !21
  br label %bb40
bb40:
  %t120 = load i1, ptr %l55, !tbaa !21
  store i1 %t120, ptr %rv
  br label %ret
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i1 false, ptr %rv
  br label %ret
bb45:
  call void @__olang_check_failed(ptr @olang_loc_5ec272a16da13ce8_6a23c064ecfaca54)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca ptr
  %l22 = alloca i1
  %l28 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l9
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l12
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_7151da8c7014d0c8_6aa5246f01d956ac)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = icmp slt i32 %t36, 0
  br i1 %t38, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t40 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = trunc i64 %t44 to i32
  %t49 = icmp sgt i32 %t41, %t46
  store i1 %t49, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t52 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t55 = load i32, ptr %t54, !tbaa !23
  %t58 = icmp sgt i32 %t53, %t55
  store i1 %t58, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t60 = load i1, ptr %l28, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t62, ptr %l33, !tbaa !27
  %t63 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l35, !tbaa !24
  %t67 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t68 = load i32, ptr %t67, !tbaa !23
  %t70 = sext i32 %t68 to i64
  store i64 %t70, ptr %l37, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l38, !tbaa !24
  %t73 = load i64, ptr %l35, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load i64, ptr %l35, !tbaa !24
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_16d25af731eb828d_f9df92790de43871)
  unreachable
bb17:
  %t80 = load i64, ptr %l37, !tbaa !24
  %t81 = load i64, ptr %l38, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  br i1 %t82, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_16d25af731eb828d_f9df92790de43871)
  unreachable
bb19:
  %t84 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l35, !tbaa !24
  %t87 = load i64, ptr %l37, !tbaa !24
  %t88 = getelementptr i8, ptr %t85, i64 %t86
  %t89 = sub i64 %t87, %t86
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  store { i64, ptr } %t91, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_16d25af731eb828d_f9df92790de43871)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc2(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %rv = alloca { i64, ptr }
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l8
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = sext i32 %t17 to i64
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l13, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = icmp sge i64 %t26, 0
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t29 = load i64, ptr %l11, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
bb4:
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = load i64, ptr %l14, !tbaa !24
  %t35 = icmp sle i64 %t33, %t34
  br i1 %t35, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
bb6:
  %t37 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l11, !tbaa !24
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = getelementptr i8, ptr %t38, i64 %t39
  %t42 = sub i64 %t40, %t39
  %t43 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = extractvalue { i64, ptr } %t44, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_acadf2af31b93e38_18751a402ed16b84)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreOver(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i1
  %l35 = alloca ptr
  %l44 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca i64
  %l65 = alloca ptr
  %l70 = alloca i64
  %l71 = alloca i32
  %l72 = alloca ptr
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca ptr
  %l90 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l103 = alloca ptr
  %l107 = alloca ptr
  %s2 = alloca %olang.scope
  %t36 = alloca { i64, [3 x i64] }, align 8
  %t81 = alloca { i64, [3 x i64] }, align 8
  %t163 = alloca { i64, [4 x i64] }, align 8
  %t179 = alloca { i64, [3 x i64] }, align 8
  %t205 = alloca { i64, [4 x i64] }, align 8
  %t224 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load i32, ptr %l12, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l4, !tbaa !23
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l19
  br label %bb4
bb4:
  %t16 = load i1, ptr %l19, !tbaa !21
  store i1 %t16, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l16, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l25
  br label %bb8
bb8:
  %t28 = load i1, ptr %l25, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t35 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 0
  store i64 1, ptr %t37
  %t39 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t33, 0
  %t41 = insertvalue { %"compiler/source:Span", ptr, ptr } %t39, ptr %t34, 1
  %t43 = insertvalue { %"compiler/source:Span", ptr, ptr } %t41, ptr %t35, 2
  %t44 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t43, ptr %t44
  %t45 = load { i64, [3 x i64] }, ptr %t36
  %t47 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t45, ptr %t47
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t32, ptr %t47)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %ret
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estable(ptr %v0, ptr %v1, ptr %v1, ptr %t50, ptr %t51)
  store ptr %t54, ptr %l35
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l35, !tbaa !29
  store ptr %t55, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s2, ptr %t60, %"compiler/source:Span" %t61, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb18:
  %t64 = load ptr, ptr %l5, !tbaa !29
  store ptr %t64, ptr %l2, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  %t68 = load i32, ptr %l4, !tbaa !23
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t66, %"compiler/source:Span" %t67, i32 %t68)
  store i64 %t72, ptr %l44
  br label %bb19
bb19:
  %t73 = load i64, ptr %l44, !tbaa !24
  store i64 %t73, ptr %l6, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l1
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = trunc i64 %t76 to i32
  %t80 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [3 x i64] }, ptr %t81, i32 0, i32 0
  store i64 0, ptr %t82
  %t84 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t75, 0
  %t86 = insertvalue { %"compiler/source:Span", i32, ptr } %t84, i32 %t78, 1
  %t88 = insertvalue { %"compiler/source:Span", i32, ptr } %t86, ptr %t80, 2
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t81, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t88, ptr %t89
  %t90 = load { i64, [3 x i64] }, ptr %t81
  %t92 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t90, ptr %t92
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t74, ptr %t92)
  br label %bb20
bb20:
  store i64 -1, ptr %l7, !tbaa !24
  %t95 = load ptr, ptr %l2, !tbaa !29
  store ptr %t95, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t96 = load ptr, ptr %l53, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb21, label %bb22
bb21:
  %t99 = load ptr, ptr %l53, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 8}
  %t102 = icmp eq i64 %t100, 0
  store i1 %t102, ptr %l54, !tbaa !21
  br label %bb22
bb22:
  %t103 = load i1, ptr %l54, !tbaa !21
  br i1 %t103, label %bb23, label %bb24
bb23:
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t106, i32 0, i32 0
  %t108 = load %"compiler/source:Span", ptr %t107
  store %"compiler/source:Span" %t108, ptr %l8
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t112, i32 0, i32 1
  %t114 = load i32, ptr %t113
  store i32 %t114, ptr %l9, !tbaa !23
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t118, i32 0, i32 2
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l10, !tbaa !23
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t122)
  store ptr %t124, ptr %l65
  br label %bb25
bb24:
  br label %bb30
bb25:
  %t125 = load ptr, ptr %l65, !tbaa !29
  %t127 = getelementptr %"compiler/check:frame", ptr %t125, i32 0, i32 23
  %t128 = load i32, ptr %l10, !tbaa !23
  %t130 = sext i32 %t128 to i64
  %t133 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t127, i64 %t130)
  %t134 = extractvalue { i32, i64 } %t133, 1
  %t135 = extractvalue { i32, i64 } %t133, 0
  store i32 %t135, ptr %l71
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb27, label %ok.137, !prof !99
ok.137:
  store i64 %t134, ptr %l70
  br label %bb26
bb26:
  %t138 = load i64, ptr %l70, !tbaa !24
  store i64 %t138, ptr %l63, !tbaa !24
  br label %bb29
bb27:
  br label %bb28
bb28:
  store i64 -1, ptr %l63, !tbaa !24
  br label %bb29
bb29:
  %t139 = load i64, ptr %l63, !tbaa !24
  store i64 %t139, ptr %l7, !tbaa !24
  br label %bb30
bb30:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l72, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l1
  %t143 = load ptr, ptr %l2, !tbaa !29
  %t144 = load i64, ptr %l7, !tbaa !24
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v1, ptr %v0, ptr %t141, %"compiler/source:Span" %t142, ptr %t143, i64 %t144)
  store ptr %t149, ptr %l77
  br label %bb31
bb31:
  %t150 = load ptr, ptr %l72, !tbaa !29
  %t151 = load ptr, ptr %l77, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t150, ptr %t151)
  br label %bb32
bb32:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l78, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l79
  %t154 = load ptr, ptr %l2, !tbaa !29
  store ptr %t154, ptr %l80, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l1
  %t157 = load %"compiler/source:Span", ptr %l1
  %t158 = load i32, ptr %l4, !tbaa !23
  %t159 = load i64, ptr %l6, !tbaa !24
  %t161 = trunc i64 %t159 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t163, i32 0, i32 0
  store i64 0, ptr %t164
  %t166 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t157, 0
  %t168 = insertvalue { %"compiler/source:Span", i32, i32 } %t166, i32 %t158, 1
  %t170 = insertvalue { %"compiler/source:Span", i32, i32 } %t168, i32 %t161, 2
  %t171 = getelementptr { i64, [4 x i64] }, ptr %t163, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t170, ptr %t171
  %t172 = load { i64, [4 x i64] }, ptr %t163
  %t174 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t172, ptr %t174
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t155, %"compiler/source:Span" %t156, ptr %t174)
  store ptr %t178, ptr %l90
  br label %bb33
bb33:
  store { i64, [3 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 0
  store i64 1, ptr %t180
  %t181 = load %"compiler/source:Span", ptr %l79
  %t182 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t181, 0
  %t183 = load ptr, ptr %l80, !tbaa !29
  %t184 = insertvalue { %"compiler/source:Span", ptr, ptr } %t182, ptr %t183, 1
  %t185 = load ptr, ptr %l90, !tbaa !29
  %t186 = insertvalue { %"compiler/source:Span", ptr, ptr } %t184, ptr %t185, 2
  %t187 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t186, ptr %t187
  %t188 = load { i64, [3 x i64] }, ptr %t179
  %t190 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t188, ptr %t190
  %t191 = load ptr, ptr %l78, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t191, ptr %t190)
  br label %bb34
bb34:
  %t193 = load i64, ptr %l7, !tbaa !24
  %t195 = icmp sge i64 %t193, 0
  br i1 %t195, label %bb35, label %bb36
bb35:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l95, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t198, ptr %l96
  %t199 = load %"compiler/source:Span", ptr %l1
  %t200 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t201 = load i64, ptr %l7, !tbaa !24
  %t203 = trunc i64 %t201 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t205, i32 0, i32 0
  store i64 0, ptr %t206
  %t208 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t199, 0
  %t210 = insertvalue { %"compiler/source:Span", i32, i32 } %t208, i32 %t200, 1
  %t212 = insertvalue { %"compiler/source:Span", i32, i32 } %t210, i32 %t203, 2
  %t213 = getelementptr { i64, [4 x i64] }, ptr %t205, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t212, ptr %t213
  %t214 = load { i64, [4 x i64] }, ptr %t205
  %t216 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t214, ptr %t216
  store ptr %t216, ptr %l103, !tbaa !29
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l1
  %t219 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t223 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t217, %"compiler/source:Span" %t218, i32 %t219, i64 1)
  store ptr %t223, ptr %l107
  br label %bb37
bb36:
  br label %bb39
bb37:
  store { i64, [3 x i64] } zeroinitializer, ptr %t224
  %t225 = getelementptr { i64, [3 x i64] }, ptr %t224, i32 0, i32 0
  store i64 1, ptr %t225
  %t226 = load %"compiler/source:Span", ptr %l96
  %t227 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t226, 0
  %t228 = load ptr, ptr %l103, !tbaa !29
  %t229 = insertvalue { %"compiler/source:Span", ptr, ptr } %t227, ptr %t228, 1
  %t230 = load ptr, ptr %l107, !tbaa !29
  %t231 = insertvalue { %"compiler/source:Span", ptr, ptr } %t229, ptr %t230, 2
  %t232 = getelementptr { i64, [3 x i64] }, ptr %t224, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t231, ptr %t232
  %t233 = load { i64, [3 x i64] }, ptr %t224
  %t235 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t233, ptr %t235
  %t236 = load ptr, ptr %l95, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t236, ptr %t235)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l22 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %l28 = alloca i1
  %l37 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l49 = alloca { i64, ptr }
  %l51 = alloca %"compiler/check:fieldSet"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %wh2 = alloca ptr
  %wc2 = alloca ptr
  %ws2 = alloca i32
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l11, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i32, ptr %l16, !tbaa !23
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %v0, ptr %t14, i32 %t15)
  store ptr %t16, ptr %l17
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l17, !tbaa !29
  store ptr %t17, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %s2, ptr %t24)
  %t27 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t26, 0, 1
  %t28 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t26, 0, 0
  store ptr %t27, ptr %wh2
  store ptr %t28, ptr %wc2
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t26, ptr %l22
  br label %bb6
bb5:
  br label %bb21
bb6:
  %t29 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l22
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t29, ptr %l4
  br label %bb7
bb7:
  %t31 = call { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %s2, ptr %l4)
  %t32 = extractvalue { i32, ptr } %t31, 1
  %t33 = extractvalue { i32, ptr } %t31, 0
  store i32 %t33, ptr %l26
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb9, label %ok.35, !prof !99
ok.35:
  store ptr %t32, ptr %l25
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l25, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  br label %bb11
bb9:
  %t37 = load i32, ptr %l26, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  store i1 %t40, ptr %l28, !tbaa !21
  br label %bb10
bb10:
  br label %bb20
bb11:
  %t41 = load ptr, ptr %l23, !tbaa !29
  %t44 = getelementptr %"compiler/ast:VarDecl", ptr %t41, i32 0, i32 0
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t59 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t59, ptr %l37, !tbaa !27
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i32, ptr %t63, i64 %t60
  %t65 = load i32, ptr %t64, !tbaa !33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l2, i32 %t65)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l7, !tbaa !24
  br label %bb12
bb18:
  br label %bb19
bb19:
  br label %bb7
bb20:
  store i32 0, ptr %ws2
  br label %wend2
wend2.c0:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t75 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t75, ptr %l45
  br label %bb22
bb22:
  %t76 = load i32, ptr %l1, !tbaa !23
  store i32 %t76, ptr %l46, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l1, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t77, i32 %t78)
  store { i64, ptr } %t81, ptr %l49
  br label %bb23
bb23:
  %t82 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  %t84 = extractvalue { i64, ptr } %t82, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t89 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t90 = load i32, ptr %l46, !tbaa !23
  %t92 = call %"compiler/check:fieldSet" @compiler_2fcheck_3afieldSet_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t89, i32 %t90, { i64, ptr } %t88, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store %"compiler/check:fieldSet" %t92, ptr %l51
  br label %bb24
bb24:
  %t93 = load %"compiler/check:fieldSet", ptr %l51
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/check:fieldSet" %t93, ptr %t94
  call void @__olang_scope_close(ptr %s0)
  store ptr %t94, ptr %rv
  br label %ret
wend2:
  %t96 = load ptr, ptr %wh2
  %t97 = load ptr, ptr %wc2
  %t98 = call ptr @llvm.coro.promise(ptr %t96, i32 8, i1 false)
  %t99 = getelementptr { { i32, ptr }, i32 }, ptr %t98, i32 0, i32 1
  store i32 2, ptr %t99
  %t100 = call { i32, ptr } %t97(ptr %t96, ptr null)
  %t101 = load i32, ptr %ws2
  switch i32 %t101, label %wend2.c0 [ ]
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextBeside(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l5 = alloca i1
  %l7 = alloca i1
  %l12 = alloca i32
  %l16 = alloca i1
  %l19 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i32
  %l28 = alloca ptr
  %l33 = alloca i32
  %l36 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2fcheck_2eisData(ptr %v1, ptr %a2)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l12
  br label %bb4
bb4:
  %t17 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t19 = trunc i64 19 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  store i1 %t22, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t24 = load i1, ptr %l7, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  store ptr %t30, ptr %l19, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l22
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i32, ptr %l22, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t38, ptr %l23
  br label %bb9
bb9:
  %t39 = load i32, ptr %l23, !range !{i32 0, i32 33}
  %t41 = trunc i64 19 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  store i1 %t44, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l16, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l28, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l33
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  store ptr %t64, ptr %l36, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l39
  br label %bb15
bb15:
  %t70 = load ptr, ptr %l36, !tbaa !29
  %t71 = load i32, ptr %l39, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l40
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l28, !tbaa !29
  %t74 = load i32, ptr %l33, !tbaa !23
  %t75 = load i32, ptr %l40, !tbaa !23
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %t73, i32 %t74, i32 %t75)
  store i1 %t76, ptr %l41
  br label %bb17
bb17:
  %t77 = load i1, ptr %l41, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 51
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d28, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 51
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 51
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopAssert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i64
  %l28 = alloca i1
  %l32 = alloca i1
  %l36 = alloca ptr
  %l42 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca %"compiler/check:TopAssertAsk"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %t1, i64 %t2, ptr %t3, i32 %t4)
  store i64 %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  store i64 -1, ptr %l6, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load ptr, ptr %l4, !tbaa !29
  store ptr %t19, ptr %l17, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  store ptr %t25, ptr %l20, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t26)
  store i32 %t28, ptr %l22
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t29 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = load i32, ptr %l22, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t30, i32 %t31, i64 %t29)
  store i32 %t33, ptr %l24
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l15, !tbaa !29
  %t35 = load i64, ptr %l16, !tbaa !24
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load i32, ptr %l24, !tbaa !23
  %t38 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v2, ptr %t34, i64 %t35, ptr %t36, i32 %t37)
  store i64 %t38, ptr %l25
  br label %bb6
bb6:
  %t39 = load i64, ptr %l25, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb13
bb9:
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  store i1 %t52, ptr %l32, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l32, !tbaa !21
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 102
  store ptr %t58, ptr %l36, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 10
  %t68 = load i64, ptr %l1, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l42
  br label %bb17
bb17:
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l44, !tbaa !24
  store %"compiler/source:Span" %a2, ptr %l45
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t81 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %t77, ptr %t78)
  store %"compiler/source:Span" %t81, ptr %l48
  br label %bb18
bb18:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l44, !tbaa !24
  %t85 = load %"compiler/source:Span", ptr %l45
  %t86 = load %"compiler/source:Span", ptr %l48
  %t89 = call %"compiler/check:TopAssertAsk" @compiler_2fcheck_3aTopAssertAsk_2ector(ptr %s0, i64 %t84, %"compiler/source:Span" %t85, %"compiler/source:Span" %t86, i64 %t82, i64 %t83)
  store %"compiler/check:TopAssertAsk" %t89, ptr %l51
  br label %bb19
bb19:
  %t90 = load ptr, ptr %l36, !tbaa !29
  %t91 = load %"compiler/check:TopAssertAsk", ptr %l51
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eP_H67072fc16e996275e069a499f28fddf9(ptr %v0, ptr %t90, %"compiler/check:TopAssertAsk" %t91)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetDecls(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i1 %a3, i1 %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca { i64, [3 x i64] }
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l34 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca { i64, [3 x i64] }
  %l69 = alloca %"compiler/diagmsg:Msg"
  %l70 = alloca i64
  %l72 = alloca i32
  %l75 = alloca ptr
  %l80 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l91 = alloca { i64, [3 x i64] }
  %l95 = alloca { i64, ptr }
  %l97 = alloca %"compiler/diagmsg:Msg"
  %l98 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i64
  %l127 = alloca { i64, ptr }
  %l137 = alloca i1
  %l139 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l150 = alloca { i64, [3 x i64] }
  %l154 = alloca { i64, ptr }
  %l156 = alloca %"compiler/diagmsg:Msg"
  %l157 = alloca i64
  %l163 = alloca ptr
  %l169 = alloca { i64, [3 x i64] }
  %l172 = alloca { i64, ptr }
  %l173 = alloca %"compiler/diagmsg:Msg"
  %l174 = alloca i64
  %l178 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca { i64, [3 x i64] }
  %l183 = alloca { i64, ptr }
  %l184 = alloca %"compiler/diagmsg:Msg"
  %l185 = alloca i64
  %l188 = alloca ptr
  %l189 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i64
  %l196 = alloca ptr
  %l197 = alloca ptr
  %l198 = alloca i1
  %l199 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i64
  %l209 = alloca %"compiler/source:Span"
  %l211 = alloca i64
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t88 = alloca { i64, [3 x i64] }, align 8
  %t148 = alloca { i64, [3 x i64] }, align 8
  %t284 = alloca { i64, [3 x i64] }, align 8
  %t335 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i1 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 10
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l34
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l34, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 4
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l6, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/load:Loader", ptr %t31, i32 0, i32 4
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l7, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  %t42 = load i64, ptr %l9, !tbaa !24
  %t43 = load i64, ptr %l10, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb6, label %bb7
bb6:
  br label %bb91
bb7:
  br label %bb8
bb8:
  %t50 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t50, ptr %l48, !tbaa !27
  %t51 = load i64, ptr %l9, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  store ptr %t56, ptr %l11, !tbaa !29
  %t58 = load ptr, ptr %l11, !tbaa !29
  store ptr %t58, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t59 = load ptr, ptr %l51, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb9, label %bb10
bb9:
  %t62 = load ptr, ptr %l51, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 11}
  %t65 = icmp eq i64 %t63, 8
  store i1 %t65, ptr %l52, !tbaa !21
  br label %bb10
bb10:
  %t66 = load i1, ptr %l52, !tbaa !21
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t67 = load ptr, ptr %l11, !tbaa !29
  %t69 = getelementptr { i64, [8 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t69, i32 0, i32 0
  %t71 = load %"compiler/source:Span", ptr %t70
  store %"compiler/source:Span" %t71, ptr %l12
  %t73 = load ptr, ptr %l11, !tbaa !29
  %t75 = getelementptr { i64, [8 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l13, !tbaa !29
  br label %bb13
bb12:
  br label %bb72
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = sext i32 %t81 to i64
  %t84 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 1
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = sext i32 %t85 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 0
  store i64 3, ptr %t89
  %t91 = insertvalue { i64, i64, i64 } undef, i64 %t79, 0
  %t93 = insertvalue { i64, i64, i64 } %t91, i64 %t83, 1
  %t95 = insertvalue { i64, i64, i64 } %t93, i64 %t87, 2
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 1
  store { i64, i64, i64 } %t95, ptr %t96
  %t97 = load { i64, [3 x i64] }, ptr %t88
  store { i64, [3 x i64] } %t97, ptr %l14
  %t99 = load i1, ptr %l3, !tbaa !21
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t103 = load ptr, ptr %l7, !tbaa !29
  store ptr %t103, ptr %l67, !tbaa !29
  %t104 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t104, ptr %l68
  %t105 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetPlace(ptr %s5)
  store %"compiler/diagmsg:Msg" %t105, ptr %l69
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t106 = load ptr, ptr %l67, !tbaa !29
  %t107 = load { i64, [3 x i64] }, ptr %l68
  %t108 = load %"compiler/diagmsg:Msg", ptr %l69
  %t109 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t106, { i64, [3 x i64] } %t107, %"compiler/diagmsg:Msg" %t108)
  store i64 %t109, ptr %l70
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb18:
  %t110 = load ptr, ptr %l13, !tbaa !29
  %t112 = call i32 @compiler_2fcheck_2esetName(ptr %v1, ptr %t110)
  store i32 %t112, ptr %l72
  br label %bb19
bb19:
  %t113 = load i32, ptr %l72, !tbaa !23
  store i32 %t113, ptr %l15, !tbaa !23
  %t114 = load i32, ptr %l15, !tbaa !23
  %t116 = icmp ne i32 %t114, 0
  br i1 %t116, label %bb20, label %bb21
bb20:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load i64, ptr %l1, !tbaa !24
  %t123 = load i32, ptr %l15, !tbaa !23
  %t127 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %s4, ptr %t121, i64 %t122, i32 %t123)
  store ptr %t127, ptr %l80
  br label %bb22
bb21:
  store ptr null, ptr %l75, !tbaa !29
  br label %bb23
bb22:
  %t128 = load ptr, ptr %l80, !tbaa !29
  store ptr %t128, ptr %l75, !tbaa !29
  br label %bb23
bb23:
  %t129 = load ptr, ptr %l75, !tbaa !29
  store ptr %t129, ptr %l16, !tbaa !29
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t132 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t130)
  store %"compiler/source:Span" %t132, ptr %l82
  br label %bb24
bb24:
  %t133 = load %"compiler/source:Span", ptr %l82
  store %"compiler/source:Span" %t133, ptr %l17
  %t134 = load ptr, ptr %l16, !tbaa !29
  %t136 = icmp eq ptr %t134, null
  br i1 %t136, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t138 = load ptr, ptr %l7, !tbaa !29
  store ptr %t138, ptr %l85, !tbaa !29
  %t139 = load i64, ptr %l6, !tbaa !24
  %t140 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  %t144 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 1
  %t145 = load i32, ptr %t144, !tbaa !23
  %t147 = sext i32 %t145 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t148
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t148, i32 0, i32 0
  store i64 3, ptr %t149
  %t151 = insertvalue { i64, i64, i64 } undef, i64 %t139, 0
  %t153 = insertvalue { i64, i64, i64 } %t151, i64 %t143, 1
  %t155 = insertvalue { i64, i64, i64 } %t153, i64 %t147, 2
  %t156 = getelementptr { i64, [3 x i64] }, ptr %t148, i32 0, i32 1
  store { i64, i64, i64 } %t155, ptr %t156
  %t157 = load { i64, [3 x i64] }, ptr %t148
  store { i64, [3 x i64] } %t157, ptr %l91
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l6, !tbaa !24
  %t160 = load %"compiler/source:Span", ptr %l17
  %t164 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc2(ptr %v0, ptr %s6, ptr %t158, i64 %t159, %"compiler/source:Span" %t160)
  store { i64, ptr } %t164, ptr %l95
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t165 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 0
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = mul i64 %t166, 1
  %t169 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t168)
  call void @llvm.memcpy.p0.p0.i64(ptr %t169, ptr %t167, i64 %t168, i1 false)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  %t173 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetTarget(ptr %s6, ptr %s6, { i64, ptr } %t171)
  store %"compiler/diagmsg:Msg" %t173, ptr %l97
  br label %bb28
bb28:
  %t174 = load ptr, ptr %l85, !tbaa !29
  %t175 = load { i64, [3 x i64] }, ptr %l91
  %t176 = load %"compiler/diagmsg:Msg", ptr %l97
  %t177 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s6, ptr %t174, { i64, [3 x i64] } %t175, %"compiler/diagmsg:Msg" %t176)
  store i64 %t177, ptr %l98
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb30:
  store i64 -1, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t178 = load ptr, ptr %l16, !tbaa !29
  %t180 = getelementptr %"compiler/ast:VarDecl", ptr %t178, i32 0, i32 0
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  store i64 %t183, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t185 = load i64, ptr %l20, !tbaa !24
  %t186 = load i64, ptr %l19, !tbaa !24
  %t189 = icmp sgt i64 %t185, %t186
  br i1 %t189, label %bb31, label %bb32
bb31:
  %t191 = load i64, ptr %l21, !tbaa !24
  %t193 = icmp sgt i64 %t191, 0
  br i1 %t193, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb36
bb33:
  %t195 = load i64, ptr %l20, !tbaa !24
  %t196 = load i64, ptr %l19, !tbaa !24
  %t199 = sub i64 %t195, %t196
  %t200 = load i64, ptr %l21, !tbaa !24
  %t203 = add i64 %t199, %t200
  %t205 = sub i64 %t203, 1
  %t206 = load i64, ptr %l21, !tbaa !24
  %t209 = sdiv i64 %t205, %t206
  store i64 %t209, ptr %l108, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb35
bb35:
  %t211 = load i64, ptr %l108, !tbaa !24
  store i64 %t211, ptr %l105, !tbaa !24
  br label %bb36
bb36:
  %t212 = load i64, ptr %l105, !tbaa !24
  store i64 %t212, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb37
bb37:
  %t213 = load i64, ptr %l23, !tbaa !24
  %t214 = load i64, ptr %l22, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb38, label %bb39
bb38:
  br label %bb45
bb39:
  br label %bb40
bb40:
  %t221 = load i64, ptr %l19, !tbaa !24
  %t222 = load i64, ptr %l23, !tbaa !24
  %t223 = load i64, ptr %l21, !tbaa !24
  %t226 = mul i64 %t222, %t223
  %t229 = add i64 %t221, %t226
  store i64 %t229, ptr %l24, !tbaa !24
  %t231 = load ptr, ptr %l16, !tbaa !29
  %t233 = getelementptr %"compiler/ast:VarDecl", ptr %t231, i32 0, i32 0
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  store { i64, ptr } %t234, ptr %l127, !tbaa !27
  %t235 = load i64, ptr %l24, !tbaa !24
  %t237 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr i32, ptr %t238, i64 %t235
  %t240 = load i32, ptr %t239, !tbaa !33
  %t241 = load i32, ptr %l15, !tbaa !23
  %t244 = icmp eq i32 %t240, %t241
  br i1 %t244, label %bb41, label %bb42
bb41:
  %t246 = load i64, ptr %l24, !tbaa !24
  store i64 %t246, ptr %l18, !tbaa !24
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t248 = load i64, ptr %l23, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l23, !tbaa !24
  br label %bb37
bb45:
  %t252 = load i64, ptr %l18, !tbaa !24
  %t254 = icmp slt i64 %t252, 0
  br i1 %t254, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb48
bb47:
  %t256 = load ptr, ptr %l16, !tbaa !29
  %t258 = getelementptr %"compiler/ast:VarDecl", ptr %t256, i32 0, i32 1
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  store { i64, ptr } %t259, ptr %l139, !tbaa !27
  %t260 = load i64, ptr %l18, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr %"compiler/source:Span", ptr %t263, i64 %t260
  %t265 = getelementptr %"compiler/source:Span", ptr %t264, i32 0, i32 0
  %t266 = load i32, ptr %t265, !tbaa !23
  %t267 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 0
  %t268 = load i32, ptr %t267, !tbaa !23
  %t271 = icmp sgt i32 %t266, %t268
  store i1 %t271, ptr %l137, !tbaa !21
  br label %bb48
bb48:
  %t273 = load i1, ptr %l137, !tbaa !21
  br i1 %t273, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t274 = load ptr, ptr %l7, !tbaa !29
  store ptr %t274, ptr %l144, !tbaa !29
  %t275 = load i64, ptr %l6, !tbaa !24
  %t276 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t277 = load i32, ptr %t276, !tbaa !23
  %t279 = sext i32 %t277 to i64
  %t280 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 1
  %t281 = load i32, ptr %t280, !tbaa !23
  %t283 = sext i32 %t281 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t284
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t284, i32 0, i32 0
  store i64 3, ptr %t285
  %t287 = insertvalue { i64, i64, i64 } undef, i64 %t275, 0
  %t289 = insertvalue { i64, i64, i64 } %t287, i64 %t279, 1
  %t291 = insertvalue { i64, i64, i64 } %t289, i64 %t283, 2
  %t292 = getelementptr { i64, [3 x i64] }, ptr %t284, i32 0, i32 1
  store { i64, i64, i64 } %t291, ptr %t292
  %t293 = load { i64, [3 x i64] }, ptr %t284
  store { i64, [3 x i64] } %t293, ptr %l150
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i64, ptr %l6, !tbaa !24
  %t296 = load %"compiler/source:Span", ptr %l17
  %t300 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc2(ptr %v0, ptr %s11, ptr %t294, i64 %t295, %"compiler/source:Span" %t296)
  store { i64, ptr } %t300, ptr %l154
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t301 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t301, 0
  %t303 = extractvalue { i64, ptr } %t301, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  %t309 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetTarget(ptr %s11, ptr %s11, { i64, ptr } %t307)
  store %"compiler/diagmsg:Msg" %t309, ptr %l156
  br label %bb52
bb52:
  %t310 = load ptr, ptr %l144, !tbaa !29
  %t311 = load { i64, [3 x i64] }, ptr %l150
  %t312 = load %"compiler/diagmsg:Msg", ptr %l156
  %t313 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s11, ptr %t310, { i64, [3 x i64] } %t311, %"compiler/diagmsg:Msg" %t312)
  store i64 %t313, ptr %l157
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb54:
  %t314 = load i64, ptr %l18, !tbaa !24
  %t315 = load ptr, ptr %l16, !tbaa !29
  %t317 = getelementptr %"compiler/ast:VarDecl", ptr %t315, i32 0, i32 3
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t323 = icmp slt i64 %t314, %t320
  br i1 %t323, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s12
  %t325 = load ptr, ptr %l7, !tbaa !29
  store ptr %t325, ptr %l163, !tbaa !29
  %t326 = load i64, ptr %l6, !tbaa !24
  %t327 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 0
  %t328 = load i32, ptr %t327, !tbaa !23
  %t330 = sext i32 %t328 to i64
  %t331 = getelementptr %"compiler/source:Span", ptr %l17, i32 0, i32 1
  %t332 = load i32, ptr %t331, !tbaa !23
  %t334 = sext i32 %t332 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t335
  %t336 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 0
  store i64 3, ptr %t336
  %t338 = insertvalue { i64, i64, i64 } undef, i64 %t326, 0
  %t340 = insertvalue { i64, i64, i64 } %t338, i64 %t330, 1
  %t342 = insertvalue { i64, i64, i64 } %t340, i64 %t334, 2
  %t343 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  store { i64, i64, i64 } %t342, ptr %t343
  %t344 = load { i64, [3 x i64] }, ptr %t335
  store { i64, [3 x i64] } %t344, ptr %l169
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i32, ptr %l15, !tbaa !23
  %t349 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t345, i32 %t346)
  store { i64, ptr } %t349, ptr %l172
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t350 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t351 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetHasValue(ptr %v0, ptr %s12, { i64, ptr } %t350)
  store %"compiler/diagmsg:Msg" %t351, ptr %l173
  br label %bb58
bb58:
  %t352 = load ptr, ptr %l163, !tbaa !29
  %t353 = load { i64, [3 x i64] }, ptr %l169
  %t354 = load %"compiler/diagmsg:Msg", ptr %l173
  %t355 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s12, ptr %t352, { i64, [3 x i64] } %t353, %"compiler/diagmsg:Msg" %t354)
  store i64 %t355, ptr %l174
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s4)
  br label %bb90
bb60:
  %t356 = load i1, ptr %l4, !tbaa !21
  br i1 %t356, label %bb61, label %bb62
bb61:
  %t358 = load ptr, ptr %l5, !tbaa !29
  %t359 = load i32, ptr %l15, !tbaa !23
  %t362 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v2, ptr %t358, i32 %t359)
  store i1 %t362, ptr %l178
  br label %bb63
bb62:
  br label %bb71
bb63:
  %t363 = load i1, ptr %l178, !tbaa !21
  br i1 %t363, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s14
  %t364 = load ptr, ptr %l7, !tbaa !29
  store ptr %t364, ptr %l179, !tbaa !29
  %t365 = load { i64, [3 x i64] }, ptr %l14
  store { i64, [3 x i64] } %t365, ptr %l180
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load i32, ptr %l15, !tbaa !23
  %t370 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t366, i32 %t367)
  store { i64, ptr } %t370, ptr %l183
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t371 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t372 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetTwice(ptr %v0, ptr %s14, { i64, ptr } %t371)
  store %"compiler/diagmsg:Msg" %t372, ptr %l184
  br label %bb67
bb67:
  %t373 = load ptr, ptr %l179, !tbaa !29
  %t374 = load { i64, [3 x i64] }, ptr %l180
  %t375 = load %"compiler/diagmsg:Msg", ptr %l184
  %t376 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s14, ptr %t373, { i64, [3 x i64] } %t374, %"compiler/diagmsg:Msg" %t375)
  store i64 %t376, ptr %l185
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s14)
  br label %bb69
bb69:
  %t377 = load ptr, ptr %l5, !tbaa !29
  %t378 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v2, ptr %t377, i32 %t378, i1 true)
  br label %bb70
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s4)
  br label %bb89
bb72:
  %t381 = load ptr, ptr %l11, !tbaa !29
  store ptr %t381, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t382 = load ptr, ptr %l188, !tbaa !29
  %t383 = icmp ne ptr %t382, null
  br i1 %t383, label %bb73, label %bb74
bb73:
  %t385 = load ptr, ptr %l188, !tbaa !29
  %t386 = load i64, ptr %t385, !range !{i64 0, i64 11}
  %t388 = icmp eq i64 %t386, 7
  store i1 %t388, ptr %l189, !tbaa !21
  br label %bb74
bb74:
  %t389 = load i1, ptr %l189, !tbaa !21
  br i1 %t389, label %bb75, label %bb76
bb75:
  %t390 = load ptr, ptr %l11, !tbaa !29
  %t392 = getelementptr { i64, [8 x i64] }, ptr %t390, i32 0, i32 1
  %t393 = getelementptr { %"compiler/source:Span", ptr }, ptr %t392, i32 0, i32 1
  %t394 = load ptr, ptr %t393
  store ptr %t394, ptr %l25, !tbaa !29
  br label %bb77
bb76:
  br label %bb84
bb77:
  %t396 = load ptr, ptr %l0, !tbaa !29
  store ptr %t396, ptr %l194, !tbaa !29
  %t397 = load i64, ptr %l1, !tbaa !24
  store i64 %t397, ptr %l195, !tbaa !24
  %t398 = load ptr, ptr %l25, !tbaa !29
  store ptr %t398, ptr %l196, !tbaa !29
  %t399 = load ptr, ptr %l25, !tbaa !29
  store ptr %t399, ptr %l197, !tbaa !29
  %t400 = load i1, ptr %l3, !tbaa !21
  store i1 %t400, ptr %l198, !tbaa !21
  %t401 = load i1, ptr %l4, !tbaa !21
  store i1 %t401, ptr %l199, !tbaa !21
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/check:Checker", ptr %t402, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !29
  %t407 = getelementptr %"compiler/generic:Program", ptr %t405, i32 0, i32 0
  %t408 = load ptr, ptr %t407, !tbaa !29
  store ptr %t408, ptr %l202, !tbaa !29
  %t409 = load i64, ptr %l1, !tbaa !24
  store i64 %t409, ptr %l203, !tbaa !24
  %t410 = load ptr, ptr %l25, !tbaa !29
  %t412 = getelementptr %"compiler/ast:TopIf", ptr %t410, i32 0, i32 0
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  br i1 %t415, label %bb78, label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_c6f64016a09fc530_b8b2abed7e41fd2c)
  unreachable
bb79:
  br label %bb80
bb80:
  %t417 = load ptr, ptr %l25, !tbaa !29
  %t419 = getelementptr %"compiler/ast:TopIf", ptr %t417, i32 0, i32 0
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t422 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t420)
  store %"compiler/source:Span" %t422, ptr %l209
  br label %bb81
bb81:
  %t423 = getelementptr %"compiler/source:Span", ptr %l209, i32 0, i32 0
  %t424 = load i32, ptr %t423, !tbaa !23
  %t425 = load ptr, ptr %l202, !tbaa !29
  %t426 = load i64, ptr %l203, !tbaa !24
  %t428 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t425, i64 %t426, i32 %t424)
  store i64 %t428, ptr %l211
  br label %bb82
bb82:
  %t429 = load ptr, ptr %l5, !tbaa !29
  %t430 = load ptr, ptr %l194, !tbaa !29
  %t431 = load i64, ptr %l195, !tbaa !24
  %t432 = load ptr, ptr %l196, !tbaa !29
  %t433 = load ptr, ptr %l197, !tbaa !29
  %t434 = load i1, ptr %l198, !tbaa !21
  %t435 = load i1, ptr %l199, !tbaa !21
  %t436 = load i64, ptr %l211, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIf(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t430, i64 %t431, ptr %t432, ptr %t433, i1 %t434, i1 %t435, i64 %t436, i64 0, ptr %t429)
  br label %bb83
bb83:
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_37fb0db160a44e56_e10956c528b68142)
  unreachable
bb89:
  br label %bb90
bb90:
  %t438 = load i64, ptr %l9, !tbaa !24
  %t440 = add i64 %t438, 1
  store i64 %t440, ptr %l9, !tbaa !24
  br label %bb5
bb91:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l11 = alloca ptr
  %l16 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/load:Loader", ptr %t9, i32 0, i32 10
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t11, i64 %t12)
  store ptr %t15, ptr %l11
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t18 = getelementptr %"compiler/load:Module", ptr %t16, i32 0, i32 8
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t23 = load i64, ptr %l5, !tbaa !24
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIn(ptr %v0, ptr %v0, ptr %v1, ptr %t22, i64 %t23, { i64, ptr } %t19, i32 %a2, %"compiler/source:Span" %a3, i1 false)
  store ptr %t27, ptr %l16
  br label %bb2
bb2:
  %t28 = load ptr, ptr %l16, !tbaa !29
  store ptr %t28, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l22 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i32
  %l44 = alloca i32
  %l52 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l6, !tbaa !23
  store i32 %a2, ptr %l7, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l6, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l12
  br label %bb1
bb1:
  %t10 = load i1, ptr %l12, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l7, !tbaa !23
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l16
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i1, ptr %l16, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l13, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l6, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t30 = load i32, ptr %l22, !tbaa !23
  store i32 %t30, ptr %l6, !tbaa !23
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l7, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l25
  br label %bb10
bb10:
  %t36 = load i1, ptr %l25, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l29
  br label %bb13
bb12:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  %t42 = load i1, ptr %l29, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l6, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l36
  br label %bb17
bb16:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb18
bb17:
  %t56 = load i32, ptr %l36, !range !{i32 0, i32 33}
  %t58 = trunc i64 25 to i32
  %t59 = icmp eq i32 %t56, %t58
  %t61 = xor i1 %t59, true
  store i1 %t61, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l31, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l7, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l44
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t74 = load i32, ptr %l44, !tbaa !23
  store i32 %t74, ptr %l7, !tbaa !23
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l6, !tbaa !23
  %t80 = load i32, ptr %l7, !tbaa !23
  %t90 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %t78, i32 %t79, i32 %t80, ptr %a3, i1 %a4, i1 %a5)
  store i32 %t90, ptr %l52
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb24, label %ok.92, !prof !99
ok.92:
  br label %bb23
bb23:
  br label %bb26
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueArg(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i1
  %l39 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t10, i64 %a1)
  store i32 %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t15, i32 %t16)
  store { i64, ptr } %t17, ptr %l14
  br label %bb2
bb2:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb4, label %bb5
bb4:
  br label %bb19
bb5:
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t31, ptr %l21, !tbaa !27
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i32, ptr %t35, i64 %t32
  %t37 = load i32, ptr %t36, !tbaa !33
  store i32 %t37, ptr %l6, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l24, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  store i32 %t40, ptr %l25, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l6, !tbaa !23
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l28
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = load i32, ptr %l25, !tbaa !23
  %t48 = load i32, ptr %l28, !tbaa !23
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementions(ptr %v0, ptr %t46, i32 %t47, i32 %t48, i64 0)
  store i1 %t49, ptr %l29
  br label %bb8
bb8:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  store ptr %t54, ptr %l32, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l6, !tbaa !23
  %t59 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb11
bb10:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb13
bb11:
  %t60 = load ptr, ptr %l32, !tbaa !29
  %t61 = load i32, ptr %l35, !tbaa !23
  %t62 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t62, ptr %l36
  br label %bb12
bb12:
  %t63 = load i1, ptr %l36, !tbaa !21
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb13
bb13:
  %t64 = load i1, ptr %l30, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l6, !tbaa !23
  %t69 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l39
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t70 = load i32, ptr %l39, !tbaa !23
  store i32 %t70, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb3
bb19:
  %t75 = load i32, ptr %l2, !tbaa !23
  store i32 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l10 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i32, ptr %l5, !tbaa !23
  store i32 %t5, ptr %l2, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load i1, ptr %l8, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i32, ptr %l2, !tbaa !23
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t18 = icmp ne i32 %t14, %t15
  store i1 %t18, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l10, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l18
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t29 = load i1, ptr %l18, !tbaa !21
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v1, ptr %t31)
  store i1 %t33, ptr %l21
  br label %bb12
bb11:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb13
bb12:
  %t34 = load i1, ptr %l21, !tbaa !21
  store i1 %t34, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t35 = load i1, ptr %l19, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l50 = alloca i32
  %l52 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueExisting(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t14 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t11)
  store i32 %t14, ptr %l14
  br label %bb5
bb5:
  %t15 = load i32, ptr %l14, !tbaa !23
  store i32 %t15, ptr %l4, !tbaa !23
  br i1 %a3, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l4, !tbaa !23
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundMention(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l19
  br label %bb8
bb7:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t23 = load i64, ptr %l19, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l2
  %t29 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueErr(ptr %v0, ptr %s2, ptr %t27, %"compiler/source:Span" %t28, i32 %t29, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t33 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  store ptr %t33, ptr %rv
  br label %ret
bb13:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t35)
  store ptr %t37, ptr %l26
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l26, !tbaa !29
  store ptr %t38, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l5, !tbaa !29
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l33
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t50 = load i1, ptr %l33, !tbaa !21
  store i1 %t50, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load i32, ptr %l4, !tbaa !23
  %t59 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l38
  br label %bb21
bb20:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb22
bb21:
  %t60 = load i1, ptr %l38, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l34, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t64 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t64, ptr %l40, !tbaa !24
  br label %bb25
bb24:
  %t66 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  store i64 %t66, ptr %l40, !tbaa !24
  br label %bb25
bb25:
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l43, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l44, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l4, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t76, i32 %t77, i64 %t68)
  store i32 %t82, ptr %l50
  br label %bb26
bb26:
  %t83 = load %"compiler/source:Span", ptr %l2
  %t84 = load ptr, ptr %l43, !tbaa !29
  %t85 = load ptr, ptr %l44, !tbaa !29
  %t86 = load i32, ptr %l50, !tbaa !23
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %t84, ptr %t85, i32 %t86, %"compiler/source:Span" %t83)
  store ptr %t88, ptr %l52
  br label %bb27
bb27:
  %t89 = load ptr, ptr %l52, !tbaa !29
  store ptr %t89, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"compiler/diagmsg:Msg"
  %l43 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  store ptr %t2, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l4, !tbaa !23
  %t8 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l15
  br label %bb4
bb3:
  %t15 = load i32, ptr %l4, !tbaa !23
  store i32 %t15, ptr %l12, !tbaa !23
  br label %bb5
bb4:
  %t17 = load i32, ptr %l15, !tbaa !23
  store i32 %t17, ptr %l12, !tbaa !23
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load ptr, ptr %l8, !tbaa !29
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v3, ptr %t18, ptr %t19, i32 %t20)
  store ptr %t21, ptr %l17
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l17, !tbaa !29
  store ptr %t22, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l21
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t33 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t30)
  store i32 %t33, ptr %l25
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i32, ptr %l25, !tbaa !23
  %t36 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l26
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l21, !tbaa !23
  %t39 = load i32, ptr %l26, !tbaa !23
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %t37, i32 %t38, i32 %t39)
  store i1 %t40, ptr %l27
  br label %bb10
bb10:
  %t41 = load i1, ptr %l27, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l29, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l31
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l32, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l4, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l35
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = load i32, ptr %l35, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l36
  br label %bb15
bb15:
  %t57 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t59 = extractvalue { i64, ptr } %t57, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l37, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v3, ptr %s1, ptr %t64, ptr %t65)
  store { i64, ptr } %t68, ptr %l40
  br label %bb16
bb16:
  %t69 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t78 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t76, { i64, ptr } %t75)
  store %"compiler/diagmsg:Msg" %t78, ptr %l42
  br label %bb17
bb17:
  %t79 = load ptr, ptr %l29, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l31
  %t81 = load %"compiler/diagmsg:Msg", ptr %l42
  %t82 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t79, %"compiler/source:Span" %t80, %"compiler/diagmsg:Msg" %t81)
  store i64 %t82, ptr %l43
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l1
  %t85 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t83, %"compiler/source:Span" %t84, i32 %t85, i64 0)
  store ptr %t89, ptr %l47
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t90 = load ptr, ptr %l47, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t92, ptr %l49
  %t93 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t93, ptr %l50
  store i32 93, ptr %l51
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l52, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v1, ptr %t95, %"compiler/source:Span" %t96, ptr %a2)
  store ptr %t101, ptr %l56
  br label %bb21
bb21:
  %t102 = load %"compiler/source:Span", ptr %l1
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = load ptr, ptr %l56, !tbaa !29
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v1, ptr %t103, ptr %t104, %"compiler/source:Span" %t102)
  store ptr %t106, ptr %l58
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l5, !tbaa !29
  store ptr %t107, ptr %l59, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t108, ptr %l60
  %t109 = load ptr, ptr %l3, !tbaa !29
  %t111 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t109)
  store %"compiler/source:Span" %t111, ptr %l62
  br label %bb23
bb23:
  %t112 = load ptr, ptr %l48, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l49
  %t114 = load %"compiler/source:Span", ptr %l50
  %t115 = load i32, ptr %l51, !range !{i32 0, i32 113}
  %t116 = load ptr, ptr %l58, !tbaa !29
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l60
  %t119 = load %"compiler/source:Span", ptr %l62
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v3, ptr %v3, ptr %t112, %"compiler/source:Span" %t113, %"compiler/source:Span" %t114, i32 %t115, ptr %t116, ptr %t117, %"compiler/source:Span" %t118, %"compiler/source:Span" %t119)
  store ptr %t120, ptr %l63
  br label %bb24
bb24:
  %t121 = load ptr, ptr %l63, !tbaa !29
  store ptr %t121, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evariadicArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %lp4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l27 = alloca i1
  %l32 = alloca i1
  %l37 = alloca ptr
  %l39 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l71 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca ptr
  %l90 = alloca ptr
  %l96 = alloca i32
  %l100 = alloca i1
  %l103 = alloca i1
  %l105 = alloca i1
  %l110 = alloca i32
  %l112 = alloca i32
  %l118 = alloca i32
  %l124 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca %"compiler/source:Span"
  %l131 = alloca { i64, ptr }
  %l135 = alloca ptr
  %l137 = alloca i32
  %l139 = alloca ptr
  %l142 = alloca i64
  %l148 = alloca i64
  %l151 = alloca i64
  %l173 = alloca ptr
  %l174 = alloca ptr
  %l179 = alloca ptr
  %l180 = alloca i32
  %l181 = alloca { i64, ptr }
  %l184 = alloca %"compiler/source:Span"
  %l185 = alloca ptr
  %l187 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l194 = alloca i1
  %l196 = alloca ptr
  %l198 = alloca ptr
  %l199 = alloca { i64, ptr }
  %l202 = alloca %"compiler/source:Span"
  %l204 = alloca i1
  %l212 = alloca ptr
  %l213 = alloca i32
  %l216 = alloca ptr
  %l218 = alloca i32
  %l221 = alloca i32
  %l222 = alloca i32
  %l223 = alloca %"compiler/source:Span"
  %l224 = alloca i32
  %l225 = alloca i32
  %l229 = alloca { i64, ptr }
  %l233 = alloca i32
  %l235 = alloca %"compiler/typed:Make"
  %rv = alloca ptr
  %t447 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l3, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp ne i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l32
  br label %bb3
bb2:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb4
bb3:
  %t17 = load i1, ptr %l32, !tbaa !21
  store i1 %t17, ptr %l27, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l27, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  %t21 = load i32, ptr %l3, !tbaa !23
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayLit(ptr %v0, ptr %v1, ptr %v2, ptr %t19, %"compiler/source:Span" %t20, i32 %t21, { i64, ptr } %t22)
  store ptr %t27, ptr %l37
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t28 = load ptr, ptr %l37, !tbaa !29
  store ptr %t28, ptr %rv
  br label %ret
bb8:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l39, !tbaa !24
  %t32 = load i64, ptr %l39, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load i64, ptr %l39, !tbaa !24
  %t36 = icmp sle i64 %t35, 1152921504606846975
  br i1 %t36, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e10237a768a7da34_a1fa84f4f434b2e0)
  unreachable
bb11:
  %t38 = load i64, ptr %l39, !tbaa !24
  %t39 = mul i64 %t38, 8
  %t40 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t43 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t43, ptr %lp4
  %t45 = load ptr, ptr %lp4
  store { i64, ptr } %t42, ptr %t45, !tbaa !27
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t46, ptr %l5, !tbaa !23
  store i64 0, ptr %l6, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = icmp sgt i64 %t52, %t53
  br i1 %t56, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e10237a768a7da34_a1fa84f4f434b2e0)
  unreachable
bb13:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = icmp sgt i64 %t58, 0
  br i1 %t60, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb18
bb15:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = add i64 %t66, %t67
  %t72 = sub i64 %t70, 1
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = sdiv i64 %t72, %t73
  store i64 %t76, ptr %l52, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb17
bb17:
  %t78 = load i64, ptr %l52, !tbaa !24
  store i64 %t78, ptr %l49, !tbaa !24
  br label %bb18
bb18:
  %t79 = load i64, ptr %l49, !tbaa !24
  store i64 %t79, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t80 = load i64, ptr %l10, !tbaa !24
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb20, label %bb21
bb20:
  br label %bb47
bb21:
  br label %bb22
bb22:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = mul i64 %t89, %t90
  %t96 = add i64 %t88, %t93
  store i64 %t96, ptr %l11, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t99, ptr %l71, !tbaa !27
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 %t100
  %t105 = load ptr, ptr %t104, !tbaa !39
  %t108 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t98, ptr %t105)
  store i1 %t108, ptr %l74
  br label %bb23
bb23:
  %t109 = load i1, ptr %l74, !tbaa !21
  br i1 %t109, label %bb24, label %bb25
bb24:
  br label %bb46
bb25:
  br label %bb26
bb26:
  %t110 = load i64, ptr %l11, !tbaa !24
  store i64 %t110, ptr %l75, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l76, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t113, ptr %l78, !tbaa !27
  %t114 = load i64, ptr %l11, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr ptr, ptr %t117, i64 %t114
  %t119 = load ptr, ptr %t118, !tbaa !39
  %t121 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t112, ptr %t119, i32 %t121)
  store ptr %t125, ptr %l83
  br label %bb27
bb27:
  %t126 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t126, ptr %l84, !tbaa !27
  %t127 = load i64, ptr %l11, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t127
  %t132 = load ptr, ptr %t131, !tbaa !39
  %t134 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t132)
  store %"compiler/source:Span" %t134, ptr %l87
  br label %bb28
bb28:
  %t135 = load ptr, ptr %l76, !tbaa !29
  %t136 = load ptr, ptr %l83, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l87
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v2, ptr %t135, ptr %t136, %"compiler/source:Span" %t137)
  store ptr %t138, ptr %l88
  br label %bb29
bb29:
  %t139 = load ptr, ptr %l88, !tbaa !29
  %t141 = load ptr, ptr %lp4
  %t142 = load i64, ptr %l75, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr ptr, ptr %t144, i64 %t142
  store ptr %t139, ptr %t145, !tbaa !39
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l90, !tbaa !29
  %t147 = load i64, ptr %l11, !tbaa !24
  %t148 = load ptr, ptr %lp4
  %t150 = getelementptr { i64, ptr }, ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr ptr, ptr %t151, i64 %t147
  %t153 = load ptr, ptr %t152, !tbaa !39
  store ptr %t153, ptr %l12, !tbaa !29
  %t155 = load ptr, ptr %l12, !tbaa !29
  %t157 = icmp eq ptr %t155, null
  br i1 %t157, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_a69c1b36a006a603_82104839c45e26c7)
  unreachable
bb31:
  br label %bb32
bb32:
  %t159 = load ptr, ptr %l12, !tbaa !29
  %t160 = load ptr, ptr %l90, !tbaa !29
  %t162 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v2, ptr %t160, ptr %t159)
  store i32 %t162, ptr %l96
  br label %bb33
bb33:
  %t163 = load i32, ptr %l96, !tbaa !23
  store i32 %t163, ptr %l13, !tbaa !23
  %t164 = load i32, ptr %l5, !tbaa !23
  %t165 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t168 = icmp eq i32 %t164, %t165
  br i1 %t168, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb37
bb35:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l13, !tbaa !23
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t174, ptr %l103
  br label %bb36
bb36:
  %t175 = load i1, ptr %l103, !tbaa !21
  %t176 = xor i1 %t175, true
  store i1 %t176, ptr %l100, !tbaa !21
  br label %bb37
bb37:
  %t178 = load i1, ptr %l100, !tbaa !21
  br i1 %t178, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb41
bb39:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t183 = load i32, ptr %l5, !tbaa !23
  %t184 = load i32, ptr %l13, !tbaa !23
  %t188 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t182, i32 %t183, i32 %t184)
  store i32 %t188, ptr %l110
  br label %bb40
bb40:
  %t189 = load i32, ptr %l110, !tbaa !23
  %t190 = icmp slt i32 %t189, 0
  store i1 %t190, ptr %l105, !tbaa !21
  br label %bb41
bb41:
  %t192 = load i1, ptr %l105, !tbaa !21
  br i1 %t192, label %bb42, label %bb43
bb42:
  %t193 = load i32, ptr %l13, !tbaa !23
  store i32 %t193, ptr %l112, !tbaa !23
  br label %bb45
bb43:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t199 = load i32, ptr %l5, !tbaa !23
  %t200 = load i32, ptr %l13, !tbaa !23
  %t204 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t198, i32 %t199, i32 %t200)
  store i32 %t204, ptr %l118
  br label %bb44
bb44:
  %t205 = load i32, ptr %l118, !tbaa !23
  store i32 %t205, ptr %l112, !tbaa !23
  br label %bb45
bb45:
  %t206 = load i32, ptr %l112, !tbaa !23
  store i32 %t206, ptr %l5, !tbaa !23
  br label %bb46
bb46:
  %t207 = load i64, ptr %l10, !tbaa !24
  %t209 = add i64 %t207, 1
  store i64 %t209, ptr %l10, !tbaa !24
  br label %bb19
bb47:
  %t211 = load i32, ptr %l5, !tbaa !23
  %t212 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t215 = icmp eq i32 %t211, %t212
  br i1 %t215, label %bb48, label %bb49
bb48:
  %t217 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t221 = icmp sgt i64 %t219, 0
  store i1 %t221, ptr %l124, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb50
bb50:
  %t223 = load i1, ptr %l124, !tbaa !21
  br i1 %t223, label %bb51, label %bb52
bb51:
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l128, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t225, ptr %l129
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t227, ptr %l131, !tbaa !27
  %t228 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr ptr, ptr %t229, i64 0
  %t231 = load ptr, ptr %t230, !tbaa !39
  %t233 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t226, ptr %t231, i32 %t233)
  store ptr %t237, ptr %l135
  br label %bb53
bb52:
  br label %bb56
bb53:
  %t238 = load ptr, ptr %l135, !tbaa !29
  %t240 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t238)
  store i32 %t240, ptr %l137
  br label %bb54
bb54:
  %t241 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t242 = load ptr, ptr %l128, !tbaa !29
  %t243 = load %"compiler/source:Span", ptr %l129
  %t244 = load i32, ptr %l137, !tbaa !23
  %t246 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayLit(ptr %v0, ptr %v1, ptr %v2, ptr %t242, %"compiler/source:Span" %t243, i32 %t244, { i64, ptr } %t241)
  store ptr %t246, ptr %l139
  br label %bb55
bb55:
  %t247 = load ptr, ptr %l139, !tbaa !29
  store ptr %t247, ptr %rv
  br label %ret
bb56:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/check:Checker", ptr %t248, i32 0, i32 36
  %t252 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t250)
  store i64 %t252, ptr %l142
  br label %bb57
bb57:
  %t253 = load i64, ptr %l142, !tbaa !24
  store i64 %t253, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t254 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t254, 0
  store i64 %t256, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t258 = load i64, ptr %l16, !tbaa !24
  %t259 = load i64, ptr %l15, !tbaa !24
  %t262 = icmp sgt i64 %t258, %t259
  br i1 %t262, label %bb58, label %bb59
bb58:
  %t264 = load i64, ptr %l17, !tbaa !24
  %t266 = icmp sgt i64 %t264, 0
  br i1 %t266, label %bb60, label %bb61
bb59:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb63
bb60:
  %t268 = load i64, ptr %l16, !tbaa !24
  %t269 = load i64, ptr %l15, !tbaa !24
  %t272 = sub i64 %t268, %t269
  %t273 = load i64, ptr %l17, !tbaa !24
  %t276 = add i64 %t272, %t273
  %t278 = sub i64 %t276, 1
  %t279 = load i64, ptr %l17, !tbaa !24
  %t282 = sdiv i64 %t278, %t279
  store i64 %t282, ptr %l151, !tbaa !24
  br label %bb62
bb61:
  store i64 0, ptr %l151, !tbaa !24
  br label %bb62
bb62:
  %t284 = load i64, ptr %l151, !tbaa !24
  store i64 %t284, ptr %l148, !tbaa !24
  br label %bb63
bb63:
  %t285 = load i64, ptr %l148, !tbaa !24
  store i64 %t285, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb64
bb64:
  %t286 = load i64, ptr %l19, !tbaa !24
  %t287 = load i64, ptr %l18, !tbaa !24
  %t290 = icmp slt i64 %t286, %t287
  %t292 = xor i1 %t290, true
  br i1 %t292, label %bb65, label %bb66
bb65:
  br label %bb85
bb66:
  br label %bb67
bb67:
  %t294 = load i64, ptr %l15, !tbaa !24
  %t295 = load i64, ptr %l19, !tbaa !24
  %t296 = load i64, ptr %l17, !tbaa !24
  %t299 = mul i64 %t295, %t296
  %t302 = add i64 %t294, %t299
  store i64 %t302, ptr %l20, !tbaa !24
  %t304 = load i64, ptr %l20, !tbaa !24
  %t305 = load ptr, ptr %lp4
  %t307 = getelementptr { i64, ptr }, ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr ptr, ptr %t308, i64 %t304
  %t310 = load ptr, ptr %t309, !tbaa !39
  %t312 = icmp eq ptr %t310, null
  %t314 = xor i1 %t312, true
  br i1 %t314, label %bb68, label %bb69
bb68:
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l174, !tbaa !29
  %t317 = load i64, ptr %l20, !tbaa !24
  %t318 = load ptr, ptr %lp4
  %t320 = getelementptr { i64, ptr }, ptr %t318, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr ptr, ptr %t321, i64 %t317
  %t323 = load ptr, ptr %t322, !tbaa !39
  store ptr %t323, ptr %l21, !tbaa !29
  %t325 = load ptr, ptr %l21, !tbaa !29
  %t327 = icmp eq ptr %t325, null
  br i1 %t327, label %bb70, label %bb71
bb69:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t330, ptr %l187, !tbaa !27
  %t331 = load i64, ptr %l20, !tbaa !24
  %t333 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = getelementptr ptr, ptr %t334, i64 %t331
  %t336 = load ptr, ptr %t335, !tbaa !39
  %t337 = load i32, ptr %l5, !tbaa !23
  %t341 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t329, ptr %t336, i32 %t337)
  store ptr %t341, ptr %l191
  br label %bb75
bb70:
  call void @__olang_check_failed(ptr @olang_loc_ddfcf2b97caa4282_7a2ed02469d97696)
  unreachable
bb71:
  br label %bb72
bb72:
  %t342 = load ptr, ptr %l21, !tbaa !29
  store ptr %t342, ptr %l179, !tbaa !29
  %t343 = load i32, ptr %l5, !tbaa !23
  store i32 %t343, ptr %l180, !tbaa !23
  %t344 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t344, ptr %l181, !tbaa !27
  %t345 = load i64, ptr %l20, !tbaa !24
  %t347 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr ptr, ptr %t348, i64 %t345
  %t350 = load ptr, ptr %t349, !tbaa !39
  %t352 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t350)
  store %"compiler/source:Span" %t352, ptr %l184
  br label %bb73
bb73:
  %t353 = load ptr, ptr %l174, !tbaa !29
  %t354 = load ptr, ptr %l179, !tbaa !29
  %t355 = load i32, ptr %l180, !tbaa !23
  %t356 = load %"compiler/source:Span", ptr %l184
  %t357 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t353, ptr %t354, i32 %t355, %"compiler/source:Span" %t356)
  store ptr %t357, ptr %l185
  br label %bb74
bb74:
  %t358 = load ptr, ptr %l185, !tbaa !29
  store ptr %t358, ptr %l173, !tbaa !29
  br label %bb76
bb75:
  %t359 = load ptr, ptr %l191, !tbaa !29
  store ptr %t359, ptr %l173, !tbaa !29
  br label %bb76
bb76:
  %t360 = load ptr, ptr %l173, !tbaa !29
  store ptr %t360, ptr %l22, !tbaa !29
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr %l5, !tbaa !23
  %t365 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t361, i32 %t362)
  store i1 %t365, ptr %l194
  br label %bb77
bb77:
  %t366 = load i1, ptr %l194, !tbaa !21
  %t367 = xor i1 %t366, true
  br i1 %t367, label %bb78, label %bb79
bb78:
  %t369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t369, ptr %l196, !tbaa !29
  %t370 = load ptr, ptr %l22, !tbaa !29
  store ptr %t370, ptr %l198, !tbaa !29
  %t372 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t372, ptr %l199, !tbaa !27
  %t373 = load i64, ptr %l20, !tbaa !24
  %t375 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr ptr, ptr %t376, i64 %t373
  %t378 = load ptr, ptr %t377, !tbaa !39
  %t380 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t378)
  store %"compiler/source:Span" %t380, ptr %l202
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t381 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t382 = load ptr, ptr %l196, !tbaa !29
  %t383 = load ptr, ptr %l198, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l202
  %t386 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t382, ptr %t383, %"compiler/source:Span" %t384, i64 %t381)
  store i1 %t386, ptr %l204
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/check:Checker", ptr %t387, i32 0, i32 36
  %t390 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t389, ptr %t390)
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t393 = load i64, ptr %l19, !tbaa !24
  %t395 = add i64 %t393, 1
  store i64 %t395, ptr %l19, !tbaa !24
  br label %bb64
bb85:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/check:Checker", ptr %t397, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t402 = getelementptr %"compiler/generic:Program", ptr %t400, i32 0, i32 2
  store ptr %t402, ptr %l212, !tbaa !29
  %t403 = load i32, ptr %l5, !tbaa !23
  store i32 %t403, ptr %l213, !tbaa !23
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/check:Checker", ptr %t404, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !29
  %t409 = getelementptr %"compiler/generic:Program", ptr %t407, i32 0, i32 2
  store ptr %t409, ptr %l216, !tbaa !29
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t410)
  store i32 %t412, ptr %l218
  br label %bb86
bb86:
  %t413 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t416 = load ptr, ptr %l216, !tbaa !29
  %t417 = load i32, ptr %l218, !tbaa !23
  %t419 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t416, i32 %t417, i64 %t415)
  store i32 %t419, ptr %l221
  br label %bb87
bb87:
  %t420 = load ptr, ptr %l212, !tbaa !29
  %t421 = load i32, ptr %l213, !tbaa !23
  %t422 = load i32, ptr %l221, !tbaa !23
  %t423 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t420, i32 %t421, i32 %t422)
  store i32 %t423, ptr %l222
  br label %bb88
bb88:
  %t424 = load i32, ptr %l222, !tbaa !23
  %t425 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t425, ptr %l223
  store i32 %t424, ptr %l224, !tbaa !23
  store i32 2, ptr %l225
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/check:Checker", ptr %t427, i32 0, i32 36
  %t430 = load i64, ptr %l14, !tbaa !24
  %t433 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t429, i64 %t430)
  store { i64, ptr } %t433, ptr %l229
  br label %bb89
bb89:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load %"compiler/source:Span", ptr %l1
  %t439 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t434, i32 1, %"compiler/source:Span" %t435)
  store i32 %t439, ptr %l233
  br label %bb90
bb90:
  %t440 = load i32, ptr %l225, !range !{i32 0, i32 5}
  %t441 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t442 = load i32, ptr %l233, !tbaa !23
  %t444 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v2, ptr %v2, i32 %t440, i64 0, { i64, ptr } %t441, ptr null, i32 %t442, i32 0, i1 false)
  store %"compiler/typed:Make" %t444, ptr %l235
  br label %bb91
bb91:
  %t445 = load %"compiler/typed:Make", ptr %l235
  %t446 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t445, ptr %t446
  store { i64, [5 x i64] } zeroinitializer, ptr %t447
  %t448 = getelementptr { i64, [5 x i64] }, ptr %t447, i32 0, i32 0
  store i64 7, ptr %t448
  %t449 = load %"compiler/source:Span", ptr %l223
  %t450 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t449, 0
  %t451 = load i32, ptr %l224, !tbaa !23
  %t452 = insertvalue { %"compiler/source:Span", i32, ptr } %t450, i32 %t451, 1
  %t454 = insertvalue { %"compiler/source:Span", i32, ptr } %t452, ptr %t446, 2
  %t455 = getelementptr { i64, [5 x i64] }, ptr %t447, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t454, ptr %t455
  %t456 = load { i64, [5 x i64] }, ptr %t447
  %t458 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t456, ptr %t458
  store ptr %t458, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %lp11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca { i64, [3 x i64] }
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i64
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca i64
  %l53 = alloca ptr
  %l56 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca i1
  %l66 = alloca i64
  %l70 = alloca i32
  %l74 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l93 = alloca i32
  %l94 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l117 = alloca i64
  %l120 = alloca ptr
  %l133 = alloca i64
  %l136 = alloca i64
  %l157 = alloca i1
  %l162 = alloca i1
  %l163 = alloca { i64, ptr }
  %l174 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l182 = alloca ptr
  %l187 = alloca i32
  %l188 = alloca i64
  %l189 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l194 = alloca { i64, [3 x i64] }
  %l195 = alloca i64
  %l197 = alloca ptr
  %l201 = alloca { i64, ptr }
  %l204 = alloca ptr
  %l207 = alloca { i64, ptr }
  %l210 = alloca ptr
  %l222 = alloca ptr
  %l225 = alloca i1
  %l226 = alloca i1
  %l229 = alloca i1
  %l234 = alloca i32
  %l240 = alloca ptr
  %l245 = alloca i32
  %l246 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l258 = alloca i1
  %l259 = alloca ptr
  %l260 = alloca %"compiler/source:Span"
  %l263 = alloca { i64, ptr }
  %l264 = alloca { i64, ptr }
  %l265 = alloca ptr
  %l270 = alloca i32
  %l271 = alloca { i64, ptr }
  %l273 = alloca %"compiler/diagmsg:Msg"
  %l274 = alloca i64
  %l279 = alloca ptr
  %l286 = alloca ptr
  %l293 = alloca i1
  %l296 = alloca i64
  %l299 = alloca ptr
  %l302 = alloca ptr
  %l306 = alloca i32
  %l307 = alloca i32
  %l308 = alloca { i64, ptr }
  %l309 = alloca { i64, ptr }
  %l311 = alloca ptr
  %l312 = alloca %"compiler/source:Span"
  %l313 = alloca i32
  %l314 = alloca i64
  %l315 = alloca ptr
  %l319 = alloca ptr
  %l320 = alloca { i64, ptr }
  %l321 = alloca ptr
  %l325 = alloca ptr
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t215 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l32
  br label %bb1
bb1:
  %t6 = load i1, ptr %l32, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l33, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l34
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t9, i32 %t10)
  store { i64, ptr } %t13, ptr %l37
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t14 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l38, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l39, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l44
  br label %bb5
bb5:
  %t32 = load ptr, ptr %l39, !tbaa !29
  %t33 = load i32, ptr %l44, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l45
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t44 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoZeroNonNull(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t42, { i64, ptr } %t41)
  store %"compiler/diagmsg:Msg" %t44, ptr %l47
  br label %bb7
bb7:
  %t45 = load ptr, ptr %l33, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l34
  %t47 = load %"compiler/diagmsg:Msg", ptr %l47
  %t48 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t45, %"compiler/source:Span" %t46, %"compiler/diagmsg:Msg" %t47)
  store i64 %t48, ptr %l48
  br label %bb8
bb8:
  %t49 = load i64, ptr %l48, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %t50, i64 %t49)
  br label %bb9
bb9:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t54, %"compiler/source:Span" %t55)
  store ptr %t58, ptr %l53
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  %t59 = load ptr, ptr %l53, !tbaa !29
  store ptr %t59, ptr %rv
  br label %ret
bb11:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l2, !tbaa !23
  %t64 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullableArray(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l56
  br label %bb12
bb12:
  %t65 = load i1, ptr %l56, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  %t68 = load i32, ptr %l2, !tbaa !23
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %t66, %"compiler/source:Span" %t67, i32 %t68)
  store ptr %t72, ptr %l60
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t73 = load ptr, ptr %l60, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t78, ptr %l63
  br label %bb17
bb17:
  %t79 = load i1, ptr %l63, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t80, i32 %t81)
  store i64 %t84, ptr %l66
  br label %bb20
bb19:
  br label %bb92
bb20:
  %t85 = load i64, ptr %l66, !tbaa !24
  store i64 %t85, ptr %l4, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load i32, ptr %l2, !tbaa !23
  %t93 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l70
  br label %bb21
bb21:
  %t94 = load i32, ptr %l70, !tbaa !23
  store i32 %t94, ptr %l5, !tbaa !23
  %t95 = load i32, ptr %l5, !tbaa !23
  %t96 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t99 = icmp ne i32 %t95, %t96
  br i1 %t99, label %bb22, label %bb23
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l77, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %l5, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l82
  br label %bb24
bb23:
  %t117 = icmp sge i64 0, 0
  br i1 %t117, label %bb26, label %bb27
bb24:
  %t119 = load ptr, ptr %l77, !tbaa !29
  %t120 = load i32, ptr %l82, !tbaa !23
  %t121 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t119, i32 %t120)
  store { i64, ptr } %t121, ptr %l83
  br label %bb25
bb25:
  %t122 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t122, ptr %l74, !tbaa !27
  br label %bb30
bb26:
  %t123 = icmp sle i64 0, 2305843009213693951
  br i1 %t123, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_39114b2b59f3c1de_f97787d703923df2)
  unreachable
bb28:
  %t125 = mul i64 0, 4
  %t126 = insertvalue { i64, ptr } undef, i64 0, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t127, ptr %l74, !tbaa !27
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_39114b2b59f3c1de_f97787d703923df2)
  unreachable
bb30:
  %t129 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t129, ptr %l6, !tbaa !27
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  store ptr %t133, ptr %l88, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l2, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l93
  br label %bb31
bb31:
  %t144 = load ptr, ptr %l88, !tbaa !29
  %t145 = load i32, ptr %l93, !tbaa !23
  %t146 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t144, i32 %t145)
  store ptr %t146, ptr %l94
  br label %bb32
bb32:
  %t147 = load ptr, ptr %l94, !tbaa !29
  store ptr %t147, ptr %l7, !tbaa !29
  %t148 = icmp sge i64 0, 0
  br i1 %t148, label %bb33, label %bb34
bb33:
  %t150 = icmp sle i64 0, 1152921504606846975
  br i1 %t150, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_bfa34a8929429713_51639094391671e7)
  unreachable
bb35:
  %t152 = mul i64 0, 8
  %t153 = insertvalue { i64, ptr } undef, i64 0, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t154, ptr %l8, !tbaa !27
  %t156 = load ptr, ptr %l7, !tbaa !29
  %t158 = icmp eq ptr %t156, null
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_bfa34a8929429713_51639094391671e7)
  unreachable
bb37:
  %t162 = load ptr, ptr %l7, !tbaa !29
  %t164 = getelementptr %"compiler/ast:TypeDecl", ptr %t162, i32 0, i32 3
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = icmp eq ptr %t165, null
  %t169 = xor i1 %t167, true
  store i1 %t169, ptr %l101, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb39
bb39:
  %t171 = load i1, ptr %l101, !tbaa !21
  br i1 %t171, label %bb40, label %bb41
bb40:
  %t172 = load ptr, ptr %l7, !tbaa !29
  %t174 = getelementptr %"compiler/ast:TypeDecl", ptr %t172, i32 0, i32 3
  %t175 = load ptr, ptr %t174, !tbaa !29
  store ptr %t175, ptr %l9, !tbaa !29
  %t177 = load ptr, ptr %l9, !tbaa !29
  store ptr %t177, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t178 = load ptr, ptr %l108, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb42, label %bb43
bb41:
  br label %bb53
bb42:
  %t181 = load ptr, ptr %l108, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 5}
  %t184 = icmp eq i64 %t182, 0
  store i1 %t184, ptr %l109, !tbaa !21
  br label %bb43
bb43:
  %t185 = load i1, ptr %l109, !tbaa !21
  br i1 %t185, label %bb44, label %bb45
bb44:
  %t186 = load ptr, ptr %l9, !tbaa !29
  %t188 = getelementptr { i64, [6 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { ptr }, ptr %t188, i32 0, i32 0
  %t190 = load ptr, ptr %t189
  store ptr %t190, ptr %l10, !tbaa !29
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t192 = load ptr, ptr %l10, !tbaa !29
  %t194 = getelementptr %"compiler/ast:StructBody", ptr %t192, i32 0, i32 0
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l8, !tbaa !27
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_37a2617a6fdca52f_9113ce984ee2ba6b)
  unreachable
bb52:
  br label %bb53
bb53:
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  store i64 %t199, ptr %l117, !tbaa !24
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v1, ptr %t200, %"compiler/source:Span" %t201)
  store ptr %t204, ptr %l120
  br label %bb54
bb54:
  %t205 = load i64, ptr %l117, !tbaa !24
  %t206 = icmp sge i64 %t205, 0
  br i1 %t206, label %bb55, label %bb56
bb55:
  %t208 = load i64, ptr %l117, !tbaa !24
  %t209 = icmp sle i64 %t208, 1152921504606846975
  br i1 %t209, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_cffeba9c7beed71d_692ce8f7e2902011)
  unreachable
bb57:
  %t211 = load i64, ptr %l117, !tbaa !24
  %t212 = mul i64 %t211, 8
  %t213 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t212)
  %t214 = load ptr, ptr %l120, !tbaa !29
  store i64 0, ptr %t215
  br label %fill.216
fill.216:
  %t219 = load i64, ptr %t215
  %t220 = icmp slt i64 %t219, %t211
  br i1 %t220, label %fillb.217, label %filld.218
fillb.217:
  %t221 = getelementptr ptr, ptr %t213, i64 %t219
  store ptr %t214, ptr %t221
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %t215
  br label %fill.216
filld.218:
  %t223 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t213, 1
  %t225 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t225, ptr %lp11
  %t227 = load ptr, ptr %lp11
  store { i64, ptr } %t224, ptr %t227, !tbaa !27
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 23
  %t231 = load i32, ptr %t230, !tbaa !23
  store i32 %t231, ptr %l12, !tbaa !23
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l2, !tbaa !23
  %t237 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 23
  store i32 %t234, ptr %t237, !tbaa !23
  store i64 0, ptr %l13, !tbaa !24
  %t238 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t238, 0
  store i64 %t240, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t242 = load i64, ptr %l14, !tbaa !24
  %t243 = load i64, ptr %l13, !tbaa !24
  %t246 = icmp sgt i64 %t242, %t243
  br i1 %t246, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_cffeba9c7beed71d_692ce8f7e2902011)
  unreachable
bb59:
  %t248 = load i64, ptr %l15, !tbaa !24
  %t250 = icmp sgt i64 %t248, 0
  br i1 %t250, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb64
bb61:
  %t252 = load i64, ptr %l14, !tbaa !24
  %t253 = load i64, ptr %l13, !tbaa !24
  %t256 = sub i64 %t252, %t253
  %t257 = load i64, ptr %l15, !tbaa !24
  %t260 = add i64 %t256, %t257
  %t262 = sub i64 %t260, 1
  %t263 = load i64, ptr %l15, !tbaa !24
  %t266 = sdiv i64 %t262, %t263
  store i64 %t266, ptr %l136, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb63
bb63:
  %t268 = load i64, ptr %l136, !tbaa !24
  store i64 %t268, ptr %l133, !tbaa !24
  br label %bb64
bb64:
  %t269 = load i64, ptr %l133, !tbaa !24
  store i64 %t269, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb65
bb65:
  %t270 = load i64, ptr %l17, !tbaa !24
  %t271 = load i64, ptr %l16, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb66, label %bb67
bb66:
  br label %bb90
bb67:
  br label %bb68
bb68:
  %t278 = load i64, ptr %l13, !tbaa !24
  %t279 = load i64, ptr %l17, !tbaa !24
  %t280 = load i64, ptr %l15, !tbaa !24
  %t283 = mul i64 %t279, %t280
  %t286 = add i64 %t278, %t283
  store i64 %t286, ptr %l18, !tbaa !24
  %t288 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t292 = icmp sgt i64 %t290, 0
  br i1 %t292, label %bb69, label %bb70
bb69:
  %t294 = load i64, ptr %l18, !tbaa !24
  %t295 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t295, 0
  %t300 = icmp slt i64 %t294, %t297
  store i1 %t300, ptr %l157, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l157, !tbaa !21
  br label %bb71
bb71:
  %t302 = load i1, ptr %l157, !tbaa !21
  br i1 %t302, label %bb72, label %bb73
bb72:
  %t303 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t303, ptr %l163, !tbaa !27
  %t304 = load i64, ptr %l18, !tbaa !24
  %t306 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr ptr, ptr %t307, i64 %t304
  %t309 = load ptr, ptr %t308, !tbaa !39
  %t311 = getelementptr %"compiler/ast:Param", ptr %t309, i32 0, i32 3
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = icmp eq ptr %t312, null
  %t316 = xor i1 %t314, true
  store i1 %t316, ptr %l162, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb74
bb74:
  %t318 = load i1, ptr %l162, !tbaa !21
  store i1 %t318, ptr %l19, !tbaa !21
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 13
  %t322 = load { i64, [3 x i64] }, ptr %t321
  store { i64, [3 x i64] } %t322, ptr %l20
  %t324 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t328 = icmp sgt i64 %t326, 0
  br i1 %t328, label %bb75, label %bb76
bb75:
  %t330 = load i64, ptr %l18, !tbaa !24
  %t331 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t331, 0
  %t336 = icmp slt i64 %t330, %t333
  store i1 %t336, ptr %l174, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb77
bb77:
  %t338 = load i1, ptr %l174, !tbaa !21
  br i1 %t338, label %bb78, label %bb79
bb78:
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l179, !tbaa !29
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l180, !tbaa !29
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !29
  store ptr %t344, ptr %l182, !tbaa !29
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t350 = getelementptr %"compiler/generic:Program", ptr %t348, i32 0, i32 2
  %t351 = load i32, ptr %l2, !tbaa !23
  %t354 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t350, i32 %t351)
  store i32 %t354, ptr %l187
  br label %bb80
bb79:
  br label %bb83
bb80:
  %t355 = load ptr, ptr %l182, !tbaa !29
  %t356 = load i32, ptr %l187, !tbaa !23
  %t357 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t355, i32 %t356)
  store i64 %t357, ptr %l188
  br label %bb81
bb81:
  %t358 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t358, ptr %l189, !tbaa !27
  %t359 = load i64, ptr %l18, !tbaa !24
  %t361 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr ptr, ptr %t362, i64 %t359
  %t364 = load ptr, ptr %t363, !tbaa !39
  %t366 = getelementptr %"compiler/ast:Param", ptr %t364, i32 0, i32 2
  %t367 = load ptr, ptr %t366, !tbaa !29
  store ptr %t367, ptr %l192, !tbaa !29
  %t368 = load ptr, ptr %l192, !tbaa !29
  %t369 = call ptr @__olang_scope_of(ptr %t368, ptr null)
  %t370 = ptrtoint ptr %t369 to i64
  %t372 = inttoptr i64 %t370 to ptr
  %t373 = load ptr, ptr %l180, !tbaa !29
  %t374 = load i64, ptr %l188, !tbaa !24
  %t375 = load ptr, ptr %l192, !tbaa !29
  %t376 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %t372, ptr %t373, i64 %t374, ptr %t375)
  store { i64, [3 x i64] } %t376, ptr %l194
  br label %bb82
bb82:
  %t377 = load { i64, [3 x i64] }, ptr %l194
  %t378 = load ptr, ptr %l179, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t378, i32 0, i32 13
  store { i64, [3 x i64] } %t377, ptr %t379
  br label %bb83
bb83:
  %t380 = load i64, ptr %l18, !tbaa !24
  store i64 %t380, ptr %l195, !tbaa !24
  %t381 = load i1, ptr %l19, !tbaa !21
  br i1 %t381, label %bb84, label %bb85
bb84:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  %t385 = load i64, ptr %l18, !tbaa !24
  %t386 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t386, ptr %l201, !tbaa !27
  %t387 = load i64, ptr %l18, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr i32, ptr %t390, i64 %t387
  %t392 = load i32, ptr %t391, !tbaa !33
  %t397 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %t383, %"compiler/source:Span" %t384, i64 %t385, i32 %t392)
  store ptr %t397, ptr %l204
  br label %bb86
bb85:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load %"compiler/source:Span", ptr %l1
  %t400 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t400, ptr %l207, !tbaa !27
  %t401 = load i64, ptr %l18, !tbaa !24
  %t403 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr i32, ptr %t404, i64 %t401
  %t406 = load i32, ptr %t405, !tbaa !33
  %t410 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %t398, %"compiler/source:Span" %t399, i32 %t406)
  store ptr %t410, ptr %l210
  br label %bb87
bb86:
  %t411 = load ptr, ptr %l204, !tbaa !29
  store ptr %t411, ptr %l197, !tbaa !29
  br label %bb88
bb87:
  %t412 = load ptr, ptr %l210, !tbaa !29
  store ptr %t412, ptr %l197, !tbaa !29
  br label %bb88
bb88:
  %t413 = load ptr, ptr %l197, !tbaa !29
  %t414 = load ptr, ptr %lp11
  %t415 = load i64, ptr %l195, !tbaa !24
  %t416 = getelementptr { i64, ptr }, ptr %t414, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !27
  %t418 = getelementptr ptr, ptr %t417, i64 %t415
  store ptr %t413, ptr %t418, !tbaa !39
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load { i64, [3 x i64] }, ptr %l20
  %t423 = getelementptr %"compiler/check:Checker", ptr %t419, i32 0, i32 13
  store { i64, [3 x i64] } %t420, ptr %t423
  br label %bb89
bb89:
  %t424 = load i64, ptr %l17, !tbaa !24
  %t426 = add i64 %t424, 1
  store i64 %t426, ptr %l17, !tbaa !24
  br label %bb65
bb90:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load i32, ptr %l12, !tbaa !23
  %t432 = getelementptr %"compiler/check:Checker", ptr %t428, i32 0, i32 23
  store i32 %t429, ptr %t432, !tbaa !23
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load %"compiler/source:Span", ptr %l1
  %t435 = load i32, ptr %l2, !tbaa !23
  %t436 = load i64, ptr %l4, !tbaa !24
  %t437 = load ptr, ptr %lp11
  %t438 = load { i64, ptr }, ptr %t437, !tbaa !27
  %t444 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v1, ptr %v1, ptr %t433, %"compiler/source:Span" %t434, i32 %t435, i64 %t436, { i64, ptr } %t438, i1 true)
  store ptr %t444, ptr %l222
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s3)
  %t445 = load ptr, ptr %l222, !tbaa !29
  store ptr %t445, ptr %rv
  br label %ret
bb92:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load i32, ptr %l2, !tbaa !23
  %t450 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t446, i32 %t447)
  store i1 %t450, ptr %l225
  br label %bb93
bb93:
  %t451 = load i1, ptr %l225, !tbaa !21
  br i1 %t451, label %bb94, label %bb95
bb94:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t453 = load i32, ptr %l2, !tbaa !23
  %t456 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t452, i32 %t453)
  store i1 %t456, ptr %l229
  br label %bb96
bb95:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb97
bb96:
  %t457 = load i1, ptr %l229, !tbaa !21
  %t458 = xor i1 %t457, true
  store i1 %t458, ptr %l226, !tbaa !21
  br label %bb97
bb97:
  %t460 = load i1, ptr %l226, !tbaa !21
  br i1 %t460, label %bb98, label %bb99
bb98:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/check:Checker", ptr %t461, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !29
  %t465 = load i32, ptr %l2, !tbaa !23
  %t468 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t464, i32 %t465, i64 0)
  store i32 %t468, ptr %l234
  br label %bb100
bb99:
  br label %bb127
bb100:
  %t469 = load i32, ptr %l234, !tbaa !23
  store i32 %t469, ptr %l21, !tbaa !23
  %t470 = load i32, ptr %l21, !tbaa !23
  %t471 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t474 = icmp ne i32 %t470, %t471
  br i1 %t474, label %bb101, label %bb102
bb101:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = getelementptr %"compiler/check:Checker", ptr %t476, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !29
  %t481 = getelementptr %"compiler/generic:Program", ptr %t479, i32 0, i32 2
  store ptr %t481, ptr %l240, !tbaa !29
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/check:Checker", ptr %t482, i32 0, i32 1
  %t485 = load ptr, ptr %t484, !tbaa !29
  %t487 = getelementptr %"compiler/generic:Program", ptr %t485, i32 0, i32 2
  %t488 = load i32, ptr %l21, !tbaa !23
  %t491 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t487, i32 %t488)
  store i32 %t491, ptr %l245
  br label %bb103
bb102:
  br label %bb126
bb103:
  %t492 = load ptr, ptr %l240, !tbaa !29
  %t493 = load i32, ptr %l245, !tbaa !23
  %t494 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t492, i32 %t493)
  store { i64, ptr } %t494, ptr %l246
  br label %bb104
bb104:
  %t495 = load { i64, ptr }, ptr %l246, !tbaa !27
  store { i64, ptr } %t495, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t496 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t498 = extractvalue { i64, ptr } %t496, 0
  store i64 %t498, ptr %l24, !tbaa !24
  br label %bb105
bb105:
  %t500 = load i64, ptr %l23, !tbaa !24
  %t501 = load i64, ptr %l24, !tbaa !24
  %t504 = icmp slt i64 %t500, %t501
  %t506 = xor i1 %t504, true
  br i1 %t506, label %bb106, label %bb107
bb106:
  br label %bb121
bb107:
  br label %bb108
bb108:
  %t508 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t508, ptr %l253, !tbaa !27
  %t509 = load i64, ptr %l23, !tbaa !24
  %t511 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t512 = load ptr, ptr %t511, !tbaa !27
  %t513 = getelementptr i32, ptr %t512, i64 %t509
  %t514 = load i32, ptr %t513, !tbaa !33
  store i32 %t514, ptr %l25, !tbaa !23
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load i32, ptr %l25, !tbaa !23
  %t520 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t516, i32 %t517)
  store i1 %t520, ptr %l258
  br label %bb109
bb109:
  %t521 = load i1, ptr %l258, !tbaa !21
  br i1 %t521, label %bb110, label %bb111
bb110:
  store %olang.scope zeroinitializer, ptr %s15
  %t522 = load ptr, ptr %l0, !tbaa !29
  store ptr %t522, ptr %l259, !tbaa !29
  %t523 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t523, ptr %l260
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load i32, ptr %l25, !tbaa !23
  %t528 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t524, i32 %t525)
  store { i64, ptr } %t528, ptr %l263
  br label %bb112
bb111:
  br label %bb119
bb112:
  %t529 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t530 = extractvalue { i64, ptr } %t529, 0
  %t531 = extractvalue { i64, ptr } %t529, 1
  %t532 = mul i64 %t530, 1
  %t533 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t532)
  call void @llvm.memcpy.p0.p0.i64(ptr %t533, ptr %t531, i64 %t532, i1 false)
  %t534 = insertvalue { i64, ptr } undef, i64 %t530, 0
  %t535 = insertvalue { i64, ptr } %t534, ptr %t533, 1
  store { i64, ptr } %t535, ptr %l264, !tbaa !27
  %t536 = load ptr, ptr %l0, !tbaa !29
  store ptr %t536, ptr %l265, !tbaa !29
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr %"compiler/check:Checker", ptr %t537, i32 0, i32 1
  %t540 = load ptr, ptr %t539, !tbaa !29
  %t542 = getelementptr %"compiler/generic:Program", ptr %t540, i32 0, i32 2
  %t543 = load i32, ptr %l25, !tbaa !23
  %t546 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t542, i32 %t543)
  store i32 %t546, ptr %l270
  br label %bb113
bb113:
  %t547 = load ptr, ptr %l265, !tbaa !29
  %t548 = load i32, ptr %l270, !tbaa !23
  %t549 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s15, ptr %t547, i32 %t548)
  store { i64, ptr } %t549, ptr %l271
  br label %bb114
bb114:
  %t550 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t551 = extractvalue { i64, ptr } %t550, 0
  %t552 = extractvalue { i64, ptr } %t550, 1
  %t553 = mul i64 %t551, 1
  %t554 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t553)
  call void @llvm.memcpy.p0.p0.i64(ptr %t554, ptr %t552, i64 %t553, i1 false)
  %t555 = insertvalue { i64, ptr } undef, i64 %t551, 0
  %t556 = insertvalue { i64, ptr } %t555, ptr %t554, 1
  %t557 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t559 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoZeroNonNull(ptr %s15, ptr %s15, ptr %s15, { i64, ptr } %t557, { i64, ptr } %t556)
  store %"compiler/diagmsg:Msg" %t559, ptr %l273
  br label %bb115
bb115:
  %t560 = load ptr, ptr %l259, !tbaa !29
  %t561 = load %"compiler/source:Span", ptr %l260
  %t562 = load %"compiler/diagmsg:Msg", ptr %l273
  %t563 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t560, %"compiler/source:Span" %t561, %"compiler/diagmsg:Msg" %t562)
  store i64 %t563, ptr %l274
  br label %bb116
bb116:
  %t564 = load i64, ptr %l274, !tbaa !24
  %t565 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %t565, i64 %t564)
  br label %bb117
bb117:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load %"compiler/source:Span", ptr %l1
  %t573 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t569, %"compiler/source:Span" %t570)
  store ptr %t573, ptr %l279
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s15)
  %t574 = load ptr, ptr %l279, !tbaa !29
  store ptr %t574, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t575 = load i64, ptr %l23, !tbaa !24
  %t577 = add i64 %t575, 1
  store i64 %t577, ptr %l23, !tbaa !24
  br label %bb105
bb121:
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t580 = load %"compiler/source:Span", ptr %l1
  %t581 = load i32, ptr %l2, !tbaa !23
  %t582 = load i32, ptr %l21, !tbaa !23
  %t587 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseZero(ptr %v0, ptr %v1, ptr %t579, %"compiler/source:Span" %t580, i32 %t581, i32 %t582)
  store ptr %t587, ptr %l286
  br label %bb122
bb122:
  %t588 = load ptr, ptr %l286, !tbaa !29
  store ptr %t588, ptr %l27, !tbaa !29
  %t589 = load ptr, ptr %l27, !tbaa !29
  %t591 = icmp eq ptr %t589, null
  %t593 = xor i1 %t591, true
  br i1 %t593, label %bb123, label %bb124
bb123:
  %t595 = load ptr, ptr %l27, !tbaa !29
  store ptr %t595, ptr %rv
  br label %ret
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t598 = load i32, ptr %l2, !tbaa !23
  %t601 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %t597, i32 %t598)
  store i1 %t601, ptr %l293
  br label %bb128
bb128:
  %t602 = load i1, ptr %l293, !tbaa !21
  br i1 %t602, label %bb129, label %bb130
bb129:
  store %olang.scope zeroinitializer, ptr %s18
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load i32, ptr %l2, !tbaa !23
  %t607 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t603, i32 %t604)
  store i64 %t607, ptr %l296
  br label %bb131
bb130:
  br label %bb138
bb131:
  %t608 = load i64, ptr %l296, !tbaa !24
  store i64 %t608, ptr %l28, !tbaa !24
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t611 = getelementptr %"compiler/check:Checker", ptr %t609, i32 0, i32 1
  %t612 = load ptr, ptr %t611, !tbaa !29
  %t614 = getelementptr %"compiler/generic:Program", ptr %t612, i32 0, i32 2
  store ptr %t614, ptr %l299, !tbaa !29
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = getelementptr %"compiler/check:Checker", ptr %t615, i32 0, i32 1
  %t618 = load ptr, ptr %t617, !tbaa !29
  %t620 = getelementptr %"compiler/generic:Program", ptr %t618, i32 0, i32 2
  store ptr %t620, ptr %l302, !tbaa !29
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t623 = getelementptr %"compiler/check:Checker", ptr %t621, i32 0, i32 1
  %t624 = load ptr, ptr %t623, !tbaa !29
  %t625 = load i32, ptr %l2, !tbaa !23
  %t628 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t624, i32 %t625)
  store i32 %t628, ptr %l306
  br label %bb132
bb132:
  %t629 = load ptr, ptr %l302, !tbaa !29
  %t630 = load i32, ptr %l306, !tbaa !23
  %t631 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t629, i32 %t630)
  store i32 %t631, ptr %l307
  br label %bb133
bb133:
  %t632 = load ptr, ptr %l299, !tbaa !29
  %t633 = load i32, ptr %l307, !tbaa !23
  %t634 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s18, ptr %t632, i32 %t633)
  store { i64, ptr } %t634, ptr %l308
  br label %bb134
bb134:
  %t635 = load { i64, ptr }, ptr %l308, !tbaa !27
  store { i64, ptr } %t635, ptr %l309, !tbaa !27
  %t636 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t637 = load ptr, ptr %t636, !tbaa !27
  %t638 = getelementptr i32, ptr %t637, i64 0
  %t639 = load i32, ptr %t638, !tbaa !33
  %t641 = load ptr, ptr %l0, !tbaa !29
  store ptr %t641, ptr %l311, !tbaa !29
  %t642 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t642, ptr %l312
  %t643 = load i32, ptr %l2, !tbaa !23
  store i32 %t643, ptr %l313, !tbaa !23
  %t644 = load i64, ptr %l28, !tbaa !24
  store i64 %t644, ptr %l314, !tbaa !24
  %t645 = load ptr, ptr %l0, !tbaa !29
  store ptr %t645, ptr %l315, !tbaa !29
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t647 = load %"compiler/source:Span", ptr %l1
  %t652 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t646, %"compiler/source:Span" %t647, i32 %t639)
  store ptr %t652, ptr %l319
  br label %bb135
bb135:
  %t653 = load ptr, ptr %l315, !tbaa !29
  %t654 = load ptr, ptr %l319, !tbaa !29
  %t655 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v0, ptr %v0, ptr %t653, ptr %t654)
  store { i64, ptr } %t655, ptr %l320
  br label %bb136
bb136:
  %t656 = load ptr, ptr %l311, !tbaa !29
  %t657 = load %"compiler/source:Span", ptr %l312
  %t658 = load i32, ptr %l313, !tbaa !23
  %t659 = load i64, ptr %l314, !tbaa !24
  %t660 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t661 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v0, ptr %v1, ptr %t656, %"compiler/source:Span" %t657, i32 %t658, i64 %t659, { i64, ptr } %t660, i1 true)
  store ptr %t661, ptr %l321
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s18)
  %t662 = load ptr, ptr %l321, !tbaa !29
  store ptr %t662, ptr %rv
  br label %ret
bb138:
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t664 = load %"compiler/source:Span", ptr %l1
  %t665 = load i32, ptr %l2, !tbaa !23
  %t669 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %t663, %"compiler/source:Span" %t664, i32 %t665, i64 0)
  store ptr %t669, ptr %l325
  br label %bb139
bb139:
  %t670 = load ptr, ptr %l325, !tbaa !29
  store ptr %t670, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l24 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i1
  %l49 = alloca i1
  %l54 = alloca ptr
  %l60 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l5, !tbaa !29
  br label %bb47
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 14
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Try", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Try", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb14, label %bb15
bb13:
  store ptr null, ptr %l24, !tbaa !29
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9272b3113db2835a_2a2a8b0a39f9db7e)
  unreachable
bb15:
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Try", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %t53)
  store ptr %t55, ptr %l30
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l30, !tbaa !29
  store ptr %t56, ptr %l24, !tbaa !29
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l24, !tbaa !29
  store ptr %t57, ptr %l5, !tbaa !29
  br label %bb47
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 18}
  %t65 = icmp eq i64 %t63, 17
  store i1 %t65, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l32, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = call ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %t73)
  store ptr %t75, ptr %l38
  br label %bb25
bb25:
  %t76 = load ptr, ptr %l38, !tbaa !29
  store ptr %t76, ptr %l5, !tbaa !29
  br label %bb47
bb26:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t81 = load ptr, ptr %l39, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 18}
  %t84 = icmp eq i64 %t82, 12
  store i1 %t84, ptr %l40, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l40, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  br label %bb42
bb31:
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Seq", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = icmp eq ptr %t95, null
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb32, label %bb33
bb32:
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Seq", ptr %t101, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = icmp eq i64 %t106, 0
  store i1 %t108, ptr %l49, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb34
bb34:
  %t110 = load i1, ptr %l49, !tbaa !21
  br i1 %t110, label %bb35, label %bb36
bb35:
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Seq", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb37, label %bb38
bb36:
  store ptr null, ptr %l54, !tbaa !29
  br label %bb41
bb37:
  call void @__olang_check_failed(ptr @olang_loc_e85625530f05a4e1_e8094ee11349b825)
  unreachable
bb38:
  br label %bb39
bb39:
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Seq", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = call ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %t121)
  store ptr %t123, ptr %l60
  br label %bb40
bb40:
  %t124 = load ptr, ptr %l60, !tbaa !29
  store ptr %t124, ptr %l54, !tbaa !29
  br label %bb41
bb41:
  %t125 = load ptr, ptr %l54, !tbaa !29
  store ptr %t125, ptr %l5, !tbaa !29
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_fd7989cc94cf1ac3_95016419ffbfbd17)
  unreachable
bb47:
  %t126 = load ptr, ptr %l5, !tbaa !29
  store ptr %t126, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2eisArrayMake(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 2 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f62b02ebb614301c_75e9b5b90c5bfe48)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4777492a424db66f_87dc2d494f6ca16b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2elimitBits(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca [6 x i64]
  %l41 = alloca [6 x i64]
  %l46 = alloca [6 x i64]
  %l49 = alloca [6 x i64]
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l13
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t18 = load i1, ptr %l13, !tbaa !21
  store i1 %t18, ptr %l4, !tbaa !21
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp eq i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load i1, ptr %l4, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb7:
  br label %bb14
bb8:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp eq i64 %t25, 64
  br i1 %t27, label %bb10, label %bb11
bb9:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t29, 1
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = shl i64 1, %t33
  %t36 = sub i64 %t34, 1
  store i64 %t36, ptr %l17, !tbaa !24
  br label %bb13
bb10:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb12
bb11:
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  %t39 = load i64, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l21, !tbaa !24
  %t41 = shl i64 1, %t40
  %t43 = sub i64 %t41, 1
  store i64 %t43, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l20, !tbaa !24
  store i64 %t45, ptr %l17, !tbaa !24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l17, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
bb14:
  %t47 = load i1, ptr %l4, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb17
bb16:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = sub i64 %t49, 1
  store i64 %t51, ptr %l31, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = load i64, ptr %l31, !tbaa !24
  %t54 = shl i64 1, %t53
  %t56 = sub i64 0, %t54
  store i64 %t56, ptr %l29, !tbaa !24
  br label %bb17
bb17:
  %t58 = load i64, ptr %l29, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
bb18:
  %t59 = load i32, ptr %l1, !tbaa !23
  %t61 = icmp eq i32 %t59, 13
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = insertvalue [6 x i64] undef, i64 2139095039, 0
  %t64 = insertvalue [6 x i64] %t63, i64 4286578687, 1
  %t65 = insertvalue [6 x i64] %t64, i64 2139095040, 2
  %t66 = insertvalue [6 x i64] %t65, i64 2143289344, 3
  %t67 = insertvalue [6 x i64] %t66, i64 872415232, 4
  %t68 = insertvalue [6 x i64] %t67, i64 8388608, 5
  store [6 x i64] %t68, ptr %l36
  %t69 = load i64, ptr %l2, !tbaa !24
  %t71 = getelementptr [6 x i64], ptr %l36, i64 0, i64 %t69
  %t72 = load i64, ptr %t71, !tbaa !34
  store i64 %t72, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t74 = load i32, ptr %l1, !tbaa !23
  %t76 = icmp eq i32 %t74, 11
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t78 = insertvalue [6 x i64] undef, i64 31743, 0
  %t79 = insertvalue [6 x i64] %t78, i64 64511, 1
  %t80 = insertvalue [6 x i64] %t79, i64 31744, 2
  %t81 = insertvalue [6 x i64] %t80, i64 32256, 3
  %t82 = insertvalue [6 x i64] %t81, i64 5120, 4
  %t83 = insertvalue [6 x i64] %t82, i64 1024, 5
  store [6 x i64] %t83, ptr %l41
  %t84 = load i64, ptr %l2, !tbaa !24
  %t86 = getelementptr [6 x i64], ptr %l41, i64 0, i64 %t84
  %t87 = load i64, ptr %t86, !tbaa !34
  store i64 %t87, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t89 = load i32, ptr %l1, !tbaa !23
  %t91 = icmp eq i32 %t89, 12
  br i1 %t91, label %bb25, label %bb26
bb25:
  %t93 = insertvalue [6 x i64] undef, i64 32639, 0
  %t94 = insertvalue [6 x i64] %t93, i64 65407, 1
  %t95 = insertvalue [6 x i64] %t94, i64 32640, 2
  %t96 = insertvalue [6 x i64] %t95, i64 32704, 3
  %t97 = insertvalue [6 x i64] %t96, i64 15360, 4
  %t98 = insertvalue [6 x i64] %t97, i64 128, 5
  store [6 x i64] %t98, ptr %l46
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = getelementptr [6 x i64], ptr %l46, i64 0, i64 %t99
  %t102 = load i64, ptr %t101, !tbaa !34
  store i64 %t102, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t104 = insertvalue [6 x i64] undef, i64 9218868437227405311, 0
  %t105 = insertvalue [6 x i64] %t104, i64 -4503599627370497, 1
  %t106 = insertvalue [6 x i64] %t105, i64 9218868437227405312, 2
  %t107 = insertvalue [6 x i64] %t106, i64 9221120237041090560, 3
  %t108 = insertvalue [6 x i64] %t107, i64 4372995238176751616, 4
  %t109 = insertvalue [6 x i64] %t108, i64 4503599627370496, 5
  store [6 x i64] %t109, ptr %l49
  %t110 = load i64, ptr %l2, !tbaa !24
  %t112 = getelementptr [6 x i64], ptr %l49, i64 0, i64 %t110
  %t113 = load i64, ptr %t112, !tbaa !34
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2elocalRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l8, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_51cc068c3aeae8b4_3b6d62df8d15b2a8)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a6ce77febe1defe5_34385e948c177179)
  unreachable
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ereflVal_2enoRefl(ptr %v0) #0 {
entry:
  %l1 = alloca %"compiler/check:reflVal"
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t3 = call %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v0, i1 false, i64 0, i64 0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, i32 %t1)
  store %"compiler/check:reflVal" %t3, ptr %l1
  br label %bb1
bb1:
  %t4 = load %"compiler/check:reflVal", ptr %l1
  store %"compiler/check:reflVal" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local i32 @compiler_2fcheck_2esatOp(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 48, ptr %l1
  br label %bb25
bb5:
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t8, ptr %l6
  br label %bb6
bb6:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 49, ptr %l1
  br label %bb25
bb10:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t13, ptr %l9
  br label %bb11
bb11:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i32 50, ptr %l1
  br label %bb25
bb15:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t18, ptr %l12
  br label %bb16
bb16:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 51, ptr %l1
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 29, ptr %l1
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_3bfa2fc53dda7240_53e39c3717a0962c)
  unreachable
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i32, ptr %l1, !range !{i32 0, i32 52}
  store i32 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l32 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 30}
  %t17 = icmp eq i64 %t15, 21
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 30}
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb35
bb14:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 30}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr }, ptr %t39, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l1, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = call i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %t43)
  store i1 %t45, ptr %l23
  br label %bb20
bb20:
  %t46 = load i1, ptr %l23, !tbaa !21
  store i1 %t46, ptr %l3, !tbaa !21
  br label %bb35
bb21:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t48 = load ptr, ptr %l24, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb22, label %bb23
bb22:
  %t51 = load ptr, ptr %l24, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 30}
  %t54 = icmp eq i64 %t52, 3
  store i1 %t54, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t55 = load i1, ptr %l25, !tbaa !21
  br i1 %t55, label %bb24, label %bb25
bb24:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 1
  %t60 = load i32, ptr %t59, !range !{i32 0, i32 113}
  store i32 %t60, ptr %l2
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t62 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t64 = trunc i64 91 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb29
bb28:
  %t67 = load i32, ptr %l2, !range !{i32 0, i32 113}
  %t69 = trunc i64 92 to i32
  %t70 = icmp eq i32 %t67, %t69
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb29
bb29:
  %t72 = load i1, ptr %l32, !tbaa !21
  store i1 %t72, ptr %l3, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d195b38137e2d30_7d67c1d5e7f3802c)
  unreachable
bb35:
  %t73 = load i1, ptr %l3, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t4, ptr %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/ast:If", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:If", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b4de3dcccf9032b4_264e366d03c66670)
  unreachable
bb5:
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/ast:If", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Branch", ptr %t27, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t32 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t31, ptr %t32)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/ast:If", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:altsCovered" @compiler_2fcheck_3aaltsCovered_2ector(ptr %v0, ptr %v1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, i1 %a1, i1 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:altsCovered"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:altsCovered" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, 0
  %t12 = insertvalue %"compiler/check:altsCovered" %t10, i1 %a1, 1
  %t14 = insertvalue %"compiler/check:altsCovered" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/check:altsCovered" %t14, i1 %a3, 3
  %t18 = insertvalue %"compiler/check:altsCovered" %t16, i1 false, 4
  store %"compiler/check:altsCovered" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:altsCovered", ptr %rv
  ret %"compiler/check:altsCovered" %rr
}

define dso_local %"compiler/check:factRead" @compiler_2fcheck_3afactRead_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, { i64, ptr } %a1, i1 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/check:factRead"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/check:factRead" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/check:factRead" %t14, { i64, ptr } %a1, 1
  %t18 = insertvalue %"compiler/check:factRead" %t16, i1 %a2, 2
  %t20 = insertvalue %"compiler/check:factRead" %t18, i64 %a3, 3
  %t22 = insertvalue %"compiler/check:factRead" %t20, %"compiler/source:Span" %a4, 4
  %t24 = insertvalue %"compiler/check:factRead" %t22, { i64, ptr } %a5, 5
  store %"compiler/check:factRead" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factRead", ptr %rv
  ret %"compiler/check:factRead" %rr
}

define dso_local %"compiler/check:factsCopy" @compiler_2fcheck_3afactsCopy_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %rv = alloca %"compiler/check:factsCopy"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:factsCopy" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, 0
  %t10 = insertvalue %"compiler/check:factsCopy" %t8, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, 1
  %t12 = insertvalue %"compiler/check:factsCopy" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, 2
  store %"compiler/check:factsCopy" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factsCopy", ptr %rv
  ret %"compiler/check:factsCopy" %rr
}

define dso_local %"compiler/check:landing" @compiler_2fcheck_3alanding_2ector(ptr %v0, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/check:landing"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:landing" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/check:landing" %t12, i64 %a1, 1
  %t16 = insertvalue %"compiler/check:landing" %t14, %"compiler/source:Span" %a2, 2
  %t18 = insertvalue %"compiler/check:landing" %t16, i32 %a3, 3
  %t20 = insertvalue %"compiler/check:landing" %t18, i64 %a4, 4
  store %"compiler/check:landing" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:landing", ptr %rv
  ret %"compiler/check:landing" %rr
}

define dso_local %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"compiler/check:laneVals"
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l0, !tbaa !24
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  %t3 = load i64, ptr %l0, !tbaa !24
  %t4 = insertvalue %"compiler/check:laneVals" undef, i64 %t3, 0
  %t6 = insertvalue %"compiler/check:laneVals" %t4, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, 1
  store %"compiler/check:laneVals" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:laneVals", ptr %rv
  ret %"compiler/check:laneVals" %rr
}

define dso_local %"compiler/check:seqOf" @compiler_2fcheck_3aseqOf_2ector(ptr %v0, i32 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:seqOf"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:seqOf" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/check:seqOf" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:seqOf" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:seqOf" %t14, i64 %a3, 3
  store %"compiler/check:seqOf" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:seqOf", ptr %rv
  ret %"compiler/check:seqOf" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare ptr @__olang_scope_of(ptr, ptr) noinline
declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d6 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d7 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d8 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Overflow" }>, align 8
@.d9 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d10 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d11 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Invalid" }>, align 8
@.d12 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"the checker asked for the body of a frame that checks none" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr }) cold noreturn
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 48
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 48
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"compiler/check:factsCopy" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fcheck_3afactsCopy(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/check:factsCopy"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/check:factsCopy"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/check:factsCopy", ptr %a0
  store %"compiler/check:factsCopy" %t2, ptr %l1
  %t3 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 1
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l5
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t12 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %t12
  %t13 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 2
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %t13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l7
  br label %bb3
bb3:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t17 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t17
  %t18 = load %"compiler/check:factsCopy", ptr %l1
  store %"compiler/check:factsCopy" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factsCopy", ptr %rv
  ret %"compiler/check:factsCopy" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d14 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"LanesEqual" }>, align 8
@.d15 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"LanesLess" }>, align 8
@.d16 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"LanesEqual" }>, align 8
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Select" }>, align 8
@.d18 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'Select'" }>, align 8
@.d19 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'Select'" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"a store over a value with destructors to run, reached through what a call gives (O15)" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @llvm.coro.promise(ptr, i32, i1)
@.d28 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d29 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d30 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a local made from it" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"satAdd" }>, align 8
@.d33 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"satSub" }>, align 8
@.d34 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"satMul" }>, align 8
@.d35 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"satShl" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotCall(ptr %v0, ptr %a0, i32 %a1, i64 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:AnySlot" %a1)
declare i1 @compiler_2fcheck_2ehasNamed(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_e1138a3bee8dfd28_1d9c93b07a3bbf3c = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyDefault(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultCopiesRecv(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNoCopy(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ecdebd42147a0915_28ece6113815da89 = external constant [0 x i8]
@olang_loc_b35cdd4155941ff6_f61ebbb89c67ebca = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNoMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyTableOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eNewAnyTable(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteAnyMethod(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/diagmsg:Msg" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eRef_H0986089bcad3c266fbd2f46fa03b07d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantStr(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare ptr @compiler_2fcheck_2epastAway(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritableTemp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_1698deca837a7d96_de8e9bfeb7067cd2 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_94214b31169ec8c4_68c852e51d74cc68 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_d48ba9fb56fa57b5_9836703f13f4bc39 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPiece(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_964ce48e3719b9fe_ecf9d1875d849bc2 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderPrivate(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7e33472f03e5a723_adcfc8d4e22973ef = external constant [0 x i8]
@olang_loc_d27f09f1ed434aae_8d18f82803f9a31a = external constant [0 x i8]
declare { i32, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eitemOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStructPatPositional(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadItem(ptr %v0, ptr %v1, ptr %a0, i1 %a1, %"compiler/source:Span" %a2, ptr %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatPositionAfterName(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWholeCaseNamed(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2enameIndex(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldReadable(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoItemField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldBothWays(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePatFieldTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H19842cc3f9f17801919cd111c108caa0(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7fe1bea66cf2144e_3863a3a9e6f6a662 = external constant [0 x i8]
@olang_loc_b79520aaecc0f88f_d487c78520878463 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Desc" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseDesc(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
@olang_loc_82b73da87554a50f_4f07d83e7e807a5b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealtTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_da99cffe6602dc08_7fa7c9f5ef49167c = external constant [0 x i8]
@olang_loc_ddff752a05460a27_f846f4bbf4f845eb = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4, ptr %a5)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeOrigin(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeInstNote(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorChecked(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eColumnsRow(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropOnExit(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i1 %a3)
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolledCompr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3, i32 %a4)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValueType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_cdb7af735b0e96fc_7d1f1dd52d37eb88 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eComprehensionReferences(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_e6a78b702db91f09_a31c62fb59cc1eed = external constant [0 x i8]
declare %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, i32 %a1, ptr %a2, i1 %a3, { i64, ptr } %a4, { i64, ptr } %a5, i1 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eComprNeedsTry(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayEnds(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i32 %a3, i1 %a4)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7f8223142f689eb4_f934e4a817092f38 = external constant [0 x i8]
@olang_loc_43d20343d6f566de_136f8b7be912828a = external constant [0 x i8]
@olang_loc_f558fce6a2b003e7_933c1b66dd113bdb = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_45d73a08c1eee64c_a811f88d32b1fa78 = external constant [0 x i8]
declare %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ekillAssigned(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:factsMark" %a1, { i64, ptr } %a2)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsRestored(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:factsCopy" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunendedArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_ebc2467d8a71e8b5_ca2d5a069c6cca29 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffP(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_d97e23b04dcff800_367dc3876d150fb4 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eeffectOp(i32 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ad4dc9fe288360e2_6bae22496d237a26 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_29ea0c7d0dcef6fa_322b22c08f06752e = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
@olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarIndex(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrSetArgUnwanted(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_c902484ee6860410_648a649019eab164 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e4324c4b30f6563f_ec149b7f01d5683b = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsArgOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2eLen_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %a0)
declare %"compiler/check:factRead" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2eAt_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2feffects_2eFact_2eNamed(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFactUndecided(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldOffset(ptr %v0, ptr %a0, %"compiler/generic:Desc" %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflUnder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePacked(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePackedBits(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBitOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_2ff0d7eb2fd53f26_264ec5bdf8203eea = external constant [0 x i8]
declare void @compiler_2fcheck_3ab5aWalk_2ector(ptr %out, ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eTruncate_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueImmutPart(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_fee5565d650674df_3b318d0e6ee4625b = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4bb92e4e6aa9fa92_ae49a41c9a1a92ee = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2fcheck_2eLaneCmp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2)
declare %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneMaskBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f29deef1411bcac7_1d318aa8f75ec9a3 = external constant [0 x i8]
@olang_loc_15db60dea160a9a8_613bb3b113b67e94 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOperandsDiffer(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2fcheck_2eLaneSel = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTotal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_89233ed815a81c43_385dc0f6d58c413f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a9a2c4034b6e08dd_84116590a5e4e601 = external constant [0 x i8]
declare i1 @compiler_2fnames_2eLoneCatchName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOverlap(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOverlap(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
@olang_loc_3bd31798abdf2684_ea9ddda83177a8c8 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erefWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMutOnValueType(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_7a28fcbf35f9c2ea_43c4b143baba89fe = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknownMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgUnknown(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
@olang_loc_bb9360f661a84828_a83eb458d7764d44 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsFixed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
@olang_loc_354044a632a7444d_aa07af71c262dc01 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %v0, i32 %a0, i1 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eapplyAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_25badba18653f983_c74616522228d697 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %a0)
@olang_loc_6168eeb228a64802_deceb7d8f3c3ddf6 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLenKey(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrPatternNeedsName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eLe_Hf8109b64a4e45220d0da36a987cf38b1(ptr %v0, ptr %a0)
declare %"compiler/check:payloadItem" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eAt_H64f851f610dd8566f1d7651b626ec99d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItemOk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, { i64, ptr } %a5, i64 %a6, ptr %a7, i64 %a8)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettle(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc78234e963d75e4843d79dfd3cff7b8f(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushErrNarrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushCases(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
@olang_loc_ec8a21dbb084e216_fbcda7bc6021fa9a = external constant [0 x i8]
declare %"compiler/check:rawTable" @compiler_2fcheck_3arawTable_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i1 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawEnum(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, ptr %a3, i1 %a4)
@olang_loc_89ab76664fe93b5c_2e5cefefce25c48 = external constant [0 x i8]
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRvBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eProject(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_492feac3979049da_7a1ccb679ec95f6e = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_42af232d2840e8db_efcef566740b002f = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroArg_3e_2ePush_3ccompiler_2fcheck_3aroArg_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roArg" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/pair:Pair.b139c4f75a6545712256427180a82a06" @std_2fpair_3aPair_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20std_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cstd_2fpair_3aPair__H9be680f663aa81558c844970355ca108(ptr %v0, ptr %a0, %"std/pair:Pair.b139c4f75a6545712256427180a82a06" %a1)
@olang_loc_3ba07a3e63e86523_b4e2f85113e27c0f = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1, i64 %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aroDeepArg_3e_2ePush_H0e30e0389c54f9bfc05db61d637e277e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roDeepArg" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b8e2733ff2674fd_52419f97eade6699 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_4fb1ec40319fc7d0_191a57ffdbf9a78c = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_5ec272a16da13ce8_6a23c064ecfaca54 = external constant [0 x i8]
@olang_loc_7151da8c7014d0c8_6aa5246f01d956ac = external constant [0 x i8]
@olang_loc_16d25af731eb828d_f9df92790de43871 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_acadf2af31b93e38_18751a402ed16b84 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estable(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/check:fieldSet" @compiler_2fcheck_3afieldSet_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2eisData(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameRepr(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:TopAssertAsk" @compiler_2fcheck_3aTopAssertAsk_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aTopAssertAsk_3e_2eP_H67072fc16e996275e069a499f28fddf9(ptr %v0, ptr %a0, %"compiler/check:TopAssertAsk" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetPlace(ptr %v0)
declare i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %a0)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetTarget(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetHasValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopSetTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_c6f64016a09fc530_b8b2abed7e41fd2c = external constant [0 x i8]
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i1 %a4, i1 %a5, i64 %a6, i64 %a7, ptr %a8)
@olang_loc_37fb0db160a44e56_e10956c528b68142 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopSetIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3, %"compiler/source:Span" %a4, i1 %a5)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementions(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundMention(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueErr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayLit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
@olang_loc_e10237a768a7da34_a1fa84f4f434b2e0 = external constant [0 x i8]
@olang_loc_a69c1b36a006a603_82104839c45e26c7 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_ddfcf2b97caa4282_7a2ed02469d97696 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoZeroNonNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullableArray(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
@olang_loc_39114b2b59f3c1de_f97787d703923df2 = external constant [0 x i8]
@olang_loc_bfa34a8929429713_51639094391671e7 = external constant [0 x i8]
@olang_loc_37a2617a6fdca52f_9113ce984ee2ba6b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_cffeba9c7beed71d_692ce8f7e2902011 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOfBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, { i64, ptr } %a4, i1 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseZero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9272b3113db2835a_2a2a8b0a39f9db7e = external constant [0 x i8]
@olang_loc_e85625530f05a4e1_e8094ee11349b825 = external constant [0 x i8]
@olang_loc_fd7989cc94cf1ac3_95016419ffbfbd17 = external constant [0 x i8]
@olang_loc_f62b02ebb614301c_75e9b5b90c5bfe48 = external constant [0 x i8]
@olang_loc_4777492a424db66f_87dc2d494f6ca16b = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_51cc068c3aeae8b4_3b6d62df8d15b2a8 = external constant [0 x i8]
@olang_loc_a6ce77febe1defe5_34385e948c177179 = external constant [0 x i8]
declare %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4)
@olang_loc_3bfa2fc53dda7240_53e39c3717a0962c = external constant [0 x i8]
@olang_loc_d195b38137e2d30_7d67c1d5e7f3802c = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b4de3dcccf9032b4_264e366d03c66670 = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
