; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/list:listState.9783095779ea18337775adeb6569839d" = type { { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, i64, i64, i64 }
define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eToArray_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"compiler/source:Span"
  %l39 = alloca i64
  %l42 = alloca i64
  %l62 = alloca { i64, ptr }
  %l76 = alloca i64
  %l79 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t44 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t6, i32 0, i32 7
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = icmp eq i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t15 = icmp sle i64 0, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f88bc59f8def7175_291a834f1a3a1ac9)
  unreachable
bb5:
  %t17 = mul i64 0, 8
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_f88bc59f8def7175_291a834f1a3a1ac9)
  unreachable
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 7
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l27, !tbaa !24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t26, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l29, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/source:Span", ptr %t31, i64 0
  %t33 = load %"compiler/source:Span", ptr %t32
  store %"compiler/source:Span" %t33, ptr %l30
  %t34 = load i64, ptr %l27, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = icmp sle i64 %t37, 1152921504606846975
  br i1 %t38, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1bf68c28770a2f08_2201243288b20e7c)
  unreachable
bb10:
  %t40 = load i64, ptr %l27, !tbaa !24
  %t41 = mul i64 %t40, 8
  %t42 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t41)
  %t43 = load %"compiler/source:Span", ptr %l30
  store i64 0, ptr %t44
  br label %fill.45
fill.45:
  %t48 = load i64, ptr %t44
  %t49 = icmp slt i64 %t48, %t40
  br i1 %t49, label %fillb.46, label %filld.47
fillb.46:
  %t50 = getelementptr %"compiler/source:Span", ptr %t42, i64 %t48
  store %"compiler/source:Span" %t43, ptr %t50
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %t44
  br label %fill.45
filld.47:
  %t52 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t42, 1
  store { i64, ptr } %t53, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t55, i32 0, i32 2
  %t58 = load i64, ptr %t57, !tbaa !24
  store i64 %t58, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1bf68c28770a2f08_2201243288b20e7c)
  unreachable
bb12:
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb17
bb14:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l42, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb16
bb16:
  %t86 = load i64, ptr %l42, !tbaa !24
  store i64 %t86, ptr %l39, !tbaa !24
  br label %bb17
bb17:
  %t87 = load i64, ptr %l39, !tbaa !24
  store i64 %t87, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb20:
  br label %bb21
bb21:
  %t96 = load i64, ptr %l4, !tbaa !24
  %t97 = load i64, ptr %l8, !tbaa !24
  %t98 = load i64, ptr %l6, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l9, !tbaa !24
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t107 = load i64, ptr %l9, !tbaa !24
  %t110 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t106, i64 %t107)
  store { i64, ptr } %t110, ptr %l62
  br label %bb22
bb22:
  %t111 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t111, ptr %l10, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l11, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t117, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = sub i64 %t120, 1
  %t125 = icmp eq i64 %t116, %t122
  br i1 %t125, label %bb23, label %bb24
bb23:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t127, i32 0, i32 5
  %t130 = load i64, ptr %t129, !tbaa !24
  store i64 %t130, ptr %l11, !tbaa !24
  br label %bb25
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l12, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  store i64 %t132, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb26, label %bb27
bb26:
  %t140 = load i64, ptr %l14, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb31
bb28:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l14, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l79, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb30
bb30:
  %t160 = load i64, ptr %l79, !tbaa !24
  store i64 %t160, ptr %l76, !tbaa !24
  br label %bb31
bb31:
  %t161 = load i64, ptr %l76, !tbaa !24
  store i64 %t161, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t162 = load i64, ptr %l16, !tbaa !24
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l17, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t180, ptr %l97, !tbaa !27
  %t181 = load i64, ptr %l3, !tbaa !24
  %t182 = load i64, ptr %l17, !tbaa !24
  %t185 = add i64 %t181, %t182
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t186, ptr %l101, !tbaa !27
  %t187 = load i64, ptr %l17, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr %"compiler/source:Span", ptr %t190, i64 %t187
  %t192 = load %"compiler/source:Span", ptr %t191
  %t195 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr %"compiler/source:Span", ptr %t196, i64 %t185
  store %"compiler/source:Span" %t192, ptr %t197
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  %t198 = load i64, ptr %l16, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l16, !tbaa !24
  br label %bb32
bb37:
  %t202 = load i64, ptr %l3, !tbaa !24
  %t203 = load i64, ptr %l11, !tbaa !24
  %t206 = add i64 %t202, %t203
  store i64 %t206, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb38:
  %t208 = load i64, ptr %l8, !tbaa !24
  %t210 = add i64 %t208, 1
  store i64 %t210, ptr %l8, !tbaa !24
  br label %bb18
bb39:
  %t212 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l5 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l0, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@olang_loc_f88bc59f8def7175_291a834f1a3a1ac9 = external constant [0 x i8]
@olang_loc_1bf68c28770a2f08_2201243288b20e7c = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
