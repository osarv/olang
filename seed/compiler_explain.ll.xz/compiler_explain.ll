; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Table" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
@G_2ecompiler_2fexplain_2eLongValue = constant <{ [8 x i8] }> <{ [8 x i8] c"\90\01\00\00\00\00\00\00" }>, align 8
define dso_local i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l9 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l24 = alloca i32
  %l31 = alloca i32
  %l36 = alloca i32
  %l45 = alloca i32
  %l50 = alloca i32
  %l54 = alloca i1
  %l58 = alloca i1
  %l66 = alloca i64
  %l70 = alloca i64
  %l72 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 -1, ptr %l2, !tbaa !23
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t10, i64 %t11)
  store i32 %t14, ptr %l13
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t15, i32 %t16)
  store { i64, ptr } %t17, ptr %l14
  br label %bb2
bb2:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp ne i64 %t21, 1
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t25, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t27 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 0
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l4, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l4, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb6
bb6:
  %t42 = load i32, ptr %l24
  %t44 = trunc i64 20 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l4, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l31
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t57 = load i32, ptr %l31, !tbaa !23
  store i32 %t57, ptr %l4, !tbaa !23
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l36
  br label %bb11
bb11:
  %t68 = load i32, ptr %l36
  %t70 = trunc i64 18 to i32
  %t71 = icmp eq i32 %t68, %t70
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb12, label %bb13
bb12:
  %t75 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t75, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l45
  br label %bb15
bb15:
  %t87 = load i32, ptr %l45, !tbaa !23
  store i32 %t87, ptr %l5, !tbaa !23
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l5, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l50
  br label %bb16
bb16:
  %t98 = load i32, ptr %l50
  store i32 %t98, ptr %l6
  %t99 = load i32, ptr %l6
  %t101 = trunc i64 0 to i32
  %t102 = icmp eq i32 %t99, %t101
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb17, label %bb18
bb17:
  %t106 = load i32, ptr %l6
  %t108 = trunc i64 1 to i32
  %t109 = icmp eq i32 %t106, %t108
  %t111 = xor i1 %t109, true
  store i1 %t111, ptr %l54, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb19
bb19:
  %t113 = load i1, ptr %l54, !tbaa !21
  br i1 %t113, label %bb20, label %bb21
bb20:
  %t114 = load i32, ptr %l6
  %t116 = trunc i64 4 to i32
  %t117 = icmp eq i32 %t114, %t116
  %t119 = xor i1 %t117, true
  store i1 %t119, ptr %l58, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t121 = load i1, ptr %l58, !tbaa !21
  br i1 %t121, label %bb23, label %bb24
bb23:
  %t122 = load i32, ptr %l2, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t122, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t128 = load i32, ptr %l5, !tbaa !23
  %t131 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t127, i32 %t128)
  store i64 %t131, ptr %l66
  br label %bb26
bb26:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t136 = load i64, ptr %l1, !tbaa !24
  %t139 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t135, i64 %t136)
  store i64 %t139, ptr %l70
  br label %bb27
bb27:
  %t140 = load i64, ptr %l66, !tbaa !24
  %t141 = load i64, ptr %l70, !tbaa !24
  %t142 = icmp eq i64 %t140, %t141
  br i1 %t142, label %bb28, label %bb29
bb28:
  %t144 = load i32, ptr %l5, !tbaa !23
  store i32 %t144, ptr %l72, !tbaa !23
  br label %bb30
bb29:
  %t146 = load i32, ptr %l2, !tbaa !23
  store i32 %t146, ptr %l72, !tbaa !23
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t148 = load i32, ptr %l72, !tbaa !23
  store i32 %t148, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fexplain_2eBuilders(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l64 = alloca %"compiler/names:Entry"
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i32
  %l88 = alloca { i64, ptr }
  %l94 = alloca %"compiler/names:Entry"
  %l100 = alloca i64
  %l103 = alloca i1
  %l107 = alloca ptr
  %l112 = alloca i1
  %l116 = alloca i1
  %l122 = alloca { i64, ptr }
  %l126 = alloca i1
  %l130 = alloca i1
  %l132 = alloca i1
  %l136 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %t105 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l22
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t8, i32 %t9)
  store i64 %t12, ptr %l26
  br label %bb2
bb2:
  %t13 = load i64, ptr %l26, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/names:Resolver", ptr %t20, i32 0, i32 1
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t22, i64 %t23)
  store ptr %t26, ptr %l32
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l32, !tbaa !29
  store ptr %t27, ptr %l5, !tbaa !29
  %t28 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l33
  br label %bb4
bb4:
  %t29 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/names:Table", ptr %t30, i32 0, i32 0
  %t34 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l36
  br label %bb5
bb5:
  %t35 = load i64, ptr %l36, !tbaa !24
  store i64 %t35, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load i64, ptr %l9, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb11
bb8:
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l9, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l43, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb10
bb10:
  %t62 = load i64, ptr %l43, !tbaa !24
  store i64 %t62, ptr %l40, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l40, !tbaa !24
  store i64 %t63, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t64 = load i64, ptr %l11, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb14:
  br label %bb15
bb15:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l12, !tbaa !24
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/names:Table", ptr %t82, i32 0, i32 0
  %t85 = load i64, ptr %l12, !tbaa !24
  %t88 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s2, ptr %t84, i64 %t85)
  store %"compiler/names:Entry" %t88, ptr %l64
  br label %bb16
bb16:
  %t89 = getelementptr %"compiler/names:Entry", ptr %l64, i32 0, i32 2
  %t90 = load i32, ptr %t89
  %t92 = trunc i64 3 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb17, label %bb18
bb17:
  %t95 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t95)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t98 = load i64, ptr %l11, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l11, !tbaa !24
  br label %bb12
bb22:
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t103 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t104 = ptrtoint ptr %t103 to i64
  %t106 = getelementptr { ptr, ptr }, ptr %t105, i32 0, i32 0
  store ptr %t102, ptr %t106, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t108 = getelementptr { ptr, ptr }, ptr %t105, i32 0, i32 1
  store ptr %v0, ptr %t108, !tbaa !28
  %t109 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t110 = insertvalue { ptr, ptr } %t109, ptr %t105, 1
  %t113 = extractvalue { ptr, ptr } %t110, 0
  %t114 = extractvalue { ptr, ptr } %t110, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %l6, ptr %t113, ptr %t114)
  br label %bb23
bb23:
  store ptr %l6, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = load ptr, ptr %l13, !tbaa !29
  %t117 = load i64, ptr %l14, !tbaa !24
  %t120 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t116, i64 %t117)
  %t121 = extractvalue { i32, { i64, ptr } } %t120, 1
  %t122 = extractvalue { i32, { i64, ptr } } %t120, 0
  store i32 %t122, ptr %l79
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb26, label %ok.124
ok.124:
  store { i64, ptr } %t121, ptr %l78
  br label %bb25
bb25:
  %t125 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t125, ptr %l75, !tbaa !27
  br label %bb30
bb26:
  %t126 = load i32, ptr %l79, !tbaa !23
  %t127 = ashr i32 %t126, 16
  %t129 = icmp eq i32 %t127, 1
  br i1 %t129, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_10922f4f875ba124_bbdc792b6e6bf8a8)
  unreachable
bb29:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb67
bb30:
  %t131 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t131, ptr %l15, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  store i64 %t134, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t136 = load i64, ptr %l17, !tbaa !24
  %t137 = load i64, ptr %l16, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb33:
  br label %bb34
bb34:
  %t144 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t144, ptr %l88, !tbaa !27
  %t145 = load i64, ptr %l17, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i64, ptr %t148, i64 %t145
  %t150 = load i64, ptr %t149, !tbaa !34
  %t152 = load ptr, ptr %l5, !tbaa !29
  %t154 = getelementptr %"compiler/names:Table", ptr %t152, i32 0, i32 0
  %t158 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s7, ptr %t154, i64 %t150)
  store %"compiler/names:Entry" %t158, ptr %l94
  br label %bb35
bb35:
  %t159 = getelementptr %"compiler/names:Entry", ptr %l94, i32 0, i32 0
  %t160 = load i32, ptr %t159, !tbaa !23
  store i32 %t160, ptr %l19, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t166 = load i64, ptr %l4, !tbaa !24
  %t167 = load i32, ptr %l19, !tbaa !23
  %t171 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t165, i64 %t166, i32 %t167)
  store i64 %t171, ptr %l100
  br label %bb36
bb36:
  %t172 = load i64, ptr %l100, !tbaa !24
  store i64 %t172, ptr %l20, !tbaa !24
  %t173 = load i64, ptr %l20, !tbaa !24
  %t175 = icmp slt i64 %t173, 0
  br i1 %t175, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb40
bb38:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t181 = load i64, ptr %l20, !tbaa !24
  %t184 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t180, i64 %t181)
  store ptr %t184, ptr %l107
  br label %bb39
bb39:
  %t185 = load ptr, ptr %l107, !tbaa !29
  %t187 = getelementptr %"compiler/ast:Func", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = icmp eq ptr %t188, null
  %t192 = xor i1 %t190, true
  store i1 %t192, ptr %l103, !tbaa !21
  br label %bb40
bb40:
  %t194 = load i1, ptr %l103, !tbaa !21
  br i1 %t194, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb44
bb42:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t199 = load i64, ptr %l20, !tbaa !24
  %t202 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t198, i64 %t199)
  store i1 %t202, ptr %l116
  br label %bb43
bb43:
  %t203 = load i1, ptr %l116, !tbaa !21
  store i1 %t203, ptr %l112, !tbaa !21
  br label %bb44
bb44:
  %t204 = load i1, ptr %l112, !tbaa !21
  br i1 %t204, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb46:
  br label %bb47
bb47:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 0
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/load:Loader", ptr %t211, i32 0, i32 3
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = load i32, ptr %l19, !tbaa !23
  %t218 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t214, i32 %t215)
  store { i64, ptr } %t218, ptr %l122
  br label %bb48
bb48:
  %t219 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t221)
  call void @olang_textcopy(ptr %t222, ptr %t220, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l21, !tbaa !27
  %t228 = xor i1 %a2, true
  br i1 %t228, label %bb49, label %bb50
bb49:
  %t230 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t234 = icmp sgt i64 %t232, 0
  br i1 %t234, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb55
bb51:
  %t236 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr i8, ptr %t237, i64 0
  %t239 = load i8, ptr %t238, !tbaa !32
  %t241 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t239)
  store i1 %t241, ptr %l132
  br label %bb53
bb52:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb54
bb53:
  %t242 = load i1, ptr %l132, !tbaa !21
  store i1 %t242, ptr %l130, !tbaa !21
  br label %bb54
bb54:
  %t243 = load i1, ptr %l130, !tbaa !21
  %t244 = xor i1 %t243, true
  store i1 %t244, ptr %l126, !tbaa !21
  br label %bb55
bb55:
  %t246 = load i1, ptr %l126, !tbaa !21
  br i1 %t246, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb57:
  br label %bb58
bb58:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i64, ptr %l20, !tbaa !24
  %t251 = call i32 @compiler_2fexplain_2eBuilderOf(ptr %v0, ptr %t247, i64 %t248)
  store i32 %t251, ptr %l136
  br label %bb59
bb59:
  %t252 = load i32, ptr %l1, !tbaa !23
  %t253 = load i32, ptr %l136, !tbaa !23
  %t255 = icmp eq i32 %t253, %t252
  br i1 %t255, label %bb60, label %bb61
bb60:
  %t257 = load ptr, ptr %lp3
  %t258 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t257, i64 %t258)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb64:
  %t261 = load i64, ptr %l17, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l17, !tbaa !24
  br label %bb31
bb65:
  %t265 = load i64, ptr %l14, !tbaa !24
  %t266 = load i64, ptr %l16, !tbaa !24
  %t269 = add i64 %t265, %t266
  store i64 %t269, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb66:
  br label %bb24
bb67:
  %t271 = load ptr, ptr %lp3
  %t272 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t271
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t272, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eFnLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l18 = alloca i32
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i64
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t5)
  store i64 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t8, i64 %t9)
  store i64 %t10, ptr %l7
  br label %bb2
bb2:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t17, i64 %t18, i32 0)
  store i64 %t21, ptr %l12
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i64, ptr %l12, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l14, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l18
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t33, i64 %t34)
  store i64 %t37, ptr %l21
  br label %bb7
bb7:
  %t38 = load ptr, ptr %l13, !tbaa !29
  %t39 = load i64, ptr %l14, !tbaa !24
  %t40 = load i32, ptr %l18, !tbaa !23
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %t38, i64 %t39, i32 %t40, i64 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l23, !tbaa !29
  %t45 = load i64, ptr %l1, !tbaa !24
  store i64 %t45, ptr %l24, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t49, i64 %t50)
  store i32 %t53, ptr %l28
  br label %bb10
bb10:
  %t54 = load ptr, ptr %l23, !tbaa !29
  %t55 = load i64, ptr %l24, !tbaa !24
  %t56 = load i32, ptr %l28, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %t54, i64 %t55, i32 %t56, i64 -1)
  store { i64, ptr } %t57, ptr %l29
  br label %bb11
bb11:
  %t58 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
  store { i64, ptr } %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/names:Entry"
  %l16 = alloca i64
  %l17 = alloca i32
  %l24 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l39 = alloca i32
  %l44 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l61 = alloca i32
  %l62 = alloca i64
  %l69 = alloca { i64, ptr }
  %l72 = alloca i32
  %l78 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i32
  %l95 = alloca { i64, ptr }
  %l107 = alloca i64
  %l113 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l129 = alloca i32
  %l134 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %t1, i64 %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 3
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l5, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v3, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l27
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb3, label %ok.22
ok.22:
  store i64 %t19, ptr %l26
  br label %bb2
bb2:
  %t23 = load i64, ptr %l26, !tbaa !24
  store i64 %t23, ptr %l24, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb5
bb5:
  %t24 = load i64, ptr %l24, !tbaa !24
  store i64 %t24, ptr %l6, !tbaa !24
  %t25 = load i64, ptr %l6, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l30, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l31, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %l32, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  store i64 %t32, ptr %l33, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l34, !tbaa !24
  %t35 = icmp sge i64 0, 0
  br i1 %t35, label %bb8, label %bb9
bb7:
  br label %bb31
bb8:
  %t37 = load i64, ptr %l33, !tbaa !24
  %t38 = icmp sle i64 0, %t37
  br i1 %t38, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb10:
  %t40 = load i64, ptr %l33, !tbaa !24
  %t41 = load i64, ptr %l34, !tbaa !24
  %t42 = icmp sle i64 %t40, %t41
  br i1 %t42, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb12:
  %t44 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l33, !tbaa !24
  %t47 = getelementptr i8, ptr %t45, i64 0
  %t48 = sub i64 %t46, 0
  %t49 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = load i64, ptr %l31, !tbaa !24
  %t54 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t51, i64 %t52, { i64, ptr } %t50)
  store i32 %t54, ptr %l39
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_35c12625cc2f75ee_5b08f4318e637d4a)
  unreachable
bb14:
  %t55 = load i32, ptr %l39, !tbaa !23
  store i32 %t55, ptr %l7, !tbaa !23
  %t56 = load i32, ptr %l7, !tbaa !23
  %t58 = icmp slt i32 %t56, 0
  br i1 %t58, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t61 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t61, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l44, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load i32, ptr %l7, !tbaa !23
  %t73 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l48
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l5, !tbaa !29
  store ptr %t74, ptr %l49, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t75, ptr %l50, !tbaa !27
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l52, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t79, 0
  store i64 %t82, ptr %l55, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l56, !tbaa !24
  %t85 = load i64, ptr %l52, !tbaa !24
  %t86 = icmp sge i64 %t85, 0
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t88 = load i64, ptr %l52, !tbaa !24
  %t89 = load i64, ptr %l55, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb21:
  %t92 = load i64, ptr %l55, !tbaa !24
  %t93 = load i64, ptr %l56, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb23:
  %t96 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l52, !tbaa !24
  %t99 = load i64, ptr %l55, !tbaa !24
  %t100 = getelementptr i8, ptr %t97, i64 %t98
  %t101 = sub i64 %t99, %t98
  %t102 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  %t104 = load ptr, ptr %l49, !tbaa !29
  %t106 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v3, ptr %t104, { i64, ptr } %t103)
  store i32 %t106, ptr %l61
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027)
  unreachable
bb25:
  %t107 = load ptr, ptr %l44, !tbaa !29
  %t108 = load i32, ptr %l48, !tbaa !23
  %t109 = load i32, ptr %l61, !tbaa !23
  %t110 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t107, i32 %t108, i32 %t109)
  store i64 %t110, ptr %l62
  br label %bb26
bb26:
  %t111 = load i64, ptr %l62, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  %t112 = load i64, ptr %l8, !tbaa !24
  %t114 = icmp slt i64 %t112, 0
  br i1 %t114, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t117 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t117, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t120 = load i64, ptr %l8, !tbaa !24
  %t124 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t118, ptr %t119, i64 %t120)
  store { i64, ptr } %t124, ptr %l69
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t125 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t126 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t125, 1
  store { i32, { i64, ptr } } %t126, ptr %rv
  br label %ret
bb31:
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t131 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v3, ptr %t127, { i64, ptr } %t128)
  store i32 %t131, ptr %l72
  br label %bb32
bb32:
  %t132 = load i32, ptr %l72, !tbaa !23
  store i32 %t132, ptr %l9, !tbaa !23
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/names:Resolver", ptr %t139, i32 0, i32 1
  %t142 = load i64, ptr %l3, !tbaa !24
  %t145 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t141, i64 %t142)
  store ptr %t145, ptr %l78
  br label %bb33
bb33:
  %t146 = load ptr, ptr %l78, !tbaa !29
  %t148 = getelementptr %"compiler/names:Table", ptr %t146, i32 0, i32 0
  store ptr %t148, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t150 = load ptr, ptr %l10, !tbaa !29
  %t151 = load i64, ptr %l11, !tbaa !24
  %t154 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t150, i64 %t151)
  %t155 = extractvalue { i32, { i64, ptr } } %t154, 1
  %t156 = extractvalue { i32, { i64, ptr } } %t154, 0
  store i32 %t156, ptr %l85
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb36, label %ok.158
ok.158:
  store { i64, ptr } %t155, ptr %l84
  br label %bb35
bb35:
  %t159 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t159, ptr %l81, !tbaa !27
  br label %bb40
bb36:
  %t160 = load i32, ptr %l85, !tbaa !23
  %t161 = ashr i32 %t160, 16
  %t163 = icmp eq i32 %t161, 1
  br i1 %t163, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  %t165 = load i32, ptr %l85, !tbaa !23
  %t166 = lshr i32 %t165, 16
  %t167 = and i32 %t165, 65535
  %t168 = icmp eq i32 %t166, 1
  %t169 = select i1 %t168, i32 0, i32 0
  %t170 = icmp eq i32 %t165, 0
  %t171 = shl i32 %t169, 16
  %t172 = or i32 %t171, %t167
  %t173 = select i1 %t170, i32 0, i32 %t172
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t175 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t173, 0
  store { i32, { i64, ptr } } %t175, ptr %rv
  br label %ret
bb39:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb63
bb40:
  %t176 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t176, ptr %l12, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  store i64 %t179, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t181 = load i64, ptr %l14, !tbaa !24
  %t182 = load i64, ptr %l13, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb61
bb43:
  br label %bb44
bb44:
  %t189 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t189, ptr %l95, !tbaa !27
  %t190 = load i64, ptr %l14, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr %"compiler/names:Entry", ptr %t193, i64 %t190
  %t195 = load %"compiler/names:Entry", ptr %t194
  store %"compiler/names:Entry" %t195, ptr %l15
  %t197 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 0
  %t198 = load i32, ptr %t197, !tbaa !23
  %t199 = load i32, ptr %l9, !tbaa !23
  %t202 = icmp ne i32 %t198, %t199
  br i1 %t202, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb46:
  br label %bb47
bb47:
  %t204 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 2
  %t205 = load i32, ptr %t204
  %t207 = trunc i64 3 to i32
  %t208 = icmp eq i32 %t205, %t207
  br i1 %t208, label %bb48, label %bb49
bb48:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t214 = load i64, ptr %l3, !tbaa !24
  %t215 = load i32, ptr %l9, !tbaa !23
  %t219 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t213, i64 %t214, i32 %t215)
  store i64 %t219, ptr %l107
  br label %bb50
bb49:
  br label %bb55
bb50:
  %t220 = load i64, ptr %l107, !tbaa !24
  store i64 %t220, ptr %l16, !tbaa !24
  %t221 = load i64, ptr %l16, !tbaa !24
  %t223 = icmp sge i64 %t221, 0
  br i1 %t223, label %bb51, label %bb52
bb51:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l1, !tbaa !29
  %t227 = load i64, ptr %l16, !tbaa !24
  %t231 = call { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v4, ptr %t225, ptr %t226, i64 %t227)
  store { i64, ptr } %t231, ptr %l113
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t232 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t233 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t232, 1
  store { i32, { i64, ptr } } %t233, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t234 = getelementptr %"compiler/names:Entry", ptr %l15, i32 0, i32 2
  %t235 = load i32, ptr %t234
  %t237 = trunc i64 2 to i32
  %t238 = icmp eq i32 %t235, %t237
  br i1 %t238, label %bb56, label %bb57
bb56:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i64, ptr %l3, !tbaa !24
  %t243 = load %"compiler/names:Entry", ptr %l15
  %t248 = call { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v2, ptr %v0, ptr %v4, ptr %t240, ptr %a2, i64 %t242, %"compiler/names:Entry" %t243)
  store { i64, ptr } %t248, ptr %l120
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t249 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t250 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t249, 1
  store { i32, { i64, ptr } } %t250, ptr %rv
  br label %ret
bb59:
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb60:
  %t251 = load i64, ptr %l14, !tbaa !24
  %t253 = add i64 %t251, 1
  store i64 %t253, ptr %l14, !tbaa !24
  br label %bb41
bb61:
  %t255 = load i64, ptr %l11, !tbaa !24
  %t256 = load i64, ptr %l13, !tbaa !24
  %t259 = add i64 %t255, %t256
  store i64 %t259, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb62:
  br label %bb34
bb63:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i64, ptr %l3, !tbaa !24
  %t263 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t267 = call i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v3, ptr %t261, i64 %t262, { i64, ptr } %t263)
  store i32 %t267, ptr %l129
  br label %bb64
bb64:
  %t268 = load i32, ptr %l129, !tbaa !23
  store i32 %t268, ptr %l17, !tbaa !23
  %t269 = load i32, ptr %l17, !tbaa !23
  %t271 = icmp sge i32 %t269, 0
  br i1 %t271, label %bb65, label %bb66
bb65:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i32, ptr %l17, !tbaa !23
  %t277 = call { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v4, ptr %t273, i32 %t274)
  store { i64, ptr } %t277, ptr %l134
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t278 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t279 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t278, 1
  store { i32, { i64, ptr } } %t279, ptr %rv
  br label %ret
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t281 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t281, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fexplain_2eLongValue_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 400, ptr @G_2ecompiler_2fexplain_2eLongValue, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fexplain_2ebuilders(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l26 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l32 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fexplain_2eBuilders(ptr %v1, ptr %s1, ptr %t1, i32 %a2, i1 false)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t7 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %t7
  store ptr %t7, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s1, ptr %t9, i64 %t10)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l17
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb4, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l16
  br label %bb3
bb3:
  %t18 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  br label %bb8
bb4:
  %t19 = load i32, ptr %l17, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d02d672b10a10044_edb2f07898a0d008)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb8:
  %t24 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t37, ptr %l26, !tbaa !27
  %t38 = load i64, ptr %l7, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i64, ptr %t41, i64 %t38
  %t43 = load i64, ptr %t42, !tbaa !34
  store ptr %a0, ptr %l29, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t50 = call { i64, ptr } @compiler_2fexplain_2eFnLine(ptr %v1, ptr %s3, ptr %t46, i64 %t43)
  store { i64, ptr } %t50, ptr %l32
  br label %bb13
bb13:
  %t51 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t53 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = getelementptr i8, ptr %t61, i64 %t55
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t60, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = extractvalue { i64, ptr } %t64, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t72 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t72, { i64, ptr } %t71)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t74 = load i64, ptr %l7, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l7, !tbaa !24
  br label %bb9
bb16:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t78, %t79
  store i64 %t82, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb2
bb18:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t32 = icmp sge i64 0, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = icmp sle i64 0, 1152921504606846975
  br i1 %t34, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb12:
  %t36 = mul i64 0, 8
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 0, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_430839a36fc86f5_d60a2ea9e5c9a99)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fexplain_2ecaseWhole(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { { i64, ptr }, ptr }, ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %a1
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = getelementptr %"compiler/ast:CaseDecl", ptr %t27, i32 0, i32 3
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5177bd7d484351dd_5d0dbb04dc509331)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fexplain_2econtract(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l25 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca %"compiler/source:Span"
  %l55 = alloca i64
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca i64
  %l60 = alloca i64
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Sig", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 82, ptr getelementptr inbounds (<{ i64, [82 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t13)
  call void @olang_textcopy(ptr %t14, ptr %t9, i64 %t10)
  %t15 = getelementptr i8, ptr %t14, i64 %t10
  call void @olang_textcopy(ptr %t15, ptr %t11, i64 %t12)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t14, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t6, { i64, ptr } %t24)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Sig", ptr %t27, i32 0, i32 5
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t36 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/load:Loader", ptr %t40, i32 0, i32 5
  %t46 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v1, ptr %v1, ptr %t42, i64 %a3)
  store ptr %t46, ptr %l25
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t49 = getelementptr %"compiler/load:Module", ptr %t47, i32 0, i32 6
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l5, !tbaa !29
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  br i1 %t54, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_e7ca39a48e286d3f_b849249cb4ab4933)
  unreachable
bb10:
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/source:Source", ptr %t56, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l6, !tbaa !27
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Sig", ptr %t62, i32 0, i32 5
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_ec0929e0cef23b20_10aa079683981964)
  unreachable
bb13:
  br label %bb14
bb14:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Sig", ptr %t69, i32 0, i32 5
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t75 = getelementptr %"compiler/ast:ContractBlock", ptr %t72, i32 0, i32 1
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t82 = load i64, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb17:
  br label %bb18
bb18:
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l46, !tbaa !27
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr ptr, ptr %t94, i64 %t91
  %t96 = load ptr, ptr %t95, !tbaa !39
  store ptr %t96, ptr %l10, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l49, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t99, ptr %l50, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t100, ptr %l51, !tbaa !27
  %t101 = load ptr, ptr %l10, !tbaa !29
  %t103 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v2, ptr %t101)
  store %"compiler/source:Span" %t103, ptr %l53
  br label %bb19
bb19:
  %t104 = getelementptr %"compiler/source:Span", ptr %l53, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = sext i32 %t105 to i64
  store i64 %t107, ptr %l55, !tbaa !24
  %t108 = load ptr, ptr %l10, !tbaa !29
  %t110 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v2, ptr %t108)
  store %"compiler/source:Span" %t110, ptr %l57
  br label %bb20
bb20:
  %t111 = getelementptr %"compiler/source:Span", ptr %l57, i32 0, i32 1
  %t112 = load i32, ptr %t111, !tbaa !23
  %t114 = sext i32 %t112 to i64
  store i64 %t114, ptr %l59, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l60, !tbaa !24
  %t117 = load i64, ptr %l55, !tbaa !24
  %t118 = icmp sge i64 %t117, 0
  br i1 %t118, label %bb21, label %bb22
bb21:
  %t120 = load i64, ptr %l55, !tbaa !24
  %t121 = load i64, ptr %l59, !tbaa !24
  %t122 = icmp sle i64 %t120, %t121
  br i1 %t122, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb23:
  %t124 = load i64, ptr %l59, !tbaa !24
  %t125 = load i64, ptr %l60, !tbaa !24
  %t126 = icmp sle i64 %t124, %t125
  br i1 %t126, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb25:
  %t128 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l55, !tbaa !24
  %t131 = load i64, ptr %l59, !tbaa !24
  %t132 = getelementptr i8, ptr %t129, i64 %t130
  %t133 = sub i64 %t131, %t130
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  %t136 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t143 = extractvalue { i64, ptr } %t135, 1
  %t144 = extractvalue { i64, ptr } %t135, 0
  %t145 = add i64 %t141, %t144
  %t146 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t137, i64 %t138)
  %t150 = getelementptr i8, ptr %t149, i64 %t138
  call void @olang_textcopy(ptr %t150, ptr %t139, i64 %t140)
  %t151 = getelementptr i8, ptr %t150, i64 %t140
  call void @olang_textcopy(ptr %t151, ptr %t143, i64 %t144)
  %t152 = getelementptr i8, ptr %t151, i64 %t144
  call void @olang_textcopy(ptr %t152, ptr %t146, i64 %t147)
  %t153 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t149, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = extractvalue { i64, ptr } %t154, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  %t162 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t162, { i64, ptr } %t161)
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t164 = load i64, ptr %l8, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l8, !tbaa !24
  br label %bb15
bb29:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a0, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [6 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:StructBody", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = icmp sle i64 0, 1152921504606846975
  br i1 %t28, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb12:
  %t30 = mul i64 0, 8
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 0, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_6448edf003c535f3_ebaded49d6e07c97)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_979fe2e14fb6de05_5947910940c194f1)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l56, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = sub i64 %t96, 1
  store i64 %t98, ptr %l1, !tbaa !24
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = icmp eq i8 %t104, 63
  store i1 %t106, ptr %l63, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb34
bb34:
  %t108 = load i1, ptr %l63, !tbaa !21
  br i1 %t108, label %bb35, label %bb36
bb35:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t111 = icmp sgt i64 %t109, 0
  store i1 %t111, ptr %l66, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb37
bb37:
  %t113 = load i1, ptr %l66, !tbaa !21
  br i1 %t113, label %bb38, label %bb39
bb38:
  %t114 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t114, ptr %l70, !tbaa !27
  %t115 = load i64, ptr %l7, !tbaa !24
  %t117 = sub i64 %t115, 1
  %t119 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr i8, ptr %t120, i64 %t117
  %t122 = load i8, ptr %t121, !tbaa !32
  %t124 = icmp eq i8 %t122, 32
  store i1 %t124, ptr %l69, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb40
bb40:
  %t126 = load i1, ptr %l69, !tbaa !21
  br i1 %t126, label %bb41, label %bb42
bb41:
  %t127 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t127, ptr %l75, !tbaa !27
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = sub i64 %t128, 1
  store i64 %t130, ptr %l77, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t131, 0
  store i64 %t134, ptr %l80, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l81, !tbaa !24
  %t137 = load i64, ptr %l77, !tbaa !24
  %t138 = icmp sge i64 %t137, 0
  br i1 %t138, label %bb43, label %bb44
bb42:
  br label %bb49
bb43:
  %t140 = load i64, ptr %l77, !tbaa !24
  %t141 = load i64, ptr %l80, !tbaa !24
  %t142 = icmp sle i64 %t140, %t141
  br i1 %t142, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb45:
  %t144 = load i64, ptr %l80, !tbaa !24
  %t145 = load i64, ptr %l81, !tbaa !24
  %t146 = icmp sle i64 %t144, %t145
  br i1 %t146, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb47:
  %t148 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = load i64, ptr %l77, !tbaa !24
  %t151 = load i64, ptr %l80, !tbaa !24
  %t152 = getelementptr i8, ptr %t149, i64 %t150
  %t153 = sub i64 %t151, %t150
  %t154 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t152, 1
  store { i64, ptr } %t155, ptr %l86, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  store i64 %t158, ptr %l87, !tbaa !24
  %t159 = load i64, ptr %l87, !tbaa !24
  %t160 = mul i64 %t159, 1
  %t161 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t160)
  %t162 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, ptr } %t163, ptr %l88, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = load i64, ptr %l87, !tbaa !24
  %t169 = mul i64 %t168, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t165, ptr %t167, i64 %t169, i1 false)
  %t170 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t170, ptr %l86, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  %t171 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t171, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_8f9ce818ff296c0e_932c83e6c6076d82)
  unreachable
bb49:
  call void @__olang_scope_close(ptr %s2)
  br label %bb50
bb50:
  %t172 = load i64, ptr %l6, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l6, !tbaa !24
  br label %bb7
bb51:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l91, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t176, ptr %l92, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  store i64 %t178, ptr %l93, !tbaa !24
  %t179 = load i64, ptr %l93, !tbaa !24
  %t180 = mul i64 %t179, 1
  %t181 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t180)
  %t182 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  store { i64, ptr } %t183, ptr %l94, !tbaa !27
  %t184 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = load i64, ptr %l93, !tbaa !24
  %t189 = mul i64 %t188, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t185, ptr %t187, i64 %t189, i1 false)
  %t190 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t190, ptr %l92, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t191, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2efields(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/typed:Local"
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l39 = alloca { i64, ptr }
  %l52 = alloca i32
  %l56 = alloca i1
  %l61 = alloca i32
  %l66 = alloca i32
  %l68 = alloca i1
  %l73 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l85 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i64
  %l92 = alloca ptr
  %l102 = alloca i64
  %l106 = alloca i64
  %l109 = alloca i64
  %l128 = alloca ptr
  %l132 = alloca i32
  %l134 = alloca %"compiler/typed:Local"
  %l139 = alloca i32
  %l140 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l149 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l162 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l164 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 11
  store ptr %t3, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l30
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l29
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t14, ptr %l26, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l30, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_d16c6b36ae6c900f_110b33433d32ce53)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb7:
  %t20 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb72
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l39, !tbaa !27
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  store ptr %t39, ptr %l8, !tbaa !29
  %t41 = load ptr, ptr %l8, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 1
  %t44 = load { i64, [2 x i64] }, ptr %t43
  store { i64, [2 x i64] } %t44, ptr %l9
  %t46 = load { i64, [2 x i64] }, ptr %l9
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l10, !tbaa !23
  %t55 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t56 = getelementptr { i32, i32 }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l11, !tbaa !23
  br label %bb14
bb13:
  br label %bb65
bb14:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l10, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l52
  br label %bb15
bb15:
  %t69 = load i32, ptr %l52
  %t71 = trunc i64 18 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb20
bb17:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l10, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l61
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %l2, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l66
  br label %bb19
bb19:
  %t96 = load i32, ptr %l61, !tbaa !23
  %t97 = load i32, ptr %l66, !tbaa !23
  %t98 = icmp ne i32 %t96, %t97
  store i1 %t98, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t100 = load i1, ptr %l56, !tbaa !21
  br i1 %t100, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb23
bb22:
  %t101 = load i32, ptr %l11, !tbaa !23
  %t103 = icmp ne i32 %t101, 0
  store i1 %t103, ptr %l68, !tbaa !21
  br label %bb23
bb23:
  %t105 = load i1, ptr %l68, !tbaa !21
  br i1 %t105, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb25:
  br label %bb26
bb26:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  store ptr %t111, ptr %l73, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t118 = load i32, ptr %l2, !tbaa !23
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v1, ptr %t117, i32 %t118)
  store i32 %t121, ptr %l78
  br label %bb27
bb27:
  %t122 = load ptr, ptr %l73, !tbaa !29
  %t123 = load i32, ptr %l78, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %t122, i32 %t123)
  store { i64, ptr } %t124, ptr %l79
  br label %bb28
bb28:
  %t125 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t125, ptr %l12, !tbaa !27
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/load:Loader", ptr %t132, i32 0, i32 5
  store ptr %t134, ptr %l83, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %l85, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l2, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l90
  br label %bb29
bb29:
  %t149 = load ptr, ptr %l85, !tbaa !29
  %t150 = load i32, ptr %l90, !tbaa !23
  %t151 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v1, ptr %t149, i32 %t150)
  store i64 %t151, ptr %l91
  br label %bb30
bb30:
  %t152 = load ptr, ptr %l83, !tbaa !29
  %t153 = load i64, ptr %l91, !tbaa !24
  %t154 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v1, ptr %v1, ptr %t152, i64 %t153)
  store ptr %t154, ptr %l92
  br label %bb31
bb31:
  %t155 = load ptr, ptr %l92, !tbaa !29
  %t157 = getelementptr %"compiler/load:Module", ptr %t155, i32 0, i32 6
  %t158 = load ptr, ptr %t157, !tbaa !29
  store ptr %t158, ptr %l13, !tbaa !29
  %t160 = load ptr, ptr %l13, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  br i1 %t162, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_35ffc19e50bbc737_e52638f1e81552b)
  unreachable
bb33:
  br label %bb34
bb34:
  %t164 = load ptr, ptr %l13, !tbaa !29
  %t167 = getelementptr %"compiler/source:Source", ptr %t164, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  store { i64, ptr } %t168, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t170 = load ptr, ptr %l8, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Body", ptr %t170, i32 0, i32 10
  %t174 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t172)
  store i64 %t174, ptr %l102
  br label %bb35
bb35:
  %t175 = load i64, ptr %l102, !tbaa !24
  store i64 %t175, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t176 = load i64, ptr %l16, !tbaa !24
  %t177 = load i64, ptr %l15, !tbaa !24
  %t180 = icmp sgt i64 %t176, %t177
  br i1 %t180, label %bb36, label %bb37
bb36:
  %t182 = load i64, ptr %l17, !tbaa !24
  %t184 = icmp sgt i64 %t182, 0
  br i1 %t184, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb41
bb38:
  %t186 = load i64, ptr %l16, !tbaa !24
  %t187 = load i64, ptr %l15, !tbaa !24
  %t190 = sub i64 %t186, %t187
  %t191 = load i64, ptr %l17, !tbaa !24
  %t194 = add i64 %t190, %t191
  %t196 = sub i64 %t194, 1
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = sdiv i64 %t196, %t197
  store i64 %t200, ptr %l109, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb40
bb40:
  %t202 = load i64, ptr %l109, !tbaa !24
  store i64 %t202, ptr %l106, !tbaa !24
  br label %bb41
bb41:
  %t203 = load i64, ptr %l106, !tbaa !24
  store i64 %t203, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t204 = load i64, ptr %l19, !tbaa !24
  %t205 = load i64, ptr %l18, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb44:
  br label %bb45
bb45:
  %t212 = load i64, ptr %l15, !tbaa !24
  %t213 = load i64, ptr %l19, !tbaa !24
  %t214 = load i64, ptr %l17, !tbaa !24
  %t217 = mul i64 %t213, %t214
  %t220 = add i64 %t212, %t217
  store i64 %t220, ptr %l20, !tbaa !24
  %t222 = load ptr, ptr %l8, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Body", ptr %t222, i32 0, i32 7
  store ptr %t224, ptr %l128, !tbaa !29
  %t225 = load ptr, ptr %l8, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Body", ptr %t225, i32 0, i32 10
  %t228 = load i64, ptr %l20, !tbaa !24
  %t231 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t227, i64 %t228)
  store i32 %t231, ptr %l132
  br label %bb46
bb46:
  %t232 = load i32, ptr %l132, !tbaa !23
  %t233 = sext i32 %t232 to i64
  %t234 = load ptr, ptr %l128, !tbaa !29
  %t236 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t234, i64 %t233)
  store %"compiler/typed:Local" %t236, ptr %l134
  br label %bb47
bb47:
  %t237 = load %"compiler/typed:Local", ptr %l134
  store %"compiler/typed:Local" %t237, ptr %l21
  %t238 = load i64, ptr %l20, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t244 = icmp slt i64 %t238, %t241
  br i1 %t244, label %bb48, label %bb49
bb48:
  %t246 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t246, ptr %l140, !tbaa !27
  %t247 = load i64, ptr %l20, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i32, ptr %t250, i64 %t247
  %t252 = load i32, ptr %t251, !tbaa !33
  store i32 %t252, ptr %l139, !tbaa !23
  br label %bb50
bb49:
  %t254 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 2
  %t255 = load i32, ptr %t254, !tbaa !23
  store i32 %t255, ptr %l139, !tbaa !23
  br label %bb50
bb50:
  %t257 = load i32, ptr %l139, !tbaa !23
  store i32 %t257, ptr %l22, !tbaa !23
  %t258 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = icmp eq i32 %t259, 0
  br i1 %t261, label %bb51, label %bb52
bb51:
  %t263 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t263, ptr %l147, !tbaa !27
  %t264 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t265 = getelementptr %"compiler/source:Span", ptr %t264, i32 0, i32 0
  %t266 = load i32, ptr %t265, !tbaa !23
  %t268 = sext i32 %t266 to i64
  store i64 %t268, ptr %l149, !tbaa !24
  %t269 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t270 = getelementptr %"compiler/source:Span", ptr %t269, i32 0, i32 1
  %t271 = load i32, ptr %t270, !tbaa !23
  %t273 = sext i32 %t271 to i64
  store i64 %t273, ptr %l151, !tbaa !24
  %t274 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  store i64 %t275, ptr %l152, !tbaa !24
  %t276 = load i64, ptr %l149, !tbaa !24
  %t277 = icmp sge i64 %t276, 0
  br i1 %t277, label %bb53, label %bb54
bb52:
  %t279 = load ptr, ptr %l1, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/load:Loader", ptr %t285, i32 0, i32 3
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t289 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t290 = load i32, ptr %t289, !tbaa !23
  %t293 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %t288, i32 %t290)
  store { i64, ptr } %t293, ptr %l162
  br label %bb59
bb53:
  %t294 = load i64, ptr %l149, !tbaa !24
  %t295 = load i64, ptr %l151, !tbaa !24
  %t296 = icmp sle i64 %t294, %t295
  br i1 %t296, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2)
  unreachable
bb55:
  %t298 = load i64, ptr %l151, !tbaa !24
  %t299 = load i64, ptr %l152, !tbaa !24
  %t300 = icmp sle i64 %t298, %t299
  br i1 %t300, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2)
  unreachable
bb57:
  %t302 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = load i64, ptr %l149, !tbaa !24
  %t305 = load i64, ptr %l151, !tbaa !24
  %t306 = getelementptr i8, ptr %t303, i64 %t304
  %t307 = sub i64 %t305, %t304
  %t308 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t306, 1
  store { i64, ptr } %t309, ptr %l146, !tbaa !27
  br label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2)
  unreachable
bb59:
  %t311 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t311, ptr %l146, !tbaa !27
  br label %bb60
bb60:
  %t312 = load { i64, ptr }, ptr %l146, !tbaa !27
  store ptr %a0, ptr %l163, !tbaa !29
  store { i64, ptr } %t312, ptr %l164, !tbaa !27
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t316 = load i32, ptr %l22, !tbaa !23
  %t319 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s7, ptr %t315, i32 %t316)
  store { i64, ptr } %t319, ptr %l167
  br label %bb61
bb61:
  %t320 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t321 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t322 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 1
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t325 = add i64 %t321, %t324
  %t326 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t327 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t328 = add i64 %t325, %t327
  %t329 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = add i64 %t328, %t331
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t334 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t335 = add i64 %t332, %t334
  %t336 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t335)
  call void @olang_textcopy(ptr %t336, ptr %t320, i64 %t321)
  %t337 = getelementptr i8, ptr %t336, i64 %t321
  call void @olang_textcopy(ptr %t337, ptr %t323, i64 %t324)
  %t338 = getelementptr i8, ptr %t337, i64 %t324
  call void @olang_textcopy(ptr %t338, ptr %t326, i64 %t327)
  %t339 = getelementptr i8, ptr %t338, i64 %t327
  call void @olang_textcopy(ptr %t339, ptr %t330, i64 %t331)
  %t340 = getelementptr i8, ptr %t339, i64 %t331
  call void @olang_textcopy(ptr %t340, ptr %t333, i64 %t334)
  %t341 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t336, 1
  %t344 = extractvalue { i64, ptr } %t342, 0
  %t345 = extractvalue { i64, ptr } %t342, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  %t350 = load ptr, ptr %l163, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t350, { i64, ptr } %t349)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s7)
  br label %bb63
bb63:
  %t352 = load i64, ptr %l19, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l19, !tbaa !24
  br label %bb42
bb64:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_36a09f0a29856ad4_1f4c57e6e1803c38)
  unreachable
bb70:
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb71:
  %t356 = load i64, ptr %l7, !tbaa !24
  %t358 = add i64 %t356, 1
  store i64 %t358, ptr %l7, !tbaa !24
  br label %bb8
bb72:
  %t360 = load i64, ptr %l4, !tbaa !24
  %t361 = load i64, ptr %l6, !tbaa !24
  %t364 = add i64 %t360, %t361
  store i64 %t364, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb73:
  br label %bb1
bb74:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fexplain_2efirstClose(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t2, 0
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = icmp sge i64 3, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sle i64 3, %t10
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sle i64 %t13, %t14
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb5:
  %t17 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr i8, ptr %t18, i64 3
  %t21 = sub i64 %t19, 3
  %t22 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = call i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %t23)
  store i64 %t25, ptr %l10
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6896438a508f3415_b4ea8b5a918f5051)
  unreachable
bb7:
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = add i64 3, %t26
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEnd(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp sgt i64 %t91, 0
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l56, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = sub i64 %t96, 1
  store i64 %t98, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb30:
  br label %bb31
bb31:
  %t100 = load i64, ptr %l1, !tbaa !24
  %t102 = icmp eq i64 %t100, 0
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load i8, ptr %l8, !tbaa !22
  %t106 = icmp eq i8 %t104, 44
  br i1 %t106, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb37
bb34:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb36
bb35:
  %t108 = load i8, ptr %l8, !tbaa !22
  %t110 = icmp eq i8 %t108, 41
  store i1 %t110, ptr %l66, !tbaa !21
  br label %bb36
bb36:
  %t112 = load i1, ptr %l66, !tbaa !21
  store i1 %t112, ptr %l63, !tbaa !21
  br label %bb37
bb37:
  %t113 = load i1, ptr %l63, !tbaa !21
  br i1 %t113, label %bb38, label %bb39
bb38:
  %t114 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t114, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  %t116 = load i64, ptr %l6, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l6, !tbaa !24
  br label %bb7
bb42:
  %t120 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  store i64 %t122, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fexplain_2efirstItemEndAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l8, !tbaa !22
  %t59 = load i8, ptr %l8, !tbaa !22
  %t61 = icmp eq i8 %t59, 40
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb13
bb12:
  %t63 = load i8, ptr %l8, !tbaa !22
  %t65 = icmp eq i8 %t63, 60
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l40, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb15:
  %t68 = load i8, ptr %l8, !tbaa !22
  %t70 = icmp eq i8 %t68, 91
  store i1 %t70, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l1, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 41
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 62
  store i1 %t83, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l50, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  %t86 = load i8, ptr %l8, !tbaa !22
  %t88 = icmp eq i8 %t86, 93
  store i1 %t88, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l53, !tbaa !21
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t93 = icmp eq i64 %t91, 0
  br i1 %t93, label %bb28, label %bb29
bb27:
  br label %bb31
bb28:
  %t95 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t95, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t97 = load i64, ptr %l1, !tbaa !24
  %t99 = sub i64 %t97, 1
  store i64 %t99, ptr %l1, !tbaa !24
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l6, !tbaa !24
  br label %bb7
bb33:
  %t105 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i64
  %l37 = alloca i32
  %l39 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca i64
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l78 = alloca ptr
  %l80 = alloca ptr
  %l84 = alloca i64
  %l88 = alloca ptr
  %l91 = alloca i64
  %l95 = alloca i64
  %l98 = alloca i64
  %l119 = alloca i64
  %l124 = alloca i64
  %l127 = alloca ptr
  %l131 = alloca i32
  %l137 = alloca i32
  %l138 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l150 = alloca i32
  %l151 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca i64
  %l168 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t3)
  store i64 %t5, ptr %l18
  br label %bb2
bb2:
  %t6 = load i64, ptr %l18, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t10, i64 %t6)
  store i64 %t14, ptr %l22
  br label %bb3
bb3:
  %t15 = load i64, ptr %l22, !tbaa !24
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t21, i64 %t22, i32 0)
  store i64 %t25, ptr %l27
  br label %bb6
bb5:
  br label %bb16
bb6:
  %t26 = load i64, ptr %l27, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l30
  br label %bb7
bb7:
  %t32 = load i64, ptr %l30, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store ptr %l3, ptr %l31, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l32, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l33, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t38, i64 %t39)
  store i32 %t42, ptr %l37
  br label %bb8
bb8:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load ptr, ptr %l32, !tbaa !29
  %t45 = load i64, ptr %l33, !tbaa !24
  %t46 = load i32, ptr %l37, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s1, ptr %t44, i64 %t45, i32 %t46, i64 %t43)
  store { i64, ptr } %t48, ptr %l39
  br label %bb9
bb9:
  %t49 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = getelementptr i8, ptr %t55, i64 %t51
  call void @olang_textcopy(ptr %t56, ptr %t52, i64 %t53)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load ptr, ptr %l31, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t66, { i64, ptr } %t65)
  br label %bb10
bb10:
  store ptr %l3, ptr %l42, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l43, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t73 = load i64, ptr %l2, !tbaa !24
  %t76 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t72, i64 %t73)
  store ptr %t76, ptr %l47
  br label %bb11
bb11:
  %t77 = load ptr, ptr %l47, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  store ptr %t80, ptr %l49, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load i64, ptr %l2, !tbaa !24
  %t88 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t84, i64 %t85)
  store i64 %t88, ptr %l53
  br label %bb12
bb12:
  %t89 = load ptr, ptr %l42, !tbaa !29
  %t90 = load ptr, ptr %l43, !tbaa !29
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = load i64, ptr %l53, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s1, ptr %t89, ptr %t90, ptr %t91, i64 %t92, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb13
bb13:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t95 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s1, ptr %l3, ptr %t93, ptr %t94, i64 %t95, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  br label %bb14
bb14:
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t101, ptr %l59
  br label %bb15
bb15:
  %t102 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t102, ptr %l60, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l61, !tbaa !24
  %t105 = load i64, ptr %l61, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l62, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l61, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t116, ptr %l60, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb16:
  store ptr %l3, ptr %l63, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l64, !tbaa !29
  %t119 = load i64, ptr %l2, !tbaa !24
  store i64 %t119, ptr %l65, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t124 = load i64, ptr %l2, !tbaa !24
  %t127 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t123, i64 %t124)
  store i32 %t127, ptr %l69
  br label %bb17
bb17:
  %t128 = load ptr, ptr %l64, !tbaa !29
  %t129 = load i64, ptr %l65, !tbaa !24
  %t130 = load i32, ptr %l69, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %s0, ptr %t128, i64 %t129, i32 %t130, i64 -1)
  store { i64, ptr } %t131, ptr %l70
  br label %bb18
bb18:
  %t132 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t133, i64 %t134)
  %t139 = getelementptr i8, ptr %t138, i64 %t134
  call void @olang_textcopy(ptr %t139, ptr %t135, i64 %t136)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t138, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } %t141, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t149 = load ptr, ptr %l63, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t149, { i64, ptr } %t148)
  br label %bb19
bb19:
  store ptr %l3, ptr %l73, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l74, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t156 = load i64, ptr %l2, !tbaa !24
  %t159 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t155, i64 %t156)
  store ptr %t159, ptr %l78
  br label %bb20
bb20:
  %t160 = load ptr, ptr %l78, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Func", ptr %t160, i32 0, i32 3
  %t163 = load ptr, ptr %t162, !tbaa !29
  store ptr %t163, ptr %l80, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t168 = load i64, ptr %l2, !tbaa !24
  %t171 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t167, i64 %t168)
  store i64 %t171, ptr %l84
  br label %bb21
bb21:
  %t172 = load ptr, ptr %l73, !tbaa !29
  %t173 = load ptr, ptr %l74, !tbaa !29
  %t174 = load ptr, ptr %l80, !tbaa !29
  %t175 = load i64, ptr %l84, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t172, ptr %t173, ptr %t174, i64 %t175, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb22
bb22:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t180 = load i64, ptr %l2, !tbaa !24
  %t183 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t179, i64 %t180)
  store ptr %t183, ptr %l88
  br label %bb23
bb23:
  %t184 = load ptr, ptr %l88, !tbaa !29
  store ptr %t184, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %t188)
  store i64 %t190, ptr %l91
  br label %bb24
bb24:
  %t191 = load i64, ptr %l91, !tbaa !24
  store i64 %t191, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t192 = load i64, ptr %l9, !tbaa !24
  %t193 = load i64, ptr %l8, !tbaa !24
  %t196 = icmp sgt i64 %t192, %t193
  br i1 %t196, label %bb25, label %bb26
bb25:
  %t198 = load i64, ptr %l10, !tbaa !24
  %t200 = icmp sgt i64 %t198, 0
  br i1 %t200, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb30
bb27:
  %t202 = load i64, ptr %l9, !tbaa !24
  %t203 = load i64, ptr %l8, !tbaa !24
  %t206 = sub i64 %t202, %t203
  %t207 = load i64, ptr %l10, !tbaa !24
  %t210 = add i64 %t206, %t207
  %t212 = sub i64 %t210, 1
  %t213 = load i64, ptr %l10, !tbaa !24
  %t216 = sdiv i64 %t212, %t213
  store i64 %t216, ptr %l98, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb29
bb29:
  %t218 = load i64, ptr %l98, !tbaa !24
  store i64 %t218, ptr %l95, !tbaa !24
  br label %bb30
bb30:
  %t219 = load i64, ptr %l95, !tbaa !24
  store i64 %t219, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t220 = load i64, ptr %l12, !tbaa !24
  %t221 = load i64, ptr %l11, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb33:
  br label %bb34
bb34:
  %t228 = load i64, ptr %l8, !tbaa !24
  %t229 = load i64, ptr %l12, !tbaa !24
  %t230 = load i64, ptr %l10, !tbaa !24
  %t233 = mul i64 %t229, %t230
  %t236 = add i64 %t228, %t233
  store i64 %t236, ptr %l13, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t242 = load i64, ptr %l13, !tbaa !24
  %t245 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t241, i64 %t242)
  store i64 %t245, ptr %l119
  br label %bb35
bb35:
  %t246 = load i64, ptr %l2, !tbaa !24
  %t247 = load i64, ptr %l119, !tbaa !24
  %t249 = icmp ne i64 %t247, %t246
  br i1 %t249, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb37:
  br label %bb38
bb38:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load i64, ptr %l13, !tbaa !24
  %t255 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %t251, i64 %t252)
  store i64 %t255, ptr %l124
  br label %bb39
bb39:
  %t256 = load i64, ptr %l124, !tbaa !24
  store i64 %t256, ptr %l14, !tbaa !24
  %t257 = load i64, ptr %l14, !tbaa !24
  %t259 = icmp slt i64 %t257, 0
  br i1 %t259, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb41:
  br label %bb42
bb42:
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l127, !tbaa !29
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/check:Checker", ptr %t262, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t266 = load i64, ptr %l13, !tbaa !24
  %t269 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t265, i64 %t266)
  store i32 %t269, ptr %l131
  br label %bb43
bb43:
  %t270 = load ptr, ptr %l7, !tbaa !29
  %t272 = getelementptr %"compiler/ast:Func", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = load ptr, ptr %l7, !tbaa !29
  %t276 = getelementptr %"compiler/ast:Func", ptr %t274, i32 0, i32 3
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/ast:Sig", ptr %t277, i32 0, i32 0
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  %t281 = load ptr, ptr %l127, !tbaa !29
  %t282 = load i32, ptr %l131, !tbaa !23
  %t285 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t281, i32 %t282, ptr %t273, { i64, ptr } %t280)
  store i32 %t285, ptr %l137
  br label %bb44
bb44:
  %t286 = load i32, ptr %l137, !tbaa !23
  store i32 %t286, ptr %l15, !tbaa !23
  store ptr %l3, ptr %l138, !tbaa !29
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/check:Checker", ptr %t287, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !29
  %t292 = getelementptr %"compiler/generic:Program", ptr %t290, i32 0, i32 0
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t295 = getelementptr %"compiler/load:Loader", ptr %t293, i32 0, i32 3
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t297 = load ptr, ptr %l7, !tbaa !29
  %t299 = getelementptr %"compiler/ast:Func", ptr %t297, i32 0, i32 2
  %t300 = load i32, ptr %t299, !tbaa !23
  %t303 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t296, i32 %t300)
  store { i64, ptr } %t303, ptr %l145
  br label %bb45
bb45:
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l146, !tbaa !29
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/check:Checker", ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t309 = load i64, ptr %l13, !tbaa !24
  %t312 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t308, i64 %t309)
  store i32 %t312, ptr %l150
  br label %bb46
bb46:
  %t313 = load ptr, ptr %l146, !tbaa !29
  %t314 = load i32, ptr %l150, !tbaa !23
  %t315 = call { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %s5, ptr %t313, i32 %t314)
  store { i64, ptr } %t315, ptr %l151
  br label %bb47
bb47:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load i32, ptr %l15, !tbaa !23
  %t318 = load i64, ptr %l14, !tbaa !24
  %t322 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s5, ptr %t316, i32 %t317, i64 %t318)
  store { i64, ptr } %t322, ptr %l155
  br label %bb48
bb48:
  %t323 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t324 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t325 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t325, 1
  %t327 = extractvalue { i64, ptr } %t325, 0
  %t328 = add i64 %t324, %t327
  %t329 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = add i64 %t328, %t331
  %t333 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t334 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t335 = add i64 %t332, %t334
  %t336 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = add i64 %t335, %t338
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t341 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t342 = add i64 %t339, %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t342)
  call void @olang_textcopy(ptr %t343, ptr %t323, i64 %t324)
  %t344 = getelementptr i8, ptr %t343, i64 %t324
  call void @olang_textcopy(ptr %t344, ptr %t326, i64 %t327)
  %t345 = getelementptr i8, ptr %t344, i64 %t327
  call void @olang_textcopy(ptr %t345, ptr %t330, i64 %t331)
  %t346 = getelementptr i8, ptr %t345, i64 %t331
  call void @olang_textcopy(ptr %t346, ptr %t333, i64 %t334)
  %t347 = getelementptr i8, ptr %t346, i64 %t334
  call void @olang_textcopy(ptr %t347, ptr %t337, i64 %t338)
  %t348 = getelementptr i8, ptr %t347, i64 %t338
  call void @olang_textcopy(ptr %t348, ptr %t340, i64 %t341)
  %t349 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t343, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } %t350, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  %t358 = load ptr, ptr %l138, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t358, { i64, ptr } %t357)
  br label %bb49
bb49:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t362 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2fexplain_2eobligations(ptr %s0, ptr %v0, ptr %v1, ptr %s5, ptr %l3, ptr %t360, ptr %t361, i64 %t362, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb51:
  %t367 = load i64, ptr %l12, !tbaa !24
  %t369 = add i64 %t367, 1
  store i64 %t369, ptr %l12, !tbaa !24
  br label %bb31
bb52:
  %t372 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t372, ptr %l165
  br label %bb53
bb53:
  %t373 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t373, ptr %l166, !tbaa !27
  %t374 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 0
  store i64 %t375, ptr %l167, !tbaa !24
  %t376 = load i64, ptr %l167, !tbaa !24
  %t377 = mul i64 %t376, 1
  %t378 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t377)
  %t379 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t380 = insertvalue { i64, ptr } %t379, ptr %t378, 1
  store { i64, ptr } %t380, ptr %l168, !tbaa !27
  %t381 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !27
  %t383 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !27
  %t385 = load i64, ptr %l167, !tbaa !24
  %t386 = mul i64 %t385, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t382, ptr %t384, i64 %t386, i1 false)
  %t387 = load { i64, ptr }, ptr %l168, !tbaa !27
  store { i64, ptr } %t387, ptr %l166, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t388 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t388, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l26 = alloca i64
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca i1
  %l59 = alloca i1
  %l64 = alloca i64
  %l65 = alloca i64
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l80 = alloca i64
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i64
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l105 = alloca i64
  %l110 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l117 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l16
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l16, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/ast:Func", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t19, i32 %t23)
  store { i64, ptr } %t26, ptr %l23
  br label %bb2
bb2:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l24, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t28)
  store i64 %t30, ptr %l26
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l29
  br label %bb4
bb4:
  %t36 = load ptr, ptr %l24, !tbaa !29
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = load i64, ptr %l29, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t36, i64 %t37, i64 %t38)
  store { i64, ptr } %t39, ptr %l30
  br label %bb5
bb5:
  %t40 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = add i64 %t42, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t41, i64 %t42)
  %t48 = getelementptr i8, ptr %t47, i64 %t42
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Func", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 3
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Sig", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t70 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v0, ptr %v0, ptr %t53, i32 %t54, ptr %t58, { i64, ptr } %t65)
  store i32 %t70, ptr %l40
  br label %bb6
bb6:
  %t72 = load ptr, ptr %l32, !tbaa !29
  %t73 = load i32, ptr %l40, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %s0, ptr %t72, i32 %t73, i64 %a3)
  store { i64, ptr } %t75, ptr %l42
  br label %bb7
bb7:
  %t76 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t76, ptr %l6, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i64, ptr %l1, !tbaa !24
  %t84 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t80, i64 %t81)
  store i1 %t84, ptr %l46
  br label %bb8
bb8:
  %t85 = load i1, ptr %l46, !tbaa !21
  br i1 %t85, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l47, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l2, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l52
  br label %bb11
bb10:
  br label %bb36
bb11:
  %t97 = load ptr, ptr %l47, !tbaa !29
  %t98 = load i32, ptr %l52, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s2, ptr %t97, i32 %t98)
  store { i64, ptr } %t99, ptr %l53
  br label %bb12
bb12:
  %t100 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t100, ptr %l7, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t105 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s2, { i64, ptr } %t101, { i64, ptr } %t102)
  store i1 %t105, ptr %l56
  br label %bb13
bb13:
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb14, label %bb15
bb14:
  %t107 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t109 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s2, ptr %s2, { i64, ptr } %t107, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t109, ptr %l59
  br label %bb16
bb15:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb17
bb16:
  %t110 = load i1, ptr %l59, !tbaa !21
  store i1 %t110, ptr %l57, !tbaa !21
  br label %bb17
bb17:
  %t111 = load i1, ptr %l57, !tbaa !21
  br i1 %t111, label %bb18, label %bb19
bb18:
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t120 = sub i64 %t114, %t117
  store i64 %t120, ptr %l64, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l65, !tbaa !24
  %t123 = icmp sge i64 0, 0
  br i1 %t123, label %bb20, label %bb21
bb19:
  br label %bb35
bb20:
  %t125 = load i64, ptr %l64, !tbaa !24
  %t126 = icmp sle i64 0, %t125
  br i1 %t126, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb22:
  %t128 = load i64, ptr %l64, !tbaa !24
  %t129 = load i64, ptr %l65, !tbaa !24
  %t130 = icmp sle i64 %t128, %t129
  br i1 %t130, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb24:
  %t132 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l64, !tbaa !24
  %t135 = getelementptr i8, ptr %t133, i64 0
  %t136 = sub i64 %t134, 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  store { i64, ptr } %t138, ptr %l69, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  store i64 %t141, ptr %l71, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l72, !tbaa !24
  %t144 = icmp sge i64 9, 0
  br i1 %t144, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb26:
  %t146 = load i64, ptr %l71, !tbaa !24
  %t147 = icmp sle i64 9, %t146
  br i1 %t147, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb28:
  %t149 = load i64, ptr %l71, !tbaa !24
  %t150 = load i64, ptr %l72, !tbaa !24
  %t151 = icmp sle i64 %t149, %t150
  br i1 %t151, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb30:
  %t153 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l71, !tbaa !24
  %t156 = getelementptr i8, ptr %t154, i64 9
  %t157 = sub i64 %t155, 9
  %t158 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  %t160 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t161 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 1
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t164 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t168 = extractvalue { i64, ptr } %t159, 1
  %t169 = extractvalue { i64, ptr } %t159, 0
  %t170 = add i64 %t166, %t169
  %t171 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t175 = extractvalue { i64, ptr } %t160, 1
  %t176 = extractvalue { i64, ptr } %t160, 0
  %t177 = add i64 %t173, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t162, i64 %t163)
  %t179 = getelementptr i8, ptr %t178, i64 %t163
  call void @olang_textcopy(ptr %t179, ptr %t164, i64 %t165)
  %t180 = getelementptr i8, ptr %t179, i64 %t165
  call void @olang_textcopy(ptr %t180, ptr %t168, i64 %t169)
  %t181 = getelementptr i8, ptr %t180, i64 %t169
  call void @olang_textcopy(ptr %t181, ptr %t171, i64 %t172)
  %t182 = getelementptr i8, ptr %t181, i64 %t172
  call void @olang_textcopy(ptr %t182, ptr %t175, i64 %t176)
  %t183 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t178, 1
  store { i64, ptr } %t184, ptr %l78, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t187 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l80, !tbaa !24
  %t190 = load i64, ptr %l80, !tbaa !24
  %t191 = icmp eq i64 %t186, %t190
  br i1 %t191, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_2d047dc2e8ba79e9_b3960442abafce65)
  unreachable
bb32:
  %t193 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = load i64, ptr %l80, !tbaa !24
  %t198 = mul i64 %t197, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t194, ptr %t196, i64 %t198, i1 false)
  br label %bb34
bb33:
  %t199 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t199, ptr %l6, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb36:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t204 = load i64, ptr %l1, !tbaa !24
  %t207 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t203, i64 %t204)
  store i1 %t207, ptr %l85
  br label %bb37
bb37:
  %t208 = load i1, ptr %l85, !tbaa !21
  br i1 %t208, label %bb38, label %bb39
bb38:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb40
bb39:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb40
bb40:
  %t209 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t209, ptr %l8, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  store i64 %t212, ptr %l88, !tbaa !24
  %t213 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 0
  store i64 %t214, ptr %l89, !tbaa !24
  %t215 = icmp sge i64 3, 0
  br i1 %t215, label %bb41, label %bb42
bb41:
  %t217 = load i64, ptr %l88, !tbaa !24
  %t218 = icmp sle i64 3, %t217
  br i1 %t218, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb43:
  %t220 = load i64, ptr %l88, !tbaa !24
  %t221 = load i64, ptr %l89, !tbaa !24
  %t222 = icmp sle i64 %t220, %t221
  br i1 %t222, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb45:
  %t224 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = load i64, ptr %l88, !tbaa !24
  %t227 = getelementptr i8, ptr %t225, i64 3
  %t228 = sub i64 %t226, 3
  %t229 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t227, 1
  store { i64, ptr } %t230, ptr %l9, !tbaa !27
  %t232 = load ptr, ptr %l4, !tbaa !29
  %t234 = getelementptr %"compiler/ast:Func", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = icmp eq ptr %t235, null
  br i1 %t237, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_62f5937584004bfc_64dbf784650d4808)
  unreachable
bb47:
  %t239 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t239, 1
  %t244 = extractvalue { i64, ptr } %t239, 0
  %t246 = extractvalue { i64, ptr } %t240, 1
  %t247 = extractvalue { i64, ptr } %t240, 0
  %t248 = add i64 %t244, %t247
  %t249 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t251 = add i64 %t248, %t250
  %t253 = extractvalue { i64, ptr } %t241, 1
  %t254 = extractvalue { i64, ptr } %t241, 0
  %t255 = add i64 %t251, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t243, i64 %t244)
  %t257 = getelementptr i8, ptr %t256, i64 %t244
  call void @olang_textcopy(ptr %t257, ptr %t246, i64 %t247)
  %t258 = getelementptr i8, ptr %t257, i64 %t247
  call void @olang_textcopy(ptr %t258, ptr %t249, i64 %t250)
  %t259 = getelementptr i8, ptr %t258, i64 %t250
  call void @olang_textcopy(ptr %t259, ptr %t253, i64 %t254)
  %t260 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t256, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t261, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t263 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t265 = call i64 @compiler_2fexplain_2efirstItemEnd(ptr %s0, { i64, ptr } %t263)
  store i64 %t265, ptr %l102
  br label %bb50
bb50:
  %t266 = load i64, ptr %l102, !tbaa !24
  store i64 %t266, ptr %l10, !tbaa !24
  %t267 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t267, ptr %l103, !tbaa !27
  %t268 = load i64, ptr %l10, !tbaa !24
  store i64 %t268, ptr %l104, !tbaa !24
  %t269 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l105, !tbaa !24
  %t271 = icmp sge i64 0, 0
  br i1 %t271, label %bb51, label %bb52
bb51:
  %t273 = load i64, ptr %l104, !tbaa !24
  %t274 = icmp sle i64 0, %t273
  br i1 %t274, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb53:
  %t276 = load i64, ptr %l104, !tbaa !24
  %t277 = load i64, ptr %l105, !tbaa !24
  %t278 = icmp sle i64 %t276, %t277
  br i1 %t278, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb55:
  %t280 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = load i64, ptr %l104, !tbaa !24
  %t283 = getelementptr i8, ptr %t281, i64 0
  %t284 = sub i64 %t282, 0
  %t285 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t283, 1
  store { i64, ptr } %t286, ptr %l11, !tbaa !27
  %t288 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t288, ptr %l110, !tbaa !27
  %t289 = load i64, ptr %l10, !tbaa !24
  %t291 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr i8, ptr %t292, i64 %t289
  %t294 = load i8, ptr %t293, !tbaa !32
  %t296 = icmp eq i8 %t294, 44
  br i1 %t296, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23)
  unreachable
bb57:
  %t298 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t298, ptr %l115, !tbaa !27
  %t299 = load i64, ptr %l10, !tbaa !24
  %t301 = add i64 %t299, 2
  store i64 %t301, ptr %l117, !tbaa !24
  %t302 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t302, 0
  store i64 %t305, ptr %l120, !tbaa !24
  %t306 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 0
  store i64 %t307, ptr %l121, !tbaa !24
  %t308 = load i64, ptr %l117, !tbaa !24
  %t309 = icmp sge i64 %t308, 0
  br i1 %t309, label %bb59, label %bb60
bb58:
  %t311 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t311, ptr %l126, !tbaa !27
  %t312 = load i64, ptr %l10, !tbaa !24
  store i64 %t312, ptr %l127, !tbaa !24
  %t313 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t313, 0
  store i64 %t316, ptr %l130, !tbaa !24
  %t317 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 0
  store i64 %t318, ptr %l131, !tbaa !24
  %t319 = load i64, ptr %l127, !tbaa !24
  %t320 = icmp sge i64 %t319, 0
  br i1 %t320, label %bb65, label %bb66
bb59:
  %t322 = load i64, ptr %l117, !tbaa !24
  %t323 = load i64, ptr %l120, !tbaa !24
  %t324 = icmp sle i64 %t322, %t323
  br i1 %t324, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb61:
  %t326 = load i64, ptr %l120, !tbaa !24
  %t327 = load i64, ptr %l121, !tbaa !24
  %t328 = icmp sle i64 %t326, %t327
  br i1 %t328, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb63:
  %t330 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = load i64, ptr %l117, !tbaa !24
  %t333 = load i64, ptr %l120, !tbaa !24
  %t334 = getelementptr i8, ptr %t331, i64 %t332
  %t335 = sub i64 %t333, %t332
  %t336 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t334, 1
  store { i64, ptr } %t337, ptr %l114, !tbaa !27
  br label %bb71
bb64:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb65:
  %t339 = load i64, ptr %l127, !tbaa !24
  %t340 = load i64, ptr %l130, !tbaa !24
  %t341 = icmp sle i64 %t339, %t340
  br i1 %t341, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb67:
  %t343 = load i64, ptr %l130, !tbaa !24
  %t344 = load i64, ptr %l131, !tbaa !24
  %t345 = icmp sle i64 %t343, %t344
  br i1 %t345, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb69:
  %t347 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = load i64, ptr %l127, !tbaa !24
  %t350 = load i64, ptr %l130, !tbaa !24
  %t351 = getelementptr i8, ptr %t348, i64 %t349
  %t352 = sub i64 %t350, %t349
  %t353 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t351, 1
  store { i64, ptr } %t354, ptr %l114, !tbaa !27
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546)
  unreachable
bb71:
  %t356 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t357 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t358 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t359 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t357, 1
  %t363 = extractvalue { i64, ptr } %t357, 0
  %t364 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t365 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t366 = add i64 %t363, %t365
  %t368 = extractvalue { i64, ptr } %t358, 1
  %t369 = extractvalue { i64, ptr } %t358, 0
  %t370 = add i64 %t366, %t369
  %t371 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t372 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t373 = add i64 %t370, %t372
  %t375 = extractvalue { i64, ptr } %t359, 1
  %t376 = extractvalue { i64, ptr } %t359, 0
  %t377 = add i64 %t373, %t376
  %t378 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t379 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t380 = add i64 %t377, %t379
  %t382 = extractvalue { i64, ptr } %t356, 1
  %t383 = extractvalue { i64, ptr } %t356, 0
  %t384 = add i64 %t380, %t383
  %t385 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t362, i64 %t363)
  %t386 = getelementptr i8, ptr %t385, i64 %t363
  call void @olang_textcopy(ptr %t386, ptr %t364, i64 %t365)
  %t387 = getelementptr i8, ptr %t386, i64 %t365
  call void @olang_textcopy(ptr %t387, ptr %t368, i64 %t369)
  %t388 = getelementptr i8, ptr %t387, i64 %t369
  call void @olang_textcopy(ptr %t388, ptr %t371, i64 %t372)
  %t389 = getelementptr i8, ptr %t388, i64 %t372
  call void @olang_textcopy(ptr %t389, ptr %t375, i64 %t376)
  %t390 = getelementptr i8, ptr %t389, i64 %t376
  call void @olang_textcopy(ptr %t390, ptr %t378, i64 %t379)
  %t391 = getelementptr i8, ptr %t390, i64 %t379
  call void @olang_textcopy(ptr %t391, ptr %t382, i64 %t383)
  %t392 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t385, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t393, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2eglobalItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, %"compiler/names:Entry" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/names:Entry"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l8 = alloca { { i64, ptr }, i1 }
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l20 = alloca i32
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l37 = alloca i64
  %l40 = alloca { { i64, ptr }, i1 }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l53 = alloca i32
  %l56 = alloca i32
  %l61 = alloca i32
  %l63 = alloca i32
  %l65 = alloca i32
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store %"compiler/names:Entry" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %t12, i64 %t13, i32 %t15)
  store i32 %t19, ptr %l20
  br label %bb1
bb1:
  %t20 = load i32, ptr %l20, !tbaa !23
  store i32 %t20, ptr %l5, !tbaa !23
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t21, i32 %t23)
  store { i64, ptr } %t26, ptr %l23
  br label %bb2
bb2:
  %t27 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t28 = load i1, ptr %t27, !tbaa !21
  br i1 %t28, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l25, !tbaa !27
  br label %bb5
bb4:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l25, !tbaa !27
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l5, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t30, i32 %t31)
  store { i64, ptr } %t34, ptr %l28
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t36, i64 %t37)
  %t47 = getelementptr i8, ptr %t46, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = getelementptr i8, ptr %t47, i64 %t40
  call void @olang_textcopy(ptr %t48, ptr %t43, i64 %t44)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t46, 1
  store { i64, ptr } %t50, ptr %l6, !tbaa !27
  %t52 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 3
  %t53 = load i1, ptr %t52, !tbaa !21
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = getelementptr i8, ptr %t62, i64 %t58
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = getelementptr %"compiler/names:Entry", ptr %l3, i32 0, i32 1
  %t72 = load %"compiler/source:Span", ptr %t71
  %t77 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %t67, i64 %t68, i32 %t70, %"compiler/source:Span" %t72)
  store i64 %t77, ptr %l37
  br label %bb10
bb10:
  %t78 = load i64, ptr %l37, !tbaa !24
  %t83 = call { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v1, ptr %s0, ptr %a1, i64 %t78)
  store { { i64, ptr }, i1 } %t83, ptr %l40
  br label %bb11
bb11:
  %t84 = load { { i64, ptr }, i1 }, ptr %l40
  store { { i64, ptr }, i1 } %t84, ptr %l8
  %t85 = getelementptr { { i64, ptr }, i1 }, ptr %l8, i32 0, i32 0
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l41, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l42, !tbaa !24
  %t89 = load i64, ptr %l42, !tbaa !24
  %t90 = mul i64 %t89, 1
  %t91 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t90)
  %t92 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l43, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l42, !tbaa !24
  %t99 = mul i64 %t98, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t95, ptr %t97, i64 %t99, i1 false)
  %t100 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t100, ptr %l9, !tbaa !27
  %t101 = getelementptr { { i64, ptr }, i1 }, ptr %l8, i32 0, i32 1
  %t102 = load i1, ptr %t101, !tbaa !21
  %t106 = xor i1 %t102, true
  br i1 %t106, label %bb12, label %bb13
bb12:
  %t108 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = extractvalue { i64, ptr } %t108, 0
  %t112 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t114 = add i64 %t111, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t110, i64 %t111)
  %t116 = getelementptr i8, ptr %t115, i64 %t111
  call void @olang_textcopy(ptr %t116, ptr %t112, i64 %t113)
  %t117 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t118, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l5, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l53
  br label %bb15
bb15:
  %t130 = load i32, ptr %l53
  %t132 = trunc i64 20 to i32
  %t133 = icmp eq i32 %t130, %t132
  br i1 %t133, label %bb16, label %bb17
bb16:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l5, !tbaa !23
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t140, i32 %t141)
  store i32 %t144, ptr %l61
  br label %bb18
bb17:
  %t145 = load i32, ptr %l5, !tbaa !23
  store i32 %t145, ptr %l56, !tbaa !23
  br label %bb19
bb18:
  %t147 = load i32, ptr %l61, !tbaa !23
  store i32 %t147, ptr %l56, !tbaa !23
  br label %bb19
bb19:
  %t148 = load i32, ptr %l56, !tbaa !23
  store i32 %t148, ptr %l63, !tbaa !23
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %t150)
  store i32 %t152, ptr %l65
  br label %bb20
bb20:
  %t153 = load i32, ptr %l63, !tbaa !23
  %t154 = load i32, ptr %l65, !tbaa !23
  %t155 = icmp eq i32 %t153, %t154
  br i1 %t155, label %bb21, label %bb22
bb21:
  %t157 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t159 = call { i64, ptr } @compiler_2fexplain_2equoted(ptr %s0, ptr %s0, { i64, ptr } %t157)
  store { i64, ptr } %t159, ptr %l69
  br label %bb23
bb22:
  %t160 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 1
  %t163 = extractvalue { i64, ptr } %t160, 0
  %t164 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t163)
  call void @olang_textcopy(ptr %t164, ptr %t162, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l67, !tbaa !27
  br label %bb24
bb23:
  %t168 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t169, i64 %t170)
  %t172 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  store { i64, ptr } %t173, ptr %l67, !tbaa !27
  br label %bb24
bb24:
  %t175 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t175, ptr %l12, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = load i64, ptr @G_2ecompiler_2fexplain_2eLongValue, !tbaa !24
  %t182 = icmp sgt i64 %t178, %t179
  br i1 %t182, label %bb25, label %bb26
bb25:
  %t184 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t184, ptr %l77, !tbaa !27
  %t185 = load i64, ptr @G_2ecompiler_2fexplain_2eLongValue, !tbaa !24
  store i64 %t185, ptr %l78, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  store i64 %t187, ptr %l79, !tbaa !24
  %t188 = icmp sge i64 0, 0
  br i1 %t188, label %bb27, label %bb28
bb26:
  br label %bb33
bb27:
  %t190 = load i64, ptr %l78, !tbaa !24
  %t191 = icmp sle i64 0, %t190
  br i1 %t191, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb29:
  %t193 = load i64, ptr %l78, !tbaa !24
  %t194 = load i64, ptr %l79, !tbaa !24
  %t195 = icmp sle i64 %t193, %t194
  br i1 %t195, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb31:
  %t197 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = load i64, ptr %l78, !tbaa !24
  %t200 = getelementptr i8, ptr %t198, i64 0
  %t201 = sub i64 %t199, 0
  %t202 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t200, 1
  %t204 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t212 = add i64 %t209, %t211
  %t214 = extractvalue { i64, ptr } %t203, 1
  %t215 = extractvalue { i64, ptr } %t203, 0
  %t216 = add i64 %t212, %t215
  %t217 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t219 = add i64 %t216, %t218
  %t221 = call i64 @__olang_fmt_i64(ptr null, i64 %t206)
  %t222 = add i64 %t219, %t221
  %t223 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t225 = add i64 %t222, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t208, i64 %t209)
  %t227 = getelementptr i8, ptr %t226, i64 %t209
  call void @olang_textcopy(ptr %t227, ptr %t210, i64 %t211)
  %t228 = getelementptr i8, ptr %t227, i64 %t211
  call void @olang_textcopy(ptr %t228, ptr %t214, i64 %t215)
  %t229 = getelementptr i8, ptr %t228, i64 %t215
  call void @olang_textcopy(ptr %t229, ptr %t217, i64 %t218)
  %t230 = getelementptr i8, ptr %t229, i64 %t218
  %t231 = call i64 @__olang_fmt_i64(ptr %t230, i64 %t206)
  %t232 = getelementptr i8, ptr %t230, i64 %t221
  call void @olang_textcopy(ptr %t232, ptr %t223, i64 %t224)
  %t233 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t226, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t234, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b)
  unreachable
bb33:
  %t236 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t236, 1
  %t240 = extractvalue { i64, ptr } %t236, 0
  %t241 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t243 = add i64 %t240, %t242
  %t245 = extractvalue { i64, ptr } %t237, 1
  %t246 = extractvalue { i64, ptr } %t237, 0
  %t247 = add i64 %t243, %t246
  %t248 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t250 = add i64 %t247, %t249
  %t251 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t239, i64 %t240)
  %t252 = getelementptr i8, ptr %t251, i64 %t240
  call void @olang_textcopy(ptr %t252, ptr %t241, i64 %t242)
  %t253 = getelementptr i8, ptr %t252, i64 %t242
  call void @olang_textcopy(ptr %t253, ptr %t245, i64 %t246)
  %t254 = getelementptr i8, ptr %t253, i64 %t246
  call void @olang_textcopy(ptr %t254, ptr %t248, i64 %t249)
  %t255 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t251, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t256, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l25 = alloca %"compiler/source:Span"
  %l27 = alloca i64
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca i64
  %l32 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l6, !tbaa !29
  %t26 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l2)
  store i64 %t26, ptr %l19
  br label %bb6
bb6:
  %t27 = load i64, ptr %l19, !tbaa !24
  %t28 = icmp sgt i64 %t27, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  store ptr %l2, ptr %l22, !tbaa !29
  store { i64, ptr } %a0, ptr %l23, !tbaa !27
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t32)
  store %"compiler/source:Span" %t34, ptr %l25
  br label %bb11
bb11:
  %t35 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l27, !tbaa !24
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t41 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t39)
  store %"compiler/source:Span" %t41, ptr %l29
  br label %bb12
bb12:
  %t42 = getelementptr %"compiler/source:Span", ptr %l29, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t45 = sext i32 %t43 to i64
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l32, !tbaa !24
  %t48 = load i64, ptr %l27, !tbaa !24
  %t49 = icmp sge i64 %t48, 0
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb15:
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb17:
  %t59 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l27, !tbaa !24
  %t62 = load i64, ptr %l31, !tbaa !24
  %t63 = getelementptr i8, ptr %t60, i64 %t61
  %t64 = sub i64 %t62, %t61
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  %t67 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t67, { i64, ptr } %t66)
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_24a71f1628ab63b4_59f385be22d57b28)
  unreachable
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t69 = load i64, ptr %l4, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l4, !tbaa !24
  br label %bb2
bb21:
  %t74 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t74, ptr %l40
  br label %bb22
bb22:
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t75, ptr %l41, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l42, !tbaa !24
  %t78 = load i64, ptr %l42, !tbaa !24
  %t79 = mul i64 %t78, 1
  %t80 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l43, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l42, !tbaa !24
  %t88 = mul i64 %t87, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t89, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t90 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2emethods(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca i1
  %l54 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l75 = alloca i32
  %l82 = alloca i32
  %l87 = alloca i32
  %l91 = alloca i1
  %l96 = alloca i32
  %l101 = alloca i32
  %l104 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i64
  %l119 = alloca i32
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i64
  %l132 = alloca i32
  %l133 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v1, ptr %t4)
  br label %bb1
bb1:
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb2
bb2:
  %t12 = load i64, ptr %l16, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l23, !tbaa !24
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l20, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v1, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l44
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l44, !tbaa !29
  store ptr %t67, ptr %l9, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb17
bb15:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t87 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v1, ptr %t78, i32 %t79, i32 %t83)
  store i64 %t87, ptr %l54
  br label %bb16
bb16:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t89 = load i64, ptr %l54, !tbaa !24
  %t91 = icmp ne i64 %t89, %t88
  store i1 %t91, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t93 = load i1, ptr %l48, !tbaa !21
  br i1 %t93, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb19:
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  store ptr %t99, ptr %l59, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t105, ptr %l62, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t109, i64 %t110)
  store i32 %t113, ptr %l66
  br label %bb21
bb21:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load i32, ptr %l66, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v1, ptr %t114, i32 %t115)
  store i32 %t116, ptr %l67
  br label %bb22
bb22:
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load i32, ptr %l67, !tbaa !23
  %t119 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v1, ptr %t117, i32 %t118)
  store { i64, ptr } %t119, ptr %l68
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t120, ptr %l69, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i32, ptr %t122, i64 0
  %t124 = load i32, ptr %t123, !tbaa !33
  store i32 %t124, ptr %l10, !tbaa !23
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l10, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l75
  br label %bb24
bb24:
  %t136 = load i32, ptr %l75
  %t138 = trunc i64 20 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb25, label %bb26
bb25:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l10, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v1, ptr %t146, i32 %t147)
  store i32 %t150, ptr %l82
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t151 = load i32, ptr %l82, !tbaa !23
  store i32 %t151, ptr %l10, !tbaa !23
  br label %bb28
bb28:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  %t158 = load i32, ptr %l10, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v1, ptr %t157, i32 %t158)
  store i32 %t161, ptr %l87
  br label %bb29
bb29:
  %t162 = load i32, ptr %l87
  %t164 = trunc i64 18 to i32
  %t165 = icmp eq i32 %t162, %t164
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb34
bb31:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/generic:Program", ptr %t172, i32 0, i32 2
  %t175 = load i32, ptr %l10, !tbaa !23
  %t178 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t174, i32 %t175)
  store i32 %t178, ptr %l96
  br label %bb32
bb32:
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l2, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v1, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l101
  br label %bb33
bb33:
  %t189 = load i32, ptr %l96, !tbaa !23
  %t190 = load i32, ptr %l101, !tbaa !23
  %t191 = icmp ne i32 %t189, %t190
  store i1 %t191, ptr %l91, !tbaa !21
  br label %bb34
bb34:
  %t193 = load i1, ptr %l91, !tbaa !21
  br i1 %t193, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb36:
  br label %bb37
bb37:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  store ptr %t197, ptr %l104, !tbaa !29
  %t198 = load i64, ptr %l8, !tbaa !24
  %t200 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t198)
  store i64 %t200, ptr %l106
  br label %bb38
bb38:
  %t201 = load ptr, ptr %l104, !tbaa !29
  %t202 = load i64, ptr %l106, !tbaa !24
  %t203 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t201, i64 %t202)
  store i64 %t203, ptr %l107
  br label %bb39
bb39:
  %t204 = load i64, ptr %l107, !tbaa !24
  %t205 = icmp eq i64 %t204, 0
  br i1 %t205, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v1, ptr %t210, i64 %t211, i32 0)
  store i64 %t214, ptr %l112
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l126, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  store ptr %t216, ptr %l127, !tbaa !29
  %t217 = load i64, ptr %l8, !tbaa !24
  store i64 %t217, ptr %l128, !tbaa !24
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t222 = load i64, ptr %l8, !tbaa !24
  %t225 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v1, ptr %t221, i64 %t222)
  store i32 %t225, ptr %l132
  br label %bb47
bb42:
  %t226 = load i64, ptr %l112, !tbaa !24
  store i64 %t226, ptr %l11, !tbaa !24
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l113, !tbaa !29
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l114, !tbaa !29
  %t229 = load i64, ptr %l8, !tbaa !24
  store i64 %t229, ptr %l115, !tbaa !24
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr %"compiler/check:Checker", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v1, ptr %t233, i64 %t234)
  store i32 %t237, ptr %l119
  br label %bb43
bb43:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t239 = load i64, ptr %l11, !tbaa !24
  %t242 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v1, ptr %t238, i64 %t239)
  store i64 %t242, ptr %l122
  br label %bb44
bb44:
  %t243 = load ptr, ptr %l114, !tbaa !29
  %t244 = load i64, ptr %l115, !tbaa !24
  %t245 = load i32, ptr %l119, !tbaa !23
  %t246 = load i64, ptr %l122, !tbaa !24
  %t247 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s6, ptr %t243, i64 %t244, i32 %t245, i64 %t246)
  store { i64, ptr } %t247, ptr %l123
  br label %bb45
bb45:
  %t248 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t250 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t269 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t269, { i64, ptr } %t268)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb47:
  %t271 = load ptr, ptr %l127, !tbaa !29
  %t272 = load i64, ptr %l128, !tbaa !24
  %t273 = load i32, ptr %l132, !tbaa !23
  %t274 = call { i64, ptr } @compiler_2fexplain_2efnLine(ptr %v1, ptr %s8, ptr %t271, i64 %t272, i32 %t273, i64 -1)
  store { i64, ptr } %t274, ptr %l133
  br label %bb48
bb48:
  %t275 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t276 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t277 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = add i64 %t276, %t279
  %t281 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t283 = add i64 %t280, %t282
  %t284 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t283)
  call void @olang_textcopy(ptr %t284, ptr %t275, i64 %t276)
  %t285 = getelementptr i8, ptr %t284, i64 %t276
  call void @olang_textcopy(ptr %t285, ptr %t278, i64 %t279)
  %t286 = getelementptr i8, ptr %t285, i64 %t279
  call void @olang_textcopy(ptr %t286, ptr %t281, i64 %t282)
  %t287 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t284, 1
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t291 = extractvalue { i64, ptr } %t288, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t296 = load ptr, ptr %l126, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t296, { i64, ptr } %t295)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb51:
  %t298 = load i64, ptr %l7, !tbaa !24
  %t300 = add i64 %t298, 1
  store i64 %t300, ptr %l7, !tbaa !24
  br label %bb9
bb52:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca { i64, ptr }
  %l37 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t5 = icmp eq ptr %t3, null
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = sext i32 %t12 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t14)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l7, !tbaa !24
  br label %bb8
bb7:
  br label %bb15
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  %t47 = getelementptr %"compiler/ast:Param", ptr %t43, i32 0, i32 1
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = sext i32 %t48 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t50)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t53 = load i64, ptr %l6, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  br label %bb15
bb15:
  %t58 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t58, ptr %l37
  br label %bb16
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  store ptr %t64, ptr %l40, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l1, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l45
  br label %bb17
bb17:
  %t75 = load ptr, ptr %l40, !tbaa !29
  %t76 = load i32, ptr %l45, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t75, i32 %t76)
  store { i64, ptr } %t77, ptr %l46
  br label %bb18
bb18:
  %t78 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = load i64, ptr %l37, !tbaa !24
  %t82 = icmp ne i64 %t80, %t79
  br i1 %t82, label %bb19, label %bb20
bb19:
  %t84 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t84, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  store ptr %t91, ptr %l52, !tbaa !29
  %t92 = load i32, ptr %l1, !tbaa !23
  store i32 %t92, ptr %l53, !tbaa !23
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l56, !tbaa !29
  %t100 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t100, ptr %l58
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l56, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t103 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %s0, ptr %t101, { i64, ptr } %t102)
  store i64 %t103, ptr %l59
  br label %bb23
bb23:
  %t104 = load ptr, ptr %l52, !tbaa !29
  %t105 = load i32, ptr %l53, !tbaa !23
  %t106 = load i64, ptr %l59, !tbaa !24
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t104, i32 %t105, i64 %t106)
  store i32 %t107, ptr %l60
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i32, ptr %l60, !tbaa !23
  store i32 %t108, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fexplain_2eobligations(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4) #0 {
entry:
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = getelementptr %"compiler/check:Checker", ptr %a1, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/load:Loader", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v2, ptr %v1, ptr %s2, ptr %a2, i64 %t6, ptr %t16)
  store { i64, ptr } %t20, ptr %l17
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 16
  %t25 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %t45, i64 %t42
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !37
  %t53 = extractvalue { i64, ptr } %a4, 1
  %t54 = extractvalue { i64, ptr } %a4, 0
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t59 = extractvalue { i64, ptr } %t47, 1
  %t60 = extractvalue { i64, ptr } %t47, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = getelementptr i8, ptr %t65, i64 %t54
  call void @olang_textcopy(ptr %t66, ptr %t55, i64 %t56)
  %t67 = getelementptr i8, ptr %t66, i64 %t56
  call void @olang_textcopy(ptr %t67, ptr %t59, i64 %t60)
  %t68 = getelementptr i8, ptr %t67, i64 %t60
  call void @olang_textcopy(ptr %t68, ptr %t62, i64 %t63)
  %t69 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t65, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %a0, { i64, ptr } %t77)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb5
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2equoted(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb2
bb2:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t19
  %t24 = load i8, ptr %t23, !tbaa !32
  store i8 %t24, ptr %l5, !tbaa !22
  %t26 = load i8, ptr %l5, !tbaa !22
  %t28 = icmp eq i8 %t26, 34
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 92
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 92)
  br label %bb12
bb11:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 10
  br i1 %t38, label %bb14, label %bb15
bb12:
  %t40 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t40)
  br label %bb13
bb13:
  br label %bb23
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb16
bb15:
  %t44 = load i8, ptr %l5, !tbaa !22
  %t46 = icmp eq i8 %t44, 9
  br i1 %t46, label %bb17, label %bb18
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d45, i32 0, i32 1) })
  br label %bb19
bb18:
  %t49 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t49)
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s7)
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb3
bb25:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 34)
  br label %bb26
bb26:
  %t58 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t58, ptr %l38
  br label %bb27
bb27:
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t59, ptr %l39, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l40, !tbaa !24
  %t62 = load i64, ptr %l40, !tbaa !24
  %t63 = mul i64 %t62, 1
  %t64 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l41, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = mul i64 %t71, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t68, ptr %t70, i64 %t72, i1 false)
  %t73 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t73, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fexplain_2ereceiverVars(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l6 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l29 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i32
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Func", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i64 0, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l20
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load i32, ptr %l20, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t39, ptr %l21
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l13, !tbaa !29
  %t41 = load i32, ptr %l21, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t42, ptr %l22
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 0
  %t47 = load i32, ptr %t46, !tbaa !33
  store i32 %t47, ptr %l2, !tbaa !23
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l29
  br label %bb8
bb8:
  %t59 = load i32, ptr %l29
  %t61 = trunc i64 20 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l36
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t74 = load i32, ptr %l36, !tbaa !23
  store i32 %t74, ptr %l2, !tbaa !23
  br label %bb12
bb12:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/generic:Program", ptr %t78, i32 0, i32 2
  %t81 = load i32, ptr %l2, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l41
  br label %bb13
bb13:
  %t85 = load i32, ptr %l41
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb14, label %bb15
bb14:
  store i64 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  store ptr %t98, ptr %l48, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l2, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l53
  br label %bb17
bb17:
  %t109 = load ptr, ptr %l48, !tbaa !29
  %t110 = load i32, ptr %l53, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t109, i32 %t110)
  store { i64, ptr } %t111, ptr %l54
  br label %bb18
bb18:
  %t112 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2esigOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l36 = alloca i32
  %l41 = alloca i64
  %l42 = alloca i32
  %l45 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l10
  br label %bb3
bb3:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %t14, i32 %t15)
  store { i64, ptr } %t18, ptr %l14
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t24, ptr %l17
  br label %bb9
bb9:
  %t25 = load i32, ptr %l17, !tbaa !23
  store i32 %t25, ptr %l3, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l25
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb11
bb11:
  %t52 = load i32, ptr %l3, !tbaa !23
  store i32 %t52, ptr %l31, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l1, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l36
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l1, !tbaa !23
  %t72 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t72, ptr %l41
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l20, !tbaa !29
  %t74 = load i32, ptr %l25, !tbaa !23
  %t75 = load i32, ptr %l30, !tbaa !23
  %t76 = load i32, ptr %l31, !tbaa !23
  %t77 = load i32, ptr %l36, !tbaa !23
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 %t74, i32 %t75, i32 %t76, i32 %t77, i64 %t78)
  store i32 %t79, ptr %l42
  br label %bb14
bb14:
  %t80 = load i32, ptr %l42, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t81, i32 %t80)
  store { i64, ptr } %t85, ptr %l45
  br label %bb15
bb15:
  %t86 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = getelementptr i8, ptr %t92, i64 %t88
  call void @olang_textcopy(ptr %t93, ptr %t89, i64 %t90)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t95, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fexplain_2etraitsMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l85 = alloca %"compiler/names:Entry"
  %l89 = alloca i1
  %l93 = alloca %"compiler/names:Entry"
  %l100 = alloca i32
  %l105 = alloca i32
  %l109 = alloca i1
  %l111 = alloca ptr
  %l113 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i32
  %l124 = alloca i1
  %l125 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca ptr
  %l139 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/names:Resolver", ptr %t9, i32 0, i32 1
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_Hb234e65a2b42ee429ada36859295662b(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l24, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb8
bb5:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l31, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l31, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l9, !tbaa !24
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/names:Resolver", ptr %t67, i32 0, i32 1
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v1, ptr %v1, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l54
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l54, !tbaa !29
  store ptr %t74, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  %t75 = load ptr, ptr %l10, !tbaa !29
  %t77 = getelementptr %"compiler/names:Table", ptr %t75, i32 0, i32 0
  %t79 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %t77)
  store i64 %t79, ptr %l57
  br label %bb14
bb14:
  %t80 = load i64, ptr %l57, !tbaa !24
  store i64 %t80, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t81 = load i64, ptr %l12, !tbaa !24
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb15, label %bb16
bb15:
  %t87 = load i64, ptr %l13, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb20
bb17:
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load i64, ptr %l11, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l13, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l13, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l64, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb19
bb19:
  %t107 = load i64, ptr %l64, !tbaa !24
  store i64 %t107, ptr %l61, !tbaa !24
  br label %bb20
bb20:
  %t108 = load i64, ptr %l61, !tbaa !24
  store i64 %t108, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t109 = load i64, ptr %l15, !tbaa !24
  %t110 = load i64, ptr %l14, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb23:
  br label %bb24
bb24:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l15, !tbaa !24
  %t119 = load i64, ptr %l13, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t125 = add i64 %t117, %t122
  store i64 %t125, ptr %l16, !tbaa !24
  %t127 = load ptr, ptr %l10, !tbaa !29
  %t129 = getelementptr %"compiler/names:Table", ptr %t127, i32 0, i32 0
  %t130 = load i64, ptr %l16, !tbaa !24
  %t133 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %s4, ptr %t129, i64 %t130)
  store %"compiler/names:Entry" %t133, ptr %l85
  br label %bb25
bb25:
  %t134 = getelementptr %"compiler/names:Entry", ptr %l85, i32 0, i32 2
  %t135 = load i32, ptr %t134
  %t137 = trunc i64 4 to i32
  %t138 = icmp eq i32 %t135, %t137
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb29
bb27:
  %t142 = load ptr, ptr %l10, !tbaa !29
  %t144 = getelementptr %"compiler/names:Table", ptr %t142, i32 0, i32 0
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v1, ptr %v1, ptr %t144, i64 %t145)
  store %"compiler/names:Entry" %t148, ptr %l93
  br label %bb28
bb28:
  %t149 = getelementptr %"compiler/names:Entry", ptr %l93, i32 0, i32 4
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  store i1 %t152, ptr %l89, !tbaa !21
  br label %bb29
bb29:
  %t154 = load i1, ptr %l89, !tbaa !21
  br i1 %t154, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb31:
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i64, ptr %l9, !tbaa !24
  %t160 = load i64, ptr %l16, !tbaa !24
  %t164 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v1, ptr %t158, i64 %t159, i64 %t160)
  store i32 %t164, ptr %l100
  br label %bb33
bb33:
  %t165 = load i32, ptr %l100, !tbaa !23
  store i32 %t165, ptr %l17, !tbaa !23
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  %t172 = load i32, ptr %l17, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v1, ptr %t171, i32 %t172)
  store i32 %t175, ptr %l105
  br label %bb34
bb34:
  %t176 = load i32, ptr %l105
  %t178 = trunc i64 3 to i32
  %t179 = icmp eq i32 %t176, %t178
  %t181 = xor i1 %t179, true
  br i1 %t181, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb39
bb36:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l111, !tbaa !29
  %t187 = load i32, ptr %l17, !tbaa !23
  %t189 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t187)
  store i64 %t189, ptr %l113
  br label %bb37
bb37:
  %t190 = load ptr, ptr %l111, !tbaa !29
  %t191 = load i64, ptr %l113, !tbaa !24
  %t192 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v1, ptr %t190, i64 %t191)
  store i64 %t192, ptr %l114
  br label %bb38
bb38:
  %t193 = load i64, ptr %l114, !tbaa !24
  %t194 = icmp sgt i64 %t193, 0
  store i1 %t194, ptr %l109, !tbaa !21
  br label %bb39
bb39:
  %t196 = load i1, ptr %l109, !tbaa !21
  br i1 %t196, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb41:
  br label %bb42
bb42:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t201 = load i32, ptr %l17, !tbaa !23
  %t204 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v1, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l119
  br label %bb43
bb43:
  %t205 = load i32, ptr %l119, !tbaa !23
  store i32 %t205, ptr %l18, !tbaa !23
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = load i32, ptr %l18, !tbaa !23
  %t215 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v1, ptr %t209, i32 %a2, i32 %t211)
  store i1 %t215, ptr %l124
  br label %bb44
bb44:
  %t216 = load i1, ptr %l124, !tbaa !21
  br i1 %t216, label %bb45, label %bb46
bb45:
  store ptr %l3, ptr %l125, !tbaa !29
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t218 = load i32, ptr %l18, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v1, ptr %s0, ptr %t217, i32 %t218)
  store { i64, ptr } %t221, ptr %l128
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t222 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = extractvalue { i64, ptr } %t222, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t229 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t229, { i64, ptr } %t228)
  br label %bb48
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb50:
  %t231 = load i64, ptr %l15, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l15, !tbaa !24
  br label %bb21
bb51:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb52:
  %t235 = load i64, ptr %l8, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l8, !tbaa !24
  br label %bb9
bb53:
  %t240 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l3)
  store i64 %t240, ptr %l135
  br label %bb54
bb54:
  %t241 = load i64, ptr %l135, !tbaa !24
  %t242 = icmp sgt i64 %t241, 0
  br i1 %t242, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %a0, ptr %l137, !tbaa !29
  %t246 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s10, ptr %s10, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store { i64, ptr } %t246, ptr %l139
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t247 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t249 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = add i64 %t248, %t251
  %t253 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t255 = add i64 %t252, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t247, i64 %t248)
  %t257 = getelementptr i8, ptr %t256, i64 %t248
  call void @olang_textcopy(ptr %t257, ptr %t250, i64 %t251)
  %t258 = getelementptr i8, ptr %t257, i64 %t251
  call void @olang_textcopy(ptr %t258, ptr %t253, i64 %t254)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t256, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } %t260, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  %t268 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s10, ptr %t268, { i64, ptr } %t267)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeArgs(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l28 = alloca i32
  %l35 = alloca i32
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 60)
  br label %bb2
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t13 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t9, i32 %a1)
  store { i64, ptr } %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb6:
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  store i32 %t33, ptr %l7, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l7, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l28
  br label %bb8
bb8:
  %t45 = load i32, ptr %l28
  %t47 = trunc i64 30 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l7, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb11
bb10:
  br label %bb20
bb11:
  %t60 = load i32, ptr %l35, !tbaa !23
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l2, ptr %l37, !tbaa !29
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb14, label %bb15
bb13:
  br label %bb19
bb14:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb16
bb15:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l7, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s4, ptr %t67, i32 %t68)
  store { i64, ptr } %t71, ptr %l43
  br label %bb17
bb17:
  %t72 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 1
  %t77 = extractvalue { i64, ptr } %t75, 0
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t73, i64 %t74)
  %t80 = getelementptr i8, ptr %t79, i64 %t74
  call void @olang_textcopy(ptr %t80, ptr %t76, i64 %t77)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } %t82, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  %t90 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t90, { i64, ptr } %t89)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb20:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb24:
  store ptr %l2, ptr %l49, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l7, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s2, ptr %t97, i32 %t98)
  store { i64, ptr } %t101, ptr %l52
  br label %bb25
bb25:
  %t102 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t109, { i64, ptr } %t108)
  br label %bb26
bb26:
  %t111 = load i64, ptr %l3, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t115 = load i64, ptr %l5, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l5, !tbaa !24
  br label %bb4
bb28:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 62)
  br label %bb29
bb29:
  %t121 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t121, ptr %l60
  br label %bb30
bb30:
  %t122 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t122, ptr %l61, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l62, !tbaa !24
  %t125 = load i64, ptr %l62, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l63, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l62, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t136, ptr %l61, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeItem(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca %"std/prelude/text:StringBuilder"
  %l59 = alloca i32
  %l63 = alloca i1
  %l68 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l84 = alloca i32
  %l94 = alloca ptr
  %l98 = alloca i64
  %l99 = alloca ptr
  %l114 = alloca { i64, ptr }
  %l120 = alloca i64
  %l123 = alloca i64
  %l141 = alloca ptr
  %l144 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l150 = alloca i64
  %l151 = alloca { i64, ptr }
  %l155 = alloca i64
  %l156 = alloca i64
  %l169 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l179 = alloca ptr
  %l182 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l190 = alloca i64
  %l191 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l201 = alloca i64
  %l207 = alloca ptr
  %l224 = alloca ptr
  %l225 = alloca i1
  %l235 = alloca ptr
  %l238 = alloca { i64, ptr }
  %l244 = alloca ptr
  %l247 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l257 = alloca i1
  %l269 = alloca { i64, ptr }
  %l272 = alloca ptr
  %l273 = alloca { i64, ptr }
  %l276 = alloca i64
  %l279 = alloca i64
  %l280 = alloca i64
  %l285 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l292 = alloca { i64, ptr }
  %l293 = alloca i64
  %l294 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l308 = alloca i32
  %l309 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l320 = alloca i64
  %l323 = alloca i64
  %l341 = alloca ptr
  %l343 = alloca { i64, ptr }
  %l346 = alloca { i64, ptr }
  %l353 = alloca i1
  %l354 = alloca { i64, ptr }
  %l361 = alloca ptr
  %l366 = alloca i1
  %l367 = alloca ptr
  %l368 = alloca ptr
  %l371 = alloca ptr
  %l374 = alloca ptr
  %l379 = alloca i32
  %l380 = alloca i32
  %l381 = alloca { i64, ptr }
  %l382 = alloca { i64, ptr }
  %l384 = alloca { i64, ptr }
  %l387 = alloca ptr
  %l388 = alloca ptr
  %l393 = alloca i32
  %l397 = alloca ptr
  %l402 = alloca { i64, ptr }
  %l403 = alloca i32
  %l404 = alloca { i64, ptr }
  %l405 = alloca ptr
  %l407 = alloca i64
  %l408 = alloca i64
  %l409 = alloca i64
  %l419 = alloca ptr
  %l420 = alloca { i64, ptr }
  %l424 = alloca i1
  %l425 = alloca { i64, ptr }
  %l426 = alloca ptr
  %l431 = alloca i32
  %l432 = alloca { i64, ptr }
  %l438 = alloca ptr
  %l444 = alloca ptr
  %l445 = alloca i1
  %l453 = alloca ptr
  %l454 = alloca ptr
  %l458 = alloca i32
  %l462 = alloca i32
  %l463 = alloca { i64, ptr }
  %l465 = alloca i64
  %l466 = alloca ptr
  %l468 = alloca i64
  %l469 = alloca i64
  %l473 = alloca { i64, ptr }
  %l475 = alloca i64
  %l477 = alloca i64
  %l478 = alloca i64
  %l483 = alloca { i64, ptr }
  %l489 = alloca ptr
  %l490 = alloca ptr
  %l494 = alloca i32
  %l498 = alloca ptr
  %l502 = alloca { i64, ptr }
  %l503 = alloca i32
  %l504 = alloca { i64, ptr }
  %l506 = alloca i64
  %l507 = alloca ptr
  %l508 = alloca { i64, ptr }
  %l510 = alloca i64
  %l511 = alloca i64
  %l515 = alloca { i64, ptr }
  %l517 = alloca i64
  %l519 = alloca i64
  %l520 = alloca i64
  %l525 = alloca { i64, ptr }
  %l531 = alloca ptr
  %l537 = alloca ptr
  %l538 = alloca i1
  %l547 = alloca ptr
  %l548 = alloca ptr
  %l553 = alloca ptr
  %l557 = alloca i64
  %l571 = alloca { i64, ptr }
  %l572 = alloca { i64, ptr }
  %l573 = alloca i64
  %l574 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l55
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l55
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l59
  br label %bb2
bb2:
  %t11 = load i32, ptr %l59, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l63
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l4, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  store ptr %t31, ptr %l68, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l73
  br label %bb4
bb4:
  %t42 = load ptr, ptr %l68, !tbaa !29
  %t43 = load i32, ptr %l73, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l74
  br label %bb5
bb5:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l75, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t48 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t46)
  store i64 %t48, ptr %l77
  br label %bb6
bb6:
  %t49 = load ptr, ptr %l75, !tbaa !29
  %t50 = load i64, ptr %l77, !tbaa !24
  %t51 = call { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %s0, ptr %t49, i64 %t50, i64 0)
  store { i64, ptr } %t51, ptr %l78
  br label %bb7
bb7:
  %t52 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = add i64 %t54, %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t53, i64 %t54)
  %t60 = getelementptr i8, ptr %t59, i64 %t54
  call void @olang_textcopy(ptr %t60, ptr %t56, i64 %t57)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  store { i64, ptr } %t62, ptr %l5, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l84
  br label %bb8
bb8:
  %t74 = load i32, ptr %l84
  store i32 %t74, ptr %l6
  %t75 = load i32, ptr %l6
  %t77 = trunc i64 5 to i32
  %t78 = icmp eq i32 %t75, %t77
  br i1 %t78, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t84 = extractvalue { i64, ptr } %t80, 1
  %t85 = extractvalue { i64, ptr } %t80, 0
  %t86 = add i64 %t82, %t85
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t81, i64 %t82)
  %t91 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t91, ptr %t84, i64 %t85)
  %t92 = getelementptr i8, ptr %t91, i64 %t85
  call void @olang_textcopy(ptr %t92, ptr %t87, i64 %t88)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t90, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t94, ptr %rv
  br label %ret
bb12:
  %t96 = load i32, ptr %l6
  %t98 = trunc i64 2 to i32
  %t99 = icmp eq i32 %t96, %t98
  br i1 %t99, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb56
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/load:Loader", ptr %t107, i32 0, i32 5
  store ptr %t109, ptr %l94, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t114 = load i32, ptr %l1, !tbaa !23
  %t117 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t113, i32 %t114)
  store i64 %t117, ptr %l98
  br label %bb16
bb16:
  %t118 = load ptr, ptr %l94, !tbaa !29
  %t119 = load i64, ptr %l98, !tbaa !24
  %t120 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t118, i64 %t119)
  store ptr %t120, ptr %l99
  br label %bb17
bb17:
  %t121 = load ptr, ptr %l99, !tbaa !29
  %t123 = getelementptr %"compiler/load:Module", ptr %t121, i32 0, i32 6
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l7, !tbaa !29
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t128 = icmp eq ptr %t126, null
  br i1 %t128, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a)
  unreachable
bb19:
  br label %bb20
bb20:
  %t130 = load ptr, ptr %l7, !tbaa !29
  %t133 = getelementptr %"compiler/source:Source", ptr %t130, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l8, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t137 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t140 = extractvalue { i64, ptr } %t136, 1
  %t141 = extractvalue { i64, ptr } %t136, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t137, i64 %t138)
  %t147 = getelementptr i8, ptr %t146, i64 %t138
  call void @olang_textcopy(ptr %t147, ptr %t140, i64 %t141)
  %t148 = getelementptr i8, ptr %t147, i64 %t141
  call void @olang_textcopy(ptr %t148, ptr %t143, i64 %t144)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t146, 1
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = extractvalue { i64, ptr } %t150, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l2, { i64, ptr } %t157)
  br label %bb21
bb21:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t164 = load i32, ptr %l1, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %t163, i32 %t164)
  store { i64, ptr } %t167, ptr %l114
  br label %bb22
bb22:
  %t168 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t168, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  store i64 %t171, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t173 = load i64, ptr %l11, !tbaa !24
  %t174 = load i64, ptr %l10, !tbaa !24
  %t177 = icmp sgt i64 %t173, %t174
  br i1 %t177, label %bb23, label %bb24
bb23:
  %t179 = load i64, ptr %l12, !tbaa !24
  %t181 = icmp sgt i64 %t179, 0
  br i1 %t181, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb28
bb25:
  %t183 = load i64, ptr %l11, !tbaa !24
  %t184 = load i64, ptr %l10, !tbaa !24
  %t187 = sub i64 %t183, %t184
  %t188 = load i64, ptr %l12, !tbaa !24
  %t191 = add i64 %t187, %t188
  %t193 = sub i64 %t191, 1
  %t194 = load i64, ptr %l12, !tbaa !24
  %t197 = sdiv i64 %t193, %t194
  store i64 %t197, ptr %l123, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb27
bb27:
  %t199 = load i64, ptr %l123, !tbaa !24
  store i64 %t199, ptr %l120, !tbaa !24
  br label %bb28
bb28:
  %t200 = load i64, ptr %l120, !tbaa !24
  store i64 %t200, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t201 = load i64, ptr %l14, !tbaa !24
  %t202 = load i64, ptr %l13, !tbaa !24
  %t205 = icmp slt i64 %t201, %t202
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb31:
  br label %bb32
bb32:
  %t209 = load i64, ptr %l10, !tbaa !24
  %t210 = load i64, ptr %l14, !tbaa !24
  %t211 = load i64, ptr %l12, !tbaa !24
  %t214 = mul i64 %t210, %t211
  %t217 = add i64 %t209, %t214
  store i64 %t217, ptr %l15, !tbaa !24
  store ptr %l2, ptr %l141, !tbaa !29
  %t219 = load i64, ptr %l15, !tbaa !24
  %t221 = icmp sgt i64 %t219, 0
  br i1 %t221, label %bb33, label %bb34
bb33:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l144, !tbaa !27
  br label %bb35
bb34:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l144, !tbaa !27
  br label %bb35
bb35:
  %t223 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t223, ptr %l145, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t224, ptr %l146, !tbaa !27
  %t225 = load i64, ptr %l15, !tbaa !24
  %t227 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr ptr, ptr %t228, i64 %t225
  %t230 = load ptr, ptr %t229, !tbaa !39
  %t232 = getelementptr %"compiler/ast:Path", ptr %t230, i32 0, i32 0
  %t233 = getelementptr %"compiler/source:Span", ptr %t232, i32 0, i32 0
  %t234 = load i32, ptr %t233, !tbaa !23
  %t236 = sext i32 %t234 to i64
  store i64 %t236, ptr %l150, !tbaa !24
  %t237 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t237, ptr %l151, !tbaa !27
  %t238 = load i64, ptr %l15, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr ptr, ptr %t241, i64 %t238
  %t243 = load ptr, ptr %t242, !tbaa !39
  %t245 = getelementptr %"compiler/ast:Path", ptr %t243, i32 0, i32 0
  %t246 = getelementptr %"compiler/source:Span", ptr %t245, i32 0, i32 1
  %t247 = load i32, ptr %t246, !tbaa !23
  %t249 = sext i32 %t247 to i64
  store i64 %t249, ptr %l155, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  store i64 %t251, ptr %l156, !tbaa !24
  %t252 = load i64, ptr %l150, !tbaa !24
  %t253 = icmp sge i64 %t252, 0
  br i1 %t253, label %bb36, label %bb37
bb36:
  %t255 = load i64, ptr %l150, !tbaa !24
  %t256 = load i64, ptr %l155, !tbaa !24
  %t257 = icmp sle i64 %t255, %t256
  br i1 %t257, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb38:
  %t259 = load i64, ptr %l155, !tbaa !24
  %t260 = load i64, ptr %l156, !tbaa !24
  %t261 = icmp sle i64 %t259, %t260
  br i1 %t261, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb40:
  %t263 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = load i64, ptr %l150, !tbaa !24
  %t266 = load i64, ptr %l155, !tbaa !24
  %t267 = getelementptr i8, ptr %t264, i64 %t265
  %t268 = sub i64 %t266, %t265
  %t269 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t267, 1
  %t271 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t275 = extractvalue { i64, ptr } %t270, 1
  %t276 = extractvalue { i64, ptr } %t270, 0
  %t277 = add i64 %t273, %t276
  %t278 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t277)
  call void @olang_textcopy(ptr %t278, ptr %t272, i64 %t273)
  %t279 = getelementptr i8, ptr %t278, i64 %t273
  call void @olang_textcopy(ptr %t279, ptr %t275, i64 %t276)
  %t280 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t278, 1
  %t283 = extractvalue { i64, ptr } %t281, 0
  %t284 = extractvalue { i64, ptr } %t281, 1
  %t285 = mul i64 %t283, 1
  %t286 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t285)
  call void @llvm.memcpy.p0.p0.i64(ptr %t286, ptr %t284, i64 %t285, i1 false)
  %t287 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  %t289 = load ptr, ptr %l141, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t289, { i64, ptr } %t288)
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f)
  unreachable
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb43:
  %t291 = load i64, ptr %l14, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l14, !tbaa !24
  br label %bb29
bb44:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) })
  br label %bb45
bb45:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/check:Checker", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t300 = load i32, ptr %l1, !tbaa !23
  %t303 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t299, i32 %t300)
  store { i64, ptr } %t303, ptr %l169
  br label %bb46
bb46:
  %t304 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t304, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t305 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t305, 0
  store i64 %t307, ptr %l18, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s11
  %t309 = load i64, ptr %l17, !tbaa !24
  %t310 = load i64, ptr %l18, !tbaa !24
  %t313 = icmp slt i64 %t309, %t310
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s11)
  br label %bb54
bb49:
  br label %bb50
bb50:
  %t317 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t317, ptr %l176, !tbaa !27
  %t318 = load i64, ptr %l17, !tbaa !24
  %t320 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr i32, ptr %t321, i64 %t318
  %t323 = load i32, ptr %t322, !tbaa !33
  store ptr %l2, ptr %l179, !tbaa !29
  %t325 = load ptr, ptr %l4, !tbaa !29
  %t329 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t325, i32 %t323)
  store { i64, ptr } %t329, ptr %l182
  br label %bb51
bb51:
  %t330 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t331 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t332 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 1
  %t334 = extractvalue { i64, ptr } %t332, 0
  %t335 = add i64 %t331, %t334
  %t336 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t337 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t338 = add i64 %t335, %t337
  %t339 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t338)
  call void @olang_textcopy(ptr %t339, ptr %t330, i64 %t331)
  %t340 = getelementptr i8, ptr %t339, i64 %t331
  call void @olang_textcopy(ptr %t340, ptr %t333, i64 %t334)
  %t341 = getelementptr i8, ptr %t340, i64 %t334
  call void @olang_textcopy(ptr %t341, ptr %t336, i64 %t337)
  %t342 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t339, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = extractvalue { i64, ptr } %t343, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  %t351 = load ptr, ptr %l179, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t351, { i64, ptr } %t350)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s11)
  br label %bb53
bb53:
  %t353 = load i64, ptr %l17, !tbaa !24
  %t355 = add i64 %t353, 1
  store i64 %t355, ptr %l17, !tbaa !24
  br label %bb47
bb54:
  %t358 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t358, ptr %l188
  br label %bb55
bb55:
  %t359 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t359, ptr %l189, !tbaa !27
  %t360 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t360, 0
  store i64 %t361, ptr %l190, !tbaa !24
  %t362 = load i64, ptr %l190, !tbaa !24
  %t363 = mul i64 %t362, 1
  %t364 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t363)
  %t365 = insertvalue { i64, ptr } undef, i64 %t362, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t364, 1
  store { i64, ptr } %t366, ptr %l191, !tbaa !27
  %t367 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = load i64, ptr %l190, !tbaa !24
  %t372 = mul i64 %t371, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t368, ptr %t370, i64 %t372, i1 false)
  %t373 = load { i64, ptr }, ptr %l191, !tbaa !27
  store { i64, ptr } %t373, ptr %l189, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t374 = load { i64, ptr }, ptr %l189, !tbaa !27
  store { i64, ptr } %t374, ptr %rv
  br label %ret
bb56:
  %t375 = load i32, ptr %l6
  %t377 = trunc i64 3 to i32
  %t378 = icmp eq i32 %t375, %t377
  br i1 %t378, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb121
bb59:
  store %olang.scope zeroinitializer, ptr %s14
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t384 = load i32, ptr %l1, !tbaa !23
  %t387 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t383, i32 %t384)
  store ptr %t387, ptr %l197
  br label %bb60
bb60:
  %t388 = load ptr, ptr %l197, !tbaa !29
  store ptr %t388, ptr %l20, !tbaa !29
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/check:Checker", ptr %t389, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !29
  %t393 = load i32, ptr %l1, !tbaa !23
  %t396 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t392, i32 %t393)
  store i64 %t396, ptr %l201
  br label %bb61
bb61:
  %t397 = load i64, ptr %l201, !tbaa !24
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/check:Checker", ptr %t398, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !29
  %t403 = getelementptr %"compiler/generic:Program", ptr %t401, i32 0, i32 0
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/load:Loader", ptr %t404, i32 0, i32 5
  %t410 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t406, i64 %t397)
  store ptr %t410, ptr %l207
  br label %bb62
bb62:
  %t411 = load ptr, ptr %l207, !tbaa !29
  %t413 = getelementptr %"compiler/load:Module", ptr %t411, i32 0, i32 6
  %t414 = load ptr, ptr %t413, !tbaa !29
  store ptr %t414, ptr %l22, !tbaa !29
  %t416 = load ptr, ptr %l22, !tbaa !29
  %t418 = icmp eq ptr %t416, null
  br i1 %t418, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_a185ff5f85e75430_c999a61f9f0eedcc)
  unreachable
bb64:
  br label %bb65
bb65:
  %t420 = load ptr, ptr %l22, !tbaa !29
  %t423 = getelementptr %"compiler/source:Source", ptr %t420, i32 0, i32 1
  %t424 = load { i64, ptr }, ptr %t423, !tbaa !27
  store { i64, ptr } %t424, ptr %l23, !tbaa !27
  %t426 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t427 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t428 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t430 = extractvalue { i64, ptr } %t426, 1
  %t431 = extractvalue { i64, ptr } %t426, 0
  %t432 = add i64 %t428, %t431
  %t433 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t434 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t435 = add i64 %t432, %t434
  %t436 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t435)
  call void @olang_textcopy(ptr %t436, ptr %t427, i64 %t428)
  %t437 = getelementptr i8, ptr %t436, i64 %t428
  call void @olang_textcopy(ptr %t437, ptr %t430, i64 %t431)
  %t438 = getelementptr i8, ptr %t437, i64 %t431
  call void @olang_textcopy(ptr %t438, ptr %t433, i64 %t434)
  %t439 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t436, 1
  %t442 = extractvalue { i64, ptr } %t440, 0
  %t443 = extractvalue { i64, ptr } %t440, 1
  %t444 = mul i64 %t442, 1
  %t445 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t444)
  call void @llvm.memcpy.p0.p0.i64(ptr %t445, ptr %t443, i64 %t444, i1 false)
  %t446 = insertvalue { i64, ptr } undef, i64 %t442, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t445, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l2, { i64, ptr } %t447)
  br label %bb66
bb66:
  %t450 = load ptr, ptr %l20, !tbaa !29
  %t452 = icmp eq ptr %t450, null
  br i1 %t452, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_60d3429e949e0f0f_c9b6e73225d64a3b)
  unreachable
bb68:
  br label %bb69
bb69:
  %t454 = load ptr, ptr %l20, !tbaa !29
  %t457 = getelementptr %"compiler/ast:TypeDecl", ptr %t454, i32 0, i32 3
  %t458 = load ptr, ptr %t457, !tbaa !29
  store ptr %t458, ptr %l24, !tbaa !29
  %t460 = load ptr, ptr %l24, !tbaa !29
  store ptr %t460, ptr %l224, !tbaa !29
  store i1 false, ptr %l225, !tbaa !21
  %t461 = load ptr, ptr %l224, !tbaa !29
  %t462 = icmp ne ptr %t461, null
  br i1 %t462, label %bb70, label %bb71
bb70:
  %t464 = load ptr, ptr %l224, !tbaa !29
  %t465 = load i64, ptr %t464
  %t467 = icmp eq i64 %t465, 2
  store i1 %t467, ptr %l225, !tbaa !21
  br label %bb71
bb71:
  %t468 = load i1, ptr %l225, !tbaa !21
  br i1 %t468, label %bb72, label %bb73
bb72:
  %t469 = load ptr, ptr %l24, !tbaa !29
  %t471 = getelementptr { i64, [6 x i64] }, ptr %t469, i32 0, i32 1
  %t472 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t471, i32 0, i32 1
  %t473 = load { i64, ptr }, ptr %t472
  store { i64, ptr } %t473, ptr %l25, !tbaa !27
  %t475 = load ptr, ptr %l24, !tbaa !29
  %t477 = getelementptr { i64, [6 x i64] }, ptr %t475, i32 0, i32 1
  %t478 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t477, i32 0, i32 2
  %t479 = load { i64, ptr }, ptr %t478
  store { i64, ptr } %t479, ptr %l26, !tbaa !27
  br label %bb74
bb73:
  br label %bb85
bb74:
  %t481 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t483 = extractvalue { i64, ptr } %t481, 0
  %t485 = icmp sgt i64 %t483, 0
  br i1 %t485, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s17
  store ptr %l2, ptr %l235, !tbaa !29
  %t487 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t488 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t491 = call { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v0, ptr %s17, { i64, ptr } %t487, { i64, ptr } %t488)
  store { i64, ptr } %t491, ptr %l238
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t492 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t493 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t494 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t495 = extractvalue { i64, ptr } %t494, 1
  %t496 = extractvalue { i64, ptr } %t494, 0
  %t497 = add i64 %t493, %t496
  %t498 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t497)
  call void @olang_textcopy(ptr %t498, ptr %t492, i64 %t493)
  %t499 = getelementptr i8, ptr %t498, i64 %t493
  call void @olang_textcopy(ptr %t499, ptr %t495, i64 %t496)
  %t500 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t498, 1
  %t503 = extractvalue { i64, ptr } %t501, 0
  %t504 = extractvalue { i64, ptr } %t501, 1
  %t505 = mul i64 %t503, 1
  %t506 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t505)
  call void @llvm.memcpy.p0.p0.i64(ptr %t506, ptr %t504, i64 %t505, i1 false)
  %t507 = insertvalue { i64, ptr } undef, i64 %t503, 0
  %t508 = insertvalue { i64, ptr } %t507, ptr %t506, 1
  %t509 = load ptr, ptr %l235, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s17, ptr %t509, { i64, ptr } %t508)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s17)
  br label %bb79
bb79:
  %t511 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t511, 0
  %t515 = icmp sgt i64 %t513, 0
  br i1 %t515, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s19
  store ptr %l2, ptr %l244, !tbaa !29
  %t517 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t518 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t521 = call { i64, ptr } @compiler_2fexplain_2elisted(ptr %v0, ptr %v0, ptr %s19, { i64, ptr } %t517, { i64, ptr } %t518)
  store { i64, ptr } %t521, ptr %l247
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t522 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t523 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t524 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t525 = extractvalue { i64, ptr } %t524, 1
  %t526 = extractvalue { i64, ptr } %t524, 0
  %t527 = add i64 %t523, %t526
  %t528 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t527)
  call void @olang_textcopy(ptr %t528, ptr %t522, i64 %t523)
  %t529 = getelementptr i8, ptr %t528, i64 %t523
  call void @olang_textcopy(ptr %t529, ptr %t525, i64 %t526)
  %t530 = insertvalue { i64, ptr } undef, i64 %t527, 0
  %t531 = insertvalue { i64, ptr } %t530, ptr %t528, 1
  %t533 = extractvalue { i64, ptr } %t531, 0
  %t534 = extractvalue { i64, ptr } %t531, 1
  %t535 = mul i64 %t533, 1
  %t536 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t535)
  call void @llvm.memcpy.p0.p0.i64(ptr %t536, ptr %t534, i64 %t535, i1 false)
  %t537 = insertvalue { i64, ptr } undef, i64 %t533, 0
  %t538 = insertvalue { i64, ptr } %t537, ptr %t536, 1
  %t539 = load ptr, ptr %l244, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s19, ptr %t539, { i64, ptr } %t538)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s19)
  br label %bb84
bb84:
  br label %bb90
bb85:
  br i1 true, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_9e7f77c067ece8f1_2a0afb54e00d35)
  unreachable
bb90:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb91
bb91:
  %t542 = load ptr, ptr %l20, !tbaa !29
  %t544 = icmp eq ptr %t542, null
  br i1 %t544, label %bb92, label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_7b101762ff8ffda9_ced5d247097fb61d)
  unreachable
bb93:
  br label %bb94
bb94:
  %t546 = load ptr, ptr %l20, !tbaa !29
  %t549 = getelementptr %"compiler/ast:TypeDecl", ptr %t546, i32 0, i32 3
  %t550 = load ptr, ptr %t549, !tbaa !29
  store ptr %t550, ptr %l27, !tbaa !29
  %t552 = load ptr, ptr %l27, !tbaa !29
  store ptr %t552, ptr %l256, !tbaa !29
  store i1 false, ptr %l257, !tbaa !21
  %t553 = load ptr, ptr %l256, !tbaa !29
  %t554 = icmp ne ptr %t553, null
  br i1 %t554, label %bb95, label %bb96
bb95:
  %t556 = load ptr, ptr %l256, !tbaa !29
  %t557 = load i64, ptr %t556
  %t559 = icmp eq i64 %t557, 2
  store i1 %t559, ptr %l257, !tbaa !21
  br label %bb96
bb96:
  %t560 = load i1, ptr %l257, !tbaa !21
  br i1 %t560, label %bb97, label %bb98
bb97:
  %t561 = load ptr, ptr %l27, !tbaa !29
  %t563 = getelementptr { i64, [6 x i64] }, ptr %t561, i32 0, i32 1
  %t564 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t563, i32 0, i32 0
  %t565 = load { i64, ptr }, ptr %t564
  store { i64, ptr } %t565, ptr %l28, !tbaa !27
  br label %bb99
bb98:
  br label %bb114
bb99:
  %t567 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t567, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t569 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t571 = extractvalue { i64, ptr } %t569, 0
  store i64 %t571, ptr %l31, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s24
  %t573 = load i64, ptr %l30, !tbaa !24
  %t574 = load i64, ptr %l31, !tbaa !24
  %t577 = icmp slt i64 %t573, %t574
  %t579 = xor i1 %t577, true
  br i1 %t579, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s24)
  br label %bb113
bb102:
  br label %bb103
bb103:
  %t581 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t581, ptr %l269, !tbaa !27
  %t582 = load i64, ptr %l30, !tbaa !24
  %t584 = getelementptr { i64, ptr }, ptr %l269, i32 0, i32 1
  %t585 = load ptr, ptr %t584, !tbaa !27
  %t586 = getelementptr ptr, ptr %t585, i64 %t582
  %t587 = load ptr, ptr %t586, !tbaa !39
  store ptr %t587, ptr %l32, !tbaa !29
  store ptr %l2, ptr %l272, !tbaa !29
  %t589 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t589, ptr %l273, !tbaa !27
  %t590 = load ptr, ptr %l32, !tbaa !29
  %t592 = getelementptr %"compiler/ast:Func", ptr %t590, i32 0, i32 0
  %t593 = getelementptr %"compiler/source:Span", ptr %t592, i32 0, i32 0
  %t594 = load i32, ptr %t593, !tbaa !23
  %t596 = sext i32 %t594 to i64
  store i64 %t596, ptr %l276, !tbaa !24
  %t597 = load ptr, ptr %l32, !tbaa !29
  %t599 = getelementptr %"compiler/ast:Func", ptr %t597, i32 0, i32 0
  %t600 = getelementptr %"compiler/source:Span", ptr %t599, i32 0, i32 1
  %t601 = load i32, ptr %t600, !tbaa !23
  %t603 = sext i32 %t601 to i64
  store i64 %t603, ptr %l279, !tbaa !24
  %t604 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t605 = extractvalue { i64, ptr } %t604, 0
  store i64 %t605, ptr %l280, !tbaa !24
  %t606 = load i64, ptr %l276, !tbaa !24
  %t607 = icmp sge i64 %t606, 0
  br i1 %t607, label %bb104, label %bb105
bb104:
  %t609 = load i64, ptr %l276, !tbaa !24
  %t610 = load i64, ptr %l279, !tbaa !24
  %t611 = icmp sle i64 %t609, %t610
  br i1 %t611, label %bb106, label %bb107
bb105:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb106:
  %t613 = load i64, ptr %l279, !tbaa !24
  %t614 = load i64, ptr %l280, !tbaa !24
  %t615 = icmp sle i64 %t613, %t614
  br i1 %t615, label %bb108, label %bb109
bb107:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb108:
  %t617 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t618 = load ptr, ptr %t617, !tbaa !27
  %t619 = load i64, ptr %l276, !tbaa !24
  %t620 = load i64, ptr %l279, !tbaa !24
  %t621 = getelementptr i8, ptr %t618, i64 %t619
  %t622 = sub i64 %t620, %t619
  %t623 = insertvalue { i64, ptr } undef, i64 %t622, 0
  %t624 = insertvalue { i64, ptr } %t623, ptr %t621, 1
  %t626 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t624)
  store { i64, ptr } %t626, ptr %l285
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_e7cf316846733e6c_5d444c1e6a143730)
  unreachable
bb110:
  %t627 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t628 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t629 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t630 = extractvalue { i64, ptr } %t629, 1
  %t631 = extractvalue { i64, ptr } %t629, 0
  %t632 = add i64 %t628, %t631
  %t633 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t634 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t635 = add i64 %t632, %t634
  %t636 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t635)
  call void @olang_textcopy(ptr %t636, ptr %t627, i64 %t628)
  %t637 = getelementptr i8, ptr %t636, i64 %t628
  call void @olang_textcopy(ptr %t637, ptr %t630, i64 %t631)
  %t638 = getelementptr i8, ptr %t637, i64 %t631
  call void @olang_textcopy(ptr %t638, ptr %t633, i64 %t634)
  %t639 = insertvalue { i64, ptr } undef, i64 %t635, 0
  %t640 = insertvalue { i64, ptr } %t639, ptr %t636, 1
  %t642 = extractvalue { i64, ptr } %t640, 0
  %t643 = extractvalue { i64, ptr } %t640, 1
  %t644 = mul i64 %t642, 1
  %t645 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t644)
  call void @llvm.memcpy.p0.p0.i64(ptr %t645, ptr %t643, i64 %t644, i1 false)
  %t646 = insertvalue { i64, ptr } undef, i64 %t642, 0
  %t647 = insertvalue { i64, ptr } %t646, ptr %t645, 1
  %t648 = load ptr, ptr %l272, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s24, ptr %t648, { i64, ptr } %t647)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s24)
  br label %bb112
bb112:
  %t650 = load i64, ptr %l30, !tbaa !24
  %t652 = add i64 %t650, 1
  store i64 %t652, ptr %l30, !tbaa !24
  br label %bb100
bb113:
  br label %bb119
bb114:
  br i1 true, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb119
bb118:
  call void @__olang_check_failed(ptr @olang_loc_4e8cd845c965dada_c1eb458e34ff6f7e)
  unreachable
bb119:
  %t655 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t655, ptr %l291
  br label %bb120
bb120:
  %t656 = load { i64, ptr }, ptr %l291, !tbaa !27
  store { i64, ptr } %t656, ptr %l292, !tbaa !27
  %t657 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t658 = extractvalue { i64, ptr } %t657, 0
  store i64 %t658, ptr %l293, !tbaa !24
  %t659 = load i64, ptr %l293, !tbaa !24
  %t660 = mul i64 %t659, 1
  %t661 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t660)
  %t662 = insertvalue { i64, ptr } undef, i64 %t659, 0
  %t663 = insertvalue { i64, ptr } %t662, ptr %t661, 1
  store { i64, ptr } %t663, ptr %l294, !tbaa !27
  %t664 = getelementptr { i64, ptr }, ptr %l294, i32 0, i32 1
  %t665 = load ptr, ptr %t664, !tbaa !27
  %t666 = getelementptr { i64, ptr }, ptr %l292, i32 0, i32 1
  %t667 = load ptr, ptr %t666, !tbaa !27
  %t668 = load i64, ptr %l293, !tbaa !24
  %t669 = mul i64 %t668, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t665, ptr %t667, i64 %t669, i1 false)
  %t670 = load { i64, ptr }, ptr %l294, !tbaa !27
  store { i64, ptr } %t670, ptr %l292, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t671 = load { i64, ptr }, ptr %l292, !tbaa !27
  store { i64, ptr } %t671, ptr %rv
  br label %ret
bb121:
  %t672 = load i32, ptr %l6
  %t674 = trunc i64 1 to i32
  %t675 = icmp eq i32 %t672, %t674
  br i1 %t675, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb179
bb124:
  store %olang.scope zeroinitializer, ptr %s28
  %t677 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t678 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t679 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t681 = extractvalue { i64, ptr } %t677, 1
  %t682 = extractvalue { i64, ptr } %t677, 0
  %t683 = add i64 %t679, %t682
  %t684 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t685 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t686 = add i64 %t683, %t685
  %t687 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t686)
  call void @olang_textcopy(ptr %t687, ptr %t678, i64 %t679)
  %t688 = getelementptr i8, ptr %t687, i64 %t679
  call void @olang_textcopy(ptr %t688, ptr %t681, i64 %t682)
  %t689 = getelementptr i8, ptr %t688, i64 %t682
  call void @olang_textcopy(ptr %t689, ptr %t684, i64 %t685)
  %t690 = insertvalue { i64, ptr } undef, i64 %t686, 0
  %t691 = insertvalue { i64, ptr } %t690, ptr %t687, 1
  %t693 = extractvalue { i64, ptr } %t691, 0
  %t694 = extractvalue { i64, ptr } %t691, 1
  %t695 = mul i64 %t693, 1
  %t696 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t695)
  call void @llvm.memcpy.p0.p0.i64(ptr %t696, ptr %t694, i64 %t695, i1 false)
  %t697 = insertvalue { i64, ptr } undef, i64 %t693, 0
  %t698 = insertvalue { i64, ptr } %t697, ptr %t696, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s28, ptr %l2, { i64, ptr } %t698)
  br label %bb125
bb125:
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t703 = getelementptr %"compiler/check:Checker", ptr %t701, i32 0, i32 1
  %t704 = load ptr, ptr %t703, !tbaa !29
  %t706 = getelementptr %"compiler/generic:Program", ptr %t704, i32 0, i32 2
  store ptr %t706, ptr %l303, !tbaa !29
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t709 = getelementptr %"compiler/check:Checker", ptr %t707, i32 0, i32 1
  %t710 = load ptr, ptr %t709, !tbaa !29
  %t712 = getelementptr %"compiler/generic:Program", ptr %t710, i32 0, i32 2
  %t713 = load i32, ptr %l3, !tbaa !23
  %t716 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t712, i32 %t713)
  store i32 %t716, ptr %l308
  br label %bb126
bb126:
  %t717 = load ptr, ptr %l303, !tbaa !29
  %t718 = load i32, ptr %l308, !tbaa !23
  %t719 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t717, i32 %t718)
  store { i64, ptr } %t719, ptr %l309
  br label %bb127
bb127:
  %t720 = load { i64, ptr }, ptr %l309, !tbaa !27
  store { i64, ptr } %t720, ptr %l33, !tbaa !27
  %t721 = load ptr, ptr %l0, !tbaa !29
  %t723 = getelementptr %"compiler/check:Checker", ptr %t721, i32 0, i32 1
  %t724 = load ptr, ptr %t723, !tbaa !29
  %t726 = getelementptr %"compiler/generic:Program", ptr %t724, i32 0, i32 2
  %t727 = load i32, ptr %l3, !tbaa !23
  %t730 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t726, i32 %t727)
  store { i64, ptr } %t730, ptr %l314
  br label %bb128
bb128:
  %t731 = load { i64, ptr }, ptr %l314, !tbaa !27
  store { i64, ptr } %t731, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t732 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t734 = extractvalue { i64, ptr } %t732, 0
  store i64 %t734, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t736 = load i64, ptr %l36, !tbaa !24
  %t737 = load i64, ptr %l35, !tbaa !24
  %t740 = icmp sgt i64 %t736, %t737
  br i1 %t740, label %bb129, label %bb130
bb129:
  %t742 = load i64, ptr %l37, !tbaa !24
  %t744 = icmp sgt i64 %t742, 0
  br i1 %t744, label %bb131, label %bb132
bb130:
  store i64 0, ptr %l320, !tbaa !24
  br label %bb134
bb131:
  %t746 = load i64, ptr %l36, !tbaa !24
  %t747 = load i64, ptr %l35, !tbaa !24
  %t750 = sub i64 %t746, %t747
  %t751 = load i64, ptr %l37, !tbaa !24
  %t754 = add i64 %t750, %t751
  %t756 = sub i64 %t754, 1
  %t757 = load i64, ptr %l37, !tbaa !24
  %t760 = sdiv i64 %t756, %t757
  store i64 %t760, ptr %l323, !tbaa !24
  br label %bb133
bb132:
  store i64 0, ptr %l323, !tbaa !24
  br label %bb133
bb133:
  %t762 = load i64, ptr %l323, !tbaa !24
  store i64 %t762, ptr %l320, !tbaa !24
  br label %bb134
bb134:
  %t763 = load i64, ptr %l320, !tbaa !24
  store i64 %t763, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb135
bb135:
  store %olang.scope zeroinitializer, ptr %s31
  %t764 = load i64, ptr %l39, !tbaa !24
  %t765 = load i64, ptr %l38, !tbaa !24
  %t768 = icmp slt i64 %t764, %t765
  %t770 = xor i1 %t768, true
  br i1 %t770, label %bb136, label %bb137
bb136:
  call void @__olang_scope_close(ptr %s31)
  br label %bb178
bb137:
  br label %bb138
bb138:
  %t772 = load i64, ptr %l35, !tbaa !24
  %t773 = load i64, ptr %l39, !tbaa !24
  %t774 = load i64, ptr %l37, !tbaa !24
  %t777 = mul i64 %t773, %t774
  %t780 = add i64 %t772, %t777
  store i64 %t780, ptr %l40, !tbaa !24
  store ptr %l2, ptr %l341, !tbaa !29
  %t782 = load ptr, ptr %l4, !tbaa !29
  %t783 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t783, ptr %l343, !tbaa !27
  %t784 = load i64, ptr %l40, !tbaa !24
  %t786 = getelementptr { i64, ptr }, ptr %l343, i32 0, i32 1
  %t787 = load ptr, ptr %t786, !tbaa !27
  %t788 = getelementptr i32, ptr %t787, i64 %t784
  %t789 = load i32, ptr %t788, !tbaa !33
  %t792 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t782, i32 %t789)
  store { i64, ptr } %t792, ptr %l346
  br label %bb139
bb139:
  %t793 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t794 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t795 = load { i64, ptr }, ptr %l346, !tbaa !27
  %t796 = extractvalue { i64, ptr } %t795, 1
  %t797 = extractvalue { i64, ptr } %t795, 0
  %t798 = add i64 %t794, %t797
  %t799 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t798)
  call void @olang_textcopy(ptr %t799, ptr %t793, i64 %t794)
  %t800 = getelementptr i8, ptr %t799, i64 %t794
  call void @olang_textcopy(ptr %t800, ptr %t796, i64 %t797)
  %t801 = insertvalue { i64, ptr } undef, i64 %t798, 0
  %t802 = insertvalue { i64, ptr } %t801, ptr %t799, 1
  %t804 = extractvalue { i64, ptr } %t802, 0
  %t805 = extractvalue { i64, ptr } %t802, 1
  %t806 = mul i64 %t804, 1
  %t807 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t806)
  call void @llvm.memcpy.p0.p0.i64(ptr %t807, ptr %t805, i64 %t806, i1 false)
  %t808 = insertvalue { i64, ptr } undef, i64 %t804, 0
  %t809 = insertvalue { i64, ptr } %t808, ptr %t807, 1
  %t810 = load ptr, ptr %l341, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s31, ptr %t810, { i64, ptr } %t809)
  br label %bb140
bb140:
  %t812 = load i64, ptr %l40, !tbaa !24
  %t813 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t815 = extractvalue { i64, ptr } %t813, 0
  %t818 = icmp slt i64 %t812, %t815
  br i1 %t818, label %bb141, label %bb142
bb141:
  %t820 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t820, ptr %l354, !tbaa !27
  %t821 = load i64, ptr %l40, !tbaa !24
  %t823 = getelementptr { i64, ptr }, ptr %l354, i32 0, i32 1
  %t824 = load ptr, ptr %t823, !tbaa !27
  %t825 = getelementptr i32, ptr %t824, i64 %t821
  %t826 = load i32, ptr %t825, !tbaa !33
  %t828 = icmp ne i32 %t826, 0
  store i1 %t828, ptr %l353, !tbaa !21
  br label %bb143
bb142:
  store i1 false, ptr %l353, !tbaa !21
  br label %bb143
bb143:
  %t830 = load i1, ptr %l353, !tbaa !21
  br i1 %t830, label %bb144, label %bb145
bb144:
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t833 = getelementptr %"compiler/check:Checker", ptr %t831, i32 0, i32 1
  %t834 = load ptr, ptr %t833, !tbaa !29
  %t835 = load i32, ptr %l1, !tbaa !23
  %t838 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t834, i32 %t835)
  store ptr %t838, ptr %l361
  br label %bb146
bb145:
  br label %bb175
bb146:
  %t839 = load ptr, ptr %l361, !tbaa !29
  store ptr %t839, ptr %l41, !tbaa !29
  %t840 = load ptr, ptr %l41, !tbaa !29
  %t842 = icmp eq ptr %t840, null
  br i1 %t842, label %bb147, label %bb148
bb147:
  call void @__olang_check_failed(ptr @olang_loc_12615553f525a8d6_4928bb51d62e2722)
  unreachable
bb148:
  br label %bb149
bb149:
  %t844 = load ptr, ptr %l41, !tbaa !29
  %t845 = load i64, ptr %l40, !tbaa !24
  %t848 = call i1 @compiler_2fexplain_2ecaseWhole(ptr %v0, ptr %t844, i64 %t845)
  store i1 %t848, ptr %l366
  br label %bb150
bb150:
  %t849 = load i1, ptr %l366, !tbaa !21
  br i1 %t849, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s34
  store ptr %l2, ptr %l367, !tbaa !29
  %t850 = load ptr, ptr %l0, !tbaa !29
  store ptr %t850, ptr %l368, !tbaa !29
  %t851 = load ptr, ptr %l0, !tbaa !29
  %t853 = getelementptr %"compiler/check:Checker", ptr %t851, i32 0, i32 1
  %t854 = load ptr, ptr %t853, !tbaa !29
  %t856 = getelementptr %"compiler/generic:Program", ptr %t854, i32 0, i32 2
  store ptr %t856, ptr %l371, !tbaa !29
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t859 = getelementptr %"compiler/check:Checker", ptr %t857, i32 0, i32 1
  %t860 = load ptr, ptr %t859, !tbaa !29
  %t862 = getelementptr %"compiler/generic:Program", ptr %t860, i32 0, i32 2
  store ptr %t862, ptr %l374, !tbaa !29
  %t863 = load ptr, ptr %l0, !tbaa !29
  %t865 = getelementptr %"compiler/check:Checker", ptr %t863, i32 0, i32 1
  %t866 = load ptr, ptr %t865, !tbaa !29
  %t867 = load i32, ptr %l3, !tbaa !23
  %t868 = load i64, ptr %l40, !tbaa !24
  %t872 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t866, i32 %t867, i64 %t868)
  store i32 %t872, ptr %l379
  br label %bb153
bb152:
  store %olang.scope zeroinitializer, ptr %s36
  %t873 = load ptr, ptr %l0, !tbaa !29
  store ptr %t873, ptr %l387, !tbaa !29
  %t874 = load ptr, ptr %l0, !tbaa !29
  store ptr %t874, ptr %l388, !tbaa !29
  %t875 = load ptr, ptr %l0, !tbaa !29
  %t877 = getelementptr %"compiler/check:Checker", ptr %t875, i32 0, i32 1
  %t878 = load ptr, ptr %t877, !tbaa !29
  %t879 = load i32, ptr %l3, !tbaa !23
  %t880 = load i64, ptr %l40, !tbaa !24
  %t884 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t878, i32 %t879, i64 %t880)
  store i32 %t884, ptr %l393
  br label %bb158
bb153:
  %t885 = load ptr, ptr %l374, !tbaa !29
  %t886 = load i32, ptr %l379, !tbaa !23
  %t887 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t885, i32 %t886)
  store i32 %t887, ptr %l380
  br label %bb154
bb154:
  %t888 = load ptr, ptr %l371, !tbaa !29
  %t889 = load i32, ptr %l380, !tbaa !23
  %t890 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t888, i32 %t889)
  store { i64, ptr } %t890, ptr %l381
  br label %bb155
bb155:
  %t891 = load { i64, ptr }, ptr %l381, !tbaa !27
  store { i64, ptr } %t891, ptr %l382, !tbaa !27
  %t892 = getelementptr { i64, ptr }, ptr %l382, i32 0, i32 1
  %t893 = load ptr, ptr %t892, !tbaa !27
  %t894 = getelementptr i32, ptr %t893, i64 0
  %t895 = load i32, ptr %t894, !tbaa !33
  %t896 = load ptr, ptr %l368, !tbaa !29
  %t898 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s34, ptr %t896, i32 %t895)
  store { i64, ptr } %t898, ptr %l384
  br label %bb156
bb156:
  %t899 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t900 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t901 = load { i64, ptr }, ptr %l384, !tbaa !27
  %t902 = extractvalue { i64, ptr } %t901, 1
  %t903 = extractvalue { i64, ptr } %t901, 0
  %t904 = add i64 %t900, %t903
  %t905 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t904)
  call void @olang_textcopy(ptr %t905, ptr %t899, i64 %t900)
  %t906 = getelementptr i8, ptr %t905, i64 %t900
  call void @olang_textcopy(ptr %t906, ptr %t902, i64 %t903)
  %t907 = insertvalue { i64, ptr } undef, i64 %t904, 0
  %t908 = insertvalue { i64, ptr } %t907, ptr %t905, 1
  %t910 = extractvalue { i64, ptr } %t908, 0
  %t911 = extractvalue { i64, ptr } %t908, 1
  %t912 = mul i64 %t910, 1
  %t913 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t912)
  call void @llvm.memcpy.p0.p0.i64(ptr %t913, ptr %t911, i64 %t912, i1 false)
  %t914 = insertvalue { i64, ptr } undef, i64 %t910, 0
  %t915 = insertvalue { i64, ptr } %t914, ptr %t913, 1
  %t916 = load ptr, ptr %l367, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s34, ptr %t916, { i64, ptr } %t915)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s34)
  br label %bb174
bb158:
  %t918 = load ptr, ptr %l0, !tbaa !29
  %t920 = getelementptr %"compiler/check:Checker", ptr %t918, i32 0, i32 1
  %t921 = load ptr, ptr %t920, !tbaa !29
  %t922 = load i32, ptr %l1, !tbaa !23
  %t925 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t921, i32 %t922)
  store ptr %t925, ptr %l397
  br label %bb159
bb159:
  %t926 = load ptr, ptr %l397, !tbaa !29
  store ptr %t926, ptr %l42, !tbaa !29
  %t927 = load ptr, ptr %l42, !tbaa !29
  %t929 = icmp eq ptr %t927, null
  br i1 %t929, label %bb160, label %bb161
bb160:
  call void @__olang_check_failed(ptr @olang_loc_4a756130778b14bd_8f8d371a853a3189)
  unreachable
bb161:
  br label %bb162
bb162:
  %t931 = load ptr, ptr %l42, !tbaa !29
  %t932 = load i64, ptr %l40, !tbaa !24
  %t935 = call { i64, ptr } @compiler_2fexplain_2ecasePayload(ptr %v0, ptr %t931, i64 %t932)
  store { i64, ptr } %t935, ptr %l402
  br label %bb163
bb163:
  %t936 = load ptr, ptr %l388, !tbaa !29
  %t937 = load i32, ptr %l393, !tbaa !23
  %t938 = load { i64, ptr }, ptr %l402, !tbaa !27
  %t939 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s36, ptr %v0, ptr %t936, i32 %t937, ptr null, { i64, ptr } %t938)
  store i32 %t939, ptr %l403
  br label %bb164
bb164:
  %t940 = load ptr, ptr %l387, !tbaa !29
  %t941 = load i32, ptr %l403, !tbaa !23
  %t942 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s36, ptr %t940, i32 %t941)
  store { i64, ptr } %t942, ptr %l404
  br label %bb165
bb165:
  %t943 = load { i64, ptr }, ptr %l404, !tbaa !27
  store { i64, ptr } %t943, ptr %l43, !tbaa !27
  store ptr %l2, ptr %l405, !tbaa !29
  %t944 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t946 = call i64 @compiler_2fexplain_2efirstClose(ptr %s36, { i64, ptr } %t944)
  store i64 %t946, ptr %l407
  br label %bb166
bb166:
  %t947 = load i64, ptr %l407, !tbaa !24
  %t948 = add i64 %t947, 1
  store i64 %t948, ptr %l408, !tbaa !24
  %t949 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t950 = extractvalue { i64, ptr } %t949, 0
  store i64 %t950, ptr %l409, !tbaa !24
  %t951 = icmp sge i64 2, 0
  br i1 %t951, label %bb167, label %bb168
bb167:
  %t953 = load i64, ptr %l408, !tbaa !24
  %t954 = icmp sle i64 2, %t953
  br i1 %t954, label %bb169, label %bb170
bb168:
  call void @__olang_check_failed(ptr @olang_loc_b6c637a5f4084e9b_d531d6adfcd75e3f)
  unreachable
bb169:
  %t956 = load i64, ptr %l408, !tbaa !24
  %t957 = load i64, ptr %l409, !tbaa !24
  %t958 = icmp sle i64 %t956, %t957
  br i1 %t958, label %bb171, label %bb172
bb170:
  call void @__olang_check_failed(ptr @olang_loc_b6c637a5f4084e9b_d531d6adfcd75e3f)
  unreachable
bb171:
  %t960 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t961 = load ptr, ptr %t960, !tbaa !27
  %t962 = load i64, ptr %l408, !tbaa !24
  %t963 = getelementptr i8, ptr %t961, i64 2
  %t964 = sub i64 %t962, 2
  %t965 = insertvalue { i64, ptr } undef, i64 %t964, 0
  %t966 = insertvalue { i64, ptr } %t965, ptr %t963, 1
  %t967 = load ptr, ptr %l405, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s36, ptr %t967, { i64, ptr } %t966)
  br label %bb173
bb172:
  call void @__olang_check_failed(ptr @olang_loc_b6c637a5f4084e9b_d531d6adfcd75e3f)
  unreachable
bb173:
  call void @__olang_scope_close(ptr %s36)
  br label %bb174
bb174:
  br label %bb175
bb175:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb176
bb176:
  call void @__olang_scope_close(ptr %s31)
  br label %bb177
bb177:
  %t970 = load i64, ptr %l39, !tbaa !24
  %t972 = add i64 %t970, 1
  store i64 %t972, ptr %l39, !tbaa !24
  br label %bb135
bb178:
  call void @__olang_scope_close(ptr %s28)
  br label %bb279
bb179:
  %t974 = load i32, ptr %l6
  %t976 = trunc i64 4 to i32
  %t977 = icmp eq i32 %t974, %t976
  br i1 %t977, label %bb180, label %bb181
bb180:
  br label %bb182
bb181:
  br label %bb227
bb182:
  store %olang.scope zeroinitializer, ptr %s38
  store ptr %l2, ptr %l419, !tbaa !29
  %t979 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t979, ptr %l420, !tbaa !27
  %t980 = load ptr, ptr %l0, !tbaa !29
  %t982 = getelementptr %"compiler/check:Checker", ptr %t980, i32 0, i32 1
  %t983 = load ptr, ptr %t982, !tbaa !29
  %t984 = load i32, ptr %l3, !tbaa !23
  %t987 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t983, i32 %t984)
  store i1 %t987, ptr %l424
  br label %bb183
bb183:
  %t988 = load i1, ptr %l424, !tbaa !21
  br i1 %t988, label %bb184, label %bb185
bb184:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %l425, !tbaa !27
  br label %bb186
bb185:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %l425, !tbaa !27
  br label %bb186
bb186:
  %t989 = load ptr, ptr %l0, !tbaa !29
  store ptr %t989, ptr %l426, !tbaa !29
  %t990 = load ptr, ptr %l0, !tbaa !29
  %t992 = getelementptr %"compiler/check:Checker", ptr %t990, i32 0, i32 1
  %t993 = load ptr, ptr %t992, !tbaa !29
  %t995 = getelementptr %"compiler/generic:Program", ptr %t993, i32 0, i32 2
  %t996 = load i32, ptr %l3, !tbaa !23
  %t999 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t995, i32 %t996)
  store i32 %t999, ptr %l431
  br label %bb187
bb187:
  %t1000 = load ptr, ptr %l426, !tbaa !29
  %t1001 = load i32, ptr %l431, !tbaa !23
  %t1002 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s38, ptr %t1000, i32 %t1001)
  store { i64, ptr } %t1002, ptr %l432
  br label %bb188
bb188:
  %t1003 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t1004 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t1005 = load { i64, ptr }, ptr %l420, !tbaa !27
  %t1006 = extractvalue { i64, ptr } %t1005, 1
  %t1007 = extractvalue { i64, ptr } %t1005, 0
  %t1008 = add i64 %t1004, %t1007
  %t1009 = load { i64, ptr }, ptr %l425, !tbaa !27
  %t1010 = extractvalue { i64, ptr } %t1009, 1
  %t1011 = extractvalue { i64, ptr } %t1009, 0
  %t1012 = add i64 %t1008, %t1011
  %t1013 = load { i64, ptr }, ptr %l432, !tbaa !27
  %t1014 = extractvalue { i64, ptr } %t1013, 1
  %t1015 = extractvalue { i64, ptr } %t1013, 0
  %t1016 = add i64 %t1012, %t1015
  %t1017 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t1016)
  call void @olang_textcopy(ptr %t1017, ptr %t1003, i64 %t1004)
  %t1018 = getelementptr i8, ptr %t1017, i64 %t1004
  call void @olang_textcopy(ptr %t1018, ptr %t1006, i64 %t1007)
  %t1019 = getelementptr i8, ptr %t1018, i64 %t1007
  call void @olang_textcopy(ptr %t1019, ptr %t1010, i64 %t1011)
  %t1020 = getelementptr i8, ptr %t1019, i64 %t1011
  call void @olang_textcopy(ptr %t1020, ptr %t1014, i64 %t1015)
  %t1021 = insertvalue { i64, ptr } undef, i64 %t1016, 0
  %t1022 = insertvalue { i64, ptr } %t1021, ptr %t1017, 1
  %t1024 = extractvalue { i64, ptr } %t1022, 0
  %t1025 = extractvalue { i64, ptr } %t1022, 1
  %t1026 = mul i64 %t1024, 1
  %t1027 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t1026)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1027, ptr %t1025, i64 %t1026, i1 false)
  %t1028 = insertvalue { i64, ptr } undef, i64 %t1024, 0
  %t1029 = insertvalue { i64, ptr } %t1028, ptr %t1027, 1
  %t1030 = load ptr, ptr %l419, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s38, ptr %t1030, { i64, ptr } %t1029)
  br label %bb189
bb189:
  %t1032 = load ptr, ptr %l0, !tbaa !29
  %t1034 = getelementptr %"compiler/check:Checker", ptr %t1032, i32 0, i32 1
  %t1035 = load ptr, ptr %t1034, !tbaa !29
  %t1036 = load i32, ptr %l1, !tbaa !23
  %t1039 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t1035, i32 %t1036)
  store ptr %t1039, ptr %l438
  br label %bb190
bb190:
  %t1040 = load ptr, ptr %l438, !tbaa !29
  store ptr %t1040, ptr %l44, !tbaa !29
  %t1041 = load ptr, ptr %l44, !tbaa !29
  %t1043 = icmp eq ptr %t1041, null
  br i1 %t1043, label %bb191, label %bb192
bb191:
  call void @__olang_check_failed(ptr @olang_loc_fdc41c6a76f01a06_9680a398378cbf4a)
  unreachable
bb192:
  br label %bb193
bb193:
  %t1045 = load ptr, ptr %l44, !tbaa !29
  %t1048 = getelementptr %"compiler/ast:TypeDecl", ptr %t1045, i32 0, i32 3
  %t1049 = load ptr, ptr %t1048, !tbaa !29
  store ptr %t1049, ptr %l45, !tbaa !29
  %t1051 = load ptr, ptr %l45, !tbaa !29
  store ptr %t1051, ptr %l444, !tbaa !29
  store i1 false, ptr %l445, !tbaa !21
  %t1052 = load ptr, ptr %l444, !tbaa !29
  %t1053 = icmp ne ptr %t1052, null
  br i1 %t1053, label %bb194, label %bb195
bb194:
  %t1055 = load ptr, ptr %l444, !tbaa !29
  %t1056 = load i64, ptr %t1055
  %t1058 = icmp eq i64 %t1056, 3
  store i1 %t1058, ptr %l445, !tbaa !21
  br label %bb195
bb195:
  %t1059 = load i1, ptr %l445, !tbaa !21
  br i1 %t1059, label %bb196, label %bb197
bb196:
  %t1060 = load ptr, ptr %l45, !tbaa !29
  %t1062 = getelementptr { i64, [6 x i64] }, ptr %t1060, i32 0, i32 1
  %t1063 = getelementptr { ptr, ptr }, ptr %t1062, i32 0, i32 1
  %t1064 = load ptr, ptr %t1063
  store ptr %t1064, ptr %l46, !tbaa !29
  br label %bb198
bb197:
  br label %bb220
bb198:
  %t1066 = load ptr, ptr %l46, !tbaa !29
  %t1068 = icmp eq ptr %t1066, null
  %t1070 = xor i1 %t1068, true
  br i1 %t1070, label %bb199, label %bb200
bb199:
  store %olang.scope zeroinitializer, ptr %s41
  %t1072 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1072, ptr %l453, !tbaa !29
  %t1073 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1073, ptr %l454, !tbaa !29
  %t1074 = load ptr, ptr %l0, !tbaa !29
  %t1076 = getelementptr %"compiler/check:Checker", ptr %t1074, i32 0, i32 1
  %t1077 = load ptr, ptr %t1076, !tbaa !29
  %t1078 = load i32, ptr %l3, !tbaa !23
  %t1081 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t1077, i32 %t1078)
  store i32 %t1081, ptr %l458
  br label %bb201
bb200:
  br label %bb219
bb201:
  %t1082 = load ptr, ptr %l46, !tbaa !29
  %t1084 = getelementptr %"compiler/ast:Func", ptr %t1082, i32 0, i32 3
  %t1085 = load ptr, ptr %t1084, !tbaa !29
  %t1087 = getelementptr %"compiler/ast:Sig", ptr %t1085, i32 0, i32 0
  %t1088 = load { i64, ptr }, ptr %t1087, !tbaa !27
  %t1089 = load ptr, ptr %l454, !tbaa !29
  %t1090 = load i32, ptr %l458, !tbaa !23
  %t1092 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s41, ptr %v0, ptr %t1089, i32 %t1090, ptr null, { i64, ptr } %t1088)
  store i32 %t1092, ptr %l462
  br label %bb202
bb202:
  %t1093 = load ptr, ptr %l453, !tbaa !29
  %t1094 = load i32, ptr %l462, !tbaa !23
  %t1095 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s41, ptr %t1093, i32 %t1094)
  store { i64, ptr } %t1095, ptr %l463
  br label %bb203
bb203:
  %t1096 = load { i64, ptr }, ptr %l463, !tbaa !27
  store { i64, ptr } %t1096, ptr %l47, !tbaa !27
  %t1097 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1099 = call i64 @compiler_2fexplain_2efirstClose(ptr %s41, { i64, ptr } %t1097)
  store i64 %t1099, ptr %l465
  br label %bb204
bb204:
  %t1100 = load i64, ptr %l465, !tbaa !24
  store i64 %t1100, ptr %l48, !tbaa !24
  store ptr %l2, ptr %l466, !tbaa !29
  %t1101 = load i64, ptr %l48, !tbaa !24
  %t1103 = add i64 %t1101, 1
  store i64 %t1103, ptr %l468, !tbaa !24
  %t1104 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1105 = extractvalue { i64, ptr } %t1104, 0
  store i64 %t1105, ptr %l469, !tbaa !24
  %t1106 = icmp sge i64 2, 0
  br i1 %t1106, label %bb205, label %bb206
bb205:
  %t1108 = load i64, ptr %l468, !tbaa !24
  %t1109 = icmp sle i64 2, %t1108
  br i1 %t1109, label %bb207, label %bb208
bb206:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb207:
  %t1111 = load i64, ptr %l468, !tbaa !24
  %t1112 = load i64, ptr %l469, !tbaa !24
  %t1113 = icmp sle i64 %t1111, %t1112
  br i1 %t1113, label %bb209, label %bb210
bb208:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb209:
  %t1115 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t1116 = load ptr, ptr %t1115, !tbaa !27
  %t1117 = load i64, ptr %l468, !tbaa !24
  %t1118 = getelementptr i8, ptr %t1116, i64 2
  %t1119 = sub i64 %t1117, 2
  %t1120 = insertvalue { i64, ptr } undef, i64 %t1119, 0
  %t1121 = insertvalue { i64, ptr } %t1120, ptr %t1118, 1
  store { i64, ptr } %t1121, ptr %l473, !tbaa !27
  %t1122 = load i64, ptr %l48, !tbaa !24
  %t1124 = add i64 %t1122, 1
  store i64 %t1124, ptr %l475, !tbaa !24
  %t1125 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1127 = extractvalue { i64, ptr } %t1125, 0
  store i64 %t1127, ptr %l477, !tbaa !24
  %t1128 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1129 = extractvalue { i64, ptr } %t1128, 0
  store i64 %t1129, ptr %l478, !tbaa !24
  %t1130 = load i64, ptr %l475, !tbaa !24
  %t1131 = icmp sge i64 %t1130, 0
  br i1 %t1131, label %bb211, label %bb212
bb210:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb211:
  %t1133 = load i64, ptr %l475, !tbaa !24
  %t1134 = load i64, ptr %l477, !tbaa !24
  %t1135 = icmp sle i64 %t1133, %t1134
  br i1 %t1135, label %bb213, label %bb214
bb212:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb213:
  %t1137 = load i64, ptr %l477, !tbaa !24
  %t1138 = load i64, ptr %l478, !tbaa !24
  %t1139 = icmp sle i64 %t1137, %t1138
  br i1 %t1139, label %bb215, label %bb216
bb214:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb215:
  %t1141 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t1142 = load ptr, ptr %t1141, !tbaa !27
  %t1143 = load i64, ptr %l475, !tbaa !24
  %t1144 = load i64, ptr %l477, !tbaa !24
  %t1145 = getelementptr i8, ptr %t1142, i64 %t1143
  %t1146 = sub i64 %t1144, %t1143
  %t1147 = insertvalue { i64, ptr } undef, i64 %t1146, 0
  %t1148 = insertvalue { i64, ptr } %t1147, ptr %t1145, 1
  %t1150 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s41, ptr %s41, { i64, ptr } %t1148)
  store { i64, ptr } %t1150, ptr %l483
  br label %bb217
bb216:
  call void @__olang_check_failed(ptr @olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41)
  unreachable
bb217:
  %t1151 = load { i64, ptr }, ptr %l473, !tbaa !27
  %t1152 = extractvalue { i64, ptr } %t1151, 1
  %t1153 = extractvalue { i64, ptr } %t1151, 0
  %t1154 = load { i64, ptr }, ptr %l483, !tbaa !27
  %t1155 = extractvalue { i64, ptr } %t1154, 1
  %t1156 = extractvalue { i64, ptr } %t1154, 0
  %t1157 = add i64 %t1153, %t1156
  %t1158 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t1157)
  call void @olang_textcopy(ptr %t1158, ptr %t1152, i64 %t1153)
  %t1159 = getelementptr i8, ptr %t1158, i64 %t1153
  call void @olang_textcopy(ptr %t1159, ptr %t1155, i64 %t1156)
  %t1160 = insertvalue { i64, ptr } undef, i64 %t1157, 0
  %t1161 = insertvalue { i64, ptr } %t1160, ptr %t1158, 1
  %t1163 = extractvalue { i64, ptr } %t1161, 0
  %t1164 = extractvalue { i64, ptr } %t1161, 1
  %t1165 = mul i64 %t1163, 1
  %t1166 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t1165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1166, ptr %t1164, i64 %t1165, i1 false)
  %t1167 = insertvalue { i64, ptr } undef, i64 %t1163, 0
  %t1168 = insertvalue { i64, ptr } %t1167, ptr %t1166, 1
  %t1169 = load ptr, ptr %l466, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s41, ptr %t1169, { i64, ptr } %t1168)
  br label %bb218
bb218:
  call void @__olang_scope_close(ptr %s41)
  br label %bb219
bb219:
  br label %bb225
bb220:
  br i1 true, label %bb221, label %bb222
bb221:
  br label %bb223
bb222:
  br label %bb224
bb223:
  br label %bb225
bb224:
  call void @__olang_check_failed(ptr @olang_loc_63a734a7069861cf_349064956b27c4f3)
  unreachable
bb225:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 10)
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s38)
  br label %bb279
bb227:
  %t1172 = load i32, ptr %l6
  %t1174 = trunc i64 0 to i32
  %t1175 = icmp eq i32 %t1172, %t1174
  br i1 %t1175, label %bb228, label %bb229
bb228:
  br label %bb230
bb229:
  br label %bb278
bb230:
  store %olang.scope zeroinitializer, ptr %s44
  %t1177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1177, ptr %l489, !tbaa !29
  %t1178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1178, ptr %l490, !tbaa !29
  %t1179 = load ptr, ptr %l0, !tbaa !29
  %t1181 = getelementptr %"compiler/check:Checker", ptr %t1179, i32 0, i32 1
  %t1182 = load ptr, ptr %t1181, !tbaa !29
  %t1183 = load i32, ptr %l3, !tbaa !23
  %t1186 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t1182, i32 %t1183)
  store i32 %t1186, ptr %l494
  br label %bb231
bb231:
  %t1187 = load ptr, ptr %l0, !tbaa !29
  %t1189 = getelementptr %"compiler/check:Checker", ptr %t1187, i32 0, i32 1
  %t1190 = load ptr, ptr %t1189, !tbaa !29
  %t1191 = load i32, ptr %l1, !tbaa !23
  %t1194 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t1190, i32 %t1191)
  store ptr %t1194, ptr %l498
  br label %bb232
bb232:
  %t1195 = load ptr, ptr %l498, !tbaa !29
  store ptr %t1195, ptr %l49, !tbaa !29
  %t1196 = load ptr, ptr %l49, !tbaa !29
  %t1198 = icmp eq ptr %t1196, null
  br i1 %t1198, label %bb233, label %bb234
bb233:
  call void @__olang_check_failed(ptr @olang_loc_c0b6a28f79589111_a09bca6888f93f2d)
  unreachable
bb234:
  br label %bb235
bb235:
  %t1200 = load ptr, ptr %l49, !tbaa !29
  %t1202 = call { i64, ptr } @compiler_2fexplain_2ectorParams(ptr %v0, ptr %t1200)
  store { i64, ptr } %t1202, ptr %l502
  br label %bb236
bb236:
  %t1203 = load ptr, ptr %l490, !tbaa !29
  %t1204 = load i32, ptr %l494, !tbaa !23
  %t1205 = load { i64, ptr }, ptr %l502, !tbaa !27
  %t1206 = call i32 @compiler_2fexplain_2enamed(ptr %v0, ptr %s44, ptr %v0, ptr %t1203, i32 %t1204, ptr null, { i64, ptr } %t1205)
  store i32 %t1206, ptr %l503
  br label %bb237
bb237:
  %t1207 = load ptr, ptr %l489, !tbaa !29
  %t1208 = load i32, ptr %l503, !tbaa !23
  %t1209 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s44, ptr %t1207, i32 %t1208)
  store { i64, ptr } %t1209, ptr %l504
  br label %bb238
bb238:
  %t1210 = load { i64, ptr }, ptr %l504, !tbaa !27
  store { i64, ptr } %t1210, ptr %l50, !tbaa !27
  %t1211 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t1213 = call i64 @compiler_2fexplain_2efirstClose(ptr %s44, { i64, ptr } %t1211)
  store i64 %t1213, ptr %l506
  br label %bb239
bb239:
  %t1214 = load i64, ptr %l506, !tbaa !24
  store i64 %t1214, ptr %l51, !tbaa !24
  store ptr %l2, ptr %l507, !tbaa !29
  %t1215 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1215, ptr %l508, !tbaa !27
  %t1216 = load i64, ptr %l51, !tbaa !24
  %t1218 = add i64 %t1216, 1
  store i64 %t1218, ptr %l510, !tbaa !24
  %t1219 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t1220 = extractvalue { i64, ptr } %t1219, 0
  store i64 %t1220, ptr %l511, !tbaa !24
  %t1221 = icmp sge i64 2, 0
  br i1 %t1221, label %bb240, label %bb241
bb240:
  %t1223 = load i64, ptr %l510, !tbaa !24
  %t1224 = icmp sle i64 2, %t1223
  br i1 %t1224, label %bb242, label %bb243
bb241:
  call void @__olang_check_failed(ptr @olang_loc_26a1398b9a278a82_457563734b32d35e)
  unreachable
bb242:
  %t1226 = load i64, ptr %l510, !tbaa !24
  %t1227 = load i64, ptr %l511, !tbaa !24
  %t1228 = icmp sle i64 %t1226, %t1227
  br i1 %t1228, label %bb244, label %bb245
bb243:
  call void @__olang_check_failed(ptr @olang_loc_26a1398b9a278a82_457563734b32d35e)
  unreachable
bb244:
  %t1230 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t1231 = load ptr, ptr %t1230, !tbaa !27
  %t1232 = load i64, ptr %l510, !tbaa !24
  %t1233 = getelementptr i8, ptr %t1231, i64 2
  %t1234 = sub i64 %t1232, 2
  %t1235 = insertvalue { i64, ptr } undef, i64 %t1234, 0
  %t1236 = insertvalue { i64, ptr } %t1235, ptr %t1233, 1
  store { i64, ptr } %t1236, ptr %l515, !tbaa !27
  %t1237 = load i64, ptr %l51, !tbaa !24
  %t1239 = add i64 %t1237, 1
  store i64 %t1239, ptr %l517, !tbaa !24
  %t1240 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t1242 = extractvalue { i64, ptr } %t1240, 0
  store i64 %t1242, ptr %l519, !tbaa !24
  %t1243 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t1244 = extractvalue { i64, ptr } %t1243, 0
  store i64 %t1244, ptr %l520, !tbaa !24
  %t1245 = load i64, ptr %l517, !tbaa !24
  %t1246 = icmp sge i64 %t1245, 0
  br i1 %t1246, label %bb246, label %bb247
bb245:
  call void @__olang_check_failed(ptr @olang_loc_26a1398b9a278a82_457563734b32d35e)
  unreachable
bb246:
  %t1248 = load i64, ptr %l517, !tbaa !24
  %t1249 = load i64, ptr %l519, !tbaa !24
  %t1250 = icmp sle i64 %t1248, %t1249
  br i1 %t1250, label %bb248, label %bb249
bb247:
  call void @__olang_check_failed(ptr @olang_loc_26a1398b9a278a82_457563734b32d35e)
  unreachable
bb248:
  %t1252 = load i64, ptr %l519, !tbaa !24
  %t1253 = load i64, ptr %l520, !tbaa !24
  %t1254 = icmp sle i64 %t1252, %t1253
  br i1 %t1254, label %bb250, label %bb251
bb249:
  call void @__olang_check_failed(ptr @olang_loc_26a1398b9a278a82_457563734b32d35e)
  unreachable
bb250:
  %t1256 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t1257 = load ptr, ptr %t1256, !tbaa !27
  %t1258 = load i64, ptr %l517, !tbaa !24
  %t1259 = load i64, ptr %l519, !tbaa !24
  %t1260 = getelementptr i8, ptr %t1257, i64 %t1258
  %t1261 = sub i64 %t1259, %t1258
  %t1262 = insertvalue { i64, ptr } undef, i64 %t1261, 0
  %t1263 = insertvalue { i64, ptr } %t1262, ptr %t1260, 1
  %t1265 = call { i64, ptr } @compiler_2fexplain_2eerrorsAfter(ptr %s44, ptr %s44, { i64, ptr } %t1263)
  store { i64, ptr } %t1265, ptr %l525
  br label %bb252
bb251:
  call void @__olang_check_failed(ptr @olang_loc_26a1398b9a278a82_457563734b32d35e)
  unreachable
bb252:
  %t1266 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t1267 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t1268 = load { i64, ptr }, ptr %l508, !tbaa !27
  %t1269 = extractvalue { i64, ptr } %t1268, 1
  %t1270 = extractvalue { i64, ptr } %t1268, 0
  %t1271 = add i64 %t1267, %t1270
  %t1272 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t1273 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t1274 = add i64 %t1271, %t1273
  %t1275 = load { i64, ptr }, ptr %l515, !tbaa !27
  %t1276 = extractvalue { i64, ptr } %t1275, 1
  %t1277 = extractvalue { i64, ptr } %t1275, 0
  %t1278 = add i64 %t1274, %t1277
  %t1279 = load { i64, ptr }, ptr %l525, !tbaa !27
  %t1280 = extractvalue { i64, ptr } %t1279, 1
  %t1281 = extractvalue { i64, ptr } %t1279, 0
  %t1282 = add i64 %t1278, %t1281
  %t1283 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t1284 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t1285 = add i64 %t1282, %t1284
  %t1286 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1285)
  call void @olang_textcopy(ptr %t1286, ptr %t1266, i64 %t1267)
  %t1287 = getelementptr i8, ptr %t1286, i64 %t1267
  call void @olang_textcopy(ptr %t1287, ptr %t1269, i64 %t1270)
  %t1288 = getelementptr i8, ptr %t1287, i64 %t1270
  call void @olang_textcopy(ptr %t1288, ptr %t1272, i64 %t1273)
  %t1289 = getelementptr i8, ptr %t1288, i64 %t1273
  call void @olang_textcopy(ptr %t1289, ptr %t1276, i64 %t1277)
  %t1290 = getelementptr i8, ptr %t1289, i64 %t1277
  call void @olang_textcopy(ptr %t1290, ptr %t1280, i64 %t1281)
  %t1291 = getelementptr i8, ptr %t1290, i64 %t1281
  call void @olang_textcopy(ptr %t1291, ptr %t1283, i64 %t1284)
  %t1292 = insertvalue { i64, ptr } undef, i64 %t1285, 0
  %t1293 = insertvalue { i64, ptr } %t1292, ptr %t1286, 1
  %t1295 = extractvalue { i64, ptr } %t1293, 0
  %t1296 = extractvalue { i64, ptr } %t1293, 1
  %t1297 = mul i64 %t1295, 1
  %t1298 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1297)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1298, ptr %t1296, i64 %t1297, i1 false)
  %t1299 = insertvalue { i64, ptr } undef, i64 %t1295, 0
  %t1300 = insertvalue { i64, ptr } %t1299, ptr %t1298, 1
  %t1301 = load ptr, ptr %l507, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s44, ptr %t1301, { i64, ptr } %t1300)
  br label %bb253
bb253:
  %t1303 = load ptr, ptr %l0, !tbaa !29
  %t1305 = getelementptr %"compiler/check:Checker", ptr %t1303, i32 0, i32 1
  %t1306 = load ptr, ptr %t1305, !tbaa !29
  %t1307 = load i32, ptr %l1, !tbaa !23
  %t1310 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t1306, i32 %t1307)
  store ptr %t1310, ptr %l531
  br label %bb254
bb254:
  %t1311 = load ptr, ptr %l531, !tbaa !29
  store ptr %t1311, ptr %l52, !tbaa !29
  %t1312 = load ptr, ptr %l52, !tbaa !29
  %t1314 = icmp eq ptr %t1312, null
  br i1 %t1314, label %bb255, label %bb256
bb255:
  call void @__olang_check_failed(ptr @olang_loc_5d61f9982e85490b_19b97e7dc205ed37)
  unreachable
bb256:
  br label %bb257
bb257:
  %t1316 = load ptr, ptr %l52, !tbaa !29
  %t1319 = getelementptr %"compiler/ast:TypeDecl", ptr %t1316, i32 0, i32 3
  %t1320 = load ptr, ptr %t1319, !tbaa !29
  store ptr %t1320, ptr %l53, !tbaa !29
  %t1322 = load ptr, ptr %l53, !tbaa !29
  store ptr %t1322, ptr %l537, !tbaa !29
  store i1 false, ptr %l538, !tbaa !21
  %t1323 = load ptr, ptr %l537, !tbaa !29
  %t1324 = icmp ne ptr %t1323, null
  br i1 %t1324, label %bb258, label %bb259
bb258:
  %t1326 = load ptr, ptr %l537, !tbaa !29
  %t1327 = load i64, ptr %t1326
  %t1329 = icmp eq i64 %t1327, 0
  store i1 %t1329, ptr %l538, !tbaa !21
  br label %bb259
bb259:
  %t1330 = load i1, ptr %l538, !tbaa !21
  br i1 %t1330, label %bb260, label %bb261
bb260:
  %t1331 = load ptr, ptr %l53, !tbaa !29
  %t1333 = getelementptr { i64, [6 x i64] }, ptr %t1331, i32 0, i32 1
  %t1334 = getelementptr { ptr }, ptr %t1333, i32 0, i32 0
  %t1335 = load ptr, ptr %t1334
  store ptr %t1335, ptr %l54, !tbaa !29
  br label %bb262
bb261:
  br label %bb271
bb262:
  %t1337 = load ptr, ptr %l54, !tbaa !29
  %t1339 = getelementptr %"compiler/ast:StructBody", ptr %t1337, i32 0, i32 1
  %t1340 = load ptr, ptr %t1339, !tbaa !29
  %t1342 = icmp eq ptr %t1340, null
  %t1344 = xor i1 %t1342, true
  br i1 %t1344, label %bb263, label %bb264
bb263:
  store %olang.scope zeroinitializer, ptr %s47
  store ptr %l2, ptr %l547, !tbaa !29
  %t1346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1346, ptr %l548, !tbaa !29
  %t1347 = load ptr, ptr %l54, !tbaa !29
  %t1349 = getelementptr %"compiler/ast:StructBody", ptr %t1347, i32 0, i32 1
  %t1350 = load ptr, ptr %t1349, !tbaa !29
  %t1352 = icmp eq ptr %t1350, null
  br i1 %t1352, label %bb265, label %bb266
bb264:
  br label %bb270
bb265:
  call void @__olang_check_failed(ptr @olang_loc_36394c6e9ac2121c_fe6a572406577b18)
  unreachable
bb266:
  br label %bb267
bb267:
  %t1354 = load ptr, ptr %l54, !tbaa !29
  %t1356 = getelementptr %"compiler/ast:StructBody", ptr %t1354, i32 0, i32 1
  %t1357 = load ptr, ptr %t1356, !tbaa !29
  store ptr %t1357, ptr %l553, !tbaa !29
  %t1358 = load ptr, ptr %l0, !tbaa !29
  %t1360 = getelementptr %"compiler/check:Checker", ptr %t1358, i32 0, i32 1
  %t1361 = load ptr, ptr %t1360, !tbaa !29
  %t1362 = load i32, ptr %l1, !tbaa !23
  %t1365 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t1361, i32 %t1362)
  store i64 %t1365, ptr %l557
  br label %bb268
bb268:
  %t1366 = load ptr, ptr %l547, !tbaa !29
  %t1367 = load ptr, ptr %l548, !tbaa !29
  %t1368 = load ptr, ptr %l553, !tbaa !29
  %t1369 = load i64, ptr %l557, !tbaa !24
  call void @compiler_2fexplain_2econtract(ptr %s0, ptr %v0, ptr %v0, ptr %s47, ptr %t1366, ptr %t1367, ptr %t1368, i64 %t1369, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d79, i32 0, i32 1) })
  br label %bb269
bb269:
  call void @__olang_scope_close(ptr %s47)
  br label %bb270
bb270:
  br label %bb276
bb271:
  br i1 true, label %bb272, label %bb273
bb272:
  br label %bb274
bb273:
  br label %bb275
bb274:
  br label %bb276
bb275:
  call void @__olang_check_failed(ptr @olang_loc_94295b17b6f8c92c_4d0fd7ff7c3c10d0)
  unreachable
bb276:
  %t1370 = load ptr, ptr %l0, !tbaa !29
  %t1371 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2efields(ptr %s0, ptr %v0, ptr %l2, ptr %t1370, i32 %t1371)
  br label %bb277
bb277:
  call void @__olang_scope_close(ptr %s44)
  br label %bb279
bb278:
  call void @__olang_check_failed(ptr @olang_loc_a0f18a4f5ed44bdd_2a81aa9ada6a661)
  unreachable
bb279:
  %t1375 = load ptr, ptr %l0, !tbaa !29
  %t1376 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fexplain_2ebuilders(ptr %s0, ptr %v0, ptr %l2, ptr %t1375, i32 %t1376)
  br label %bb280
bb280:
  %t1380 = load ptr, ptr %l0, !tbaa !29
  %t1381 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2emethods(ptr %s0, ptr %v0, ptr %l2, ptr %t1380, i32 %t1381)
  br label %bb281
bb281:
  %t1385 = load ptr, ptr %l0, !tbaa !29
  %t1386 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fexplain_2etraitsMet(ptr %s0, ptr %v0, ptr %l2, ptr %t1385, i32 %t1386)
  br label %bb282
bb282:
  %t1391 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t1391, ptr %l571
  br label %bb283
bb283:
  %t1392 = load { i64, ptr }, ptr %l571, !tbaa !27
  store { i64, ptr } %t1392, ptr %l572, !tbaa !27
  %t1393 = load { i64, ptr }, ptr %l572, !tbaa !27
  %t1394 = extractvalue { i64, ptr } %t1393, 0
  store i64 %t1394, ptr %l573, !tbaa !24
  %t1395 = load i64, ptr %l573, !tbaa !24
  %t1396 = mul i64 %t1395, 1
  %t1397 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t1396)
  %t1398 = insertvalue { i64, ptr } undef, i64 %t1395, 0
  %t1399 = insertvalue { i64, ptr } %t1398, ptr %t1397, 1
  store { i64, ptr } %t1399, ptr %l574, !tbaa !27
  %t1400 = getelementptr { i64, ptr }, ptr %l574, i32 0, i32 1
  %t1401 = load ptr, ptr %t1400, !tbaa !27
  %t1402 = getelementptr { i64, ptr }, ptr %l572, i32 0, i32 1
  %t1403 = load ptr, ptr %t1402, !tbaa !27
  %t1404 = load i64, ptr %l573, !tbaa !24
  %t1405 = mul i64 %t1404, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1401, ptr %t1403, i64 %t1405, i1 false)
  %t1406 = load { i64, ptr }, ptr %l574, !tbaa !27
  store { i64, ptr } %t1406, ptr %l572, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t1407 = load { i64, ptr }, ptr %l572, !tbaa !27
  store { i64, ptr } %t1407, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fexplain_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %a2)
  store i32 %t19, ptr %l12
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l5, !tbaa !29
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i32, ptr %l12, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t20, i64 %t21, i32 %t22)
  store i64 %t23, ptr %l13
  br label %bb2
bb2:
  %t24 = load i64, ptr %l13, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i32 -1, ptr %l16, !tbaa !23
  br label %bb6
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t38 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t32, i64 %t33, i64 %t34)
  store i32 %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = load i32, ptr %l21, !tbaa !23
  store i32 %t39, ptr %l16, !tbaa !23
  br label %bb6
bb6:
  %t40 = load i32, ptr %l16, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fexplain_2etypeVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:varRow"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca i64
  %l37 = alloca i64
  %l59 = alloca %"compiler/generic:varRow"
  %l64 = alloca i1
  %l65 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l130 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t4, i64 %t5)
  store i64 %t8, ptr %l19
  br label %bb1
bb1:
  %t9 = load i64, ptr %l19, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sle i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t16, ptr %l24, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l25, !tbaa !24
  %t19 = load i64, ptr %l25, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l26, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l25, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t30, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t32 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t32, ptr %l27
  br label %bb5
bb5:
  %t33 = load %"std/prelude/text:StringBuilder", ptr %l27
  store %"std/prelude/text:StringBuilder" %t33, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 60)
  br label %bb6
bb6:
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l37, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb51
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load i64, ptr %l10, !tbaa !24
  %t94 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t88, i64 %t89, i64 %t90)
  store %"compiler/generic:varRow" %t94, ptr %l59
  br label %bb17
bb17:
  %t95 = load %"compiler/generic:varRow", ptr %l59
  store %"compiler/generic:varRow" %t95, ptr %l11
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i64, ptr %l1, !tbaa !24
  %t101 = load i64, ptr %l10, !tbaa !24
  %t105 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %t99, i64 %t100, i64 %t101)
  store i1 %t105, ptr %l64
  br label %bb18
bb18:
  %t106 = load i1, ptr %l64, !tbaa !21
  br i1 %t106, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l4, ptr %l65, !tbaa !29
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l2, !tbaa !24
  %t111 = icmp sgt i64 %t107, %t108
  br i1 %t111, label %bb21, label %bb22
bb20:
  br label %bb26
bb21:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb23
bb23:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/load:Loader", ptr %t119, i32 0, i32 3
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t123 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 1
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t122, i32 %t124)
  store { i64, ptr } %t127, ptr %l75
  br label %bb24
bb24:
  %t128 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = add i64 %t130, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t129, i64 %t130)
  %t136 = getelementptr i8, ptr %t135, i64 %t130
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t146 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t146, { i64, ptr } %t145)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb50
bb26:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t149 = load i64, ptr %l2, !tbaa !24
  %t152 = icmp sgt i64 %t148, %t149
  br i1 %t152, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l4, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  store ptr %l4, ptr %l82, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/generic:Program", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/load:Loader", ptr %t161, i32 0, i32 3
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t165 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 1
  %t166 = load i32, ptr %t165, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t164, i32 %t166)
  store { i64, ptr } %t169, ptr %l88
  br label %bb31
bb31:
  %t170 = load ptr, ptr %l82, !tbaa !29
  %t171 = load { i64, ptr }, ptr %l88, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t170, { i64, ptr } %t171)
  br label %bb32
bb32:
  %t172 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t173 = load i32, ptr %t172, !tbaa !23
  %t174 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t177 = icmp ne i32 %t173, %t174
  br i1 %t177, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l4, ptr %l92, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 2
  %t181 = load i32, ptr %t180, !tbaa !23
  %t184 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s7, ptr %t179, i32 %t181)
  store { i64, ptr } %t184, ptr %l95
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t185 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t187 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = add i64 %t186, %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t185, i64 %t186)
  %t192 = getelementptr i8, ptr %t191, i64 %t186
  call void @olang_textcopy(ptr %t192, ptr %t188, i64 %t189)
  %t193 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t191, 1
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t197 = extractvalue { i64, ptr } %t194, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  %t202 = load ptr, ptr %l92, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t202, { i64, ptr } %t201)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  %t204 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t205 = load i32, ptr %t204, !tbaa !23
  %t206 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t209 = icmp ne i32 %t205, %t206
  br i1 %t209, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = getelementptr %"compiler/generic:varRow", ptr %l11, i32 0, i32 3
  %t216 = load i32, ptr %t215, !tbaa !23
  %t219 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %s10, ptr %t214, i32 %t216)
  store { i64, ptr } %t219, ptr %l104
  br label %bb40
bb39:
  br label %bb49
bb40:
  %t220 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  %t222 = extractvalue { i64, ptr } %t220, 1
  %t223 = mul i64 %t221, 4
  %t224 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t223)
  call void @llvm.memcpy.p0.p0.i64(ptr %t224, ptr %t222, i64 %t223, i1 false)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  store { i64, ptr } %t226, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  store i64 %t230, ptr %l14, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s11
  %t232 = load i64, ptr %l13, !tbaa !24
  %t233 = load i64, ptr %l14, !tbaa !24
  %t236 = icmp slt i64 %t232, %t233
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s11)
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t240 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t240, ptr %l112, !tbaa !27
  %t241 = load i64, ptr %l13, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i32, ptr %t244, i64 %t241
  %t246 = load i32, ptr %t245, !tbaa !33
  store ptr %l4, ptr %l115, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t252 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s11, ptr %t248, i32 %t246)
  store { i64, ptr } %t252, ptr %l118
  br label %bb45
bb45:
  %t253 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t255 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = add i64 %t254, %t257
  %t259 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t253, i64 %t254)
  %t260 = getelementptr i8, ptr %t259, i64 %t254
  call void @olang_textcopy(ptr %t260, ptr %t256, i64 %t257)
  %t261 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t259, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } %t262, 1
  %t266 = mul i64 %t264, 1
  %t267 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t267, ptr %t265, i64 %t266, i1 false)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t270 = load ptr, ptr %l115, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t270, { i64, ptr } %t269)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb47
bb47:
  %t272 = load i64, ptr %l13, !tbaa !24
  %t274 = add i64 %t272, 1
  store i64 %t274, ptr %l13, !tbaa !24
  br label %bb41
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s3)
  br label %bb50
bb50:
  %t276 = load i64, ptr %l9, !tbaa !24
  %t278 = add i64 %t276, 1
  store i64 %t278, ptr %l9, !tbaa !24
  br label %bb13
bb51:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l4, i8 62)
  br label %bb52
bb52:
  %t282 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l4)
  store { i64, ptr } %t282, ptr %l127
  br label %bb53
bb53:
  %t283 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t283, ptr %l128, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  store i64 %t285, ptr %l129, !tbaa !24
  %t286 = load i64, ptr %l129, !tbaa !24
  %t287 = mul i64 %t286, 1
  %t288 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t287)
  %t289 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  store { i64, ptr } %t290, ptr %l130, !tbaa !27
  %t291 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = load i64, ptr %l129, !tbaa !24
  %t296 = mul i64 %t295, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t292, ptr %t294, i64 %t296, i1 false)
  %t297 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t297, ptr %l128, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t298 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t298, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @olang_2einit_2ecompiler_2fexplain() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fexplain_2eLongValue_2einit()
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_0(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca %"compiler/names:Entry"
  %l7 = alloca i32
  %l11 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/names:Table", ptr %t1, i32 0, i32 0
  %t7 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t3, i64 %a0)
  store %"compiler/names:Entry" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/names:Entry", ptr %l6, i32 0, i32 1
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/names:Table", ptr %t11, i32 0, i32 0
  %t17 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %vc0, ptr %s0, ptr %t13, i64 %a1)
  store %"compiler/names:Entry" %t17, ptr %l11
  br label %bb2
bb2:
  %t18 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 1
  %t19 = getelementptr %"compiler/source:Span", ptr %t18, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t21 = load i32, ptr %l7, !tbaa !23
  %t23 = icmp slt i32 %t21, %t20
  call void @__olang_scope_close(ptr %s0)
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d2 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d4 = private constant <{ i64, [82 x i8] }> <{ i64 0, [82 x i8] c"# commutes: the operator applies with its operands the other way round too (E31c)\0A" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]\0A" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d16 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"    instance " }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d19 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"        " }>, align 8
@.d20 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Generator" }>, align 8
@.d21 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Iterator" }>, align 8
@.d22 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"   # a generator: a call gives a " }>, align 8
@.d23 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"extern fn " }>, align 8
@.d24 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d28 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" mut " }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d30 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"   # set at startup\0A" }>, align 8
@.d31 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"   # set at startup\0A" }>, align 8
@.d32 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"...   # " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d34 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" characters\0A" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d37 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d43 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]\0A" }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cn" }>, align 8
@.d45 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Ct" }>, align 8
@.d46 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"   # its error set inferred" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d47 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d48 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"    meets " }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d52 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d53 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"extern type " }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d55 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d56 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" error" }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d60 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d62 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d63 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" trait" }>, align 8
@.d64 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" extends " }>, align 8
@.d65 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" for " }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d67 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d69 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d70 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" enum\0A" }>, align 8
@.d71 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d73 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" extends " }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d75 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d76 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"type " }>, align 8
@.d77 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" struct" }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d79 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d82 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d83 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d84 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d85 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_10922f4f875ba124_bbdc792b6e6bf8a8 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eBodyOfInstance(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_35c12625cc2f75ee_5b08f4318e637d4a = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9f8e1ebc65423eb_b98ce2e98ea0027 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d02d672b10a10044_edb2f07898a0d008 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_430839a36fc86f5_d60a2ea9e5c9a99 = external constant [0 x i8]
@olang_loc_8ab7a894dba5a8d7_a5979f5013b78ba3 = external constant [0 x i8]
@olang_loc_5177bd7d484351dd_5d0dbb04dc509331 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_e7ca39a48e286d3f_b849249cb4ab4933 = external constant [0 x i8]
@olang_loc_ec0929e0cef23b20_10aa079683981964 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_f15d5c61f6a9e0c3_25b5f938bbb7b67 = external constant [0 x i8]
@olang_loc_6448edf003c535f3_ebaded49d6e07c97 = external constant [0 x i8]
@olang_loc_979fe2e14fb6de05_5947910940c194f1 = external constant [0 x i8]
@olang_loc_8f9ce818ff296c0e_932c83e6c6076d82 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d16c6b36ae6c900f_110b33433d32ce53 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_35ffc19e50bbc737_e52638f1e81552b = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7e282c17ef3fe15e_3580b6f44c3439a2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_36a09f0a29856ad4_1f4c57e6e1803c38 = external constant [0 x i8]
@olang_loc_6896438a508f3415_b4ea8b5a918f5051 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2d047dc2e8ba79e9_b3960442abafce65 = external constant [0 x i8]
@olang_loc_62f5937584004bfc_64dbf784650d4808 = external constant [0 x i8]
@olang_loc_fb9ea6e5b3ca71a7_d8a084b91cdc3d23 = external constant [0 x i8]
@olang_loc_4b0ecce8a943eeca_78f5e61d37c8c546 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRenderBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { { i64, ptr }, i1 } @compiler_2finterp_2ecompiler_2finterp_3aExec_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %a0)
@olang_loc_8383a0ec0de75e1f_623ffa8ab7fe468b = external constant [0 x i8]
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@olang_loc_24a71f1628ab63b4_59f385be22d57b28 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParamNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInfersErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_Hb234e65a2b42ee429ada36859295662b(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_85d3fea1d96f25de_7b2f6a0f1962587a = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorMembers(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_24a17849deeaf8b3_b2bce68c41c61f8f = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a185ff5f85e75430_c999a61f9f0eedcc = external constant [0 x i8]
@olang_loc_60d3429e949e0f0f_c9b6e73225d64a3b = external constant [0 x i8]
@olang_loc_9e7f77c067ece8f1_2a0afb54e00d35 = external constant [0 x i8]
@olang_loc_7b101762ff8ffda9_ced5d247097fb61d = external constant [0 x i8]
@olang_loc_e7cf316846733e6c_5d444c1e6a143730 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
@olang_loc_4e8cd845c965dada_c1eb458e34ff6f7e = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_12615553f525a8d6_4928bb51d62e2722 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_4a756130778b14bd_8f8d371a853a3189 = external constant [0 x i8]
@olang_loc_b6c637a5f4084e9b_d531d6adfcd75e3f = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fdc41c6a76f01a06_9680a398378cbf4a = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4a4f0a2a7fb90dfd_df3cc4daa7702d41 = external constant [0 x i8]
@olang_loc_63a734a7069861cf_349064956b27c4f3 = external constant [0 x i8]
@olang_loc_c0b6a28f79589111_a09bca6888f93f2d = external constant [0 x i8]
@olang_loc_26a1398b9a278a82_457563734b32d35e = external constant [0 x i8]
@olang_loc_5d61f9982e85490b_19b97e7dc205ed37 = external constant [0 x i8]
@olang_loc_36394c6e9ac2121c_fe6a572406577b18 = external constant [0 x i8]
@olang_loc_94295b17b6f8c92c_4d0fd7ff7c3c10d0 = external constant [0 x i8]
@olang_loc_a0f18a4f5ed44bdd_2a81aa9ada6a661 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
